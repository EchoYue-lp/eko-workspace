#[cfg(test)]
mod mixed_reasoning_replay_contract_tests {
    use super::*;

    fn original_input() -> Value {
        json!([
            {"type":"message","id":"before","role":"assistant","phase":"commentary",
             "content":[{"type":"output_text","text":"before","annotations":[]}]},
            {"type":"reasoning","id":"mixed-reasoning","encrypted_content":"sealed-original",
             "summary":[{"type":"summary_text","text":"同文🙂"},{"type":"summary_text","text":"摘要二"}],
             "content":[{"type":"reasoning_text","text":"同文🙂"},{"type":"reasoning_text","text":"公开二"}]},
            {"type":"message","id":"after","role":"assistant","phase":"final_answer",
             "content":[{"type":"output_text","text":"after","annotations":[]}]}
        ])
    }

    fn full_response() -> Value {
        json!({"id":"mixed-response","status":"completed","output":original_input()})
    }

    fn next_request(message: Message, stream: bool) -> Result<Value> {
        // 同一Message先经持久化格式往返，再走真实request_body；不调用HTTP。
        let restored = serde_json::from_value(serde_json::to_value(message)?)?;
        let client = ResponsesClient::new(LlmConfig {
            provider_name: Some("test-provider".into()),
            api_protocol: LlmApiProtocol::Responses,
            base_url: "https://api.example.test/v1/responses".into(),
            api_key: "fixture-key".into(),
            model: "gpt-test".into(),
            input_modalities: echo_core::llm::ModelInputModality::all_supported(),
            thinking_protocol: echo_core::llm::ThinkingProtocol::OpenaiReasoningEffort,
            timeouts: echo_core::llm::LlmTimeouts::default(),
        })?;
        client.request_body(
            &ChatRequest {
                messages: vec![restored, Message::user("继续".into())],
                ..Default::default()
            },
            stream,
        )
    }

    fn assert_next_request(message: Message) -> Result<()> {
        let mut expected = original_input();
        expected
            .as_array_mut()
            .ok_or_else(|| invalid_response("fixture input must be an array"))?
            .push(json!({"type":"message","role":"user","content":[{"type":"input_text","text":"继续"}]}));
        for stream in [false, true] {
            let body = next_request(message.clone(), stream)?;
            assert_eq!(body.get("input"), Some(&expected));
            assert_eq!(body.get("stream").and_then(Value::as_bool), Some(stream));
        }
        Ok(())
    }

    fn streamed_message(item_done: Option<Value>, prefix: bool) -> Result<Message> {
        let mut events =
            vec![json!({"type":"response.created","response":{"id":"mixed-response"}})];
        if prefix {
            events.extend([
                json!({"type":"response.reasoning_summary_text.delta","item_id":"mixed-reasoning","output_index":1,"summary_index":0,"delta":"同文"}),
                // 不同content索引可以交错到达；下一请求必须按原坐标排回0、1。
                json!({"type":"response.reasoning_text.delta","item_id":"mixed-reasoning","output_index":1,"content_index":1,"delta":"公开"}),
                json!({"type":"response.reasoning_text.delta","item_id":"mixed-reasoning","output_index":1,"content_index":0,"delta":"同文"}),
            ]);
        }
        if let Some(item) = item_done {
            events.push(json!({"type":"response.output_item.done","output_index":1,"item":item}));
        }
        events.push(json!({"type":"response.completed","response":full_response()}));
        let mut adapter = ResponsesStreamAdapter::default();
        let mut blocks = Vec::new();
        let mut terminals = 0usize;
        for event in events {
            if let Some(chunk) = adapter.map_event(event)? {
                terminals = terminals.saturating_add(usize::from(chunk.finish_reason.is_some()));
                blocks.extend(chunk.delta.assistant_blocks.unwrap_or_default());
            }
        }
        adapter.validate_transport_end("EOF")?;
        assert_eq!(terminals, 1);
        assert_eq!(
            blocks
                .iter()
                .filter(|block| matches!(block.reasoning, Some(ReasoningBlock::Opaque { .. })))
                .count(),
            1,
        );
        // 累积原canonical块，而非用公开正文重新合成provider原件。
        let mut message = Message::assistant("beforeafter".into());
        message.assistant_blocks = Some(blocks);
        Ok(message)
    }

    #[test]
    fn mixed_reasoning_nonstream_next_request_keeps_encrypted_summary_and_content_in_order()
    -> Result<()> {
        let message = response_to_chat(full_response())?.message;
        assert_next_request(message.clone())?;
        let mut reversed = message;
        reversed
            .assistant_blocks
            .as_mut()
            .ok_or_else(|| invalid_response("fixture native blocks missing"))?
            .reverse();
        // 同源Opaque可以先于或晚于明文入表；不能覆盖content，也不能误判重复item。
        assert_next_request(reversed)
    }

    #[test]
    fn mixed_reasoning_stream_next_request_deduplicates_only_carried_summary() -> Result<()> {
        let original = full_response();
        let item = original
            .pointer("/output/1")
            .cloned()
            .ok_or_else(|| invalid_response("fixture reasoning item missing"))?;
        for prefix in [false, true] {
            assert_next_request(streamed_message(Some(item.clone()), prefix)?)?;
            assert_next_request(streamed_message(None, prefix)?)?;
        }
        Ok(())
    }

    #[test]
    fn late_encrypted_after_plaintext_item_done_survives_persistence_and_next_request() -> Result<()>
    {
        let mut original = full_response();
        let item = original
            .pointer_mut("/output/1")
            .and_then(Value::as_object_mut)
            .ok_or_else(|| invalid_response("fixture reasoning item missing"))?;
        item.remove("encrypted_content");
        let public_item = Value::Object(item.clone());
        for prefix in [false, true] {
            assert_next_request(streamed_message(Some(public_item.clone()), prefix)?)?;
        }
        Ok(())
    }

    #[test]
    fn summary_not_carried_by_opaque_remains_once_with_original_content() -> Result<()> {
        for carried in [0, 1] {
            let mut message = response_to_chat(full_response())?.message;
            let opaque = message
                .assistant_blocks
                .as_mut()
                .and_then(|blocks| {
                    blocks
                        .iter_mut()
                        .find_map(|block| match &mut block.reasoning {
                            Some(ReasoningBlock::Opaque { summary, .. }) => Some(summary),
                            _ => None,
                        })
                })
                .ok_or_else(|| invalid_response("fixture opaque block missing"))?;
            opaque.truncate(carried);
            assert_next_request(message)?;
        }
        Ok(())
    }

    #[test]
    fn mixed_reasoning_replay_rejects_item_owner_and_summary_conflicts() -> Result<()> {
        for conflict in ["item", "owner", "summary"] {
            let mut message = response_to_chat(full_response())?.message;
            let target = if conflict == "summary" {
                "mixed-reasoning:summary:0"
            } else {
                "mixed-reasoning:content:0"
            };
            let block = message
                .assistant_blocks
                .as_mut()
                .and_then(|blocks| blocks.iter_mut().find(|block| block.block_id == target))
                .ok_or_else(|| invalid_response("fixture plaintext block missing"))?;
            if conflict == "summary" {
                block.delta = "冲突摘要".into();
            } else {
                let source = block
                    .provider_source
                    .as_mut()
                    .ok_or_else(|| invalid_response("fixture provider source missing"))?;
                if conflict == "item" {
                    source.item_id = "different-item".into();
                } else {
                    source.request_id = "different-request".into();
                    block.request_id = "different-request".into();
                }
            }
            assert!(
                next_request(message, false).is_err(),
                "冲突原件不得被Opaque去重吞掉：{conflict}"
            );
        }
        Ok(())
    }
}
