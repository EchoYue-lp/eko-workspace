# Responses 混合 reasoning 回放：增量候选

仅写本 ignored 目录。正式 F684、Frame 的 `next-source-684ad1-ignored/tree`、原 typed8 combined/candidate 均只读。此修正属于框架 provider 请求适配，复用唯一 canonical Message/source 坐标，不改共享类型、wire、自动重试或原 retry loop；provider error 的 `retryable=false` 不受影响。

## 反例与最小修正

base SHA 为 `907a31d17f49c165c03fe3cd510a654bedabc27f2604c63fa7322fffb1adae7d`。该源码接受同一 reasoning item 同时含 `encrypted_content`、`summary` 和 `content.reasoning_text`，canonical 块能保留三者；但 `native_history_to_responses` 的 `opaque_indexes` 把同 output_index 的明文全部跳过，下一请求没有 content。只把跳过条件改为 summary 也不够：明文先建 item 后，Opaque 的无条件 `items.insert` 会把合法同源 item 判成重复。

增量修正合并相同 source/item 的 encrypted 原件，保留原 content。去重键为 request_id＋item_id＋output_index＋summary index；仅当该摘要索引已由 Opaque 携带且文字相等时省去 canonical 镜像。不同摘要文本明确报错；Opaque 没携带的摘要继续按原索引追加。`reasoning_text` 即使与 summary 同文也独立保留。最终仍使用现有 BTreeMap 输出 item/content 顺序。跨 item/owner 或冲突摘要不会被去重吞掉。

## 补丁与测试定义

- `00-tests-first-on-typed8.patch`：只追加五个测试，base 907a31d，不改生产逻辑。
- `10-production-after-tests.patch`：在 tests-first 之后只修重放函数。
- `combined.increment.patch`：907a31d → 本增量 after；不是 F684 → 最终组合的替代总包。全部补丁在 echo-agent 仓库按 `-p1` 使用，由唯一 writer 决定采用时间。
- `00-legacy-f684-tests-only.patch`：相同测试直接追加至正式 F684 的 responses.rs（SHA 13a5cc1e…）；用于旧 API RED 准备，不含生产修改。

五个测试覆盖：非流式解析→Message serde→下一请求（含 Opaque/明文相反到达顺序）；流式无前缀/交错索引前缀、item.done/仅 completed；plaintext item.done 后 encrypted 晚到 completed，再持久化并发下一请求；Opaque 未携带的摘要不丢失；同 output 的 item、owner 与摘要冲突反控。每条正常下一请求同时走 `request_body(stream=false/true)`，包括后续 user 消息。测试仅构造客户端和请求 JSON，不执行 HTTP。

所有新测试只引用 F684 已有 Message/provider_source/serde、ChatRequest/LlmConfig 及私有 adapter/request_body API；不引用新 ProviderError 或新增 wire。**API 可用于旧 RED 不等于旧行为已通过**：late plaintext item.done 的 GREEN 依赖 typed8 内已包含的 prior4 明文接受修正，本增量不重复实现它。

## 证据边界与同步

准确 base/tests-first/after/补丁 hash 见 `manifest.json`。本轮仅允许源码审查、rustfmt 与 ignored 补丁机械应用核对；没有实际 Rust RED/GREEN、Cargo、validator、真实 API 或消费者执行资格。具体检查自然退出码见 `commands.json`；独立源码审查结论另记 `source-review.md`。

这是现有无损回放合同的局部修正，无新增公共能力、API 或使用方式；当前文档、examples、website 和 ADR 无需新增产品承诺，本交接记录缺口及采用边界。唯一下一步由 Frame/Root 在统一 safe point 采用增量并按批准窗口运行实际 RED→GREEN，不能把源码检查当作行为通过。
