//! Concurrent workflow: all agents execute the same input in parallel; results are aggregated via a merge function.

use super::{SharedAgent, StepOutput, Workflow, WorkflowOutput, shared_agent};
use echo_core::agent::Agent;
use echo_core::error::Result;
use futures::future::BoxFuture;
use std::time::Instant;
use tokio::task::JoinSet;
use tracing::{debug, info};

/// Result merge function
type MergeFn = Box<dyn Fn(Vec<String>) -> String + Send + Sync>;

fn default_merge(results: Vec<String>) -> String {
    results.join("\n---\n")
}

/// Concurrent workflow: all registered agents execute in parallel; results are merged via a `merge` function.
///
/// # Example
///
/// ```rust,no_run
/// use echo_core::agent::{Agent, AgentEvent};
/// use echo_core::error::Result;
/// use echo_orchestration::workflow::{ConcurrentWorkflow, Workflow};
/// use futures::future::BoxFuture;
/// use futures::stream::BoxStream;
///
/// # struct DummyAgent {
/// #     name: String,
/// # }
/// #
/// # impl DummyAgent {
/// #     fn new(name: impl Into<String>) -> Self {
/// #         Self { name: name.into() }
/// #     }
/// # }
/// #
/// # impl Agent for DummyAgent {
/// #     fn name(&self) -> &str { &self.name }
/// #     fn model_name(&self) -> &str { "mock-model" }
/// #     fn system_prompt(&self) -> &str { "You are a mock agent" }
/// #     fn execute_stream_message_with_invocation_context<'a>(
/// #         &'a self, message: echo_core::llm::types::Message,
/// #         _cancel: tokio_util::sync::CancellationToken, invocation: echo_core::agent::AgentInvocationContext,
/// #     ) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
/// #         Box::pin(async move {
/// #             let text = message.text_content().ok_or_else(|| echo_core::error::ReactError::Other("示例需要文本输入".into()))?;
/// #             let answer = format!("{}: {text}", self.name);
/// #             let execution = format!("example:{}", self.name);
/// #             let status = |kind, sequence| AgentEvent::ExecutionStatus(echo_core::agent::ExecutionStatus {
/// #                 adapter_generated: false, execution_id: execution.clone(), request_id: Some("example-response".into()), sequence,
/// #                 phase: echo_core::agent::AgentPhase::Terminal, status: kind, reason: None,
/// #             });
/// #             let events = vec![Ok(status(echo_core::agent::ExecutionStatusKind::Started, 0)),
/// #                 Ok(AgentEvent::FinalAnswer(answer)), Ok(status(echo_core::agent::ExecutionStatusKind::Settled, 1))];
/// #             Ok(Box::pin(async_stream::stream! {
/// #                 let _retained = (message, invocation);
/// #                 for event in events { yield event; }
/// #             }) as BoxStream<'a, Result<AgentEvent>>)
/// #         })
/// #     }
/// # }
///
/// # async fn example() -> Result<()> {
/// let agent_x = DummyAgent::new("tech");
/// let agent_y = DummyAgent::new("business");
///
/// let mut wf = ConcurrentWorkflow::builder()
///     .agent(agent_x)
///     .agent(agent_y)
///     .merge(|results| {
///         format!("Combined analysis:\n{}", results.join("\n\n"))
///     })
///     .build();
///
/// let output = wf.run("Analyze AI Agent development trends").await?;
/// println!("{}", output.result);
/// # Ok(())
/// # }
/// ```
pub struct ConcurrentWorkflow {
    agents: Vec<SharedAgent>,
    merge: MergeFn,
}

impl ConcurrentWorkflow {
    pub fn builder() -> ConcurrentWorkflowBuilder {
        ConcurrentWorkflowBuilder {
            agents: Vec::new(),
            merge: None,
        }
    }
}

impl Workflow for ConcurrentWorkflow {
    fn run<'a>(&'a mut self, input: &'a str) -> BoxFuture<'a, Result<WorkflowOutput>> {
        Box::pin(async move {
            let total_start = Instant::now();
            let agent_count = self.agents.len();

            info!(
                workflow = "concurrent",
                agents = agent_count,
                "⚡ Executing {} agents concurrently",
                agent_count
            );

            let mut handles = JoinSet::new();

            for (index, agent_handle) in self.agents.iter().enumerate() {
                let agent_handle = agent_handle.clone();
                let input = input.to_string();
                handles.spawn(async move {
                    let step_start = Instant::now();
                    let agent = agent_handle.as_ref();
                    let agent_name = agent.name().to_string();
                    debug!(workflow = "concurrent", agent = %agent_name, "▶ Starting execution");
                    let result = agent.execute(&input).await;
                    let elapsed = step_start.elapsed();
                    (index, agent_name, input, result, elapsed)
                });
            }

            let mut completed = Vec::with_capacity(agent_count);
            completed.resize_with(agent_count, || None);

            let mut first_error = None;
            while let Some(joined) = handles.join_next().await {
                let (index, agent_name, step_input, result, elapsed) = match joined {
                    Ok(value) => value,
                    Err(error) => {
                        first_error = Some(echo_core::error::ReactError::Other(format!(
                            "task join error: {error}"
                        )));
                        break;
                    }
                };
                let output = match result {
                    Ok(output) => output,
                    Err(error) => {
                        first_error = Some(error);
                        break;
                    }
                };
                info!(
                    workflow = "concurrent",
                    agent = %agent_name,
                    elapsed_ms = elapsed.as_millis(),
                    "✓ Agent completed"
                );

                let Some(slot) = completed.get_mut(index) else {
                    first_error = Some(echo_core::error::ReactError::Other(format!(
                        "task completed with invalid registration index {index}"
                    )));
                    break;
                };
                if slot
                    .replace((agent_name, step_input, output, elapsed))
                    .is_some()
                {
                    first_error = Some(echo_core::error::ReactError::Other(format!(
                        "task completed more than once for registration index {index}"
                    )));
                    break;
                }
            }
            if let Some(error) = first_error {
                handles.abort_all();
                while handles.join_next().await.is_some() {}
                return Err(error);
            }

            let mut step_outputs = Vec::with_capacity(agent_count);
            let mut results = Vec::with_capacity(agent_count);
            for completed_step in completed {
                let (agent_name, step_input, output, elapsed) =
                    completed_step.ok_or_else(|| {
                        echo_core::error::ReactError::Other(
                            "concurrent task completed without a registered result".to_string(),
                        )
                    })?;
                step_outputs.push(StepOutput {
                    agent_name,
                    input: step_input,
                    output: output.clone(),
                    elapsed,
                });
                results.push(output);
            }

            let merged = (self.merge)(results);

            Ok(WorkflowOutput {
                result: merged,
                steps: step_outputs,
                elapsed: total_start.elapsed(),
            })
        })
    }
}

/// [`ConcurrentWorkflow`] builder
pub struct ConcurrentWorkflowBuilder {
    agents: Vec<SharedAgent>,
    merge: Option<MergeFn>,
}

impl ConcurrentWorkflowBuilder {
    /// Add an agent to execute concurrently
    pub fn agent(mut self, agent: impl Agent + 'static) -> Self {
        self.agents.push(shared_agent(agent));
        self
    }

    /// Add an already-wrapped SharedAgent
    pub fn agent_shared(mut self, agent: SharedAgent) -> Self {
        self.agents.push(agent);
        self
    }

    /// Set the result merge function (default joins with `\n---\n`)
    pub fn merge(mut self, f: impl Fn(Vec<String>) -> String + Send + Sync + 'static) -> Self {
        self.merge = Some(Box::new(f));
        self
    }

    pub fn build(self) -> ConcurrentWorkflow {
        ConcurrentWorkflow {
            agents: self.agents,
            merge: self.merge.unwrap_or_else(|| Box::new(default_merge)),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use echo_core::agent::AgentEvent;
    use echo_core::error::ReactError;
    use futures::stream::BoxStream;
    use std::time::Duration;

    struct TestAgent {
        name: &'static str,
        fail: bool,
        delay: Duration,
    }

    impl Agent for TestAgent {
        fn name(&self) -> &str {
            self.name
        }
        fn model_name(&self) -> &str {
            "test"
        }
        fn system_prompt(&self) -> &str {
            "test"
        }
        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            message: echo_core::llm::types::Message,
            _cancel: tokio_util::sync::CancellationToken,
            invocation: echo_core::agent::AgentInvocationContext,
        ) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
            Box::pin(async move {
                // 原 delay / setup failure 时点保持不变；不替换为 Unsupported 默认路径。
                tokio::time::sleep(self.delay).await;
                if self.fail {
                    return Err(ReactError::Other(format!("{} failed", self.name)));
                }
                let execution = format!("workflow-test:{}", self.name);
                let status = |kind, sequence| {
                    AgentEvent::ExecutionStatus(echo_core::agent::ExecutionStatus {
                        adapter_generated: false,
                        execution_id: execution.clone(),
                        request_id: Some("test-response".into()),
                        sequence,
                        phase: echo_core::agent::AgentPhase::Terminal,
                        status: kind,
                        reason: None,
                    })
                };
                let events = vec![
                    Ok(status(echo_core::agent::ExecutionStatusKind::Started, 0)),
                    Ok(AgentEvent::FinalAnswer(self.name.to_string())),
                    Ok(status(echo_core::agent::ExecutionStatusKind::Settled, 1)),
                ];
                Ok(Box::pin(async_stream::stream! {
                    let _retained = (message, invocation);
                    for event in events { yield event; }
                }) as BoxStream<'a, Result<AgentEvent>>)
            })
        }
    }

    #[tokio::test]
    async fn failed_concurrent_workflow_aborts_and_drains_siblings() {
        let mut workflow = ConcurrentWorkflow::builder()
            .agent(TestAgent {
                name: "fail",
                fail: true,
                delay: Duration::from_millis(1),
            })
            .agent(TestAgent {
                name: "slow",
                fail: false,
                delay: Duration::from_secs(60),
            })
            .build();

        let result = tokio::time::timeout(Duration::from_secs(1), workflow.run("input"))
            .await
            .unwrap();
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn successful_concurrent_workflow_preserves_registration_order() -> Result<()> {
        let mut workflow = ConcurrentWorkflow::builder()
            .agent(TestAgent {
                name: "registered-first",
                fail: false,
                delay: Duration::from_millis(30),
            })
            .agent(TestAgent {
                name: "completed-first",
                fail: false,
                delay: Duration::from_millis(1),
            })
            .build();

        let output = workflow.run("input").await?;
        assert_eq!(output.result, "registered-first\n---\ncompleted-first");
        assert_eq!(
            output
                .steps
                .iter()
                .map(|step| step.agent_name.as_str())
                .collect::<Vec<_>>(),
            vec!["registered-first", "completed-first"]
        );
        Ok(())
    }
}
