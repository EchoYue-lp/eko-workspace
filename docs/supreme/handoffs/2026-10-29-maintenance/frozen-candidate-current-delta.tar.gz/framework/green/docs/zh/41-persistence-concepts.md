# Store、Journal、Checkpoint 与 Trace

这四个概念并不处于同一抽象层：`Store` 表示某类数据的读写边界；`Journal`、`Checkpoint` 和 `Trace` 表示数据承担的不同语义角色。

## 核心区别

| 概念         | 回答的问题                         | 典型形态                 | 主要用途               |
| ------------ | ---------------------------------- | ------------------------ | ---------------------- |
| `Store`      | 数据存在哪里、如何读写？           | trait、文件或内存后端    | 持久化和查询某类数据   |
| `Journal`    | 按确定顺序发生了什么？             | append-only event stream | 重放、恢复、生成投影   |
| `Checkpoint` | 执行到某个边界时状态是什么？       | Journal identity + state + sequence | 快速恢复、避免全量重放 |
| `Trace`      | 一次执行如何运行、为何成功或失败？ | `Run` + `RunEvent`       | 调试、诊断、评估和统计 |

```text
业务事件
   │
   ├─> Journal ─> reduce/fold ─> 当前状态
   │                               │
   │                               └─> Checkpoint
   │
   └─> Trace

不同 Store 负责持久化上述数据或其它领域数据。
```

## Store：领域存储接口

框架中不存在一个能表示所有持久化数据的总 `Store` trait。名字中包含 `Store`，只能说明它是某个领域的读写边界，不能据此推断数据模型或权威性。

| 接口                 | 所有的数据                       | 作用域         |
| -------------------- | -------------------------------- | -------------- |
| `Store`              | namespace/key/value 长期记忆     | 跨会话知识     |
| `ConversationStore`  | 用户可见的消息历史投影           | 对话浏览       |
| `RuntimeStateStore`  | `AgentCheckpoint`                | ReAct 会话恢复 |
| `CheckpointStore<S>` | Journal generation + reducer state + applied sequence | 事件投影恢复   |
| `RunStore`           | Trace `Run`/`RunEvent`           | 执行观测       |

长期记忆 `Store` 提供 namespace 隔离、KV 读写、搜索和删除。它只是框架中的一种 Store，不是 `ConversationStore`、`RuntimeStateStore` 或 `RunStore` 的父接口。

## Journal：有序事实历史

`EventJournal<E>` 保存有序事件，而不是反复覆盖当前状态。核心约束是：

- 事件只追加；
- sequence 从 1 开始连续递增；
- 每一代事实历史拥有一个稳定的 `JournalIdentity`；
- 可以从指定 sequence 后顺序重放；
- 事件先提交，再由 reducer 折叠为状态；
- append receipt 携带实际提交方的 Journal identity，typed adapter 也必须保留；
- 文件实现可修复撕裂的尾部记录，但历史中段损坏必须报错；
- 不确定的 batch commit 结果必须先 reopen/reconcile，不能盲目重试副作用。

Journal 通常适合承担“已经发生的领域事实”。当前状态、列表或 UI DTO 可以从 Journal 投影，但不应反过来覆盖事实历史。

## Checkpoint：稳定边界的状态快照

### Reducer checkpoint

`CheckpointedReducer` 将 Journal 事件 fold 为状态，并通过 `CheckpointStore<S>` 保存：

- 精确的 Journal generation identity；
- 已应用到的 sequence；
- 该 sequence 对应的 reducer state。

sequence 只在所属 Journal generation 内有意义；序号相同不代表两个 Journal 可以交换 checkpoint。

恢复时先加载 checkpoint，再只重放 Journal 尾部：

```text
Journal:      identity=A, 1 2 3 4 5 6 7 8 9 10
Checkpoint:   journal=A, state@7
恢复:          要求 journal=A，再 load@7 + replay 8..10
```

`FileCheckpointStore` 使用原子替换、schema version，以及覆盖 Journal identity、sequence、state 的 SHA-256 digest，避免把部分写入、被篡改或来自其它 Journal 的合法 JSON 当成可信状态。完整 Journal 仍在时，identity 不匹配会丢弃 checkpoint、从事实全量重放并修复；Journal prefix 已裁剪时则失败关闭，因为缺失事实无法重建。

`apply_committed` 会在 fold 任何 record 前校验外部 append receipt 的 Journal identity。adapter 可以转换 payload 类型，但必须与 batch identity、sequence 一起无损保留物理 Journal identity。

文件 Journal batch、checkpoint 与 segmented retention marker 使用带 identity 的 schema version 2。version 1 无法证明来源绑定，因此直接拒绝，不猜测 identity。详见 [ADR 0055](../adr/0055-checkpoint-journal-identity.md)。

### AgentCheckpoint

`AgentCheckpoint` 保存 ReAct 继续运行所需的消息、激活技能、blocked reason、working directory 和时间戳，由 `RuntimeStateStore` 持久化。它不承载计划副本；版本化任务图与计划 artifact 由 `TaskRevisionService` 持有。当前payload统一显式schema3，合法无cursor的runtime-only/raw用途仍保留；旧裸数组、缺版本与旧迁移恢复义务退出，不能据此删除通用Store或当前CAS/恢复能力。

恢复前会校验 assistant tool call 与 tool result 是否成对，避免恢复出 provider 无法接受的上下文，或重复执行已经完成的副作用。

`AgentCheckpoint` 只拥有 ReAct runtime state，不拥有任务 DAG 或其它应用领域状态。它也不是 `ConversationStore` 中面向用户展示的 transcript。启用 transcript projection 时，其私有 versioned payload 可以保存一条完整的 `PendingTranscriptProjection`；在 ConversationStore receipt 确认提交前，它只是 durable intent，不是 transcript fact。

`AgentInvocationContext` 可以显式拆分这两种身份：`runtime.conversation_id` 继续表示产品事件与
transcript 身份，`runtime_state_id` 只选择 `RuntimeStateStore` checkpoint key。两者不同时，调用方
还应把 runtime incarnation 传给 `transcript_generation_id`。framework 会为规范 transcript 记录
附加 typed generation + ordinal，并在 `AgentCheckpoint` 中保存 ordinal/digest cursor。即使两轮
内容完全相同，多次 safe point、checkpoint 与产品 Store 的 crash cut 也保持幂等；压缩只在完整
pre-compaction transcript 已落盘后重新对齐 cursor。

压缩生成的摘要和改写后的工具内容属于模型上下文，不代表再次发生的 transcript 事件。
内部 checkpoint payload version 3 保留严格递增的事实 ordinal/digest cursor，并用可选
`context_only` 位置/digest 绑定标明派生项；完整 messages 与绑定通过同一次 runtime CAS
保存。存在 pending 时，当前消息视图校验针对 cursor-after，原 cursor-before 的形状和
lineage 约束保留。后续同文新 turn 仍分配新 ordinal，清空活跃视图也不倒退 append frontier。
version 1/2 继续按缺少派生来源证明的 legacy 路径读取，旧 framework reader 会拒绝 version 3。

Managed 压缩在 Store I/O 期间释放 Context 锁，让只读回调读取一致的 pre-view；候选 observer
和 cache 只在 checkpoint CAS 成功后接受。失败或取消恢复的是 volatile view，后续 managed
写入须先完成权威 hydration；timeout 时 CAS 可能已提交，不能声称 durable rollback。
恢复不重放 MemoryPromoter，也不假称撤销其外部效果。详见
[ADR 0056](../adr/0056-durable-transcript-projection-settlement.md)。

canonical root prompt 的身份来自 `CanonicalContext.system_prompt`。
工作目录刷新及根提示词 setter 会保留其它 System 消息（包括恢复出的摘要和 Global Objective）
以及 projection scopes；已存在目标根时直接复用。未配置 canonical context 的独立
ContextManager 继续保留原 first-System 更新语义。

live 根提示词沿用 runtime override 优先于配置 base 的原顺序，并保留原有 CoT、
模型 profile 后缀及项目规则层。更新 base 或注入 skill 不清除 active override；
只有显式 `replace_system_prompt` 清除它，借用型 trait getter 仍返回 base。
刷新与 reset 共用 effective renderer；reset 同时接受最终根消息和 canonical metadata，
并保留原有清空 projection scopes 的语义。

只要设置了 `transcript_generation_id`，它就必须与有效 runtime-state identity 相等。framework
会在 admission 产生 guard、trace、context、模型或 checkpoint 副作用前拒绝不匹配，并在
checkpoint 写入前再次校验，因此不会持久化出恢复端必然拒绝的 identity 漂移状态。
同一个共享 Agent 可以处理多个 value-scoped invocation：effective `runtime_state_id` 变化时，
framework 会在模型准备前精确 reset/restore；只有相同 ID 才复用 warm context。运行时显式记录
当前 hydrated ID：任何可取消的状态修改前先写 `Hydrating(target)`，restore hook 完整结算后才
提交 `Hydrated(target)`；非 exact 状态一律重建。identity 切换还会清空 rollback snapshots。
restore/save 使用相同优先级：显式 invocation runtime ID、invocation 产品 conversation、legacy
external conversation、configured conversation。因此 A -> B -> A 不会把 A 的消息写入 B。

轮换 `runtime_state_id` 会创建干净的模型上下文，但不会删除稳定产品会话。
`save_checkpoint_for_scope` 把每个 runtime ID 持久索引到产品 scope。关闭 admission 并完成旧 owner
结算后，reset 通过 `clear_persisted_runtime_incarnation` 先结清 durable pending projection，再精确
退役旧 runtime checkpoint，并保留 transcript 数据。只有 legacy unmanaged Store pair 会顺带删除
incarnation-keyed transcript；managed 清理在会话重建后无法安全推断稳定 delete identity。managed 产品删除
必须由调用方保留稳定的 `ManagedConversationDelete` request，并调用
`delete_persisted_conversation_managed`；timeout、重启、回执丢失以及会话后来以新 epoch 重建时，都复用
同一个 request identity。`delete_persisted_conversation` 仅保留给 legacy unmanaged Store pair；managed
pair 会失败关闭，因为该便捷入口无法判断一次调用是在重试旧删除，还是要删除后来重建的新 epoch。
managed generation 使用 revision CAS 与 retirement tombstone；产品删除先持久化完整 scope manifest、
全部 dropped operation identity，再取得带 epoch fence 的 ConversationStore receipt。详见
[ADR 0006](../adr/0006-runtime-state-scope-lineage.md) 和
[ADR 0056](../adr/0056-durable-transcript-projection-settlement.md)。

managed clear/delete helper 提供 context-aware 变体，把调用方 absolute deadline 贯穿整个 saga。
legacy unmanaged Store 的原始 trait 没有 context 参数，因此兼容 helper 保留历史上的无界合同；其
context-aware 变体会返回 Unsupported，不会伪装成无法兑现的 deadline 保证。

### Transcript 投影坐标与应用扩展元数据

`StoredMessage.attachments_json` 可同时包含 Framework 的规范消息字段与应用自有
JSON 扩展。`set_transcript_projection_meta` 先校验既有 projection marker、版本及已知
字段，再只替换 `transcript_generation_id` 和 `transcript_ordinal`。未知字段、嵌套值、
显式 `null`、布尔值和中文内容按 JSON 值保留；该操作不负责解释应用呈现 schema，
也不承诺 JSON 空白或对象键顺序逐字节不变。

`normalized_transcript_attachments` 是现有 **Framework canonical 摘要视图**，供
`transcript_projection_message_digest` 与 runtime cursor 使用。它继续忽略应用扩展及
append 坐标，不可作为重写存储行的方法。此次修复不改变该 v1 digest 的序列化、
旧 checkpoint hash 或 cursor 比较语义；应用呈现扩展的变化不代表新的模型执行事实。

Managed import／projection batch 的操作身份及 Store ordinal digest 仍覆盖完整
`StoredMessage`，包括应用扩展。修改扩展后须按原 CAS 生成新的有效请求，不能复用
旧 payload_digest；这与排除应用扩展的 runtime cursor 摘要是两层既有合同。FileStore
原件冷重载与重复请求回执沿用同一权威，无需新增 Store 或迁移版本。

原生 raw／approved assistant blocks、`Some(empty)` 的禁止回退语义、reasoning 签名／
opaque payload 及多模态 Parts 继续通过规范字段持久化。此处只保证数据保存，不使
应用呈现 provenance 成为 Framework 的成功终态或执行许可。

### 当前typed恢复与context-view派生

新执行及显式Resume沿原RuntimeStateStore严格load/reconcile、tool配对、cursor与pending
transcript检查；没有旧控制工具来源getter、宽松inspection、pending-control归一或
专用recovery commit。旧think/final日志与恢复原件不迁移/改写，不从旧参数补成功。

当前File CAS仍使用同scope/runtime锁、expected revision、epoch、replay/conflict与
普通pending transition内核。`derive_context_view_checkpoint`继续为runtime-only新
context view保原cursor lineage，不把未交付内容变成transcript事实。

同一React准备owner在当前Store已准入的Load/保存等待中持有原lease、execution mutex
与资源束；typedunknown或丢失等待者不等于物理结算，不能释放owner或重放真实工具。
原截止时间传播到实际Store，迟到结算后仍按原期限拒新写，不延长期限或另建Store。

旧兼容专用测试义务随人类新裁决retire，不新增skip、不记matched/pass；当前cursor
损坏拒绝、CAS幂等与stale hydrate、context lineage、deadline与资源保有继续由新
正常managed记录测试覆盖。

### 其它同名 checkpoint

框架还有其它作用域不同的 checkpoint：

- compression checkpoint：记录上下文压缩边界；
- Git checkpoint：文件修改前创建 Git tag，用于工作区回滚；
- Trace 的 `Checkpoint`/`CheckpointResumed`：记录 checkpoint 行为已经发生，不是 checkpoint 本体。

因此讨论 checkpoint 时必须说明领域和恢复来源。

## Trace：执行观测

Trace 把一次 Agent invocation 保存为 `Run`。它可包含：

- run、parent run、session、turn 和 execution identity；
- agent、model、provider；
- input、final output、error 和 status；
- LLM 调用、token usage、cache 和耗时；
- tool call/result/error；
- context compression、phase transition、测试、文件修改和 Subagent 调度；
- checkpoint 保存与恢复事件。

Trace 通过 `RunStore` 持久化，供 analyzer、eval、replay 和诊断工具消费。

Trace 与 Journal 都可能包含按时间排列的事件，但职责不同：

| 对比                 | Journal        | Trace                          |
| -------------------- | -------------- | ------------------------------ |
| 目标                 | 保存领域事实   | 解释执行行为                   |
| 是否驱动领域投影     | 通常是         | 否                             |
| 是否适合作为恢复权威 | 按领域设计决定 | 默认不是                       |
| 常见内容             | 状态变更事件   | LLM、工具、usage、timing、错误 |

如果 Trace 写入失败允许主执行继续，Trace 就不能同时承担该执行的业务提交权威。

## 设计规则

新增或修改相关能力时，先回答：

1. 这是新的持久化后端，还是新的数据语义？只有前者主要是 Store 问题。
2. 哪份数据是不可丢失的事实？需要顺序恢复时优先扩展现有 Journal。
3. Checkpoint 是 Journal 派生缓存，还是独立 runtime snapshot？必须写清权威范围、generation identity 和重建来源。
4. Trace 写入失败是否允许主流程继续？如果允许，就不能用 Trace 判断业务是否已提交。
5. 是否已存在同作用域的 Journal、Checkpoint、Store 或 projection？不得平行实现同一语义。

## 代码入口

- 长期记忆 `Store`：`echo-core/src/memory/store.rs`
- `ConversationStore`：`echo-core/src/memory/conversation.rs`
- Journal 与 checkpointed reducer：`echo-state/src/journal/mod.rs`
- 文件 Journal/checkpoint：`echo-state/src/journal/file.rs`
- `AgentCheckpoint` / `RuntimeStateStore`：`src/state/mod.rs`
- Trace `Run` / `RunEvent` / `RunStore`：`src/trace/mod.rs`

延伸阅读：[记忆系统](03-memory.md)、[上下文压缩](04-compression.md)、[追踪系统](27-tracing.md)、[Git 隔离](34-git-isolation.md)。
