//! Subagent executor — unified dispatch engine for Sync / Fork / Teammate modes
//!
//! The executor receives a [`DispatchRequest`] and routes it to the appropriate
//! execution strategy based on the definition's [`ExecutionMode`].

use crate::error::{AgentError, ReactError, Result};
use echo_core::agent::{
    Agent, AgentEvent, AgentInvocationContext, CancellationToken, EventIdentity,
    ExecutionAdmission, KeyedExecutionLease,
};
use echo_core::error::AgentTerminalKind;
use echo_core::llm::types::Message;
use futures::StreamExt;
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tracing::{info, warn};

use super::context::SubagentContext;
use super::control::{
    SubagentAttemptBinding, SubagentAttemptIdentity, SubagentControlError, SubagentControlRegistry,
    SubagentGuidanceQueueReceipt, SubagentInterruptOutcome, SubagentInterruptRequestDisposition,
    SubagentMessageReceipt,
};
use super::events::{SubagentEvent, SubagentEventPublisher, SubagentInvocationIdentity};
use super::hooks::{SubagentHookContext, SubagentHookRegistry};
use super::prompt::{
    CompiledSubagentInvocation, ContextTransferPolicy, SubagentInvocation, SubagentPromptCompiler,
    SubagentTaskContext, ToolCapabilitySnapshot,
};
use super::registry::{SubagentRegistration, SubagentRegistry};
use super::types::{
    ExecutionMode, ObservedIsolation, SubagentArtifact, SubagentEvidence, SubagentEvidenceSource,
    SubagentOutcome, SubagentResult, SubagentStatus,
};
use crate::tasks::{
    NestedDelegationPolicy, RuntimeAttemptControlCleanupReceipt,
    RuntimeTaskAttemptInterruptDisposition, RuntimeTaskAttemptInterruptProjectionError, Task,
    TaskClaim, TaskSubagentContext,
};

// ── Dispatch Request ──────────────────────────────────────────────────────────

/// A request to dispatch a task to a subagent.
#[derive(Clone)]
pub struct DispatchRequest {
    /// Target subagent name.
    pub agent_name: String,
    /// Task description.
    pub task: String,
    /// Override the definition's default execution mode.
    pub mode_override: Option<ExecutionMode>,
    /// Cancellation token (propagated from parent).
    pub cancel: CancellationToken,
    /// Parent agent name (for logging and topology).
    pub parent_agent: String,
    /// Parent context for inheritance (Fork mode).
    pub parent_context: Option<SubagentContext>,
    /// Nested delegation policy (prevents unbounded delegation chains).
    pub delegation_policy: NestedDelegationPolicy,
    /// 应用层 run 级上下文（跨 spawn 安全，值传递）。
    ///
    /// dispatch_fork 将它放入本次 `AgentInvocationContext`，使 subagent 内的工具
    /// 能经 ToolContext 读到 run_id/cancel/trace_sink——不修改共享 agent。
    pub runtime_context: Option<echo_core::tools::ExternalRunContext>,
    /// Optional multimodal message (images/files). When `Some`, the subagent is
    /// dispatched via `execute_stream_message_with_invocation_context` instead of the text
    /// `task` path, so it sees user-uploaded attachments. `None` = plain text
    /// dispatch (the default for all existing callers).
    pub message: Option<Message>,
    /// Opaque structured payload consumed only by an injected product compiler.
    pub prompt_payload: Option<serde_json::Value>,
    /// Typed task facts consumed by every prompt compiler.
    pub prompt_context: Option<SubagentTaskContext>,
    /// Explicit task constraints / boundaries from the dispatch caller (e.g.
    /// the `agent_tool` `constraints` parameter). Rendered by the invocation
    /// compiler independently of `parent_context`, so fresh-context dispatches
    /// can still carry boundaries.
    pub constraints: Vec<String>,
    /// When true, this dispatch was (or will be) started via
    /// [`SubagentExecutor::dispatch_background`]. Propagated onto
    /// [`SubagentEvent::DispatchStarted`] so UI can mark background cards.
    pub background: bool,
}

impl std::fmt::Debug for DispatchRequest {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DispatchRequest")
            .field("agent_name", &self.agent_name)
            .field("task", &self.task)
            .field("mode_override", &self.mode_override)
            .field("parent_agent", &self.parent_agent)
            .field("delegation_policy", &self.delegation_policy)
            .field(
                "runtime_context",
                &self.runtime_context.as_ref().map(|c| &c.run_id),
            )
            .field("has_prompt_payload", &self.prompt_payload.is_some())
            .field("has_prompt_context", &self.prompt_context.is_some())
            .finish()
    }
}

impl DispatchRequest {
    /// Build a request delegation policy from the legacy depth parameter used
    /// by older public helper methods.
    pub fn policy_from_depth(depth: u32) -> NestedDelegationPolicy {
        NestedDelegationPolicy {
            can_spawn_subagents: true,
            delegate_depth: depth.min(u8::MAX as u32) as u8,
            max_delegate_depth: 3,
        }
    }
}

fn apply_subagent_invocation_scope(
    invocation: &mut AgentInvocationContext,
    agent: &dyn Agent,
    allowed_tools: Option<&[String]>,
    tool_access: Option<echo_core::tools::ToolAccess>,
    target_policy: NestedDelegationPolicy,
) {
    // The request already names this exact actor. Advancing child_policy here
    // would count the same dispatch edge again; copying parent runtime policy
    // would let a child masquerade as its parent on the next dispatch.
    invocation
        .runtime
        .get_or_insert_with(echo_core::tools::ExternalRunContext::default)
        .delegation_policy = Some(target_policy);
    // Keep the positive bound until the original Agent takes its snapshot
    // after acquiring the execution lock. A deny complement of today's names
    // cannot exclude tools registered while this invocation waits in the queue.
    invocation.tool_access = match (invocation.tool_access, tool_access) {
        (Some(echo_core::tools::ToolAccess::ReadOnly), _)
        | (_, Some(echo_core::tools::ToolAccess::ReadOnly)) => {
            Some(echo_core::tools::ToolAccess::ReadOnly)
        }
        (current, inherited) => inherited.or(current),
    };
    invocation.allowed_tools = allowed_tools
        .filter(|tools| !tools.is_empty())
        .map(|tools| tools.iter().cloned().collect());
    invocation.visible_tools = invocation.allowed_tools.as_ref().map(|allowed| {
        agent
            .tool_names()
            .into_iter()
            .filter(|name| allowed.contains(name))
            .collect()
    });
}

fn effective_capabilities(
    agent: &dyn Agent,
    allowed_tools: Option<&[String]>,
) -> ToolCapabilitySnapshot {
    let definitions = agent.tool_definitions();
    let mut disabled = agent.disabled_tool_names();
    if let Some(allowed) = allowed_tools.filter(|tools| !tools.is_empty()) {
        let allowed = allowed.iter().map(String::as_str).collect::<HashSet<_>>();
        disabled.extend(
            definitions
                .iter()
                .map(|definition| definition.function.name.clone())
                .filter(|name| !allowed.contains(name.as_str())),
        );
    }
    ToolCapabilitySnapshot::from_definitions(&definitions, &disabled)
}

/// Map framework errors to the runtime-owned subagent terminal status.
pub fn subagent_status_from_error(error: &ReactError) -> Result<SubagentStatus> {
    echo_core::error::AgentFailure::try_from(error)?;
    Ok(match error {
        ReactError::Agent(agent_error) => match agent_error.as_ref() {
            AgentError::Timeout(_) => SubagentStatus::TimedOut,
            AgentError::Interrupted | AgentError::Cancelled(_) => SubagentStatus::Cancelled,
            _ => SubagentStatus::Failed,
        },
        _ => SubagentStatus::Failed,
    })
}

#[cfg(test)]
mod typed_error_mapping_tests {
    use super::*;

    #[test]
    fn terminal_status_ignores_misleading_error_text() -> Result<()> {
        let error = ReactError::Other("cancelled timeout are ordinary words here".to_string());
        assert_eq!(subagent_status_from_error(&error)?, SubagentStatus::Failed);
        Ok(())
    }

    #[test]
    fn attempt_control_projection_preserves_capacity_and_identity_conflict() {
        assert_eq!(
            runtime_interrupt_projection_error(SubagentControlError::PendingCapacityExceeded {
                limit: 17
            }),
            RuntimeTaskAttemptInterruptProjectionError::PendingCapacityExceeded { limit: 17 }
        );
        assert_eq!(
            runtime_interrupt_projection_error(SubagentControlError::IdentityConflict {
                task_id: "task".to_string(),
                attempt: 2,
                expected_execution_id: "expected".to_string(),
                actual_execution_id: "actual".to_string(),
            }),
            RuntimeTaskAttemptInterruptProjectionError::IdentityConflict {
                task_id: "task".to_string(),
                attempt: 2,
                expected_execution_id: "expected".to_string(),
                actual_execution_id: "actual".to_string(),
            }
        );
    }

    #[test]
    fn exact_dispatch_context_preserves_resources_and_rejects_identity_conflicts()
    -> std::result::Result<(), String> {
        let trace_sink: echo_core::tools::TraceSinkFn = Arc::new(|_| {});
        let uplink: echo_core::tools::SubagentUplinkFn = Arc::new(|_| {
            Box::pin(async {
                echo_core::tools::SubagentUplinkReceipt {
                    accepted: true,
                    status: "test".to_string(),
                    detail: String::new(),
                }
            })
        });
        let initial_cancel = CancellationToken::new();
        let exact_cancel = CancellationToken::new();
        let exact = ExactTaskDispatchContext {
            run_id: "run".to_string(),
            execution_id: "execution".to_string(),
            task_id: "task".to_string(),
            attempt: 3,
            plan_revision: 9,
            cancel: exact_cancel.clone(),
            delegation_policy: NestedDelegationPolicy {
                can_spawn_subagents: true,
                delegate_depth: 1,
                max_delegate_depth: 4,
            },
        };
        let mut request = DispatchRequest {
            agent_name: "reviewer".to_string(),
            task: "review".to_string(),
            mode_override: None,
            cancel: initial_cancel,
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: NestedDelegationPolicy::default(),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("conversation".to_string()),
                turn_id: Some("turn".to_string()),
                isolation_id: Some("isolation".to_string()),
                message_id: Some("message".to_string()),
                trace_sink: Some(trace_sink.clone()),
                resource_guards: vec![echo_core::tools::InvocationResourceGuard::new_identified(
                    "guard".to_string(),
                    7_u64,
                )],
                subagent_lineage: Some(echo_core::tools::SubagentLineage {
                    agent_name: Some("reviewer".to_string()),
                    parent_agent: Some("parent".to_string()),
                    ..Default::default()
                }),
                uplink: Some(uplink.clone()),
                ..Default::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        bind_exact_dispatch_context(&mut request, &exact).map_err(|error| error.to_string())?;
        let runtime = request
            .runtime_context
            .as_ref()
            .ok_or_else(|| "runtime context missing".to_string())?;
        assert_eq!(runtime.conversation_id.as_deref(), Some("conversation"));
        assert_eq!(runtime.turn_id.as_deref(), Some("turn"));
        assert_eq!(runtime.isolation_id.as_deref(), Some("isolation"));
        assert_eq!(runtime.message_id.as_deref(), Some("message"));
        assert_eq!(runtime.resource_guards.len(), 1);
        assert!(
            runtime
                .trace_sink
                .as_ref()
                .is_some_and(|value| { Arc::ptr_eq(value, &trace_sink) })
        );
        assert!(
            runtime
                .uplink
                .as_ref()
                .is_some_and(|value| { Arc::ptr_eq(value, &uplink) })
        );
        let lineage = runtime
            .subagent_lineage
            .as_ref()
            .ok_or_else(|| "subagent lineage missing".to_string())?;
        assert_eq!(lineage.agent_name.as_deref(), Some("reviewer"));
        assert_eq!(lineage.run_id.as_deref(), Some("run"));
        assert_eq!(lineage.task_id.as_deref(), Some("task"));
        assert_eq!(lineage.execution_id.as_deref(), Some("execution"));
        assert_eq!(lineage.attempt, Some(3));
        assert_eq!(lineage.plan_revision, Some(9));
        exact_cancel.cancel();
        assert!(request.cancel.is_cancelled());
        assert!(
            runtime
                .cancel
                .as_ref()
                .is_some_and(|cancel| cancel.is_cancelled())
        );
        assert_eq!(request.delegation_policy, exact.delegation_policy);

        let mut conflicting = request.clone();
        if let Some(runtime) = conflicting.runtime_context.as_mut() {
            runtime.run_id = Some("other-run".to_string());
        }
        assert!(
            bind_exact_dispatch_context(&mut conflicting, &exact)
                .is_err_and(|error| error.to_string().contains("run_id mismatch"))
        );
        Ok(())
    }
}

fn hook_stop_status(status: SubagentStatus) -> echo_core::hooks::SubagentStopStatus {
    match status {
        SubagentStatus::Running => echo_core::hooks::SubagentStopStatus::Failed,
        SubagentStatus::Completed => echo_core::hooks::SubagentStopStatus::Completed,
        SubagentStatus::Failed => echo_core::hooks::SubagentStopStatus::Failed,
        SubagentStatus::Cancelled => echo_core::hooks::SubagentStopStatus::Cancelled,
        SubagentStatus::TimedOut => echo_core::hooks::SubagentStopStatus::TimedOut,
    }
}

fn correlate_subagent_hook(
    ctx: crate::skills::hooks::HookContext,
    run_id: Option<&str>,
    execution_id: Option<&str>,
    attempt: u32,
) -> crate::skills::hooks::HookContext {
    ctx.with_run_correlation(run_id, None, execution_id, Some(attempt))
}

fn bounded_detail(text: &str) -> String {
    text.chars().take(500).collect()
}

/// Merge runtime-observed evidence into a parsed result.
///
/// Observed facts replace older evidence with the same kind, subject, and
/// attributes, while distinct invocations and artifacts are preserved.
pub fn merge_observed_evidence(
    outcome: &mut SubagentOutcome,
    evidence: Vec<SubagentEvidence>,
    artifacts: Vec<SubagentArtifact>,
) {
    for observed in evidence {
        outcome.evidence.retain(|existing| {
            existing.kind != observed.kind
                || existing.subject != observed.subject
                || existing.attributes != observed.attributes
        });
        outcome.evidence.push(observed);
    }
    for artifact in artifacts {
        outcome
            .artifacts
            .retain(|existing| existing.path != artifact.path);
        outcome.artifacts.push(artifact);
    }
    super::types::normalize_outcome(outcome);
    outcome.refresh_derived_views();
}

// ── Teammate Handle ───────────────────────────────────────────────────────────

/// Handle to a running teammate agent.
///
/// Used to poll for results or cancel execution.
#[derive(Debug)]
pub struct TeammateHandle {
    /// Unique handle ID.
    pub id: String,
    /// The teammate agent name.
    pub agent_name: String,
    /// Cancellation token for this teammate.
    pub cancel: CancellationToken,
    /// Join handle for the spawned task.
    join_handle: tokio::task::JoinHandle<Result<SubagentResult>>,
    observation_run_id: String,
    observation_execution_id: Option<String>,
}

/// Handle returned immediately by [`SubagentExecutor::dispatch_background`].
///
/// The subagent continues on a spawned task; lifecycle events
/// (`DispatchStarted` / `DispatchCompleted` / `DispatchFailed`) still fire on
/// the registry event bus. The handle also owns cancellation and the eventual
/// result so direct API callers do not have to depend on a lossy event stream.
#[derive(Debug, Clone)]
pub struct BackgroundSubagentHandle {
    /// Stable execution id (also on `DispatchStarted.execution_id`).
    pub execution_id: String,
    /// Target subagent name.
    pub agent_name: String,
    cancel: CancellationToken,
    join_handle: Arc<Mutex<Option<tokio::task::JoinHandle<Result<SubagentResult>>>>>,
    observation_run_id: String,
}

/// Scope-bound live control for TaskClaim-derived Subagent attempts.
///
/// Durable claim validation and Task terminal settlement remain owned by
/// [`crate::tasks::RuntimeTaskService`]. This handle only projects a controller's
/// already-validated claim into the same process-local registry used by dispatch.
pub struct SubagentAttemptControlHandle {
    executor: SubagentExecutor,
    control_scope_id: String,
}

impl Clone for SubagentAttemptControlHandle {
    fn clone(&self) -> Self {
        Self {
            executor: self.executor.clone_for_spawn(),
            control_scope_id: self.control_scope_id.clone(),
        }
    }
}

impl std::fmt::Debug for SubagentAttemptControlHandle {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("SubagentAttemptControlHandle")
            .field("control_scope_id", &self.control_scope_id)
            .finish_non_exhaustive()
    }
}

impl BackgroundSubagentHandle {
    /// Request cancellation of the background dispatch.
    pub fn cancel(&self) {
        self.cancel.cancel();
    }

    /// Check whether the spawned dispatch has reached a terminal state.
    pub fn is_finished(&self) -> bool {
        self.join_handle
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .as_ref()
            .is_none_or(tokio::task::JoinHandle::is_finished)
    }

    /// Await and consume the background result.
    ///
    /// Cloned handles share one result slot; only the first `join` call
    /// consumes it. Later calls return an explicit error.
    pub async fn join(&self) -> Result<SubagentResult> {
        let handle = self
            .join_handle
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .take()
            .ok_or_else(|| ReactError::Other("Background result already consumed".to_string()))?;
        handle
            .await
            .map_err(|error| {
                tracing::error!(error=%error, panic=error.is_panic(), cancelled=error.is_cancelled(), "background join lost physical closure knowledge");
                ReactError::ExecutionNotSettled { run_id: self.observation_run_id.clone(), execution_id: Some(self.execution_id.clone()) }
            })?
    }
}

impl TeammateHandle {
    /// Check if the teammate has completed.
    pub fn is_finished(&self) -> bool {
        self.join_handle.is_finished()
    }

    /// Await the teammate's result.
    pub async fn join(mut self) -> Result<SubagentResult> {
        (&mut self.join_handle)
            .await
            .map_err(|error| {
                tracing::error!(error=%error, panic=error.is_panic(), cancelled=error.is_cancelled(), "teammate join lost physical closure knowledge");
                ReactError::ExecutionNotSettled { run_id: self.observation_run_id.clone(), execution_id: self.observation_execution_id.clone() }
            })?
    }
}

impl Drop for TeammateHandle {
    fn drop(&mut self) {
        self.cancel.cancel();
    }
}

// ── Executor Config ───────────────────────────────────────────────────────────

/// Configuration for the subagent executor.
pub struct SubagentExecutorConfig {
    /// Maximum concurrent Fork dispatches.
    pub max_concurrent_forks: usize,
    /// Default timeout (seconds) for ALL dispatch modes (Sync/Fork/Teammate).
    /// 0 = no timeout. Sourced from `AgentConfig.subagent_timeout_secs` (default
    /// 600 = 10 min). Per-subagent `SubagentDefinition.timeout_secs` (>0) overrides.
    pub default_timeout_secs: u64,
    /// Enable hooks.
    pub enable_hooks: bool,
    /// Optional bridge to the unified lifecycle hook system (echo-core).
    /// When set, SubagentStart/SubagentStop events are fired into the
    /// unified HookRegistry alongside the trait-based SubagentHooks.
    pub unified_hook_executor: Option<crate::skills::hooks::UnifiedHookExecutorFn>,
    /// Optional application-owned provider for product-defined isolation kinds.
    pub isolation_provider: Option<super::isolation::SharedIsolationProvider>,
    /// Compiler shared by direct `agent_tool` and programmatic delegation.
    pub prompt_compiler: Arc<dyn SubagentPromptCompiler>,
    /// Optional shared process admission. When absent, Fork uses its local
    /// `max_concurrent_forks` semaphore for standalone compatibility.
    pub shared_admission: Option<Arc<ExecutionAdmission>>,
}

impl Default for SubagentExecutorConfig {
    fn default() -> Self {
        Self {
            max_concurrent_forks: 5,
            default_timeout_secs: 600,
            enable_hooks: true,
            unified_hook_executor: None,
            isolation_provider: None,
            prompt_compiler: Arc::new(super::prompt::DefaultSubagentPromptCompiler),
            shared_admission: None,
        }
    }
}

struct SubagentPhysicalResources {
    lease: Option<KeyedExecutionLease>,
    isolation: Option<super::isolation::IsolationHandle>,
    resource_guards: Vec<echo_core::tools::InvocationResourceGuard>,
    uncertain: bool,
}
impl Drop for SubagentPhysicalResources {
    fn drop(&mut self) {
        if self.uncertain
            && let Some(lease) = self.lease.take()
        {
            // Same original admission key owns both capacity and the isolation
            // finalizer until authoritative closure. Never finalize on unknown.
            lease.retain_unknown_with_resources(Some(Box::new((
                self.isolation.take(),
                std::mem::take(&mut self.resource_guards),
            ))));
        }
    }
}

// ── Subagent Executor ─────────────────────────────────────────────────────────

/// Unified dispatch engine for all subagent execution modes.
pub struct SubagentExecutor {
    registry: Arc<SubagentRegistry>,
    hooks: Arc<SubagentHookRegistry>,
    config: SubagentExecutorConfig,
    local_fork_admission: Arc<ExecutionAdmission>,
    control_registry: Arc<SubagentControlRegistry>,
    shared_admission: Arc<tokio::sync::RwLock<Option<Arc<ExecutionAdmission>>>>,
    team_runtimes: Arc<Mutex<TeamRuntimeIndex>>,
}

// Only the original dispatcher creates the admitted form. Tool callers may
// select a record early for routing, but cannot bypass its host validation.
struct DispatchRegistration {
    registration: SubagentRegistration,
    admitted: bool,
}

const TEAM_RUNTIME_RETENTION: usize = 64;

#[derive(Default)]
struct TeamRuntimeIndex {
    handles: HashMap<String, Arc<super::team::TeamRuntimeHandle>>,
    order: VecDeque<String>,
}

fn prune_team_runtime_index(index: &Arc<Mutex<TeamRuntimeIndex>>) {
    let mut runtimes = index
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut excess = runtimes
        .handles
        .values()
        .filter(|handle| !handle.is_active())
        .count()
        .saturating_sub(TEAM_RUNTIME_RETENTION);
    let scan_count = runtimes.order.len();
    for _ in 0..scan_count {
        let Some(handle_id) = runtimes.order.pop_front() else {
            break;
        };
        let remove = excess > 0
            && runtimes
                .handles
                .get(&handle_id)
                .is_some_and(|handle| !handle.is_active());
        if remove {
            runtimes.handles.remove(&handle_id);
            excess = excess.saturating_sub(1);
        } else if runtimes.handles.contains_key(&handle_id) {
            runtimes.order.push_back(handle_id);
        }
    }
}

struct TeamRuntimeRetentionGuard {
    index: Arc<Mutex<TeamRuntimeIndex>>,
}

impl Drop for TeamRuntimeRetentionGuard {
    fn drop(&mut self) {
        prune_team_runtime_index(&self.index);
    }
}

/// Framework-default uplink sink.
///
/// Behavior per target:
/// - `Parent`: when the sender's lineage carries `parent_execution_id` and
///   that attempt is live in the shared control registry, the message steers
///   the parent's active turn (queue-only; the parent drains it at its next
///   model boundary). Otherwise the message is still accepted and surfaced as
///   [`SubagentEvent::UplinkReceived`] for host-side listeners.
/// - `Sibling`: delivered queue-only via the shared control registry; a
///   non-active sibling reports `sibling_not_active` so the model can retry
///   or escalate instead of assuming delivery.
pub fn default_uplink_sink(registry: Arc<SubagentRegistry>) -> echo_core::tools::SubagentUplinkFn {
    use echo_core::tools::{SubagentUplinkMessage, SubagentUplinkReceipt, SubagentUplinkTarget};
    Arc::new(move |message: SubagentUplinkMessage| {
        let registry = Arc::clone(&registry);
        Box::pin(async move {
            let from = &message.from;
            let agent = from
                .agent_name
                .clone()
                .unwrap_or_else(|| "<unknown>".to_string());
            let parent = from
                .parent_agent
                .clone()
                .unwrap_or_else(|| "<unknown>".to_string());
            let (direction, intent_prefix, mut receipt) = match &message.target {
                SubagentUplinkTarget::Parent { kind, text } => {
                    let intent = if *kind == echo_core::tools::SubagentUplinkKind::Escalate {
                        "[escalate] "
                    } else {
                        ""
                    };
                    let delivery = match from.parent_execution_id.as_deref() {
                        Some(execution_id) => {
                            registry
                                .control_registry()
                                .send_message_to_active(execution_id, text.clone())
                                .await
                        }
                        None => Err(SubagentControlError::UnknownExecution {
                            execution_id: String::new(),
                        }),
                    };
                    let receipt = match delivery {
                        Ok(receipt) => SubagentUplinkReceipt {
                            accepted: true,
                            status: "parent_steered".to_string(),
                            detail: format!("queued into parent attempt {}", receipt.attempt),
                        },
                        Err(error) => SubagentUplinkReceipt {
                            accepted: true,
                            status: "event_emitted".to_string(),
                            detail: format!(
                                "parent not steerable ({error}); surfaced for host listeners"
                            ),
                        },
                    };
                    ("parent", intent, receipt)
                }
                SubagentUplinkTarget::Sibling { to, text } => {
                    let receipt = match to {
                        echo_core::tools::SubagentPeerAddress::ByExecutionId(execution_id) => {
                            match registry
                                .control_registry()
                                .send_message_to_active(execution_id, text.clone())
                                .await
                            {
                                Ok(receipt) => SubagentUplinkReceipt {
                                    accepted: true,
                                    status: "delivered_to_sibling".to_string(),
                                    detail: format!(
                                        "queued into sibling attempt {}",
                                        receipt.attempt
                                    ),
                                },
                                Err(error) => SubagentUplinkReceipt {
                                    accepted: false,
                                    status: "sibling_not_active".to_string(),
                                    detail: error.to_string(),
                                },
                            }
                        }
                        echo_core::tools::SubagentPeerAddress::ByTaskId(task_id) => {
                            SubagentUplinkReceipt {
                                accepted: false,
                                status: "task_addressing_requires_application_sink".to_string(),
                                detail: format!(
                                    "task '{task_id}' has no live attempt; an application                                      sink owning attempt scheduling must deliver it"
                                ),
                            }
                        }
                    };
                    ("sibling", "", receipt)
                }
            };
            let summary: String = {
                let text = match &message.target {
                    SubagentUplinkTarget::Parent { text, .. }
                    | SubagentUplinkTarget::Sibling { text, .. } => text,
                };
                format!(
                    "{intent_prefix}{}",
                    text.chars().take(200).collect::<String>()
                )
            };
            let uplink_event = SubagentEvent::UplinkReceived {
                parent,
                agent,
                direction: direction.to_string(),
                status: receipt.status.clone(),
                summary,
                execution_id: from.execution_id.clone(),
                run_id: from.run_id.clone(),
            };
            let published = from
                .execution_id
                .as_deref()
                .and_then(|execution_id| registry.event_bus().publisher_for_execution(execution_id))
                .is_some_and(|publisher| match publisher.emit(uplink_event) {
                    Ok(_) => true,
                    Err(error) => {
                        warn!(%error, "failed to publish Subagent uplink envelope");
                        false
                    }
                });
            if !published {
                warn!(
                    execution_id = from.execution_id.as_deref().unwrap_or("<none>"),
                    "Subagent uplink has no active event publisher"
                );
                if receipt.status == "event_emitted" {
                    receipt.accepted = false;
                    receipt.status = "event_unavailable".to_string();
                    receipt.detail =
                        "parent not steerable and no active event publisher exists".to_string();
                }
            }
            receipt
        })
    })
}

impl SubagentAttemptControlHandle {
    pub fn control_scope_id(&self) -> &str {
        &self.control_scope_id
    }

    fn identity_from_context(
        &self,
        context: &TaskSubagentContext,
    ) -> std::result::Result<SubagentAttemptIdentity, SubagentControlError> {
        let claim = context
            .claim()
            .ok_or(SubagentControlError::InvalidIdentity { field: "claim" })?;
        let task_id = context
            .task_id()
            .ok_or(SubagentControlError::InvalidIdentity { field: "task_id" })?;
        SubagentAttemptIdentity::for_runtime_scope(
            self.control_scope_id.clone(),
            context.run_id().to_string(),
            task_id.to_string(),
            claim.execution_id(context.run_id(), task_id),
            claim.attempt,
        )
    }

    fn identity_from_claim(
        &self,
        run_id: &str,
        task_id: &str,
        claim: &TaskClaim,
    ) -> std::result::Result<SubagentAttemptIdentity, SubagentControlError> {
        SubagentAttemptIdentity::for_runtime_scope(
            self.control_scope_id.clone(),
            run_id.to_string(),
            task_id.to_string(),
            claim.execution_id(run_id, task_id),
            claim.attempt,
        )
    }

    /// Reserve one exact TaskClaim attempt before it waits for admission.
    pub fn reserve(
        &self,
        context: &TaskSubagentContext,
    ) -> std::result::Result<(), SubagentControlError> {
        let identity = self.identity_from_context(context)?;
        self.executor
            .reserve_attempt(identity, context.cancellation_token().clone())
    }

    /// Dispatch one exact TaskClaim attempt through this handle's registry.
    pub async fn dispatch(
        &self,
        mut request: DispatchRequest,
        context: TaskSubagentContext,
    ) -> Result<SubagentResult> {
        let identity = self
            .identity_from_context(&context)
            .map_err(SubagentExecutor::control_react_error)?;
        bind_task_dispatch_context(&mut request, &context)?;
        self.executor.dispatch_attempt(request, identity).await
    }

    async fn dispatch_registered(
        &self,
        mut request: DispatchRequest,
        context: TaskSubagentContext,
        registration: SubagentRegistration,
    ) -> Result<SubagentResult> {
        let identity = self
            .identity_from_context(&context)
            .map_err(SubagentExecutor::control_react_error)?;
        bind_task_dispatch_context(&mut request, &context)?;
        let (request, admission) = self.executor.admit_attempt(request, identity)?;
        self.executor
            .dispatch_owned(
                request,
                Some(admission),
                Some(DispatchRegistration {
                    registration,
                    admitted: false,
                }),
            )
            .await
    }

    /// Project an interrupt that has already passed durable TaskClaim checks.
    ///
    /// Durable callers must invoke this only from
    /// [`crate::tasks::RuntimeDagController::request_live_interrupt`].
    pub fn project_interrupt(
        &self,
        run_id: &str,
        task_id: &str,
        claim: &TaskClaim,
    ) -> std::result::Result<
        RuntimeTaskAttemptInterruptDisposition,
        RuntimeTaskAttemptInterruptProjectionError,
    > {
        let identity = self
            .identity_from_claim(run_id, task_id, claim)
            .map_err(runtime_interrupt_projection_error)?;
        self.executor
            .request_interrupt(identity)
            .map(|receipt| runtime_interrupt_disposition(receipt.disposition))
            .map_err(runtime_interrupt_projection_error)
    }

    /// Retire one live projection after its durable claim has advanced.
    pub fn retire(
        &self,
        run_id: &str,
        task: &Task,
        claim: &TaskClaim,
    ) -> RuntimeAttemptControlCleanupReceipt {
        let identity = match self.identity_from_claim(run_id, &task.spec.id, claim) {
            Ok(identity) => identity,
            Err(error) => {
                return RuntimeAttemptControlCleanupReceipt::RetryableFailure {
                    error: error.to_string(),
                };
            }
        };
        match self.executor.retire_attempt_control(&identity) {
            Ok(true) => RuntimeAttemptControlCleanupReceipt::Retired,
            Ok(false) => RuntimeAttemptControlCleanupReceipt::AlreadyConsumed,
            Err(error) => RuntimeAttemptControlCleanupReceipt::RetryableFailure {
                error: error.to_string(),
            },
        }
    }

    /// Reconcile only this handle's fixed control scope.
    pub fn reconcile(
        &self,
        run_id: &str,
        current_execution_ids: &HashSet<String>,
    ) -> std::result::Result<(), SubagentControlError> {
        self.executor.reconcile_attempt_control(
            &self.control_scope_id,
            run_id,
            current_execution_ids,
        )
    }
}

fn bind_task_dispatch_context(
    request: &mut DispatchRequest,
    context: &TaskSubagentContext,
) -> Result<()> {
    let exact = ExactTaskDispatchContext::from_task_context(context)?;
    bind_exact_dispatch_context(request, &exact)
}

struct ExactTaskDispatchContext {
    run_id: String,
    execution_id: String,
    task_id: String,
    attempt: u32,
    plan_revision: u64,
    cancel: CancellationToken,
    delegation_policy: NestedDelegationPolicy,
}

impl ExactTaskDispatchContext {
    fn from_task_context(context: &TaskSubagentContext) -> Result<Self> {
        let execution_id = context.execution_id().ok_or_else(|| {
            ReactError::Other("exact task dispatch requires an execution identity".to_string())
        })?;
        let task_id = context.task_id().ok_or_else(|| {
            ReactError::Other("exact task dispatch requires a task identity".to_string())
        })?;
        let claim = context.claim().ok_or_else(|| {
            ReactError::Other("exact task dispatch requires a TaskClaim".to_string())
        })?;
        Ok(Self {
            run_id: context.run_id().to_string(),
            execution_id,
            task_id: task_id.to_string(),
            attempt: claim.attempt,
            plan_revision: claim.revision,
            cancel: context.cancellation_token().clone(),
            delegation_policy: context.delegation_policy(),
        })
    }
}

fn bind_exact_dispatch_context(
    request: &mut DispatchRequest,
    exact: &ExactTaskDispatchContext,
) -> Result<()> {
    let runtime = request
        .runtime_context
        .get_or_insert_with(echo_core::tools::ExternalRunContext::default);
    ensure_string_identity("run_id", runtime.run_id.as_deref(), &exact.run_id)?;
    ensure_string_identity(
        "execution_id",
        runtime.execution_id.as_deref(),
        &exact.execution_id,
    )?;
    runtime.run_id = Some(exact.run_id.clone());
    runtime.execution_id = Some(exact.execution_id.clone());
    if runtime.turn_id.is_none() {
        runtime.turn_id = Some(exact.execution_id.clone());
    }
    runtime.cancel = Some(Arc::new(exact.cancel.clone()));
    runtime.delegation_policy = Some(exact.delegation_policy);
    let lineage = runtime
        .subagent_lineage
        .get_or_insert_with(Default::default);
    ensure_string_identity("lineage.run_id", lineage.run_id.as_deref(), &exact.run_id)?;
    ensure_string_identity(
        "lineage.task_id",
        lineage.task_id.as_deref(),
        &exact.task_id,
    )?;
    ensure_string_identity(
        "lineage.execution_id",
        lineage.execution_id.as_deref(),
        &exact.execution_id,
    )?;
    ensure_numeric_identity("lineage.attempt", lineage.attempt, exact.attempt)?;
    ensure_numeric_identity(
        "lineage.plan_revision",
        lineage.plan_revision,
        exact.plan_revision,
    )?;
    lineage.run_id = Some(exact.run_id.clone());
    lineage.task_id = Some(exact.task_id.clone());
    lineage.execution_id = Some(exact.execution_id.clone());
    lineage.attempt = Some(exact.attempt);
    lineage.plan_revision = Some(exact.plan_revision);
    request.cancel = exact.cancel.clone();
    request.delegation_policy = exact.delegation_policy;
    Ok(())
}

fn ensure_string_identity(field: &str, actual: Option<&str>, expected: &str) -> Result<()> {
    if let Some(actual) = actual
        && actual != expected
    {
        return Err(ReactError::Other(format!(
            "Subagent {field} mismatch: expected {expected}, actual {actual}"
        )));
    }
    Ok(())
}

fn ensure_numeric_identity<T>(field: &str, actual: Option<T>, expected: T) -> Result<()>
where
    T: Copy + PartialEq + std::fmt::Display,
{
    if let Some(actual) = actual
        && actual != expected
    {
        return Err(ReactError::Other(format!(
            "Subagent {field} mismatch: expected {expected}, actual {actual}"
        )));
    }
    Ok(())
}

fn runtime_interrupt_disposition(
    disposition: SubagentInterruptRequestDisposition,
) -> RuntimeTaskAttemptInterruptDisposition {
    match disposition {
        SubagentInterruptRequestDisposition::QueuedBeforeAdmission => {
            RuntimeTaskAttemptInterruptDisposition::QueuedBeforeReservation
        }
        SubagentInterruptRequestDisposition::ReservedRequested => {
            RuntimeTaskAttemptInterruptDisposition::ReservedRequested
        }
        SubagentInterruptRequestDisposition::ActiveRequested => {
            RuntimeTaskAttemptInterruptDisposition::ActiveRequested
        }
        SubagentInterruptRequestDisposition::ActiveAlreadyRequested => {
            RuntimeTaskAttemptInterruptDisposition::ActiveAlreadyRequested
        }
        SubagentInterruptRequestDisposition::AlreadySettled(status) => {
            RuntimeTaskAttemptInterruptDisposition::AlreadySettled {
                status: status.as_str().to_string(),
            }
        }
    }
}

fn runtime_interrupt_projection_error(
    error: SubagentControlError,
) -> RuntimeTaskAttemptInterruptProjectionError {
    match error {
        SubagentControlError::PendingCapacityExceeded { limit } => {
            RuntimeTaskAttemptInterruptProjectionError::PendingCapacityExceeded { limit }
        }
        SubagentControlError::IdentityConflict {
            task_id,
            attempt,
            expected_execution_id,
            actual_execution_id,
        } => RuntimeTaskAttemptInterruptProjectionError::IdentityConflict {
            task_id,
            attempt,
            expected_execution_id,
            actual_execution_id,
        },
        error => RuntimeTaskAttemptInterruptProjectionError::Unavailable {
            message: error.to_string(),
        },
    }
}

impl SubagentExecutor {
    /// Create a new executor backed by the given registry.
    pub fn new(registry: Arc<SubagentRegistry>, config: SubagentExecutorConfig) -> Self {
        let local_fork_admission = Arc::new(ExecutionAdmission::with_capacity(
            config.max_concurrent_forks,
        ));
        let shared_admission = config.shared_admission.clone();
        Self {
            control_registry: Arc::clone(registry.control_registry()),
            registry,
            hooks: Arc::new(SubagentHookRegistry::new()),
            config,
            local_fork_admission,
            shared_admission: Arc::new(tokio::sync::RwLock::new(shared_admission)),
            team_runtimes: Arc::new(Mutex::new(TeamRuntimeIndex::default())),
        }
    }

    /// Create with a specific hook registry.
    pub fn with_hooks(
        registry: Arc<SubagentRegistry>,
        config: SubagentExecutorConfig,
        hooks: SubagentHookRegistry,
    ) -> Self {
        let local_fork_admission = Arc::new(ExecutionAdmission::with_capacity(
            config.max_concurrent_forks,
        ));
        let shared_admission = config.shared_admission.clone();
        Self {
            control_registry: Arc::clone(registry.control_registry()),
            registry,
            hooks: Arc::new(hooks),
            config,
            local_fork_admission,
            shared_admission: Arc::new(tokio::sync::RwLock::new(shared_admission)),
            team_runtimes: Arc::new(Mutex::new(TeamRuntimeIndex::default())),
        }
    }

    /// Get the hook registry (for external registration).
    pub fn hooks(&self) -> &SubagentHookRegistry {
        &self.hooks
    }

    /// Shared registry handle (for callers that need definition lookups).
    pub fn registry(&self) -> &Arc<SubagentRegistry> {
        &self.registry
    }

    /// Create one complete live-control capability for an external task adapter.
    pub fn attempt_control_handle(
        &self,
        control_scope_id: impl Into<String>,
    ) -> std::result::Result<SubagentAttemptControlHandle, SubagentControlError> {
        let control_scope_id = control_scope_id.into();
        if control_scope_id.trim().is_empty() {
            return Err(SubagentControlError::InvalidIdentity {
                field: "control_scope_id",
            });
        }
        Ok(SubagentAttemptControlHandle {
            executor: self.clone_for_spawn(),
            control_scope_id,
        })
    }

    /// Return one retained Team runtime by its unique handle identity.
    pub fn team_runtime_handle(
        &self,
        handle_id: &str,
    ) -> Option<Arc<super::team::TeamRuntimeHandle>> {
        self.team_runtimes
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .handles
            .get(handle_id)
            .cloned()
    }

    /// Return every retained Team runtime for a business run. Multiple nested
    /// or concurrent Team executions can legitimately share the same run ID.
    pub fn team_runtime_handles(&self, run_id: &str) -> Vec<Arc<super::team::TeamRuntimeHandle>> {
        let runtimes = self
            .team_runtimes
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        runtimes
            .order
            .iter()
            .filter_map(|handle_id| runtimes.handles.get(handle_id))
            .filter(|handle| handle.run_id() == run_id)
            .cloned()
            .collect()
    }

    fn retain_team_runtime(&self, handle: Arc<super::team::TeamRuntimeHandle>) {
        let mut runtimes = self
            .team_runtimes
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let handle_id = handle.handle_id().to_string();
        if !runtimes.handles.contains_key(&handle_id) {
            runtimes.order.push_back(handle_id.clone());
        }
        runtimes.handles.insert(handle_id, handle);
        drop(runtimes);
        prune_team_runtime_index(&self.team_runtimes);
    }

    /// Inject an application-owned process admission for direct dispatches.
    pub async fn set_shared_admission(&self, admission: Arc<ExecutionAdmission>) {
        *self.shared_admission.write().await = Some(admission);
    }

    fn retain_invocation_resources(
        &self,
        req: &DispatchRequest,
    ) -> Result<Option<SubagentPhysicalResources>> {
        let guards = req
            .runtime_context
            .as_ref()
            .map(|context| context.resource_guards.clone())
            .unwrap_or_default();
        if guards.is_empty() {
            return Ok(None);
        }
        let lease = self
            .local_fork_admission
            .keyed()
            .issue(format!("subagent-resources:{}", uuid::Uuid::new_v4()))
            .map_err(|error| ReactError::Other(error.to_string()))?;
        Ok(Some(SubagentPhysicalResources {
            lease: Some(lease),
            isolation: None,
            resource_guards: guards,
            uncertain: true,
        }))
    }

    /// Main dispatch entry point.
    ///
    /// Routes to the appropriate mode based on the definition or override.
    /// Uses a loop for retry/delegation instead of recursion to prevent stack overflow.
    pub async fn dispatch(&self, mut req: DispatchRequest) -> Result<SubagentResult> {
        req.cancel = req.cancel.child_token();
        self.dispatch_owned(req, None, None).await
    }

    /// Dispatch a previously selected record through the normal host policy.
    ///
    /// This preserves a tool's definition-based routing and actual executable
    /// as one selection. Foreign-registry or differently named records fail
    /// before construction. Retries select and admit their actual target anew.
    pub async fn dispatch_registered(
        &self,
        mut req: DispatchRequest,
        registration: SubagentRegistration,
    ) -> Result<SubagentResult> {
        req.cancel = req.cancel.child_token();
        self.dispatch_owned(
            req,
            None,
            Some(DispatchRegistration {
                registration,
                admitted: false,
            }),
        )
        .await
    }

    async fn dispatch_owned(
        &self,
        req: DispatchRequest,
        admission: Option<super::control::SubagentAttemptAdmission>,
        registration: Option<DispatchRegistration>,
    ) -> Result<SubagentResult> {
        struct CancelObservation(CancellationToken);
        impl Drop for CancelObservation {
            fn drop(&mut self) {
                self.0.cancel();
            }
        }
        let _observer = CancelObservation(req.cancel.clone());
        let owner = self.clone_for_spawn();
        let observation_execution = admission
            .as_ref()
            .map(|admission| admission.binding.identity().execution_id.clone())
            .or_else(|| {
                req.runtime_context
                    .as_ref()
                    .and_then(|context| context.execution_id.clone())
            });
        let observation_run = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.run_id.clone())
            .or_else(|| {
                admission
                    .as_ref()
                    .and_then(|admission| admission.binding.identity().run_id.clone())
            })
            .unwrap_or_else(|| format!("subagent-owner:{}", uuid::Uuid::new_v4()));
        // Admission, stream, permits and lifecycle publication are all inside
        // this same original owner, independent of a dropped caller's wait.
        tokio::spawn(async move {
            let binding = admission
                .as_ref()
                .map(|admission| admission.binding.clone());
            let result = owner.dispatch_inner(req, binding, registration).await;
            if let Some(admission) = admission {
                let status = match &result {
                    Ok(result) => result.outcome.status,
                    Err(error) => subagent_status_from_error(error)?,
                };
                admission.settle(status);
            }
            result
        })
        .await
        .map_err(|error| {
            tracing::error!(run_id=%observation_run, panic=error.is_panic(), cancelled=error.is_cancelled(), error=%error,
                "Subagent execution owner lost without physical receipt");
            ReactError::ExecutionNotSettled { run_id: observation_run, execution_id: observation_execution }
        })?
    }

    /// Dispatch one explicitly identified task attempt under live control.
    ///
    /// The identity is process-scoped. Durable run/revision/command validation
    /// remains the responsibility of the framework consumer.
    pub async fn dispatch_attempt(
        &self,
        req: DispatchRequest,
        identity: SubagentAttemptIdentity,
    ) -> Result<SubagentResult> {
        let (req, admission) = self.admit_attempt(req, identity)?;
        self.dispatch_admitted_attempt(req, admission).await
    }

    fn admit_attempt(
        &self,
        mut req: DispatchRequest,
        identity: SubagentAttemptIdentity,
    ) -> Result<(DispatchRequest, super::control::SubagentAttemptAdmission)> {
        Self::bind_attempt_runtime_identity(&mut req, &identity)?;
        let admission = self
            .control_registry
            .admit(identity, req.cancel.clone())
            .map_err(Self::control_react_error)?;
        req.cancel = admission.cancel.clone();
        if let Some(context) = req.runtime_context.as_mut() {
            context.cancel = Some(Arc::new(req.cancel.clone()));
        }
        Self::append_queued_guidance(&mut req.task, &admission.guidance);
        Ok((req, admission))
    }

    async fn dispatch_admitted_attempt(
        &self,
        req: DispatchRequest,
        admission: super::control::SubagentAttemptAdmission,
    ) -> Result<SubagentResult> {
        self.dispatch_owned(req, Some(admission), None).await
    }

    /// Deliver a live instruction to one exact active attempt.
    pub async fn send_message_tracked(
        &self,
        execution_id: &str,
        expected_attempt: u32,
        instruction: impl Into<String>,
    ) -> std::result::Result<SubagentMessageReceipt, SubagentControlError> {
        self.control_registry
            .send_message_tracked(execution_id, expected_attempt, instruction)
            .await
    }

    /// Queue guidance for one exact future attempt. Admission claims it once.
    pub fn queue_guidance(
        &self,
        task_id: &str,
        expected_next_attempt: u32,
        instruction: impl Into<String>,
    ) -> std::result::Result<SubagentGuidanceQueueReceipt, SubagentControlError> {
        self.control_registry
            .queue_guidance(task_id, expected_next_attempt, instruction)
    }

    /// Queue guidance in the same control scope and run as a future admission.
    ///
    /// The future attempt may not have an execution id yet. This carries its
    /// logical scope/run identity into the existing queue; admission claims the
    /// guidance once, without changing the legacy unscoped queue.
    pub fn queue_guidance_scoped(
        &self,
        control_scope_id: &str,
        run_id: &str,
        task_id: &str,
        expected_next_attempt: u32,
        instruction: impl Into<String>,
    ) -> std::result::Result<SubagentGuidanceQueueReceipt, SubagentControlError> {
        self.control_registry.queue_guidance_scoped(
            control_scope_id,
            run_id,
            task_id,
            expected_next_attempt,
            instruction,
        )
    }

    /// Cancel one exact attempt and wait until its dispatch has settled.
    pub async fn interrupt_subagent(
        &self,
        execution_id: &str,
        expected_attempt: u32,
    ) -> std::result::Result<SubagentInterruptOutcome, SubagentControlError> {
        self.control_registry
            .interrupt(
                execution_id,
                expected_attempt,
                crate::tasks::RuntimeTaskServiceConfig::default().cancellation_grace_period,
            )
            .await
    }

    /// Request an exact attempt interruption without waiting for settlement.
    ///
    /// This process-local acknowledgement may be queued before dispatch
    /// admission. Durable callers must validate the corresponding TaskClaim
    /// before invoking this registry-level projection.
    pub fn request_interrupt(
        &self,
        identity: SubagentAttemptIdentity,
    ) -> std::result::Result<super::control::SubagentInterruptRequestReceipt, SubagentControlError>
    {
        self.control_registry.request_interrupt(identity)
    }

    /// Bind a claimed Team task to its exact live-control identity before it
    /// waits for execution capacity. The later dispatch consumes this binding.
    pub(crate) fn reserve_attempt(
        &self,
        identity: SubagentAttemptIdentity,
        cancel: CancellationToken,
    ) -> std::result::Result<(), SubagentControlError> {
        self.control_registry.reserve(identity, cancel)
    }

    pub(crate) fn retire_attempt_control(
        &self,
        identity: &SubagentAttemptIdentity,
    ) -> std::result::Result<bool, SubagentControlError> {
        self.control_registry.retire_exact(identity)
    }

    pub(crate) fn reconcile_attempt_control(
        &self,
        control_scope_id: &str,
        run_id: &str,
        current_execution_ids: &HashSet<String>,
    ) -> std::result::Result<(), SubagentControlError> {
        self.control_registry
            .reconcile_scope(control_scope_id, run_id, current_execution_ids)
    }

    /// Stamp identity/lineage basics and install the default uplink sink on a
    /// dispatch request.
    ///
    /// Precedence: caller-stamped lineage fields always win (the `agent_tool`
    /// path fills the parent path/execution id; application task runtimes fill
    /// task/attempt/revision); only missing basics are derived here. An
    /// application-provided uplink sink is never replaced — the framework
    /// default (event bus + shared control-registry delivery) is a fallback,
    /// not an override.
    fn enrich_dispatch_context(&self, req: &mut DispatchRequest) {
        let Some(context) = req.runtime_context.as_mut() else {
            return;
        };
        let lineage = context
            .subagent_lineage
            .get_or_insert_with(Default::default);
        if lineage.agent_name.is_none() {
            lineage.agent_name = Some(req.agent_name.clone());
        }
        if lineage.parent_agent.is_none() {
            lineage.parent_agent = Some(req.parent_agent.clone());
        }
        if lineage.agent_path.is_none() {
            lineage.agent_path = Some(format!("root/{}", req.agent_name));
        }
        if lineage.execution_id.is_none() {
            lineage.execution_id = context.execution_id.clone();
        }
        if lineage.run_id.is_none() {
            lineage.run_id = context.run_id.clone();
        }
        if context.uplink.is_none() {
            context.uplink = Some(default_uplink_sink(Arc::clone(&self.registry)));
        }
    }

    fn event_publisher(&self, req: &DispatchRequest) -> Result<SubagentEventPublisher> {
        let runtime = req.runtime_context.as_ref();
        let transport_identity = EventIdentity::from_runtime_context(runtime)?;
        let invocation_identity = Self::event_invocation_identity(req, &transport_identity)?;
        self.registry
            .event_bus()
            .publisher(transport_identity, invocation_identity)
    }

    fn event_invocation_identity(
        req: &DispatchRequest,
        transport_identity: &EventIdentity,
    ) -> Result<SubagentInvocationIdentity> {
        let runtime = req.runtime_context.as_ref();
        SubagentInvocationIdentity::from_lineage(
            req.parent_agent.clone(),
            req.agent_name.clone(),
            transport_identity,
            runtime.and_then(|context| context.subagent_lineage.as_ref()),
        )
    }

    fn retarget_dispatch_context(req: &mut DispatchRequest) {
        let Some(context) = req.runtime_context.as_mut() else {
            return;
        };
        let lineage = context
            .subagent_lineage
            .get_or_insert_with(Default::default);
        lineage.agent_name = Some(req.agent_name.clone());
        lineage.parent_agent = Some(req.parent_agent.clone());
        lineage.agent_path = Some(
            lineage
                .agent_path
                .as_deref()
                .and_then(|path| path.rsplit_once('/').map(|(parent, _)| parent))
                .map(|parent| format!("{parent}/{}", req.agent_name))
                .unwrap_or_else(|| format!("root/{}", req.agent_name)),
        );
    }

    fn emit_pre_execution_failure(
        publisher: &SubagentEventPublisher,
        req: &DispatchRequest,
        error: &ReactError,
    ) -> Result<()> {
        let status = subagent_status_from_error(error)?;
        let detail = error.to_string();
        let outcome = SubagentOutcome::terminal(status, detail.clone(), vec![detail.clone()]);
        let runtime = req.runtime_context.as_ref();
        if status == SubagentStatus::Cancelled {
            publisher.emit(SubagentEvent::DispatchCancelled {
                parent: req.parent_agent.clone(),
                agent: req.agent_name.clone(),
                outcome,
                execution_id: runtime.and_then(|context| context.execution_id.clone()),
                run_id: runtime.and_then(|context| context.run_id.clone()),
            })?;
        } else {
            publisher.emit(SubagentEvent::DispatchFailed {
                parent: req.parent_agent.clone(),
                agent: req.agent_name.clone(),
                error: detail,
                status,
                outcome,
                execution_id: runtime.and_then(|context| context.execution_id.clone()),
                run_id: runtime.and_then(|context| context.run_id.clone()),
            })?;
        }
        Ok(())
    }

    fn terminal_event_for_result(
        parent: &str,
        agent: &str,
        result: &mut SubagentResult,
        execution_id: Option<String>,
        run_id: Option<String>,
    ) -> SubagentEvent {
        match result.outcome.status {
            SubagentStatus::Cancelled => SubagentEvent::DispatchCancelled {
                parent: parent.to_string(),
                agent: agent.to_string(),
                outcome: result.outcome.clone(),
                execution_id,
                run_id,
            },
            SubagentStatus::Completed => SubagentEvent::DispatchCompleted {
                parent: parent.to_string(),
                agent: agent.to_string(),
                duration_ms: u64::try_from(result.duration.as_millis()).unwrap_or(u64::MAX),
                tokens_used: result
                    .tokens_used
                    .map(|tokens| u64::try_from(tokens).unwrap_or(u64::MAX)),
                iterations: Some(u64::try_from(result.iterations).unwrap_or(u64::MAX)),
                output: result.output.clone(),
                outcome: result.outcome.clone(),
                execution_id,
                run_id,
            },
            status => {
                let status = if status == SubagentStatus::Running {
                    result.outcome.status = SubagentStatus::Failed;
                    result.outcome.summary =
                        "Subagent returned without a terminal outcome".to_string();
                    SubagentStatus::Failed
                } else {
                    status
                };
                let error = if result.outcome.summary.is_empty() {
                    format!("Subagent '{agent}' reported {}", status.as_str())
                } else {
                    result.outcome.summary.clone()
                };
                SubagentEvent::DispatchFailed {
                    parent: parent.to_string(),
                    agent: agent.to_string(),
                    error,
                    status,
                    outcome: result.outcome.clone(),
                    execution_id,
                    run_id,
                }
            }
        }
    }

    // Keep dispatch lazy and boxed: strategies can dispatch further Subagents,
    // while the future itself already carries Rust's must-use contract.
    fn dispatch_inner(
        &self,
        mut req: DispatchRequest,
        control: Option<SubagentAttemptBinding>,
        registration: Option<DispatchRegistration>,
    ) -> futures::future::BoxFuture<'_, Result<SubagentResult>> {
        Box::pin(async move {
            let mut retry_count: u32 = 0;
            let max_retries: u32 = 3; // Prevent infinite retry loops
            // Save parent cancel token so retry/delegate paths propagate cancellation
            // instead of creating independent tokens (P1 — CancellationToken propagation).
            let parent_cancel = req.cancel.clone();

            // Stamp identity and create the single attempt-scoped ordering
            // authority before any accepted dispatch can settle or fail setup.
            self.enrich_dispatch_context(&mut req);
            let event_publisher = self.event_publisher(&req)?;
            let mut initial_registration = match registration {
                Some(registration) => Some(registration),
                None => self
                    .registry
                    .resolve_registration(&req.agent_name)
                    .await
                    .map(|registration| DispatchRegistration {
                        registration,
                        admitted: false,
                    }),
            };
            let initial_mode = req
                .mode_override
                .clone()
                .or_else(|| {
                    initial_registration
                        .as_ref()
                        .map(|registered| registered.registration.definition.execution_mode.clone())
                })
                .unwrap_or(ExecutionMode::Sync);
            let runtime = req.runtime_context.as_ref();
            event_publisher.emit(SubagentEvent::DispatchStarted {
                parent: req.parent_agent.clone(),
                agent: req.agent_name.clone(),
                mode: initial_mode.clone(),
                task: req.task.clone(),
                execution_id: runtime.and_then(|context| context.execution_id.clone()),
                run_id: runtime.and_then(|context| context.run_id.clone()),
                conversation_id: runtime.and_then(|context| context.conversation_id.clone()),
                message_id: runtime.and_then(|context| context.message_id.clone()),
                background: req.background,
            })?;

            if parent_cancel.is_cancelled() {
                let result = SubagentResult::cancelled(
                    req.agent_name.clone(),
                    "Cancelled before execution",
                    initial_mode,
                );
                event_publisher.emit(SubagentEvent::DispatchCancelled {
                    parent: req.parent_agent.clone(),
                    agent: req.agent_name.clone(),
                    outcome: result.outcome.clone(),
                    execution_id: runtime.and_then(|context| context.execution_id.clone()),
                    run_id: runtime.and_then(|context| context.run_id.clone()),
                })?;
                return Ok(result);
            }

            if req.delegation_policy.delegate_depth > req.delegation_policy.max_delegate_depth {
                let error = ReactError::Other(format!(
                    "Delegation depth exceeded (max {}): agent '{}'",
                    req.delegation_policy.max_delegate_depth, req.agent_name
                ));
                Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                return Err(error);
            }
            if initial_registration.is_none() {
                let error = ReactError::Other(format!("Subagent '{}' not found", req.agent_name));
                Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                return Err(error);
            }

            loop {
                // Guard against excessive retries
                if retry_count > max_retries {
                    let error =
                        ReactError::Agent(Box::new(AgentError::ContextLimitExceeded(format!(
                            "Max retry count exceeded ({}): agent '{}'",
                            max_retries, req.agent_name
                        ))));
                    Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                    return Err(error);
                }

                // The first record may come from agent_tool's routing. Every
                // retry/retarget resolves once again; strategies never perform
                // a second name lookup for definition or executable.
                let selected = match initial_registration.take() {
                    Some(selected) => Some(selected),
                    None => self
                        .registry
                        .resolve_registration(&req.agent_name)
                        .await
                        .map(|registration| DispatchRegistration {
                            registration,
                            admitted: false,
                        }),
                };
                let selected = match selected {
                    Some(selected) => selected,
                    None => {
                        let error =
                            ReactError::Other(format!("Subagent '{}' not found", req.agent_name));
                        Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                        return Err(error);
                    }
                };
                let registered = selected.registration;
                if !selected.admitted
                    && let Err(error) = self
                        .registry
                        .admit_registration(&registered, &mut req)
                        .await
                {
                    Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                    return Err(error);
                }

                let mode = req
                    .mode_override
                    .as_ref()
                    .unwrap_or(&registered.definition.execution_mode)
                    .clone();
                let runtime_run_id = req
                    .runtime_context
                    .as_ref()
                    .and_then(|ctx| ctx.run_id.as_deref())
                    .unwrap_or("<none>");
                // Extract stable identity for event payload (Option<String>).
                // Used by all Dispatch* events so the bridge/frontend can route
                // thinking/tool/token streams without temp id allocation.
                let event_execution_id = req
                    .runtime_context
                    .as_ref()
                    .and_then(|ctx| ctx.execution_id.clone());
                let event_run_id = req
                    .runtime_context
                    .as_ref()
                    .and_then(|ctx| ctx.run_id.clone());
                let has_trace_sink = req
                    .runtime_context
                    .as_ref()
                    .is_some_and(|ctx| ctx.trace_sink.is_some());
                let has_cancel = req
                    .runtime_context
                    .as_ref()
                    .is_some_and(|ctx| ctx.cancel.is_some());
                info!(
                    parent = %req.parent_agent,
                    subagent = %req.agent_name,
                    mode = ?mode,
                    attempt = retry_count + 1,
                    delegate_depth = req.delegation_policy.delegate_depth,
                    runtime_run_id = %runtime_run_id,
                    has_runtime_context = req.runtime_context.is_some(),
                    has_trace_sink,
                    has_cancel,
                    task_chars = req.task.chars().count(),
                    "subagent_dispatch_start"
                );

                // Build hook context
                let hook_ctx = SubagentHookContext {
                    parent_agent: req.parent_agent.clone(),
                    subagent_name: req.agent_name.clone(),
                    execution_mode: mode.clone(),
                    task: req.task.clone(),
                    attempt: 1 + retry_count,
                };

                if self.config.enable_hooks {
                    self.hooks.before_dispatch(&hook_ctx).await;
                }

                // Snapshot fields needed in error path before `req` is moved
                let req_agent_name = req.agent_name.clone();
                let req_parent_agent = req.parent_agent.clone();
                let delegation_policy = req.delegation_policy;

                // Fire unified SubagentStart for this concrete dispatch attempt.
                if let Some(ref executor) = self.config.unified_hook_executor {
                    let ctx = correlate_subagent_hook(
                        crate::skills::hooks::HookContext::for_subagent_start(
                            &req_agent_name,
                            &mode.to_string(),
                            &req.task,
                            "", // session_id not available at this layer
                            &req_parent_agent,
                        ),
                        event_run_id.as_deref(),
                        event_execution_id.as_deref(),
                        hook_ctx.attempt,
                    );
                    executor(ctx).await;
                }

                // Reuse the original keyed admission authority for borrowed
                // invocation resources, without consuming a Fork process slot.
                // A typed observation (or unwind) cannot release those guards.
                // Fork retains the same bundle in its existing physical slot.
                let mut resources = if !matches!(mode, ExecutionMode::Fork) {
                    self.retain_invocation_resources(&req)?
                } else {
                    None
                };
                // Dispatch based on mode
                let start = Instant::now();
                let result = match mode {
                    ExecutionMode::Sync => {
                        self.dispatch_sync(
                            &req,
                            &registered,
                            control.clone(),
                            event_publisher.clone(),
                        )
                        .await
                    }
                    ExecutionMode::Fork => {
                        self.dispatch_fork(
                            &req,
                            &registered,
                            control.clone(),
                            event_publisher.clone(),
                        )
                        .await
                    }
                    ExecutionMode::Teammate => {
                        // Teammate mode: spawn independently, then await result
                        match self
                            .dispatch_teammate_with_control(
                                req.clone(),
                                control.clone(),
                                event_publisher.clone(),
                                false,
                                &registered,
                                None,
                            )
                            .await
                        {
                            Ok(handle) => handle.join().await,
                            Err(e) => Err(e),
                        }
                    }
                    ExecutionMode::Team => {
                        self.dispatch_team(&req, &registered, event_publisher.clone())
                            .await
                    }
                };

                if let Some(resources) = resources.as_mut() {
                    resources.uncertain =
                        matches!(&result, Err(ReactError::ExecutionNotSettled { .. }));
                }
                let duration = start.elapsed();

                match result {
                    Ok(mut sub_result) => {
                        sub_result.duration = duration;
                        sub_result.mode = mode.clone();
                        info!(
                            parent = %req_parent_agent,
                            subagent = %req_agent_name,
                            mode = ?mode,
                            duration_ms = duration.as_millis() as u64,
                            output_chars = sub_result.output.chars().count(),
                            tokens_used = ?sub_result.tokens_used,
                            iterations = sub_result.iterations,
                            "subagent_dispatch_complete"
                        );

                        event_publisher.emit(Self::terminal_event_for_result(
                            &req_parent_agent,
                            &req_agent_name,
                            &mut sub_result,
                            event_execution_id.clone(),
                            event_run_id.clone(),
                        ))?;

                        if self.config.enable_hooks {
                            self.hooks.after_dispatch(&hook_ctx, &sub_result).await;
                        }

                        // Every Start has exactly one Stop. An executor may return a
                        // structured cancelled/failed outcome inside Ok, so map the
                        // outcome instead of assuming Completed from the Result arm.
                        if let Some(ref executor) = self.config.unified_hook_executor {
                            let ctx = correlate_subagent_hook(
                                crate::skills::hooks::HookContext::for_subagent_stop(
                                    &req_agent_name,
                                    &mode.to_string(),
                                    &sub_result.output,
                                    hook_stop_status(sub_result.outcome.status),
                                    "",
                                    &req_parent_agent,
                                ),
                                event_run_id.as_deref(),
                                event_execution_id.as_deref(),
                                hook_ctx.attempt,
                            );
                            executor(ctx).await;
                        }

                        return Ok(sub_result);
                    }
                    Err(e) => {
                        let error_str = e.to_string();
                        let status = subagent_status_from_error(&e)?;
                        let terminal_result = SubagentOutcome::terminal(
                            status,
                            error_str.clone(),
                            vec![error_str.clone()],
                        );
                        warn!(
                            parent = %req_parent_agent,
                            subagent = %req_agent_name,
                            mode = ?mode,
                            error = %error_str,
                            "subagent_dispatch_failed"
                        );

                        // Close this attempt before cancellation returns or a hook
                        // policy starts another attempt. Previously cancellation
                        // returned above the only Stop call, while retries emitted
                        // multiple Starts followed by one terminal Stop.
                        if let Some(ref executor) = self.config.unified_hook_executor {
                            let ctx = correlate_subagent_hook(
                                crate::skills::hooks::HookContext::for_subagent_stop(
                                    &req_agent_name,
                                    &mode.to_string(),
                                    &format!("error: {error_str}"),
                                    hook_stop_status(status),
                                    "",
                                    &req_parent_agent,
                                ),
                                event_run_id.as_deref(),
                                event_execution_id.as_deref(),
                                hook_ctx.attempt,
                            );
                            executor(ctx).await;
                        }

                        if status == SubagentStatus::Cancelled {
                            event_publisher.emit(SubagentEvent::DispatchCancelled {
                                parent: req_parent_agent.clone(),
                                agent: req_agent_name.clone(),
                                outcome: terminal_result,
                                execution_id: event_execution_id.clone(),
                                run_id: event_run_id.clone(),
                            })?;
                            return Err(e);
                        }

                        if self.config.enable_hooks {
                            let decision = self.hooks.on_failure(&hook_ctx, &error_str).await;
                            match decision {
                                super::hooks::SubagentRetryDecision::Delegate {
                                    alternative_agent,
                                } => {
                                    if let Some(child_policy) = delegation_policy.child_policy() {
                                        info!(
                                            from = %hook_ctx.subagent_name,
                                            to = %alternative_agent,
                                            depth = child_policy.delegate_depth,
                                            "Delegating to alternative subagent"
                                        );
                                        retry_count = retry_count.saturating_add(1);
                                        let rt_ctx = req.runtime_context.clone();
                                        let retry_msg = req.message.clone();
                                        let prompt_payload = req.prompt_payload.clone();
                                        let prompt_context = req.prompt_context.clone();
                                        let parent_context = req.parent_context.clone();
                                        let constraints = req.constraints.clone();
                                        req = DispatchRequest {
                                            agent_name: alternative_agent,
                                            task: hook_ctx.task.clone(),
                                            mode_override: Some(hook_ctx.execution_mode.clone()),
                                            cancel: parent_cancel.child_token(),
                                            parent_agent: hook_ctx.parent_agent.clone(),
                                            parent_context,
                                            delegation_policy: child_policy,
                                            runtime_context: rt_ctx,
                                            message: retry_msg,
                                            prompt_payload,
                                            prompt_context,
                                            constraints,
                                            background: false,
                                        };
                                        Self::retarget_dispatch_context(&mut req);
                                        event_publisher.retarget_from_lineage(
                                            req.parent_agent.clone(),
                                            req.agent_name.clone(),
                                            req.runtime_context.as_ref().and_then(|context| {
                                                context.subagent_lineage.as_ref()
                                            }),
                                        )?;
                                        // This attempt is recoverable, so it is not a terminal event.
                                        continue;
                                    }
                                    warn!(
                                        agent = %hook_ctx.subagent_name,
                                        max_depth = delegation_policy.max_delegate_depth,
                                        "subagent delegation rejected at depth limit"
                                    );
                                }
                                super::hooks::SubagentRetryDecision::Retry { delay_secs } => {
                                    if retry_count < max_retries {
                                        info!(
                                            delay_secs,
                                            attempt = retry_count.saturating_add(2),
                                            "Retrying subagent dispatch"
                                        );
                                        tokio::time::sleep(Duration::from_secs(delay_secs)).await;
                                        retry_count = retry_count.saturating_add(1);
                                        let rt_ctx = req.runtime_context.clone();
                                        let retry_msg = req.message.clone();
                                        let prompt_payload = req.prompt_payload.clone();
                                        let prompt_context = req.prompt_context.clone();
                                        let parent_context = req.parent_context.clone();
                                        let constraints = req.constraints.clone();
                                        req = DispatchRequest {
                                            agent_name: hook_ctx.subagent_name.clone(),
                                            task: hook_ctx.task.clone(),
                                            mode_override: Some(hook_ctx.execution_mode.clone()),
                                            cancel: parent_cancel.child_token(),
                                            parent_agent: hook_ctx.parent_agent.clone(),
                                            parent_context,
                                            delegation_policy,
                                            runtime_context: rt_ctx,
                                            message: retry_msg,
                                            prompt_payload,
                                            prompt_context,
                                            constraints,
                                            background: false,
                                        };
                                        // This attempt is recoverable, so it is not a terminal event.
                                        continue;
                                    }
                                    warn!(
                                        agent = %hook_ctx.subagent_name,
                                        max_retries,
                                        "subagent retry limit reached"
                                    );
                                }
                                super::hooks::SubagentRetryDecision::Fail => {}
                            }
                        }

                        event_publisher.emit(SubagentEvent::DispatchFailed {
                            parent: req_parent_agent.clone(),
                            agent: req_agent_name.clone(),
                            error: error_str.clone(),
                            status,
                            outcome: terminal_result,
                            execution_id: event_execution_id.clone(),
                            run_id: event_run_id.clone(),
                        })?;

                        return Err(e);
                    }
                }
            }
        })
    }

    /// Clone internals so a background subagent can own an executor on a spawned task.
    fn clone_for_spawn(&self) -> Self {
        Self {
            registry: self.registry.clone(),
            hooks: self.hooks.clone(),
            config: SubagentExecutorConfig {
                max_concurrent_forks: self.config.max_concurrent_forks,
                default_timeout_secs: self.config.default_timeout_secs,
                enable_hooks: self.config.enable_hooks,
                unified_hook_executor: self.config.unified_hook_executor.clone(),
                isolation_provider: self.config.isolation_provider.clone(),
                prompt_compiler: self.config.prompt_compiler.clone(),
                shared_admission: self.config.shared_admission.clone(),
            },
            local_fork_admission: self.local_fork_admission.clone(),
            control_registry: self.control_registry.clone(),
            shared_admission: self.shared_admission.clone(),
            team_runtimes: self.team_runtimes.clone(),
        }
    }

    fn bind_attempt_runtime_identity(
        req: &mut DispatchRequest,
        identity: &SubagentAttemptIdentity,
    ) -> Result<()> {
        let context =
            req.runtime_context
                .get_or_insert_with(|| echo_core::tools::ExternalRunContext {
                    conversation_id: None,
                    run_id: None,
                    turn_id: Some(identity.execution_id.clone()),
                    execution_id: Some(identity.execution_id.clone()),
                    isolation_id: None,
                    message_id: None,
                    cancel: None,
                    trace_sink: None,
                    delegation_policy: None,
                    resource_guards: Vec::new(),
                    subagent_lineage: None,
                    uplink: None,
                });
        if let Some(existing) = context.execution_id.as_deref()
            && existing != identity.execution_id.as_str()
        {
            return Err(Self::control_react_error(
                SubagentControlError::ExecutionIdentityMismatch {
                    expected: identity.execution_id.clone(),
                    actual: existing.to_string(),
                },
            ));
        }
        context.execution_id = Some(identity.execution_id.clone());
        if context.turn_id.is_none() && context.run_id.is_none() {
            context.turn_id = Some(identity.execution_id.clone());
        }
        let lineage = context
            .subagent_lineage
            .get_or_insert_with(Default::default);
        lineage.execution_id = Some(identity.execution_id.clone());
        lineage.task_id = Some(identity.task_id.clone());
        lineage.attempt = Some(identity.attempt);
        if lineage.run_id.is_none() {
            lineage.run_id = context.run_id.clone();
        }
        Ok(())
    }

    fn append_queued_guidance(task: &mut String, guidance: &[String]) {
        if guidance.is_empty() {
            return;
        }
        task.push_str("\n\n[queued_guidance]");
        for instruction in guidance {
            task.push_str("\n- ");
            task.push_str(instruction);
        }
        task.push_str("\n[/queued_guidance]");
    }

    fn control_react_error(error: SubagentControlError) -> ReactError {
        match error {
            SubagentControlError::ExecutionNotSettled {
                run_id,
                execution_id,
            } => ReactError::ExecutionNotSettled {
                run_id,
                execution_id: Some(execution_id),
            },
            other => ReactError::Other(format!("Subagent control rejected: {other}")),
        }
    }

    /// Ensure `runtime_context.execution_id` is set (generate `agent_tool-{uuid}` if missing).
    fn ensure_background_execution_id(req: &mut DispatchRequest) -> String {
        let ctx = req
            .runtime_context
            .get_or_insert_with(|| echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some(format!("bg-{}", uuid::Uuid::new_v4().as_simple())),
                turn_id: None,
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            });
        if ctx
            .execution_id
            .as_ref()
            .map(|id| id.is_empty())
            .unwrap_or(true)
        {
            ctx.execution_id = Some(format!("agent_tool-{}", uuid::Uuid::new_v4()));
        }
        ctx.execution_id
            .clone()
            .unwrap_or_else(|| format!("agent_tool-{}", uuid::Uuid::new_v4()))
    }

    /// Non-blocking dispatch: spawn the normal `dispatch` path and return a handle
    /// immediately. Lifecycle events still fire on the registry event bus.
    ///
    /// Mirrors the `tokio::spawn` pattern of [`Self::dispatch_teammate`], but
    /// reuses Sync/Fork/Team routing via [`Self::dispatch`] rather than the
    /// teammate-only streaming path.
    pub async fn dispatch_background(
        &self,
        req: DispatchRequest,
    ) -> Result<BackgroundSubagentHandle> {
        let registration = self
            .registry
            .resolve_registration(&req.agent_name)
            .await
            .ok_or_else(|| ReactError::Other(format!("Subagent '{}' not found", req.agent_name)))?;
        self.dispatch_background_registered(req, registration).await
    }

    /// Background variant of [`Self::dispatch_registered`].
    /// Host refusal is returned before a background handle or work is created.
    pub async fn dispatch_background_registered(
        &self,
        mut req: DispatchRequest,
        registration: SubagentRegistration,
    ) -> Result<BackgroundSubagentHandle> {
        let execution_id = Self::ensure_background_execution_id(&mut req);
        req.background = true;
        self.enrich_dispatch_context(&mut req);
        self.registry
            .admit_registration(&registration, &mut req)
            .await?;
        let observation_run_id = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.run_id.clone())
            .unwrap_or_else(|| execution_id.clone());
        let agent_name = req.agent_name.clone();
        let agent_name_for_handle = agent_name.clone();
        let cancel = req.cancel.clone();
        let spawned = self.clone_for_spawn();

        let join_handle = tokio::spawn(async move {
            req.cancel = req.cancel.child_token();
            let result = spawned
                .dispatch_owned(
                    req,
                    None,
                    Some(DispatchRegistration {
                        registration,
                        admitted: true,
                    }),
                )
                .await;
            if let Err(error) = &result {
                warn!(agent = %agent_name, error = %error, "background subagent dispatch failed");
            }
            result
        });

        Ok(BackgroundSubagentHandle {
            execution_id,
            agent_name: agent_name_for_handle,
            cancel,
            join_handle: Arc::new(Mutex::new(Some(join_handle))),
            observation_run_id,
        })
    }

    /// Non-blocking variant of [`Self::dispatch_attempt`].
    pub async fn dispatch_background_attempt(
        &self,
        req: DispatchRequest,
        identity: SubagentAttemptIdentity,
    ) -> Result<BackgroundSubagentHandle> {
        let registration = self
            .registry
            .resolve_registration(&req.agent_name)
            .await
            .ok_or_else(|| ReactError::Other(format!("Subagent '{}' not found", req.agent_name)))?;
        let (mut req, admission) = self.admit_attempt(req, identity)?;
        req.background = true;
        self.enrich_dispatch_context(&mut req);
        if let Err(error) = self
            .registry
            .admit_registration(&registration, &mut req)
            .await
        {
            // No child was constructed: settle the original exact-attempt
            // reservation instead of leaving a refused background claim live.
            admission.settle(subagent_status_from_error(&error)?);
            return Err(error);
        }
        let execution_id = admission.binding.identity().execution_id.clone();
        let observation_run_id = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.run_id.clone())
            .unwrap_or_else(|| execution_id.clone());
        let agent_name = req.agent_name.clone();
        let agent_name_for_handle = agent_name.clone();
        let cancel = req.cancel.clone();
        let spawned = self.clone_for_spawn();

        let join_handle = tokio::spawn(async move {
            let result = spawned
                .dispatch_owned(
                    req,
                    Some(admission),
                    Some(DispatchRegistration {
                        registration,
                        admitted: true,
                    }),
                )
                .await;
            if let Err(error) = &result {
                warn!(agent = %agent_name, error = %error, "controlled background subagent dispatch failed");
            }
            result
        });

        Ok(BackgroundSubagentHandle {
            execution_id,
            agent_name: agent_name_for_handle,
            cancel,
            join_handle: Arc::new(Mutex::new(Some(join_handle))),
            observation_run_id,
        })
    }

    /// Dispatch a teammate, returning a handle for async polling.
    pub async fn dispatch_teammate(&self, mut req: DispatchRequest) -> Result<TeammateHandle> {
        // This explicit entry always selects Teammate. Expose the actual mode
        // to host admission rather than a caller's otherwise ignored override.
        req.mode_override = Some(ExecutionMode::Teammate);
        self.enrich_dispatch_context(&mut req);
        let event_publisher = self.event_publisher(&req)?;
        let runtime = req.runtime_context.as_ref();
        event_publisher.emit(SubagentEvent::DispatchStarted {
            parent: req.parent_agent.clone(),
            agent: req.agent_name.clone(),
            mode: ExecutionMode::Teammate,
            task: req.task.clone(),
            execution_id: runtime.and_then(|context| context.execution_id.clone()),
            run_id: runtime.and_then(|context| context.run_id.clone()),
            conversation_id: runtime.and_then(|context| context.conversation_id.clone()),
            message_id: runtime.and_then(|context| context.message_id.clone()),
            background: req.background,
        })?;
        let result = async {
            let registration = self
                .registry
                .resolve_registration(&req.agent_name)
                .await
                .ok_or_else(|| {
                    ReactError::Other(format!("Subagent '{}' not found", req.agent_name))
                })?;
            self.registry
                .admit_registration(&registration, &mut req)
                .await?;
            // This public handle entry bypasses dispatch_inner's borrowed-
            // resource bundle. Reuse that same keyed retainer, then move it
            // into the existing Teammate physical task; no second process slot.
            let resources = self.retain_invocation_resources(&req)?;
            self.dispatch_teammate_with_control(
                req.clone(),
                None,
                event_publisher.clone(),
                true,
                &registration,
                resources,
            )
            .await
        }
        .await;
        match result {
            Ok(handle) => Ok(handle),
            Err(error) => {
                Self::emit_pre_execution_failure(&event_publisher, &req, &error)?;
                Err(error)
            }
        }
    }

    async fn dispatch_teammate_with_control(
        &self,
        req: DispatchRequest,
        control: Option<SubagentAttemptBinding>,
        event_publisher: SubagentEventPublisher,
        settle_in_handle: bool,
        registered: &SubagentRegistration,
        mut resources: Option<SubagentPhysicalResources>,
    ) -> Result<TeammateHandle> {
        let agent_arc = match registered.agent_for_dispatch().await {
            Ok(agent) => agent,
            Err(error) => {
                if let Some(resources) = resources.as_mut() {
                    resources.uncertain = matches!(&error, ReactError::ExecutionNotSettled { .. });
                }
                return Err(error);
            }
        };

        let child_token = req.cancel.child_token();
        let handle_cancel = child_token.clone();
        let compiled = self.compile_invocation(
            &req,
            ExecutionMode::Teammate,
            registered.definition.inherit_history,
            agent_arc.as_ref(),
        );
        let agent_name = req.agent_name.clone();
        let parent_agent = req.parent_agent.clone();
        let timeout_secs = if registered.definition.timeout_secs > 0 {
            registered.definition.timeout_secs
        } else {
            self.config.default_timeout_secs
        };

        let handle_id = format!("tm_{}", uuid::Uuid::new_v4().as_simple());

        // Extract stable identity for event payload (moved into the spawn).
        let event_execution_id = req
            .runtime_context
            .as_ref()
            .and_then(|ctx| ctx.execution_id.clone());
        let event_run_id = req
            .runtime_context
            .as_ref()
            .and_then(|ctx| ctx.run_id.clone());
        let mut invocation = AgentInvocationContext {
            runtime: req.runtime_context.clone(),
            working_dir: agent_arc.working_dir(),
            ..AgentInvocationContext::default()
        };
        apply_subagent_invocation_scope(
            &mut invocation,
            agent_arc.as_ref(),
            req.parent_context
                .as_ref()
                .and_then(|context| context.allowed_tools.as_deref()),
            req.parent_context
                .as_ref()
                .and_then(|context| context.tool_access),
            req.delegation_policy,
        );

        let observation_run_id = event_run_id.clone().unwrap_or_else(|| handle_id.clone());
        let observation_execution_id = event_execution_id.clone();
        let join_handle = tokio::spawn(async move {
            let _permit = child_token.clone();
            let start = Instant::now();

            let cause = Arc::new(Mutex::new(None));
            let deadline = (timeout_secs > 0)
                .then(|| tokio::time::Instant::now() + Duration::from_secs(timeout_secs));
            let execution = Self::execute_agent_streaming(
                agent_arc,
                compiled,
                child_token.clone(),
                invocation,
                &parent_agent,
                &agent_name,
                ExecutionMode::Teammate,
                start,
                event_execution_id.clone(),
                event_run_id.clone(),
                control,
                event_publisher.clone(),
                cause.clone(),
            );
            let mut result = Self::await_stream_settlement(
                execution,
                child_token,
                deadline,
                cause,
                ReactError::Agent(Box::new(AgentError::Interrupted)),
                ReactError::Agent(Box::new(AgentError::Timeout(format!(
                    "Teammate '{}' timed out after {}s",
                    agent_name, timeout_secs
                )))),
            )
            .await;
            if let Some(resources) = resources.as_mut() {
                // Agent's default invocation wrapper cannot retain a context
                // when stream setup itself returns unknown. The original keyed
                // debt owner must keep the last guard in that case (or unwind).
                resources.uncertain =
                    matches!(&result, Err(ReactError::ExecutionNotSettled { .. }));
            }
            if settle_in_handle {
                match &mut result {
                    Ok(value) => {
                        event_publisher.emit(Self::terminal_event_for_result(
                            &parent_agent,
                            &agent_name,
                            value,
                            event_execution_id.clone(),
                            event_run_id.clone(),
                        ))?;
                    }
                    Err(error) => {
                        let status = subagent_status_from_error(error)?;
                        let outcome = SubagentOutcome::terminal(
                            status,
                            error.to_string(),
                            vec![error.to_string()],
                        );
                        if status == SubagentStatus::Cancelled {
                            event_publisher.emit(SubagentEvent::DispatchCancelled {
                                parent: parent_agent.clone(),
                                agent: agent_name.clone(),
                                outcome,
                                execution_id: event_execution_id.clone(),
                                run_id: event_run_id.clone(),
                            })?;
                        } else {
                            event_publisher.emit(SubagentEvent::DispatchFailed {
                                parent: parent_agent.clone(),
                                agent: agent_name.clone(),
                                error: error.to_string(),
                                status,
                                outcome,
                                execution_id: event_execution_id.clone(),
                                run_id: event_run_id.clone(),
                            })?;
                        }
                    }
                }
            }
            result
        });

        Ok(TeammateHandle {
            id: handle_id,
            agent_name: req.agent_name.clone(),
            cancel: handle_cancel,
            join_handle,
            observation_run_id,
            observation_execution_id,
        })
    }

    /// Compile Team intent to one revisioned graph and execute it through the
    /// canonical `RuntimeTaskService`.
    async fn dispatch_team(
        &self,
        req: &DispatchRequest,
        registered: &SubagentRegistration,
        event_publisher: SubagentEventPublisher,
    ) -> Result<SubagentResult> {
        let spec = registered.definition.team.clone().ok_or_else(|| {
            ReactError::Other("Team mode requested but definition has no TeamSpec".to_string())
        })?;
        let delegation_policy = req.delegation_policy.child_policy().ok_or_else(|| {
            ReactError::Other(format!(
                "Delegation depth exceeded before Team '{}' (max {})",
                req.agent_name, req.delegation_policy.max_delegate_depth
            ))
        })?;
        // Team is a graph coordinator rather than a model invocation. Keep its
        // objective raw; every concrete member dispatch below compiles exactly
        // once with the member's actual tools, workspace, and inherited context.
        let team_objective = req.task.clone();
        let run_id = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.run_id.clone())
            .unwrap_or_else(|| format!("team-{}", uuid::Uuid::new_v4().as_simple()));
        let parent_agent = req.agent_name.clone();
        let team_prompt_payload = req.prompt_payload.clone();
        let team_prompt_context = req.prompt_context.clone();
        let team_constraints = req.constraints.clone();
        let team_message = req.message.clone();
        let team_parent_event_id = event_publisher
            .dispatch_started_event_id()
            .map(|event_id| event_id.as_str().to_string());
        let inherited_history = req
            .parent_context
            .clone()
            .filter(SubagentContext::has_content);
        // Retained Team runtime handles outlive this invocation. Their stored
        // dispatch closure must not keep a completed parent's physical lease
        // alive forever. Actual members upgrade while this original call is
        // alive, then carry real guard clones into their original resources.
        let team_resource_guards = req
            .runtime_context
            .as_ref()
            .map(|runtime| runtime.resource_guards.clone())
            .filter(|guards| !guards.is_empty())
            .map(Arc::new);
        let member_resource_guards = team_resource_guards.as_ref().map(Arc::downgrade);
        let control_scope_id = format!(
            "team-control:{}:{}",
            run_id,
            req.runtime_context
                .as_ref()
                .and_then(|context| context.execution_id.as_deref())
                .map(str::to_string)
                .unwrap_or_else(|| uuid::Uuid::new_v4().to_string())
        );
        let attempt_control = Arc::new(
            self.attempt_control_handle(control_scope_id)
                .map_err(Self::control_react_error)?,
        );
        let reserve_control = Arc::clone(&attempt_control);
        let reserve_attempt: super::team::TeamReserveAttemptFn = Arc::new(move |context| {
            reserve_control
                .reserve(&context)
                .map_err(|error| error.to_string())
        });
        let interrupt_control = Arc::clone(&attempt_control);
        let request_interrupt: super::team::TeamRequestInterruptFn =
            Arc::new(move |run_id, task_id, claim| {
                interrupt_control
                    .project_interrupt(&run_id, &task_id, &claim)
                    .map(Some)
            });
        let cleanup_control = Arc::clone(&attempt_control);
        let retire_attempt: super::team::TeamRetireAttemptFn =
            Arc::new(move |run_id, task, claim| {
                let cleanup_control = Arc::clone(&cleanup_control);
                Box::pin(async move { cleanup_control.retire(&run_id, &task, &claim) })
            });
        let reconcile_control = Arc::clone(&attempt_control);
        let reconcile_attempts: super::team::TeamReconcileAttemptFn =
            Arc::new(move |run_id, current_execution_ids| {
                reconcile_control
                    .reconcile(&run_id, &current_execution_ids)
                    .map_err(|error| error.to_string())
            });
        let spawned = self.clone_for_spawn();
        let dispatch_control = attempt_control;
        let dispatch: super::team::TeamDispatchFn = Arc::new(move |request| {
            let super::team::TeamDispatchRequest {
                member: agent_name,
                task,
                context,
            } = request;
            let executor = spawned.clone_for_spawn();
            let attempt_control = Arc::clone(&dispatch_control);
            let parent_agent = parent_agent.clone();
            let parent_context = inherited_history.clone();
            let prompt_payload = team_prompt_payload.clone();
            let message = team_message.clone();
            let mut prompt_context = team_prompt_context.clone();
            if let Some(context) = prompt_context.as_mut() {
                context.task_title = Some(task.clone());
            }
            let constraints = team_constraints.clone();
            let parent_event_id = team_parent_event_id.clone();
            let member_resource_guards = member_resource_guards.clone();
            Box::pin(async move {
                let member = executor
                    .registry
                    .resolve_registration(&agent_name)
                    .await
                    .ok_or_else(|| {
                        ReactError::Other(format!("Team Subagent '{agent_name}' not registered"))
                    })?;
                if member.definition.execution_mode == ExecutionMode::Team {
                    return Err(ReactError::Other(format!(
                        "nested Team mode is not supported for '{agent_name}'"
                    )));
                }
                let mut runtime_context = context.runtime_context();
                if let Some(guards) = member_resource_guards {
                    let guards = guards.upgrade().ok_or_else(|| ReactError::Other(
                        "Team invocation resource source has settled; refusing an unretained member".to_string(),
                    ))?;
                    runtime_context
                        .resource_guards
                        .extend(guards.iter().cloned());
                }
                runtime_context.subagent_lineage =
                    runtime_context.subagent_lineage.map(|mut lineage| {
                        lineage.agent_name = Some(agent_name.clone());
                        lineage.parent_agent = Some(parent_agent.clone());
                        lineage.parent_event_id = parent_event_id.clone();
                        lineage
                    });
                attempt_control
                    .dispatch_registered(
                        DispatchRequest {
                            agent_name,
                            task,
                            mode_override: None,
                            cancel: context.cancellation_token().clone(),
                            parent_agent,
                            parent_context,
                            delegation_policy: NestedDelegationPolicy::default(),
                            runtime_context: Some(runtime_context),
                            message,
                            prompt_payload,
                            prompt_context,
                            constraints,
                            background: false,
                        },
                        context,
                        member,
                    )
                    .await
            })
        });
        let start = Instant::now();
        let control = super::team::TeamDispatchControl {
            reserve_attempt,
            request_interrupt,
            retire_attempt,
            reconcile_attempts,
        };
        let dispatch_controller = super::team::closure_dispatch_controller(dispatch, control);
        let runtime_handle = super::team::runtime_handle_for_controller(
            run_id.clone(),
            dispatch_controller,
            echo_orchestration::tasks::RuntimeTaskServiceConfig {
                max_concurrent_subagents: spec.config.max_concurrent.max(1),
                delegation_policy,
                ..echo_orchestration::tasks::RuntimeTaskServiceConfig::default()
            },
        );
        let active = runtime_handle.start_execution();
        self.retain_team_runtime(runtime_handle.clone());
        let _retention = TeamRuntimeRetentionGuard {
            index: Arc::clone(&self.team_runtimes),
        };
        let result = runtime_handle
            .execute_started(&spec, &team_objective, req.cancel.child_token(), active)
            .await?;
        let tokens_used = result
            .usage
            .as_ref()
            .map(|usage| usize::try_from(usage.total_tokens).unwrap_or(usize::MAX));
        Ok(SubagentResult {
            agent_name: req.agent_name.clone(),
            output: result.output,
            outcome: SubagentOutcome {
                status: SubagentStatus::Completed,
                ..SubagentOutcome::default()
            },
            duration: start.elapsed(),
            iterations: 1,
            tokens_used,
            was_truncated: false,
            mode: ExecutionMode::Team,
            isolation_observed: ObservedIsolation::new("subagent"),
            llm_usage: result.usage,
        }
        .with_structured(
            req.runtime_context
                .as_ref()
                .and_then(|context| context.execution_id.as_deref()),
            std::env::current_dir().ok().as_deref(),
        ))
    }

    // ── Internal dispatch methods ──────────────────────────────────────────

    fn compile_invocation(
        &self,
        req: &DispatchRequest,
        mode: ExecutionMode,
        inherit_history: Option<usize>,
        agent: &dyn Agent,
    ) -> CompiledSubagentInvocation {
        let transfer_policy = if matches!(
            mode,
            ExecutionMode::Fork | ExecutionMode::Teammate | ExecutionMode::Team
        ) && req
            .parent_context
            .as_ref()
            .is_some_and(|context| !context.messages.is_empty())
        {
            ContextTransferPolicy::InheritStructured
        } else {
            ContextTransferPolicy::Fresh
        };
        let mut context = req.prompt_context.clone().unwrap_or_default();
        if context.user_goal.is_none() {
            context.user_goal = req
                .parent_context
                .as_ref()
                .and_then(|parent| parent.parent_goal.clone());
        }
        if context.workspace.is_none() {
            context.workspace = agent.working_dir();
        }
        if context.constraints.is_empty() {
            context.constraints = req.constraints.clone();
        }
        let allowed_tools = req
            .parent_context
            .as_ref()
            .and_then(|parent| parent.allowed_tools.as_deref())
            .filter(|allowed| !allowed.is_empty());
        let capability_override =
            allowed_tools.map(|allowed| effective_capabilities(agent, Some(allowed)));
        self.config
            .prompt_compiler
            .compile_invocation(&SubagentInvocation {
                agent_name: &req.agent_name,
                task: &req.task,
                mode,
                transfer_policy,
                history: req
                    .parent_context
                    .as_ref()
                    .map(|context| context.messages.as_slice())
                    .unwrap_or_default(),
                history_limit: inherit_history,
                current_message: req.message.as_ref(),
                context: &context,
                capability_override: capability_override.as_ref(),
                payload: req.prompt_payload.as_ref(),
            })
    }

    #[allow(clippy::too_many_arguments)]
    async fn execute_agent_streaming(
        agent: Arc<dyn Agent>,
        compiled: CompiledSubagentInvocation,
        cancel: CancellationToken,
        mut invocation: AgentInvocationContext,
        parent: &str,
        subagent: &str,
        mode: ExecutionMode,
        start: Instant,
        execution_id: Option<String>,
        run_id: Option<String>,
        control: Option<SubagentAttemptBinding>,
        event_publisher: SubagentEventPublisher,
        first_cause: Arc<Mutex<Option<ReactError>>>,
    ) -> Result<SubagentResult> {
        let artifact_base_dir = invocation
            .working_dir
            .clone()
            .or_else(|| std::env::current_dir().ok());
        let control_turn_id = control.as_ref().map(|binding| {
            invocation
                .runtime
                .as_ref()
                .and_then(|runtime| runtime.turn_id.clone().or_else(|| runtime.run_id.clone()))
                .unwrap_or_else(|| binding.identity().execution_id.clone())
        });
        let mut messages = compiled.messages;
        let current_message = messages.pop().ok_or_else(|| {
            ReactError::Other("Subagent prompt compiler returned no invocation message".to_string())
        })?;
        invocation.history = (!messages.is_empty()).then_some(messages);
        let event_identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
        let source_observation = Arc::new(Mutex::new(None::<ReactError>));
        let source_progress = source_observation.clone();
        let source_run = event_identity
            .run_id
            .as_ref()
            .map(|value| value.as_str())
            .unwrap_or(event_identity.turn_id.as_str())
            .to_string();
        let terminal_run = source_run.clone();
        let source_execution = event_identity
            .execution_id
            .as_ref()
            .map(|value| value.as_str().to_string());
        // 当前typed消息与invocation始终完整值传递，不把Text内容当作旧入口选择依据。
        let mut raw_stream = agent
            .execute_stream_message_with_invocation_context(
                current_message,
                cancel.clone(),
                invocation,
            )
            .await?
            .inspect(move |item| {
                let mut pending = source_progress.lock().unwrap_or_else(|p| p.into_inner());
                let matches_owner = |error: &ReactError| {
                    matches!(error,
                ReactError::ExecutionNotSettled { run_id, execution_id }
                    if run_id == &source_run && execution_id == &source_execution)
                };
                if let Err(ReactError::ExecutionNotSettled {
                    run_id,
                    execution_id,
                }) = item
                    && pending.as_ref().is_none_or(matches_owner)
                {
                    *pending = Some(ReactError::ExecutionNotSettled {
                        run_id: run_id.clone(),
                        execution_id: execution_id.clone(),
                    });
                }
            })
            .fuse();
        let mut output = echo_core::agent::AgentOutputProjection::default();
        let _steering_lease = if let Some(binding) = control {
            let attachment = control_turn_id
                .ok_or_else(|| ReactError::Other("Subagent control turn id missing".to_string()))
                .and_then(|turn_id| {
                    binding
                        .attach(agent.clone(), turn_id)
                        .map_err(Self::control_react_error)
                });
            match attachment {
                Ok(lease) => Some(lease),
                Err(error) => {
                    Self::record_first_cause(&first_cause, error);
                    cancel.cancel();
                    Self::drain_source_stream(
                        &mut raw_stream,
                        &first_cause,
                        &mut output,
                        &source_observation,
                        &terminal_run,
                    )
                    .await;
                    if let Some(error) = source_observation
                        .lock()
                        .unwrap_or_else(|p| p.into_inner())
                        .take()
                    {
                        return Err(error);
                    }
                    return Err(Self::take_first_cause(&first_cause).ok_or_else(|| {
                        ReactError::Other("stream attachment cause missing".to_string())
                    })?);
                }
            }
        } else {
            None
        };
        // 同一原source读到物理EOF；不经旧terminal包装器截断/改判身份。
        let stream = raw_stream.by_ref();
        let mut prompt_tokens: usize = 0;
        let mut completion_tokens: usize = 0;
        let mut usage_stats = super::usage::LlmUsageStats::default();
        let mut pending_tool_evidence = HashMap::<String, (String, serde_json::Value)>::new();
        let mut observed_evidence = Vec::new();
        let mut observed_artifacts = Vec::new();

        while let Some(event_result) = stream.next().await {
            if let Ok(AgentEvent::ExecutionStatus(status)) = &event_result {
                if let Err(error) = Self::observe_stream_runtime_status(
                    &mut output,
                    &source_observation,
                    &terminal_run,
                    status,
                ) {
                    Self::record_first_cause(&first_cause, error);
                }
                continue;
            }
            let event_result = match event_result {
                Err(ReactError::ExecutionNotSettled { .. }) => continue,
                other => other,
            };
            if first_cause
                .lock()
                .unwrap_or_else(|p| p.into_inner())
                .is_some()
            {
                // A terminal/error observation is not the producer cleanup receipt.
                // Keep polling this original stream until its owned EOF settles.
                continue;
            }
            let event = match event_result {
                Ok(event) => event,
                Err(error) => {
                    Self::record_first_cause(&first_cause, error);
                    continue;
                }
            };
            let processed = (|| -> Result<()> {
                match event {
                    AgentEvent::AssistantMessage { block } => {
                        if let Some(delta) = output.observe_block(&block)? {
                            if delta.reasoning_started {
                                event_publisher.emit(SubagentEvent::DispatchThinkingStarted {
                                    parent: parent.to_string(),
                                    agent: subagent.to_string(),
                                    execution_id: execution_id.clone(),
                                    run_id: run_id.clone(),
                                })?;
                            }
                            if !delta.text.is_empty() {
                                let event = if delta.block.phase
                                    == echo_core::agent::AssistantPhase::Reasoning
                                {
                                    SubagentEvent::DispatchThinkingDelta {
                                        parent: parent.to_string(),
                                        agent: subagent.to_string(),
                                        content: delta.text,
                                        execution_id: execution_id.clone(),
                                        run_id: run_id.clone(),
                                    }
                                } else {
                                    SubagentEvent::DispatchTokenDelta {
                                        parent: parent.to_string(),
                                        agent: subagent.to_string(),
                                        content: delta.text,
                                        execution_id: execution_id.clone(),
                                        run_id: run_id.clone(),
                                    }
                                };
                                event_publisher.emit(event)?;
                            }
                            if delta.reasoning_finished {
                                // 用量只来自每请求LlmUsage；结束块不是第二份token统计。
                                event_publisher.emit(SubagentEvent::DispatchThinkingEnded {
                                    parent: parent.to_string(),
                                    agent: subagent.to_string(),
                                    prompt_tokens: 0,
                                    completion_tokens: 0,
                                    execution_id: execution_id.clone(),
                                    run_id: run_id.clone(),
                                })?;
                            }
                        }
                    }
                    AgentEvent::LlmUsage {
                        model,
                        prompt_tokens: pt,
                        completion_tokens: ct,
                        total_tokens: tt,
                        cached_prompt_tokens: cpt,
                        cache_creation_prompt_tokens: ccpt,
                        usage_reported,
                    } => {
                        prompt_tokens = prompt_tokens.saturating_add(pt);
                        completion_tokens = completion_tokens.saturating_add(ct);
                        usage_stats.record(&model, pt, ct, tt, cpt, ccpt, usage_reported);
                        event_publisher.emit(SubagentEvent::DispatchLlmUsage {
                            parent: parent.to_string(),
                            agent: subagent.to_string(),
                            model: model.clone(),
                            prompt_tokens: pt,
                            completion_tokens: ct,
                            total_tokens: tt,
                            cached_prompt_tokens: cpt,
                            cache_creation_prompt_tokens: ccpt,
                            usage_reported,
                            execution_id: execution_id.clone(),
                            run_id: run_id.clone(),
                        })?;
                    }
                    AgentEvent::ToolCall {
                        call_id,
                        invocation,
                    } => {
                        pending_tool_evidence.insert(
                            call_id.clone(),
                            (invocation.name.clone(), invocation.args.clone()),
                        );
                        event_publisher.emit(SubagentEvent::DispatchToolStarted {
                            parent: parent.to_string(),
                            agent: subagent.to_string(),
                            call_id,
                            invocation,
                            execution_id: execution_id.clone(),
                            run_id: run_id.clone(),
                        })?;
                    }
                    AgentEvent::ToolResult {
                        call_id,
                        name,
                        result,
                    } => {
                        let detail = result
                            .error
                            .as_deref()
                            .filter(|value| !value.is_empty())
                            .unwrap_or(&result.output);
                        let (subject, args) = pending_tool_evidence
                            .remove(&call_id)
                            .unwrap_or_else(|| (name.clone(), serde_json::Value::Null));
                        observed_evidence.push(SubagentEvidence {
                            kind: "tool_result".to_string(),
                            subject,
                            outcome: Some(if result.success {
                                "succeeded".to_string()
                            } else {
                                "failed".to_string()
                            }),
                            details: bounded_detail(detail),
                            source: SubagentEvidenceSource::Observed,
                            attributes: serde_json::json!({ "args": args }),
                        });
                        if let Some(artifact) = result.artifact.as_ref() {
                            observed_artifacts.push(SubagentArtifact {
                                path: artifact.path.to_string_lossy().to_string(),
                                kind: "tool_log".to_string(),
                                bytes: Some(artifact.artifact_bytes),
                                sha256: Some(artifact.sha256.clone()),
                                producer_execution_id: execution_id.clone(),
                                available: true,
                            });
                        }
                        event_publisher.emit(SubagentEvent::DispatchToolCompleted {
                            parent: parent.to_string(),
                            agent: subagent.to_string(),
                            call_id,
                            name,
                            result,
                            execution_id: execution_id.clone(),
                            run_id: run_id.clone(),
                        })?;
                    }
                    AgentEvent::FinalAnswer(answer) => output.confirm_answer(&answer)?,
                    AgentEvent::Cancelled => {
                        return Err(ReactError::Agent(Box::new(AgentError::Cancelled(format!(
                            "Subagent '{subagent}' cancelled"
                        )))));
                    }
                    AgentEvent::Error {
                        source,
                        message,
                        failure,
                    } => {
                        return match failure.terminal_kind {
                            AgentTerminalKind::Cancelled => {
                                Err(ReactError::Agent(Box::new(AgentError::Cancelled(message))))
                            }
                            AgentTerminalKind::TimedOut => {
                                Err(ReactError::Agent(Box::new(AgentError::Timeout(message))))
                            }
                            AgentTerminalKind::PermissionDenied => Err(ReactError::Agent(
                                Box::new(AgentError::PermissionDenied(message)),
                            )),
                            AgentTerminalKind::Failed => {
                                Err(ReactError::Other(format!("{source}: {message}")))
                            }
                        };
                    }
                    _ => {}
                }
                Ok(())
            })();
            if let Err(error) = processed {
                Self::record_first_cause(&first_cause, error);
            }
        }
        // Envelope EOF only proves terminal projection. The original stream
        // may still own a producer/finally; consume that source to its real EOF
        // and keep any cleanup failure it reports on the way out.
        Self::drain_source_stream(
            &mut raw_stream,
            &first_cause,
            &mut output,
            &source_observation,
            &terminal_run,
        )
        .await;
        if let Some(error) = source_observation
            .lock()
            .unwrap_or_else(|p| p.into_inner())
            .take()
        {
            return Err(error);
        }
        if let Some(error) = Self::take_first_cause(&first_cause) {
            return Err(error);
        }

        // 原source EOF及尾部错误均已检查，才投影当前runtime确认的最终结果。
        let answer = output.finish()?;
        let final_delta = output.take_final_presentation()?;
        let output = answer;
        if let Some(content) = final_delta {
            event_publisher.emit(SubagentEvent::DispatchTokenDelta {
                parent: parent.to_string(),
                agent: subagent.to_string(),
                content,
                execution_id: execution_id.clone(),
                run_id: run_id.clone(),
            })?;
        }
        let tokens_used = Some(prompt_tokens.saturating_add(completion_tokens));
        let usage = if usage_stats.call_count > 0 {
            // Also update tokens_used from real usage stats for consistency.
            Some(usage_stats)
        } else {
            None
        };

        let status = SubagentStatus::Completed;
        let mut result = SubagentResult {
            agent_name: subagent.to_string(),
            output,
            outcome: SubagentOutcome {
                status,
                ..SubagentOutcome::default()
            },
            duration: start.elapsed(),
            iterations: 1,
            tokens_used,
            was_truncated: false,
            mode,
            isolation_observed: ObservedIsolation::default(),
            llm_usage: usage,
        }
        .with_structured(execution_id.as_deref(), artifact_base_dir.as_deref());
        merge_observed_evidence(&mut result.outcome, observed_evidence, observed_artifacts);
        Ok(result)
    }

    // 主读取与attachment失败后的原source drain使用同一纯native事实核验。
    fn observe_stream_runtime_status(
        output: &mut echo_core::agent::AgentOutputProjection,
        observation: &Arc<Mutex<Option<ReactError>>>,
        run: &str,
        status: &echo_core::agent::ExecutionStatus,
    ) -> Result<()> {
        let new_fact = output.observe_status(status)?;
        if new_fact
            && matches!(
                status.status,
                echo_core::agent::ExecutionStatusKind::Settled
                    | echo_core::agent::ExecutionStatusKind::Failed
                    | echo_core::agent::ExecutionStatusKind::Cancelled
            )
        {
            let mut pending = observation
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner());
            if pending.as_ref().is_some_and(|error|matches!(error, ReactError::ExecutionNotSettled {run_id,execution_id:Some(execution)} if run_id==run && execution==&status.execution_id)) {
                *pending=None;
            }
            // 先解除匹配unknown，再把原生失败按观察顺序交给既有首因槽；不提前结算。
            if let Some(error) = output.terminal_failure() {
                return Err(error);
            }
        }
        Ok(())
    }

    fn record_first_cause(cause: &Arc<Mutex<Option<ReactError>>>, error: ReactError) {
        let mut cause = cause.lock().unwrap_or_else(|p| p.into_inner());
        if cause.is_none() {
            *cause = Some(error);
        }
    }

    fn take_first_cause(cause: &Arc<Mutex<Option<ReactError>>>) -> Option<ReactError> {
        cause.lock().unwrap_or_else(|p| p.into_inner()).take()
    }

    /// Consume the untouched original producer stream down to its physical EOF.
    ///
    /// The envelope projection stops at the first terminal event, but the raw
    /// stream keeps owning producer/finally cleanup after that point. Those
    /// tail items therefore decide whether the producer actually settled, and
    /// discarding their errors reported `FinalAnswer -> cleanup error -> EOF`
    /// as success.
    ///
    /// Every ordinary tail error goes through the single first-cause slot:
    /// an earlier terminal/error/cancellation keeps precedence, while a tail
    /// error that is the only failure becomes the cause. `ExecutionNotSettled`
    /// is deliberately left to `source_observation`, which owns its identity
    /// and precedence; folding it into this slot would flatten an unsettled
    /// execution receipt into an ordinary cleanup failure.
    ///
    /// Both drain sites (attachment failure and post-terminal tail) share this
    /// function so the cleanup-error contract cannot diverge between them.
    async fn drain_source_stream<S>(
        source: &mut S,
        first_cause: &Arc<Mutex<Option<ReactError>>>,
        output: &mut echo_core::agent::AgentOutputProjection,
        observation: &Arc<Mutex<Option<ReactError>>>,
        run: &str,
    ) where
        S: futures::Stream<Item = Result<AgentEvent>> + Unpin,
    {
        while let Some(item) = source.next().await {
            if let Ok(AgentEvent::ExecutionStatus(status)) = &item
                && let Err(error) =
                    Self::observe_stream_runtime_status(output, observation, run, status)
            {
                Self::record_first_cause(first_cause, error);
            }
            if let Err(error) = item
                && !matches!(error, ReactError::ExecutionNotSettled { .. })
            {
                Self::record_first_cause(first_cause, error);
            }
        }
    }

    async fn await_stream_settlement<F>(
        execution: F,
        cancel: CancellationToken,
        deadline: Option<tokio::time::Instant>,
        cause: Arc<Mutex<Option<ReactError>>>,
        cancelled: ReactError,
        timed_out: ReactError,
    ) -> Result<SubagentResult>
    where
        F: std::future::Future<Output = Result<SubagentResult>>,
    {
        if cancel.is_cancelled() {
            return Err(cancelled);
        }
        if deadline.is_some_and(|deadline| deadline <= tokio::time::Instant::now()) {
            cancel.cancel();
            return Err(timed_out);
        }
        tokio::pin!(execution);
        let error = tokio::select! {
            biased;
            result = &mut execution => return result,
            _ = cancel.cancelled() => cancelled,
            _ = async {
                match deadline {
                    Some(deadline) => tokio::time::sleep_until(deadline).await,
                    None => std::future::pending().await,
                }
            } => { cancel.cancel(); timed_out },
        };
        Self::record_first_cause(&cause, error);
        // The same future owns physical stream cleanup, including an already
        // observed error. Later cancellation cannot replace that first cause.
        let result = execution.await;
        if matches!(&result, Err(ReactError::ExecutionNotSettled { .. })) {
            return result;
        }
        match Self::take_first_cause(&cause) {
            Some(error) => Err(error),
            None => result,
        }
    }

    /// Sync mode: execute one isolated invocation and return its result.
    async fn dispatch_sync(
        &self,
        req: &DispatchRequest,
        registered: &SubagentRegistration,
        control: Option<SubagentAttemptBinding>,
        event_publisher: SubagentEventPublisher,
    ) -> Result<SubagentResult> {
        let agent_arc = registered.agent_for_dispatch().await?;

        // Per-subagent override (0 = executor default). Sync now enforces a
        // timeout too (previously it blocked the parent indefinitely) — one
        // config (AgentConfig.subagent_timeout_secs) governs all three modes.
        let timeout_secs = if registered.definition.timeout_secs > 0 {
            registered.definition.timeout_secs
        } else {
            self.config.default_timeout_secs
        };

        let start = Instant::now();
        let compiled = self.compile_invocation(
            req,
            ExecutionMode::Sync,
            registered.definition.inherit_history,
            agent_arc.as_ref(),
        );
        let execution_cancel = req.cancel.child_token();
        let event_execution_id = req
            .runtime_context
            .as_ref()
            .and_then(|ctx| ctx.execution_id.clone());
        let event_run_id = req
            .runtime_context
            .as_ref()
            .and_then(|ctx| ctx.run_id.clone());
        let mut invocation = AgentInvocationContext {
            runtime: req.runtime_context.clone(),
            working_dir: agent_arc.working_dir(),
            ..AgentInvocationContext::default()
        };
        apply_subagent_invocation_scope(
            &mut invocation,
            agent_arc.as_ref(),
            req.parent_context
                .as_ref()
                .and_then(|context| context.allowed_tools.as_deref()),
            req.parent_context
                .as_ref()
                .and_then(|context| context.tool_access),
            req.delegation_policy,
        );

        let cause = Arc::new(Mutex::new(None));
        let deadline = (timeout_secs > 0)
            .then(|| tokio::time::Instant::now() + Duration::from_secs(timeout_secs));
        let execution = Self::execute_agent_streaming(
            agent_arc,
            compiled,
            execution_cancel.clone(),
            invocation,
            &req.parent_agent,
            &req.agent_name,
            ExecutionMode::Sync,
            start,
            event_execution_id,
            event_run_id,
            control,
            event_publisher,
            cause.clone(),
        );
        Self::await_stream_settlement(
            execution,
            execution_cancel,
            deadline,
            cause,
            ReactError::Agent(Box::new(AgentError::Cancelled(format!(
                "Sync subagent '{}' cancelled",
                req.agent_name
            )))),
            ReactError::Agent(Box::new(AgentError::Timeout(format!(
                "Sync subagent '{}' timed out after {}s",
                req.agent_name, timeout_secs
            )))),
        )
        .await
    }

    /// Fork mode: acquire semaphore, spawn task, await with timeout.
    async fn dispatch_fork(
        &self,
        req: &DispatchRequest,
        registered: &SubagentRegistration,
        control: Option<SubagentAttemptBinding>,
        event_publisher: SubagentEventPublisher,
    ) -> Result<SubagentResult> {
        let timeout_secs = if registered.definition.timeout_secs > 0 {
            registered.definition.timeout_secs
        } else {
            self.config.default_timeout_secs
        };
        let deadline = (timeout_secs > 0)
            .then(|| tokio::time::Instant::now() + Duration::from_secs(timeout_secs));
        let admission = self
            .shared_admission
            .read()
            .await
            .clone()
            .unwrap_or_else(|| self.local_fork_admission.clone());
        let admission_key = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.execution_id.as_deref())
            .map(str::to_string)
            .unwrap_or_else(|| uuid::Uuid::new_v4().to_string());
        let permit = tokio::select! {
            biased;
            _ = req.cancel.cancelled() => return Err(ReactError::Agent(Box::new(AgentError::Cancelled(
                format!("Fork subagent '{}' cancelled while waiting for capacity", req.agent_name))))),
            _ = async { match deadline { Some(deadline) => tokio::time::sleep_until(deadline).await, None => std::future::pending().await } } =>
                return Err(ReactError::Agent(Box::new(AgentError::Timeout(format!("Fork subagent '{}' timed out after {}s while waiting for capacity",req.agent_name,timeout_secs))))),
            permit = admission.issue_wait(format!("subagent:{admission_key}")) => permit.map_err(|error|ReactError::Other(error.to_string()))?,
        };

        let agent_arc = tokio::select! {
            biased;
            _ = req.cancel.cancelled() => {
                return Err(ReactError::Agent(Box::new(AgentError::Cancelled(format!(
                    "Fork subagent '{}' cancelled during initialization",
                    req.agent_name
                )))));
            }
            _ = async {
                match deadline {
                    Some(deadline) => tokio::time::sleep_until(deadline).await,
                    None => std::future::pending().await,
                }
            } => {
                return Err(ReactError::Agent(Box::new(AgentError::Timeout(format!(
                    "Fork subagent '{}' timed out after {}s during initialization",
                    req.agent_name, timeout_secs
                )))));
            }
            agent = registered.agent_for_dispatch() => agent?,
        };

        let agent_name = req.agent_name.clone();
        let parent_agent = req.parent_agent.clone();
        let cancel = req.cancel.clone();
        let message = req.message.clone();
        let prompt_compiler = self.config.prompt_compiler.clone();
        let prompt_task = req.task.clone();
        let prompt_parent_context = req.parent_context.clone();
        let prompt_payload = req.prompt_payload.clone();
        let prompt_context = req.prompt_context.clone();
        let prompt_constraints = req.constraints.clone();
        let prompt_inherit_history = registered.definition.inherit_history;
        // 跨 spawn 安全的值传递: 把外部 run context 带进 spawn 块。
        // Carry run context as an invocation value. Factory-backed Fork roles
        // receive a fresh agent instance; legacy pre-built roles still use the
        // cached instance without mutating shared runtime/working_dir fields.
        let mut runtime_context = req.runtime_context.clone();
        if let Some(ctx) = runtime_context.as_mut() {
            ctx.delegation_policy = Some(req.delegation_policy);
        }
        // Extract stable identity for event payload (moved into the spawn below).
        let event_execution_id = runtime_context
            .as_ref()
            .and_then(|ctx| ctx.execution_id.clone());
        let event_run_id = runtime_context.as_ref().and_then(|ctx| ctx.run_id.clone());

        let isolation_kind = registered.definition.isolation.clone();
        let isolation_provider = isolation_kind
            .as_ref()
            .and_then(|_| self.config.isolation_provider.clone());
        if isolation_kind.is_some() && isolation_provider.is_none() {
            // Local execution still requires this guard: silently dropping a
            // requested isolation boundary can corrupt user data.
            return Err(ReactError::Other(format!(
                "Subagent '{}' requests isolation but no IsolationProvider is configured; refusing to run without isolation",
                agent_name
            )));
        }
        let runtime_run_id = runtime_context
            .as_ref()
            .and_then(|ctx| ctx.run_id.as_deref())
            .unwrap_or("<none>");
        let has_trace_sink = runtime_context
            .as_ref()
            .is_some_and(|ctx| ctx.trace_sink.is_some());
        info!(
            parent = %parent_agent,
            subagent = %agent_name,
            runtime_run_id = %runtime_run_id,
            has_runtime_context = runtime_context.is_some(),
            has_trace_sink,
            timeout_secs,
            isolation = isolation_kind.as_deref().unwrap_or("context"),
            "subagent_fork_start"
        );
        // Prefer a caller-supplied stable isolation identity so retries of one
        // logical task can reuse the same worktree/workspace while preserving
        // their distinct execution ids for events and audit records.
        let isolation_identity = runtime_context
            .as_ref()
            .and_then(|context| {
                context
                    .isolation_id
                    .as_deref()
                    .or(context.execution_id.as_deref())
                    .or(context.run_id.as_deref())
                    .or(context.turn_id.as_deref())
            })
            .map(str::to_string)
            .unwrap_or_else(|| uuid::Uuid::new_v4().as_simple().to_string());
        let isolation_label = format!("{agent_name}-{isolation_identity}");
        let execution_cancel = cancel.child_token();
        let invocation_allowed_tools = req
            .parent_context
            .as_ref()
            .and_then(|context| context.allowed_tools.clone())
            .filter(|allowed| !allowed.is_empty());
        let invocation_tool_access = req
            .parent_context
            .as_ref()
            .and_then(|context| context.tool_access);
        let invocation_target_policy = req.delegation_policy;

        let observation_run_id = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.run_id.clone())
            .unwrap_or_else(|| format!("fork-owner:{}", uuid::Uuid::new_v4()));
        let observation_execution_id = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.execution_id.clone());
        let resource_guards = runtime_context
            .as_ref()
            .map(|context| context.resource_guards.clone())
            .unwrap_or_default();
        let result = tokio::spawn(async move {
            let mut physical_owner = SubagentPhysicalResources { lease: Some(permit), isolation: None, resource_guards, uncertain: false };
            let start = Instant::now();

            // Check cancellation
            if execution_cancel.is_cancelled() {
                let mut result = SubagentResult::cancelled(
                    agent_name.clone(),
                    "Cancelled before execution",
                    ExecutionMode::Fork,
                );
                result.duration = start.elapsed();
                return Ok(result);
            }

            let mut isolation_handle: Option<super::isolation::IsolationHandle> = None;
            if let (Some(provider), Some(kind)) = (&isolation_provider, &isolation_kind) {
                let request = super::isolation::IsolationRequest {
                    kind: kind.clone(),
                    label: isolation_label,
                };
                match provider.isolate(&request) {
                    Ok(handle) => {
                        isolation_handle = Some(handle);
                    }
                    Err(error) => {
                        return Err(ReactError::Other(format!(
                            "Isolation '{}' for Fork subagent '{agent_name}' failed: {error}",
                            request.kind
                        )));
                    }
                }
            }
            let isolation_observed = isolation_handle
                .as_ref()
                .map(|handle| handle.observed.clone())
                .unwrap_or_else(|| ObservedIsolation::new("context"));
            let mut context = prompt_context.unwrap_or_default();
            if context.user_goal.is_none() {
                context.user_goal = prompt_parent_context
                    .as_ref()
                    .and_then(|parent| parent.parent_goal.clone());
            }
            if context.workspace.is_none() {
                context.workspace = isolation_handle
                    .as_ref()
                    .map(|handle| handle.path.clone())
                    .or_else(|| agent_arc.working_dir());
            }
            if context.constraints.is_empty() {
                context.constraints = prompt_constraints;
            }
            let capability_override = invocation_allowed_tools
                .as_deref()
                .map(|allowed| effective_capabilities(agent_arc.as_ref(), Some(allowed)));
            let compiled = prompt_compiler.compile_invocation(&SubagentInvocation {
                agent_name: &agent_name,
                task: &prompt_task,
                mode: ExecutionMode::Fork,
                transfer_policy: if prompt_parent_context
                    .as_ref()
                    .is_some_and(|context| !context.messages.is_empty())
                {
                    ContextTransferPolicy::InheritStructured
                } else {
                    ContextTransferPolicy::Fresh
                },
                history: prompt_parent_context
                    .as_ref()
                    .map(|context| context.messages.as_slice())
                    .unwrap_or_default(),
                history_limit: prompt_inherit_history,
                current_message: message.as_ref(),
                context: &context,
                capability_override: capability_override.as_ref(),
                payload: prompt_payload.as_ref(),
            });
            let effective_working_dir = isolation_handle
                .as_ref()
                .map(|handle| handle.path.clone())
                .or_else(|| agent_arc.working_dir());
            let mut invocation = AgentInvocationContext {
                runtime: runtime_context.clone(),
                runtime_state_id: None,
                transcript_generation_id: None,
                working_dir: effective_working_dir,
                cancel: None,
                disabled_tools: None,
                allowed_tools: None,
                tool_access: None,
                visible_tools: None,
                run_budget: None,
                history: None,
                resource_guards: Vec::new(),
                input_lifecycle: None,
            };
            apply_subagent_invocation_scope(
                &mut invocation,
                agent_arc.as_ref(),
                invocation_allowed_tools.as_deref(),
                invocation_tool_access,
                invocation_target_policy,
            );
            event_publisher.emit(SubagentEvent::DispatchIsolationObserved {
                parent: parent_agent.clone(),
                agent: agent_name.clone(),
                isolation: isolation_observed.clone(),
                execution_id: event_execution_id.clone(),
                run_id: event_run_id.clone(),
            })?;
            physical_owner.isolation = isolation_handle;
            physical_owner.uncertain = true;
            let cause = Arc::new(Mutex::new(None));
            let execution = Self::execute_agent_streaming(
                agent_arc,
                compiled,
                execution_cancel.clone(),
                invocation,
                &parent_agent,
                &agent_name,
                ExecutionMode::Fork,
                start,
                event_execution_id.clone(),
                event_run_id.clone(),
                control,
                event_publisher.clone(),
                cause.clone(),
            );
            let mut result = Self::await_stream_settlement(
                execution,
                execution_cancel,
                deadline,
                cause,
                ReactError::Agent(Box::new(AgentError::Cancelled(format!(
                    "Fork subagent '{}' cancelled",
                    agent_name
                )))),
                ReactError::Agent(Box::new(AgentError::Timeout(format!(
                    "Fork subagent '{}' timed out after {}s",
                    agent_name, timeout_secs
                )))),
            )
            .await;
            if matches!(&result, Err(ReactError::ExecutionNotSettled { .. })) { return result; }
            physical_owner.uncertain = false;
            if let Ok(subagent_result) = &mut result {
                subagent_result.isolation_observed = isolation_observed;
            }

            if let Some(handle) = physical_owner.isolation.take() {
                match (handle.finalize)() {
                    Ok(finalized) => {
                        if let Ok(mut r) = result {
                            if !finalized.summary.trim().is_empty() {
                                r.output = format!(
                                    "{}\n\n--- isolation outcome ---\n{}",
                                    r.output, finalized.summary
                                );
                            }
                            merge_observed_evidence(
                                &mut r.outcome,
                                finalized.evidence,
                                finalized.artifacts,
                            );
                            return Ok(r);
                        }
                    }
                    Err(error) => {
                        tracing::warn!(
                            subagent = %agent_name,
                            error = %error,
                            "Subagent isolation finalization failed; result preserved"
                        );
                    }
                }
            }

            result
        })
        .await
        .map_err(|error| {
            tracing::error!(error=%error, panic=error.is_panic(), cancelled=error.is_cancelled(), "Fork owner lost without physical receipt");
            ReactError::ExecutionNotSettled { run_id: observation_run_id, execution_id: observation_execution_id }
        })??;

        Ok(result)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent::subagent::SubagentDefinition;
    use crate::agent::subagent::prompt::{
        CompiledSubagentSystemPrompt, PromptDiagnostics, SubagentSystemPromptInput,
    };
    use crate::agent::subagent::registry::FnAgentFactory;
    use crate::testing::{FailingMockAgent, MockAgent};
    use echo_core::agent::{ToolInvocation, ToolInvocationRewrite};
    use echo_core::tools::{InvocationResourceGuard, ToolResult, ToolResultKind};
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

    /// 测试 producer 自己选择状态及序号；此函数只保留同一次调用的身份。
    fn source_status(
        identity: &echo_core::agent::EventIdentity,
        kind: echo_core::agent::ExecutionStatusKind,
        sequence: u64,
    ) -> AgentEvent {
        AgentEvent::ExecutionStatus(echo_core::agent::ExecutionStatus {
            adapter_generated: false,
            execution_id: identity
                .execution_id
                .as_ref()
                .map(|value| value.as_str())
                .unwrap_or(identity.turn_id.as_str())
                .to_string(),
            request_id: Some(
                identity
                    .message_id
                    .as_ref()
                    .map(|value| value.as_str())
                    .unwrap_or(identity.turn_id.as_str())
                    .to_string(),
            ),
            sequence,
            phase: echo_core::agent::AgentPhase::Thinking,
            status: kind,
            reason: None,
        })
    }

    /// Agent that blocks its stream until released and records steer input —
    /// used to exercise the default uplink sink against a live attempt.
    struct SteerableBlockingAgent {
        release: Arc<tokio::sync::Notify>,
        steered: Arc<Mutex<Vec<String>>>,
    }

    impl SteerableBlockingAgent {
        fn blocking_stream<'a>(
            release: Arc<tokio::sync::Notify>,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Box::pin(async move {
                let identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
                let source = async_stream::stream! {
                    let _invocation = invocation;
                    yield Ok(source_status(&identity, echo_core::agent::ExecutionStatusKind::Started, 0));
                    release.notified().await;
                    yield Ok(AgentEvent::FinalAnswer("released".to_string()));
                    yield Ok(source_status(&identity, echo_core::agent::ExecutionStatusKind::Settled, 1));
                };
                Ok(source.boxed())
            })
        }
    }

    impl Agent for SteerableBlockingAgent {
        fn name(&self) -> &str {
            "steerable-blocking"
        }

        fn model_name(&self) -> &str {
            "test"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            _message: Message,
            _cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Self::blocking_stream(self.release.clone(), invocation)
        }

        fn steer_input(
            &self,
            _expected_turn_id: Option<&str>,
            message: Message,
        ) -> std::result::Result<String, echo_core::agent::AgentSteerError> {
            let text = message
                .content
                .as_text()
                .filter(|text| !text.trim().is_empty())
                .ok_or(echo_core::agent::AgentSteerError::EmptyInput)?
                .to_string();
            self.steered
                .lock()
                .map_err(|_| echo_core::agent::AgentSteerError::StateUnavailable)?
                .push(text.clone());
            Ok("turn".to_string())
        }

        fn steer_input_tracked(
            &self,
            expected_turn_id: Option<&str>,
            message: Message,
        ) -> std::result::Result<
            echo_core::agent::AgentSteerReceipt,
            echo_core::agent::AgentSteerError,
        > {
            let turn_id = self.steer_input(expected_turn_id, message)?;
            let (_tx, rx) = tokio::sync::watch::channel(echo_core::agent::AgentSteerState::Drained);
            Ok(echo_core::agent::AgentSteerReceipt::new(
                uuid::Uuid::new_v4().to_string(),
                turn_id,
                rx,
            ))
        }
    }

    #[test]
    fn enrich_dispatch_context_fills_missing_lineage_and_keeps_caller_values() {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(registry, SubagentExecutorConfig::default());

        // Missing lineage → basics derived from the request.
        let mut req = DispatchRequest {
            agent_name: "explorer".to_string(),
            task: "probe".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "primary".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                run_id: Some("run-1".to_string()),
                execution_id: Some("exec-1".to_string()),
                ..Default::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        executor.enrich_dispatch_context(&mut req);
        let lineage = req
            .runtime_context
            .as_ref()
            .and_then(|context| context.subagent_lineage.clone())
            .unwrap_or_default();
        assert_eq!(lineage.agent_name.as_deref(), Some("explorer"));
        assert_eq!(lineage.parent_agent.as_deref(), Some("primary"));
        assert_eq!(lineage.agent_path.as_deref(), Some("root/explorer"));
        assert_eq!(lineage.execution_id.as_deref(), Some("exec-1"));
        assert_eq!(lineage.run_id.as_deref(), Some("run-1"));
        assert!(
            req.runtime_context
                .as_ref()
                .is_some_and(|c| c.uplink.is_some())
        );

        // Caller-stamped lineage and application uplink are preserved.
        let mut stamped = req.clone();
        let app_sink: echo_core::tools::SubagentUplinkFn = Arc::new(|_message| {
            Box::pin(async {
                echo_core::tools::SubagentUplinkReceipt {
                    accepted: true,
                    status: "app".to_string(),
                    detail: String::new(),
                }
            })
        });
        if let Some(context) = stamped.runtime_context.as_mut() {
            context.subagent_lineage = Some(echo_core::tools::SubagentLineage {
                agent_path: Some("root/implementer/sub-probe".to_string()),
                parent_execution_id: Some("parent-exec".to_string()),
                ..Default::default()
            });
            context.uplink = Some(app_sink.clone());
        }
        executor.enrich_dispatch_context(&mut stamped);
        let (preserved, kept_sink) = stamped
            .runtime_context
            .as_ref()
            .and_then(|context| {
                context
                    .subagent_lineage
                    .clone()
                    .map(|lineage| (lineage, context.uplink.clone()))
            })
            .unwrap_or_default();
        assert_eq!(
            preserved.agent_path.as_deref(),
            Some("root/implementer/sub-probe")
        );
        assert_eq!(
            preserved.parent_execution_id.as_deref(),
            Some("parent-exec")
        );
        assert!(kept_sink.is_some_and(|sink| Arc::ptr_eq(&sink, &app_sink)));
    }

    #[tokio::test]
    async fn default_uplink_sink_delivers_to_active_attempt_and_reports_missing() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();
        let release = Arc::new(tokio::sync::Notify::new());
        let steered = Arc::new(Mutex::new(Vec::new()));
        registry
            .register(
                SubagentDefinition::new("target", "Uplink target"),
                Box::new(SteerableBlockingAgent {
                    release: release.clone(),
                    steered: steered.clone(),
                }),
            )
            .await;

        let identity = SubagentAttemptIdentity::new("task-9", "exec-9", 1)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let dispatch = tokio::spawn(async move {
            executor
                .dispatch_attempt(
                    DispatchRequest {
                        agent_name: "target".to_string(),
                        task: "block until released".to_string(),
                        mode_override: Some(ExecutionMode::Sync),
                        cancel: CancellationToken::new(),
                        parent_agent: "primary".to_string(),
                        parent_context: None,
                        delegation_policy: DispatchRequest::policy_from_depth(0),
                        runtime_context: None,
                        message: None,
                        prompt_payload: None,
                        prompt_context: None,
                        constraints: Vec::new(),
                        background: false,
                    },
                    identity,
                )
                .await
        });

        // Wait for the attempt to become addressable in the shared plane.
        let mut became_active = false;
        for _ in 0..100 {
            if registry
                .control_registry()
                .active_snapshot(16)
                .iter()
                .any(|summary| summary.execution_id == "exec-9")
            {
                became_active = true;
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(20)).await;
        }
        assert!(became_active, "attempt never became active");

        let sink = default_uplink_sink(Arc::clone(&registry));
        let sender_lineage = echo_core::tools::SubagentLineage {
            agent_name: Some("target".to_string()),
            execution_id: Some("exec-9".to_string()),
            parent_agent: Some("primary".to_string()),
            parent_execution_id: Some("exec-9".to_string()),
            ..Default::default()
        };

        // Parent direction: the parent attempt is live → steered queue-only.
        let parent_receipt = sink(echo_core::tools::SubagentUplinkMessage {
            from: sender_lineage.clone(),
            target: echo_core::tools::SubagentUplinkTarget::Parent {
                kind: echo_core::tools::SubagentUplinkKind::Escalate,
                text: "plan assumption is wrong?".to_string(),
            },
        })
        .await;
        assert!(parent_receipt.accepted);
        assert_eq!(parent_receipt.status, "parent_steered");

        // Sibling direction: live attempt → delivered; unknown → reported.
        let sibling_receipt = sink(echo_core::tools::SubagentUplinkMessage {
            from: sender_lineage,
            target: echo_core::tools::SubagentUplinkTarget::Sibling {
                to: echo_core::tools::SubagentPeerAddress::ByExecutionId("exec-9".to_string()),
                text: "dependency output is ready".to_string(),
            },
        })
        .await;
        assert!(sibling_receipt.accepted);
        assert_eq!(sibling_receipt.status, "delivered_to_sibling");

        let missing_receipt =
            default_uplink_sink(Arc::clone(&registry))(echo_core::tools::SubagentUplinkMessage {
                from: echo_core::tools::SubagentLineage::default(),
                target: echo_core::tools::SubagentUplinkTarget::Sibling {
                    to: echo_core::tools::SubagentPeerAddress::ByExecutionId(
                        "exec-missing".to_string(),
                    ),
                    text: "anyone?".to_string(),
                },
            })
            .await;
        assert!(!missing_receipt.accepted);
        assert_eq!(missing_receipt.status, "sibling_not_active");

        release.notify_one();
        let settled = dispatch
            .await
            .map_err(|error| ReactError::Other(error.to_string()))??;
        assert_eq!(settled.outcome.status, SubagentStatus::Completed);
        let steered_now = steered
            .lock()
            .map(|messages| messages.clone())
            .unwrap_or_default();
        assert_eq!(steered_now.len(), 2);
        let mut observed = Vec::new();
        for _ in 0..4 {
            observed.push(
                envelopes
                    .recv()
                    .await
                    .map_err(|error| ReactError::Other(error.to_string()))?,
            );
        }
        assert_eq!(
            observed
                .iter()
                .map(|envelope| envelope.sequence)
                .collect::<Vec<_>>(),
            vec![1, 2, 3, 4]
        );
        assert!(matches!(
            observed.get(1).map(|envelope| &envelope.payload.event),
            Some(SubagentEvent::UplinkReceived { .. })
        ));
        assert!(matches!(
            observed.get(2).map(|envelope| &envelope.payload.event),
            Some(SubagentEvent::UplinkReceived { .. })
        ));
        Ok(())
    }

    struct PrefixPromptCompiler;

    impl SubagentPromptCompiler for PrefixPromptCompiler {
        fn compile_system(
            &self,
            input: &SubagentSystemPromptInput<'_>,
        ) -> CompiledSubagentSystemPrompt {
            CompiledSubagentSystemPrompt {
                system_prompt: input.role_prompt.to_string(),
                diagnostics: PromptDiagnostics::default(),
            }
        }

        fn compile_invocation(&self, input: &SubagentInvocation<'_>) -> CompiledSubagentInvocation {
            CompiledSubagentInvocation {
                messages: vec![Message::user(format!("compiled:{}", input.task))],
                diagnostics: PromptDiagnostics::default(),
            }
        }
    }

    fn readonly_test_request(target: &str, mode: ExecutionMode) -> DispatchRequest {
        DispatchRequest {
            agent_name: target.to_string(),
            task: "只读调用传递".to_string(),
            mode_override: Some(mode),
            cancel: CancellationToken::new(),
            parent_agent: "primary".to_string(),
            parent_context: Some(SubagentContext {
                tool_access: Some(echo_core::tools::ToolAccess::ReadOnly),
                ..SubagentContext::empty()
            }),
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        }
    }

    #[tokio::test]
    async fn readonly_access_only_survives_sync_fork_teammate_and_background() -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            for (background, inherited) in
                [(false, false), (false, true), (true, false), (true, true)]
            {
                let registry = Arc::new(SubagentRegistry::new());
                let agent = MockAgent::new("reader").with_response("## Summary\n只读完成");
                let mut definition = SubagentDefinition::new("reader", "只读角色");
                definition.access_mode = super::super::types::SubagentAccessMode::ReadOnly;
                registry.register(definition, Box::new(agent.clone())).await;
                let executor = SubagentExecutor::new(registry, SubagentExecutorConfig::default());
                let mut request = readonly_test_request("reader", mode.clone());
                if !inherited {
                    request.parent_context = None;
                }
                if background {
                    executor.dispatch_background(request).await?.join().await?;
                } else {
                    executor.dispatch(request).await?;
                }
                let calls = agent.invocation_contexts();
                assert_eq!(calls.len(), 1, "{mode:?}/{background}");
                let context = calls
                    .first()
                    .ok_or_else(|| ReactError::Other("readonly invocation missing".into()))?;
                assert_eq!(
                    context.tool_access,
                    Some(echo_core::tools::ToolAccess::ReadOnly)
                );
                assert!(context.allowed_tools.is_none());
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn readonly_writer_registration_is_rejected_before_factory_in_every_entry() -> Result<()>
    {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            for background in [false, true] {
                let registry = Arc::new(SubagentRegistry::new());
                let calls = Arc::new(AtomicUsize::new(0));
                let observed = Arc::clone(&calls);
                registry
                    .register_factory(
                        SubagentDefinition::new("writer", "写角色"),
                        Arc::new(super::super::registry::FnAgentFactory::new(move || {
                            let observed = Arc::clone(&observed);
                            Box::pin(async move {
                                observed.fetch_add(1, Ordering::SeqCst);
                                Ok(Box::new(MockAgent::new("writer")) as Box<dyn Agent>)
                            })
                        })),
                    )
                    .await;
                let executor = SubagentExecutor::new(registry, SubagentExecutorConfig::default());
                let request = readonly_test_request("writer", mode.clone());
                let error = if background {
                    match executor.dispatch_background(request).await {
                        Err(error) => error,
                        Ok(handle) => {
                            let _settled = handle.join().await;
                            return Err(ReactError::Other(
                                "readonly writer background was admitted".into(),
                            ));
                        }
                    }
                } else {
                    match executor.dispatch(request).await {
                        Err(error) => error,
                        Ok(_) => {
                            return Err(ReactError::Other("readonly writer was admitted".into()));
                        }
                    }
                };
                assert!(error.to_string().contains("Read-only"));
                assert_eq!(calls.load(Ordering::SeqCst), 0, "{mode:?}/{background}");
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn readonly_team_carries_access_and_checks_each_actual_member() -> Result<()> {
        for member_is_readonly in [true, false] {
            let registry = Arc::new(SubagentRegistry::new());
            let member = MockAgent::new("member").with_response("## Summary\n成员完成");
            let mut definition = SubagentDefinition::new("member", "实际成员");
            if member_is_readonly {
                definition.access_mode = super::super::types::SubagentAccessMode::ReadOnly;
            }
            registry
                .register(definition, Box::new(member.clone()))
                .await;
            let team = super::super::builder::SubagentBuilder::new("readonly-team")
                .read_only()
                .team(super::super::team::TeamSpec {
                    strategy: super::super::team::TeamStrategy::Pipeline(vec!["member".into()]),
                    manager: String::new(),
                    subagents: Vec::new(),
                    config: super::super::team::TeamConfig::default(),
                })
                .build();
            registry
                .register(team, Box::new(MockAgent::new("readonly-team")))
                .await;
            let executor = SubagentExecutor::new(registry, SubagentExecutorConfig::default());
            let mut request = readonly_test_request("readonly-team", ExecutionMode::Team);
            // 普通父的 None 不抵消 Team 自己的 ReadOnly 声明。
            request.parent_context = None;
            let result = executor.dispatch(request).await;
            if member_is_readonly {
                let result = result?;
                assert_eq!(result.outcome.status, SubagentStatus::Completed);
                let calls = member.invocation_contexts();
                let invocation = calls
                    .first()
                    .ok_or_else(|| ReactError::Other("Team dropped access-only context".into()))?;
                assert_eq!(
                    invocation.tool_access,
                    Some(echo_core::tools::ToolAccess::ReadOnly)
                );
            } else {
                let failure = match result {
                    Err(error) => error.to_string(),
                    Ok(result) => {
                        assert_ne!(result.outcome.status, SubagentStatus::Completed);
                        serde_json::to_string(&result.outcome)?
                    }
                };
                assert!(
                    failure.to_ascii_lowercase().contains("read-only"),
                    "{failure}"
                );
                assert!(member.invocation_contexts().is_empty());
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn readonly_target_bound_survives_retry_target_change_without_resetting_depth_or_scope()
    -> Result<()> {
        let registry = Arc::new(SubagentRegistry::new());
        let mut reader = SubagentDefinition::new("reader", "readonly target");
        reader.access_mode = super::super::types::SubagentAccessMode::ReadOnly;
        registry
            .register(reader, Box::new(MockAgent::new("reader")))
            .await;
        registry
            .register(
                SubagentDefinition::new("writer", "write target"),
                Box::new(MockAgent::new("writer")),
            )
            .await;
        let mut request = readonly_test_request("reader", ExecutionMode::Sync);
        request.parent_context = Some(SubagentContext {
            tool_access: Some(echo_core::tools::ToolAccess::Mutating),
            allowed_tools: Some(vec!["read_file".to_string()]),
            ..SubagentContext::empty()
        });
        let policy = NestedDelegationPolicy {
            can_spawn_subagents: true,
            delegate_depth: 2,
            max_delegate_depth: 4,
        };
        request.delegation_policy = policy;
        let reader = registry
            .resolve_registration("reader")
            .await
            .ok_or_else(|| ReactError::Other("reader registration missing".to_string()))?;
        registry.admit_registration(&reader, &mut request).await?;
        assert_eq!(request.delegation_policy, policy);
        let inherited = request
            .parent_context
            .as_ref()
            .ok_or_else(|| ReactError::Other("readonly target bound missing".to_string()))?;
        assert_eq!(
            inherited.tool_access,
            Some(echo_core::tools::ToolAccess::ReadOnly)
        );
        assert_eq!(inherited.allowed_tools, Some(vec!["read_file".to_string()]));
        request.agent_name = "writer".to_string();
        let writer = registry
            .resolve_registration("writer")
            .await
            .ok_or_else(|| ReactError::Other("writer registration missing".to_string()))?;
        assert!(
            matches!(registry.admit_registration(&writer,&mut request).await,Err(error) if error.to_string().contains("Read-only"))
        );
        assert_eq!(request.delegation_policy, policy);
        Ok(())
    }

    #[test]
    fn inherited_readonly_cannot_be_promoted_by_mutating_or_absent_child_values() {
        let agent = MockAgent::new("reader");
        let mut invocation = AgentInvocationContext {
            tool_access: Some(echo_core::tools::ToolAccess::ReadOnly),
            ..Default::default()
        };
        for inherited in [None, Some(echo_core::tools::ToolAccess::Mutating)] {
            apply_subagent_invocation_scope(
                &mut invocation,
                &agent,
                None,
                inherited,
                DispatchRequest::policy_from_depth(0),
            );
            assert_eq!(
                invocation.tool_access,
                Some(echo_core::tools::ToolAccess::ReadOnly)
            );
        }
    }

    #[test]
    fn invocation_allowlist_hides_every_unlisted_tool() {
        let agent = MockAgent::new("no-registered-tools");
        let mut invocation = AgentInvocationContext::default();
        let allowed = vec!["read_file".to_string()];
        apply_subagent_invocation_scope(
            &mut invocation,
            &agent,
            Some(&allowed),
            None,
            DispatchRequest::policy_from_depth(0),
        );
        assert_eq!(
            invocation.allowed_tools,
            Some(HashSet::from(["read_file".to_string()]))
        );
        assert_eq!(invocation.visible_tools, Some(HashSet::new()));
        apply_subagent_invocation_scope(
            &mut invocation,
            &agent,
            None,
            None,
            DispatchRequest::policy_from_depth(0),
        );
        assert!(invocation.allowed_tools.is_none());
        assert!(invocation.visible_tools.is_none());
        apply_subagent_invocation_scope(
            &mut invocation,
            &agent,
            Some(&[]),
            None,
            DispatchRequest::policy_from_depth(0),
        );
        assert!(invocation.allowed_tools.is_none());
        assert!(invocation.visible_tools.is_none());
    }

    #[tokio::test]
    async fn legacy_empty_scope_keeps_all_mode_invocations_unrestricted() -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            for allowed_tools in [None, Some(Vec::new())] {
                let registry = Arc::new(SubagentRegistry::new());
                let agent = MockAgent::new("legacy-scope").with_response("complete");
                registry
                    .register(
                        SubagentDefinition::new("legacy-scope", "legacy"),
                        Box::new(agent.clone()),
                    )
                    .await;
                let executor = SubagentExecutor::new(registry, SubagentExecutorConfig::default());
                let context = allowed_tools.map(|tools| SubagentContext {
                    allowed_tools: Some(tools),
                    ..SubagentContext::empty()
                });
                executor
                    .dispatch(DispatchRequest {
                        agent_name: "legacy-scope".into(),
                        task: "legacy independent consumer".into(),
                        mode_override: Some(mode.clone()),
                        cancel: CancellationToken::new(),
                        parent_agent: "parent".into(),
                        parent_context: context,
                        delegation_policy: DispatchRequest::policy_from_depth(0),
                        runtime_context: None,
                        message: None,
                        prompt_payload: None,
                        prompt_context: None,
                        constraints: Vec::new(),
                        background: false,
                    })
                    .await?;
                let invocations = agent.invocation_contexts();
                let invocation = invocations
                    .first()
                    .ok_or_else(|| ReactError::Other("legacy invocation missing".into()))?;
                assert!(invocation.disabled_tools.is_none());
                assert!(invocation.allowed_tools.is_none());
                assert!(invocation.visible_tools.is_none());
                let runtime = invocation
                    .runtime
                    .as_ref()
                    .ok_or_else(|| ReactError::Other("target policy runtime missing".into()))?;
                assert_eq!(
                    runtime.delegation_policy,
                    Some(DispatchRequest::policy_from_depth(0))
                );
                assert!(runtime.run_id.is_none());
                assert!(runtime.conversation_id.is_none());
            }
        }
        Ok(())
    }

    struct DelegateFailedDispatch;

    struct CancellationAwareStreamAgent {
        cancellation_seen: Arc<tokio::sync::Notify>,
    }

    struct RichToolEventAgent;

    impl Agent for RichToolEventAgent {
        fn name(&self) -> &str {
            "rich-tool-events"
        }

        fn model_name(&self) -> &str {
            "test-model"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            _message: Message,
            _cancel: CancellationToken,
            invocation_context: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Box::pin(async move {
                let identity =
                    echo_core::agent::EventIdentity::from_invocation(&invocation_context)?;
                let invocation = ToolInvocation {
                    requested_name: "requested_tool".to_string(),
                    requested_args: serde_json::json!({"value": "requested"}),
                    name: "effective_tool".to_string(),
                    args: serde_json::json!({"value": "effective"}),
                    rewrites: vec![ToolInvocationRewrite::Approval],
                };
                let result = ToolResult {
                    kind: ToolResultKind::Json,
                    success: true,
                    output: "{\"ok\":true}".to_string(),
                    error: None,
                    failure: None,
                    data: Some(serde_json::json!({"ok": true})),
                    truncated: true,
                    mime_type: Some("application/json".to_string()),
                    metadata: HashMap::from([("source".to_string(), "fixture".to_string())]),
                    artifact: None,
                    effects: Vec::new(),
                    model_content: Vec::new(),
                };
                let events = vec![
                    Ok(source_status(
                        &identity,
                        echo_core::agent::ExecutionStatusKind::Started,
                        0,
                    )),
                    Ok(AgentEvent::ToolCall {
                        call_id: "call-rich".to_string(),
                        invocation,
                    }),
                    Ok(AgentEvent::ToolResult {
                        call_id: "call-rich".to_string(),
                        name: "effective_tool".to_string(),
                        result,
                    }),
                    Ok(AgentEvent::FinalAnswer("done".to_string())),
                    Ok(source_status(
                        &identity,
                        echo_core::agent::ExecutionStatusKind::Settled,
                        1,
                    )),
                ];
                Ok(Box::pin(async_stream::stream! {
                    let _invocation = invocation_context;
                    for event in events { yield event; }
                })
                    as futures::stream::BoxStream<'a, Result<AgentEvent>>)
            })
        }
    }

    impl Agent for CancellationAwareStreamAgent {
        fn name(&self) -> &str {
            "cancellation-aware"
        }

        fn model_name(&self) -> &str {
            "test-model"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            _message: Message,
            cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            let cancellation_seen = Arc::clone(&self.cancellation_seen);
            Box::pin(async move {
                let identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
                let (sender, receiver) = tokio::sync::mpsc::channel(2);
                tokio::spawn(async move {
                    let _invocation = invocation;
                    let _ = sender
                        .send(Ok(source_status(
                            &identity,
                            echo_core::agent::ExecutionStatusKind::Started,
                            0,
                        )))
                        .await;
                    cancel.cancelled().await;
                    cancellation_seen.notify_one();
                    let _ = sender
                        .send(Ok(source_status(
                            &identity,
                            echo_core::agent::ExecutionStatusKind::Cancelled,
                            1,
                        )))
                        .await;
                    let _ = sender.send(Ok(AgentEvent::Cancelled)).await;
                });
                Ok(
                    Box::pin(tokio_stream::wrappers::ReceiverStream::new(receiver))
                        as futures::stream::BoxStream<'a, Result<AgentEvent>>,
                )
            })
        }
    }

    #[async_trait::async_trait]
    impl super::super::hooks::SubagentHooks for DelegateFailedDispatch {
        async fn on_failure(
            &self,
            _ctx: &super::super::hooks::SubagentHookContext,
            _error: &str,
        ) -> super::super::hooks::SubagentRetryDecision {
            super::super::hooks::SubagentRetryDecision::Delegate {
                alternative_agent: "recovery".to_string(),
            }
        }
    }

    async fn make_executor() -> (Arc<SubagentRegistry>, SubagentExecutor) {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(registry.clone(), SubagentExecutorConfig::default());
        (registry, executor)
    }

    struct DispatchGuardDrop(Arc<AtomicUsize>);

    impl Drop for DispatchGuardDrop {
        fn drop(&mut self) {
            self.0.fetch_add(1, Ordering::SeqCst);
        }
    }

    struct PendingDropStream {
        dropped: Arc<AtomicBool>,
        physical_eof: futures::future::BoxFuture<'static, ()>,
    }

    impl futures::Stream for PendingDropStream {
        type Item = Result<AgentEvent>;

        fn poll_next(
            self: std::pin::Pin<&mut Self>,
            context: &mut std::task::Context<'_>,
        ) -> std::task::Poll<Option<Self::Item>> {
            self.get_mut()
                .physical_eof
                .as_mut()
                .poll(context)
                .map(|()| None)
        }
    }

    impl Drop for PendingDropStream {
        fn drop(&mut self) {
            self.dropped.store(true, Ordering::SeqCst);
        }
    }

    struct NonCooperativeTeamAgent {
        dropped: Arc<AtomicBool>,
        started: Arc<tokio::sync::Notify>,
        release: Arc<tokio::sync::Notify>,
    }

    impl Agent for NonCooperativeTeamAgent {
        fn name(&self) -> &str {
            "non-cooperative-team-member"
        }

        fn model_name(&self) -> &str {
            "test"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            _message: Message,
            _cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            let dropped = Arc::clone(&self.dropped);
            let started = self.started.clone();
            let release = self.release.clone();
            Box::pin(async move {
                let identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
                started.notify_one();
                let pending = PendingDropStream {
                    dropped,
                    physical_eof: Box::pin(async move {
                        let _invocation = invocation;
                        release.notified().await
                    }),
                };
                // 原 PendingDropStream 仍拥有 physical EOF；不为非合作 source 猜成功。
                Ok(futures::stream::once(async move {
                    Ok(source_status(
                        &identity,
                        echo_core::agent::ExecutionStatusKind::Started,
                        0,
                    ))
                })
                .chain(pending)
                .boxed())
            })
        }
    }

    struct UnknownCleanupAgent {
        setup: bool,
        panic_setup: bool,
    }
    impl Agent for UnknownCleanupAgent {
        fn name(&self) -> &str {
            "unknown-cleanup"
        }
        fn model_name(&self) -> &str {
            "test"
        }
        fn system_prompt(&self) -> &str {
            ""
        }
        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            _message: Message,
            _cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Box::pin(async move {
                if self.panic_setup {
                    std::panic::resume_unwind(Box::new("original foreign producer owner lost"));
                }
                let unknown = ReactError::ExecutionNotSettled {
                    run_id: "unknown-original".to_string(),
                    execution_id: Some("unknown-attempt".to_string()),
                };
                if self.setup {
                    return Err(unknown);
                }
                let identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
                Ok(async_stream::stream! {
                    let _invocation = invocation;
                    yield Ok(source_status(&identity, echo_core::agent::ExecutionStatusKind::Started, 0));
                    yield Ok(source_status(&identity, echo_core::agent::ExecutionStatusKind::Cancelled, 1));
                    yield Ok(AgentEvent::Cancelled);
                    yield Err(unknown);
                }.boxed())
            })
        }
    }

    fn unknown_request(mode: ExecutionMode, cancel: CancellationToken) -> DispatchRequest {
        DispatchRequest {
            agent_name: "unknown-cleanup".to_string(),
            task: "original unknown producer".to_string(),
            mode_override: Some(mode),
            cancel,
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        }
    }

    #[tokio::test]
    async fn cleanup_observation_cannot_be_replaced_by_earlier_cancel_terminal_in_any_mode()
    -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            let (registry, executor) = make_executor().await;
            registry
                .register(
                    SubagentDefinition::new("unknown-cleanup", "unknown tail"),
                    Box::new(UnknownCleanupAgent {
                        setup: false,
                        panic_setup: false,
                    }),
                )
                .await;
            let result = executor
                .dispatch(unknown_request(mode, CancellationToken::new()))
                .await;
            assert!(
                matches!(result,Err(ReactError::ExecutionNotSettled{run_id,execution_id:Some(execution_id)})if run_id=="unknown-original"&&execution_id=="unknown-attempt")
            );
        }
        Ok(())
    }

    #[tokio::test]
    async fn standalone_fork_unknown_or_panic_retains_original_local_and_shared_capacity()
    -> Result<()> {
        for shared in [false, true] {
            for panic_setup in [false, true] {
                let registry = Arc::new(SubagentRegistry::new());
                registry
                    .register(
                        SubagentDefinition::new("unknown-cleanup", "unknown setup"),
                        Box::new(UnknownCleanupAgent {
                            setup: true,
                            panic_setup,
                        }),
                    )
                    .await;
                let admission = Arc::new(ExecutionAdmission::with_capacity(1));
                let executor = SubagentExecutor::new(
                    registry,
                    SubagentExecutorConfig {
                        max_concurrent_forks: 1,
                        shared_admission: shared.then(|| admission.clone()),
                        ..Default::default()
                    },
                );
                let result = executor
                    .dispatch(unknown_request(
                        ExecutionMode::Fork,
                        CancellationToken::new(),
                    ))
                    .await;
                assert!(matches!(
                    result,
                    Err(ReactError::ExecutionNotSettled { .. })
                ));
                let owner = if shared {
                    admission.clone()
                } else {
                    executor.local_fork_admission.clone()
                };
                assert_eq!(
                    owner.active_count(),
                    1,
                    "unknown Fork must keep its original admission after its call returns"
                );
                assert!(owner.issue("new-physical-attempt").is_err());
                let cancel = CancellationToken::new();
                cancel.cancel();
                let cancelled = executor
                    .dispatch(unknown_request(ExecutionMode::Fork, cancel))
                    .await?;
                assert_eq!(cancelled.outcome.status, SubagentStatus::Cancelled);
                assert_eq!(owner.active_count(), 1);
                drop(executor);
                assert_eq!(
                    owner.active_count(),
                    1,
                    "dropping an observer executor must not clear uncertainty owned by its admission"
                );
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn foreign_observation_keeps_original_invocation_guards_in_each_mode() -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            let (registry, executor) = make_executor().await;
            registry
                .register(
                    SubagentDefinition::new("unknown-cleanup", "unknown setup"),
                    Box::new(UnknownCleanupAgent {
                        setup: true,
                        panic_setup: false,
                    }),
                )
                .await;
            let drops = Arc::new(AtomicUsize::new(0));
            let mut request = unknown_request(mode, CancellationToken::new());
            let runtime = request.runtime_context.get_or_insert_with(|| {
                echo_core::tools::ExternalRunContext {
                    run_id: Some("unknown-original".to_string()),
                    execution_id: Some("unknown-attempt".to_string()),
                    ..Default::default()
                }
            });
            runtime
                .resource_guards
                .push(echo_core::tools::InvocationResourceGuard::new(
                    DispatchGuardDrop(drops.clone()),
                ));
            let result = executor.dispatch(request).await;
            assert!(matches!(
                result,
                Err(ReactError::ExecutionNotSettled { .. })
            ));
            assert_eq!(
                drops.load(Ordering::SeqCst),
                0,
                "foreign physical authority remains unknown; its original invocation guard cannot be released"
            );
        }
        Ok(())
    }

    /// Original-stream shapes whose interesting behavior lives *after* the
    /// terminal projection. `envelope_event_stream` stops at the first
    /// terminal event, so the trailing items below are only reachable through
    /// the executor's drain of the untouched raw producer stream.
    #[derive(Clone, Copy)]
    enum TailCleanupSequence {
        AnswerOnly,
        AnswerThenCleanupError,
        EarlyFailureThenCleanupError,
        AnswerThenTwoCleanupErrors,
    }

    struct TailCleanupAgent {
        sequence: TailCleanupSequence,
    }

    impl TailCleanupAgent {
        fn events(&self, identity: &echo_core::agent::EventIdentity) -> Vec<Result<AgentEvent>> {
            let started =
                source_status(identity, echo_core::agent::ExecutionStatusKind::Started, 0);
            let settled =
                source_status(identity, echo_core::agent::ExecutionStatusKind::Settled, 1);
            let mut events = match self.sequence {
                TailCleanupSequence::AnswerOnly => {
                    vec![
                        Ok(AgentEvent::FinalAnswer("done".to_string())),
                        Ok(settled.clone()),
                    ]
                }
                TailCleanupSequence::AnswerThenCleanupError => vec![
                    Ok(AgentEvent::FinalAnswer("done".to_string())),
                    Ok(settled.clone()),
                    Err(ReactError::Other("cleanup close failed".to_string())),
                ],
                TailCleanupSequence::EarlyFailureThenCleanupError => vec![
                    Ok(AgentEvent::Error {
                        source: "fixture".to_string(),
                        message: "fixture terminal failure".to_string(),
                        failure: echo_core::error::AgentFailure::message(
                            "fixture",
                            "fixture terminal failure",
                        ),
                    }),
                    Ok(source_status(
                        identity,
                        echo_core::agent::ExecutionStatusKind::Failed,
                        1,
                    )),
                    Err(ReactError::Other("cleanup close failed".to_string())),
                ],
                TailCleanupSequence::AnswerThenTwoCleanupErrors => vec![
                    Ok(AgentEvent::FinalAnswer("done".to_string())),
                    Ok(settled.clone()),
                    Err(ReactError::Other("first tail cleanup failure".to_string())),
                    Err(ReactError::Other("second tail cleanup failure".to_string())),
                ],
            };
            events.insert(0, Ok(started));
            events
        }
    }

    impl Agent for TailCleanupAgent {
        fn name(&self) -> &str {
            "tail-cleanup"
        }

        fn model_name(&self) -> &str {
            "test"
        }

        fn system_prompt(&self) -> &str {
            ""
        }

        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            _message: Message,
            _cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Box::pin(async move {
                let identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
                let events = self.events(&identity);
                Ok(Box::pin(async_stream::stream! {
                    let _invocation = invocation;
                    for event in events { yield event; }
                })
                    as futures::stream::BoxStream<'a, Result<AgentEvent>>)
            })
        }
    }

    async fn tail_cleanup_dispatch(
        mode: ExecutionMode,
        sequence: TailCleanupSequence,
    ) -> Result<SubagentResult> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("tail-cleanup", "Tail cleanup fixture"),
                Box::new(TailCleanupAgent { sequence }),
            )
            .await;
        executor
            .dispatch(DispatchRequest {
                agent_name: "tail-cleanup".to_string(),
                task: "emit a terminal projection and then tail cleanup".to_string(),
                mode_override: Some(mode),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
    }

    #[tokio::test]
    async fn final_answer_tail_cleanup_error_fails_dispatch_in_every_mode() -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            let result =
                tail_cleanup_dispatch(mode.clone(), TailCleanupSequence::AnswerThenCleanupError)
                    .await;
            let error = result.err().ok_or_else(|| {
                ReactError::Other(format!(
                    "{mode:?} reported FinalAnswer -> cleanup error -> EOF as success"
                ))
            })?;
            assert!(
                error.to_string().contains("cleanup close failed"),
                "{mode:?} lost the only tail failure cause: {error}"
            );
        }
        Ok(())
    }

    #[tokio::test]
    async fn final_answer_tail_without_error_still_completes_in_every_mode() -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            let result =
                tail_cleanup_dispatch(mode.clone(), TailCleanupSequence::AnswerOnly).await?;
            assert_eq!(result.outcome.status, SubagentStatus::Completed);
            assert_eq!(result.output, "done");
        }
        Ok(())
    }

    #[tokio::test]
    async fn earlier_terminal_failure_keeps_precedence_over_tail_cleanup_error_in_every_mode()
    -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            let result = tail_cleanup_dispatch(
                mode.clone(),
                TailCleanupSequence::EarlyFailureThenCleanupError,
            )
            .await;
            let error = result.err().ok_or_else(|| {
                ReactError::Other(format!("{mode:?} hid the earlier terminal failure"))
            })?;
            let message = error.to_string();
            assert!(
                message.contains("fixture terminal failure"),
                "{mode:?} tail cleanup replaced the earlier root cause: {error}"
            );
            assert!(
                !message.contains("cleanup close failed"),
                "{mode:?} surfaced the cleanup error instead of the earlier root cause: {error}"
            );
        }
        Ok(())
    }

    #[tokio::test]
    async fn tail_cleanup_error_precedence_keeps_the_first_cleanup_failure_in_every_mode()
    -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            let result = tail_cleanup_dispatch(
                mode.clone(),
                TailCleanupSequence::AnswerThenTwoCleanupErrors,
            )
            .await;
            let error = result.err().ok_or_else(|| {
                ReactError::Other(format!(
                    "{mode:?} reported two tail cleanup errors as success"
                ))
            })?;
            let message = error.to_string();
            assert!(
                message.contains("first tail cleanup failure"),
                "{mode:?} did not keep the first tail cleanup cause: {error}"
            );
            assert!(
                !message.contains("second tail cleanup failure"),
                "{mode:?} let a later tail error replace the first: {error}"
            );
        }
        Ok(())
    }

    struct LiveObservationAgent {
        barrier: Arc<StreamSettlementBarrier>,
        release_terminal: Arc<tokio::sync::Notify>,
        terminal_seen: Arc<tokio::sync::Notify>,
        cancelled_seen: Arc<tokio::sync::Notify>,
        effect: std::path::PathBuf,
        cancelled: bool,
        executions: Arc<AtomicUsize>,
    }

    impl Agent for LiveObservationAgent {
        fn name(&self) -> &str {
            "live-observation"
        }
        fn model_name(&self) -> &str {
            "fixture"
        }
        fn system_prompt(&self) -> &str {
            ""
        }
        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            _message: Message,
            cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            Box::pin(async move {
                let identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
                let run_id = identity
                    .run_id
                    .as_ref()
                    .map(|value| value.as_str())
                    .unwrap_or(identity.turn_id.as_str())
                    .to_string();
                let execution_id = identity
                    .execution_id
                    .as_ref()
                    .map(|value| value.as_str().to_string());
                self.executions.fetch_add(1, Ordering::SeqCst);
                let source = async_stream::stream! {
                    let _invocation = invocation;
                    yield Ok(source_status(&identity, echo_core::agent::ExecutionStatusKind::Started, 0));
                    if let Err(error) = tokio::fs::write(&self.effect, b"same-source-entered").await {
                        yield Err(ReactError::Other(error.to_string())); return;
                    }
                    yield Err(ReactError::ExecutionNotSettled { run_id, execution_id });
                    self.barrier.started.notify_one();
                    if self.cancelled {
                        cancel.cancelled().await;
                        self.cancelled_seen.notify_one();
                    }
                    self.release_terminal.notified().await;
                    yield Ok(AgentEvent::FinalAnswer("same source completed".to_string()));
                    yield Ok(source_status(&identity, echo_core::agent::ExecutionStatusKind::Settled, 1));
                    self.terminal_seen.notify_one();
                    self.barrier.release_cleanup.notified().await;
                    if let Err(error) = tokio::fs::write(&self.effect, b"same-source-closed").await {
                        yield Err(ReactError::Other(error.to_string())); return;
                    }
                    self.barrier.physical_stopped.store(true, Ordering::SeqCst);
                };
                Ok(source.boxed())
            })
        }
    }

    #[tokio::test]
    async fn matching_live_source_closes_the_original_team_claim_after_observation() -> Result<()> {
        for cancelled in [false, true] {
            let (registry, executor) = make_executor().await;
            let executor = Arc::new(executor);
            let barrier = Arc::new(StreamSettlementBarrier::default());
            let terminal_seen = Arc::new(tokio::sync::Notify::new());
            let cancelled_seen = Arc::new(tokio::sync::Notify::new());
            let release_terminal = Arc::new(tokio::sync::Notify::new());
            let directory = tempfile::tempdir()?;
            let effect = directory.path().join("same-source.txt");
            let executions = Arc::new(AtomicUsize::new(0));
            registry
                .register(
                    SubagentDefinition::new("live-observation", "original live source"),
                    Box::new(LiveObservationAgent {
                        barrier: barrier.clone(),
                        release_terminal: release_terminal.clone(),
                        terminal_seen: terminal_seen.clone(),
                        cancelled_seen: cancelled_seen.clone(),
                        effect: effect.clone(),
                        cancelled,
                        executions: executions.clone(),
                    }),
                )
                .await;
            let definition = super::super::builder::SubagentBuilder::new("live-team")
                .team(super::super::team::TeamSpec {
                    strategy: super::super::team::TeamStrategy::Pipeline(vec![
                        "live-observation".to_string(),
                    ]),
                    manager: String::new(),
                    subagents: Vec::new(),
                    config: super::super::team::TeamConfig::default(),
                })
                .build();
            registry
                .register(definition, Box::new(MockAgent::new("live-team")))
                .await;
            let drops = Arc::new(AtomicUsize::new(0));
            let mut request = unknown_request(ExecutionMode::Team, CancellationToken::new());
            request.agent_name = "live-team".to_string();
            request.mode_override = None;
            request.runtime_context = Some(echo_core::tools::ExternalRunContext {
                run_id: Some("live-team-run".to_string()),
                resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
                    DispatchGuardDrop(drops.clone()),
                )],
                ..Default::default()
            });
            let runner = executor.clone();
            let mut dispatch = tokio::spawn(async move { runner.dispatch(request).await });
            let entered =
                tokio::time::timeout(Duration::from_secs(2), barrier.started.notified()).await;
            let runtime = executor
                .team_runtime_handles("live-team-run")
                .first()
                .cloned()
                .ok_or_else(|| ReactError::Other("same Team runtime missing".to_string()))?;
            let task = runtime
                .snapshot()
                .await?
                .tasks
                .into_iter()
                .find(|task| task.execution.claim.is_some())
                .ok_or_else(|| ReactError::Other("same Team claim missing".to_string()))?;
            let claim = task
                .execution
                .claim
                .clone()
                .ok_or_else(|| ReactError::Other("claim missing".to_string()))?;
            let held =
                !dispatch.is_finished() && runtime.is_active() && drops.load(Ordering::SeqCst) == 0;
            let held_effect = tokio::fs::read(&effect).await;
            if cancelled {
                runtime
                    .request_attempt_interrupt(&task.spec.id, &claim)
                    .await
                    .map_err(|error| ReactError::Other(error.to_string()))?;
            }
            let cancel_seen = if cancelled {
                tokio::time::timeout(Duration::from_secs(2), cancelled_seen.notified())
                    .await
                    .is_ok()
            } else {
                true
            };
            release_terminal.notify_one();
            let terminal =
                tokio::time::timeout(Duration::from_secs(2), terminal_seen.notified()).await;
            let held_terminal =
                !dispatch.is_finished() && runtime.is_active() && drops.load(Ordering::SeqCst) == 0;
            let snapshot = runtime.snapshot().await?;
            let same_claim = snapshot
                .tasks
                .iter()
                .find(|item| item.spec.id == task.spec.id)
                .is_some_and(|item| {
                    item.execution.claim.as_ref() == Some(&claim)
                        && item.execution.status == crate::tasks::TaskStatus::Running
                });
            // Release and join the original invocation before every assertion.
            barrier.release_cleanup.notify_one();
            let result = tokio::time::timeout(Duration::from_secs(2), &mut dispatch)
                .await
                .map_err(|_| ReactError::Other("same Team owner did not join".to_string()))?
                .map_err(|error| ReactError::Other(error.to_string()))?;
            let after = runtime.snapshot().await?;
            let final_task = after
                .tasks
                .iter()
                .find(|item| item.spec.id == task.spec.id)
                .ok_or_else(|| ReactError::Other("settled same Team task missing".to_string()))?;
            assert!(entered.is_ok() && cancel_seen && terminal.is_ok());
            assert!(held && held_terminal && same_claim);
            assert_eq!(held_effect?, b"same-source-entered");
            assert_eq!(tokio::fs::read(&effect).await?, b"same-source-closed");
            assert!(barrier.physical_stopped.load(Ordering::SeqCst));
            assert_eq!(executions.load(Ordering::SeqCst), 1);
            assert!(final_task.execution.claim.is_none());
            assert_eq!(
                final_task.execution.status,
                if cancelled {
                    crate::tasks::TaskStatus::Cancelled
                } else {
                    crate::tasks::TaskStatus::Completed
                }
            );
            assert!(!runtime.is_active());
            if cancelled {
                assert!(
                    matches!(result, Err(ReactError::Agent(error)) if matches!(*error, AgentError::Cancelled(_)))
                );
            } else {
                assert_eq!(result?.outcome.status, SubagentStatus::Completed);
            }
        }
        Ok(())
    }

    #[derive(Clone, Copy)]
    enum HeldStreamFailure {
        Cancellation,
        CancelledEvent,
        RawError,
        ErrorEvent,
    }

    #[derive(Default)]
    struct StreamSettlementBarrier {
        started: tokio::sync::Notify,
        cleanup_entered: tokio::sync::Notify,
        collector_waiting_eof: tokio::sync::Notify,
        release_cleanup: tokio::sync::Notify,
        physical_stopped: AtomicBool,
    }

    struct HeldCleanupStreamAgent {
        barrier: Arc<StreamSettlementBarrier>,
        failure: HeldStreamFailure,
    }

    impl Agent for HeldCleanupStreamAgent {
        fn name(&self) -> &str {
            "held-cleanup"
        }
        fn model_name(&self) -> &str {
            "fixture"
        }
        fn system_prompt(&self) -> &str {
            ""
        }
        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            _message: Message,
            cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> futures::future::BoxFuture<
            'a,
            Result<futures::stream::BoxStream<'a, Result<AgentEvent>>>,
        > {
            let barrier = self.barrier.clone();
            let failure = self.failure;
            let self_barrier = barrier.clone();
            Box::pin(async move {
                let identity = echo_core::agent::EventIdentity::from_invocation(&invocation)?;
                let started =
                    source_status(&identity, echo_core::agent::ExecutionStatusKind::Started, 0);
                let (sender, receiver) = tokio::sync::mpsc::channel(2);
                tokio::spawn(async move {
                    let _invocation = invocation;
                    barrier.started.notify_one();
                    let item = match failure {
                        HeldStreamFailure::Cancellation => {
                            cancel.cancelled().await;
                            Ok(AgentEvent::Cancelled)
                        }
                        HeldStreamFailure::CancelledEvent => Ok(AgentEvent::Cancelled),
                        HeldStreamFailure::RawError => {
                            Err(ReactError::Other("original raw stream failure".to_string()))
                        }
                        HeldStreamFailure::ErrorEvent => {
                            let error = ReactError::Other("original event failure".to_string());
                            Ok(AgentEvent::Error {
                                source: "fixture".to_string(),
                                message: error.to_string(),
                                failure: echo_core::error::AgentFailure::message(
                                    "other",
                                    error.to_string(),
                                ),
                            })
                        }
                    };
                    let _ = sender.send(item).await;
                    // 保留原 Err/Error/Cancelled 的观察顺序和首因，独立声明 source 终态。
                    let terminal = match failure {
                        HeldStreamFailure::Cancellation | HeldStreamFailure::CancelledEvent => {
                            echo_core::agent::ExecutionStatusKind::Cancelled
                        }
                        HeldStreamFailure::RawError | HeldStreamFailure::ErrorEvent => {
                            echo_core::agent::ExecutionStatusKind::Failed
                        }
                    };
                    let _ = sender.send(Ok(source_status(&identity, terminal, 1))).await;
                    barrier.cleanup_entered.notify_one();
                    barrier.release_cleanup.notified().await;
                    barrier.physical_stopped.store(true, Ordering::SeqCst);
                    drop(sender);
                });
                let observed = self_barrier;
                Ok(futures::stream::once(async move { Ok(started) })
                    .chain(futures::stream::unfold(
                        (receiver, false),
                        move |(mut receiver, seen)| {
                            let observed = observed.clone();
                            async move {
                                if seen {
                                    observed.collector_waiting_eof.notify_one();
                                }
                                receiver.recv().await.map(|item| (item, (receiver, true)))
                            }
                        },
                    ))
                    .boxed())
            })
        }
    }

    async fn held_cleanup_dispatch(
        mode: ExecutionMode,
        timed_out: bool,
        failure: HeldStreamFailure,
    ) -> Result<(
        Arc<StreamSettlementBarrier>,
        CancellationToken,
        tokio::task::JoinHandle<Result<SubagentResult>>,
    )> {
        let (registry, executor) = make_executor().await;
        let barrier = Arc::new(StreamSettlementBarrier::default());
        let mut definition = SubagentDefinition::new("held-cleanup", "Held cleanup fixture");
        definition.execution_mode = mode.clone();
        definition.timeout_secs = if timed_out { 1 } else { 30 };
        registry
            .register(
                definition,
                Box::new(HeldCleanupStreamAgent {
                    barrier: barrier.clone(),
                    failure,
                }),
            )
            .await;
        let cancel = CancellationToken::new();
        let request = DispatchRequest {
            agent_name: "held-cleanup".to_string(),
            task: "wait for original producer cleanup".to_string(),
            mode_override: Some(mode),
            cancel: cancel.clone(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let dispatch = tokio::spawn(async move { executor.dispatch(request).await });
        tokio::time::timeout(Duration::from_secs(5), barrier.started.notified())
            .await
            .map_err(|_| ReactError::Other("held-cleanup fixture did not start".to_string()))?;
        Ok((barrier, cancel, dispatch))
    }

    async fn assert_dispatch_waits_for_held_cleanup(
        mode: ExecutionMode,
        timed_out: bool,
        failure: HeldStreamFailure,
    ) -> Result<()> {
        let expected = if timed_out {
            SubagentStatus::TimedOut
        } else {
            match failure {
                HeldStreamFailure::Cancellation | HeldStreamFailure::CancelledEvent => {
                    SubagentStatus::Cancelled
                }
                HeldStreamFailure::RawError | HeldStreamFailure::ErrorEvent => {
                    SubagentStatus::Failed
                }
            }
        };
        let (barrier, cancel, mut dispatch) =
            held_cleanup_dispatch(mode.clone(), timed_out, failure).await?;
        if !timed_out && matches!(failure, HeldStreamFailure::Cancellation) {
            cancel.cancel();
        }
        tokio::time::timeout(Duration::from_secs(5), barrier.cleanup_entered.notified())
            .await
            .map_err(|_| {
                ReactError::Other("original stream did not enter held cleanup".to_string())
            })?;
        let early = tokio::time::timeout(Duration::from_millis(50), &mut dispatch)
            .await
            .ok();
        let stopped_early = barrier.physical_stopped.load(Ordering::SeqCst);
        barrier.release_cleanup.notify_one();
        let returned_early = early.is_some();
        let result = match early {
            Some(result) => result,
            None => tokio::time::timeout(Duration::from_secs(5), dispatch)
                .await
                .map_err(|_| {
                    ReactError::Other("dispatch did not settle after producer release".to_string())
                })?,
        }
        .map_err(|error| {
            ReactError::Other(format!("held cleanup dispatch join failed: {error}"))
        })?;
        if returned_early || stopped_early {
            return Err(ReactError::Other(format!(
                "{mode:?} returned before held stream cleanup completed"
            )));
        }
        if !barrier.physical_stopped.load(Ordering::SeqCst) {
            return Err(ReactError::Other(
                "dispatch settled without original producer EOF".to_string(),
            ));
        }
        let error = result.err().ok_or_else(|| {
            ReactError::Other("held-failure dispatch fabricated success".to_string())
        })?;
        if subagent_status_from_error(&error)? != expected {
            return Err(ReactError::Other(format!(
                "original {expected:?} cause changed: {error}"
            )));
        }
        if matches!(failure, HeldStreamFailure::RawError)
            && !error.to_string().contains("original raw stream failure")
        {
            return Err(ReactError::Other("original raw cause lost".to_string()));
        }
        if matches!(failure, HeldStreamFailure::ErrorEvent)
            && !error.to_string().contains("original event failure")
        {
            return Err(ReactError::Other("original event cause lost".to_string()));
        }
        Ok(())
    }

    #[tokio::test]
    async fn sync_cancel_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Sync,
            false,
            HeldStreamFailure::Cancellation,
        )
        .await
    }
    #[tokio::test]
    async fn fork_cancel_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Fork,
            false,
            HeldStreamFailure::Cancellation,
        )
        .await
    }
    #[tokio::test]
    async fn teammate_cancel_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Teammate,
            false,
            HeldStreamFailure::Cancellation,
        )
        .await
    }
    #[tokio::test]
    async fn sync_timeout_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Sync,
            true,
            HeldStreamFailure::Cancellation,
        )
        .await
    }
    #[tokio::test]
    async fn fork_timeout_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Fork,
            true,
            HeldStreamFailure::Cancellation,
        )
        .await
    }
    #[tokio::test]
    async fn teammate_timeout_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Teammate,
            true,
            HeldStreamFailure::Cancellation,
        )
        .await
    }
    #[tokio::test]
    async fn cancelled_event_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Sync,
            false,
            HeldStreamFailure::CancelledEvent,
        )
        .await
    }
    #[tokio::test]
    async fn raw_error_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Sync,
            false,
            HeldStreamFailure::RawError,
        )
        .await
    }
    #[tokio::test]
    async fn error_event_waits_for_original_stream_cleanup() -> Result<()> {
        assert_dispatch_waits_for_held_cleanup(
            ExecutionMode::Sync,
            false,
            HeldStreamFailure::ErrorEvent,
        )
        .await
    }

    async fn assert_failure_precedes_late_cancellation(failure: HeldStreamFailure) -> Result<()> {
        let (barrier, cancel, dispatch) =
            held_cleanup_dispatch(ExecutionMode::Sync, false, failure).await?;
        tokio::time::timeout(Duration::from_secs(5), barrier.cleanup_entered.notified())
            .await
            .map_err(|_| ReactError::Other("failure producer did not reach cleanup".to_string()))?;
        tokio::time::timeout(
            Duration::from_secs(5),
            barrier.collector_waiting_eof.notified(),
        )
        .await
        .map_err(|_| {
            ReactError::Other(
                "collector did not observe original failure before held EOF".to_string(),
            )
        })?;
        cancel.cancel();
        barrier.release_cleanup.notify_one();
        let error = dispatch
            .await
            .map_err(|error| ReactError::Other(format!("failure dispatch join: {error}")))?
            .err()
            .ok_or_else(|| ReactError::Other("failure became success".to_string()))?;
        if subagent_status_from_error(&error)? != SubagentStatus::Failed {
            return Err(ReactError::Other(format!(
                "late cancellation replaced original failure: {error}"
            )));
        }
        let expected = match failure {
            HeldStreamFailure::RawError => "original raw stream failure",
            HeldStreamFailure::ErrorEvent => "original event failure",
            _ => {
                return Err(ReactError::Other(
                    "invalid failure precedence fixture".to_string(),
                ));
            }
        };
        if !error.to_string().contains(expected) || !barrier.physical_stopped.load(Ordering::SeqCst)
        {
            return Err(ReactError::Other(format!(
                "original cause or cleanup receipt lost: {error}"
            )));
        }
        Ok(())
    }

    #[tokio::test]
    async fn raw_failure_retains_first_cause_after_late_cancellation() -> Result<()> {
        assert_failure_precedes_late_cancellation(HeldStreamFailure::RawError).await
    }
    #[tokio::test]
    async fn event_failure_retains_first_cause_after_late_cancellation() -> Result<()> {
        assert_failure_precedes_late_cancellation(HeldStreamFailure::ErrorEvent).await
    }

    type TeamToolPhysicalJoin = futures::future::Shared<
        futures::future::BoxFuture<'static, std::result::Result<(), String>>,
    >;

    struct TeamPhysicalCleanupTool {
        parallel: bool,
        owns_timeout: bool,
        barrier: Arc<StreamSettlementBarrier>,
        effect: std::path::PathBuf,
        producer: Arc<Mutex<Option<TeamToolPhysicalJoin>>>,
    }

    impl echo_core::tools::Tool for TeamPhysicalCleanupTool {
        fn name(&self) -> &str {
            "team_physical_cleanup"
        }
        fn description(&self) -> &str {
            "retains original file producer through cleanup"
        }
        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type":"object"})
        }
        fn allows_parallel_batch_execution(&self) -> bool {
            self.parallel
        }
        // Isolate the real outer batch deadline from the per-tool deadline.
        // The tool remains subject to the unchanged batch timeout budget.
        fn manages_own_timeout(&self) -> bool {
            self.owns_timeout
        }
        fn execute_with_context<'a>(
            &'a self,
            _params: echo_core::tools::ToolParameters,
            ctx: &'a echo_core::tools::ToolContext,
        ) -> futures::future::BoxFuture<'a, Result<ToolResult>> {
            use futures::FutureExt;
            Box::pin(async move {
                let cancel = ctx.cancel.clone().ok_or_else(|| {
                    ReactError::Other("physical Tool cancellation scope missing".to_string())
                })?;
                let barrier = self.barrier.clone();
                let effect = self.effect.clone();
                let resources = ctx.resource_guards.clone();
                let producer = tokio::spawn(async move {
                    let _resources = resources;
                    tokio::fs::write(&effect, b"original-producer-entered")
                        .await
                        .map_err(|error| error.to_string())?;
                    barrier.started.notify_one();
                    cancel.cancelled().await;
                    barrier.cleanup_entered.notify_one();
                    barrier.release_cleanup.notified().await;
                    tokio::fs::write(&effect, b"original-producer-closed")
                        .await
                        .map_err(|error| error.to_string())?;
                    barrier.physical_stopped.store(true, Ordering::SeqCst);
                    Ok::<(), String>(())
                });
                let joined = async move { producer.await.map_err(|error| error.to_string())? }
                    .boxed()
                    .shared();
                *self
                    .producer
                    .lock()
                    .unwrap_or_else(|error| error.into_inner()) = Some(joined.clone());
                joined.await.map_err(ReactError::Other)?;
                Ok(ToolResult::success("original physical cleanup joined"))
            })
        }
    }

    #[tokio::test]
    async fn default_exact_grace_retains_original_team_claim_until_physical_cleanup() -> Result<()>
    {
        assert_team_claim_waits_for_physical_cleanup(None, false).await
    }

    #[tokio::test]
    async fn real_react_sequential_tool_exact_grace_retains_same_team_claim() -> Result<()> {
        assert_team_claim_waits_for_physical_cleanup(Some(false), false).await
    }

    #[tokio::test]
    async fn real_react_concurrent_tool_exact_grace_retains_same_team_claim() -> Result<()> {
        assert_team_claim_waits_for_physical_cleanup(Some(true), false).await
    }

    #[tokio::test]
    async fn real_react_batch_timeout_retains_same_team_claim_until_original_tool_join()
    -> Result<()> {
        assert_team_claim_waits_for_physical_cleanup(Some(true), true).await
    }

    async fn assert_team_claim_waits_for_physical_cleanup(
        tool_parallel: Option<bool>,
        batch_timeout: bool,
    ) -> Result<()> {
        let (registry, executor) = make_executor().await;
        let executor = Arc::new(executor);
        let barrier = Arc::new(StreamSettlementBarrier::default());
        let producer = Arc::new(Mutex::new(None::<TeamToolPhysicalJoin>));
        let effect_directory = if tool_parallel.is_some() {
            Some(tempfile::tempdir()?)
        } else {
            None
        };
        let effect = effect_directory
            .as_ref()
            .map(|directory| directory.path().join("original-effect.txt"));
        let tool_config = crate::tools::ToolExecutionConfig {
            timeout_ms: if batch_timeout { 20 } else { 0 },
            retry_on_fail: false,
            max_retries: 0,
            retry_delay_ms: 0,
            max_concurrency: Some(1),
            max_read_concurrency: None,
        };
        let batch_budget = crate::agent::react::run::retry::compute_concurrent_tool_batch_timeout(
            &tool_config,
            1,
            Some(1),
        );
        let physical_llm = if let Some(parallel) = tool_parallel {
            let llm = Arc::new(
                crate::testing::MockLlmClient::new()
                    .then_tool_call("physical-team-call", "team_physical_cleanup", "{}")
                    .with_response("must not continue before physical cleanup"),
            );
            let physical_agent = crate::agent::ReactAgentBuilder::new()
                .llm_client(llm.clone())
                .system_prompt("Execute the requested tool.")
                .tool_execution(tool_config)
                .tool(Box::new(TeamPhysicalCleanupTool {
                    parallel,
                    owns_timeout: batch_timeout,
                    barrier: barrier.clone(),
                    effect: effect.clone().ok_or_else(|| {
                        ReactError::Other("physical effect path missing".to_string())
                    })?,
                    producer: producer.clone(),
                }))
                .build()?;
            registry
                .register(
                    SubagentDefinition::new("held-cleanup", "Actual React Tool producer"),
                    Box::new(physical_agent),
                )
                .await;
            Some(llm)
        } else {
            registry
                .register(
                    SubagentDefinition::new("held-cleanup", "Held producer"),
                    Box::new(HeldCleanupStreamAgent {
                        barrier: barrier.clone(),
                        failure: HeldStreamFailure::Cancellation,
                    }),
                )
                .await;
            None
        };
        let definition = super::super::builder::SubagentBuilder::new("grace-team")
            .team(super::super::team::TeamSpec {
                strategy: super::super::team::TeamStrategy::Pipeline(vec![
                    "held-cleanup".to_string(),
                ]),
                manager: String::new(),
                subagents: Vec::new(),
                config: super::super::team::TeamConfig::default(),
            })
            .build();
        registry
            .register(definition, Box::new(MockAgent::new("grace-team")))
            .await;
        let request = DispatchRequest {
            agent_name: "grace-team".to_string(),
            task: "held cleanup".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                run_id: Some("grace-probe-run".to_string()),
                ..Default::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let runner = executor.clone();
        let dispatch = tokio::spawn(async move { runner.dispatch(request).await });
        tokio::time::timeout(Duration::from_secs(5), barrier.started.notified())
            .await
            .map_err(|_| ReactError::Other("grace probe producer did not start".to_string()))?;
        let runtime = executor
            .team_runtime_handles("grace-probe-run")
            .first()
            .cloned()
            .ok_or_else(|| ReactError::Other("grace probe original runtime missing".to_string()))?;
        let task = runtime
            .snapshot()
            .await?
            .tasks
            .into_iter()
            .find(|task| task.execution.claim.is_some())
            .ok_or_else(|| ReactError::Other("grace probe claim missing".to_string()))?;
        let claim = task
            .execution
            .claim
            .clone()
            .ok_or_else(|| ReactError::Other("grace probe missing exact claim".to_string()))?;
        if !batch_timeout {
            runtime
                .request_attempt_interrupt(&task.spec.id, &claim)
                .await
                .map_err(|error| ReactError::Other(error.to_string()))?;
        } else {
            // Original single-wave budget: configured 20ms + existing 250ms.
            assert_eq!(batch_budget, Some(Duration::from_millis(270)));
        }
        tokio::time::timeout(Duration::from_secs(5), barrier.cleanup_entered.notified())
            .await
            .map_err(|_| {
                ReactError::Other("grace producer did not receive cancellation".to_string())
            })?;
        let mut dispatch = dispatch;
        let grace = crate::tasks::RuntimeTaskServiceConfig::default().cancellation_grace_period;
        let observation_window = if batch_timeout {
            batch_budget
                .ok_or_else(|| ReactError::Other("original batch budget missing".to_string()))?
        } else {
            grace
        };
        let early = tokio::time::timeout(
            observation_window + Duration::from_millis(100),
            &mut dispatch,
        )
        .await;
        let snapshot = runtime.snapshot().await?;
        let after = snapshot
            .tasks
            .iter()
            .find(|item| item.spec.id == task.spec.id)
            .ok_or_else(|| ReactError::Other("grace probe task vanished".to_string()))?;
        let actual_claim_retained = after.execution.claim.as_ref() == Some(&claim)
            && after.execution.status == crate::tasks::TaskStatus::Running;
        let active_while_held = runtime.is_active();
        let effect_while_held = match effect.as_ref() {
            Some(effect) => Some(tokio::fs::read(effect).await),
            None => None,
        };
        let stopped = barrier.physical_stopped.load(Ordering::SeqCst);
        let request_retained = after.execution.interruption_requested
            == if batch_timeout {
                None
            } else {
                Some(crate::tasks::RuntimeInterruptionDisposition::Cancelled)
            };
        // Release and observe the same original owner before asserting, so a
        // red counterexample cannot leave its real producer behind.
        barrier.release_cleanup.notify_one();
        let original_join = producer
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .clone();
        let physical_join = match original_join {
            Some(joined) => Some(tokio::time::timeout(Duration::from_secs(2), joined).await),
            None => None,
        };
        let closed_effect = match effect.as_ref() {
            Some(effect) => Some(tokio::fs::read(effect).await),
            None => None,
        };
        let returned_early = early.is_ok();
        let result = match early {
            Ok(joined) => joined,
            Err(_) => tokio::time::timeout(Duration::from_secs(2), dispatch)
                .await
                .map_err(|_| {
                    ReactError::Other("original Team owner did not settle after EOF".to_string())
                })?,
        }
        .map_err(|error| ReactError::Other(error.to_string()))?;
        if let Some(joined) = physical_join {
            joined
                .map_err(|_| {
                    ReactError::Other("released original Tool producer did not join".to_string())
                })?
                .map_err(ReactError::Other)?;
        }
        assert!(
            !returned_early,
            "Team returned while original physical cleanup remained held"
        );
        assert!(
            active_while_held,
            "original Team execution guard must remain active"
        );
        if let Some(content) = effect_while_held {
            assert_eq!(content?, b"original-producer-entered");
        }
        if let Some(content) = closed_effect {
            assert_eq!(content?, b"original-producer-closed");
        }
        if let Some(llm) = physical_llm {
            assert_eq!(llm.call_count(), 1);
        }
        assert!(
            actual_claim_retained && request_retained,
            "default grace cannot erase claim/interruption before physical EOF"
        );
        assert!(
            !stopped,
            "default grace cannot abort the original held producer"
        );
        assert!(barrier.physical_stopped.load(Ordering::SeqCst));
        let error = result
            .err()
            .ok_or_else(|| ReactError::Other("interrupted Team fabricated success".to_string()))?;
        assert_eq!(
            subagent_status_from_error(&error)?,
            if batch_timeout {
                SubagentStatus::Failed
            } else {
                SubagentStatus::Cancelled
            }
        );
        if batch_timeout {
            assert!(error.to_string().contains("batch timeout"));
        }
        let final_snapshot = runtime.snapshot().await?;
        let final_task = final_snapshot
            .tasks
            .iter()
            .find(|item| item.spec.id == task.spec.id)
            .ok_or_else(|| ReactError::Other("original Task missing".to_string()))?;
        assert!(final_task.execution.claim.is_none());
        if batch_timeout {
            assert!(
                matches!(&final_task.execution.status, crate::tasks::TaskStatus::TimedOut { error }
                if error.contains("batch timeout")),
                "original batch terminal status: {:?}",
                final_task.execution.status
            );
        } else {
            assert_eq!(
                final_task.execution.status,
                crate::tasks::TaskStatus::Cancelled
            );
        }
        // Execution CAS keeps the relation revision unchanged. This is the
        // original claim's terminal disposition, never a replacement attempt.
        assert_eq!(snapshot.revision, final_snapshot.revision);
        assert_eq!(final_task.execution.retry_count, task.execution.retry_count);
        assert!(!runtime.is_active());
        assert!(matches!(
            runtime
                .request_attempt_interrupt(&task.spec.id, &claim)
                .await,
            Err(crate::tasks::RuntimeTaskAttemptInterruptError::StaleOrSettledClaim { .. })
        ));
        let repeated_snapshot = runtime.snapshot().await?;
        assert_eq!(repeated_snapshot.revision, final_snapshot.revision);
        assert_eq!(repeated_snapshot.tasks, final_snapshot.tasks);
        Ok(())
    }

    #[tokio::test]
    async fn caller_drop_retains_original_stream_cleanup_in_all_modes() -> Result<()> {
        for mode in [
            ExecutionMode::Sync,
            ExecutionMode::Fork,
            ExecutionMode::Teammate,
        ] {
            let (barrier, _cancel, dispatch) =
                held_cleanup_dispatch(mode, false, HeldStreamFailure::Cancellation).await?;
            dispatch.abort();
            assert!(dispatch.await.is_err_and(|error| error.is_cancelled()));
            tokio::time::timeout(Duration::from_secs(2), barrier.cleanup_entered.notified())
                .await
                .map_err(|_| {
                    ReactError::Other(
                        "detached original owner did not receive cancellation".to_string(),
                    )
                })?;
            assert!(!barrier.physical_stopped.load(Ordering::SeqCst));
            barrier.release_cleanup.notify_one();
            tokio::time::timeout(Duration::from_secs(2), async {
                while !barrier.physical_stopped.load(Ordering::SeqCst) {
                    tokio::task::yield_now().await;
                }
            })
            .await
            .map_err(|_| {
                ReactError::Other("detached original producer did not close".to_string())
            })?;
        }
        Ok(())
    }

    async fn assert_mode_retains_runtime_guards(
        mode: ExecutionMode,
    ) -> std::result::Result<(), String> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("guarded").with_response("done");
        registry
            .register(
                SubagentDefinition {
                    execution_mode: mode.clone(),
                    ..SubagentDefinition::new("guarded", "Guarded subagent")
                },
                Box::new(agent.clone()),
            )
            .await;
        let drops = Arc::new(AtomicUsize::new(0));
        let result = executor
            .dispatch(DispatchRequest {
                agent_name: "guarded".to_string(),
                task: "retain guard".to_string(),
                mode_override: Some(mode),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: Some(echo_core::tools::ExternalRunContext {
                    conversation_id: None,
                    run_id: None,
                    turn_id: None,
                    execution_id: None,
                    isolation_id: None,
                    message_id: None,
                    cancel: None,
                    trace_sink: None,
                    delegation_policy: None,
                    resource_guards: vec![InvocationResourceGuard::new(DispatchGuardDrop(
                        Arc::clone(&drops),
                    ))],
                    subagent_lineage: None,
                    uplink: None,
                }),
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .map_err(|error| error.to_string())?;
        if result.outcome.status != SubagentStatus::Completed {
            return Err(format!(
                "guarded dispatch did not complete: {:?}",
                result.outcome.status
            ));
        }

        let contexts = agent.take_invocation_contexts();
        let guard_count = contexts
            .first()
            .and_then(|context| context.runtime.as_ref())
            .map(|runtime| runtime.resource_guards.len());
        if guard_count != Some(1) {
            return Err(format!(
                "subagent invocation lost runtime guards: {guard_count:?}"
            ));
        }
        assert_eq!(drops.load(Ordering::SeqCst), 0);
        drop(contexts);
        assert_eq!(drops.load(Ordering::SeqCst), 1);
        Ok(())
    }

    #[tokio::test]
    async fn sync_dispatch_retains_runtime_guards_until_settlement()
    -> std::result::Result<(), String> {
        assert_mode_retains_runtime_guards(ExecutionMode::Sync).await
    }

    #[tokio::test]
    async fn fork_dispatch_retains_runtime_guards_until_settlement()
    -> std::result::Result<(), String> {
        assert_mode_retains_runtime_guards(ExecutionMode::Fork).await
    }

    #[tokio::test]
    async fn teammate_dispatch_retains_runtime_guards_until_settlement()
    -> std::result::Result<(), String> {
        assert_mode_retains_runtime_guards(ExecutionMode::Teammate).await
    }

    #[tokio::test]
    async fn dispatch_preserves_rich_tool_events_without_parallel_adapters()
    -> std::result::Result<(), Box<dyn std::error::Error>> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("rich-tool-events", "Rich tool events"),
                Box::new(RichToolEventAgent),
            )
            .await;
        let mut events = registry.event_bus().subscribe();

        let dispatched = executor
            .dispatch(DispatchRequest {
                agent_name: "rich-tool-events".to_string(),
                task: "preserve typed events".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await?;
        assert_eq!(dispatched.output, "done");

        let mut started = None;
        let mut completed = None;
        while let Ok(event) = events.try_recv() {
            match event.as_ref() {
                SubagentEvent::DispatchToolStarted { invocation, .. } => {
                    started = Some(invocation.clone());
                }
                SubagentEvent::DispatchToolCompleted { name, result, .. } => {
                    completed = Some((name.clone(), result.clone()));
                }
                _ => {}
            }
        }

        let Some(invocation) = started else {
            return Err(std::io::Error::other("missing typed tool-start event").into());
        };
        assert_eq!(invocation.requested_name, "requested_tool");
        assert_eq!(invocation.name, "effective_tool");
        assert_eq!(invocation.rewrites, vec![ToolInvocationRewrite::Approval]);
        assert_eq!(
            invocation
                .args
                .get("value")
                .and_then(serde_json::Value::as_str),
            Some("effective")
        );

        let Some((name, result)) = completed else {
            return Err(std::io::Error::other("missing typed tool-result event").into());
        };
        assert_eq!(name, "effective_tool");
        assert_eq!(result.kind, ToolResultKind::Json);
        assert_eq!(result.data, Some(serde_json::json!({"ok": true})));
        assert_eq!(result.mime_type.as_deref(), Some("application/json"));
        assert!(result.truncated);
        assert_eq!(
            result.metadata.get("source").map(String::as_str),
            Some("fixture")
        );
        Ok(())
    }

    fn collect_terminal_events(
        events: &mut tokio::sync::broadcast::Receiver<Arc<SubagentEvent>>,
    ) -> Vec<Arc<SubagentEvent>> {
        let mut terminal_events = Vec::new();
        while let Ok(event) = events.try_recv() {
            if matches!(
                event.as_ref(),
                SubagentEvent::DispatchCompleted { .. }
                    | SubagentEvent::DispatchFailed { .. }
                    | SubagentEvent::DispatchCancelled { .. }
            ) {
                terminal_events.push(event);
            }
        }
        terminal_events
    }

    #[test]
    fn structured_result_terminal_event_matches_runtime_status() -> Result<()> {
        for status in [
            SubagentStatus::Completed,
            SubagentStatus::Failed,
            SubagentStatus::TimedOut,
            SubagentStatus::Cancelled,
            SubagentStatus::Running,
        ] {
            let mut result = SubagentResult::sync_result(
                "child",
                "## Summary\nresult".to_string(),
                std::time::Duration::ZERO,
            );
            result.outcome.status = status;
            let event = SubagentExecutor::terminal_event_for_result(
                "parent",
                "child",
                &mut result,
                Some("attempt-1".to_string()),
                Some("run-1".to_string()),
            );
            let terminal = match &event {
                SubagentEvent::DispatchCompleted { outcome, .. }
                    if status == SubagentStatus::Completed =>
                {
                    outcome.status
                }
                SubagentEvent::DispatchCancelled { outcome, .. }
                    if status == SubagentStatus::Cancelled =>
                {
                    outcome.status
                }
                SubagentEvent::DispatchFailed {
                    status: emitted,
                    outcome,
                    ..
                } if status == SubagentStatus::Running && *emitted == SubagentStatus::Failed => {
                    outcome.status
                }
                SubagentEvent::DispatchFailed {
                    status: emitted,
                    outcome,
                    ..
                } if *emitted == status => outcome.status,
                other => {
                    return Err(ReactError::Other(format!(
                        "incorrect terminal event for {status:?}: {other:?}"
                    )));
                }
            };
            assert_eq!(terminal, result.outcome.status);
            assert_ne!(terminal, SubagentStatus::Running);
        }
        Ok(())
    }

    /// Build a SubagentContext with N numbered user messages and no system prompt.
    #[test]
    fn dispatch_request_uses_nested_delegation_policy_as_depth_authority() {
        let policy = DispatchRequest::policy_from_depth(2);

        assert!(policy.can_spawn_subagents);
        assert_eq!(policy.delegate_depth, 2);
        assert_eq!(policy.max_delegate_depth, 3);

        let child = policy.child_policy().unwrap_or_default();
        assert_eq!(child.delegate_depth, 3);
        assert!(!child.can_delegate());
    }

    #[test]
    fn merge_observed_evidence_keeps_latest_check_result() {
        let mut outcome = SubagentOutcome {
            evidence: vec![SubagentEvidence {
                kind: "verification".to_string(),
                subject: "cargo test".to_string(),
                outcome: Some("passed".to_string()),
                details: "model claim".to_string(),
                source: SubagentEvidenceSource::Reported,
                attributes: serde_json::Value::Null,
            }],
            ..SubagentOutcome::default()
        };
        merge_observed_evidence(
            &mut outcome,
            vec![
                SubagentEvidence {
                    kind: "verification".to_string(),
                    subject: "cargo test".to_string(),
                    outcome: Some("failed".to_string()),
                    details: "first run failed".to_string(),
                    source: SubagentEvidenceSource::Observed,
                    attributes: serde_json::Value::Null,
                },
                SubagentEvidence {
                    kind: "verification".to_string(),
                    subject: "cargo test".to_string(),
                    outcome: Some("passed".to_string()),
                    details: "retry passed".to_string(),
                    source: SubagentEvidenceSource::Observed,
                    attributes: serde_json::Value::Null,
                },
            ],
            Vec::new(),
        );
        assert!(matches!(
            outcome.evidence.as_slice(),
            [SubagentEvidence {
                source: SubagentEvidenceSource::Observed,
                ..
            }]
        ));
        assert_eq!(
            outcome
                .evidence
                .first()
                .and_then(|item| item.outcome.as_deref()),
            Some("passed")
        );
    }

    #[test]
    fn merge_observed_evidence_preserves_distinct_tool_arguments() {
        let mut outcome = SubagentOutcome::default();
        let evidence = ["src/a.rs", "src/b.rs"]
            .into_iter()
            .map(|path| SubagentEvidence {
                kind: "tool_result".to_string(),
                subject: "write_file".to_string(),
                outcome: Some("succeeded".to_string()),
                details: String::new(),
                source: SubagentEvidenceSource::Observed,
                attributes: serde_json::json!({ "args": { "path": path } }),
            })
            .collect();

        merge_observed_evidence(&mut outcome, evidence, Vec::new());

        assert_eq!(outcome.evidence.len(), 2);
    }

    #[tokio::test]
    async fn test_dispatch_sync() {
        let (registry, executor) = make_executor().await;

        let agent = MockAgent::new("subagent").with_response("done");
        let def = super::super::types::SubagentDefinition::new("subagent", "Subagent");
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "subagent".into(),
            task: "do work".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        assert_eq!(result.output, "done");
        assert_eq!(result.mode, ExecutionMode::Sync);
    }

    #[tokio::test]
    async fn fork_cancelled_while_queued_never_starts_agent() -> std::result::Result<(), String> {
        let registry = Arc::new(SubagentRegistry::new());
        let agent = MockAgent::new("queued").with_response("should not run");
        let observed = agent.clone();
        let mut definition = SubagentDefinition::new("queued", "Queued agent");
        definition.execution_mode = ExecutionMode::Fork;
        registry.register(definition, Box::new(agent)).await;
        let executor = Arc::new(SubagentExecutor::new(
            registry,
            SubagentExecutorConfig {
                max_concurrent_forks: 1,
                default_timeout_secs: 30,
                ..SubagentExecutorConfig::default()
            },
        ));
        let permit = executor
            .local_fork_admission
            .issue("queued-test-existing-owner")
            .map_err(|error| error.to_string())?;
        let cancel = CancellationToken::new();
        let request = DispatchRequest {
            agent_name: "queued".to_string(),
            task: "must not start".to_string(),
            mode_override: None,
            cancel: cancel.clone(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let execution = tokio::spawn({
            let executor = Arc::clone(&executor);
            async move { executor.dispatch(request).await }
        });
        tokio::task::yield_now().await;
        cancel.cancel();
        drop(permit);

        let result = tokio::time::timeout(Duration::from_secs(2), execution)
            .await
            .map_err(|_| "cancelled queued dispatch did not terminate".to_string())?
            .map_err(|error| error.to_string())?;
        assert!(result.is_err());
        assert_eq!(observed.call_count(), 0);
        Ok(())
    }

    #[tokio::test]
    async fn dispatch_uses_injected_prompt_compiler() -> Result<()> {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(
            registry.clone(),
            SubagentExecutorConfig {
                prompt_compiler: Arc::new(PrefixPromptCompiler),
                ..SubagentExecutorConfig::default()
            },
        );
        let agent = MockAgent::new("compiled").with_response("done");
        registry
            .register(
                super::super::types::SubagentDefinition::new("compiled", "Compiled subagent"),
                Box::new(agent.clone()),
            )
            .await;

        executor
            .dispatch(DispatchRequest {
                agent_name: "compiled".to_string(),
                task: "do work".to_string(),
                mode_override: Some(ExecutionMode::Sync),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await?;

        assert_eq!(agent.last_task().as_deref(), Some("compiled:do work"));
        Ok(())
    }

    #[tokio::test]
    async fn dispatch_background_returns_before_completion() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("slow")
            .with_delay_ms(200)
            .with_response("## Summary\nbg done");
        let def = super::super::types::SubagentDefinition::new("slow", "Slow subagent");
        registry.register(def, Box::new(agent)).await;

        let mut events = registry.event_bus().subscribe();
        let req = DispatchRequest {
            agent_name: "slow".into(),
            task: "take your time".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let started_at = Instant::now();
        let handle = executor.dispatch_background(req).await?;
        assert!(
            started_at.elapsed() < Duration::from_millis(100),
            "dispatch_background must return before the slow subagent finishes"
        );
        assert!(!handle.execution_id.is_empty());
        assert_eq!(handle.agent_name, "slow");
        assert!(handle.execution_id.starts_with("agent_tool-"));
        assert!(!handle.is_finished());

        let mut saw_started_bg = false;
        let mut saw_completed = false;
        let deadline = tokio::time::Instant::now() + Duration::from_secs(3);
        while tokio::time::Instant::now() < deadline && !(saw_started_bg && saw_completed) {
            let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
            match tokio::time::timeout(remaining, events.recv()).await {
                Ok(Ok(ev)) => match ev.as_ref() {
                    SubagentEvent::DispatchStarted {
                        background: true,
                        execution_id: Some(id),
                        ..
                    } if id == &handle.execution_id => {
                        saw_started_bg = true;
                    }
                    SubagentEvent::DispatchCompleted {
                        output,
                        execution_id: Some(id),
                        ..
                    } if id == &handle.execution_id => {
                        assert!(output.contains("bg done"));
                        saw_completed = true;
                    }
                    _ => {}
                },
                _ => break,
            }
        }
        assert!(
            saw_started_bg,
            "expected DispatchStarted with background=true"
        );
        assert!(
            saw_completed,
            "expected DispatchCompleted after background work"
        );
        let result = handle.join().await?;
        assert!(result.output.contains("bg done"));
        assert!(
            handle.join().await.is_err(),
            "result must only be consumed once"
        );
        Ok(())
    }

    #[tokio::test]
    async fn controlled_dispatch_claims_guidance_once_for_exact_attempt() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("guided").with_response("done");
        registry
            .register(
                SubagentDefinition::new("guided", "Guided subagent"),
                Box::new(agent.clone()),
            )
            .await;
        executor
            .queue_guidance("task-guided", 1, "inspect the latest revision")
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let request = DispatchRequest {
            agent_name: "guided".to_string(),
            task: "perform task".to_string(),
            mode_override: Some(ExecutionMode::Sync),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let identity = SubagentAttemptIdentity::new("task-guided", "execution-guided-1", 1)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        executor.dispatch_attempt(request, identity).await?;

        let observed = agent.last_task().unwrap_or_default();
        assert!(observed.contains("perform task"));
        assert!(observed.contains("[queued_guidance]"));
        assert!(observed.contains("inspect the latest revision"));
        assert!(matches!(
            executor.queue_guidance("task-guided", 1, "late"),
            Err(SubagentControlError::AttemptAlreadyStarted { .. })
        ));
        Ok(())
    }

    #[tokio::test]
    async fn controlled_dispatch_claims_scoped_guidance_for_independent_runs() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("guided")
            .with_response("done")
            .with_response("done");
        registry
            .register(
                SubagentDefinition::new("guided", "Guided subagent"),
                Box::new(agent.clone()),
            )
            .await;
        for (run, instruction) in [("run-a", "只处理甲"), ("run-b", "只处理乙")] {
            executor
                .queue_guidance_scoped(run, run, "task-guided", 1, instruction)
                .map_err(|error| ReactError::Other(error.to_string()))?;
        }

        for (run, execution, instruction, other_instruction) in [
            ("run-a", "execution-a", "只处理甲", "只处理乙"),
            ("run-b", "execution-b", "只处理乙", "只处理甲"),
        ] {
            let request = DispatchRequest {
                agent_name: "guided".to_string(),
                task: "perform task".to_string(),
                mode_override: Some(ExecutionMode::Sync),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            };
            let identity = SubagentAttemptIdentity::for_run(run, "task-guided", execution, 1)
                .map_err(|error| ReactError::Other(error.to_string()))?;
            executor.dispatch_attempt(request, identity).await?;
            let observed = agent.last_task().unwrap_or_default();
            assert!(observed.contains("perform task"));
            assert!(observed.contains("[queued_guidance]"));
            assert!(observed.contains(instruction));
            assert!(!observed.contains(other_instruction));
            assert!(matches!(
                executor.queue_guidance_scoped(run, run, "task-guided", 1, "late"),
                Err(SubagentControlError::AttemptAlreadyStarted { .. })
            ));
        }
        Ok(())
    }

    #[tokio::test]
    async fn background_handle_cancels_dispatch() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                super::super::types::SubagentDefinition::new("slow", "Slow subagent"),
                Box::new(MockAgent::new("slow").with_delay_ms(1_000)),
            )
            .await;
        let handle = executor
            .dispatch_background(DispatchRequest {
                agent_name: "slow".into(),
                task: "wait".into(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".into(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await?;
        handle.cancel();
        let result = handle.join().await?;
        assert_eq!(result.outcome.status, SubagentStatus::Cancelled);
        Ok(())
    }

    #[tokio::test]
    async fn controlled_background_interrupt_is_registered_before_handle_returns() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("controlled", "Controlled subagent"),
                Box::new(MockAgent::new("controlled").with_response("must not escape")),
            )
            .await;
        let request = DispatchRequest {
            agent_name: "controlled".to_string(),
            task: "wait".to_string(),
            mode_override: Some(ExecutionMode::Sync),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let identity = SubagentAttemptIdentity::new("task-controlled", "execution-controlled", 1)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let handle = executor
            .dispatch_background_attempt(request, identity)
            .await?;

        let interrupted = executor
            .interrupt_subagent("execution-controlled", 1)
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert!(interrupted.requested);
        assert!(interrupted.settled);
        assert_eq!(interrupted.terminal_status, Some(SubagentStatus::Cancelled));
        let result = handle.join().await?;
        assert_eq!(result.outcome.status, SubagentStatus::Cancelled);
        assert!(matches!(
            executor
                .send_message_tracked("execution-controlled", 1, "late")
                .await,
            Err(SubagentControlError::AttemptSettled { .. })
        ));
        Ok(())
    }

    #[tokio::test]
    async fn dispatch_started_preserves_chat_identity() -> std::result::Result<(), String> {
        let (registry, executor) = make_executor().await;
        let agent = MockAgent::new("identity").with_response("done");
        let definition =
            super::super::types::SubagentDefinition::new("identity", "Identity subagent");
        registry.register(definition, Box::new(agent)).await;
        let mut events = registry.event_bus().subscribe();
        let mut envelopes = registry.event_bus().subscribe_envelopes();
        let request = DispatchRequest {
            agent_name: "identity".to_string(),
            task: "preserve identity".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("conversation-identity".to_string()),
                run_id: None,
                turn_id: Some("turn-identity".to_string()),
                execution_id: Some("agent_tool-identity".to_string()),
                isolation_id: None,
                message_id: Some("message-identity".to_string()),
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: Some(echo_core::tools::SubagentLineage {
                    task_id: Some("task-identity".to_string()),
                    attempt: Some(3),
                    plan_revision: Some(7),
                    ..echo_core::tools::SubagentLineage::default()
                }),
                uplink: None,
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        executor
            .dispatch(request)
            .await
            .map_err(|error| error.to_string())?;
        let started = events.recv().await.map_err(|error| error.to_string())?;
        match started.as_ref() {
            SubagentEvent::DispatchStarted {
                conversation_id,
                message_id,
                run_id,
                ..
            } => {
                assert_eq!(conversation_id.as_deref(), Some("conversation-identity"));
                assert_eq!(message_id.as_deref(), Some("message-identity"));
                assert!(run_id.is_none());
            }
            other => return Err(format!("expected DispatchStarted, got {other:?}")),
        }
        let started_envelope = envelopes.recv().await.map_err(|error| error.to_string())?;
        assert_eq!(started_envelope.sequence, 1);
        assert_eq!(
            started_envelope
                .conversation_id
                .as_ref()
                .map(|value| value.as_str()),
            Some("conversation-identity")
        );
        assert_eq!(
            started_envelope
                .message_id
                .as_ref()
                .map(|value| value.as_str()),
            Some("message-identity")
        );
        assert_eq!(
            started_envelope.payload.invocation.task_id.as_deref(),
            Some("task-identity")
        );
        assert_eq!(started_envelope.payload.invocation.attempt, Some(3));
        assert_eq!(started_envelope.payload.invocation.plan_revision, Some(7));
        let terminal = envelopes.recv().await.map_err(|error| error.to_string())?;
        assert_eq!(terminal.sequence, 2);
        assert_eq!(
            terminal.parent_event_id,
            Some(started_envelope.event_id.clone())
        );
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchCompleted { .. }
        ));
        Ok(())
    }

    // 完整 Message、history 与只读上界由 canonical_consumer_tests 及 MockAgent typed 记录实测。

    #[tokio::test]
    async fn test_dispatch_not_found() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let req = DispatchRequest {
            agent_name: "missing".into(),
            task: "task".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let err =
            executor.dispatch(req).await.err().ok_or_else(|| {
                ReactError::Other("missing Subagent unexpectedly ran".to_string())
            })?;
        assert!(err.to_string().contains("not found"));
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let terminal = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(started.sequence, 1);
        assert_eq!(terminal.sequence, 2);
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchFailed { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn test_dispatch_cancelled() -> Result<()> {
        let (registry, executor) = make_executor().await;

        let agent = MockAgent::new("c").with_response("ok");
        let def = super::super::types::SubagentDefinition::new("c", "C");
        registry.register(def, Box::new(agent)).await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let cancel = CancellationToken::new();
        cancel.cancel();

        let req = DispatchRequest {
            agent_name: "c".into(),
            task: "task".into(),
            mode_override: None,
            cancel,
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await?;
        assert!(result.output.contains("Cancelled"));
        assert_eq!(result.outcome.status, SubagentStatus::Cancelled);
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let terminal = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(started.sequence, 1);
        assert_eq!(terminal.sequence, 2);
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchCancelled { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn rejected_delegation_depth_emits_one_failed_lifecycle() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("depth", "Depth guard"),
                Box::new(MockAgent::new("depth").with_response("must not run")),
            )
            .await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();
        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "depth".to_string(),
                task: "reject".to_string(),
                mode_override: Some(ExecutionMode::Sync),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: NestedDelegationPolicy {
                    can_spawn_subagents: true,
                    delegate_depth: 2,
                    max_delegate_depth: 1,
                },
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("invalid depth unexpectedly ran".to_string()))?;
        assert!(error.to_string().contains("Delegation depth exceeded"));
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let terminal = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!((started.sequence, terminal.sequence), (1, 2));
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchFailed { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn recovered_dispatch_emits_only_one_terminal_event() -> Result<()> {
        let registry = Arc::new(SubagentRegistry::new());
        let mut hooks = super::super::hooks::SubagentHookRegistry::new();
        hooks.register(Arc::new(DelegateFailedDispatch));
        let executor = SubagentExecutor::with_hooks(
            registry.clone(),
            SubagentExecutorConfig::default(),
            hooks,
        );
        registry
            .register(
                super::super::types::SubagentDefinition::new("primary", "Primary"),
                Box::new(FailingMockAgent::new("primary", "first attempt failed")),
            )
            .await;
        let recovery = MockAgent::new("recovery").with_response("recovered");
        registry
            .register(
                super::super::types::SubagentDefinition::new("recovery", "Recovery"),
                Box::new(recovery.clone()),
            )
            .await;
        let mut events = registry.event_bus().subscribe();
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let result = executor
            .dispatch(DispatchRequest {
                agent_name: "primary".to_string(),
                task: "recover this task".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: vec!["Preserve the caller boundary".to_string()],
                background: false,
            })
            .await?;
        assert_eq!(result.outcome.status, SubagentStatus::Completed);
        assert!(
            recovery
                .last_task()
                .as_deref()
                .is_some_and(|task| task.contains("Preserve the caller boundary")),
            "delegated recovery must receive the original constraints"
        );

        let terminal_events = collect_terminal_events(&mut events);
        assert_eq!(terminal_events.len(), 1);
        assert!(matches!(
            terminal_events.first().map(AsRef::as_ref),
            Some(SubagentEvent::DispatchCompleted { outcome, .. })
                if outcome.status == SubagentStatus::Completed
        ));
        let mut sequences = Vec::new();
        let mut agents = Vec::new();
        for _ in 0..2 {
            let envelope = envelopes
                .recv()
                .await
                .map_err(|error| ReactError::Other(error.to_string()))?;
            sequences.push(envelope.sequence);
            agents.push(envelope.payload.invocation.agent_name.clone());
        }
        assert_eq!(sequences, vec![1, 2]);
        assert_eq!(agents, vec!["primary", "recovery"]);
        assert!(matches!(
            envelopes.try_recv(),
            Err(tokio::sync::broadcast::error::TryRecvError::Empty)
        ));
        Ok(())
    }

    #[tokio::test]
    async fn failed_dispatch_emits_failed_terminal_status() -> std::result::Result<(), String> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                super::super::types::SubagentDefinition::new("failing", "Failing"),
                Box::new(FailingMockAgent::new("failing", "boom")),
            )
            .await;
        let mut events = registry.event_bus().subscribe();
        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "failing".to_string(),
                task: "fail".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| "failing subagent unexpectedly completed".to_string())?;
        assert_eq!(
            subagent_status_from_error(&error).map_err(|error| error.to_string())?,
            SubagentStatus::Failed
        );
        let terminal_events = collect_terminal_events(&mut events);
        assert!(matches!(
            terminal_events.as_slice(),
            [event]
                if matches!(
                    event.as_ref(),
                    SubagentEvent::DispatchFailed {
                        status: SubagentStatus::Failed,
                        ..
                    }
                )
        ));
        Ok(())
    }

    #[tokio::test]
    async fn running_dispatch_cancel_emits_cancelled_terminal_status()
    -> std::result::Result<(), String> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                super::super::types::SubagentDefinition::new("slow-cancel", "Slow cancel"),
                Box::new(
                    MockAgent::new("slow-cancel")
                        .with_delay_ms(500)
                        .with_default_success("completed"),
                ),
            )
            .await;
        let mut events = registry.event_bus().subscribe();
        let cancel = CancellationToken::new();
        let trigger = cancel.clone();
        tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(20)).await;
            trigger.cancel();
        });
        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow-cancel".to_string(),
                task: "wait".to_string(),
                mode_override: None,
                cancel,
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| "cancelled subagent unexpectedly completed".to_string())?;
        assert_eq!(
            subagent_status_from_error(&error).map_err(|error| error.to_string())?,
            SubagentStatus::Cancelled
        );
        let terminal_events = collect_terminal_events(&mut events);
        assert!(matches!(
            terminal_events.as_slice(),
            [event]
                if matches!(event.as_ref(), SubagentEvent::DispatchCancelled { outcome, .. }
                    if outcome.status == SubagentStatus::Cancelled)
        ));
        Ok(())
    }

    #[tokio::test]
    async fn timed_out_dispatch_emits_timed_out_terminal_status() -> std::result::Result<(), String>
    {
        let (registry, executor) = make_executor().await;
        let mut definition =
            super::super::types::SubagentDefinition::new("slow-timeout", "Slow timeout");
        definition.timeout_secs = 1;
        registry
            .register(
                definition,
                Box::new(
                    MockAgent::new("slow-timeout")
                        .with_delay_ms(1_500)
                        .with_default_success("completed"),
                ),
            )
            .await;
        let mut events = registry.event_bus().subscribe();
        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow-timeout".to_string(),
                task: "wait".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| "timed-out subagent unexpectedly completed".to_string())?;
        assert_eq!(
            subagent_status_from_error(&error).map_err(|error| error.to_string())?,
            SubagentStatus::TimedOut
        );
        let terminal_events = collect_terminal_events(&mut events);
        assert!(matches!(
            terminal_events.as_slice(),
            [event]
                if matches!(
                    event.as_ref(),
                    SubagentEvent::DispatchFailed {
                        status: SubagentStatus::TimedOut,
                        outcome,
                        ..
                    } if outcome.status == SubagentStatus::TimedOut
                )
        ));
        Ok(())
    }

    #[tokio::test]
    async fn test_dispatch_mode_override() {
        let (registry, executor) = make_executor().await;

        let agent = MockAgent::new("forker").with_response("forked");
        let mut def = super::super::types::SubagentDefinition::new("forker", "Fork agent");
        def.execution_mode = ExecutionMode::Sync; // Default is Sync
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "forker".into(),
            task: "task".into(),
            mode_override: Some(ExecutionMode::Fork),
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        assert_eq!(result.output, "forked");
        assert_eq!(result.mode, ExecutionMode::Fork);
    }

    #[tokio::test]
    async fn sync_dispatch_creates_fresh_agent_per_request() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut definition = super::super::types::SubagentDefinition::new("explorer", "Explorer");
        definition.execution_mode = ExecutionMode::Sync;
        registry
            .register(
                definition.clone(),
                Box::new(MockAgent::new("explorer").with_response("cached")),
            )
            .await;

        let creations = Arc::new(AtomicUsize::new(0));
        let factory_creations = Arc::clone(&creations);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let instance = factory_creations
                .fetch_add(1, Ordering::SeqCst)
                .saturating_add(1);
            Box::pin(async move {
                Ok(Box::new(
                    MockAgent::new("explorer")
                        .with_delay_ms(50)
                        .with_response(format!("instance-{instance}")),
                ) as Box<dyn Agent>)
            })
        }));
        assert!(registry.register_factory_sync(definition, factory));
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let request = || DispatchRequest {
            agent_name: "explorer".to_string(),
            task: "inspect".to_string(),
            mode_override: Some(ExecutionMode::Sync),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let (first, second) =
            tokio::join!(executor.dispatch(request()), executor.dispatch(request()));
        let first = first?;
        let second = second?;

        assert_eq!(creations.load(Ordering::SeqCst), 2);
        assert_ne!(first.output, second.output);
        assert_ne!(first.output, "cached");
        assert_ne!(second.output, "cached");
        let mut sequences_by_stream = HashMap::<String, Vec<u64>>::new();
        for _ in 0..4 {
            let envelope = envelopes
                .recv()
                .await
                .map_err(|error| ReactError::Other(error.to_string()))?;
            sequences_by_stream
                .entry(envelope.stream_id.as_str().to_string())
                .or_default()
                .push(envelope.sequence);
        }
        assert_eq!(sequences_by_stream.len(), 2);
        assert!(
            sequences_by_stream
                .values()
                .all(|sequences| sequences.as_slice() == [1, 2])
        );
        Ok(())
    }

    #[tokio::test]
    async fn sync_timeout_cancels_detached_stream_producer() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let cancellation_seen = Arc::new(tokio::sync::Notify::new());
        let mut definition = super::super::types::SubagentDefinition::new("slow", "Slow stream");
        definition.execution_mode = ExecutionMode::Sync;
        definition.timeout_secs = 1;
        registry
            .register(
                definition,
                Box::new(CancellationAwareStreamAgent {
                    cancellation_seen: Arc::clone(&cancellation_seen),
                }),
            )
            .await;

        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow".to_string(),
                task: "wait".to_string(),
                mode_override: Some(ExecutionMode::Sync),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("slow Sync unexpectedly completed".to_string()))?;

        assert_eq!(
            subagent_status_from_error(&error)?,
            SubagentStatus::TimedOut
        );
        tokio::time::timeout(Duration::from_secs(1), cancellation_seen.notified())
            .await
            .map_err(|_| {
                ReactError::Other(
                    "Sync timeout did not cancel the detached stream producer".to_string(),
                )
            })?;
        Ok(())
    }

    #[tokio::test]
    async fn fork_dispatch_creates_fresh_agent_per_request() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut definition = super::super::types::SubagentDefinition::new("explorer", "Explorer");
        definition.execution_mode = ExecutionMode::Fork;
        registry
            .register(
                definition.clone(),
                Box::new(MockAgent::new("explorer").with_response("cached")),
            )
            .await;

        let creations = Arc::new(AtomicUsize::new(0));
        let factory_creations = Arc::clone(&creations);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let instance = factory_creations
                .fetch_add(1, Ordering::SeqCst)
                .saturating_add(1);
            Box::pin(async move {
                Ok(Box::new(
                    MockAgent::new("explorer")
                        .with_delay_ms(50)
                        .with_response(format!("instance-{instance}")),
                ) as Box<dyn Agent>)
            })
        }));
        assert!(registry.register_factory_sync(definition, factory));

        let request = || DispatchRequest {
            agent_name: "explorer".to_string(),
            task: "inspect".to_string(),
            mode_override: Some(ExecutionMode::Fork),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let (first, second) =
            tokio::join!(executor.dispatch(request()), executor.dispatch(request()));
        let first = first?;
        let second = second?;

        assert_eq!(creations.load(Ordering::SeqCst), 2);
        assert_ne!(first.output, second.output);
        assert_ne!(first.output, "cached");
        assert_ne!(second.output, "cached");
        Ok(())
    }

    #[tokio::test]
    async fn fork_timeout_cancels_detached_stream_producer() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let cancellation_seen = Arc::new(tokio::sync::Notify::new());
        let mut definition = super::super::types::SubagentDefinition::new("slow", "Slow stream");
        definition.execution_mode = ExecutionMode::Fork;
        definition.timeout_secs = 1;
        registry
            .register(
                definition,
                Box::new(CancellationAwareStreamAgent {
                    cancellation_seen: Arc::clone(&cancellation_seen),
                }),
            )
            .await;

        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow".to_string(),
                task: "wait".to_string(),
                mode_override: Some(ExecutionMode::Fork),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("slow Fork unexpectedly completed".to_string()))?;

        assert_eq!(
            subagent_status_from_error(&error)?,
            SubagentStatus::TimedOut
        );
        tokio::time::timeout(Duration::from_secs(1), cancellation_seen.notified())
            .await
            .map_err(|_| {
                ReactError::Other(
                    "Fork timeout did not cancel the detached stream producer".to_string(),
                )
            })?;
        Ok(())
    }

    #[tokio::test]
    async fn test_teammate_dispatch() -> Result<()> {
        let (registry, executor) = make_executor().await;

        let agent = MockAgent::new("tm").with_response("team result");
        let mut def = super::super::types::SubagentDefinition::new("tm", "Teammate");
        def.execution_mode = ExecutionMode::Teammate;
        registry.register(def, Box::new(agent)).await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();

        let req = DispatchRequest {
            agent_name: "tm".into(),
            task: "team task".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "leader".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let handle = executor.dispatch_teammate(req).await?;
        assert_eq!(handle.agent_name, "tm");

        let result = handle.join().await?;
        assert_eq!(result.output, "team result");
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let terminal = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(started.sequence, 1);
        assert_eq!(terminal.sequence, 2);
        assert!(matches!(
            terminal.payload.event,
            SubagentEvent::DispatchCompleted { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn teammate_setup_failure_emits_started_and_failed() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut envelopes = registry.event_bus().subscribe_envelopes();
        let error = executor
            .dispatch_teammate(DispatchRequest {
                agent_name: "missing-teammate".to_string(),
                task: "fail setup".to_string(),
                mode_override: Some(ExecutionMode::Teammate),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("missing teammate unexpectedly ran".to_string()))?;
        assert!(error.to_string().contains("not found"));
        let started = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let failed = envelopes
            .recv()
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!((started.sequence, failed.sequence), (1, 2));
        assert!(matches!(
            failed.payload.event,
            SubagentEvent::DispatchFailed { .. }
        ));
        Ok(())
    }

    #[tokio::test]
    async fn team_dispatch_rejects_unregistered_member_without_false_completion() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let definition = super::super::builder::SubagentBuilder::new("pipeline-team")
            .team(super::super::team::TeamSpec {
                strategy: super::super::team::TeamStrategy::Pipeline(vec![
                    "missing-member".to_string(),
                ]),
                manager: String::new(),
                subagents: Vec::new(),
                config: super::super::team::TeamConfig::default(),
            })
            .build();
        registry
            .register(definition, Box::new(MockAgent::new("pipeline-team")))
            .await;

        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "pipeline-team".to_string(),
                task: "run pipeline".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| {
                ReactError::Other("unregistered Team member completed successfully".to_string())
            })?;
        assert!(error.to_string().contains("not registered"));
        Ok(())
    }

    #[tokio::test]
    async fn team_member_dispatch_preserves_claim_derived_execution_identity() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("member", "Team member"),
                Box::new(MockAgent::new("member").with_response("member done")),
            )
            .await;
        let definition = super::super::builder::SubagentBuilder::new("pipeline-team")
            .team(super::super::team::TeamSpec {
                strategy: super::super::team::TeamStrategy::Pipeline(vec!["member".to_string()]),
                manager: String::new(),
                subagents: Vec::new(),
                config: super::super::team::TeamConfig {
                    default_timeout_secs: 0,
                    ..super::super::team::TeamConfig::default()
                },
            })
            .build();
        registry
            .register(definition, Box::new(MockAgent::new("pipeline-team")))
            .await;

        let mut events = registry.event_bus().subscribe();
        let request = DispatchRequest {
            agent_name: "pipeline-team".to_string(),
            task: "run the member".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                run_id: Some("team-identity-run".to_string()),
                ..echo_core::tools::ExternalRunContext::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let root_identity = SubagentAttemptIdentity::new("root-task", "team-identity-root", 1)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let result = executor.dispatch_attempt(request, root_identity).await?;
        assert_eq!(result.outcome.status, SubagentStatus::Completed);
        let team_runtime = executor
            .team_runtime_handles("team-identity-run")
            .first()
            .cloned()
            .ok_or_else(|| {
                ReactError::Other("React Team runtime handle was not retained".to_string())
            })?;
        assert_eq!(team_runtime.run_id(), "team-identity-run");
        assert!(
            team_runtime
                .snapshot()
                .await?
                .tasks
                .iter()
                .all(|task| task.execution.status.is_terminal())
        );

        let mut member_execution = None;
        while let Ok(event) = tokio::time::timeout(Duration::from_secs(1), events.recv()).await {
            let event = event.map_err(|error| ReactError::Other(error.to_string()))?;
            if let SubagentEvent::DispatchStarted {
                agent,
                execution_id: Some(execution_id),
                run_id: Some(run_id),
                ..
            } = event.as_ref()
                && agent == "member"
            {
                member_execution = Some((execution_id.clone(), run_id.clone()));
                break;
            }
        }
        let (execution_id, run_id) = member_execution.ok_or_else(|| {
            ReactError::Other("member DispatchStarted event was not observed".to_string())
        })?;
        assert_eq!(run_id, "team-identity-run");
        assert!(execution_id.starts_with("team-identity-run:"));
        assert!(execution_id.contains(":1:"));
        Ok(())
    }

    #[test]
    fn same_run_team_runtimes_are_retained_by_unique_handle_identity() -> Result<()> {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(registry, SubagentExecutorConfig::default());
        let make_handle = || {
            let dispatch: super::super::team::TeamDispatchFn = Arc::new(|request| {
                Box::pin(async move {
                    Ok(SubagentResult::sync_result(
                        &request.member,
                        "done".to_string(),
                        Duration::ZERO,
                    ))
                })
            });
            let controller = super::super::team::closure_dispatch_controller(
                dispatch,
                super::super::team::TeamDispatchControl::default(),
            );
            super::super::team::runtime_handle_for_controller(
                "shared-run".to_string(),
                controller,
                echo_orchestration::tasks::RuntimeTaskServiceConfig::default(),
            )
        };
        let handles = (0..=TEAM_RUNTIME_RETENTION)
            .map(|_| make_handle())
            .collect::<Vec<_>>();
        let active = handles
            .iter()
            .map(|handle| handle.start_execution())
            .collect::<Vec<_>>();
        for handle in &handles {
            executor.retain_team_runtime(handle.clone());
        }

        let retained = executor.team_runtime_handles("shared-run");
        assert_eq!(retained.len(), TEAM_RUNTIME_RETENTION.saturating_add(1));
        let first = handles
            .first()
            .ok_or_else(|| ReactError::Other("first Team handle missing".to_string()))?;
        let last = handles
            .last()
            .ok_or_else(|| ReactError::Other("last Team handle missing".to_string()))?;
        assert!(
            executor
                .team_runtime_handle(first.handle_id())
                .is_some_and(|retained| Arc::ptr_eq(&retained, first))
        );
        assert!(
            executor
                .team_runtime_handle(last.handle_id())
                .is_some_and(|retained| Arc::ptr_eq(&retained, last))
        );
        for mut guard in active {
            guard.settle();
        }
        prune_team_runtime_index(&executor.team_runtimes);
        assert_eq!(
            executor.team_runtime_handles("shared-run").len(),
            TEAM_RUNTIME_RETENTION
        );
        Ok(())
    }

    #[tokio::test]
    async fn react_team_targeted_interrupt_retains_non_cooperative_member_until_physical_eof()
    -> Result<()> {
        let (registry, executor) = make_executor().await;
        let executor = Arc::new(executor);
        let dropped = Arc::new(AtomicBool::new(false));
        let started = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        registry
            .register(
                SubagentDefinition::new("stuck-member", "Non-cooperative Team member"),
                Box::new(NonCooperativeTeamAgent {
                    dropped: Arc::clone(&dropped),
                    started: started.clone(),
                    release: release.clone(),
                }),
            )
            .await;
        let definition = super::super::builder::SubagentBuilder::new("controlled-team")
            .team(super::super::team::TeamSpec {
                strategy: super::super::team::TeamStrategy::Pipeline(vec![
                    "stuck-member".to_string(),
                ]),
                manager: String::new(),
                subagents: Vec::new(),
                config: super::super::team::TeamConfig {
                    default_timeout_secs: 0,
                    ..super::super::team::TeamConfig::default()
                },
            })
            .build();
        registry
            .register(definition, Box::new(MockAgent::new("controlled-team")))
            .await;
        let run_id = "react-team-non-cooperative";
        let request = DispatchRequest {
            agent_name: "controlled-team".to_string(),
            task: "wait forever".to_string(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                run_id: Some(run_id.to_string()),
                ..echo_core::tools::ExternalRunContext::default()
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };
        let root_identity =
            SubagentAttemptIdentity::for_run(run_id, "root-task", "react-team-root", 1)
                .map_err(|error| ReactError::Other(error.to_string()))?;
        let execution = tokio::spawn({
            let executor = Arc::clone(&executor);
            async move { executor.dispatch_attempt(request, root_identity).await }
        });
        let observed = tokio::time::timeout(Duration::from_secs(2), async {
            loop {
                if let Some(handle) = executor.team_runtime_handles(run_id).first().cloned()
                    && let Ok(snapshot) = handle.snapshot().await
                    && let Some((task_id, claim)) = snapshot.tasks.iter().find_map(|task| {
                        task.execution
                            .claim
                            .clone()
                            .map(|claim| (task.spec.id.clone(), claim))
                    })
                {
                    break (handle, task_id, claim);
                }
                tokio::task::yield_now().await;
            }
        })
        .await;
        let (handle, task_id, claim) = match observed {
            Ok(observed) => observed,
            Err(_) if execution.is_finished() => {
                let result = execution.await.map_err(|error| {
                    ReactError::Other(format!("React Team task panicked: {error}"))
                })?;
                return Err(ReactError::Other(format!(
                    "React Team finished before claim observation: {result:?}"
                )));
            }
            Err(_) => {
                return Err(ReactError::Other(
                    "React Team claim was not observable".to_string(),
                ));
            }
        };
        started.notified().await;
        assert!(
            handle
                .request_attempt_interrupt(&task_id, &claim)
                .await?
                .requested
        );
        assert!(!execution.is_finished());
        assert!(!dropped.load(Ordering::SeqCst));
        let pending = handle.snapshot().await?;
        assert!(
            pending
                .tasks
                .iter()
                .any(|task| task.execution.claim.as_ref() == Some(&claim))
        );
        release.notify_one();
        let error = tokio::time::timeout(Duration::from_secs(7), execution)
            .await
            .map_err(|_| ReactError::Other("React Team exact abort did not settle".to_string()))?
            .map_err(|error| ReactError::Other(format!("React Team task panicked: {error}")))?
            .err()
            .ok_or_else(|| ReactError::Other("cancelled React Team succeeded".to_string()))?;
        assert!(
            matches!(
                &error,
                ReactError::Agent(agent_error)
                    if matches!(agent_error.as_ref(), AgentError::Cancelled(_))
            ),
            "unexpected React Team terminal: {error:?}"
        );
        assert!(dropped.load(Ordering::SeqCst));
        Ok(())
    }

    #[tokio::test]
    async fn teammate_dispatch_creates_fresh_agent_per_request() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let mut definition = super::super::types::SubagentDefinition::new("explorer", "Explorer");
        definition.execution_mode = ExecutionMode::Teammate;
        registry
            .register(
                definition.clone(),
                Box::new(MockAgent::new("explorer").with_response("cached")),
            )
            .await;

        let creations = Arc::new(AtomicUsize::new(0));
        let factory_creations = Arc::clone(&creations);
        let factory = Arc::new(FnAgentFactory::new(move || {
            let instance = factory_creations
                .fetch_add(1, Ordering::SeqCst)
                .saturating_add(1);
            Box::pin(async move {
                Ok(Box::new(
                    MockAgent::new("explorer")
                        .with_delay_ms(50)
                        .with_response(format!("instance-{instance}")),
                ) as Box<dyn Agent>)
            })
        }));
        assert!(registry.register_factory_sync(definition, factory));

        let request = || DispatchRequest {
            agent_name: "explorer".to_string(),
            task: "inspect".to_string(),
            mode_override: Some(ExecutionMode::Teammate),
            cancel: CancellationToken::new(),
            parent_agent: "parent".to_string(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let (first, second) =
            tokio::join!(executor.dispatch(request()), executor.dispatch(request()));
        let first = first?;
        let second = second?;

        assert_eq!(creations.load(Ordering::SeqCst), 2);
        assert_ne!(first.output, second.output);
        assert_ne!(first.output, "cached");
        assert_ne!(second.output, "cached");
        Ok(())
    }

    #[tokio::test]
    async fn teammate_timeout_cancels_detached_stream_producer() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let cancellation_seen = Arc::new(tokio::sync::Notify::new());
        let mut definition = super::super::types::SubagentDefinition::new("slow", "Slow stream");
        definition.execution_mode = ExecutionMode::Teammate;
        definition.timeout_secs = 1;
        registry
            .register(
                definition,
                Box::new(CancellationAwareStreamAgent {
                    cancellation_seen: Arc::clone(&cancellation_seen),
                }),
            )
            .await;

        let error = executor
            .dispatch(DispatchRequest {
                agent_name: "slow".to_string(),
                task: "wait".to_string(),
                mode_override: Some(ExecutionMode::Teammate),
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .err()
            .ok_or_else(|| ReactError::Other("slow Teammate unexpectedly completed".to_string()))?;

        assert_eq!(
            subagent_status_from_error(&error)?,
            SubagentStatus::TimedOut
        );
        tokio::time::timeout(Duration::from_secs(1), cancellation_seen.notified())
            .await
            .map_err(|_| {
                ReactError::Other(
                    "Teammate timeout did not cancel the detached stream producer".to_string(),
                )
            })?;
        Ok(())
    }

    #[tokio::test]
    async fn teammate_handle_cancel_does_not_cancel_parent() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let definition = super::super::types::SubagentDefinition::new("slow", "Slow stream");
        registry
            .register(
                definition,
                Box::new(CancellationAwareStreamAgent {
                    cancellation_seen: Arc::new(tokio::sync::Notify::new()),
                }),
            )
            .await;

        let parent_cancel = CancellationToken::new();
        let handle = executor
            .dispatch_teammate(DispatchRequest {
                agent_name: "slow".to_string(),
                task: "wait".to_string(),
                mode_override: Some(ExecutionMode::Teammate),
                cancel: parent_cancel.clone(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: None,
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await?;

        handle.cancel.cancel();
        if parent_cancel.is_cancelled() {
            return Err(ReactError::Other(
                "cancelling a Teammate handle cancelled its parent run".to_string(),
            ));
        }
        let error = handle
            .join()
            .await
            .err()
            .ok_or_else(|| ReactError::Other("cancelled Teammate completed".to_string()))?;
        assert!(
            matches!(error, ReactError::Agent(inner) if matches!(*inner, AgentError::Interrupted))
        );
        Ok(())
    }

    // ── Generic Fork isolation ─────────────────────────────────────────────

    use crate::agent::subagent::{
        IsolationError, IsolationHandle, IsolationOutcome, IsolationProvider, IsolationRequest,
    };
    use std::sync::Mutex as StdMutex;

    /// A mock factory whose `create` always succeeds, records the label, and
    /// whose `finalize` returns a canned diff. `should_fail` toggles hard-fail.
    struct MockIsolationProvider {
        labels: StdMutex<Vec<String>>,
        should_fail: bool,
    }

    impl IsolationProvider for MockIsolationProvider {
        fn isolate(
            &self,
            request: &IsolationRequest,
        ) -> std::result::Result<IsolationHandle, IsolationError> {
            if self.should_fail {
                return Err(IsolationError::new("mock isolation failed"));
            }
            let label = &request.label;
            self.labels.lock().unwrap().push(label.to_string());
            let path = std::path::PathBuf::from(format!("/tmp/mock-wt-{label}"));
            Ok(IsolationHandle {
                path,
                observed: ObservedIsolation::new(&request.kind),
                finalize: Box::new(|| {
                    Ok(IsolationOutcome {
                        summary: "=== mock diff ===\nfoo.rs | 1 +".to_string(),
                        artifacts: Vec::new(),
                        evidence: Vec::new(),
                    })
                }),
            })
        }
    }

    /// Build an executor with a worktree factory wired into its config.
    fn make_executor_with_factory(
        provider: Arc<dyn IsolationProvider>,
    ) -> (Arc<SubagentRegistry>, SubagentExecutor) {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(
            registry.clone(),
            SubagentExecutorConfig {
                isolation_provider: Some(provider),
                ..SubagentExecutorConfig::default()
            },
        );
        (registry, executor)
    }

    #[tokio::test]
    async fn fork_provider_binds_path_and_appends_outcome() {
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory.clone();
        let (registry, executor) = make_executor_with_factory(factory_obs);

        let agent = MockAgent::new("writer").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent.clone())).await;

        let req = DispatchRequest {
            agent_name: "writer".into(),
            task: "edit foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        // Output = subagent's answer + appended diff (the diff append is the
        // observable proof that the worktree was created and finalized).
        assert!(result.output.contains("done"));
        assert!(result.output.contains("=== mock diff ==="));
        // Factory was invoked once with a label derived from the agent name.
        let labels = factory.labels.lock().unwrap().clone();
        assert_eq!(labels.len(), 1);
        assert!(labels[0].starts_with("writer-"));
    }

    #[tokio::test]
    async fn fork_worktree_prefers_stable_isolation_identity() -> std::result::Result<(), String> {
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_for_executor: Arc<dyn IsolationProvider> = factory.clone();
        let (registry, executor) = make_executor_with_factory(factory_for_executor);
        let agent = MockAgent::new("writer").with_response("done");
        let definition = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(definition, Box::new(agent)).await;

        executor
            .dispatch(DispatchRequest {
                agent_name: "writer".to_string(),
                task: "retry the same logical task".to_string(),
                mode_override: None,
                cancel: CancellationToken::new(),
                parent_agent: "parent".to_string(),
                parent_context: None,
                delegation_policy: DispatchRequest::policy_from_depth(0),
                runtime_context: Some(echo_core::tools::ExternalRunContext {
                    conversation_id: None,
                    run_id: Some("run-1".to_string()),
                    turn_id: None,
                    execution_id: Some("task-1:2".to_string()),
                    isolation_id: Some("run-1:task-1".to_string()),
                    message_id: None,
                    cancel: None,
                    trace_sink: None,
                    delegation_policy: None,
                    resource_guards: Vec::new(),
                    subagent_lineage: None,
                    uplink: None,
                }),
                message: None,
                prompt_payload: None,
                prompt_context: None,
                constraints: Vec::new(),
                background: false,
            })
            .await
            .map_err(|error| error.to_string())?;

        let labels = factory
            .labels
            .lock()
            .map_err(|error| error.to_string())?
            .clone();
        if labels != vec!["writer-run-1:task-1".to_string()] {
            return Err(format!("unexpected worktree labels: {labels:?}"));
        }
        Ok(())
    }

    #[tokio::test]
    async fn fork_worktree_observation_precedes_subagent_completion()
    -> std::result::Result<(), String> {
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory;
        let (registry, executor) = make_executor_with_factory(factory_obs);
        let agent = MockAgent::new("writer").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent)).await;
        let mut events = registry.event_bus().subscribe();
        let req = DispatchRequest {
            agent_name: "writer".into(),
            task: "edit foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor
            .dispatch(req)
            .await
            .map_err(|error| error.to_string())?;
        if result.isolation_observed != ObservedIsolation::new("sandbox") {
            return Err(format!(
                "expected worktree result observation, got {:?}",
                result.isolation_observed
            ));
        }
        let started = events.recv().await.map_err(|error| error.to_string())?;
        let observed = events.recv().await.map_err(|error| error.to_string())?;
        let completed = events.recv().await.map_err(|error| error.to_string())?;
        if !matches!(started.as_ref(), SubagentEvent::DispatchStarted { .. }) {
            return Err(format!("first event was not started: {started:?}"));
        }
        if !matches!(
            observed.as_ref(),
            SubagentEvent::DispatchIsolationObserved { isolation, .. }
                if isolation.as_str() == "sandbox"
        ) {
            return Err(format!(
                "second event was not worktree observation: {observed:?}"
            ));
        }
        if !matches!(completed.as_ref(), SubagentEvent::DispatchCompleted { .. }) {
            return Err(format!("third event was not completed: {completed:?}"));
        }
        Ok(())
    }

    #[tokio::test]
    async fn concurrent_forks_carry_distinct_worktree_invocations()
    -> std::result::Result<(), String> {
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory;
        let (registry, executor) = make_executor_with_factory(factory_obs);
        let agent = MockAgent::new("writer").with_responses(["done-a", "done-b"]);
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent.clone())).await;
        let executor = Arc::new(executor);
        let request = |run_id: &str| DispatchRequest {
            agent_name: "writer".into(),
            task: format!("edit for {run_id}"),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some(run_id.to_string()),
                turn_id: None,
                execution_id: Some(format!("execution-{run_id}")),
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let first = {
            let executor = Arc::clone(&executor);
            async move { executor.dispatch(request("run-a")).await }
        };
        let second = {
            let executor = Arc::clone(&executor);
            async move { executor.dispatch(request("run-b")).await }
        };
        let (first_result, second_result) = tokio::join!(first, second);
        first_result.map_err(|error| error.to_string())?;
        second_result.map_err(|error| error.to_string())?;

        let invocations = agent.invocation_contexts();
        if invocations.len() != 2 {
            return Err(format!(
                "expected two value-scoped invocations, got {invocations:?}"
            ));
        }
        for invocation in invocations {
            let runtime = invocation
                .runtime
                .ok_or_else(|| "fork invocation missing runtime context".to_string())?;
            let run_id = runtime
                .run_id
                .ok_or_else(|| "fork invocation missing run id".to_string())?;
            let working_dir = invocation
                .working_dir
                .ok_or_else(|| format!("{run_id} missing worktree path"))?;
            let path = working_dir.to_string_lossy();
            if !path.contains(run_id.as_str()) {
                return Err(format!(
                    "cross-worktree invocation: run {} received {}",
                    run_id, path
                ));
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn fork_isolation_provider_failure_fails_dispatch() {
        // A factory that hard-fails → dispatch must fail, never run unisolated.
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: true,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory;
        let (registry, executor) = make_executor_with_factory(factory_obs);

        let agent = MockAgent::new("writer").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent.clone())).await;

        let req = DispatchRequest {
            agent_name: "writer".into(),
            task: "edit foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let err = executor.dispatch(req).await.unwrap_err();
        assert!(
            err.to_string().contains("Isolation 'sandbox'"),
            "got: {err}"
        );
        // The dispatch hard-failed (the safety gate) — never silently continued
        // without isolation. The error message itself is the proof; we don't
        // assert on MockAgent's recorded working_dir_calls because the registry
        // stores the agent behind an Arc<dyn Agent> and the recorded-state
        // sharing across the clone boundary is not reliably observable here.
        let _ = agent; // suppress unused warning
    }

    #[tokio::test]
    async fn fork_isolate_without_factory_hard_fails() {
        // A requested boundary with no provider must hard-fail.
        let (registry, executor) = make_executor().await; // default config, no factory

        let agent = MockAgent::new("writer").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("writer", "Writer")
        };
        registry.register(def, Box::new(agent.clone())).await;

        let req = DispatchRequest {
            agent_name: "writer".into(),
            task: "edit foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let err = executor.dispatch(req).await.unwrap_err();
        assert!(
            err.to_string().contains("no IsolationProvider")
                || err
                    .to_string()
                    .contains("refusing to run without isolation"),
            "got: {err}"
        );
        let _ = agent;
    }

    #[tokio::test]
    async fn fork_without_isolation_does_not_invoke_provider() {
        // A subagent with no isolation request never invokes the provider.
        let factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory.clone();
        let (registry, executor) = make_executor_with_factory(factory_obs);

        let agent = MockAgent::new("reader").with_response("ok");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            ..super::super::types::SubagentDefinition::new("reader", "Reader")
        };
        registry.register(def, Box::new(agent.clone())).await;

        let req = DispatchRequest {
            agent_name: "reader".into(),
            task: "read foo".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        assert_eq!(result.output, "ok");
        assert_eq!(result.isolation_observed, ObservedIsolation::new("context"));
        // Factory never invoked — readonly subagents don't request isolation.
        assert!(factory.labels.lock().unwrap().is_empty());
        let _ = agent;
    }

    // A second provider proves the framework treats isolation kinds opaquely.

    /// A second mock provider used with a different opaque isolation kind.
    struct MockWorkspaceFactory {
        labels: StdMutex<Vec<String>>,
        should_fail: bool,
    }

    impl IsolationProvider for MockWorkspaceFactory {
        fn isolate(
            &self,
            request: &IsolationRequest,
        ) -> std::result::Result<IsolationHandle, IsolationError> {
            if self.should_fail {
                return Err(IsolationError::new("mock workspace create failed"));
            }
            let label = &request.label;
            self.labels.lock().unwrap().push(label.to_string());
            Ok(IsolationHandle {
                path: std::path::PathBuf::from(format!("/tmp/mock-ws-{label}")),
                observed: ObservedIsolation::new(&request.kind),
                finalize: Box::new(|| {
                    Ok(IsolationOutcome {
                        summary: "run_001_clean.parquet\nrun_001_stats.json".to_string(),
                        artifacts: Vec::new(),
                        evidence: Vec::new(),
                    })
                }),
            })
        }
    }

    /// Build an executor with a data-workspace factory wired into its config.
    fn make_executor_with_workspace_factory(
        provider: Arc<dyn IsolationProvider>,
    ) -> (Arc<SubagentRegistry>, SubagentExecutor) {
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(
            registry.clone(),
            SubagentExecutorConfig {
                isolation_provider: Some(provider),
                ..SubagentExecutorConfig::default()
            },
        );
        (registry, executor)
    }

    #[tokio::test]
    async fn fork_arbitrary_isolation_kind_appends_provider_summary() {
        let factory = Arc::new(MockWorkspaceFactory {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory.clone();
        let (registry, executor) = make_executor_with_workspace_factory(factory_obs);

        let agent = MockAgent::new("analyst").with_response("analysis done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("workspace".to_string()),
            ..super::super::types::SubagentDefinition::new("analyst", "Analyst")
        };
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "analyst".into(),
            task: "analyze data".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        assert!(result.output.contains("analysis done"));
        assert!(result.output.contains("run_001_clean.parquet"));
        assert!(result.output.contains("--- isolation outcome ---"));
        assert_eq!(
            result.isolation_observed,
            ObservedIsolation::new("workspace")
        );
        // Factory invoked once with a label derived from the agent name.
        let labels = factory.labels.lock().unwrap().clone();
        assert_eq!(labels.len(), 1);
        assert!(labels[0].starts_with("analyst-"));
    }

    #[tokio::test]
    async fn fork_arbitrary_isolation_kind_propagates_provider_failure() {
        // Workspace factory hard-fails → dispatch fails (safety gate).
        let factory = Arc::new(MockWorkspaceFactory {
            labels: StdMutex::new(Vec::new()),
            should_fail: true,
        });
        let factory_obs: Arc<dyn IsolationProvider> = factory;
        let (registry, executor) = make_executor_with_workspace_factory(factory_obs);

        let agent = MockAgent::new("analyst").with_response("ok");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("workspace".to_string()),
            ..super::super::types::SubagentDefinition::new("analyst", "Analyst")
        };
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "analyst".into(),
            task: "analyze".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let err = executor.dispatch(req).await.unwrap_err();
        assert!(
            err.to_string().contains("Isolation 'workspace'"),
            "got: {err}"
        );
    }

    #[tokio::test]
    async fn fork_uses_only_the_configured_provider() {
        let ws_factory = Arc::new(MockWorkspaceFactory {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let wt_factory = Arc::new(MockIsolationProvider {
            labels: StdMutex::new(Vec::new()),
            should_fail: false,
        });
        let registry = Arc::new(SubagentRegistry::new());
        let executor = SubagentExecutor::new(
            registry.clone(),
            SubagentExecutorConfig {
                isolation_provider: Some(wt_factory.clone()),
                ..SubagentExecutorConfig::default()
            },
        );

        let agent = MockAgent::new("w").with_response("done");
        let def = super::super::types::SubagentDefinition {
            execution_mode: ExecutionMode::Fork,
            isolation: Some("sandbox".to_string()),
            ..super::super::types::SubagentDefinition::new("w", "Writer")
        };
        registry.register(def, Box::new(agent)).await;

        let req = DispatchRequest {
            agent_name: "w".into(),
            task: "work".into(),
            mode_override: None,
            cancel: CancellationToken::new(),
            parent_agent: "parent".into(),
            parent_context: None,
            delegation_policy: DispatchRequest::policy_from_depth(0),
            runtime_context: None,
            message: None,
            prompt_payload: None,
            prompt_context: None,
            constraints: Vec::new(),
            background: false,
        };

        let result = executor.dispatch(req).await.unwrap();
        // Worktree was used (mock diff appended), workspace was NOT.
        assert!(result.output.contains("=== mock diff ==="));
        assert!(
            ws_factory.labels.lock().unwrap().is_empty(),
            "workspace factory must not be invoked when worktree is active"
        );
        assert!(
            !wt_factory.labels.lock().unwrap().is_empty(),
            "worktree factory should have been invoked"
        );
    }

    fn guarded_team_definition(member: &str) -> SubagentDefinition {
        super::super::builder::SubagentBuilder::new("guarded-team")
            .team(super::super::team::TeamSpec {
                strategy: super::super::team::TeamStrategy::Pipeline(vec![member.to_string()]),
                manager: String::new(),
                subagents: Vec::new(),
                config: super::super::team::TeamConfig::default(),
            })
            .build()
    }

    struct RequireActualTeamGuard(Arc<AtomicUsize>);

    #[async_trait::async_trait]
    impl super::super::registry::SubagentRegistrationAdmission for RequireActualTeamGuard {
        async fn admit(
            &self,
            _registration: &super::super::registry::SubagentRegistration,
            request: &DispatchRequest,
        ) -> Result<()> {
            if !request.runtime_context.as_ref().is_some_and(|runtime| {
                runtime
                    .resource_guards
                    .iter()
                    .any(|guard| guard.retains::<DispatchGuardDrop>())
            }) {
                return Err(ReactError::Other(
                    "actual Team member lost its original physical guard".to_string(),
                ));
            }
            self.0.fetch_add(1, Ordering::SeqCst);
            Ok(())
        }
    }

    #[tokio::test]
    async fn team_admission_and_member_invocation_keep_guards_without_retained_runtime_leak()
    -> Result<()> {
        let (registry, executor) = make_executor().await;
        let member = MockAgent::new("guarded-member").with_response("done");
        registry
            .register(
                SubagentDefinition::new("guarded-member", "actual member"),
                Box::new(member.clone()),
            )
            .await;
        registry
            .register(
                guarded_team_definition("guarded-member"),
                Box::new(MockAgent::new("guarded-team")),
            )
            .await;
        let checks = Arc::new(AtomicUsize::new(0));
        registry
            .set_registration_admission(Some(Arc::new(RequireActualTeamGuard(checks.clone()))))
            .await;
        let drops = Arc::new(AtomicUsize::new(0));
        let mut request = unknown_request(ExecutionMode::Team, CancellationToken::new());
        request.agent_name = "guarded-team".to_string();
        request.runtime_context = Some(echo_core::tools::ExternalRunContext {
            run_id: Some("guarded-team-run".to_string()),
            resource_guards: vec![InvocationResourceGuard::new(DispatchGuardDrop(
                drops.clone(),
            ))],
            ..echo_core::tools::ExternalRunContext::default()
        });
        executor.dispatch(request).await?;
        assert_eq!(checks.load(Ordering::SeqCst), 2);
        let contexts = member.take_invocation_contexts();
        assert!(
            contexts
                .first()
                .and_then(|context| context.runtime.as_ref())
                .is_some_and(|runtime| runtime
                    .resource_guards
                    .iter()
                    .any(|guard| guard.retains::<DispatchGuardDrop>()))
        );
        assert_eq!(executor.team_runtime_handles("guarded-team-run").len(), 1);
        assert_eq!(drops.load(Ordering::SeqCst), 0);
        drop(contexts);
        assert_eq!(
            drops.load(Ordering::SeqCst),
            1,
            "retained completed Team runtime leaked invocation lease"
        );
        Ok(())
    }

    #[tokio::test]
    async fn team_caller_drop_keeps_guard_until_original_member_physical_eof() -> Result<()> {
        let (registry, executor) = make_executor().await;
        let dropped = Arc::new(AtomicBool::new(false));
        let started = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        registry
            .register(
                SubagentDefinition::new("held-team-member", "original producer"),
                Box::new(NonCooperativeTeamAgent {
                    dropped: dropped.clone(),
                    started: started.clone(),
                    release: release.clone(),
                }),
            )
            .await;
        registry
            .register(
                guarded_team_definition("held-team-member"),
                Box::new(MockAgent::new("guarded-team")),
            )
            .await;
        let drops = Arc::new(AtomicUsize::new(0));
        let mut request = unknown_request(ExecutionMode::Team, CancellationToken::new());
        request.agent_name = "guarded-team".to_string();
        request.runtime_context = Some(echo_core::tools::ExternalRunContext {
            resource_guards: vec![InvocationResourceGuard::new(DispatchGuardDrop(
                drops.clone(),
            ))],
            ..echo_core::tools::ExternalRunContext::default()
        });
        let caller = tokio::spawn(async move { executor.dispatch(request).await });
        tokio::time::timeout(Duration::from_secs(3), started.notified())
            .await
            .map_err(|error| ReactError::Other(error.to_string()))?;
        caller.abort();
        assert!(caller.await.is_err_and(|error| error.is_cancelled()));
        assert!(!dropped.load(Ordering::SeqCst));
        assert_eq!(drops.load(Ordering::SeqCst), 0);
        release.notify_one();
        tokio::time::timeout(Duration::from_secs(3), async {
            while !dropped.load(Ordering::SeqCst) || drops.load(Ordering::SeqCst) != 1 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .map_err(|error| {
            ReactError::Other(format!(
                "original Team cleanup did not release guard: {error}"
            ))
        })?;
        Ok(())
    }

    #[tokio::test]
    async fn team_unknown_member_settlement_retains_original_invocation_guard() -> Result<()> {
        let (registry, executor) = make_executor().await;
        registry
            .register(
                SubagentDefinition::new("unknown-cleanup", "unknown producer"),
                Box::new(UnknownCleanupAgent {
                    setup: true,
                    panic_setup: false,
                }),
            )
            .await;
        registry
            .register(
                guarded_team_definition("unknown-cleanup"),
                Box::new(MockAgent::new("guarded-team")),
            )
            .await;
        let drops = Arc::new(AtomicUsize::new(0));
        let mut request = unknown_request(ExecutionMode::Team, CancellationToken::new());
        request.agent_name = "guarded-team".to_string();
        request.runtime_context = Some(echo_core::tools::ExternalRunContext {
            resource_guards: vec![InvocationResourceGuard::new(DispatchGuardDrop(
                drops.clone(),
            ))],
            ..echo_core::tools::ExternalRunContext::default()
        });
        let result = executor.dispatch(request).await;
        assert!(matches!(
            result,
            Err(ReactError::ExecutionNotSettled { .. })
        ));
        assert_eq!(
            drops.load(Ordering::SeqCst),
            0,
            "unknown Team producer released physical guard"
        );
        Ok(())
    }

    #[tokio::test]
    async fn direct_teammate_setup_unknown_retains_last_invocation_guard_in_original_keyed_owner()
    -> Result<()> {
        let registry = Arc::new(SubagentRegistry::new());
        registry
            .register(
                SubagentDefinition::new("unknown-cleanup", "direct setup unknown"),
                Box::new(UnknownCleanupAgent {
                    setup: true,
                    panic_setup: false,
                }),
            )
            .await;
        let executor = SubagentExecutor::new(
            registry,
            SubagentExecutorConfig {
                max_concurrent_forks: 1,
                ..SubagentExecutorConfig::default()
            },
        );
        let drops = Arc::new(AtomicUsize::new(0));
        let mut request = unknown_request(ExecutionMode::Sync, CancellationToken::new());
        request.runtime_context = Some(echo_core::tools::ExternalRunContext {
            resource_guards: vec![InvocationResourceGuard::new(DispatchGuardDrop(
                drops.clone(),
            ))],
            ..echo_core::tools::ExternalRunContext::default()
        });
        // This is deliberately the public handle API, not dispatch(mode=Teammate).
        // The default Agent wrapper returns during setup, before it can build
        // an invocation-retaining stream, leaving this the last guard owner.
        let result = executor.dispatch_teammate(request).await?.join().await;
        assert!(
            matches!(result, Err(ReactError::ExecutionNotSettled { run_id, execution_id: Some(execution_id) })
            if run_id == "unknown-original" && execution_id == "unknown-attempt")
        );
        assert_eq!(drops.load(Ordering::SeqCst), 0);
        assert_eq!(executor.local_fork_admission.active_count(), 1);
        // Borrowed-resource retention does not consume a second process slot.
        let probe = executor
            .local_fork_admission
            .issue("direct-teammate-capacity-probe")
            .map_err(|error| ReactError::Other(error.to_string()))?;
        drop(probe);
        assert_eq!(executor.local_fork_admission.active_count(), 1);
        Ok(())
    }

    #[tokio::test]
    async fn direct_teammate_original_eof_releases_guard_after_normal_join_or_observer_drop()
    -> Result<()> {
        for observer_drop in [false, true] {
            let (registry, executor) = make_executor().await;
            let barrier = Arc::new(StreamSettlementBarrier::default());
            let release_terminal = Arc::new(tokio::sync::Notify::new());
            let terminal_seen = Arc::new(tokio::sync::Notify::new());
            let cancelled_seen = Arc::new(tokio::sync::Notify::new());
            let executions = Arc::new(AtomicUsize::new(0));
            let directory = tempfile::tempdir()?;
            let effect = directory.path().join("direct-original-source.txt");
            registry
                .register(
                    SubagentDefinition::new("direct-held", "original direct producer"),
                    Box::new(LiveObservationAgent {
                        barrier: barrier.clone(),
                        release_terminal: release_terminal.clone(),
                        terminal_seen: terminal_seen.clone(),
                        cancelled_seen: cancelled_seen.clone(),
                        effect: effect.clone(),
                        cancelled: observer_drop,
                        executions: executions.clone(),
                    }),
                )
                .await;
            let drops = Arc::new(AtomicUsize::new(0));
            let mut request = unknown_request(ExecutionMode::Sync, CancellationToken::new());
            request.agent_name = "direct-held".to_string();
            request.runtime_context = Some(echo_core::tools::ExternalRunContext {
                run_id: Some("direct-original-source".to_string()),
                resource_guards: vec![InvocationResourceGuard::new(DispatchGuardDrop(
                    drops.clone(),
                ))],
                ..echo_core::tools::ExternalRunContext::default()
            });
            let mut handle = Some(executor.dispatch_teammate(request).await?);
            tokio::time::timeout(Duration::from_secs(3), barrier.started.notified())
                .await
                .map_err(|error| ReactError::Other(error.to_string()))?;
            assert_eq!(executor.local_fork_admission.active_count(), 1);
            assert_eq!(drops.load(Ordering::SeqCst), 0);
            if observer_drop {
                drop(handle.take());
                tokio::time::timeout(Duration::from_secs(3), cancelled_seen.notified())
                    .await
                    .map_err(|error| ReactError::Other(error.to_string()))?;
                assert!(!barrier.physical_stopped.load(Ordering::SeqCst));
                assert_eq!(drops.load(Ordering::SeqCst), 0);
            }
            release_terminal.notify_one();
            tokio::time::timeout(Duration::from_secs(3), terminal_seen.notified())
                .await
                .map_err(|error| ReactError::Other(error.to_string()))?;
            // A valid terminal projection is still not physical cleanup.
            assert!(!barrier.physical_stopped.load(Ordering::SeqCst));
            assert_eq!(drops.load(Ordering::SeqCst), 0);
            assert_eq!(executor.local_fork_admission.active_count(), 1);
            barrier.release_cleanup.notify_one();
            if let Some(handle) = handle {
                let result = handle.join().await?;
                assert_eq!(result.outcome.status, SubagentStatus::Completed);
            }
            tokio::time::timeout(Duration::from_secs(3), async {
                while !barrier.physical_stopped.load(Ordering::SeqCst)
                    || drops.load(Ordering::SeqCst) != 1
                {
                    tokio::task::yield_now().await;
                }
            })
            .await
            .map_err(|error| {
                ReactError::Other(format!("direct original cleanup did not settle: {error}"))
            })?;
            assert_eq!(executor.local_fork_admission.active_count(), 0);
            assert_eq!(executions.load(Ordering::SeqCst), 1);
            assert_eq!(tokio::fs::read(&effect).await?, b"same-source-closed");
        }
        Ok(())
    }
}

#[cfg(test)]
mod canonical_consumer_tests {
    use super::*;
    use crate::agent::subagent::events::SubagentEventBus;
    use echo_core::agent::{
        AgentPhase, AssistantMessageBlock, AssistantPhase, ExecutionStatus, ExecutionStatusKind,
    };
    use futures::future::BoxFuture;
    use futures::stream::BoxStream;
    use std::sync::atomic::{AtomicUsize, Ordering};

    struct NativeSource {
        observed: Arc<Mutex<Vec<serde_json::Value>>>,
        before_eof: Arc<tokio::sync::Notify>,
        release_eof: Arc<tokio::sync::Notify>,
        tail_error: bool,
        safe_final_only: bool,
        unsettled: Option<&'static str>,
    }
    fn status(kind: ExecutionStatusKind, sequence: u64) -> AgentEvent {
        AgentEvent::ExecutionStatus(ExecutionStatus {
            adapter_generated: false,
            execution_id: "native-execution".into(),
            request_id: Some("native-request".into()),
            sequence,
            phase: AgentPhase::Thinking,
            status: kind,
            reason: None,
        })
    }
    fn block(phase: AssistantPhase, text: &str) -> AgentEvent {
        AgentEvent::AssistantMessage {
            block: AssistantMessageBlock {
                provider_source: None,
                block_id: format!("{phase:?}"),
                request_id: "native-request".into(),
                sequence: 0,
                phase,
                delta: text.into(),
                complete: true,
                provider: None,
                reasoning: None,
            },
        }
    }
    impl Agent for NativeSource {
        fn name(&self) -> &str {
            "native-source"
        }
        fn model_name(&self) -> &str {
            "fixture"
        }
        fn system_prompt(&self) -> &str {
            ""
        }
        fn execute<'a>(&'a self, _task: &'a str) -> BoxFuture<'a, Result<String>> {
            Box::pin(async { Err(ReactError::Other("text result fallback forbidden".into())) })
        }
        fn execute_stream<'a>(
            &'a self,
            _task: &'a str,
        ) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
            Box::pin(async { Err(ReactError::Other("text stream downgrade forbidden".into())) })
        }
        fn execute_stream_with_invocation_context<'a>(
            &'a self,
            _task: &'a str,
            _cancel: CancellationToken,
            _invocation: AgentInvocationContext,
        ) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
            Box::pin(async { Err(ReactError::Other("rich Text was downgraded".into())) })
        }
        fn execute_stream_message_with_invocation_context<'a>(
            &'a self,
            message: Message,
            _cancel: CancellationToken,
            invocation: AgentInvocationContext,
        ) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
            Box::pin(async move {
                assert_eq!(
                    invocation.tool_access,
                    Some(echo_core::tools::ToolAccess::ReadOnly)
                );
                self.observed.lock().map_err(|_| ReactError::Other("observation lock poisoned".into()))?.push(serde_json::json!({
                    "message":message, "history":invocation.history,
                    "execution":invocation.runtime.as_ref().and_then(|runtime|runtime.execution_id.clone()),
                }));
                let before_eof = self.before_eof.clone();
                let release_eof = self.release_eof.clone();
                let tail_error = self.tail_error;
                let safe_final_only = self.safe_final_only;
                let unsettled = self.unsettled;
                let stream = async_stream::stream! {
                    let _resources = invocation.resource_guards;
                    yield Ok(status(ExecutionStatusKind::Started, 0));
                    if matches!(unsettled,Some("cancelled"|"failed")) {
                        let mut terminal=status(if unsettled==Some("cancelled") {ExecutionStatusKind::Cancelled} else {ExecutionStatusKind::Failed},1);
                        if let AgentEvent::ExecutionStatus(status)=&mut terminal {status.reason=Some("native-terminal-reason".into());}
                        yield Ok(terminal);before_eof.notify_one();release_eof.notified().await;
                        if tail_error { yield Err(ReactError::Other("real native tail cleanup failed".into())); }
                        return;
                    }
                    yield Ok(block(AssistantPhase::Reasoning, "独立推理"));
                    let progress = block(AssistantPhase::Commentary, "进度");
                    yield Ok(progress.clone()); yield Ok(progress);
                    if !safe_final_only { yield Ok(block(AssistantPhase::FinalAnswer, "最终结果")); }
                    if let Some(kind)=unsettled.filter(|kind|*kind!="duplicate") {
                        yield Err(ReactError::ExecutionNotSettled {run_id:"native-run".into(),execution_id:Some(if kind=="foreign" {"foreign"} else {"native-execution"}.into())});
                    }
                    yield Ok(AgentEvent::LlmUsage { model:"fixture".into(), prompt_tokens:3, completion_tokens:2, total_tokens:5, cached_prompt_tokens:0, cache_creation_prompt_tokens:0, usage_reported:true });
                    let final_text=if safe_final_only {"Guard确认的安全结果"} else {"最终结果"};
                    yield Ok(AgentEvent::FinalAnswer(final_text.into()));
                    let mut terminal=status(ExecutionStatusKind::Settled,1);
                    if let AgentEvent::ExecutionStatus(status)=&mut terminal {
                        if unsettled==Some("synthetic") {status.adapter_generated=true;}
                        if unsettled==Some("foreign") {status.execution_id="foreign".into();}
                    }
                    yield Ok(terminal.clone());
                    if unsettled==Some("duplicate") {
                        yield Err(ReactError::ExecutionNotSettled {run_id:"native-run".into(),execution_id:Some("native-execution".into())});
                        yield Ok(terminal);
                    }
                    before_eof.notify_one(); release_eof.notified().await;
                    if tail_error { yield Err(ReactError::Other("real native tail cleanup failed".into())); }
                };
                Ok(Box::pin(stream) as BoxStream<'a, Result<AgentEvent>>)
            })
        }
    }
    struct GuardDrop(Arc<AtomicUsize>);
    impl Drop for GuardDrop {
        fn drop(&mut self) {
            self.0.fetch_add(1, Ordering::SeqCst);
        }
    }

    #[tokio::test]
    async fn canonical_subagent_keeps_rich_text_and_waits_for_source_eof() -> Result<()> {
        for (tail_error, safe_final_only, unsettled) in [
            (false, false, None),
            (true, false, None),
            (false, true, None),
            (false, false, Some("synthetic")),
            (false, false, Some("foreign")),
            (false, false, Some("valid")),
            (false, false, Some("duplicate")),
            (false, false, Some("cancelled")),
            (false, false, Some("failed")),
            (true, false, Some("cancelled")),
            (true, false, Some("failed")),
        ] {
            let observed = Arc::new(Mutex::new(Vec::new()));
            let before_eof = Arc::new(tokio::sync::Notify::new());
            let release_eof = Arc::new(tokio::sync::Notify::new());
            let drops = Arc::new(AtomicUsize::new(0));
            let source = Arc::new(NativeSource {
                observed: observed.clone(),
                before_eof: before_eof.clone(),
                release_eof: release_eof.clone(),
                tail_error,
                safe_final_only,
                unsettled,
            });
            let mut current = Message::user("带元数据的文本 🧭".into());
            current.name = Some("original-name".into());
            current.role = echo_core::llm::types::Role::System;
            let expected = serde_json::to_value(&current)?;
            let prior = Message::user("原history".into());
            let expected_history = serde_json::to_value(vec![prior.clone()])?;
            let invocation = AgentInvocationContext {
                runtime: Some(echo_core::tools::ExternalRunContext {
                    run_id: Some("native-run".into()),
                    turn_id: Some("native-turn".into()),
                    execution_id: Some("native-execution".into()),
                    ..Default::default()
                }),
                tool_access: Some(echo_core::tools::ToolAccess::ReadOnly),
                resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(GuardDrop(
                    drops.clone(),
                ))],
                ..Default::default()
            };
            let identity = EventIdentity::from_invocation(&invocation)?;
            let bus = SubagentEventBus::new();
            let mut events = bus.subscribe();
            let publisher = bus.publisher(
                identity.clone(),
                SubagentInvocationIdentity::from_lineage(
                    "parent",
                    "native-source",
                    &identity,
                    None,
                )?,
            )?;
            publisher.emit(SubagentEvent::DispatchStarted {
                parent: "parent".into(),
                agent: "native-source".into(),
                mode: ExecutionMode::Sync,
                task: "typed".into(),
                execution_id: Some("native-execution".into()),
                run_id: Some("native-run".into()),
                conversation_id: None,
                message_id: None,
                background: false,
            })?;
            let compiled = CompiledSubagentInvocation {
                messages: vec![prior, current],
                ..Default::default()
            };
            let mut running = tokio::spawn(async move {
                SubagentExecutor::execute_agent_streaming(
                    source,
                    compiled,
                    CancellationToken::new(),
                    invocation,
                    "parent",
                    "native-source",
                    ExecutionMode::Sync,
                    Instant::now(),
                    Some("native-execution".into()),
                    Some("native-run".into()),
                    None,
                    publisher,
                    Arc::new(Mutex::new(None)),
                )
                .await
            });
            tokio::select! {
                entered = tokio::time::timeout(Duration::from_secs(2), before_eof.notified()) => {
                    entered.map_err(|_| ReactError::Other("source did not reach EOF gate".into()))?;
                },
                early = &mut running => {
                    let result = early.map_err(|error| ReactError::Other(error.to_string()))?;
                    return match result {
                        Err(error) => Err(error),
                        Ok(_) => Err(ReactError::Other("source returned before original EOF gate".into())),
                    };
                },
            }
            assert!(
                !running.is_finished(),
                "Final确认/Settled不能替代原source物理EOF"
            );
            assert_eq!(drops.load(Ordering::SeqCst), 0);
            release_eof.notify_one();
            let result = running
                .await
                .map_err(|error| ReactError::Other(error.to_string()))?;
            if unsettled == Some("cancelled") {
                assert!(
                    matches!(result,Err(ReactError::Agent(error)) if matches!(error.as_ref(),AgentError::Cancelled(reason) if reason=="native-terminal-reason"))
                );
            } else if unsettled == Some("failed") {
                assert!(
                    matches!(result,Err(ReactError::Other(reason)) if reason=="native-terminal-reason")
                );
            } else if matches!(unsettled, Some("synthetic" | "foreign" | "duplicate")) {
                assert!(
                    matches!(result,Err(ReactError::ExecutionNotSettled {run_id,execution_id:Some(execution)}) if run_id=="native-run" && execution==if unsettled==Some("foreign") {"foreign"} else {"native-execution"})
                );
            } else if tail_error {
                assert!(result.is_err());
            } else {
                let result = result?;
                assert_eq!(
                    result.output,
                    if safe_final_only {
                        "Guard确认的安全结果"
                    } else {
                        "最终结果"
                    }
                );
                assert_eq!(result.tokens_used, Some(5));
            }
            let rows = observed
                .lock()
                .map_err(|_| ReactError::Other("observation lock poisoned".into()))?;
            let row = rows
                .first()
                .ok_or_else(|| ReactError::Other("typed request missing".into()))?;
            assert_eq!(row.get("message"), Some(&expected));
            assert_eq!(row.get("history"), Some(&expected_history));
            let mut text = String::new();
            let mut reasoning = String::new();
            while let Ok(event) = events.try_recv() {
                match event.as_ref() {
                    SubagentEvent::DispatchTokenDelta { content, .. } => text.push_str(content),
                    SubagentEvent::DispatchThinkingDelta { content, .. } => {
                        reasoning.push_str(content)
                    }
                    _ => {}
                }
            }
            assert_eq!(
                text,
                if matches!(unsettled, Some("cancelled" | "failed")) {
                    ""
                } else if safe_final_only {
                    "进度Guard确认的安全结果"
                } else {
                    "进度最终结果"
                },
                "重复block及Final确认不能双拼，Guard安全最终正文不能漏"
            );
            assert_eq!(
                reasoning,
                if matches!(unsettled, Some("cancelled" | "failed")) {
                    ""
                } else {
                    "独立推理"
                }
            );
            assert_eq!(drops.load(Ordering::SeqCst), 1);
        }
        Ok(())
    }
    #[tokio::test]
    async fn attachment_failure_drain_uses_the_same_native_terminal_qualification() -> Result<()> {
        for mode in ["valid", "synthetic", "foreign"] {
            let mut output = echo_core::agent::AgentOutputProjection::default();
            let pending = Arc::new(Mutex::new(Some(ReactError::ExecutionNotSettled {
                run_id: "native-run".into(),
                execution_id: Some("native-execution".into()),
            })));
            let first = Arc::new(Mutex::new(Some(ReactError::Other(
                "original attachment failure".into(),
            ))));
            let mut terminal = status(ExecutionStatusKind::Settled, 1);
            if let AgentEvent::ExecutionStatus(status) = &mut terminal {
                if mode == "synthetic" {
                    status.adapter_generated = true;
                }
                if mode == "foreign" {
                    status.execution_id = "foreign".into();
                }
            }
            let mut source = futures::stream::iter(vec![
                Ok(status(ExecutionStatusKind::Started, 0)),
                Ok(terminal),
            ]);
            SubagentExecutor::drain_source_stream(
                &mut source,
                &first,
                &mut output,
                &pending,
                "native-run",
            )
            .await;
            assert_eq!(
                pending
                    .lock()
                    .map_err(|_| ReactError::Other("pending lock poisoned".into()))?
                    .is_none(),
                mode == "valid"
            );
            assert!(
                matches!(SubagentExecutor::take_first_cause(&first),Some(ReactError::Other(message)) if message=="original attachment failure")
            );
        }
        Ok(())
    }
}
