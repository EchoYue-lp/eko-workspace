use super::{ReactAgent, merge_model_profile_resolution};
use crate::agent::ReactAgentBuilder;
use crate::agent::config::{AgentConfig, DEFAULT_TOKEN_LIMIT};
#[cfg(feature = "subagent")]
use crate::agent::subagent::SubagentBuilder;
#[cfg(feature = "subagent")]
use crate::agent::subagent::SubagentRegistry;
use crate::agent::{Agent, AgentHandle};
use crate::llm::types::{Message, Role};
#[cfg(feature = "shell")]
use crate::sandbox::SandboxManager;
#[cfg(feature = "shell")]
use crate::skills::builtin::ShellSkill;
use crate::skills::external::loader::DiscoveryScope;
use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};
use crate::testing::{FailingMockAgent, MockAgent, MockTool};
use serde_json::json;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::time::SystemTime;

struct SharedSandboxCleanupProbe {
    active: AtomicBool,
    cleanup_calls: AtomicUsize,
}

#[test]
fn model_profile_merge_retains_provider_and_exact_facts() {
    use echo_core::llm::capabilities::{
        ModelFactConfidence, ModelFactMetadata, ModelFactSet, ModelFactSource,
        ModelProfileOverride, ModelProfileResolver,
    };

    let now = SystemTime::now();
    let current = ModelProfileResolver::new()
        .register_provider_facts(
            "openai",
            ModelFactSet::new(
                ModelFactMetadata::new(
                    ModelFactSource::ProviderAdapter,
                    "test:provider",
                    "provider-v1",
                    now,
                    None,
                    ModelFactConfidence::VERIFIED,
                ),
                None,
                ModelProfileOverride {
                    max_output_tokens: Some(8_000),
                    ..Default::default()
                },
            ),
        )
        .register_exact_model_facts(
            "openai",
            "gpt-5-test",
            ModelFactSet::new(
                ModelFactMetadata::new(
                    ModelFactSource::ExactModel,
                    "test:exact",
                    "model-v1",
                    now,
                    None,
                    ModelFactConfidence::VERIFIED,
                ),
                None,
                ModelProfileOverride {
                    context_window: Some(64_000),
                    ..Default::default()
                },
            ),
        )
        .register_explicit_override(
            "openai",
            "gpt-5-test",
            ModelFactSet::new(
                ModelFactMetadata::new(
                    ModelFactSource::CallerOverride,
                    "test:legacy-caller",
                    "caller-v1",
                    now,
                    None,
                    ModelFactConfidence::VERIFIED,
                ),
                None,
                ModelProfileOverride {
                    context_window: Some(48_000),
                    ..Default::default()
                },
            ),
        )
        .resolve_at("openai", "gpt-5-test", now);
    let fresh = ModelProfileResolver::new()
        .register_provider_facts(
            "openai",
            ModelFactSet::new(
                ModelFactMetadata::new(
                    ModelFactSource::ProviderAdapter,
                    "test:provider",
                    "provider-v2",
                    now,
                    None,
                    ModelFactConfidence::VERIFIED,
                ),
                None,
                ModelProfileOverride {
                    max_output_tokens: Some(12_000),
                    ..Default::default()
                },
            ),
        )
        .register_exact_model_facts(
            "openai",
            "gpt-5-test",
            ModelFactSet::new(
                ModelFactMetadata::new(
                    ModelFactSource::ExactModel,
                    "test:exact",
                    "model-v2",
                    now,
                    None,
                    ModelFactConfidence::VERIFIED,
                ),
                None,
                ModelProfileOverride {
                    context_window: Some(96_000),
                    ..Default::default()
                },
            ),
        )
        .register_explicit_override(
            "openai",
            "gpt-5-test",
            ModelFactSet::new(
                ModelFactMetadata::new(
                    ModelFactSource::CallerOverride,
                    "test:fresh-caller",
                    "caller-v2",
                    now,
                    None,
                    ModelFactConfidence::VERIFIED,
                ),
                None,
                ModelProfileOverride {
                    max_output_tokens: Some(14_000),
                    ..Default::default()
                },
            ),
        )
        .resolve_at("openai", "gpt-5-test", now);
    let merged = merge_model_profile_resolution(Some(&current), fresh);

    assert!(
        merged
            .registered_facts
            .iter()
            .any(|facts| facts.metadata.version == "provider-v2")
    );
    assert!(
        !merged
            .registered_facts
            .iter()
            .any(|facts| facts.metadata.version == "provider-v1")
    );
    assert!(
        merged
            .registered_facts
            .iter()
            .any(|facts| facts.metadata.version == "model-v2")
    );
    assert!(
        merged
            .registered_facts
            .iter()
            .any(|facts| facts.metadata.version == "caller-v1")
    );
    assert!(
        merged
            .registered_facts
            .iter()
            .any(|facts| facts.metadata.version == "caller-v2")
    );
    assert_eq!(merged.profile.context_window, Some(48_000));
    assert_eq!(merged.profile.max_output_tokens, Some(14_000));
}

#[test]
fn model_profile_merge_does_not_let_empty_fresh_fact_mask_lower_fact() {
    use echo_core::llm::capabilities::{
        ModelFactConfidence, ModelFactMetadata, ModelFactSet, ModelFactSource,
        ModelProfileOverride, ModelProfileResolver,
    };

    let now = SystemTime::now();
    let current = ModelProfileResolver::new()
        .register_exact_model_facts(
            "openai",
            "future-model",
            ModelFactSet::new(
                ModelFactMetadata::new(
                    ModelFactSource::ExactModel,
                    "test:exact",
                    "model-v1",
                    now,
                    None,
                    ModelFactConfidence::VERIFIED,
                ),
                None,
                ModelProfileOverride {
                    context_window: Some(64_000),
                    ..Default::default()
                },
            ),
        )
        .resolve_at("openai", "future-model", now);
    let fresh = ModelProfileResolver::new()
        .register_exact_model_facts(
            "openai",
            "future-model",
            ModelFactSet::new(
                ModelFactMetadata::new(
                    ModelFactSource::ExactModel,
                    "test:empty",
                    "model-v2-empty",
                    now,
                    None,
                    ModelFactConfidence::VERIFIED,
                ),
                None,
                ModelProfileOverride::default(),
            ),
        )
        .resolve_at("openai", "future-model", now);

    let merged = merge_model_profile_resolution(Some(&current), fresh);
    assert_eq!(merged.profile.context_window, Some(64_000));
}

impl crate::sandbox::SandboxExecutor for SharedSandboxCleanupProbe {
    fn name(&self) -> &str {
        "shared-cleanup-probe"
    }

    fn isolation_level(&self) -> crate::sandbox::IsolationLevel {
        crate::sandbox::IsolationLevel::None
    }

    fn is_available(&self) -> futures::future::BoxFuture<'_, bool> {
        Box::pin(async { false })
    }

    fn execute(
        &self,
        _command: crate::sandbox::SandboxCommand,
    ) -> futures::future::BoxFuture<'_, crate::error::Result<crate::sandbox::ExecutionResult>> {
        Box::pin(async {
            Err(crate::error::ReactError::Other(
                "cleanup probe does not execute commands".to_string(),
            ))
        })
    }

    fn cleanup(&self) -> futures::future::BoxFuture<'_, crate::error::Result<()>> {
        Box::pin(async move {
            self.cleanup_calls.fetch_add(1, Ordering::SeqCst);
            if self.active.load(Ordering::SeqCst) {
                Err(crate::error::ReactError::Sandbox(Box::new(
                    crate::error::SandboxError::IoError(
                        "shared sandbox owner remains active".to_string(),
                    ),
                )))
            } else {
                Ok(())
            }
        })
    }
}

#[tokio::test]
async fn agent_close_reports_shared_sandbox_owner_and_retries_after_settlement()
-> crate::error::Result<()> {
    let sandbox = Arc::new(SharedSandboxCleanupProbe {
        active: AtomicBool::new(true),
        cleanup_calls: AtomicUsize::new(0),
    });
    let mut first = ReactAgent::new(AgentConfig::new("test-model", "first", "system"));
    let mut second = ReactAgent::new(AgentConfig::new("test-model", "second", "system"));
    first.set_sandbox_executor(sandbox.clone());
    second.set_sandbox_executor(sandbox.clone());

    let first_error =
        first.close().await.err().ok_or_else(|| {
            crate::error::ReactError::Other("active sandbox was hidden".to_string())
        })?;
    assert!(
        first_error
            .to_string()
            .contains("shared sandbox owner remains active")
    );
    assert!(sandbox.active.load(Ordering::SeqCst));
    assert!(second.close().await.is_err());
    assert_eq!(sandbox.cleanup_calls.load(Ordering::SeqCst), 2);

    sandbox.active.store(false, Ordering::SeqCst);
    first.close().await?;
    second.close().await?;
    assert_eq!(sandbox.cleanup_calls.load(Ordering::SeqCst), 4);
    Ok(())
}

fn external_context_with_guards(
    resource_guards: Vec<echo_core::tools::InvocationResourceGuard>,
) -> echo_core::tools::ExternalRunContext {
    echo_core::tools::ExternalRunContext {
        conversation_id: None,
        run_id: None,
        turn_id: None,
        execution_id: None,
        isolation_id: None,
        message_id: None,
        cancel: None,
        trace_sink: None,
        delegation_policy: None,
        resource_guards,
        subagent_lineage: None,
        uplink: None,
    }
}

struct ReentrantGuardProbe {
    agent: std::sync::Weak<ReactAgent>,
    observed_unlocked: Arc<AtomicBool>,
}

impl Drop for ReentrantGuardProbe {
    fn drop(&mut self) {
        let observed = self.agent.upgrade().is_some_and(|agent| {
            // 当前snapshot析构不保有Agent的执行锁或ActiveTurn观察锁。
            let _ = agent.current_run_id();
            agent.execution_mutex.try_lock().is_ok()
        });
        self.observed_unlocked.store(observed, Ordering::SeqCst);
    }
}

struct SlowGuardDrop {
    entered: std::sync::mpsc::Sender<()>,
    release: std::sync::Mutex<std::sync::mpsc::Receiver<()>>,
}

impl Drop for SlowGuardDrop {
    fn drop(&mut self) {
        let _ = self.entered.send(());
        let _ = self
            .release
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .recv_timeout(std::time::Duration::from_secs(2));
    }
}

fn test_llm_config(model: &str) -> crate::llm::LlmConfig {
    crate::llm::LlmConfig {
        provider_name: Some("test-provider".to_string()),
        api_protocol: crate::llm::LlmApiProtocol::ChatCompletions,
        base_url: "https://api.example.test/v1/chat/completions".to_string(),
        api_key: "test-key".to_string(),
        model: model.to_string(),
        input_modalities: crate::llm::ModelInputModality::text_only(),
        thinking_protocol: crate::llm::ThinkingProtocol::None,
        timeouts: crate::llm::LlmTimeouts::default(),
    }
}

async fn model_publication_http_request(
    socket: &mut tokio::net::TcpStream,
) -> crate::error::Result<serde_json::Value> {
    use tokio::io::AsyncReadExt;
    let mut bytes = Vec::new();
    let mut chunk = [0; 4096];
    loop {
        let count = socket.read(&mut chunk).await?;
        if count == 0 || bytes.len() > 2_000_000 {
            return Err(std::io::Error::other("incomplete model publication HTTP request").into());
        }
        bytes.extend_from_slice(chunk.get(..count).unwrap_or_default());
        let Some(header_end) = bytes.windows(4).position(|value| value == b"\r\n\r\n") else {
            continue;
        };
        let headers = String::from_utf8_lossy(bytes.get(..header_end).unwrap_or_default());
        let length = headers
            .lines()
            .filter_map(|line| line.split_once(':'))
            .find(|(name, _)| name.eq_ignore_ascii_case("content-length"))
            .and_then(|(_, value)| value.trim().parse::<usize>().ok())
            .ok_or_else(|| std::io::Error::other("missing model publication content length"))?;
        let body_start = header_end.saturating_add(4);
        let body_end = body_start.saturating_add(length);
        if let Some(body) = bytes.get(body_start..body_end) {
            return Ok(serde_json::from_slice(body)?);
        }
    }
}

async fn model_publication_http_server(
    listener: tokio::net::TcpListener,
) -> crate::error::Result<Vec<serde_json::Value>> {
    use tokio::io::AsyncWriteExt;
    let mut requests = Vec::new();
    for _ in 0..2 {
        let (mut socket, _) = listener.accept().await?;
        let request = model_publication_http_request(&mut socket).await?;
        // Exercise the concrete adapter's real streaming request, including
        // its required semantic terminal, without a substitute LlmClient.
        let delta = json!({"choices":[{"index":0,"delta":{"role":"assistant","content":"ok"},"finish_reason":null}]});
        let stop = json!({"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]});
        let body = format!("data: {delta}\n\ndata: {stop}\n\ndata: [DONE]\n\n");
        let response = format!(
            "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
            body.len(),
        );
        socket.write_all(response.as_bytes()).await?;
        requests.push(request);
    }
    Ok(requests)
}

#[tokio::test]
async fn runtime_model_publication_switches_actual_http() -> crate::error::Result<()> {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
    let mut config = test_llm_config("model-a");
    config.base_url = format!("http://{}/v1/chat/completions", listener.local_addr()?);
    let server = tokio::spawn(async move {
        tokio::time::timeout(
            std::time::Duration::from_secs(10),
            model_publication_http_server(listener),
        )
        .await
        .map_err(|error| std::io::Error::other(error.to_string()))?
    });
    let client: Arc<dyn crate::llm::LlmClient> = Arc::from(config.build_client()?);
    let mut agent = ReactAgent::new_with_configured_llm_client(
        AgentConfig::new("model-a", "model-publication", "system")
            .enable_tool(false)
            .auto_project_rules(false)
            .session_id("same-session")
            .conversation_id("same-conversation"),
        client,
        config,
    )?;
    assert_eq!(Agent::chat(&agent, "first request").await?, "ok");
    // Compatible with the original infallible setter for the natural red
    // observation; the real HTTP assertion still rejects a failed rebind.
    let _ = agent.set_model("model-b");
    assert_eq!(Agent::chat(&agent, "second request").await?, "ok");
    let requests = server
        .await
        .map_err(|error| std::io::Error::other(error.to_string()))??;
    let models: Vec<_> = requests
        .iter()
        .map(|request| request.get("model"))
        .collect();
    assert_eq!(models, [Some(&json!("model-a")), Some(&json!("model-b"))]);
    let second = requests
        .get(1)
        .ok_or_else(|| std::io::Error::other("second model request missing"))?;
    assert!(second.to_string().contains("first request"));
    assert!(second.to_string().contains("second request"));
    assert_eq!(agent.model_name(), "model-b");
    assert_eq!(
        agent.llm_client().map(|client| client.model_name()),
        Some("model-b")
    );
    Ok(())
}

fn model_publication_state(agent: &ReactAgent) -> serde_json::Value {
    json!({
        "model": agent.model_name(),
        "config": agent.llm_config(),
        "profile": format!("{:?}", agent.config.model_profile),
        "temperature": agent.config.get_temperature(),
        "max_tokens": agent.config.get_max_tokens(),
        "thinking": format!("{:?}", agent.thinking()),
    })
}

#[test]
fn runtime_model_publication_custom_client_rejects_rebind_without_stale_config()
-> crate::error::Result<()> {
    for builder_injection in [false, true] {
        let config = test_llm_config("model-a");
        let client: Arc<dyn crate::llm::LlmClient> = Arc::from(config.build_client()?);
        let mut agent = ReactAgent::new_with_configured_llm_client(
            AgentConfig::minimal("model-a", "test"),
            client,
            config,
        )?;
        agent.set_temperature(Some(0.25));
        agent.set_max_tokens(Some(1024));
        let custom: Arc<dyn crate::llm::LlmClient> =
            Arc::new(crate::testing::MockLlmClient::new().with_model_name("custom-model"));
        if builder_injection {
            agent = agent.with_llm_client(Arc::clone(&custom));
        } else {
            agent.set_llm_client(Arc::clone(&custom));
        }
        assert!(agent.llm_config().is_none());
        let before = model_publication_state(&agent);
        agent.set_model("custom-model")?;
        let error = agent.set_model("model-b");
        assert!(matches!(error, Err(crate::error::ReactError::Config(error))
            if matches!(error.as_ref(), crate::error::ConfigError::MissingConfig(..))));
        assert_eq!(model_publication_state(&agent), before);
        assert!(
            agent
                .llm_client()
                .is_some_and(|client| Arc::ptr_eq(client, &custom))
        );
    }
    Ok(())
}

#[test]
fn runtime_model_publication_noop_and_failed_construction_are_inert() -> crate::error::Result<()> {
    let mut agent = ReactAgent::new(AgentConfig::minimal("model-a", "test"));
    agent.set_llm_config(test_llm_config("model-a"))?;
    let client = agent
        .llm_client()
        .cloned()
        .ok_or_else(|| std::io::Error::other("configured client missing"))?;
    let before = model_publication_state(&agent);
    agent.set_model("model-a")?;
    assert!(
        agent
            .llm_client()
            .is_some_and(|value| Arc::ptr_eq(value, &client))
    );
    for name in ["", " \t\n"] {
        assert!(
            matches!(agent.set_model(name), Err(crate::error::ReactError::Config(error))
            if matches!(error.as_ref(), crate::error::ConfigError::MissingConfig(..)))
        );
        assert_eq!(model_publication_state(&agent), before);
    }
    let mut invalid = test_llm_config("model-b");
    invalid.api_key = "invalid\nheader".to_string();
    assert!(agent.set_llm_config(invalid.clone()).is_err());
    assert_eq!(model_publication_state(&agent), before);
    assert!(
        agent
            .set_sourced_llm_config(crate::llm::SourcedLlmConfig::new(invalid))
            .is_err()
    );
    assert_eq!(model_publication_state(&agent), before);
    assert!(
        agent
            .llm_client()
            .is_some_and(|value| Arc::ptr_eq(value, &client))
    );

    // A legacy inconsistent display/config pair must not short-circuit a
    // requested rebind just because the display already says model-b.
    agent.config.model_name = "model-b".to_string();
    agent.set_model("model-b")?;
    assert_eq!(
        agent.llm_client().map(|value| value.model_name()),
        Some("model-b")
    );
    assert!(
        !agent
            .llm_client()
            .is_some_and(|value| Arc::ptr_eq(value, &client))
    );
    Ok(())
}

#[test]
fn runtime_model_publication_self_builders_preserve_state_on_failure() -> crate::error::Result<()> {
    for sourced in [false, true] {
        let mut agent = ReactAgent::new(AgentConfig::minimal("model-a", "test"));
        agent.set_llm_config(test_llm_config("model-a"))?;
        let before = model_publication_state(&agent);
        let mut invalid = test_llm_config("model-b");
        invalid.api_key = "invalid\nheader".to_string();
        assert!(
            crate::agent::ReactAgentBuilder::new()
                .llm_config(invalid.clone())
                .build()
                .is_err()
        );
        agent = if sourced {
            agent.with_sourced_llm_config(crate::llm::SourcedLlmConfig::new(invalid))
        } else {
            agent.with_llm_config(invalid)
        };
        assert_eq!(model_publication_state(&agent), before);
    }
    Ok(())
}

#[test]
fn runtime_model_publication_sourced_facts_keep_precedence_and_expiry() -> crate::error::Result<()>
{
    use echo_core::llm::capabilities::{
        ModelFactConfidence, ModelFactMetadata, ModelFactSet, ModelFactSource, ModelProfile,
        ModelProfileOverride,
    };
    let mut old = ModelProfile::from_provider_name("model-a", "test-provider");
    old.context_window = Some(32_000);
    old.prompt_suffix = Some("retained complementary instruction".to_string());
    let mut agent = ReactAgent::new(AgentConfig::minimal("model-a", "test").model_profile(old));
    let fact = |version: &str, window, expired: bool| {
        ModelFactSet::new(
            ModelFactMetadata::new(
                ModelFactSource::CallerOverride,
                "test:runtime-publication",
                version,
                SystemTime::UNIX_EPOCH,
                expired.then_some(SystemTime::UNIX_EPOCH + std::time::Duration::from_secs(1)),
                ModelFactConfidence::VERIFIED,
            ),
            None,
            ModelProfileOverride {
                context_window: Some(window),
                ..Default::default()
            },
        )
    };
    agent.set_sourced_llm_config(test_llm_config("model-a").with_model_override(fact(
        "fresh-64k",
        64_000,
        false,
    )))?;
    let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
    assert_eq!(snapshot.config.token_limit, 64_000);
    assert!(
        agent
            .config
            .model_profile
            .as_ref()
            .is_some_and(|value| value.profile.prompt_suffix.as_deref()
                == Some("retained complementary instruction"))
    );
    agent.set_sourced_llm_config(test_llm_config("model-a").with_model_override(fact(
        "expired-8k",
        8_000,
        true,
    )))?;
    let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
    assert_eq!(snapshot.config.token_limit, 64_000);
    assert!(
        snapshot
            .config
            .ignored_model_facts
            .iter()
            .any(|value| value.version == "expired-8k")
    );
    Ok(())
}

#[tokio::test]
async fn runtime_model_publication_rebind_refreshes_implicit_not_explicit_budget()
-> crate::error::Result<()> {
    for explicit in [false, true] {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
        let mut config = test_llm_config("model-a");
        config.base_url = format!("http://{}/v1/chat/completions", listener.local_addr()?);
        let server = tokio::spawn(async move {
            tokio::time::timeout(
                std::time::Duration::from_secs(10),
                model_publication_http_server(listener),
            )
            .await
            .map_err(|error| std::io::Error::other(error.to_string()))?
        });
        let mut old = echo_core::llm::capabilities::ModelProfile::from_provider_name(
            "model-a",
            "test-provider",
        );
        old.context_window = Some(32_000);
        let mut agent_config = AgentConfig::minimal("model-a", "test")
            .auto_project_rules(false)
            .enable_tool(false)
            .model_profile(old);
        if explicit {
            agent_config = agent_config.token_limit(100_000);
        }
        let client: Arc<dyn crate::llm::LlmClient> = Arc::from(config.build_client()?);
        let mut agent =
            ReactAgent::new_with_configured_llm_client(agent_config, client, config.clone())?;
        assert_eq!(Agent::chat(&agent, "before switch").await?, "ok");
        agent.set_model("model-b")?;
        assert_eq!(Agent::chat(&agent, "after switch").await?, "ok");
        let requests = server
            .await
            .map_err(|error| std::io::Error::other(error.to_string()))??;
        assert_eq!(
            requests
                .iter()
                .filter_map(|value| value.get("model").and_then(|value| value.as_str()))
                .collect::<Vec<_>>(),
            ["model-a", "model-b"]
        );
        let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
        let expected = if explicit {
            100_000
        } else {
            DEFAULT_TOKEN_LIMIT
        };
        assert_eq!(snapshot.config.token_limit, expected);
        assert_eq!(
            snapshot
                .config
                .token_budget
                .as_ref()
                .map(|budget| budget.total_window()),
            Some(expected)
        );
        assert!(
            agent
                .config
                .model_profile
                .as_ref()
                .is_some_and(|value| value.profile.model_name == "model-b"
                    && value.profile.context_window != Some(32_000))
        );
        // The actual Context was updated by the second real turn's prepare.
        // 90k of request overhead fits 128k's input allowance, but not 100k's.
        assert_eq!(
            agent
                .memory
                .context
                .lock()
                .await
                .should_compress_with_overhead(90_000),
            explicit
        );
        assert_eq!(
            agent.llm_config().map(|value| (
                &value.base_url,
                &value.api_key,
                value.api_protocol,
                value.timeouts
            )),
            Some((
                &config.base_url,
                &config.api_key,
                config.api_protocol,
                config.timeouts
            ))
        );
    }
    Ok(())
}

struct ModelPublicationProfileClient {
    inner: crate::testing::MockLlmClient,
    profile: echo_core::llm::capabilities::ModelProfileResolution,
    queries: Arc<AtomicUsize>,
}

impl crate::llm::LlmClient for ModelPublicationProfileClient {
    fn chat(
        &self,
        request: crate::llm::ChatRequest,
    ) -> futures::future::BoxFuture<'_, crate::error::Result<crate::llm::ChatResponse>> {
        crate::llm::LlmClient::chat(&self.inner, request)
    }
    fn chat_stream(
        &self,
        request: crate::llm::ChatRequest,
    ) -> futures::future::BoxFuture<
        '_,
        crate::error::Result<
            futures::stream::BoxStream<'static, crate::error::Result<crate::llm::ChatChunk>>,
        >,
    > {
        crate::llm::LlmClient::chat_stream(&self.inner, request)
    }
    fn model_name(&self) -> &str {
        crate::llm::LlmClient::model_name(&self.inner)
    }
    fn model_profile_resolution(&self) -> echo_core::llm::capabilities::ModelProfileResolution {
        self.queries.fetch_add(1, Ordering::SeqCst);
        self.profile.clone()
    }
}

#[tokio::test]
async fn configured_client_constructor_keeps_arc_config_and_initial_budget()
-> crate::error::Result<()> {
    for explicit in [false, true] {
        let queries = Arc::new(AtomicUsize::new(0));
        let mut profile = echo_core::llm::capabilities::ModelProfile::from_provider_name(
            "model-a",
            "test-provider",
        );
        profile.context_window = Some(64_000);
        let client: Arc<dyn crate::llm::LlmClient> = Arc::new(ModelPublicationProfileClient {
            inner: crate::testing::MockLlmClient::new().with_model_name("model-a"),
            profile: echo_core::llm::capabilities::ModelProfileResolution::from_explicit_profile(
                profile,
                SystemTime::now(),
            ),
            queries: Arc::clone(&queries),
        });
        let original = test_llm_config("model-a");
        let mut config = AgentConfig::minimal("model-a", "test")
            .temperature(Some(0.25))
            .max_tokens(Some(1024))
            .auto_project_rules(false);
        if explicit {
            config = config.token_limit(100_000);
        }
        let mut agent = ReactAgent::new_with_configured_llm_client(
            config,
            Arc::clone(&client),
            original.clone(),
        )?;
        // Count only construction: invocation safe points may query again.
        assert_eq!(queries.load(Ordering::SeqCst), 1);
        assert!(
            agent
                .llm_client()
                .is_some_and(|value| Arc::ptr_eq(value, &client))
        );
        assert_eq!(
            serde_json::to_value(agent.llm_config())?,
            serde_json::to_value(Some(&original))?
        );
        assert_eq!(agent.config.token_limit_explicit, explicit);
        assert_eq!(
            agent.config.token_limit,
            if explicit { 100_000 } else { 64_000 }
        );
        assert_eq!(agent.config.get_temperature(), Some(0.25));
        assert_eq!(agent.config.get_max_tokens(), Some(1024));
        assert!(agent.thinking().is_none());
        // A compressible message distinguishes the actual initial windows.
        // A system-only view has nothing compressible even with zero allowance.
        {
            let mut context = agent.memory.context.lock().await;
            context.push(Message::user("budget probe".to_string()));
            assert_eq!(context.should_compress_with_overhead(70_000), !explicit);
        }
        agent.set_model("model-a")?;
        assert_eq!(queries.load(Ordering::SeqCst), 1);
        assert!(
            agent
                .llm_client()
                .is_some_and(|value| Arc::ptr_eq(value, &client))
        );
    }
    Ok(())
}

#[test]
fn configured_client_constructor_rejects_bad_pairs_without_query_or_secret()
-> crate::error::Result<()> {
    let sentinel = "configured-client-private-key-sentinel";
    for (client_model, config_model) in [
        ("", ""),
        ("model-a", ""),
        ("", "model-a"),
        ("model-a", "model-b"),
    ] {
        let queries = Arc::new(AtomicUsize::new(0));
        let client: Arc<dyn crate::llm::LlmClient> = Arc::new(ModelPublicationProfileClient {
            inner: crate::testing::MockLlmClient::new().with_model_name(client_model),
            profile: echo_core::llm::capabilities::ModelProfileResolution::from_explicit_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    client_model,
                    "test-provider",
                ),
                SystemTime::now(),
            ),
            queries: Arc::clone(&queries),
        });
        let mut original = test_llm_config(config_model);
        original.api_key = sentinel.to_string();
        let result = ReactAgent::new_with_configured_llm_client(
            AgentConfig::minimal("model-a", "test"),
            Arc::clone(&client),
            original,
        );
        let error = match result {
            Err(error) => error,
            Ok(_) => {
                return Err(std::io::Error::other("invalid configured pair was accepted").into());
            }
        };
        assert!(matches!(&error, crate::error::ReactError::Config(value)
            if matches!(value.as_ref(), crate::error::ConfigError::ConfigFileError(..))));
        assert!(!format!("{error:?} {error}").contains(sentinel));
        assert_eq!(queries.load(Ordering::SeqCst), 0);
        assert_eq!(Arc::strong_count(&client), 1);
    }
    // Existing public paths have different contracts: custom Arc loses rebuild
    // config; config construction builds a distinct Arc. Neither is this seam.
    let original = test_llm_config("model-a");
    let client: Arc<dyn crate::llm::LlmClient> = Arc::from(original.build_client()?);
    let opaque = ReactAgent::new(AgentConfig::minimal("model-a", "test"))
        .with_llm_client(Arc::clone(&client));
    assert!(opaque.llm_config().is_none());
    assert!(
        opaque
            .llm_client()
            .is_some_and(|value| Arc::ptr_eq(value, &client))
    );
    let rebuilt =
        ReactAgent::new(AgentConfig::minimal("model-a", "test")).with_llm_config(original);
    assert!(rebuilt.llm_config().is_some());
    assert!(
        rebuilt
            .llm_client()
            .is_some_and(|value| !Arc::ptr_eq(value, &client))
    );
    Ok(())
}

#[tokio::test]
async fn configured_client_builder_keeps_arc_profile_budget_and_injections()
-> crate::error::Result<()> {
    for explicit in [false, true] {
        let queries = Arc::new(AtomicUsize::new(0));
        let mut profile = echo_core::llm::capabilities::ModelProfile::from_provider_name(
            "model-a",
            "test-provider",
        );
        profile.context_window = Some(64_000);
        let client: Arc<dyn crate::llm::LlmClient> = Arc::new(ModelPublicationProfileClient {
            inner: crate::testing::MockLlmClient::new().with_model_name("model-a"),
            profile: echo_core::llm::capabilities::ModelProfileResolution::from_explicit_profile(
                profile,
                SystemTime::now(),
            ),
            queries: Arc::clone(&queries),
        });
        let mut original = test_llm_config("model-a");
        original.api_key.clear();
        let store: Arc<dyn crate::memory::Store> = Arc::new(crate::memory::InMemoryStore::new());
        let mut builder = ReactAgentBuilder::new()
            .configured_llm_client(Arc::clone(&client), original.clone())
            .model("must-not-split-the-pair")
            .name("paired-builder")
            .system_prompt("paired system")
            .session_id("paired-session")
            .temperature(Some(0.25))
            .max_tokens(Some(1024))
            .tool(Box::new(MockTool::new("paired-tool")))
            .with_memory_tools(Arc::clone(&store));
        if explicit {
            builder = builder.token_limit(100_000);
        }
        let mut agent = builder.build_strict()?;
        assert_eq!(queries.load(Ordering::SeqCst), 1);
        assert!(
            agent
                .llm_client()
                .is_some_and(|value| Arc::ptr_eq(value, &client))
        );
        assert_eq!(
            serde_json::to_value(agent.llm_config())?,
            serde_json::to_value(Some(&original))?
        );
        assert_eq!(agent.model_name(), "model-a");
        assert_eq!(agent.config.token_limit_explicit, explicit);
        assert_eq!(
            agent.config.token_limit,
            if explicit { 100_000 } else { 64_000 }
        );
        assert_eq!(agent.config.get_temperature(), Some(0.25));
        assert_eq!(agent.config.get_max_tokens(), Some(1024));
        assert!(agent.tool_names().iter().any(|name| name == "paired-tool"));
        assert!(
            agent
                .store()
                .is_some_and(|value| Arc::ptr_eq(value, &store))
        );
        {
            let mut context = agent.memory.context.lock().await;
            context.push(Message::user("budget probe".to_string()));
            assert_eq!(context.should_compress_with_overhead(70_000), !explicit);
        }
        agent.set_model("model-a")?;
        assert_eq!(queries.load(Ordering::SeqCst), 1);
        agent.set_llm_client(Arc::clone(&client));
        assert!(agent.llm_config().is_none());
        assert!(agent.set_model("model-b").is_err());
        assert!(
            agent
                .llm_client()
                .is_some_and(|value| Arc::ptr_eq(value, &client))
        );
    }
    Ok(())
}

#[test]
fn configured_client_builder_rejects_invalid_pairs_before_profile_query() -> crate::error::Result<()>
{
    for (client_model, config_model) in [
        ("", ""),
        ("model-a", ""),
        ("", "model-a"),
        ("model-a", "model-b"),
    ] {
        let queries = Arc::new(AtomicUsize::new(0));
        let client: Arc<dyn crate::llm::LlmClient> = Arc::new(ModelPublicationProfileClient {
            inner: crate::testing::MockLlmClient::new().with_model_name(client_model),
            profile: echo_core::llm::capabilities::ModelProfileResolution::from_explicit_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    client_model,
                    "test-provider",
                ),
                SystemTime::now(),
            ),
            queries: Arc::clone(&queries),
        });
        let mut original = test_llm_config(config_model);
        original.api_key = "builder-pair-secret-sentinel".to_string();
        let error = match ReactAgentBuilder::new()
            .configured_llm_client(Arc::clone(&client), original)
            .build_strict()
        {
            Err(error) => error,
            Ok(_) => return Err(std::io::Error::other("invalid Builder pair was accepted").into()),
        };
        assert!(matches!(&error, crate::error::ReactError::Config(value)
            if matches!(value.as_ref(), crate::error::ConfigError::ConfigFileError(..))));
        assert!(!format!("{error:?} {error}").contains("builder-pair-secret-sentinel"));
        assert_eq!(queries.load(Ordering::SeqCst), 0);
        assert_eq!(Arc::strong_count(&client), 1);
    }
    Ok(())
}

#[test]
fn configured_client_builder_preserves_legacy_and_explicit_replacement_order()
-> crate::error::Result<()> {
    let original = test_llm_config("model-a");
    let client: Arc<dyn crate::llm::LlmClient> = Arc::from(original.build_client()?);
    let custom: Arc<dyn crate::llm::LlmClient> =
        Arc::new(crate::testing::MockLlmClient::new().with_model_name("custom"));
    let opaque = ReactAgentBuilder::new()
        .configured_llm_client(Arc::clone(&client), original.clone())
        .llm_client(Arc::clone(&custom))
        .build_strict()?;
    assert!(opaque.llm_config().is_none());
    assert!(
        opaque
            .llm_client()
            .is_some_and(|value| Arc::ptr_eq(value, &custom))
    );
    for sourced in [false, true] {
        let builder =
            ReactAgentBuilder::new().configured_llm_client(Arc::clone(&client), original.clone());
        let replacement = if sourced {
            builder.sourced_llm_config(crate::llm::SourcedLlmConfig::new(original.clone()))
        } else {
            builder.llm_config(original.clone())
        }
        .build_strict()?;
        assert!(replacement.llm_config().is_some());
        assert!(
            replacement
                .llm_client()
                .is_some_and(|value| !Arc::ptr_eq(value, &client))
        );
    }
    for config_first in [false, true] {
        let builder = ReactAgentBuilder::new();
        let legacy = if config_first {
            builder
                .llm_config(original.clone())
                .llm_client(Arc::clone(&custom))
        } else {
            builder
                .llm_client(Arc::clone(&custom))
                .llm_config(original.clone())
        }
        .build_strict()?;
        assert_eq!(legacy.model_name(), "model-a");
        assert!(legacy.llm_config().is_some());
        assert!(
            legacy
                .llm_client()
                .is_some_and(|value| !Arc::ptr_eq(value, &custom))
        );
    }
    let paired = ReactAgentBuilder::new()
        .llm_client(custom)
        .llm_config(test_llm_config("old-model"))
        .configured_llm_client(Arc::clone(&client), original)
        .build_strict()?;
    assert!(
        paired
            .llm_client()
            .is_some_and(|value| Arc::ptr_eq(value, &client))
    );
    assert_eq!(
        paired.llm_config().map(|value| value.model.as_str()),
        Some("model-a")
    );
    Ok(())
}

#[tokio::test]
async fn configured_client_builder_switches_actual_http() -> crate::error::Result<()> {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
    let mut original = test_llm_config("model-a");
    original.base_url = format!("http://{}/v1/chat/completions", listener.local_addr()?);
    let server = tokio::spawn(async move {
        tokio::time::timeout(
            std::time::Duration::from_secs(10),
            model_publication_http_server(listener),
        )
        .await
        .map_err(|error| std::io::Error::other(error.to_string()))?
    });
    let client: Arc<dyn crate::llm::LlmClient> = Arc::from(original.build_client()?);
    let mut agent = ReactAgentBuilder::new()
        .configured_llm_client(Arc::clone(&client), original)
        .session_id("same-paired-session")
        .conversation_id("same-paired-conversation")
        .build_strict()?;
    assert!(
        agent
            .llm_client()
            .is_some_and(|value| Arc::ptr_eq(value, &client))
    );
    assert_eq!(Agent::chat(&agent, "first request").await?, "ok");
    agent.set_model("model-b")?;
    assert_eq!(Agent::chat(&agent, "second request").await?, "ok");
    let requests = server
        .await
        .map_err(|error| std::io::Error::other(error.to_string()))??;
    let models: Vec<_> = requests
        .iter()
        .map(|request| request.get("model"))
        .collect();
    assert_eq!(models, [Some(&json!("model-a")), Some(&json!("model-b"))]);
    let second = requests
        .get(1)
        .ok_or_else(|| std::io::Error::other("second model request missing"))?;
    assert!(second.to_string().contains("first request"));
    assert!(second.to_string().contains("second request"));
    Ok(())
}

#[cfg(feature = "subagent")]
#[test]
fn configured_client_builder_preserves_shared_subagent_registry() -> crate::error::Result<()> {
    let original = test_llm_config("model-a");
    let client: Arc<dyn crate::llm::LlmClient> = Arc::from(original.build_client()?);
    let registry = Arc::new(SubagentRegistry::new());
    let agent = ReactAgentBuilder::new()
        .configured_llm_client(Arc::clone(&client), original)
        .subagent_registry(Arc::clone(&registry))
        .enable_tools()
        .enable_subagent()
        .register_agent_dispatch_tool()
        .build_strict()?;
    assert!(Arc::ptr_eq(agent.subagent_registry(), &registry));
    assert!(
        agent
            .llm_client()
            .is_some_and(|value| Arc::ptr_eq(value, &client))
    );
    assert!(agent.tool_names().iter().any(|name| name == "agent_tool"));
    Ok(())
}

#[tokio::test]
async fn runtime_model_publication_prepared_commit_uses_only_frozen_profile()
-> crate::error::Result<()> {
    for commit in [false, true] {
        let agent = ReactAgent::new(AgentConfig::minimal("model-a", "test"));
        let before = model_publication_state(&agent);
        let handle = AgentHandle::new(agent);
        let queries = Arc::new(AtomicUsize::new(0));
        let mut profile = echo_core::llm::capabilities::ModelProfile::from_provider_name(
            "model-b",
            "test-provider",
        );
        profile.context_window = Some(64_000);
        let client: Arc<dyn crate::llm::LlmClient> = Arc::new(ModelPublicationProfileClient {
            inner: crate::testing::MockLlmClient::new().with_model_name("model-b"),
            profile: echo_core::llm::capabilities::ModelProfileResolution::from_explicit_profile(
                profile,
                SystemTime::now(),
            ),
            queries: Arc::clone(&queries),
        });
        let prepared = handle
            .prepare_model_generation(
                test_llm_config("model-b"),
                client,
                Some(0.25),
                Some(1024),
                None,
                100_000,
                super::PreparedCriticUpdate::Preserve,
            )
            .await?;
        let after_prepare = queries.load(Ordering::SeqCst);
        assert!(after_prepare > 0);
        if commit {
            prepared.commit();
        } else {
            drop(prepared);
        }
        assert_eq!(queries.load(Ordering::SeqCst), after_prepare);
        if commit {
            assert_eq!(
                handle
                    .read(|agent| agent.config.model_profile.as_ref().map(|value| (
                        value.profile.model_name.clone(),
                        value.profile.context_window
                    )))
                    .await,
                Some(("model-b".to_string(), Some(64_000)))
            );
        } else {
            assert_eq!(handle.read(model_publication_state).await, before);
        }
    }
    Ok(())
}

#[cfg(feature = "subagent")]
#[tokio::test]
async fn react_agent_initializes_subagent_hook_executor() {
    let agent = ReactAgent::new(AgentConfig::new("test-model", "main", "sys"));
    let mut definition = HooksDefinition::default();
    definition.add_rules(
        HookEvent::SessionStart,
        vec![HookRule {
            matcher: "startup".to_string(),
            hooks: vec![HookAction::Subagent {
                name: "missing-reviewer".to_string(),
                task: Some("Review the change".to_string()),
                timeout: 5,
            }],
        }],
    );
    {
        let mut registry = agent.hook_registry().write().await;
        registry.register_user_hooks(definition);
    }
    let registry = agent.hook_registry().read().await.clone();

    let result = registry
        .run_lifecycle_hooks(&crate::skills::hooks::HookContext::for_session_start(
            "startup", "session", "main",
        ))
        .await;

    assert!(
        result
            .messages
            .iter()
            .any(|message| message.contains("missing-reviewer"))
    );
    assert!(
        result
            .messages
            .iter()
            .all(|message| !message.contains("no subagent executor"))
    );
}

// ── ReactAgent::reset() ───────────────────────────────────────────────────────

/// reset() should clear all messages, keeping only the system prompt (1 message)
#[tokio::test]
async fn react_agent_reset_clears_to_system_only() {
    let config = AgentConfig::new("test-model", "test_agent", "You are a test assistant");
    let agent = ReactAgent::new(config);

    let (count, _) = agent.context_stats().await;
    assert_eq!(count, 1, "Initially should only have 1 system message");

    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("Hello".to_string()));
    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::assistant("Hello!".to_string()));
    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("Goodbye".to_string()));
    let (count_after_push, _) = agent.context_stats().await;
    assert_eq!(
        count_after_push, 4,
        "After appending should have 4 messages"
    );

    agent.reset().await;
    let (count_after_reset, _) = agent.context_stats().await;
    assert_eq!(
        count_after_reset, 1,
        "After reset() should only have 1 system message"
    );
}

/// Multiple consecutive reset() calls should be idempotent, not producing duplicate system prompts
#[tokio::test]
async fn react_agent_reset_is_idempotent() {
    let config = AgentConfig::new("test-model", "test_agent", "System prompt");
    let agent = ReactAgent::new(config);

    agent.reset().await;
    agent.reset().await;
    agent.reset().await;

    let (count, _) = agent.context_stats().await;
    assert_eq!(
        count, 1,
        "After multiple reset() calls should still only have 1 system message"
    );
}

/// After reset() the system prompt content should remain unchanged
#[tokio::test]
async fn react_agent_reset_preserves_system_prompt() -> crate::error::Result<()> {
    let system = "This is a custom system prompt";
    let config = AgentConfig::new("test-model", "agent", system);
    let agent = ReactAgent::new(config);
    // Keep project rules enabled: reset must preserve the complete initial
    // harness payload, including feature-dependent rules, rather than raw base.
    let original = agent.get_messages().await;

    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("Some random message".to_string()));
    agent.reset().await;

    let messages = agent.memory.context.lock().await.messages().to_vec();
    assert_eq!(messages.len(), 1);
    assert_eq!(
        serde_json::to_value(&messages)?,
        serde_json::to_value(&original)?
    );
    let root = messages
        .first()
        .ok_or_else(|| std::io::Error::other("reset root missing"))?;
    assert_eq!(root.role, Role::System);
    assert!(
        root.content
            .as_text_ref()
            .is_some_and(|text| text.contains(system))
    );
    Ok(())
}

// ── ReactAgent tool registration tests ─────────────────────────────────────────

/// 工具注册不依赖已退役的控制工具。
#[test]
fn react_agent_add_tool_enables_tool_flag() {
    let config = AgentConfig::minimal("test-model", "helper");
    assert!(
        !config.is_tool_enabled(),
        "minimal config does not enable tools by default"
    );

    let mut agent = ReactAgent::new(config);
    agent.add_tool(Box::new(MockTool::new("test_tool")));

    assert!(
        agent.config().is_tool_enabled(),
        "after add_tool, tools should be enabled"
    );
    // 真实注册的test_tool；最终候选走原生消息。
    let tool_names = agent.tool_names();
    assert!(tool_names.contains(&String::from("test_tool")));
    assert!(
        !tool_names
            .iter()
            .any(|name| name == "final_answer" || name == "think")
    );
}

#[test]
fn react_agent_add_tools_batch() {
    let config = AgentConfig::minimal("test-model", "helper");
    let mut agent = ReactAgent::new(config);

    let tools: Vec<Box<dyn crate::tools::Tool>> = vec![
        Box::new(MockTool::new("tool1")),
        Box::new(MockTool::new("tool2")),
        Box::new(MockTool::new("tool3")),
    ];

    agent.add_tools(tools);

    let tool_names = agent.tool_names();
    // built-in tools + 3 custom tools
    assert!(tool_names.len() >= 4);
    assert!(tool_names.contains(&String::from("tool1")));
    assert!(tool_names.contains(&String::from("tool2")));
    assert!(tool_names.contains(&String::from("tool3")));
}

#[test]
fn react_agent_add_tools_empty_vec() {
    let config = AgentConfig::minimal("test-model", "helper");
    let mut agent = ReactAgent::new(config);

    agent.add_tools(vec![]);

    assert!(
        !agent.config().is_tool_enabled(),
        "empty tool list should not modify enable_tool"
    );
}

#[test]
fn react_agent_add_tools_with_allowed_list() {
    let config = AgentConfig::minimal("test-model", "helper")
        .allowed_tools(vec!["allowed_tool".to_string()]);
    let mut agent = ReactAgent::new(config);

    let tools: Vec<Box<dyn crate::tools::Tool>> = vec![
        Box::new(MockTool::new("allowed_tool")),
        Box::new(MockTool::new("blocked_tool")),
    ];

    agent.add_tools(tools);

    let tool_names = agent.tool_names();
    // built-in tools + allowed_tool (whitelist only filters user-added tools)
    assert!(tool_names.len() >= 2);
    assert!(tool_names.contains(&String::from("allowed_tool")));
}

// ── ReactAgent getter method tests ─────────────────────────────────────────────

#[test]
fn react_agent_tool_names() {
    let config = AgentConfig::minimal("test-model", "helper");
    let mut agent = ReactAgent::new(config);

    // 默认构造保留任务图与工具发现能力；具名控制工具已退役。
    let initial_len = agent.tool_names().len();
    assert!(initial_len >= 1);

    agent.add_tool(Box::new(MockTool::new("tool1")));
    agent.add_tool(Box::new(MockTool::new("tool2")));

    let names = agent.tool_names();
    assert_eq!(names.len(), initial_len + 2);
}

#[test]
fn react_agent_skill_names() {
    let config = AgentConfig::minimal("test-model", "helper");
    let agent = ReactAgent::new(config);

    assert!(
        agent.skill_names().is_empty(),
        "Initially should have no skills"
    );
}

#[test]
fn react_agent_mcp_server_names() {
    let config = AgentConfig::minimal("test-model", "helper");
    let agent = ReactAgent::new(config);

    assert!(
        agent.mcp_server_names().is_empty(),
        "Initially should have no MCP servers"
    );
}

#[tokio::test]
async fn agent_messages_returns_a_non_blocking_context_snapshot() {
    let agent = ReactAgent::new(AgentConfig::minimal("test-model", "helper"));
    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("hello".to_string()));

    let trait_agent: &dyn Agent = &agent;
    let messages = trait_agent.messages();
    assert!(messages.iter().any(|message| {
        message
            .content
            .as_text()
            .is_some_and(|content| content == "hello")
    }));
}

#[test]
fn concrete_and_trait_tool_names_share_one_contract() {
    let agent = ReactAgent::new(AgentConfig::minimal("test-model", "helper"));
    let concrete = agent.tool_names();
    let trait_agent: &dyn Agent = &agent;
    assert_eq!(concrete, trait_agent.tool_names());
}

#[tokio::test]
async fn react_agent_get_messages() {
    let config = AgentConfig::new("test-model", "agent", "You are helpful");
    let agent = ReactAgent::new(config);

    let messages = agent.get_messages().await;
    assert_eq!(messages.len(), 1, "Initially only has system message");
    assert_eq!(messages[0].role, Role::System);

    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("Hello".to_string()));
    let messages = agent.get_messages().await;
    assert_eq!(messages.len(), 2);
}

#[tokio::test]
async fn react_agent_context_stats() {
    let config = AgentConfig::new("test-model", "agent", "System prompt");
    let agent = ReactAgent::new(config);

    let (count, _tokens) = agent.context_stats().await;
    assert_eq!(count, 1);

    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("This is a test message".to_string()));
    let (count, tokens) = agent.context_stats().await;
    assert_eq!(count, 2);
    assert!(tokens > 0, "token estimate should be greater than 0");
}

// ── ReactAgent configuration tests ─────────────────────────────────────────────

#[test]
fn react_agent_set_model() -> crate::error::Result<()> {
    let config = AgentConfig::minimal("model1", "helper");
    let mut agent = ReactAgent::new(config);

    assert_eq!(agent.model_name(), "model1");

    agent.set_model("model2")?;

    assert_eq!(agent.model_name(), "model2");
    Ok(())
}

#[tokio::test]
async fn react_agent_set_system_prompt() {
    let config = AgentConfig::minimal("test-model", "helper");
    let agent = ReactAgent::new(config);

    let original_prompt = agent.system_prompt().to_string();
    assert_eq!(original_prompt, "helper");

    // set_system_prompt stores a runtime override in mutable_system_prompt.
    // The system_prompt() getter returns the base config prompt (cannot return
    // a reference into RwLock). The effective-root renderer consumes the
    // override through current_system_prompt().
    agent.set_system_prompt("New system prompt");

    // Base prompt is unchanged (by design — getter returns config value)
    assert_eq!(agent.system_prompt(), "helper");

    // The override IS stored internally
    let override_val = agent.mutable_system_prompt.read().unwrap();
    assert_eq!(override_val.as_deref(), Some("New system prompt"));
}

#[test]
fn react_agent_name() {
    let config = AgentConfig::new("model", "my_agent", "prompt");
    let agent = ReactAgent::new(config);

    assert_eq!(agent.name(), "my_agent");
}

#[test]
fn react_agent_model_name() {
    let config = AgentConfig::new("qwen3-max", "agent", "prompt");
    let agent = ReactAgent::new(config);

    assert_eq!(agent.model_name(), "qwen3-max");
}

#[test]
fn react_agent_system_prompt() {
    let config = AgentConfig::new("model", "agent", "Be helpful");
    let agent = ReactAgent::new(config);

    assert_eq!(agent.system_prompt(), "Be helpful");
}

// ── ReactAgent callback tests ──────────────────────────────────────────────────

/// Simple callback counter
struct CounterCallback {
    count: AtomicUsize,
}

impl CounterCallback {
    fn new() -> Self {
        Self {
            count: AtomicUsize::new(0),
        }
    }

    #[allow(dead_code)]
    fn get_count(&self) -> usize {
        self.count.load(Ordering::SeqCst)
    }
}

impl crate::agent::AgentCallback for CounterCallback {
    fn on_think_start<'a>(
        &'a self,
        _agent: &'a str,
        _messages: &'a [Message],
    ) -> futures::future::BoxFuture<'a, ()> {
        self.count.fetch_add(1, Ordering::SeqCst);
        Box::pin(async {})
    }

    fn on_final_answer<'a>(
        &'a self,
        _agent: &'a str,
        _answer: &'a str,
    ) -> futures::future::BoxFuture<'a, ()> {
        self.count.fetch_add(1, Ordering::SeqCst);
        Box::pin(async {})
    }
}

#[test]
fn react_agent_add_callback() {
    let config = AgentConfig::minimal("test-model", "helper");
    let mut agent = ReactAgent::new(config);

    let callback = Arc::new(CounterCallback::new());
    agent.add_callback(callback.clone());

    // Verify the callback has been added (by checking internal state)
    // Since callbacks are private, we can only verify through execution
    // Here we simply verify the method does not panic
}

// ── Agent trait contract ───────────────────────────────────────────────────────

/// reset() is callable via &mut dyn Agent (trait object safety verification)
#[tokio::test]
async fn trait_reset_callable_via_dyn_agent() {
    let agent: Box<dyn Agent> = Box::new(
        MockAgent::new("mock")
            .with_response("r1")
            .with_response("r2"),
    );

    let r1 = agent.chat("msg1").await.unwrap();
    assert_eq!(r1, "r1");

    agent.reset().await;

    let r2 = agent.chat("msg2").await.unwrap();
    assert_eq!(r2, "r2");
}

#[test]
fn trait_name_callable() {
    let agent: Box<dyn Agent> = Box::new(MockAgent::new("test_agent"));

    assert_eq!(agent.name(), "test_agent");
}

#[test]
fn trait_model_name_callable() {
    let agent: Box<dyn Agent> = Box::new(MockAgent::new("agent"));
    // MockAgent default model_name returns "mock-model"
    assert_eq!(agent.model_name(), "mock-model");
}

#[test]
fn trait_tool_names_default() {
    let agent: Box<dyn Agent> = Box::new(MockAgent::new("agent"));

    assert!(agent.tool_names().is_empty());
}

#[test]
fn trait_skill_names_default() {
    let agent: Box<dyn Agent> = Box::new(MockAgent::new("agent"));

    assert!(agent.skill_names().is_empty());
}

// ── MockAgent contract ─────────────────────────────────────────────────────────

/// chat() should record calls and consume the preset response queue
#[tokio::test]
async fn mock_agent_chat_records_calls_and_consumes_responses() {
    let agent = MockAgent::new("test")
        .with_response("Response1")
        .with_response("Response2")
        .with_response("Response3");

    let r1 = agent.chat("Message1").await.unwrap();
    let r2 = agent.chat("Message2").await.unwrap();
    let r3 = agent.chat("Message3").await.unwrap();

    assert_eq!(r1, "Response1");
    assert_eq!(r2, "Response2");
    assert_eq!(r3, "Response3");
    assert_eq!(agent.call_count(), 3);
    assert_eq!(agent.calls(), vec!["Message1", "Message2", "Message3"]);
}

/// reset() should clear MockAgent's call history (simulating conversation reset semantics)
#[tokio::test]
async fn mock_agent_reset_clears_call_history() {
    let agent = MockAgent::new("test")
        .with_response("r1")
        .with_response("r2")
        .with_response("r3");

    agent.chat("Round1 Message1").await.unwrap();
    agent.chat("Round1 Message2").await.unwrap();
    assert_eq!(agent.call_count(), 2, "before reset should have 2 records");

    agent.reset().await;
    assert_eq!(
        agent.call_count(),
        0,
        "after reset, call history should be cleared"
    );

    agent.chat("Round2 Message1").await.unwrap();
    assert_eq!(
        agent.call_count(),
        1,
        "after reset, round 2 should start counting from 1"
    );
    assert_eq!(agent.calls(), vec!["Round2 Message1"]);
}

/// execute() and chat() share the same response queue
#[tokio::test]
async fn mock_agent_execute_and_chat_share_response_queue() {
    let agent = MockAgent::new("test")
        .with_response("executeResponse")
        .with_response("chatResponse");

    let r1 = agent.execute("Task").await.unwrap();
    let r2 = agent.chat("Chat").await.unwrap();

    assert_eq!(r1, "executeResponse");
    assert_eq!(r2, "chatResponse");
    assert_eq!(agent.call_count(), 2);
}

/// Callers can explicitly opt into a reusable default response.
#[tokio::test]
async fn mock_agent_chat_falls_back_to_default_when_queue_empty() {
    let agent = MockAgent::new("test").with_default_success("mock agent response");

    let r = agent.chat("Any message").await.unwrap();
    assert_eq!(
        r, "mock agent response",
        "when queue is empty, should return default response"
    );
}

/// FailingMockAgent::reset() clears call history
#[tokio::test]
async fn failing_mock_agent_reset_clears_calls() {
    let agent = FailingMockAgent::new("failing", "Always fails");

    agent.execute("Task1").await.unwrap_err();
    agent.chat("Task2").await.unwrap_err();
    assert_eq!(agent.call_count(), 2);

    agent.reset().await;
    assert_eq!(
        agent.call_count(),
        0,
        "after reset, call records should be cleared"
    );
}

// ── chat + reset full lifecycle ────────────────────────────────────────────────

/// Simulate a typical multi-turn conversation lifecycle: chat → reset → chat
#[tokio::test]
async fn mock_agent_full_chat_lifecycle() {
    let agent = MockAgent::new("assistant").with_responses([
        "Round1Reply1",
        "Round1Reply2",
        "Round2Reply1",
        "Round2Reply2",
    ]);

    agent.chat("Round 1: Question A").await.unwrap();
    agent.chat("Round 1: Question B").await.unwrap();
    assert_eq!(agent.call_count(), 2);

    agent.reset().await;
    assert_eq!(agent.call_count(), 0);

    agent.chat("Round 2: Question C").await.unwrap();
    agent.chat("Round 2: Question D").await.unwrap();
    assert_eq!(agent.call_count(), 2);
    assert_eq!(
        agent.calls(),
        vec!["Round 2: Question C", "Round 2: Question D"]
    );
}

// ── ReactAgentBuilder Tests ───────────────────────────────────────────────────────

#[test]
fn react_agent_builder_basic() {
    let agent = crate::agent::ReactAgentBuilder::new()
        .name("test")
        .model("qwen3-max")
        .system_prompt("Be helpful")
        .build()
        .unwrap();

    assert_eq!(agent.name(), "test");
    assert_eq!(agent.model_name(), "qwen3-max");
    assert_eq!(agent.system_prompt(), "Be helpful");
}

#[test]
fn react_agent_builder_with_tools() -> crate::error::Result<()> {
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .enable_tools()
        .tool(Box::new(MockTool::new("tool1")))
        .tool(Box::new(MockTool::new("tool2")))
        .build()?;

    assert!(agent.config().is_tool_enabled());
    // 标准内置能力与两个实际工具。
    let names = agent.tool_names();
    assert!(
        names.contains(&String::from("tool1")),
        "Should contain tool1"
    );
    assert!(
        names.contains(&String::from("tool2")),
        "Should contain tool2"
    );
    assert!(
        !names.contains(&String::from("final_answer")),
        "Retired final_answer must not be registered"
    );
    for required in ["task_create", "task_update", "task_list", "tool1", "tool2"] {
        assert!(
            names.iter().any(|name| name == required),
            "保留统一task authority与实际工具：{required}"
        );
    }
    assert!(
        !names
            .iter()
            .any(|name| name == "final_answer" || name == "think")
    );
    Ok(())
}

#[test]
fn react_agent_builder_with_memory() {
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .enable_memory()
        .build()
        .unwrap();

    assert!(agent.config().is_memory_enabled());
}

#[test]
fn react_agent_builder_registers_cell_tools_with_injected_registry() {
    use echo_core::tools::cell::CommandCellRegistry;
    use echo_orchestration::tasks::BackgroundCommandManager;

    let registry: std::sync::Arc<dyn CommandCellRegistry> =
        std::sync::Arc::new(BackgroundCommandManager::default());
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .enable_tools()
        .command_cells(registry)
        .build()
        .unwrap();

    let tool_names = agent.tool_names();
    assert!(tool_names.contains(&String::from("wait")));
    assert!(tool_names.contains(&String::from("stop_cell")));
    assert!(tool_names.contains(&String::from("list_cells")));

    // 未注入 registry 的 agent 不注册 cell 工具。
    let plain = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .enable_tools()
        .build()
        .unwrap();
    let plain_names = plain.tool_names();
    assert!(!plain_names.contains(&String::from("wait")));
    assert!(!plain_names.contains(&String::from("stop_cell")));
    assert!(!plain_names.contains(&String::from("list_cells")));
}

#[test]
fn react_agent_builder_max_iterations() {
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .max_iterations(50)
        .build()
        .unwrap();

    assert_eq!(agent.config().get_max_iterations(), 50);
}

#[test]
fn react_agent_builder_token_limit() {
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .token_limit(DEFAULT_TOKEN_LIMIT)
        .build()
        .unwrap();

    assert_eq!(agent.config().get_token_limit(), DEFAULT_TOKEN_LIMIT);
}

#[tokio::test]
async fn prepared_model_generation_is_inert_until_infallible_commit() -> crate::error::Result<()> {
    let agent = ReactAgent::new(AgentConfig::new(
        "original-model",
        "test_agent",
        "system prompt",
    ));
    let llm_config = test_llm_config("replacement-model");
    let client: Arc<dyn crate::llm::LlmClient> =
        Arc::new(crate::testing::MockLlmClient::new().with_model_name("replacement-model"));

    let handle = AgentHandle::new(agent);
    let context = handle.read(|agent| Arc::clone(&agent.memory.context)).await;
    assert_eq!(
        handle.read(|agent| agent.model_name().to_string()).await,
        "original-model"
    );
    let prepared = handle
        .prepare_model_generation(
            llm_config,
            Arc::clone(&client),
            Some(0.25),
            Some(4096),
            None,
            32_768,
            super::PreparedCriticUpdate::Preserve,
        )
        .await?;

    assert!(handle.try_write(|_| ()).is_none());
    assert!(context.try_lock().is_err());

    prepared.commit();

    let projection = handle
        .read(|agent| {
            (
                agent.model_name().to_string(),
                agent.config().get_temperature(),
                agent.config().get_max_tokens(),
                agent.config().get_token_limit(),
                agent.llm_config().map(|config| config.model.clone()),
                agent
                    .llm_client()
                    .map(|value| value.model_name().to_string()),
            )
        })
        .await;
    assert_eq!(projection.0, "replacement-model");
    assert_eq!(projection.1, Some(0.25));
    assert_eq!(projection.2, Some(4096));
    assert_eq!(projection.3, 32_768);
    assert_eq!(projection.4.as_deref(), Some("replacement-model"),);
    assert_eq!(projection.5.as_deref(), Some("replacement-model"));
    assert!(context.try_lock().is_ok());
    Ok(())
}

#[tokio::test]
async fn prepared_model_deactivation_clears_the_committed_generation() -> crate::error::Result<()> {
    let handle = AgentHandle::new(ReactAgent::new(AgentConfig::new(
        "original-model",
        "test_agent",
        "system prompt",
    )));
    let client: Arc<dyn crate::llm::LlmClient> =
        Arc::new(crate::testing::MockLlmClient::new().with_model_name("active-model"));
    handle
        .prepare_model_generation(
            test_llm_config("active-model"),
            client,
            Some(0.25),
            Some(4096),
            None,
            32_768,
            super::PreparedCriticUpdate::Preserve,
        )
        .await?
        .commit();

    let prepared = handle.prepare_model_deactivation(None).await;
    assert!(handle.try_write(|_| ()).is_none());
    prepared.commit();

    let projection = handle
        .read(|agent| {
            (
                agent.model_name().to_string(),
                agent.config().get_temperature(),
                agent.config().get_max_tokens(),
                agent.llm_config().is_none(),
                agent.llm_client().is_none(),
            )
        })
        .await;
    assert!(projection.0.is_empty());
    assert_eq!(projection.1, None);
    assert_eq!(projection.2, None);
    assert!(projection.3);
    assert!(projection.4);
    Ok(())
}

#[tokio::test]
async fn mismatched_prepared_client_leaves_agent_unchanged() {
    let agent = AgentHandle::new(ReactAgent::new(AgentConfig::new(
        "original-model",
        "test_agent",
        "system prompt",
    )));
    let llm_config = test_llm_config("replacement-model");
    let client: Arc<dyn crate::llm::LlmClient> =
        Arc::new(crate::testing::MockLlmClient::new().with_model_name("wrong-model"));

    let result = agent
        .prepare_model_generation(
            llm_config,
            client,
            None,
            None,
            None,
            32_768,
            super::PreparedCriticUpdate::Preserve,
        )
        .await;

    assert!(result.is_err());
    assert_eq!(
        agent.read(|agent| agent.model_name().to_string()).await,
        "original-model"
    );
    assert_eq!(
        agent.read(|agent| agent.config().get_token_limit()).await,
        DEFAULT_TOKEN_LIMIT
    );
    assert!(agent.try_write(|_| ()).is_some());
}

#[tokio::test]
async fn owned_critic_refresh_does_not_replace_a_custom_critic() -> crate::error::Result<()> {
    let mut agent = ReactAgent::new(AgentConfig::new(
        "original-model",
        "test_agent",
        "system prompt",
    ));
    let custom = Arc::new(echo_core::agent::StaticCritic::always_pass());
    agent.set_critic(custom.clone());
    assert_eq!(agent.critic_owner(), None);
    let agent = AgentHandle::new(agent);

    let llm_config = test_llm_config("replacement-model");
    let client: Arc<dyn crate::llm::LlmClient> =
        Arc::new(crate::testing::MockLlmClient::new().with_model_name("replacement-model"));
    let replacement = Arc::new(echo_core::agent::StaticCritic::always_fail());
    let prepared = agent
        .prepare_model_generation(
            llm_config,
            client,
            None,
            None,
            None,
            32_768,
            super::PreparedCriticUpdate::ReplaceOwned {
                owner: "eko:model-generation".to_string(),
                critic: replacement,
            },
        )
        .await?;

    prepared.commit();

    assert_eq!(Arc::strong_count(&custom), 2);
    assert_eq!(
        agent
            .read(|agent| agent.critic_owner().map(str::to_string))
            .await,
        None
    );
    Ok(())
}

#[tokio::test]
async fn prepared_generation_is_type_bound_to_its_origin_agent() -> crate::error::Result<()> {
    let origin = AgentHandle::new(ReactAgent::new(AgentConfig::new(
        "origin-model",
        "origin",
        "system prompt",
    )));
    let other = AgentHandle::new(ReactAgent::new(AgentConfig::new(
        "other-model",
        "other",
        "system prompt",
    )));
    let client: Arc<dyn crate::llm::LlmClient> =
        Arc::new(crate::testing::MockLlmClient::new().with_model_name("replacement-model"));
    let prepared = origin
        .prepare_model_generation(
            test_llm_config("replacement-model"),
            client,
            None,
            None,
            None,
            32_768,
            super::PreparedCriticUpdate::Preserve,
        )
        .await?;

    assert!(origin.try_write(|_| ()).is_none());
    assert!(other.try_write(|_| ()).is_some());
    prepared.commit();

    assert_eq!(
        origin.read(|agent| agent.model_name().to_string()).await,
        "replacement-model"
    );
    assert_eq!(
        origin.read(|agent| agent.config().get_token_limit()).await,
        32_768
    );
    assert_eq!(
        other.read(|agent| agent.model_name().to_string()).await,
        "other-model"
    );
    assert_eq!(
        other.read(|agent| agent.config().get_token_limit()).await,
        DEFAULT_TOKEN_LIMIT
    );
    Ok(())
}

#[test]
fn react_agent_builder_session_id() {
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .session_id("session-123")
        .build()
        .unwrap();

    assert_eq!(agent.config().get_session_id(), Some("session-123"));
}

#[test]
fn react_agent_builder_conversation_id() {
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .conversation_id("conversation-123")
        .build()
        .unwrap();

    assert_eq!(
        agent.config().get_conversation_id(),
        Some("conversation-123")
    );
}

#[test]
fn react_agent_builder_split_thread_and_conversation_ids() {
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .session_id("thread-123")
        .conversation_id("conversation-123")
        .build()
        .unwrap();

    assert_eq!(agent.config().get_session_id(), Some("thread-123"));
    assert_eq!(
        agent.config().get_conversation_id(),
        Some("conversation-123")
    );
}

// ── ReactAgent Config Preset Tests ───────────────────────────────────────────────────────

#[test]
fn react_agent_builder_simple() {
    let error = crate::agent::ReactAgentBuilder::simple("qwen3-max", "You are helpful")
        .err()
        .expect("simple preset must reject deferred LLM configuration");
    assert!(error.to_string().contains("llm_client"));
}

#[test]
fn react_agent_builder_standard() {
    let error = crate::agent::ReactAgentBuilder::standard("qwen3-max", "agent1", "Be helpful")
        .err()
        .expect("standard preset must reject deferred LLM configuration");
    assert!(error.to_string().contains("llm_client"));
}

#[test]
fn react_agent_builder_full_featured() {
    let error = crate::agent::ReactAgentBuilder::full_featured("qwen3-max", "agent1", "Be helpful")
        .err()
        .expect("full-featured preset must reject deferred LLM configuration");
    assert!(error.to_string().contains("llm_client"));
}

// ── Subagent Tests ───────────────────────────────────────────────────────────────

#[cfg(feature = "subagent")]
#[test]
fn react_agent_register_subagent_requires_enable_flag() {
    // Do not enable subagent feature
    let config = AgentConfig::minimal("test-model", "main_agent");
    let mut agent = ReactAgent::new(config);

    let sub_agent = Box::new(MockAgent::new("sub_agent"));
    agent.register_agent(sub_agent);

    // Since enable_subagent = false, subagent should not be registered
    // There is no public method to directly check subagent list, but can verify through behavior
}

#[cfg(feature = "subagent")]
#[test]
fn react_agent_register_subagent_when_enabled() {
    let config = AgentConfig::minimal("test-model", "main_agent").enable_subagent(true);
    let mut agent = ReactAgent::new(config);

    let sub_agent = Box::new(MockAgent::new("sub_agent"));
    agent.register_agent(sub_agent);

    // subagent should be successfully registered
    // Can indirectly verify by checking if agent_dispatch tool is available
}

#[cfg(feature = "subagent")]
#[test]
fn react_agent_register_multiple_subagents() {
    let config = AgentConfig::minimal("test-model", "main_agent").enable_subagent(true);
    let mut agent = ReactAgent::new(config);

    let sub_agents: Vec<Box<dyn Agent>> = vec![
        Box::new(MockAgent::new("subagent1")),
        Box::new(MockAgent::new("subagent2")),
        Box::new(MockAgent::new("subagent3")),
    ];

    agent.register_agents(sub_agents);

    // All subagents should be successfully registered
}

#[tokio::test]
async fn subagent_context_isolation() {
    // Create parent agent
    let parent_config =
        AgentConfig::new("qwen3-max", "parent", "You are the parent agent").enable_subagent(true);
    let parent = ReactAgent::new(parent_config);

    // Parent agent adds message to context
    parent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("Parent message".to_string()));
    let (parent_count_before, _) = parent.context_stats().await;
    assert_eq!(parent_count_before, 2); // system + user message

    // Create independent child agent
    let sub_config = AgentConfig::new("qwen3-max", "child", "You are a child agent");
    let child = ReactAgent::new(sub_config);

    assert!(!Arc::ptr_eq(
        &parent.execution_mutex,
        &child.execution_mutex
    ));
    assert!(!Arc::ptr_eq(&parent.memory.context, &child.memory.context));

    // Child agent has its own independent context
    let (child_count, _) = child.context_stats().await;
    assert_eq!(child_count, 1); // only system message

    // Child agent adding messages does not affect parent agent
    child
        .memory
        .context
        .lock()
        .await
        .push(Message::user("Child message".to_string()));
    let (child_count_after, _) = child.context_stats().await;
    assert_eq!(child_count_after, 2);

    // Parent agent's context is unaffected
    let (parent_count_after, _) = parent.context_stats().await;
    assert_eq!(parent_count_after, 2);
}

#[tokio::test]
async fn subagent_reset_independence() {
    // Create parent agent and child agent
    let parent_config =
        AgentConfig::new("qwen3-max", "parent", "Parent system").enable_subagent(true);
    let parent = ReactAgent::new(parent_config);

    let child_config = AgentConfig::new("qwen3-max", "child", "Child system");
    let child = ReactAgent::new(child_config);

    // Both add messages
    parent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("Parent msg".to_string()));
    child
        .memory
        .context
        .lock()
        .await
        .push(Message::user("Child msg".to_string()));

    // Reset parent agent
    parent.reset().await;

    // Parent agent context is cleared
    let (parent_count, _) = parent.context_stats().await;
    assert_eq!(parent_count, 1);

    // Child agent context is unaffected
    let (child_count, _) = child.context_stats().await;
    assert_eq!(child_count, 2);
}

#[cfg(feature = "subagent")]
#[test]
fn react_agent_register_agent_dispatch_tool() {
    let config = AgentConfig::minimal("test-model", "main_agent")
        .enable_subagent(true)
        .register_agent_dispatch_tool(true);
    let agent = ReactAgent::new(config);

    // When register_agent_dispatch_tool is enabled, agent_tool should be registered
    let tool_names = agent.tool_names();
    assert!(tool_names.contains(&String::from("agent_tool")));
}

#[cfg(feature = "subagent")]
#[tokio::test]
async fn shared_subagent_registry_exposes_parent_registrations_to_child() -> crate::error::Result<()>
{
    let registry = Arc::new(SubagentRegistry::new());
    let mut parent = ReactAgentBuilder::new()
        .model("test-model")
        .name("parent")
        .enable_tools()
        .enable_subagent()
        .subagent_registry(registry.clone())
        .build()?;
    let child = ReactAgentBuilder::new()
        .model("test-model")
        .name("child")
        .enable_tools()
        .enable_subagent()
        .subagent_registry(registry.clone())
        .register_agent_dispatch_tool()
        .build()?;

    parent.register_subagent_with_definition(
        SubagentBuilder::new("reviewer")
            .description("Review code")
            .build(),
        Box::new(MockAgent::new("reviewer")),
    );

    assert!(Arc::ptr_eq(
        parent.subagent_registry(),
        child.subagent_registry()
    ));
    assert!(
        child
            .subagent_registry()
            .list_available()
            .await
            .iter()
            .any(|definition| definition.name == "reviewer")
    );
    assert!(child.tool_names().iter().any(|name| name == "agent_tool"));
    let definitions = child.subagent_registry().list_available().await;
    child.sync_subagent_dispatch_catalog(&definitions);
    let dispatch_schema = <ReactAgent as Agent>::tool_definitions(&child)
        .into_iter()
        .find(|definition| definition.function.name == "agent_tool")
        .and_then(|definition| {
            definition
                .function
                .parameters
                .pointer("/properties/agent_name/enum")
                .cloned()
        });
    assert!(
        dispatch_schema.is_some_and(|schema| {
            schema
                .as_array()
                .is_some_and(|names| names.iter().any(|name| name == "reviewer"))
        }),
        "shared targets must be discoverable through the child agent_tool schema"
    );
    Ok(())
}

#[cfg(feature = "subagent")]
#[test]
fn agent_dispatch_tool_schema_lists_registered_subagents() {
    let config = AgentConfig::minimal("test-model", "main_agent")
        .enable_subagent(true)
        .register_agent_dispatch_tool(true);
    let mut agent = ReactAgent::new(config);

    let def = SubagentBuilder::new("code_reviewer")
        .description("Reviews code for bugs and test gaps")
        .fork_mode()
        .tag("readonly")
        .build();
    agent.register_subagent_with_definition(def, Box::new(MockAgent::new("code_reviewer")));

    let definitions = <ReactAgent as Agent>::tool_definitions(&agent);
    let maybe_dispatch = definitions
        .iter()
        .find(|definition| definition.function.name == "agent_tool");
    let Some(dispatch) = maybe_dispatch else {
        assert!(
            maybe_dispatch.is_some(),
            "agent_tool should be registered when subagent is enabled"
        );
        return;
    };

    let agent_name_schema = dispatch
        .function
        .parameters
        .get("properties")
        .and_then(|properties| properties.get("agent_name"));
    let Some(agent_name_schema) = agent_name_schema else {
        assert!(
            agent_name_schema.is_some(),
            "agent_name schema should exist"
        );
        return;
    };

    let enum_values = agent_name_schema
        .get("enum")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();
    assert!(enum_values.iter().any(|value| value == "code_reviewer"));

    let description = agent_name_schema
        .get("description")
        .and_then(|value| value.as_str())
        .unwrap_or_default();
    assert!(description.contains("Reviews code for bugs and test gaps"));

    let task_description = dispatch
        .function
        .parameters
        .pointer("/properties/task/description")
        .and_then(|value| value.as_str())
        .unwrap_or_default();
    assert!(task_description.contains("user's current language"));
}

#[cfg(feature = "subagent")]
#[test]
fn react_agent_no_agent_dispatch_without_subagent() {
    let config = AgentConfig::minimal("test-model", "main_agent").enable_subagent(false);
    let agent = ReactAgent::new(config);

    // When subagent is not enabled, agent_tool should not be registered
    let tool_names = agent.tool_names();
    assert!(!tool_names.contains(&String::from("agent_tool")));
}

// ── Agent Config Isolation Tests ───────────────────────────────────────────────────────

#[test]
fn agent_config_isolation() {
    // Create two agents with independent configurations
    let config1 = AgentConfig::new("model-a", "agent1", "System A");
    let config2 = AgentConfig::new("model-b", "agent2", "System B");

    let agent1 = ReactAgent::new(config1);
    let agent2 = ReactAgent::new(config2);

    // Verify configurations are completely independent
    assert_eq!(agent1.model_name(), "model-a");
    assert_eq!(agent2.model_name(), "model-b");
    assert_eq!(agent1.name(), "agent1");
    assert_eq!(agent2.name(), "agent2");
    assert_eq!(agent1.system_prompt(), "System A");
    assert_eq!(agent2.system_prompt(), "System B");
}

#[test]
fn agent_tool_registration_isolation() {
    let config1 = AgentConfig::minimal("model", "agent1");
    let config2 = AgentConfig::minimal("model", "agent2");

    let mut agent1 = ReactAgent::new(config1);
    let agent2 = ReactAgent::new(config2);

    // agent1 registers a tool
    agent1.add_tool(Box::new(MockTool::new("tool1")));

    // agent2 should not be affected
    let tools1 = agent1.tool_names();
    let tools2 = agent2.tool_names();

    // agent1 has built-in tools + tool1; agent2 only has built-in tools
    assert!(
        tools1.len() >= 2,
        "agent1 should have at least 2 tools (built-in + tool1)"
    );
    assert!(
        !tools2.is_empty(),
        "agent2 should have at least 1 built-in tool"
    );
    assert_eq!(
        tools1.len(),
        tools2.len() + 1,
        "agent1 should have exactly one more tool than agent2"
    );
}

#[test]
fn agent_callbacks_isolation() {
    let config1 = AgentConfig::minimal("model", "agent1");
    let config2 = AgentConfig::minimal("model", "agent2");

    let mut agent1 = ReactAgent::new(config1);
    let agent2 = ReactAgent::new(config2);

    // agent1 adds a callback
    let callback = Arc::new(CounterCallback::new());
    agent1.add_callback(callback);

    // agent2 should not be affected (verified through execution behavior)
    // Since callbacks are private, only verify the method doesn't panic
    let _ = agent2;
}

// ── Agent Human-in-Loop Tool Tests ───────────────────────────────────────────────

#[cfg(feature = "human-loop")]
#[test]
fn react_agent_human_in_loop_tool_registration() {
    let config = AgentConfig::minimal("model", "agent").enable_human_in_loop(true);
    let agent = ReactAgent::new(config);

    // After enabling human_in_loop, the human_in_loop tool should be registered
    let tool_names = agent.tool_names();
    assert!(tool_names.contains(&String::from("human_in_loop")));
}

#[cfg(feature = "human-loop")]
#[test]
fn react_agent_no_human_in_loop_without_flag() {
    let config = AgentConfig::minimal("model", "agent").enable_human_in_loop(false);
    let agent = ReactAgent::new(config);

    // When human_in_loop is not enabled, the tool should not be registered
    let tool_names = agent.tool_names();
    assert!(!tool_names.contains(&String::from("human_in_loop")));
}

#[cfg(feature = "human-loop")]
#[tokio::test]
async fn runtime_human_loop_provider_replaces_registered_tool() -> Result<(), String> {
    struct FixedProvider(&'static str);

    impl crate::human_loop::HumanLoopProvider for FixedProvider {
        fn request(
            &self,
            _request: crate::human_loop::HumanLoopRequest,
        ) -> futures::future::BoxFuture<
            '_,
            crate::error::Result<crate::human_loop::HumanLoopResponse>,
        > {
            Box::pin(async move {
                Ok(crate::human_loop::HumanLoopResponse::Text(
                    self.0.to_string(),
                ))
            })
        }
    }

    let config = AgentConfig::minimal("model", "agent").enable_human_in_loop(true);
    let mut agent = ReactAgent::new(config);
    agent.set_human_loop_provider(Arc::new(FixedProvider("first-provider")));
    agent.set_human_loop_provider_preserving_approvals(Arc::new(FixedProvider(
        "replacement-provider",
    )));

    let result = agent
        .tool_manager()
        .execute_tool(
            "human_in_loop",
            [
                ("reasoning".to_string(), json!("test replacement")),
                ("approval_type".to_string(), json!("LLM")),
            ]
            .into(),
        )
        .await
        .map_err(|error| error.to_string())?;

    assert!(result.success);
    assert!(result.output.contains("replacement-provider"));
    assert!(!result.output.contains("first-provider"));
    Ok(())
}

#[tokio::test]
#[cfg(feature = "human-loop")]
async fn add_need_appeal_tool_does_not_nest_runtime_with_permission_service() {
    struct AllowProvider;
    impl crate::human_loop::HumanLoopProvider for AllowProvider {
        fn request(
            &self,
            _req: crate::human_loop::HumanLoopRequest,
        ) -> futures::future::BoxFuture<
            '_,
            crate::error::Result<crate::human_loop::HumanLoopResponse>,
        > {
            Box::pin(async { Ok(crate::human_loop::HumanLoopResponse::Approved) })
        }
    }

    let provider = Arc::new(AllowProvider);
    let service = Arc::new(crate::human_loop::PermissionService::from_provider(
        provider.clone() as Arc<dyn crate::human_loop::HumanLoopProvider>,
    ));

    let config = AgentConfig::minimal("model", "agent").enable_human_in_loop(true);
    let mut agent = ReactAgent::new(config);
    agent.set_permission_service(service.clone());

    // Before fix, this would trigger Handle::current().block_on(...) panic in async context.
    agent.add_need_appeal_tool(Box::new(MockTool::new("dangerous_tool")));

    let snapshot = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent);
    let _ = snapshot
        .check_tool_approval("call-1", "dangerous_tool", &serde_json::json!({}), None)
        .await;

    let rules = service.all_rules().await;
    assert!(rules.iter().any(|rule| {
        matches!(
            &rule.matcher,
            echo_core::tools::permission::RuleMatcher::Pattern { pattern }
                if pattern == "dangerous_tool"
        )
    }));
}

#[tokio::test]
async fn discover_skills_refreshes_activate_skill_registry() {
    let base =
        std::env::temp_dir().join(format!("echo-agent-skill-refresh-{}", std::process::id()));
    let dir1 = base.join("skills-a").join("skill-one");
    let dir2 = base.join("skills-b").join("skill-two");
    tokio::fs::create_dir_all(&dir1).await.unwrap();
    tokio::fs::create_dir_all(&dir2).await.unwrap();

    tokio::fs::write(
        dir1.join("SKILL.md"),
        "---\nname: skill-one\ndescription: first skill\n---\n\nUse skill one.\n",
    )
    .await
    .unwrap();
    tokio::fs::write(
        dir2.join("SKILL.md"),
        "---\nname: skill-two\ndescription: second skill\n---\n\nUse skill two.\n",
    )
    .await
    .unwrap();

    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    let base_system_prompt = agent.config.system_prompt.clone();

    agent
        .discover_skills(&[DiscoveryScope::Custom(base.join("skills-a"))])
        .await
        .unwrap();

    let first_params = agent
        .tools
        .tool_manager
        .get_tool("activate_skill")
        .expect("activate_skill should be registered")
        .parameters()
        .to_string();
    assert!(first_params.contains(&String::from("skill-one")));
    assert!(!first_params.contains(&String::from("skill-two")));

    let first_activation = agent
        .tools
        .tool_manager
        .execute_tool(
            "activate_skill",
            [("name".to_string(), json!("skill-one"))].into(),
        )
        .await
        .unwrap();
    assert!(first_activation.success);
    assert!(
        first_activation
            .output
            .contains(&String::from("Use skill one."))
    );
    assert!(agent.skill_registry().is_activated("skill-one"));
    assert!(
        agent
            .tools
            .progressive_skill_registry
            .as_ref()
            .and_then(|registry| registry.try_read().ok())
            .is_some_and(|registry| registry.is_activated("skill-one"))
    );

    agent
        .discover_skills(&[DiscoveryScope::Custom(base.join("skills-b"))])
        .await
        .unwrap();

    assert_eq!(agent.config.system_prompt, base_system_prompt);
    {
        let context = agent.memory.context.lock().await;
        assert!(context.has_projection("echo-agent:skill-catalog"));
        let catalogs: Vec<_> = context
            .messages()
            .iter()
            .filter(|message| {
                message.content.as_text_ref().is_some_and(|text| {
                    text.contains("The following skills") && text.contains("skill-one")
                })
            })
            .collect();
        assert_eq!(catalogs.len(), 1);
        assert!(catalogs.first().is_some_and(|message| {
            message
                .content
                .as_text_ref()
                .is_some_and(|text| text.contains("skill-two"))
        }));
    }

    let second_params = agent
        .tools
        .tool_manager
        .get_tool("activate_skill")
        .expect("activate_skill should stay registered")
        .parameters()
        .to_string();
    assert!(second_params.contains(&String::from("skill-one")));
    assert!(second_params.contains(&String::from("skill-two")));

    let repeat_activation = agent
        .tools
        .tool_manager
        .execute_tool(
            "activate_skill",
            [("name".to_string(), json!("skill-one"))].into(),
        )
        .await
        .unwrap();
    assert!(repeat_activation.success);
    assert!(
        repeat_activation
            .output
            .contains(&String::from("Use skill one."))
    );
    assert_eq!(agent.skill_registry().activated_count(), 1);

    let second_activation = agent
        .tools
        .tool_manager
        .execute_tool(
            "activate_skill",
            [("name".to_string(), json!("skill-two"))].into(),
        )
        .await
        .unwrap();
    assert!(second_activation.success);
    assert!(
        second_activation
            .output
            .contains(&String::from("Use skill two."))
    );
    assert_eq!(
        agent.skill_registry().activated_names(),
        vec!["skill-one".to_string(), "skill-two".to_string()]
    );

    let _ = tokio::fs::remove_dir_all(base).await;
}

#[tokio::test]
async fn registry_reconciliation_keeps_progressive_tools_visible_and_non_resurrecting()
-> Result<(), String> {
    struct RejectDeniedReplacement;
    impl crate::skills::external::SkillLoadPolicy for RejectDeniedReplacement {
        fn allows<'a>(
            &'a self,
            descriptor: &'a crate::skills::external::SkillDescriptor,
        ) -> futures::future::BoxFuture<'a, bool> {
            Box::pin(async move { !descriptor.description.contains("denied") })
        }
    }

    let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
    let skill_dir = temp.path().join("facade-skill");
    tokio::fs::create_dir_all(skill_dir.join("references"))
        .await
        .map_err(|error| error.to_string())?;
    let markdown = "---\nname: facade-skill\ndescription: Facade mutation skill\nallowed-tools: read_skill_resource\n---\n\nUse facade skill.\n";
    let skill_path = skill_dir.join("SKILL.md");
    tokio::fs::write(&skill_path, markdown)
        .await
        .map_err(|error| error.to_string())?;
    tokio::fs::write(skill_dir.join("references/guide.md"), "facade resource")
        .await
        .map_err(|error| error.to_string())?;
    let document = crate::skills::external::SkillDocument::parse_at(markdown, &skill_path)
        .map_err(|error| error.to_string())?;
    let mut descriptor = document.descriptor().clone();
    descriptor.sandbox = Some(crate::skills::external::SkillSandboxPolicy {
        isolation: Some(echo_core::sandbox::IsolationLevel::Process),
        network: Some(false),
        timeout_secs: Some(9),
        allowed_paths: Vec::new(),
        denied_paths: Vec::new(),
    });

    let mut agent = ReactAgent::new(AgentConfig::minimal("model", "agent"));
    agent
        .register_skill_descriptor(descriptor.clone())
        .await
        .map_err(|error| error.to_string())?;
    let stale_activate = agent
        .tools
        .tool_manager
        .get_tool("activate_skill")
        .ok_or_else(|| "activate_skill tool missing after registration".to_string())?;

    let activation = agent
        .tools
        .tool_manager
        .execute_tool(
            "activate_skill",
            [("name".to_string(), json!("facade-skill"))].into(),
        )
        .await
        .map_err(|error| error.to_string())?;
    assert!(activation.success);
    let resource = agent
        .tools
        .tool_manager
        .execute_tool(
            "read_skill_resource",
            [
                ("skill_name".to_string(), json!("facade-skill")),
                ("path".to_string(), json!("references/guide.md")),
            ]
            .into(),
        )
        .await
        .map_err(|error| error.to_string())?;
    assert!(resource.success);

    agent.set_skill_load_policy(Some(Arc::new(RejectDeniedReplacement)));
    let mut denied_replacement = descriptor;
    denied_replacement.description = "denied replacement".to_string();
    let denied = agent.register_skill_descriptor(denied_replacement).await;
    assert!(denied.is_err());
    assert_eq!(
        agent
            .skill_registry()
            .get_descriptor("facade-skill")
            .map(|descriptor| descriptor.description.as_str()),
        Some("Facade mutation skill")
    );
    assert!(agent.skill_registry().is_activated("facade-skill"));
    let retained_policy = agent
        .skill_registry()
        .get_active_sandbox_policy("facade-skill")
        .ok_or_else(|| "denied replacement removed active sandbox policy".to_string())?;
    assert_eq!(
        retained_policy.isolation,
        Some(echo_core::sandbox::IsolationLevel::Process)
    );
    assert_eq!(retained_policy.timeout_secs, Some(9));
    assert!(
        agent
            .skill_registry()
            .catalog_prompt()
            .is_some_and(|catalog| catalog.contains("Facade mutation skill")
                && !catalog.contains("denied replacement"))
    );
    let progressive_description = agent
        .tools
        .progressive_skill_registry
        .as_ref()
        .ok_or_else(|| "progressive registry missing".to_string())?
        .read()
        .await
        .get_descriptor("facade-skill")
        .map(|descriptor| descriptor.description.clone());
    assert_eq!(
        progressive_description.as_deref(),
        Some("Facade mutation skill")
    );
    let retained_resource = agent
        .tools
        .tool_manager
        .execute_tool(
            "read_skill_resource",
            [
                ("skill_name".to_string(), json!("facade-skill")),
                ("path".to_string(), json!("references/guide.md")),
            ]
            .into(),
        )
        .await
        .map_err(|error| error.to_string())?;
    assert!(retained_resource.success);

    assert_eq!(
        agent
            .unregister_skill_names(&["facade-skill".to_string()])
            .await,
        vec!["facade-skill".to_string()]
    );
    assert!(!agent.has_skill("facade-skill"));
    let stale_result = stale_activate
        .execute([("name".to_string(), json!("facade-skill"))].into())
        .await
        .map_err(|error| error.to_string())?;
    assert!(!stale_result.success);
    let resource_after_remove = agent
        .tools
        .tool_manager
        .execute_tool(
            "read_skill_resource",
            [
                ("skill_name".to_string(), json!("facade-skill")),
                ("path".to_string(), json!("references/guide.md")),
            ]
            .into(),
        )
        .await
        .map_err(|error| error.to_string())?;
    assert!(!resource_after_remove.success);
    Ok(())
}

#[tokio::test]
async fn intent_router_skill_activation_survives_compression_markers() -> Result<(), String> {
    let base =
        std::env::temp_dir().join(format!("echo-agent-skill-protected-{}", std::process::id()));
    let skill_dir = base.join("skills").join("skill-protected");
    let _ = tokio::fs::remove_dir_all(&base).await;
    tokio::fs::create_dir_all(&skill_dir)
        .await
        .map_err(|error| format!("create skill dir: {error}"))?;
    tokio::fs::write(
        skill_dir.join("SKILL.md"),
        "---\nname: skill-protected\ndescription: protected skill\n---\n\nProtected instructions survive compression.\n",
    )
    .await
    .map_err(|error| format!("write skill file: {error}"))?;

    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    agent
        .discover_skills(&[DiscoveryScope::Custom(base.join("skills"))])
        .await
        .map_err(|error| format!("discover skill: {error}"))?;
    agent
        .activate_skill("skill-protected")
        .await
        .map_err(|error| format!("activate skill: {error}"))?;

    {
        let mut ctx = agent.memory.context.lock().await;
        ctx.push(Message::user("old user message".to_string()));
        ctx.push(Message::assistant("old assistant message".to_string()));
        ctx.push(Message::user("latest user message".to_string()));
    }

    let compressor = crate::compression::compressor::SlidingWindowCompressor::new(1);
    agent
        .force_compress_with(&compressor)
        .await
        .map_err(|error| format!("force compress: {error}"))?;

    let messages = agent.memory.context.lock().await.messages().to_vec();
    assert!(
        messages.iter().any(|message| {
            message
                .content
                .as_text_ref()
                .is_some_and(|text| text.contains("<skill_content"))
        }),
        "activated skill block should retain the protected marker after compression"
    );
    assert!(
        messages.iter().any(|message| {
            message
                .content
                .as_text_ref()
                .is_some_and(|text| text.contains("Protected instructions survive compression."))
        }),
        "activated skill instructions should remain after compression"
    );

    let _ = tokio::fs::remove_dir_all(&base).await;
    Ok(())
}

#[tokio::test]
async fn plugin_skill_variables_cover_body() -> Result<(), String> {
    let base = std::env::temp_dir().join(format!(
        "echo-agent-plugin-skill-variables-{}",
        uuid::Uuid::new_v4()
    ));
    let skill_dir = base.join("configured-skill");
    tokio::fs::create_dir_all(&skill_dir)
        .await
        .map_err(|error| format!("create skill dir: {error}"))?;
    tokio::fs::write(
        skill_dir.join("SKILL.md"),
        "---\nname: configured-skill\ndescription: Configured skill\n---\nUse ${user_config.endpoint}.\n",
    )
    .await
    .map_err(|error| format!("write skill file: {error}"))?;
    let variables = crate::plugin::PluginVariables::new(
        base.clone(),
        base.join("plugin-data/configured-plugin"),
        base.join("project"),
    )
    .with_user_config(std::collections::HashMap::from([(
        "endpoint".to_string(),
        "http://localhost:9100".to_string(),
    )]));
    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    agent
        .load_plugin_skills_from_dir(&base, "plugin:configured-plugin", &variables)
        .await
        .map_err(|error| format!("load plugin skill: {error}"))?;

    let descriptor = agent
        .skill_descriptors()
        .into_iter()
        .find(|descriptor| descriptor.name == "configured-skill")
        .ok_or_else(|| "configured plugin skill was not registered".to_string())?;
    assert!(descriptor.hooks.is_none());

    agent
        .activate_skill("configured-skill")
        .await
        .map_err(|error| format!("activate plugin skill: {error}"))?;
    assert!(agent.get_messages().await.iter().any(|message| {
        message
            .content
            .as_text_ref()
            .is_some_and(|text| text.contains("Use http://localhost:9100."))
    }));

    let _ = tokio::fs::remove_dir_all(base).await;
    Ok(())
}

#[tokio::test]
async fn execute_tool_injects_pre_and_post_hook_messages_into_context() -> crate::error::Result<()>
{
    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    agent.add_tool(Box::new(
        MockTool::new("test_tool").with_response("tool ok"),
    ));

    let mut hooks = agent.tools.hook_registry.write().await;
    let mut hook_def = HooksDefinition::default();
    hook_def.add_rules(
        HookEvent::PreToolUse,
        vec![HookRule {
            matcher: "test_tool".into(),
            hooks: vec![HookAction::Prompt {
                prompt: "pre-hook guidance".into(),
            }],
        }],
    );
    hook_def.add_rules(
        HookEvent::PostToolUse,
        vec![HookRule {
            matcher: "test_tool".into(),
            hooks: vec![HookAction::Prompt {
                prompt: "post-hook guidance".into(),
            }],
        }],
    );
    hooks.register("hook-skill", "/tmp", hook_def);
    drop(hooks);

    let input = json!({});
    let result = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent)
        .execute_tool_with_policy(
            "hook-test".to_string(),
            "test_tool",
            &crate::tools::ToolParameters::new(),
            &input,
            None,
        )
        .await;
    let result = match result {
        Ok(output) => output,
        Err(failure) => return Err(failure.error),
    };
    assert_eq!(result.result.output, "tool ok");

    let messages: Vec<String> = agent
        .get_messages()
        .await
        .iter()
        .filter_map(|m| m.content.as_text_ref().map(str::to_string))
        .collect();
    assert!(
        messages
            .iter()
            .any(|m| m.contains(&String::from("pre-hook guidance"))),
        "pre-hook context missing from {messages:?}"
    );
    assert!(
        messages
            .iter()
            .any(|m| m.contains(&String::from("post-hook guidance")))
    );
    Ok(())
}

#[cfg(feature = "shell")]
#[tokio::test]
async fn shell_skill_uses_agent_sandbox_manager_when_present() -> crate::error::Result<()> {
    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    agent.set_sandbox_manager(Arc::new(SandboxManager::local_only()));
    agent.add_skill(Box::new(ShellSkill::new()));

    let input = json!({"command": "echo sandboxed"});
    let params = match input.clone() {
        serde_json::Value::Object(values) => values.into_iter().collect(),
        _ => crate::tools::ToolParameters::new(),
    };
    let result = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent)
        .execute_tool_with_policy("shell-test".to_string(), "shell", &params, &input, None)
        .await;
    match result {
        Ok(output) => assert!(output.result.output.contains(&String::from("sandboxed"))),
        Err(failure) => return Err(failure.error),
    }
    Ok(())
}

#[tokio::test]
async fn activate_skill_enforces_context_path_for_conditional_skills() {
    let base = std::env::temp_dir().join(format!(
        "echo-agent-conditional-skill-{}",
        std::process::id()
    ));
    let skill_dir = base.join("python-linter");
    tokio::fs::create_dir_all(&skill_dir).await.unwrap();
    tokio::fs::write(
        skill_dir.join("SKILL.md"),
        "---\nname: python-linter\ndescription: Lint Python files\n---\n\nLint the current Python file.\n",
    )
    .await
    .unwrap();

    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    agent
        .discover_skills(&[DiscoveryScope::Custom(base.clone())])
        .await
        .unwrap();

    // The standard frontmatter has no `paths` source; conditional activation
    // is a programmatic descriptor field, so replace it through the Agent
    // reconciliation API used by every registry mutation surface.
    let mut conditional = agent
        .skill_registry()
        .get_descriptor("python-linter")
        .cloned()
        .expect("discovered descriptor");
    conditional.paths = vec!["*.py".to_string()];
    let registered = agent.register_skill_descriptor(conditional).await;
    assert!(
        registered.is_ok(),
        "conditional descriptor replacement failed"
    );

    let missing = agent
        .tools
        .tool_manager
        .execute_tool(
            "activate_skill",
            [("name".to_string(), json!("python-linter"))].into(),
        )
        .await
        .unwrap();
    assert!(!missing.success);
    assert!(
        missing
            .error
            .unwrap_or_default()
            .contains(&String::from("context_path"))
    );

    let mismatch = agent
        .tools
        .tool_manager
        .execute_tool(
            "activate_skill",
            [
                ("name".to_string(), json!("python-linter")),
                ("context_path".to_string(), json!("src/main.rs")),
            ]
            .into(),
        )
        .await
        .unwrap();
    assert!(!mismatch.success);
    assert!(
        mismatch
            .error
            .unwrap_or_default()
            .contains(&String::from("cannot be activated"))
    );

    let matched = agent
        .tools
        .tool_manager
        .execute_tool(
            "activate_skill",
            [
                ("name".to_string(), json!("python-linter")),
                ("context_path".to_string(), json!("app.py")),
            ]
            .into(),
        )
        .await
        .unwrap();
    assert!(matched.success);
    assert!(
        matched
            .output
            .contains(&String::from("Lint the current Python file."))
    );

    let _ = tokio::fs::remove_dir_all(base).await;
}

// ── Agent Task Planning Tool Tests ───────────────────────────────────────────────────────

#[test]
fn react_agent_planning_tools_registration() {
    let config = AgentConfig::minimal("model", "agent").enable_tool(true);
    let agent = ReactAgent::new(config);

    // The revisioned task-relation tools are always part of the default tool
    // surface (the old enable_task-gated background-task trio was replaced by
    // the injected command-cell tools; see
    // react_agent_builder_registers_cell_tools_with_injected_registry).
    let tool_names = agent.tool_names();
    assert!(tool_names.contains(&String::from("task_create")));
    assert!(tool_names.contains(&String::from("task_update")));
    assert!(tool_names.contains(&String::from("task_list")));
}

#[test]
fn react_agent_no_planning_tools_without_flag() {
    let config = AgentConfig::minimal("model", "agent");
    let agent = ReactAgent::new(config);

    let tool_names = agent.tool_names();
    // The revisioned task-relation tools are part of the default surface
    // (registered unconditionally; no enable flag since the old background
    // trio was replaced by the injected command-cell tools).
    assert!(tool_names.contains(&String::from("task_create")));
}

// ══════════════════════════════════════════════════════════════════════════════
// Feature 1: Memory Tool auto-injection (with_memory_tools + SearchMemoryTool)
// ══════════════════════════════════════════════════════════════════════════════

#[test]
fn builder_with_memory_tools_exposes_reviewed_read_only_projection() {
    let store = Arc::new(crate::memory::store::InMemoryStore::new());
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .with_memory_tools(store)
        .build()
        .unwrap();

    let tools = agent.tool_names();
    assert!(!tools.contains(&String::from("remember")));
    assert!(
        tools.contains(&String::from("recall")),
        "Should register recall"
    );
    assert!(
        tools.contains(&String::from("search_memory")),
        "Should register search_memory"
    );
    assert!(!tools.contains(&String::from("forget")));
}

#[test]
fn builder_with_memory_tools_sets_store() {
    let store = Arc::new(crate::memory::store::InMemoryStore::new());
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .with_memory_tools(store)
        .build()
        .unwrap();

    assert!(agent.store().is_some(), "Store should be set");
}

#[test]
fn set_memory_store_registers_search_memory_tool() {
    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);

    assert!(
        !agent.tool_names().contains(&String::from("search_memory")),
        "Should not have search_memory initially"
    );

    let store = Arc::new(crate::memory::store::InMemoryStore::new());
    assert!(agent.set_memory_store(store).is_ok());

    assert!(
        agent.tool_names().contains(&String::from("search_memory")),
        "Should have search_memory after set_memory_store"
    );
}

#[tokio::test]
async fn set_memory_store_replaces_existing_memory_tools() -> Result<(), String> {
    use crate::memory::{InMemoryStore, Store};
    use echo_state::memory::typed_store::TypedMemoryStore;

    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    let first_store = Arc::new(InMemoryStore::new());
    let replacement_store = Arc::new(InMemoryStore::new());

    agent
        .set_memory_store(first_store.clone())
        .map_err(|error| error.to_string())?;
    agent
        .set_memory_store(replacement_store.clone())
        .map_err(|error| error.to_string())?;

    let mut meta = crate::memory::MemoryMeta::new(
        crate::memory::MemoryType::ProjectFact,
        crate::memory::MemorySource::ExplicitSave,
        "test",
    )
    .with_status(crate::memory::MemoryStatus::Active)
    .with_provenance(crate::memory::MemoryProvenance::draft(
        crate::memory::MemoryTrust::User,
        vec![crate::memory::MemoryEvidence::new(
            crate::memory::MemoryEvidenceRole::User,
            "replacement store marker",
        )],
    ));
    meta.provenance.approval = Some(crate::memory::MemoryApproval::new(
        "replace-test",
        "reviewer",
        1,
    ));

    let namespace = ["agent", "memories"];
    TypedMemoryStore::new(replacement_store.clone())
        .put_typed(&namespace, "marker", "replacement store marker", meta)
        .await
        .map_err(|error| error.to_string())?;
    let result = agent
        .tool_manager()
        .execute_tool(
            "recall",
            [("query".to_string(), json!("replacement"))].into(),
        )
        .await
        .map_err(|error| error.to_string())?;
    assert!(result.output.contains("replacement store marker"));
    assert!(
        first_store
            .search(&namespace, "replacement store marker", 10)
            .await
            .map_err(|error| error.to_string())?
            .is_empty()
    );
    assert!(!agent.tool_names().contains(&"remember".to_string()));
    Ok(())
}

#[tokio::test]
async fn promoted_hot_memory_remains_in_automatic_recall() -> crate::error::Result<()> {
    use crate::evolution::audit::NullChangeLog;
    use crate::evolution::{MemoryLayer, MemoryLayerManager};
    use crate::memory::{
        InMemoryStore, MemoryApproval, MemoryEvidence, MemoryEvidenceRole, MemoryMeta,
        MemoryProvenance, MemorySource, MemoryTrust, MemoryType,
    };

    let dir = tempfile::tempdir()?;
    let store = Arc::new(InMemoryStore::new());
    let manager = Arc::new(MemoryLayerManager::new(
        dir.path().to_path_buf(),
        store,
        Box::new(NullChangeLog),
    ));
    let content = "Use Rust for durable services";
    let meta = MemoryMeta::new(
        MemoryType::ProjectFact,
        MemorySource::ExplicitSave,
        "runtime",
    )
    .with_confidence(0.95)
    .with_stability(0.90)
    .with_provenance(MemoryProvenance::draft(
        MemoryTrust::User,
        vec![MemoryEvidence::new(MemoryEvidenceRole::User, content)],
    ));
    manager.write_memory("hot-recall", content, meta).await?;
    let proposal = manager
        .preview_activation("hot-recall")
        .await?
        .ok_or_else(|| crate::error::ReactError::Other("missing activation proposal".into()))?;
    manager
        .activate_draft(
            &proposal,
            MemoryApproval::new("hot-approval", "reviewer", 1),
        )
        .await?;
    assert!(matches!(
        manager.locate("hot-recall").await?,
        Some((MemoryLayer::Hot, _))
    ));

    let mut agent = ReactAgent::new(AgentConfig::minimal("model", "agent"));
    agent.install_memory_layer_manager(manager)?;
    let recalled = agent
        .recall_long_term_memories("unrelated question")
        .await?;
    assert!(
        recalled
            .iter()
            .any(|item| item.value.get("content").and_then(|v| v.as_str()) == Some(content))
    );
    Ok(())
}

#[tokio::test]
async fn layer_manager_install_and_store_replacement_keep_one_backend() -> crate::error::Result<()>
{
    use crate::evolution::MemoryLayerManager;
    use crate::evolution::audit::NullChangeLog;
    use crate::memory::{InMemoryStore, Store};

    let root = tempfile::tempdir()?;
    let first: Arc<dyn Store> = Arc::new(InMemoryStore::new());
    let managed: Arc<dyn Store> = Arc::new(InMemoryStore::new());
    let replacement: Arc<dyn Store> = Arc::new(InMemoryStore::new());
    let manager = Arc::new(MemoryLayerManager::new(
        root.path().to_path_buf(),
        managed.clone(),
        Box::new(NullChangeLog),
    ));
    let mut agent = ReactAgent::new(AgentConfig::minimal("model", "agent"));
    agent.set_memory_store(first)?;
    agent.install_memory_layer_manager(manager)?;
    assert!(
        agent
            .store()
            .is_some_and(|current| Arc::ptr_eq(current, &managed))
    );
    assert!(agent.tool_names().contains(&"remember".to_string()));

    assert!(agent.set_memory_store(replacement.clone()).is_err());
    assert!(agent.install_memory_store(replacement).await.is_err());
    assert!(
        agent
            .store()
            .is_some_and(|current| Arc::ptr_eq(current, &managed))
    );
    assert!(agent.tool_names().contains(&"remember".to_string()));
    Ok(())
}

#[tokio::test]
async fn busy_context_rejects_manager_install_without_partial_publication()
-> crate::error::Result<()> {
    use crate::evolution::MemoryLayerManager;
    use crate::evolution::audit::NullChangeLog;
    use crate::memory::InMemoryStore;

    let root = tempfile::tempdir()?;
    let manager = Arc::new(MemoryLayerManager::new(
        root.path().to_path_buf(),
        Arc::new(InMemoryStore::new()),
        Box::new(NullChangeLog),
    ));
    let mut agent = ReactAgent::new(AgentConfig::minimal("model", "agent"));
    let context = agent.memory.context.clone();
    let guard = context.lock().await;
    assert!(agent.install_memory_layer_manager(manager.clone()).is_err());
    assert!(!agent.has_memory_layer_manager());
    assert!(!agent.tool_names().contains(&"remember".to_string()));
    drop(guard);
    agent.install_memory_layer_manager(manager)?;
    assert!(agent.has_memory_layer_manager());
    Ok(())
}

#[tokio::test]
async fn search_memory_tool_returns_empty_for_no_matches() {
    let store = Arc::new(crate::memory::store::InMemoryStore::new());
    let tool = crate::tools::builtin::memory::SearchMemoryTool::new(
        store,
        vec!["test".to_string(), "memories".to_string()],
    );
    use crate::tools::Tool;
    let mut params = std::collections::HashMap::new();
    params.insert(
        "query".to_string(),
        serde_json::Value::String("Non-existent memory".to_string()),
    );
    let result = tool.execute(params).await.unwrap();
    assert!(result.success);
    assert!(result.output.contains(&String::from("No memories found")));
}

// ══════════════════════════════════════════════════════════════════════════════
// Feature 2: Token budget management (max_tool_output_tokens)
// ══════════════════════════════════════════════════════════════════════════════

#[test]
fn config_max_tool_output_tokens_default_is_none() {
    let config = AgentConfig::new("model", "agent", "prompt");
    assert_eq!(config.get_max_tool_output_tokens(), None);
}

#[test]
fn config_max_tool_output_tokens_setter() {
    let config = AgentConfig::new("model", "agent", "prompt").max_tool_output_tokens(2000);
    assert_eq!(config.get_max_tool_output_tokens(), Some(2000));
}

#[test]
fn builder_max_tool_output_tokens() {
    let agent = crate::agent::ReactAgentBuilder::new()
        .model("qwen3-max")
        .max_tool_output_tokens(1500)
        .build()
        .unwrap();

    assert_eq!(agent.config().get_max_tool_output_tokens(), Some(1500));
}

#[tokio::test]
async fn truncate_tool_output_no_limit() {
    let config = AgentConfig::new("model", "agent", "prompt");
    let agent = ReactAgent::new(config);
    let long_text = "a".repeat(10000);
    let result = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent)
        .truncate_tool_output(long_text.clone())
        .await;
    assert_eq!(
        result.len(),
        long_text.len(),
        "Should not truncate when no limit is set"
    );
}

#[tokio::test]
async fn truncate_tool_output_within_limit() {
    let config = AgentConfig::new("model", "agent", "prompt").max_tool_output_tokens(100000);
    let agent = ReactAgent::new(config);
    let short_text = "hello world".to_string();
    let result = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent)
        .truncate_tool_output(short_text.clone())
        .await;
    assert_eq!(result, short_text, "Should not truncate when within limit");
}

#[tokio::test]
async fn truncate_tool_output_exceeds_limit() {
    let config = AgentConfig::new("model", "agent", "prompt")
        .max_tool_output_tokens(10)
        .tool_output_artifacts(None);
    let agent = ReactAgent::new(config);
    let long_text = "a ".repeat(500);
    let result = crate::agent::snapshot::AgentRunSnapshot::from_agent(&agent)
        .truncate_tool_output(long_text)
        .await;
    assert!(
        result.contains(&String::from("[Output truncated")),
        "Should show truncation notice when over limit"
    );
    assert!(
        result.len() < 1000,
        "Should be significantly shorter after truncation"
    );
}

// ══════════════════════════════════════════════════════════════════════════════
// Feature 5: Dynamic Tool Registration/Deregistration
// ══════════════════════════════════════════════════════════════════════════════

#[test]
fn remove_tool_basic() {
    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    agent.add_tool(Box::new(MockTool::new("tool_a")));
    agent.add_tool(Box::new(MockTool::new("tool_b")));

    assert!(agent.tool_names().contains(&String::from("tool_a")));

    let removed = agent.remove_tool("tool_a");
    assert!(removed, "Should return true for successful removal");
    assert!(
        !agent.tool_names().contains(&String::from("tool_a")),
        "Should not exist after removal"
    );
    assert!(
        agent.tool_names().contains(&String::from("tool_b")),
        "Other tools should be unaffected"
    );
}

#[test]
fn remove_tool_nonexistent() {
    let config = AgentConfig::minimal("model", "agent");
    let agent = ReactAgent::new(config);
    let removed = agent.remove_tool("nonexistent");
    assert!(!removed, "Should return false for nonexistent tool");
}

#[test]
fn replace_tool_basic() {
    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);
    agent.add_tool(Box::new(MockTool::new("tool_x")));

    let old = agent.replace_tool(Box::new(MockTool::new("tool_x")));
    assert!(old.is_some(), "Should return the old tool");
    assert!(
        agent.tool_names().contains(&String::from("tool_x")),
        "New tool should exist"
    );
}

#[test]
fn replace_tool_when_not_exists() {
    let config = AgentConfig::minimal("model", "agent");
    let mut agent = ReactAgent::new(config);

    let old = agent.replace_tool(Box::new(MockTool::new("new_tool")));
    assert!(
        old.is_none(),
        "Should return None when old tool doesn't exist"
    );
    assert!(
        agent.tool_names().contains(&String::from("new_tool")),
        "New tool should be registered"
    );
}

struct InvocationWorkingDirProbe {
    observed: Arc<std::sync::Mutex<Vec<Option<std::path::PathBuf>>>>,
}

impl crate::tools::Tool for InvocationWorkingDirProbe {
    fn name(&self) -> &str {
        "invocation_working_dir_probe"
    }

    fn description(&self) -> &str {
        "记录实际工具调用收到的工作目录"
    }

    fn parameters(&self) -> serde_json::Value {
        json!({"type": "object", "properties": {}})
    }

    fn risk_level(&self) -> crate::tools::ToolRiskLevel {
        crate::tools::ToolRiskLevel::ReadOnly
    }

    fn execute(
        &self,
        _parameters: crate::tools::ToolParameters,
    ) -> futures::future::BoxFuture<'_, crate::error::Result<crate::tools::ToolResult>> {
        Box::pin(async {
            Err(crate::error::ReactError::Other(
                "cwd probe requires the actual invocation ToolContext".into(),
            ))
        })
    }

    fn execute_with_context<'a>(
        &'a self,
        _parameters: crate::tools::ToolParameters,
        context: &'a crate::tools::ToolContext,
    ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::tools::ToolResult>> {
        Box::pin(async move {
            self.observed
                .lock()
                .map_err(|error| crate::error::ReactError::Other(error.to_string()))?
                .push(context.working_dir.clone());
            Ok(crate::tools::ToolResult::success("cwd observed"))
        })
    }
}

fn workspace_roots_received_by_model(messages: &[Message]) -> Vec<String> {
    messages
        .iter()
        .filter_map(|message| message.content.as_text_ref())
        .flat_map(str::lines)
        .filter_map(|line| line.strip_prefix("- root: "))
        .map(str::to_string)
        .collect()
}

async fn collect_current_cwd_turn(
    agent: &ReactAgent,
    message_entry: bool,
    mode: crate::agent::react::run::types::StreamMode,
    invocation: echo_core::agent::AgentInvocationContext,
) -> crate::error::Result<Vec<crate::agent::AgentEvent>> {
    use crate::agent::react::run::types::StreamMode;
    use futures::StreamExt;

    // 直接调用现有两条prepare入口与同一producer；不另建执行器或模拟ToolContext。
    let stream = if message_entry {
        let message = Message::user("observe current working directory".into());
        let cancel = crate::agent::CancellationToken::new();
        match mode {
            StreamMode::Chat => {
                agent
                    .chat_stream_message_with_invocation_context(message, cancel, invocation)
                    .await?
            }
            StreamMode::Execute => {
                agent
                    .execute_stream_message_with_invocation_context(message, cancel, invocation)
                    .await?
            }
        }
    } else {
        agent
            .run_stream_entry("observe current working directory", mode, Some(invocation))
            .await?
    };
    stream
        .collect::<Vec<_>>()
        .await
        .into_iter()
        .collect::<crate::error::Result<Vec<_>>>()
}

#[tokio::test]
async fn invocation_cwd_matches_model_workspace_and_tool_without_mutating_config()
-> crate::error::Result<()> {
    use crate::agent::react::run::types::StreamMode;
    use crate::testing::MockLlmClient;

    for message_entry in [false, true] {
        let root = tempfile::tempdir()
            .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;
        let configured_a = root.path().join("configured-a");
        let invocation_b = root.path().join("invocation-b");
        let observed = Arc::new(std::sync::Mutex::new(Vec::new()));
        let client = Arc::new(
            MockLlmClient::new()
                .then_tool_call("cwd-b", "invocation_working_dir_probe", "{}")
                .with_response("invocation B complete")
                .then_tool_call("cwd-a", "invocation_working_dir_probe", "{}")
                .with_response("plain A complete"),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(client.clone())
            .system_prompt("system")
            .auto_project_rules(false)
            .working_dir(configured_a.clone())
            .tool(Box::new(InvocationWorkingDirProbe {
                observed: observed.clone(),
            }))
            .build()?;
        let invocation = echo_core::agent::AgentInvocationContext {
            working_dir: Some(invocation_b.clone()),
            ..Default::default()
        };
        let events =
            collect_current_cwd_turn(&agent, message_entry, StreamMode::Chat, invocation).await?;
        assert!(events.iter().any(|event| matches!(event,
            crate::agent::AgentEvent::FinalAnswer(answer) if answer == "invocation B complete"
        )));
        assert_eq!(agent.working_dir(), Some(configured_a.clone()));
        assert_eq!(
            agent
                .chat("observe plain configured working directory")
                .await?,
            "plain A complete"
        );
        assert_eq!(agent.working_dir(), Some(configured_a.clone()));
        assert_eq!(
            observed
                .lock()
                .map_err(|error| crate::error::ReactError::Other(error.to_string()))?
                .as_slice(),
            &[Some(invocation_b.clone()), Some(configured_a.clone())],
        );
        let requests = client.all_calls();
        assert_eq!(requests.len(), 4);
        for (index, request) in requests.iter().enumerate() {
            let expected = if index < 2 {
                &invocation_b
            } else {
                &configured_a
            };
            assert_eq!(
                workspace_roots_received_by_model(request),
                vec![expected.display().to_string()]
            );
        }
    }
    Ok(())
}

#[tokio::test]
async fn absent_invocation_cwd_uses_restored_checkpoint_for_model_and_tool()
-> crate::error::Result<()> {
    use crate::agent::react::run::types::StreamMode;
    use crate::testing::MockLlmClient;

    for message_entry in [false, true] {
        for mode in [StreamMode::Chat, StreamMode::Execute] {
            let root = tempfile::tempdir()
                .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;
            let configured_a = root.path().join("configured-a");
            let restored_c = root.path().join("restored-c");
            let state = Arc::new(crate::state::FileRuntimeStateStore::new(
                root.path().join("runtime"),
            )?);
            let mut checkpoint = crate::state::AgentCheckpoint::new("cwd-restore-state");
            checkpoint.working_dir = Some(restored_c.clone());
            checkpoint.messages_json = crate::state::AgentCheckpoint::serialize_payload(
                vec![
                    Message::system("system".into()),
                    Message::user("historical input".into()),
                ],
                None,
            )
            .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;
            crate::state::RuntimeStateStore::save_checkpoint(state.as_ref(), &checkpoint).await?;
            let traces = Arc::new(crate::trace::InMemoryRunStore::new());
            let observed = Arc::new(std::sync::Mutex::new(Vec::new()));
            let client = Arc::new(
                MockLlmClient::new()
                    .then_tool_call("cwd-c", "invocation_working_dir_probe", "{}")
                    .with_response("restored C complete"),
            );
            let agent = ReactAgentBuilder::new()
                .llm_client(client.clone())
                .system_prompt("system")
                .auto_project_rules(false)
                .conversation_id("cwd-restore-state")
                .working_dir(configured_a.clone())
                .state_store(state)
                .with_run_store(traces.clone())
                .tool(Box::new(InvocationWorkingDirProbe {
                    observed: observed.clone(),
                }))
                .build()?;
            assert_eq!(agent.working_dir(), Some(configured_a));
            let events =
                collect_current_cwd_turn(&agent, message_entry, mode, Default::default()).await?;
            assert!(events.iter().any(|event| matches!(event,
                crate::agent::AgentEvent::FinalAnswer(answer) if answer == "restored C complete"
            )));
            assert_eq!(agent.working_dir(), Some(restored_c.clone()));
            assert_eq!(
                observed
                    .lock()
                    .map_err(|error| crate::error::ReactError::Other(error.to_string()))?
                    .as_slice(),
                &[Some(restored_c.clone())]
            );
            let requests = client.all_calls();
            assert_eq!(requests.len(), 2);
            for request in requests {
                assert_eq!(
                    workspace_roots_received_by_model(&request),
                    vec![restored_c.display().to_string()]
                );
            }
            let runs = crate::trace::RunStore::list_all(traces.as_ref(), 10).await?;
            assert_eq!(runs.len(), 1);
            let summary = runs
                .first()
                .ok_or_else(|| crate::error::ReactError::Other("cold cwd trace missing".into()))?;
            let run = crate::trace::RunStore::load(traces.as_ref(), &summary.run_id)
                .await?
                .ok_or_else(|| {
                    crate::error::ReactError::Other("cold cwd trace body missing".into())
                })?;
            assert_eq!(run.events.iter().filter(|event| matches!(event,
                crate::trace::RunEvent::CheckpointResumed { conversation_id, .. } if conversation_id == "cwd-restore-state"
            )).count(), 1);
            assert_eq!(run.status, crate::trace::RunStatus::Completed);
        }
    }
    Ok(())
}

#[tokio::test]
async fn invocation_history_is_inserted_before_current_input() -> Result<(), String> {
    use crate::agent::react::run::types::StreamMode;

    // Disable workspace rule injection: this test asserts exact message
    // content ordering, which must not depend on whether the checkout
    // directory happens to carry project rule files (e.g. AGENTS.md).
    let config =
        AgentConfig::new("test-model", "history-order", "system prompt").auto_project_rules(false);
    let agent = ReactAgent::new(config);
    let history = vec![
        Message::user("inherited user".to_string()),
        Message::assistant("inherited assistant".to_string()),
    ];

    let invocation = echo_core::agent::AgentInvocationContext {
        history: Some(history),
        ..Default::default()
    };
    agent
        .prepare_stream_context(
            StreamMode::Chat,
            "current input",
            &invocation,
            None,
            None,
            None,
        )
        .await
        .map_err(|error| error.to_string())?;

    let messages = agent.memory.context.lock().await.messages().to_vec();
    let position = |needle: &str| {
        messages.iter().position(|message| {
            message
                .text_content()
                .is_some_and(|content| content == needle)
        })
    };
    let system = position("system prompt").ok_or_else(|| "system prompt missing".to_string())?;
    let inherited_user =
        position("inherited user").ok_or_else(|| "inherited user missing".to_string())?;
    let inherited_assistant =
        position("inherited assistant").ok_or_else(|| "inherited assistant missing".to_string())?;
    let current = position("current input").ok_or_else(|| "current input missing".to_string())?;

    assert!(system < inherited_user);
    assert!(inherited_user < inherited_assistant);
    assert!(inherited_assistant < current);
    Ok(())
}

#[tokio::test]
async fn q_flt_v07_corrupt_checkpoint_fails_closed_without_overwrite() -> Result<(), String> {
    let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
    let checkpoint_dir = temp.path().join("runtime_state").join("_runtime_owners");
    std::fs::create_dir_all(&checkpoint_dir).map_err(|error| error.to_string())?;
    let checkpoint_path = checkpoint_dir.join(format!(
        "{}.json",
        echo_core::utils::fs::encode_utf8_path_identity("corrupt-conversation")
    ));
    let corrupt = b"{ truncated checkpoint";
    std::fs::write(&checkpoint_path, corrupt).map_err(|error| error.to_string())?;

    let config = AgentConfig::new("test-model", "restore-barrier", "system prompt")
        .conversation_id("corrupt-conversation");
    let mut agent = ReactAgent::new(config);
    let store =
        crate::state::FileRuntimeStateStore::new(temp.path()).map_err(|error| error.to_string())?;
    agent.set_state_store(Arc::new(store));
    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("preserve me".to_string()));

    let result = agent.restore_thread_context().await;
    assert!(result.is_err());
    assert!(
        agent
            .memory
            .context
            .lock()
            .await
            .messages()
            .iter()
            .any(|message| {
                message
                    .text_content()
                    .is_some_and(|content| content == "preserve me")
            })
    );
    assert_eq!(
        std::fs::read(&checkpoint_path).map_err(|error| error.to_string())?,
        corrupt
    );
    Ok(())
}

#[tokio::test]
async fn cold_chat_restores_persisted_checkpoint() -> Result<(), String> {
    use crate::state::RuntimeStateStore;

    let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
    let store = Arc::new(
        crate::state::FileRuntimeStateStore::new(temp.path()).map_err(|error| error.to_string())?,
    );
    let mut checkpoint = crate::state::AgentCheckpoint::new("cold-chat");
    checkpoint.messages_json = crate::state::AgentCheckpoint::serialize_payload(
        vec![
            Message::system("system prompt".to_string()),
            Message::user("persisted turn".to_string()),
        ],
        None,
    )
    .map_err(|error| error.to_string())?;
    store
        .save_checkpoint(&checkpoint)
        .await
        .map_err(|error| error.to_string())?;

    let config = AgentConfig::new("test-model", "cold-chat-agent", "system prompt")
        .conversation_id("cold-chat");
    let mut agent = ReactAgent::new(config);
    agent.set_state_store(store);
    agent
        .restore_chat_context_if_cold()
        .await
        .map_err(|error| error.to_string())?;

    assert!(agent.get_messages().await.iter().any(|message| {
        message
            .text_content()
            .is_some_and(|content| content == "persisted turn")
    }));
    Ok(())
}

#[tokio::test]
async fn checkpoint_skill_activation_restores_resource_tool_authority() -> Result<(), String> {
    use crate::state::RuntimeStateStore;

    let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
    let skill_root = temp.path().join("skills");
    let skill_dir = skill_root.join("resume-skill");
    tokio::fs::create_dir_all(skill_dir.join("references"))
        .await
        .map_err(|error| error.to_string())?;
    tokio::fs::write(
        skill_dir.join("SKILL.md"),
        "---\nname: resume-skill\ndescription: checkpoint skill\nallowed-tools: read_skill_resource\n---\n\nUse the saved reference.\n",
    )
    .await
    .map_err(|error| error.to_string())?;
    tokio::fs::write(skill_dir.join("references/guide.md"), "restored resource")
        .await
        .map_err(|error| error.to_string())?;

    let store = Arc::new(
        crate::state::FileRuntimeStateStore::new(temp.path().join("state"))
            .map_err(|error| error.to_string())?,
    );
    let mut checkpoint = crate::state::AgentCheckpoint::new("skill-roundtrip");
    checkpoint.messages_json = crate::state::AgentCheckpoint::serialize_payload(
        vec![Message::system("system prompt".to_string())],
        None,
    )
    .map_err(|error| error.to_string())?;
    checkpoint.active_skills = vec!["resume-skill".to_string()];
    store
        .save_checkpoint(&checkpoint)
        .await
        .map_err(|error| error.to_string())?;

    let config = AgentConfig::new("test-model", "skill-resume-agent", "system prompt")
        .conversation_id("skill-roundtrip");
    let mut agent = ReactAgent::new(config);
    agent
        .discover_skills(&[DiscoveryScope::Custom(skill_root)])
        .await
        .map_err(|error| error.to_string())?;
    let mut descriptor = agent
        .skill_registry()
        .get_descriptor("resume-skill")
        .cloned()
        .ok_or_else(|| "resume-skill descriptor missing".to_string())?;
    descriptor.sandbox = Some(crate::skills::external::SkillSandboxPolicy {
        isolation: Some(echo_core::sandbox::IsolationLevel::Process),
        network: Some(false),
        timeout_secs: Some(5),
        allowed_paths: Vec::new(),
        denied_paths: Vec::new(),
    });
    agent
        .register_skill_descriptor(descriptor)
        .await
        .map_err(|error| error.to_string())?;
    agent.set_state_store(store);

    let restored = agent
        .resume_from_state_store()
        .await
        .map_err(|error| error.to_string())?;
    assert!(restored.is_some());
    assert!(agent.skill_registry().is_activated("resume-skill"));
    assert!(
        agent
            .tools
            .progressive_skill_registry
            .as_ref()
            .and_then(|registry| registry.try_read().ok())
            .is_some_and(|registry| registry.is_activated("resume-skill"))
    );
    let policy = agent
        .skill_registry()
        .get_active_sandbox_policy("resume-skill")
        .ok_or_else(|| "restored sandbox policy missing".to_string())?;
    assert_eq!(
        policy.isolation,
        Some(echo_core::sandbox::IsolationLevel::Process)
    );
    assert_eq!(policy.network, Some(false));
    assert_eq!(policy.timeout_secs, Some(5));

    let resource = agent
        .tools
        .tool_manager
        .execute_tool(
            "read_skill_resource",
            [
                ("skill_name".to_string(), json!("resume-skill")),
                ("path".to_string(), json!("references/guide.md")),
            ]
            .into(),
        )
        .await
        .map_err(|error| error.to_string())?;
    assert!(resource.success);
    assert!(resource.output.contains("restored resource"));
    Ok(())
}

#[tokio::test]
async fn warm_chat_history_is_not_replaced_by_checkpoint() -> Result<(), String> {
    use crate::state::RuntimeStateStore;

    let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
    let store = Arc::new(
        crate::state::FileRuntimeStateStore::new(temp.path()).map_err(|error| error.to_string())?,
    );
    let mut checkpoint = crate::state::AgentCheckpoint::new("warm-chat");
    checkpoint.messages_json = crate::state::AgentCheckpoint::serialize_payload(
        vec![
            Message::system("system prompt".to_string()),
            Message::user("stale persisted turn".to_string()),
        ],
        None,
    )
    .map_err(|error| error.to_string())?;
    store
        .save_checkpoint(&checkpoint)
        .await
        .map_err(|error| error.to_string())?;

    let config = AgentConfig::new("test-model", "warm-chat-agent", "system prompt")
        .conversation_id("warm-chat");
    let mut agent = ReactAgent::new(config);
    agent.set_state_store(store);
    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("live turn".to_string()));
    agent
        .restore_chat_context_if_cold()
        .await
        .map_err(|error| error.to_string())?;

    let messages = agent.get_messages().await;
    assert!(messages.iter().any(|message| {
        message
            .text_content()
            .is_some_and(|content| content == "live turn")
    }));
    assert!(!messages.iter().any(|message| {
        message
            .text_content()
            .is_some_and(|content| content == "stale persisted turn")
    }));
    Ok(())
}

// ── recall_long_term_memories injects into the current user turn ─────────────

/// Recalled memories are dynamic per turn, so they must not be appended as
/// permanent system messages where they destabilize the provider's prompt-cache
/// prefix. The current turn owns one replaceable projection before the request.
#[tokio::test]
async fn recall_injects_memories_into_current_user_message() -> Result<(), String> {
    use crate::agent::react::run::types::StreamMode;
    use crate::memory::InMemoryStore;
    use echo_core::memory::{
        MemoryApproval, MemoryEvidence, MemoryEvidenceRole, MemoryMeta, MemoryProvenance,
        MemorySource, MemoryStatus, MemoryTrust, MemoryType, TypedMemoryValue,
    };

    let agent_name = "recall_role_test";
    let config = AgentConfig::new("test-model", agent_name, "system prompt").enable_memory(false);
    let mut agent = ReactAgent::new(config);

    // Seed the long-term store with a fact that will be recalled by exact-text search.
    // (stage4 A2) Seed the unified namespace ["agent","memories"] — recall no
    // longer reads the legacy per-agent namespace.
    let store: Arc<dyn crate::memory::Store> = Arc::new(InMemoryStore::new());
    let mut provenance = MemoryProvenance::draft(
        MemoryTrust::User,
        vec![MemoryEvidence::new(
            MemoryEvidenceRole::User,
            "user prefers Rust over Python",
        )],
    );
    provenance.approval = Some(MemoryApproval::new("recall-fixture", "reviewer", 1));
    let value = TypedMemoryValue::new(
        "user prefers Rust over Python",
        MemoryMeta::new(
            MemoryType::UserPreference,
            MemorySource::ExplicitSave,
            "preferences",
        )
        .with_status(MemoryStatus::Active)
        .with_provenance(provenance),
    )
    .to_value()
    .map_err(|error| error.to_string())?;
    store
        .put(&["agent", "memories"], "fact-1", value)
        .await
        .map_err(|error| error.to_string())?;
    agent
        .set_memory_store(store)
        .map_err(|error| error.to_string())?;

    // Drive prepare_stream_context with a query that should hit the seeded fact.
    let recalled = agent
        .prepare_stream_context(
            StreamMode::Chat,
            "Rust",
            &Default::default(),
            None,
            None,
            None,
        )
        .await
        .map_err(|error| error.to_string())?;
    assert!(
        recalled >= 1,
        "expected at least one memory to be recalled, got {recalled}"
    );

    // The context keeps stable workspace/runtime state before the current user
    // request so provider prefix caches can reuse the shared project context
    // across different requests.
    let ctx = agent.memory.context.lock().await;
    let messages = ctx.messages();

    let memory_systems: Vec<&Message> = messages
        .iter()
        .filter(|m| {
            m.role == Role::System
                && m.text_content()
                    .is_some_and(|c| c.contains("[memory_context]"))
        })
        .collect();
    assert_eq!(
        memory_systems.len(),
        0,
        "memory_context should not be injected as system message, found: {:?}",
        messages
            .iter()
            .map(|m| format!("{:?}: {:?}", m.role, m.text_content()))
            .collect::<Vec<_>>()
    );

    let memory_users: Vec<&Message> = messages
        .iter()
        .filter(|m| {
            m.role == Role::User
                && m.text_content()
                    .is_some_and(|c| c.contains("[memory_context]"))
        })
        .collect();
    assert_eq!(
        memory_users.len(),
        1,
        "expected exactly one user message with [memory_context] marker"
    );

    assert!(
        memory_users
            .first()
            .and_then(|message| message.text_content())
            .is_some_and(|c| c.contains("user prefers Rust over Python")),
        "memory_context user message should contain seeded fact"
    );
    assert!(
        !memory_users
            .first()
            .and_then(|message| message.text_content())
            .is_some_and(|c| c.contains("[current_user_request]") || c.contains("\nRust")),
        "memory_context user message must not duplicate the current request"
    );

    let context_then_request = messages.windows(2).any(|pair| {
        pair[0].role == Role::User
            && pair[0]
                .text_content()
                .is_some_and(|c| c.contains("[runtime_context:memory]"))
            && pair[1].role == Role::User
            && pair[1].text_content().is_some_and(|c| c == "Rust")
    });
    assert!(
        context_then_request,
        "expected runtime context before current request so shared workspace context remains prefix-cacheable"
    );

    drop(ctx);
    agent
        .prepare_stream_context(
            StreamMode::Chat,
            "unrelated-query",
            &Default::default(),
            None,
            None,
            None,
        )
        .await
        .map_err(|error| error.to_string())?;
    let ctx = agent.memory.context.lock().await;
    let runtime_contexts: Vec<_> = ctx
        .messages()
        .iter()
        .filter(|message| {
            message
                .text_content()
                .is_some_and(|content| content.contains("[runtime_context:memory]"))
        })
        .collect();
    assert!(
        runtime_contexts.len() <= 1,
        "turn runtime context must use latest-wins replacement"
    );
    assert!(ctx.messages().iter().all(|message| {
        message
            .text_content()
            .is_none_or(|content| !content.contains("user prefers Rust over Python"))
    }));
    Ok(())
}

// ── save_transcript_projection ──────────────────────────────────────────────

#[tokio::test]
async fn managed_compaction_checkpoint_preserves_retained_transcript_ordinals()
-> crate::error::Result<()> {
    struct EvictFinal;

    impl crate::compression::ContextCompressor for EvictFinal {
        fn compress(
            &self,
            input: echo_core::compression::CompressionInput,
        ) -> futures::future::BoxFuture<
            '_,
            crate::error::Result<echo_core::compression::CompressionOutput>,
        > {
            Box::pin(async move {
                let mut messages = input.messages;
                let evicted = messages.pop().into_iter().collect();
                Ok(echo_core::compression::CompressionOutput {
                    messages,
                    evicted,
                    checkpoint: None,
                })
            })
        }
    }

    let root = tempfile::tempdir()?;
    let conversation_root = root.path().join("conversation");
    let runtime_root = root.path().join("runtime");
    let scope = "managed-compaction-retained-ordinals";
    let mut agent =
        ReactAgent::new(AgentConfig::new("test-model", "agent", "system").conversation_id(scope));
    agent.set_conversation_store(Arc::new(crate::memory::FileConversationStore::new(
        &conversation_root,
    )?));
    agent.set_state_store(Arc::new(crate::state::FileRuntimeStateStore::new(
        &runtime_root,
    )?));
    let original = [
        Message::user("same user text".to_string()),
        Message::assistant_with_tools(vec![crate::llm::types::ToolCall {
            provider_source: None,
            id: "retained-tool-call".to_string(),
            call_type: "function".to_string(),
            function: crate::llm::types::FunctionCall {
                name: "read_file".to_string(),
                arguments: "{}".to_string(),
            },
        }]),
        Message::tool_result(
            "retained-tool-call".to_string(),
            "read_file".to_string(),
            "retained tool result".to_string(),
        ),
        Message::assistant("same final text".to_string()),
    ];
    {
        let mut context = agent.memory.context.lock().await;
        for message in original.iter().cloned() {
            context.push(message);
        }
    }
    agent.force_checkpoint().await?;
    let before = crate::memory::ConversationStore::get_messages(
        &crate::memory::FileConversationStore::new(&conversation_root)?,
        scope,
    )
    .await?;
    assert_eq!(before.len(), 4);

    let (stats, _) = agent.force_compress_with(&EvictFinal).await?;
    assert_eq!(stats.evicted, 1);
    agent.force_checkpoint().await?;
    let after = crate::memory::ConversationStore::get_messages(
        &crate::memory::FileConversationStore::new(&conversation_root)?,
        scope,
    )
    .await?;
    assert_eq!(
        after, before,
        "retained messages must not be appended again"
    );

    let state = crate::state::RuntimeStateStore::load_runtime_state(
        &crate::state::FileRuntimeStateStore::new(&runtime_root)?,
        scope,
        scope,
    )
    .await?
    .ok_or_else(|| crate::error::ReactError::Other("runtime state missing".to_string()))?;
    let checkpoint = state
        .checkpoint
        .ok_or_else(|| crate::error::ReactError::Other("runtime checkpoint missing".to_string()))?;
    let payload = checkpoint.restore_managed_runtime_payload()?;
    assert_eq!(
        serde_json::to_value(
            payload
                .messages
                .into_iter()
                .filter(|message| message.role != Role::System)
                .collect::<Vec<_>>()
        )?,
        serde_json::to_value(original.iter().take(3).cloned().collect::<Vec<_>>())?,
    );
    let cursor = payload
        .transcript_projection
        .ok_or_else(|| crate::error::ReactError::Other("runtime cursor missing".to_string()))?;
    assert_eq!(cursor.next_ordinal, 4);
    assert_eq!(
        cursor
            .projected
            .iter()
            .map(|message| message.ordinal)
            .collect::<Vec<_>>(),
        vec![0, 1, 2]
    );

    // A new turn may repeat old text; only the retained window reuses ordinals.
    {
        let mut context = agent.memory.context.lock().await;
        context.push(Message::user("same user text".to_string()));
        context.push(Message::assistant("same final text".to_string()));
    }
    agent.force_checkpoint().await?;
    let appended = crate::memory::ConversationStore::get_messages(
        &crate::memory::FileConversationStore::new(&conversation_root)?,
        scope,
    )
    .await?;
    let ordinals = appended
        .iter()
        .map(|message| {
            crate::memory::transcript_projection_meta(message)?
                .map(|meta| meta.ordinal)
                .ok_or_else(|| {
                    crate::error::ReactError::Other("transcript ordinal missing".to_string())
                })
        })
        .collect::<crate::error::Result<Vec<_>>>()?;
    assert_eq!(ordinals, vec![0, 1, 2, 3, 4, 5]);
    Ok(())
}

#[tokio::test]
async fn canonical_root_agent_refresh_and_setters_keep_derived_system_and_scope()
-> crate::error::Result<()> {
    let root = tempfile::tempdir()?;
    // Isolate base/override selection and canonical identity from project-rule
    // discovery, which has its own feature-dependent harness inputs.
    let mut agent = ReactAgent::new(
        AgentConfig::new("test-model", "root-agent", "original root").auto_project_rules(false),
    );
    {
        let mut context = agent.memory.context.lock().await;
        let mut messages = context.messages().to_vec();
        messages.insert(0, Message::system("derived system objective".to_string()));
        context.set_messages(messages);
        context.apply_projection_scope(
            "root-agent-test",
            &[crate::compression::ContextProjection {
                marker: "retained-root-scope".to_string(),
                message: Some(Message::user("protected source".to_string())),
            }],
        );
    }
    crate::agent::Agent::set_system_prompt(&agent, "trait root");
    let systems = agent
        .get_messages()
        .await
        .into_iter()
        .filter(|message| message.role == Role::System)
        .filter_map(|message| message.content.as_text())
        .collect::<Vec<_>>();
    assert!(
        systems
            .iter()
            .any(|text| text == "derived system objective")
    );
    assert!(systems.iter().any(|text| text == "trait root"));
    agent.set_working_dir(Some(root.path().to_path_buf()));
    let refreshed = agent.get_messages().await;
    let current_after_directory = agent.current_system_prompt();
    assert_eq!(current_after_directory, "trait root");
    assert!(
        refreshed.iter().any(|message| message.role == Role::System
            && message.content.as_text_ref() == Some(current_after_directory.as_str())),
        "working-directory refresh must retain the effective prompt override"
    );
    assert!(refreshed.iter().any(|message| message.role == Role::System
        && message.content.as_text_ref() == Some("derived system objective")));
    ReactAgent::set_system_prompt(&mut agent, "async root".to_string()).await;
    let messages = agent.get_messages().await;
    assert_eq!(crate::agent::Agent::system_prompt(&agent), "async root");
    let current_after_base_setter = agent.current_system_prompt();
    assert_eq!(current_after_base_setter, "trait root");
    assert!(
        messages.iter().any(|message| message.role == Role::System
            && message.content.as_text_ref() == Some(current_after_base_setter.as_str())),
        "base setter must render the same effective prompt as the current getter"
    );
    assert!(messages.iter().any(|message| message.role == Role::System
        && message.content.as_text_ref() == Some("derived system objective")));
    assert!(
        agent
            .memory
            .context
            .lock()
            .await
            .has_projection("retained-root-scope")
    );
    agent.replace_system_prompt("replacement root");
    assert_eq!(agent.current_system_prompt(), "replacement root");
    assert_eq!(
        crate::agent::Agent::system_prompt(&agent),
        "replacement root"
    );
    let replaced = agent.get_messages().await;
    assert!(replaced.iter().any(|message| message.role == Role::System
        && message.content.as_text_ref() == Some("replacement root")));
    assert!(replaced.iter().any(|message| message.role == Role::System
        && message.content.as_text_ref() == Some("derived system objective")));
    assert!(
        agent
            .memory
            .context
            .lock()
            .await
            .has_projection("retained-root-scope")
    );
    agent.reset_messages().await;
    let reset = agent.get_messages().await;
    assert_eq!(reset.len(), 1);
    assert_eq!(
        reset
            .first()
            .and_then(|message| message.content.as_text_ref()),
        Some("replacement root")
    );
    Ok(())
}

fn managed_compaction_agent(
    root: &std::path::Path,
    scope: &str,
) -> crate::error::Result<ReactAgent> {
    let mut agent =
        ReactAgent::new(AgentConfig::new("test-model", "agent", "system").conversation_id(scope));
    agent.set_conversation_store(Arc::new(crate::memory::FileConversationStore::new(
        root.join("conversation"),
    )?));
    agent.set_state_store(Arc::new(crate::state::FileRuntimeStateStore::new(
        root.join("runtime"),
    )?));
    Ok(agent)
}

async fn managed_compaction_transcript(
    root: &std::path::Path,
    scope: &str,
) -> crate::error::Result<Vec<crate::memory::StoredMessage>> {
    crate::memory::ConversationStore::get_messages(
        &crate::memory::FileConversationStore::new(root.join("conversation"))?,
        scope,
    )
    .await
}

#[tokio::test]
async fn managed_compaction_horizon_restart_and_empty_preserve_fact_frontier()
-> crate::error::Result<()> {
    struct Empty;
    impl crate::compression::ContextCompressor for Empty {
        fn compress(
            &self,
            input: echo_core::compression::CompressionInput,
        ) -> futures::future::BoxFuture<
            '_,
            crate::error::Result<echo_core::compression::CompressionOutput>,
        > {
            Box::pin(async move {
                Ok(echo_core::compression::CompressionOutput {
                    messages: Vec::new(),
                    evicted: input.messages,
                    checkpoint: None,
                })
            })
        }
    }
    let root = tempfile::tempdir()?;
    let scope = "managed-horizon-restart";
    let agent = managed_compaction_agent(root.path(), scope)?;
    {
        let mut context = agent.memory.context.lock().await;
        context.push(Message::user("same text".to_string()));
        context.push(Message::assistant_with_tools(vec![
            crate::llm::types::ToolCall {
                provider_source: None,
                id: "horizon-call".to_string(),
                call_type: "function".to_string(),
                function: crate::llm::types::FunctionCall {
                    name: "read_file".to_string(),
                    arguments: "{}".to_string(),
                },
            },
        ]));
        context.push(Message::tool_result(
            "horizon-call".to_string(),
            "read_file".to_string(),
            "old raw tool result".repeat(20),
        ));
        context.push(Message::assistant("old final".to_string()));
        context.push(Message::user("same text".to_string()));
        context.push(Message::assistant("current final".to_string()));
    }
    agent.force_checkpoint().await?;
    let original = managed_compaction_transcript(root.path(), scope).await?;
    assert_eq!(original.len(), 6);
    let horizon = crate::compression::horizon::VisibilityHorizonCompressor::new(
        crate::compression::horizon::VisibilityHorizonConfig {
            active_window_turns: 0,
            enable_global_objective: true,
            global_objective: Some("persist model objective".to_string()),
            ..Default::default()
        },
    );
    agent.force_compress_with(&horizon).await?;
    let model_view = serde_json::to_value(agent.get_messages().await)?;
    assert!(model_view.to_string().contains("Horizon compact"));
    assert!(model_view.to_string().contains("persist model objective"));
    assert_eq!(
        managed_compaction_transcript(root.path(), scope).await?,
        original
    );
    let restored = managed_compaction_agent(root.path(), scope)?;
    restored.resume_from_state_store().await?.ok_or_else(|| {
        crate::error::ReactError::Other("compacted checkpoint missing".to_string())
    })?;
    assert_eq!(
        serde_json::to_value(restored.get_messages().await)?,
        model_view
    );
    restored.force_checkpoint().await?;
    assert_eq!(
        managed_compaction_transcript(root.path(), scope).await?,
        original
    );
    let checkpoint = crate::state::RuntimeStateStore::get_checkpoint(
        &crate::state::FileRuntimeStateStore::new(root.path().join("runtime"))?,
        scope,
    )
    .await?
    .ok_or_else(|| crate::error::ReactError::Other("runtime checkpoint missing".to_string()))?;
    let bound = checkpoint
        .restore_managed_runtime_payload()?
        .transcript_projection
        .ok_or_else(|| crate::error::ReactError::Other("projection cursor missing".to_string()))?;
    assert_eq!(
        bound
            .projected
            .iter()
            .map(|item| item.ordinal)
            .collect::<Vec<_>>(),
        vec![0, 3, 4, 5]
    );
    assert_eq!(bound.context_only.as_ref().map(Vec::len), Some(2));
    restored.force_compress_with(&Empty).await?;
    restored.force_checkpoint().await?;
    assert_eq!(
        managed_compaction_transcript(root.path(), scope).await?,
        original
    );
    {
        let mut context = restored.memory.context.lock().await;
        context.push(Message::user("same text".to_string()));
        context.push(Message::assistant("current final".to_string()));
    }
    restored.force_checkpoint().await?;
    let messages = managed_compaction_transcript(root.path(), scope).await?;
    let ordinals = messages
        .iter()
        .map(|message| {
            crate::memory::transcript_projection_meta(message)?
                .map(|item| item.ordinal)
                .ok_or_else(|| crate::error::ReactError::Other("missing fact ordinal".to_string()))
        })
        .collect::<crate::error::Result<Vec<_>>>()?;
    assert_eq!(ordinals, vec![0, 1, 2, 3, 4, 5, 6, 7]);
    Ok(())
}

struct CompactionRewrite;
impl crate::compression::ContextCompressor for CompactionRewrite {
    fn compress(
        &self,
        input: echo_core::compression::CompressionInput,
    ) -> futures::future::BoxFuture<
        '_,
        crate::error::Result<echo_core::compression::CompressionOutput>,
    > {
        Box::pin(async move {
            let first = input.messages.first().cloned().ok_or_else(|| {
                crate::error::ReactError::Other("first input missing".to_string())
            })?;
            let last =
                input.messages.last().cloned().ok_or_else(|| {
                    crate::error::ReactError::Other("last input missing".to_string())
                })?;
            let evicted = input
                .messages
                .iter()
                .skip(1)
                .take(input.messages.len().saturating_sub(2))
                .cloned()
                .collect();
            Ok(echo_core::compression::CompressionOutput {
                messages: vec![
                    first,
                    Message::user("derived model-only view".to_string()),
                    last,
                ],
                evicted,
                checkpoint: None,
            })
        })
    }
}

struct CompactionObserver(Arc<AtomicUsize>);
impl crate::compression::ContextCompressor for CompactionObserver {
    fn compress(
        &self,
        input: echo_core::compression::CompressionInput,
    ) -> futures::future::BoxFuture<
        '_,
        crate::error::Result<echo_core::compression::CompressionOutput>,
    > {
        Box::pin(async move {
            Ok(echo_core::compression::CompressionOutput {
                messages: input.messages,
                evicted: Vec::new(),
                checkpoint: None,
            })
        })
    }
    fn context_committed(&self, _messages: &[Message]) {
        self.0.fetch_add(1, Ordering::SeqCst);
    }
}

struct CompactionPromotion {
    calls: Arc<AtomicUsize>,
    entered: Arc<tokio::sync::Notify>,
    pending: bool,
}
impl crate::compression::MemoryPromoter for CompactionPromotion {
    fn promote(
        &self,
        messages: &[Message],
    ) -> futures::future::BoxFuture<
        '_,
        crate::error::Result<crate::compression::MemoryPromotionReceipt>,
    > {
        let count = messages.len();
        Box::pin(async move {
            self.calls.fetch_add(1, Ordering::SeqCst);
            self.entered.notify_one();
            if self.pending {
                std::future::pending::<()>().await;
            }
            Ok(crate::compression::MemoryPromotionReceipt {
                submitted: count,
                promoted: count,
                deduplicated: 0,
            })
        })
    }
}

async fn seed_compaction_probe(
    agent: &ReactAgent,
    observations: Arc<AtomicUsize>,
) -> crate::error::Result<serde_json::Value> {
    let mut messages = agent.get_messages().await;
    messages.extend([
        Message::user("original user".to_string()),
        Message::assistant("old middle".to_string()),
        Message::assistant("retained final".to_string()),
    ]);
    {
        let mut context = agent.memory.context.lock().await;
        context.set_compressor(CompactionObserver(observations));
        context.set_messages(messages);
    }
    agent.force_checkpoint().await?;
    serde_json::to_value(agent.get_messages().await).map_err(Into::into)
}

#[tokio::test]
async fn managed_compaction_cancelled_promotion_restores_tuple_without_replay()
-> crate::error::Result<()> {
    let root = tempfile::tempdir()?;
    let agent = Arc::new(managed_compaction_agent(
        root.path(),
        "cancelled-compaction-promotion",
    )?);
    let observations = Arc::new(AtomicUsize::new(0));
    let original = seed_compaction_probe(&agent, observations.clone()).await?;
    let calls = Arc::new(AtomicUsize::new(0));
    let entered = Arc::new(tokio::sync::Notify::new());
    agent
        .memory
        .context
        .lock()
        .await
        .set_memory_promoter(Arc::new(CompactionPromotion {
            calls: calls.clone(),
            entered: entered.clone(),
            pending: true,
        }));
    let running = {
        let agent = agent.clone();
        tokio::spawn(async move { agent.force_compress_with(&CompactionRewrite).await })
    };
    tokio::time::timeout(std::time::Duration::from_secs(5), entered.notified())
        .await
        .map_err(|_| crate::error::ReactError::Other("promoter was not entered".to_string()))?;
    running.abort();
    assert!(running.await.is_err_and(|error| error.is_cancelled()));
    assert_eq!(serde_json::to_value(agent.get_messages().await)?, original);
    assert_eq!(
        agent
            .memory
            .context
            .lock()
            .await
            .compression_metrics()
            .total_compressions,
        0
    );
    assert_eq!(observations.load(Ordering::SeqCst), 1);
    assert!(agent.force_checkpoint().await.is_err());
    agent.resume_from_state_store().await?;
    agent.force_checkpoint().await?;
    assert_eq!(
        calls.load(Ordering::SeqCst),
        1,
        "recovery must not re-run promotion"
    );
    assert_eq!(serde_json::to_value(agent.get_messages().await)?, original);
    Ok(())
}

type CompactionProbeFuture<'a, T> = futures::future::BoxFuture<'a, crate::error::Result<T>>;

struct CompactionRuntimeProbe {
    inner: crate::state::FileRuntimeStateStore,
    agent: std::sync::Mutex<std::sync::Weak<ReactAgent>>,
    seen: std::sync::Mutex<Vec<serde_json::Value>>,
    target: AtomicBool,
    cancel_after_commit: bool,
    entered: tokio::sync::Notify,
}

impl crate::state::RuntimeStateStore for CompactionRuntimeProbe {
    fn runtime_state_capability(&self) -> crate::state::RuntimeStateCapability {
        crate::state::RuntimeStateCapability::RevisionedV1
    }
    fn persistence_call_capability(&self) -> crate::memory::PersistenceCallCapability {
        crate::memory::PersistenceCallCapability::AbsoluteDeadlineV1
    }
    fn compare_and_save_checkpoint_with_context<'a>(
        &'a self,
        context: crate::memory::PersistenceCallContext,
        request: crate::state::RuntimeCheckpointCasRequest,
    ) -> CompactionProbeFuture<'a, crate::state::RuntimeCheckpointCasReceipt> {
        Box::pin(async move {
            let payload = request.checkpoint.restore_managed_runtime_payload()?;
            let target = payload.pending_transcript_projection.is_none()
                && payload
                    .transcript_projection
                    .as_ref()
                    .and_then(|cursor| cursor.context_only.as_ref())
                    .is_some_and(|view| !view.is_empty())
                && self.target.swap(false, Ordering::SeqCst);
            if target {
                let agent = self
                    .agent
                    .lock()
                    .map_err(|error| crate::error::ReactError::Other(error.to_string()))?
                    .upgrade()
                    .ok_or_else(|| {
                        crate::error::ReactError::Other("callback agent missing".to_string())
                    })?;
                let messages =
                    tokio::time::timeout(std::time::Duration::from_secs(5), agent.get_messages())
                        .await
                        .map_err(|_| {
                            crate::error::ReactError::Other(
                                "read-only Store callback deadlocked".to_string(),
                            )
                        })?;
                self.seen
                    .lock()
                    .map_err(|error| crate::error::ReactError::Other(error.to_string()))?
                    .push(serde_json::to_value(messages)?);
            }
            let receipt =
                crate::state::RuntimeStateStore::compare_and_save_checkpoint_with_context(
                    &self.inner,
                    context,
                    request,
                )
                .await?;
            if target && self.cancel_after_commit {
                self.entered.notify_one();
                std::future::pending::<()>().await;
            }
            Ok(receipt)
        })
    }
    fn get_checkpoint<'a>(
        &'a self,
        id: &'a str,
    ) -> CompactionProbeFuture<'a, Option<crate::state::AgentCheckpoint>> {
        crate::state::RuntimeStateStore::get_checkpoint(&self.inner, id)
    }
    fn save_checkpoint<'a>(
        &'a self,
        checkpoint: &'a crate::state::AgentCheckpoint,
    ) -> CompactionProbeFuture<'a, ()> {
        crate::state::RuntimeStateStore::save_checkpoint(&self.inner, checkpoint)
    }
    fn save_checkpoint_for_scope<'a>(
        &'a self,
        scope: &'a str,
        checkpoint: &'a crate::state::AgentCheckpoint,
    ) -> CompactionProbeFuture<'a, ()> {
        crate::state::RuntimeStateStore::save_checkpoint_for_scope(&self.inner, scope, checkpoint)
    }
    fn runtime_state_ids<'a>(&'a self, scope: &'a str) -> CompactionProbeFuture<'a, Vec<String>> {
        crate::state::RuntimeStateStore::runtime_state_ids(&self.inner, scope)
    }
    fn clear_runtime_state<'a>(
        &'a self,
        scope: &'a str,
        id: &'a str,
    ) -> CompactionProbeFuture<'a, crate::state::RuntimeStateClearReceipt> {
        crate::state::RuntimeStateStore::clear_runtime_state(&self.inner, scope, id)
    }
    fn clear_runtime_state_scope<'a>(
        &'a self,
        scope: &'a str,
    ) -> CompactionProbeFuture<'a, crate::state::RuntimeStateScopeClearReceipt> {
        crate::state::RuntimeStateStore::clear_runtime_state_scope(&self.inner, scope)
    }
    fn clear_conversation<'a>(&'a self, id: &'a str) -> CompactionProbeFuture<'a, ()> {
        crate::state::RuntimeStateStore::clear_conversation(&self.inner, id)
    }
    fn load_runtime_state_with_context<'a>(
        &'a self,
        context: crate::memory::PersistenceCallContext,
        scope: &'a str,
        id: &'a str,
    ) -> CompactionProbeFuture<'a, Option<crate::state::ManagedRuntimeStateSnapshot>> {
        crate::state::RuntimeStateStore::load_runtime_state_with_context(
            &self.inner,
            context,
            scope,
            id,
        )
    }
    fn load_scope_authority_with_context<'a>(
        &'a self,
        context: crate::memory::PersistenceCallContext,
        scope: &'a str,
    ) -> CompactionProbeFuture<'a, Option<crate::state::RuntimeScopeAuthority>> {
        crate::state::RuntimeStateStore::load_scope_authority_with_context(
            &self.inner,
            context,
            scope,
        )
    }
    fn acknowledge_transcript_projection_with_context<'a>(
        &'a self,
        context: crate::memory::PersistenceCallContext,
        request: crate::state::RuntimeTranscriptAckRequest,
    ) -> CompactionProbeFuture<'a, crate::state::RuntimeCheckpointCasReceipt> {
        crate::state::RuntimeStateStore::acknowledge_transcript_projection_with_context(
            &self.inner,
            context,
            request,
        )
    }
}

#[tokio::test]
async fn managed_compaction_store_read_reentry_and_commit_response_cancellation()
-> crate::error::Result<()> {
    for cancel_after_commit in [false, true] {
        let root = tempfile::tempdir()?;
        let scope = "compaction-read-reentry";
        let runtime = Arc::new(CompactionRuntimeProbe {
            inner: crate::state::FileRuntimeStateStore::new(root.path().join("runtime"))?,
            agent: std::sync::Mutex::new(std::sync::Weak::new()),
            seen: std::sync::Mutex::new(Vec::new()),
            target: AtomicBool::new(true),
            cancel_after_commit,
            entered: tokio::sync::Notify::new(),
        });
        let mut agent = managed_compaction_agent(root.path(), scope)?;
        agent.set_state_store(runtime.clone());
        let agent = Arc::new(agent);
        *runtime
            .agent
            .lock()
            .map_err(|error| crate::error::ReactError::Other(error.to_string()))? =
            Arc::downgrade(&agent);
        let observations = Arc::new(AtomicUsize::new(0));
        let original = seed_compaction_probe(&agent, observations.clone()).await?;
        let transcript = managed_compaction_transcript(root.path(), scope).await?;
        let promotions = Arc::new(AtomicUsize::new(0));
        agent
            .memory
            .context
            .lock()
            .await
            .set_memory_promoter(Arc::new(CompactionPromotion {
                calls: promotions.clone(),
                entered: Arc::new(tokio::sync::Notify::new()),
                pending: false,
            }));
        if cancel_after_commit {
            let running = {
                let agent = agent.clone();
                tokio::spawn(async move { agent.force_compress_with(&CompactionRewrite).await })
            };
            tokio::time::timeout(
                std::time::Duration::from_secs(5),
                runtime.entered.notified(),
            )
            .await
            .map_err(|_| {
                crate::error::ReactError::Other(
                    "CAS did not reach commit-before-response cut".to_string(),
                )
            })?;
            assert_eq!(serde_json::to_value(agent.get_messages().await)?, original);
            running.abort();
            assert!(running.await.is_err_and(|error| error.is_cancelled()));
            assert_eq!(serde_json::to_value(agent.get_messages().await)?, original);
            assert_eq!(observations.load(Ordering::SeqCst), 1);
            assert!(agent.force_checkpoint().await.is_err());
            agent.resume_from_state_store().await?;
        } else {
            tokio::time::timeout(
                std::time::Duration::from_secs(5),
                agent.force_compress_with(&CompactionRewrite),
            )
            .await
            .map_err(|_| {
                crate::error::ReactError::Other("compaction read reentry timed out".to_string())
            })??;
        }
        assert_eq!(
            *runtime
                .seen
                .lock()
                .map_err(|error| crate::error::ReactError::Other(error.to_string()))?,
            vec![original]
        );
        assert!(
            serde_json::to_value(agent.get_messages().await)?
                .to_string()
                .contains("derived model-only view")
        );
        if !cancel_after_commit {
            assert_eq!(
                observations.load(Ordering::SeqCst),
                2,
                "the accepted transform publishes its observer exactly once"
            );
        }
        // Resume can notify its restored view and refresh the canonical root.
        // Those existing restoration notifications are not this cancelled
        // transform publishing a candidate; its zero-publication cut is above.
        agent.force_checkpoint().await?;
        assert_eq!(
            managed_compaction_transcript(root.path(), scope).await?,
            transcript
        );
        assert_eq!(
            promotions.load(Ordering::SeqCst),
            1,
            "Store recovery must not replay the promoter"
        );
    }
    Ok(())
}

#[tokio::test]
async fn conversation_store_without_runtime_state_is_rejected_before_run_side_effects()
-> crate::error::Result<()> {
    let temp = tempfile::tempdir()?;
    let store = Arc::new(crate::memory::FileConversationStore::new(temp.path())?);
    let config = AgentConfig::new("test-model", "agent", "system")
        .conversation_id("store-only-conversation");
    let mut agent = ReactAgent::new(config);
    agent.set_conversation_store(store.clone());
    let before = serde_json::to_value(agent.memory.context.lock().await.messages())?;

    let direct = agent.run_direct("must not run").await;
    assert!(matches!(direct, Err(crate::error::ReactError::Config(_))));
    assert_eq!(
        serde_json::to_value(agent.memory.context.lock().await.messages())?,
        before
    );
    assert!(
        crate::memory::ConversationStore::get_conversation(
            store.as_ref(),
            "store-only-conversation"
        )
        .await?
        .is_none()
    );

    let streaming = agent.execute_stream("must not stream").await;
    assert!(matches!(
        streaming,
        Err(crate::error::ReactError::Config(_))
    ));
    assert_eq!(
        serde_json::to_value(agent.memory.context.lock().await.messages())?,
        before
    );
    assert!(
        crate::memory::ConversationStore::get_conversation(
            store.as_ref(),
            "store-only-conversation"
        )
        .await?
        .is_none()
    );
    Ok(())
}

#[tokio::test]
async fn revisioned_runtime_without_deadline_capability_is_rejected_before_side_effects()
-> crate::error::Result<()> {
    struct RevisionedWithoutDeadline;

    impl crate::state::RuntimeStateStore for RevisionedWithoutDeadline {
        fn runtime_state_capability(&self) -> crate::state::RuntimeStateCapability {
            crate::state::RuntimeStateCapability::RevisionedV1
        }

        fn get_checkpoint<'a>(
            &'a self,
            _conversation_id: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<Option<crate::state::AgentCheckpoint>>,
        > {
            Box::pin(async { Ok(None) })
        }

        fn save_checkpoint<'a>(
            &'a self,
            _checkpoint: &'a crate::state::AgentCheckpoint,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<()>> {
            Box::pin(async { Ok(()) })
        }

        fn save_checkpoint_for_scope<'a>(
            &'a self,
            _scope_id: &'a str,
            _checkpoint: &'a crate::state::AgentCheckpoint,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<()>> {
            Box::pin(async { Ok(()) })
        }

        fn runtime_state_ids<'a>(
            &'a self,
            _scope_id: &'a str,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<Vec<String>>> {
            Box::pin(async { Ok(Vec::new()) })
        }

        fn clear_runtime_state<'a>(
            &'a self,
            scope_id: &'a str,
            runtime_state_id: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<crate::state::RuntimeStateClearReceipt>,
        > {
            Box::pin(async move {
                Ok(crate::state::RuntimeStateClearReceipt {
                    scope_id: scope_id.to_string(),
                    runtime_state_id: runtime_state_id.to_string(),
                    checkpoint_removed: false,
                })
            })
        }

        fn clear_runtime_state_scope<'a>(
            &'a self,
            scope_id: &'a str,
        ) -> futures::future::BoxFuture<
            'a,
            crate::error::Result<crate::state::RuntimeStateScopeClearReceipt>,
        > {
            Box::pin(async move {
                Ok(crate::state::RuntimeStateScopeClearReceipt {
                    scope_id: scope_id.to_string(),
                    runtime_state_ids: Vec::new(),
                })
            })
        }

        fn clear_conversation<'a>(
            &'a self,
            _conversation_id: &'a str,
        ) -> futures::future::BoxFuture<'a, crate::error::Result<()>> {
            Box::pin(async { Ok(()) })
        }
    }

    let root = tempfile::tempdir()?;
    let conversations = Arc::new(crate::memory::FileConversationStore::new(root.path())?);
    let config =
        AgentConfig::new("test-model", "agent", "system").conversation_id("deadline-capability");
    let mut agent = ReactAgent::new(config);
    agent.set_conversation_store(conversations.clone());
    agent.set_state_store(Arc::new(RevisionedWithoutDeadline));
    let before = serde_json::to_value(agent.memory.context.lock().await.messages())?;

    let result = agent.run_direct("must not run").await;
    assert!(matches!(result, Err(crate::error::ReactError::Config(_))));
    assert_eq!(
        serde_json::to_value(agent.memory.context.lock().await.messages())?,
        before
    );
    assert!(
        crate::memory::ConversationStore::get_conversation(
            conversations.as_ref(),
            "deadline-capability"
        )
        .await?
        .is_none()
    );
    Ok(())
}

#[tokio::test]
async fn managed_force_checkpoint_settles_transcript_before_returning() -> crate::error::Result<()>
{
    let conversation_root = tempfile::tempdir()?;
    let runtime_root = tempfile::tempdir()?;
    let conversations = Arc::new(crate::memory::FileConversationStore::new(
        conversation_root.path(),
    )?);
    let runtime = Arc::new(crate::state::FileRuntimeStateStore::new(
        runtime_root.path(),
    )?);
    let config = AgentConfig::new("test-model", "agent", "system")
        .conversation_id("managed-force-checkpoint");
    let mut agent = ReactAgent::new(config);
    agent.set_conversation_store(conversations.clone());
    agent.set_state_store(runtime.clone());
    let mut legacy = crate::state::AgentCheckpoint::new("managed-force-checkpoint");
    legacy.messages_json = crate::state::AgentCheckpoint::serialize_payload(
        vec![Message::system("system".to_string())],
        None,
    )?;
    crate::state::RuntimeStateStore::save_checkpoint(runtime.as_ref(), &legacy).await?;
    assert!(agent.resume_from_state_store().await?.is_some());
    agent
        .memory
        .context
        .lock()
        .await
        .push(Message::user("persist both authorities".to_string()));

    agent.force_checkpoint().await?;

    let messages = crate::memory::ConversationStore::get_messages(
        conversations.as_ref(),
        "managed-force-checkpoint",
    )
    .await?;
    assert!(
        messages
            .iter()
            .any(|message| message.content.as_deref() == Some("persist both authorities"))
    );
    let state = crate::state::RuntimeStateStore::load_runtime_state(
        runtime.as_ref(),
        "managed-force-checkpoint",
        "managed-force-checkpoint",
    )
    .await?
    .ok_or_else(|| {
        crate::error::ReactError::Other("managed runtime checkpoint missing".to_string())
    })?;
    let payload = state
        .checkpoint
        .as_ref()
        .ok_or_else(|| crate::error::ReactError::Other("checkpoint payload missing".to_string()))?
        .restore_managed_runtime_payload()?;
    assert!(payload.pending_transcript_projection.is_none());
    assert!(
        payload
            .transcript_projection
            .is_some_and(|cursor| cursor.next_ordinal > 0)
    );
    Ok(())
}

/// Third-party stores remain source-compatible but cannot claim atomic support.
#[tokio::test]
async fn legacy_conversation_store_defaults_to_unsupported_projection() {
    use crate::memory::{
        Conversation, ConversationFilter, ConversationMeta, ConversationStore, NewConversation,
        StoredMessage,
    };
    use echo_core::error::Result as CoreResult;
    use futures::future::BoxFuture;
    use std::sync::Mutex as StdMutex;

    /// Minimal in-memory ConversationStore that records every save_messages call.
    struct RecordingStore {
        saves: StdMutex<Vec<(String, Vec<StoredMessage>)>>,
        conversations: StdMutex<Vec<Conversation>>,
        persisted: StdMutex<Vec<StoredMessage>>,
    }

    impl RecordingStore {
        fn new() -> Self {
            Self {
                saves: StdMutex::new(Vec::new()),
                conversations: StdMutex::new(Vec::new()),
                persisted: StdMutex::new(Vec::new()),
            }
        }
    }

    impl ConversationStore for RecordingStore {
        fn create_conversation<'a>(
            &'a self,
            conv: NewConversation,
        ) -> BoxFuture<'a, CoreResult<Conversation>> {
            Box::pin(async move {
                let c = Conversation {
                    id: 1,
                    conversation_id: conv.conversation_id,
                    user_id: conv.user_id,
                    agent_type: conv.agent_type,
                    title: conv.title,
                    summary: None,
                    compressed_before_id: None,
                    created_at: "now".to_string(),
                    updated_at: "now".to_string(),
                };
                self.conversations.lock().unwrap().push(c.clone());
                Ok(c)
            })
        }

        fn get_conversation<'a>(
            &'a self,
            conversation_id: &'a str,
        ) -> BoxFuture<'a, CoreResult<Option<Conversation>>> {
            Box::pin(async move {
                Ok(self
                    .conversations
                    .lock()
                    .unwrap()
                    .iter()
                    .find(|c| c.conversation_id == conversation_id)
                    .cloned())
            })
        }

        fn list_conversations<'a>(
            &'a self,
            _filter: ConversationFilter,
        ) -> BoxFuture<'a, CoreResult<Vec<ConversationMeta>>> {
            Box::pin(async move { Ok(Vec::new()) })
        }

        fn update_conversation<'a>(
            &'a self,
            _conversation_id: &'a str,
            _title: Option<&'a str>,
            _summary: Option<&'a str>,
            _compressed_before_id: Option<i64>,
        ) -> BoxFuture<'a, CoreResult<()>> {
            Box::pin(async move { Ok(()) })
        }

        fn delete_conversation<'a>(
            &'a self,
            _conversation_id: &'a str,
        ) -> BoxFuture<'a, CoreResult<()>> {
            Box::pin(async move { Ok(()) })
        }

        fn save_messages<'a>(
            &'a self,
            conversation_id: &'a str,
            messages: &'a [StoredMessage],
        ) -> BoxFuture<'a, CoreResult<()>> {
            let key = conversation_id.to_string();
            let msgs = messages.to_vec();
            Box::pin(async move {
                self.saves
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push((key, msgs.clone()));
                *self
                    .persisted
                    .lock()
                    .unwrap_or_else(|error| error.into_inner()) = msgs;
                Ok(())
            })
        }

        fn get_messages<'a>(
            &'a self,
            conversation_id: &'a str,
        ) -> BoxFuture<'a, CoreResult<Vec<StoredMessage>>> {
            Box::pin(async move {
                let is_known = self
                    .conversations
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .iter()
                    .any(|conversation| conversation.conversation_id == conversation_id);
                if is_known {
                    Ok(self
                        .persisted
                        .lock()
                        .unwrap_or_else(|error| error.into_inner())
                        .clone())
                } else {
                    Ok(Vec::new())
                }
            })
        }

        fn count_messages<'a>(
            &'a self,
            _conversation_id: &'a str,
        ) -> BoxFuture<'a, CoreResult<usize>> {
            Box::pin(async move { Ok(0) })
        }
    }

    let store = Arc::new(RecordingStore::new());
    assert_eq!(
        store.projection_capability(),
        crate::memory::ConversationProjectionCapability::Unsupported
    );
}

#[test]
fn anonymous_invocation_guards_survive_source_value_and_release_with_last_snapshot() {
    let agent = ReactAgent::new(AgentConfig::new("test-model", "agent", "system"));
    let resource = Arc::new("anonymous-lease".to_string());
    let weak = Arc::downgrade(&resource);
    let invocation = echo_core::agent::AgentInvocationContext {
        runtime: Some(external_context_with_guards(vec![
            echo_core::tools::InvocationResourceGuard::new(resource),
        ])),
        ..Default::default()
    };
    let snapshot = crate::agent::AgentRunSnapshot::from_agent_with_invocation(&agent, &invocation);
    drop(invocation);
    assert!(snapshot.current_run_id.is_none());
    assert!(snapshot.current_turn_id.is_none());
    assert_eq!(snapshot.resource_guards.len(), 1);
    assert!(weak.upgrade().is_some());
    let second = snapshot.clone();
    drop(snapshot);
    assert!(weak.upgrade().is_some());
    drop(second);
    assert!(weak.upgrade().is_none());
}

#[test]
fn invocation_conversation_override_and_plain_config_fallback_do_not_publish_run_ids() {
    let agent = ReactAgent::new(
        AgentConfig::new("test-model", "agent", "system").conversation_id("configured"),
    );
    for conversation in [None, Some("explicit".to_string())] {
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: conversation.clone(),
                ..Default::default()
            }),
            ..Default::default()
        };
        let snapshot =
            crate::agent::AgentRunSnapshot::from_agent_with_invocation(&agent, &invocation);
        assert_eq!(
            snapshot.config.conversation_id.as_deref(),
            conversation.as_deref().or(Some("configured"))
        );
        assert!(snapshot.current_run_id.is_none());
        assert!(snapshot.trace_run_id.is_none());
    }
    let plain = crate::agent::AgentRunSnapshot::from_agent(&agent);
    assert_eq!(plain.config.conversation_id.as_deref(), Some("configured"));
    assert!(plain.current_run_id.is_none());
    assert!(agent.current_run_id().is_none());
}

#[test]
fn invocation_preserves_cancel_and_trace_only_without_shared_context() {
    let agent = ReactAgent::new(AgentConfig::new("test-model", "agent", "system"));
    let cancel = Arc::new(crate::agent::CancellationToken::new());
    let trace: echo_core::tools::TraceSinkFn = Arc::new(|_| {});
    let invocation = echo_core::agent::AgentInvocationContext {
        runtime: Some(echo_core::tools::ExternalRunContext {
            cancel: Some(Arc::clone(&cancel)),
            trace_sink: Some(Arc::clone(&trace)),
            ..Default::default()
        }),
        ..Default::default()
    };
    let snapshot = crate::agent::AgentRunSnapshot::from_agent_with_invocation(&agent, &invocation);
    assert!(
        snapshot
            .external_cancel
            .as_ref()
            .is_some_and(|value| Arc::ptr_eq(value, &cancel))
    );
    assert!(
        snapshot
            .external_trace_sink
            .as_ref()
            .is_some_and(|value| Arc::ptr_eq(value, &trace))
    );
    assert!(snapshot.current_run_id.is_none());
    cancel.cancel();
    assert!(
        snapshot
            .cancel_token
            .as_ref()
            .is_some_and(|value| value.is_cancelled())
    );
    assert!(
        crate::agent::AgentRunSnapshot::from_agent(&agent)
            .external_trace_sink
            .is_none()
    );
}

#[test]
fn invocation_guard_drop_can_reenter_current_agent_observation() {
    let agent = Arc::new(ReactAgent::new(AgentConfig::new(
        "test-model",
        "agent",
        "system",
    )));
    let observed_unlocked = Arc::new(AtomicBool::new(false));
    let invocation = echo_core::agent::AgentInvocationContext {
        resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
            ReentrantGuardProbe {
                agent: Arc::downgrade(&agent),
                observed_unlocked: observed_unlocked.clone(),
            },
        )],
        ..Default::default()
    };
    let snapshot = crate::agent::AgentRunSnapshot::from_agent_with_invocation(&agent, &invocation);
    drop(invocation);
    assert!(!observed_unlocked.load(Ordering::SeqCst));
    drop(snapshot);
    assert!(observed_unlocked.load(Ordering::SeqCst));
}

#[tokio::test]
async fn slow_invocation_guard_drop_does_not_block_other_snapshot_or_run_observation()
-> Result<(), String> {
    let agent = Arc::new(ReactAgent::new(AgentConfig::new(
        "test-model",
        "agent",
        "system",
    )));
    let (entered_tx, entered_rx) = std::sync::mpsc::channel();
    let (release_tx, release_rx) = std::sync::mpsc::channel();
    let invocation = echo_core::agent::AgentInvocationContext {
        resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
            SlowGuardDrop {
                entered: entered_tx,
                release: std::sync::Mutex::new(release_rx),
            },
        )],
        ..Default::default()
    };
    let snapshot = crate::agent::AgentRunSnapshot::from_agent_with_invocation(&agent, &invocation);
    drop(invocation);
    let dropping = tokio::task::spawn_blocking(move || drop(snapshot));
    tokio::task::spawn_blocking(move || {
        entered_rx
            .recv_timeout(std::time::Duration::from_secs(2))
            .map_err(|error| error.to_string())
    })
    .await
    .map_err(|error| error.to_string())??;
    let concurrent = {
        let agent = agent.clone();
        tokio::task::spawn_blocking(move || {
            let fresh = crate::agent::AgentRunSnapshot::from_agent(&agent);
            assert!(fresh.resource_guards.is_empty());
            assert!(agent.current_run_id().is_none());
        })
    };
    let result = tokio::time::timeout(std::time::Duration::from_secs(1), concurrent).await;
    let _ = release_tx.send(());
    dropping.await.map_err(|error| error.to_string())?;
    result
        .map_err(|_| "current snapshot waited on another invocation destructor".to_string())?
        .map_err(|error| error.to_string())?;
    Ok(())
}

#[tokio::test]
async fn activate_skill_of_unknown_skill_returns_error() -> Result<(), String> {
    let agent = ReactAgent::new(AgentConfig::new("test-model", "agent", "system"));
    let err = agent
        .activate_skill("no-such-skill")
        .await
        .err()
        .ok_or_else(|| "unknown skill returned silent success".to_string())?;
    assert!(
        err.to_string().contains("not installed"),
        "unexpected error message: {err}"
    );
    Ok(())
}

#[cfg(feature = "subagent")]
#[derive(Clone, Copy, Debug)]
enum DelegatePolicyEntry {
    Text,
    TextAttempt,
    Message,
    MessageAttempt,
}

#[cfg(feature = "subagent")]
type DelegatePolicyObservation = (String, Option<echo_core::tools::NestedDelegationPolicy>);

#[cfg(feature = "subagent")]
struct DelegatePolicyProbe {
    actor: String,
    observations: Arc<std::sync::Mutex<Vec<DelegatePolicyObservation>>>,
}

#[cfg(feature = "subagent")]
impl crate::tools::Tool for DelegatePolicyProbe {
    fn name(&self) -> &str {
        "delegate_policy_probe"
    }
    fn description(&self) -> &str {
        "观察真实子智能体工具调用的目标策略"
    }
    fn parameters(&self) -> serde_json::Value {
        json!({"type":"object","properties":{}})
    }
    fn execute(
        &self,
        _parameters: crate::tools::ToolParameters,
    ) -> futures::future::BoxFuture<'_, crate::error::Result<crate::tools::ToolResult>> {
        Box::pin(async { Ok(crate::tools::ToolResult::success("已观察")) })
    }
    fn execute_with_context<'a>(
        &'a self,
        parameters: crate::tools::ToolParameters,
        context: &'a crate::tools::ToolContext,
    ) -> futures::future::BoxFuture<'a, crate::error::Result<crate::tools::ToolResult>> {
        Box::pin(async move {
            self.observations
                .lock()
                .map_err(|error| crate::error::ReactError::Other(error.to_string()))?
                .push((self.actor.clone(), context.delegation_policy));
            self.execute(parameters).await
        })
    }
}

#[cfg(feature = "subagent")]
async fn probe_delegate_policy_entry(
    entry: DelegatePolicyEntry,
    policy: Option<echo_core::tools::NestedDelegationPolicy>,
    depth: u32,
    expected_maximum: Option<u8>,
) -> crate::error::Result<()> {
    use crate::agent::subagent::{SubagentAttemptIdentity, SubagentEvent};
    use crate::testing::MockLlmClient;

    let registry = Arc::new(SubagentRegistry::new());
    let observations = Arc::new(std::sync::Mutex::new(Vec::new()));
    let mut events = registry.event_bus().subscribe();
    let mut clients = Vec::new();
    // 多注册一层真实 Agent；越界调用不能因目标不存在而侥幸被拒。
    for actor_depth in 1_u8..=5 {
        let name = format!("policy-actor-{actor_depth}");
        let client = Arc::new(
            MockLlmClient::new()
                .then_tool_call("probe", "delegate_policy_probe", "{}")
                .then_tool_call("search", "tool_search", r#"{"query":"agent_tool"}"#)
                .then_tool_call(
                    "delegate",
                    "agent_tool",
                    json!({
                        "agent_name": format!("policy-actor-{}", actor_depth.saturating_add(1)),
                        "task": "继续下一层真实调用",
                        "mode": "fork"
                    })
                    .to_string(),
                )
                .with_response("## Summary\n完成真实策略探针"),
        );
        let agent = ReactAgentBuilder::new()
            .name(&name)
            .model("mock-model")
            .enable_tools()
            .enable_subagent()
            .register_agent_dispatch_tool()
            .subagent_registry(registry.clone())
            .llm_client(client.clone())
            .tool(Box::new(DelegatePolicyProbe {
                actor: name.clone(),
                observations: observations.clone(),
            }))
            .build()?;
        registry
            .register(
                SubagentBuilder::new(&name)
                    .fork_mode()
                    .can_delegate()
                    .build(),
                Box::new(agent),
            )
            .await;
        clients.push((actor_depth, client));
    }
    let primary = ReactAgentBuilder::new()
        .name("primary")
        .model("mock-model")
        .enable_tools()
        .enable_subagent()
        .subagent_registry(registry)
        .build()?;
    let runtime = policy.map(|policy| echo_core::tools::ExternalRunContext {
        delegation_policy: Some(policy),
        ..Default::default()
    });
    let identity = SubagentAttemptIdentity::new("policy-task", "policy-execution", 1)
        .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;
    let result = match entry {
        DelegatePolicyEntry::Text => {
            primary
                .delegate_to_agent_with_prompt_payload(
                    "policy-actor-1",
                    "首层任务",
                    "primary",
                    super::CancellationToken::new(),
                    depth,
                    runtime,
                    None,
                    None,
                    None,
                )
                .await
        }
        DelegatePolicyEntry::TextAttempt => {
            primary
                .delegate_to_agent_attempt_with_prompt_payload(
                    "policy-actor-1",
                    "首层任务",
                    "primary",
                    super::CancellationToken::new(),
                    depth,
                    runtime,
                    None,
                    None,
                    None,
                    identity,
                )
                .await
        }
        DelegatePolicyEntry::Message => {
            primary
                .delegate_to_agent_with_message_and_prompt_payload(
                    "policy-actor-1",
                    "首层任务",
                    Message::user("带消息的首层任务".into()),
                    "primary",
                    super::CancellationToken::new(),
                    depth,
                    runtime,
                    None,
                    None,
                    None,
                )
                .await
        }
        DelegatePolicyEntry::MessageAttempt => {
            primary
                .delegate_to_agent_attempt_with_message_and_prompt_payload(
                    "policy-actor-1",
                    "首层任务",
                    Message::user("带消息的首层任务".into()),
                    "primary",
                    super::CancellationToken::new(),
                    depth,
                    runtime,
                    None,
                    None,
                    None,
                    identity,
                )
                .await
        }
    };
    let observed = observations
        .lock()
        .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;
    if let Some(maximum) = expected_maximum {
        result?;
        let last_depth = if policy.is_some_and(|value| !value.can_spawn_subagents) {
            1
        } else {
            maximum
        };
        for (actor_depth, client) in clients {
            assert_eq!(
                client.call_count() > 0,
                actor_depth <= last_depth,
                "{entry:?}/{maximum}/{actor_depth}"
            );
        }
        assert_eq!(observed.len(), usize::from(last_depth));
        for actor_depth in 1..=last_depth {
            let name = format!("policy-actor-{actor_depth}");
            let actual = observed
                .iter()
                .find(|(actor, _)| actor == &name)
                .ok_or_else(|| crate::error::ReactError::Other(format!("缺少真实调用 {name}")))?;
            assert_eq!(
                actual.1,
                Some(echo_core::tools::NestedDelegationPolicy {
                    can_spawn_subagents: policy.is_none_or(|value| value.can_spawn_subagents),
                    delegate_depth: actor_depth,
                    max_delegate_depth: maximum,
                })
            );
        }
        let mut starts = Vec::new();
        while let Ok(event) = events.try_recv() {
            if let SubagentEvent::DispatchStarted { agent, mode, .. } = event.as_ref() {
                assert_eq!(*mode, crate::agent::subagent::ExecutionMode::Fork);
                starts.push(agent.clone());
            }
        }
        assert_eq!(starts.len(), usize::from(last_depth));
    } else {
        assert!(result.is_err(), "冲突或越界目标必须拒绝");
        assert!(observed.is_empty());
        assert!(clients.iter().all(|(_, client)| client.call_count() == 0));
        let conflicting_depth =
            policy.is_some_and(|value| u32::from(value.delegate_depth) != depth);
        let mut starts = 0_usize;
        let mut failed = 0_usize;
        while let Ok(event) = events.try_recv() {
            match event.as_ref() {
                SubagentEvent::DispatchStarted { .. } => starts = starts.saturating_add(1),
                SubagentEvent::DispatchFailed {
                    status, outcome, ..
                } => {
                    assert_eq!(*status, crate::agent::subagent::SubagentStatus::Failed);
                    assert_eq!(outcome.status, *status);
                    failed = failed.saturating_add(1);
                }
                _ => {}
            }
        }
        // 冲突必须在 helper 内拒绝；已匹配但越界的目标仍保原
        // dispatcher Started→Failed 顺序，Started 不等于模型已经执行。
        assert_eq!(starts, usize::from(!conflicting_depth));
        assert_eq!(failed, usize::from(!conflicting_depth));
    }
    Ok(())
}

#[cfg(feature = "subagent")]
#[tokio::test]
async fn delegate_helpers_keep_bound_target_policy_in_fork() -> crate::error::Result<()> {
    for entry in [
        DelegatePolicyEntry::Text,
        DelegatePolicyEntry::TextAttempt,
        DelegatePolicyEntry::Message,
        DelegatePolicyEntry::MessageAttempt,
    ] {
        for maximum in [1, 2, 3, 4] {
            probe_delegate_policy_entry(
                entry,
                Some(echo_core::tools::NestedDelegationPolicy {
                    can_spawn_subagents: true,
                    delegate_depth: 1,
                    max_delegate_depth: maximum,
                }),
                1,
                Some(maximum),
            )
            .await?;
        }
        probe_delegate_policy_entry(
            entry,
            Some(echo_core::tools::NestedDelegationPolicy {
                can_spawn_subagents: false,
                delegate_depth: 1,
                max_delegate_depth: 3,
            }),
            1,
            Some(3),
        )
        .await?;
    }
    Ok(())
}

#[cfg(feature = "subagent")]
#[tokio::test]
async fn delegate_helpers_keep_plain_default_without_runtime_policy() -> crate::error::Result<()> {
    for entry in [
        DelegatePolicyEntry::Text,
        DelegatePolicyEntry::TextAttempt,
        DelegatePolicyEntry::Message,
        DelegatePolicyEntry::MessageAttempt,
    ] {
        probe_delegate_policy_entry(entry, None, 1, Some(3)).await?;
    }
    Ok(())
}

#[cfg(feature = "subagent")]
#[tokio::test]
async fn delegate_helpers_reject_conflicting_target_depth_before_dispatch()
-> crate::error::Result<()> {
    for entry in [
        DelegatePolicyEntry::Text,
        DelegatePolicyEntry::TextAttempt,
        DelegatePolicyEntry::Message,
        DelegatePolicyEntry::MessageAttempt,
    ] {
        probe_delegate_policy_entry(
            entry,
            Some(echo_core::tools::NestedDelegationPolicy {
                can_spawn_subagents: true,
                delegate_depth: 1,
                max_delegate_depth: 3,
            }),
            0,
            None,
        )
        .await?;
    }
    Ok(())
}

#[cfg(feature = "subagent")]
#[tokio::test]
async fn delegate_helpers_reject_target_already_beyond_bound() -> crate::error::Result<()> {
    for entry in [
        DelegatePolicyEntry::Text,
        DelegatePolicyEntry::TextAttempt,
        DelegatePolicyEntry::Message,
        DelegatePolicyEntry::MessageAttempt,
    ] {
        probe_delegate_policy_entry(
            entry,
            Some(echo_core::tools::NestedDelegationPolicy {
                can_spawn_subagents: true,
                delegate_depth: 2,
                max_delegate_depth: 1,
            }),
            2,
            None,
        )
        .await?;
    }
    Ok(())
}
