//! Channel-based streaming execution — returns `BoxStream<'static>`.
//!
//! Uses a tokio::mpsc channel + spawned task instead of `try_stream!`.
//! All streaming execution goes through this module.
//!
//! The body of [`AgentRunSnapshot::run_core_loop`] is a thin driver that
//! sequences the phase functions in [`super::phases`]: the loop itself stays
//! here so there is one — and only one — place to read the unified ReAct
//! control flow. Each phase is responsible for a focused subset of work
//! (audit, compaction, LLM call, tool execution, verification, finalization)
//!
//! **Converged with the non-streaming path:** `run_stream_channel` runs the
//! same pre-flight checks as `prepare_react_context` — `GuardDirection::Input`
//! and `IntentRouter` classification (including skill activation). A blocked
//! guard yields a terminal stream without entering `run_core_loop`.

use super::super::ReactAgent;
use super::phases::{self, IterOutcome, LoopState, PrepareOutcome};
use super::types::{StreamInit, StreamMode};
use crate::agent::AgentEvent;
use crate::error::Result;
use crate::llm::types::{ContentPart, Message, MessageContent};
use futures::{Stream, StreamExt};
use std::future::Future;
use std::ops::ControlFlow;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};
use tokio::sync::mpsc;
use tracing::debug;

async fn finish_pre_spawn_terminal(
    snapshot: &crate::agent::snapshot::AgentRunSnapshot,
    context: &Arc<tokio::sync::Mutex<crate::compression::ContextManager>>,
    reason: String,
    business_terminal: AgentEvent,
) -> (crate::agent::AgentSteerTurnOutcome, Vec<Result<AgentEvent>>) {
    let mut events = vec![Ok(phases::finalize::execution_status_event(
        snapshot,
        echo_core::agent::ExecutionStatusKind::Started,
        echo_core::agent::AgentPhase::Thinking,
        None,
        0,
        None,
    ))];
    match snapshot
        .save_transcript_projection(context, Some(reason.clone()))
        .await
    {
        Ok(settlement) => {
            if snapshot.conversation_store.is_some() {
                events.push(Ok(AgentEvent::TranscriptProjectionSettlement(
                    settlement.clone(),
                )));
            }
            if matches!(
                settlement.status,
                crate::memory::TranscriptProjectionSettlementStatus::Blocked
                    | crate::memory::TranscriptProjectionSettlementStatus::Conflict
            ) {
                let error =
                    crate::agent::snapshot::transcript_settlement_admission_error(&settlement);
                snapshot
                    .finalize_run(
                        crate::trace::RunStatus::Failed,
                        None,
                        Some(&error.to_string()),
                    )
                    .await;
                events.push(AgentEvent::from_error("react_loop", &error));
            } else {
                snapshot
                    .finalize_run(crate::trace::RunStatus::Failed, None, Some(&reason))
                    .await;
                events.push(Ok(business_terminal));
            }
        }
        Err(error) => {
            if snapshot.conversation_store.is_some() {
                let settlement = snapshot.observe_persistence_failure(&error).await;
                events.push(Ok(AgentEvent::TranscriptProjectionSettlement(settlement)));
            }
            if !matches!(error, crate::error::ReactError::ExecutionNotSettled { .. }) {
                snapshot
                    .finalize_run(
                        crate::trace::RunStatus::Failed,
                        None,
                        Some(&error.to_string()),
                    )
                    .await;
            }
            events.push(AgentEvent::from_error("react_loop", &error));
        }
    }
    if !events.iter().any(|event| {
        matches!(
            event,
            Err(crate::error::ReactError::ExecutionNotSettled { .. })
        )
    }) {
        events.push(Ok(phases::finalize::execution_status_event(
            snapshot,
            echo_core::agent::ExecutionStatusKind::Failed,
            echo_core::agent::AgentPhase::Terminal,
            None,
            1,
            Some(reason),
        )));
    }
    (crate::agent::AgentSteerTurnOutcome::Failed, events)
}

pub(in crate::agent::react) struct ReactStreamTurnOwner {
    lease: Option<crate::agent::react::lifecycle::ReactAgentTurnLease>,
    steering: Option<crate::agent::steer::ActiveTurnLease>,
    execution: Option<tokio::sync::OwnedMutexGuard<()>>,
    // Snapshot merges invocation and runtime guards; retain that original
    // bundle with the same physical owner if settlement remains unknown.
    resource_guards: Vec<echo_core::tools::InvocationResourceGuard>,
    run_id: Option<String>,
    execution_id: Option<String>,
}

impl ReactStreamTurnOwner {
    fn unknown_identity(events: &[Result<AgentEvent>]) -> Option<(String, Option<String>)> {
        events.iter().find_map(|event| match event {
            Err(crate::error::ReactError::ExecutionNotSettled {
                run_id,
                execution_id,
            }) => Some((run_id.clone(), execution_id.clone())),
            _ => None,
        })
    }

    pub(in crate::agent::react) fn settle(&mut self, outcome: crate::agent::AgentSteerTurnOutcome) {
        if let Some(steering) = self.steering.take() {
            steering.settle(outcome);
        }
        if let Some(lease) = self.lease.take() {
            lease.settle();
        }
        self.execution.take();
        self.resource_guards.clear();
    }

    pub(in crate::agent::react) fn preparation(
        snapshot: &crate::agent::snapshot::AgentRunSnapshot,
        lease: crate::agent::react::lifecycle::ReactAgentTurnLease,
        execution: tokio::sync::OwnedMutexGuard<()>,
    ) -> Self {
        Self {
            lease: Some(lease),
            steering: None,
            execution: Some(execution),
            resource_guards: snapshot.resource_guards.clone(),
            run_id: snapshot.current_run_id.clone(),
            execution_id: snapshot.current_execution_id.clone(),
        }
    }

    pub(in crate::agent::react) fn observe_preparation_result<T>(&mut self, result: &Result<T>) {
        if let Err(crate::error::ReactError::ExecutionNotSettled {
            run_id,
            execution_id,
        }) = result
        {
            self.run_id = Some(run_id.clone());
            self.execution_id = execution_id.clone();
            self.retain_unknown();
        } else {
            self.settle(crate::agent::AgentSteerTurnOutcome::Failed);
        }
    }

    fn retain_unknown(&mut self) {
        let mut steering = self.steering.take();
        if let Some(active) = steering.as_mut() {
            active.retain_unknown();
        }
        if let Some(lease) = self.lease.take() {
            let resources = Box::new((
                steering,
                self.execution.take(),
                std::mem::take(&mut self.resource_guards),
            ));
            if let Some(run_id) = self.run_id.as_ref() {
                lease.retain_unknown(run_id.clone(), self.execution_id.clone(), resources);
            } else {
                lease.retain_unidentified(resources);
            }
        }
    }
}

impl Drop for ReactStreamTurnOwner {
    fn drop(&mut self) {
        self.retain_unknown();
    }
}

struct ManagedAgentEventStream {
    receiver: tokio_stream::wrappers::ReceiverStream<Result<AgentEvent>>,
    cancel: crate::agent::CancellationToken,
    task: Option<tokio::task::JoinHandle<()>>,
    runtime: tokio::runtime::Handle,
    pending_terminal: Option<Result<AgentEvent>>,
    // 同一producer的成功发布包在物理结算前不可逃逸；尾部失败丢弃该包。
    pending_publication: std::collections::VecDeque<Result<AgentEvent>>,
    status_sequence: u64,
    terminal_status: Option<echo_core::agent::ExecutionStatus>,
    publication_ready: bool,
    receiver_closed: bool,
    observation_run_id: String,
    observation_execution_id: Option<String>,
}

impl ManagedAgentEventStream {
    fn poll_producer(&mut self, cx: &mut Context<'_>) -> Poll<Result<()>> {
        let Some(task) = self.task.as_mut() else {
            return Poll::Ready(Ok(()));
        };
        match Pin::new(task).poll(cx) {
            Poll::Pending => Poll::Pending,
            Poll::Ready(Ok(())) => {
                self.task.take();
                Poll::Ready(Ok(()))
            }
            Poll::Ready(Err(error)) => {
                self.task.take();
                tracing::error!(error=%error, panic=error.is_panic(), cancelled=error.is_cancelled(), "managed producer lost without physical receipt");
                Poll::Ready(Err(crate::error::ReactError::ExecutionNotSettled {
                    run_id: self.observation_run_id.clone(),
                    execution_id: self.observation_execution_id.clone(),
                }))
            }
        }
    }
}

impl ManagedAgentEventStream {
    fn sequenced(&mut self, mut item: Result<AgentEvent>) -> Result<AgentEvent> {
        if let Ok(AgentEvent::ExecutionStatus(status)) = &mut item {
            status.sequence = status.sequence.max(self.status_sequence);
            self.status_sequence = status.sequence.saturating_add(1);
        }
        item
    }

    fn prepare_publication(&mut self) {
        self.publication_ready = true;
        let Some(terminal) = self.pending_terminal.take() else {
            self.pending_publication.clear();
            return;
        };
        if matches!(
            &terminal,
            Err(crate::error::ReactError::ExecutionNotSettled { .. })
        ) {
            self.pending_publication.clear();
            self.terminal_status.take();
            self.pending_publication.push_back(terminal);
            return;
        }
        let (status, reason) = match &terminal {
            Ok(AgentEvent::FinalAnswer(_)) => {
                (echo_core::agent::ExecutionStatusKind::Settled, None)
            }
            Ok(AgentEvent::Cancelled) => (
                echo_core::agent::ExecutionStatusKind::Cancelled,
                Some("execution cancelled".to_string()),
            ),
            Ok(AgentEvent::Error {
                message, failure, ..
            }) => (
                if failure.terminal_kind == crate::error::AgentTerminalKind::Cancelled {
                    echo_core::agent::ExecutionStatusKind::Cancelled
                } else {
                    echo_core::agent::ExecutionStatusKind::Failed
                },
                Some(message.clone()),
            ),
            Err(error) => (
                echo_core::agent::ExecutionStatusKind::Failed,
                Some(error.to_string()),
            ),
            _ => return,
        };
        if status != echo_core::agent::ExecutionStatusKind::Settled {
            self.pending_publication.clear();
        }
        let mut observation =
            self.terminal_status
                .take()
                .unwrap_or_else(|| echo_core::agent::ExecutionStatus {
                    adapter_generated: false,
                    execution_id: self
                        .observation_execution_id
                        .clone()
                        .unwrap_or_else(|| self.observation_run_id.clone()),
                    request_id: None,
                    sequence: self.status_sequence,
                    phase: echo_core::agent::AgentPhase::Terminal,
                    status: status.clone(),
                    reason: reason.clone(),
                });
        observation.status = status;
        observation.reason = reason;
        // terminal status是最后一个公开事件；SDK可在此停止读取而不会丢正文/尾部原因。
        let needs_cancel_event = observation.status
            == echo_core::agent::ExecutionStatusKind::Cancelled
            && !matches!(&terminal, Ok(AgentEvent::Cancelled));
        self.pending_publication.push_back(terminal);
        if needs_cancel_event {
            self.pending_publication
                .push_back(Ok(AgentEvent::Cancelled));
        }
        self.pending_publication
            .push_back(Ok(AgentEvent::ExecutionStatus(observation)));
    }
}

impl Stream for ManagedAgentEventStream {
    type Item = Result<AgentEvent>;
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let stream = self.get_mut();
        loop {
            if stream.receiver_closed {
                if !stream.publication_ready {
                    match stream.poll_producer(cx) {
                        Poll::Pending => return Poll::Pending,
                        Poll::Ready(Err(error)) => {
                            stream.pending_publication.clear();
                            stream.pending_terminal = Some(Err(error));
                        }
                        Poll::Ready(Ok(())) => {}
                    }
                    stream.prepare_publication();
                }
                let item = stream.pending_publication.pop_front();
                return Poll::Ready(item.map(|item| stream.sequenced(item)));
            }
            match Pin::new(&mut stream.receiver).poll_next(cx) {
                Poll::Pending => return Poll::Pending,
                Poll::Ready(Some(Ok(AgentEvent::ExecutionStatus(status))))
                    if matches!(
                        status.status,
                        echo_core::agent::ExecutionStatusKind::Settled
                            | echo_core::agent::ExecutionStatusKind::Failed
                            | echo_core::agent::ExecutionStatusKind::Cancelled
                    ) =>
                {
                    // producer内部先交发布包标记；公开事实仍由原物理owner完成后才释放。
                    stream.terminal_status = Some(status);
                }
                Poll::Ready(Some(item)) => {
                    let success = matches!(&item, Ok(AgentEvent::FinalAnswer(_)));
                    let failure = item.is_err()
                        || matches!(&item, Ok(AgentEvent::Error { .. } | AgentEvent::Cancelled));
                    if failure {
                        stream.pending_publication.clear();
                        if stream
                            .pending_terminal
                            .as_ref()
                            .is_none_or(|item| matches!(item, Ok(AgentEvent::FinalAnswer(_))))
                        {
                            stream.pending_terminal = Some(item);
                        }
                    } else if success {
                        if stream.pending_terminal.is_none() {
                            stream.pending_terminal = Some(item);
                        }
                    } else if stream.terminal_status.is_some() {
                        stream.pending_publication.push_back(item);
                    } else if stream.pending_terminal.is_none() {
                        return Poll::Ready(Some(stream.sequenced(item)));
                    }
                    // 读到原EOF再join；不能在FinalAnswer处停读而漏尾失败或卡住原sender。
                }
                Poll::Ready(None) => stream.receiver_closed = true,
            }
        }
    }
}

impl Drop for ManagedAgentEventStream {
    fn drop(&mut self) {
        let Some(task) = self.task.take() else {
            return;
        };
        self.cancel.cancel();
        let (_, empty) = mpsc::channel(1);
        let mut receiver = std::mem::replace(
            &mut self.receiver,
            tokio_stream::wrappers::ReceiverStream::new(empty),
        );
        let reaper = self.runtime.spawn(async move {
            // Retain the original receiver as well as its producer. Dropping
            // only the reader can strand a final send during cleanup.
            while receiver.next().await.is_some() {}
            let _ = task.await;
        });
        // Consumer drop releases observation only; the runtime keeps cleanup.
        std::mem::drop(reaper);
    }
}

// ── ReactAgent: entry point ──────────────────────────────────────────

impl ReactAgent {
    /// Channel-based streaming entry point. Returns `BoxStream<'static>`.
    pub(crate) async fn run_stream_channel(
        &self,
        init: StreamInit,
        mode: StreamMode,
    ) -> Result<futures::stream::BoxStream<'static, Result<AgentEvent>>> {
        let buffer = self.config.stream_buffer_size;
        let (tx, rx) = mpsc::channel::<Result<AgentEvent>>(buffer);
        let context = self.memory.context.clone();
        let mut text = init.text.clone();
        let mut message = init.message.clone();
        let label = init.label.clone();
        // 在任何排队/await前值化。plain调用与显式调用只走同一条当前通路。
        let mut invocation = init.invocation.unwrap_or_default();
        let requested_cancel = invocation
            .runtime
            .as_ref()
            .and_then(|runtime| runtime.cancel.as_deref().cloned())
            .or_else(|| invocation.cancel.clone());
        let (mut turn_lease, lifecycle_cancel) = self.close_authority.admit(requested_cancel)?;
        invocation.cancel = Some(lifecycle_cancel.clone());
        if let Some(runtime) = invocation.runtime.as_mut() {
            runtime.cancel = Some(Arc::new(lifecycle_cancel.clone()));
        }
        let runtime_state_id = crate::agent::snapshot::effective_runtime_state_id(
            self.config.conversation_id.as_deref(),
            Some(&invocation),
        );
        crate::agent::snapshot::validate_transcript_generation_identity(
            runtime_state_id,
            invocation.transcript_generation_id.as_deref(),
        )?;
        self.validate_persistence_configuration()?;

        // ★ Acquire execution mutex BEFORE context mutation — using lock_owned()
        // so the guard can be moved into the spawned task and held for the
        // entire stream lifetime.
        let execution_guard = self.execution_mutex.clone().lock_owned().await;
        if lifecycle_cancel.is_cancelled() {
            return Err(crate::error::ReactError::Agent(Box::new(
                crate::error::AgentError::Cancelled(
                    "Agent close cancelled queued turn".to_string(),
                ),
            )));
        }
        // Preparation below may reconcile persistence, hydrate state, emit
        // diagnostics, or start a trace. Abandoning this caller future after
        // admission must therefore remain visible as close debt.
        turn_lease.mark_started();

        let mut admission_snapshot = AgentSnapshot::from_agent_with_invocation(self, &invocation);
        // 当前准备期的同一物理owner持有lease/mutex/资源，直到交给原producer。
        // 去掉旧控制历史归一不代表正常Store已准入工作可因caller drop提前释放。
        let mut preparation_owner =
            ReactStreamTurnOwner::preparation(&admission_snapshot, turn_lease, execution_guard);
        let pending_settlement = match admission_snapshot
            .reconcile_pending_transcript_projection()
            .await
        {
            Ok(settlement) => settlement,
            Err(error) => {
                if let crate::error::ReactError::ExecutionNotSettled {
                    run_id,
                    execution_id,
                } = &error
                {
                    preparation_owner.run_id = Some(run_id.clone());
                    preparation_owner.execution_id = execution_id.clone();
                    preparation_owner.retain_unknown();
                } else {
                    preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                }
                return Err(error);
            }
        };
        if let Some(settlement) = pending_settlement {
            if settlement.status != crate::memory::TranscriptProjectionSettlementStatus::Settled {
                let error =
                    crate::agent::snapshot::transcript_settlement_admission_error(&settlement);
                preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                return Err(error);
            }
            if tx
                .send(Ok(AgentEvent::TranscriptProjectionSettlement(settlement)))
                .await
                .is_err()
            {
                preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                return Err(crate::error::ReactError::Other(
                    "event consumer closed during transcript recovery".to_string(),
                ));
            }
        }
        if admission_snapshot.conversation_store.is_some() {
            let Some(scope_id) = admission_snapshot.config.conversation_id.as_deref() else {
                preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                return Err(crate::error::ConfigError::ConfigFileError(
                    "managed transcript persistence requires a conversation identity".to_string(),
                )
                .into());
            };
            let Some(runtime_state_id) = runtime_state_id else {
                preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                return Err(crate::error::ConfigError::ConfigFileError(
                    "managed transcript persistence requires a runtime-state identity".to_string(),
                )
                .into());
            };
            match self
                .hydrate_managed_runtime_before_input_guard(scope_id, runtime_state_id)
                .await
            {
                Ok(event) => admission_snapshot.pending_checkpoint_resume = event,
                Err(error) => {
                    if let crate::error::ReactError::ExecutionNotSettled {
                        run_id,
                        execution_id,
                    } = &error
                    {
                        preparation_owner.run_id = Some(run_id.clone());
                        preparation_owner.execution_id = execution_id.clone();
                        preparation_owner.retain_unknown();
                    } else {
                        preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                    }
                    return Err(error);
                }
            }
        }

        // Guard raw input before trace, hooks, memory, or conversation context
        // can retain it. Transformations become the authoritative turn input.
        if let Some(gm) = &self.guard.guard_manager {
            let result = match gm
                .check_all(&text, crate::guard::GuardDirection::Input)
                .await
            {
                Ok(result) => result,
                Err(error) => {
                    if let crate::error::ReactError::ExecutionNotSettled {
                        run_id,
                        execution_id,
                    } = &error
                    {
                        preparation_owner.run_id = Some(run_id.clone());
                        preparation_owner.execution_id = execution_id.clone();
                        preparation_owner.retain_unknown();
                    } else {
                        preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                    }
                    return Err(error);
                }
            };
            match result {
                crate::guard::GuardResult::Block { reason } => {
                    let agent = self.config.agent_name.clone();
                    debug!(agent = %agent, reason = %reason, "🛡️ Stream input blocked by guard");
                    if self.guard.audit_logger.is_some() {
                        let event = crate::audit::AuditEvent::now(
                            self.config.session_id.clone(),
                            agent,
                            crate::audit::AuditEventType::GuardBlock {
                                guard: "guard_manager".to_string(),
                                direction: crate::guard::GuardDirection::Input,
                                reason: reason.clone(),
                            },
                        );
                        self.record_audit_event(event).await;
                    }
                    let trace_run_id = self
                        .start_scoped_trace_run(
                            "[input blocked by guard]",
                            admission_snapshot.current_run_id.as_deref(),
                            admission_snapshot.config.conversation_id.as_deref(),
                            admission_snapshot.current_turn_id.as_deref(),
                            admission_snapshot.current_execution_id.as_deref(),
                        )
                        .await;
                    let mut terminal_snapshot =
                        AgentSnapshot::from_agent_with_invocation(self, &invocation);
                    terminal_snapshot.trace_run_id = trace_run_id;
                    if let Some(event) = admission_snapshot.pending_checkpoint_resume.take() {
                        terminal_snapshot.record_event(event).await;
                    }
                    let terminal_reason = format!("Request blocked by safety guard: {reason}");
                    let (_, events) = finish_pre_spawn_terminal(
                        &terminal_snapshot,
                        &context,
                        terminal_reason.clone(),
                        phases::pre_model_block_terminal(
                            self.config.response_format.as_ref(),
                            "input_guard",
                            terminal_reason,
                        ),
                    )
                    .await;
                    if let Some((run_id, execution_id)) =
                        ReactStreamTurnOwner::unknown_identity(&events)
                    {
                        preparation_owner.run_id = Some(run_id);
                        preparation_owner.execution_id = execution_id;
                        preparation_owner.retain_unknown();
                        return Ok(Box::pin(futures::stream::iter(events)));
                    }
                    preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                    return Ok(Box::pin(futures::stream::iter(events)));
                }
                crate::guard::GuardResult::Transform { content, .. } => {
                    text = content;
                    if let Some(original) = message.take() {
                        message = Some(message_with_replaced_text(original, &text));
                    }
                }
                crate::guard::GuardResult::Pass | crate::guard::GuardResult::Warn { .. } => {}
            }
        }

        // Start a unique trace invocation after guard transformation. Product run identity
        // remains in ExternalRunContext and is only used as correlation.
        let trace_run_id = self
            .start_scoped_trace_run(
                &text,
                admission_snapshot.current_run_id.as_deref(),
                admission_snapshot.config.conversation_id.as_deref(),
                admission_snapshot.current_turn_id.as_deref(),
                admission_snapshot.current_execution_id.as_deref(),
            )
            .await;
        admission_snapshot.trace_run_id = trace_run_id.clone();
        // 普通prepare会用当前trace重读并发布实际恢复记录；Guard专用暂存不重复发布。
        admission_snapshot.pending_checkpoint_resume = None;
        let turn_id = invocation
            .runtime
            .as_ref()
            .and_then(|runtime| runtime.turn_id.clone().or_else(|| runtime.run_id.clone()))
            .unwrap_or_else(|| uuid::Uuid::new_v4().to_string());
        let active_turn_lease = self.turn_steer_mailbox.begin(turn_id.clone());
        active_turn_lease.set_run_id(admission_snapshot.current_run_id.clone());
        // admission与实际drain分开：准备期可排队，只有原safe point才消费。
        // Hook拒绝/恢复失败仍由同一lease结算Accepted且未drain的receipt。
        active_turn_lease.set_steerable(true);
        let turn_steer_incarnation = active_turn_lease.incarnation();
        preparation_owner.steering = Some(active_turn_lease);

        // ── Restore thread context (Execute mode) + memory triggers/recall ──
        let persistence_scope_id = admission_snapshot.config.conversation_id.as_deref();
        let recalled_result = if let Some(ref msg) = message {
            self.prepare_stream_context_with_message(
                mode,
                msg,
                &invocation,
                persistence_scope_id,
                runtime_state_id,
                Some(&admission_snapshot),
            )
            .await
        } else {
            self.prepare_stream_context(
                mode,
                &text,
                &invocation,
                persistence_scope_id,
                runtime_state_id,
                Some(&admission_snapshot),
            )
            .await
        };
        let recalled = match recalled_result {
            Ok(recalled) => recalled,
            Err(error)
                if error
                    .to_string()
                    .starts_with("Blocked by UserPromptSubmit hook:") =>
            {
                let reason = error.to_string();
                let mut terminal_snapshot =
                    AgentSnapshot::from_agent_with_invocation(self, &invocation);
                terminal_snapshot.trace_run_id = trace_run_id;
                let (outcome, events) = finish_pre_spawn_terminal(
                    &terminal_snapshot,
                    &context,
                    reason.clone(),
                    phases::pre_model_block_terminal(
                        self.config.response_format.as_ref(),
                        "user_prompt_hook",
                        reason,
                    ),
                )
                .await;
                if let Some((run_id, execution_id)) =
                    ReactStreamTurnOwner::unknown_identity(&events)
                {
                    preparation_owner.run_id = Some(run_id);
                    preparation_owner.execution_id = execution_id;
                    preparation_owner.retain_unknown();
                    return Ok(Box::pin(futures::stream::iter(events)));
                }
                preparation_owner.settle(outcome);
                return Ok(Box::pin(futures::stream::iter(events)));
            }
            Err(error) => {
                if let crate::error::ReactError::ExecutionNotSettled {
                    run_id,
                    execution_id,
                } = &error
                {
                    preparation_owner.run_id = Some(run_id.clone());
                    preparation_owner.execution_id = execution_id.clone();
                    preparation_owner.retain_unknown();
                    return Err(error);
                }
                let mut terminal_snapshot =
                    AgentSnapshot::from_agent_with_invocation(self, &invocation);
                terminal_snapshot.trace_run_id = trace_run_id;
                let terminal = AgentEvent::from_error("react_loop", &error)?;
                let (outcome, events) = finish_pre_spawn_terminal(
                    &terminal_snapshot,
                    &context,
                    error.to_string(),
                    terminal,
                )
                .await;
                if let Some((run_id, execution_id)) =
                    ReactStreamTurnOwner::unknown_identity(&events)
                {
                    preparation_owner.run_id = Some(run_id);
                    preparation_owner.execution_id = execution_id;
                    preparation_owner.retain_unknown();
                    return Ok(Box::pin(futures::stream::iter(events)));
                }
                preparation_owner.settle(outcome);
                return Ok(Box::pin(futures::stream::iter(events)));
            }
        };
        // A tracked cold-input receipt may be published only after the initial
        // message has been inserted into ContextManager and before intent
        // routing or provider execution begins. Generic Agent implementations
        // that do not provide this publisher intentionally leave the receipt
        // at `drained = false`.
        if let Some(lifecycle) = invocation.input_lifecycle.as_ref() {
            lifecycle.mark_drained();
        }

        // ── G2: IntentRouter classification (converged with run_react_loop) ──
        // Routing may activate a skill. DirectAnswer uses the canonical loop
        // so every invocation has the same lifecycle and terminal authority.
        if let Some(ref router) = self.intent_router {
            let messages = self.memory.context.lock().await.messages().to_vec();
            let cancel = invocation.cancel.clone().unwrap_or_default();
            let intent = router.classify_with_cancel(&text, &messages, cancel).await;
            match intent {
                crate::intent::Intent::DirectAnswer { confidence } => {
                    tracing::debug!(
                        agent = %self.config.agent_name,
                        confidence,
                        "Stream DirectAnswer routed through ReAct for pre-model projection"
                    );
                }
                crate::intent::Intent::SkillRequired {
                    skill_name,
                    confidence,
                } => {
                    tracing::info!(
                        agent = %self.config.agent_name,
                        skill = %skill_name,
                        confidence = confidence,
                        "🎯 Stream IntentRouter: activating skill"
                    );
                    if let Err(e) = self.activate_skill(&skill_name).await {
                        tracing::warn!(
                            skill = %skill_name,
                            error = %e,
                            "Stream IntentRouter: failed to activate skill"
                        );
                    }
                    // Fall through to run_core_loop.
                }
                crate::intent::Intent::Fallback => {
                    tracing::debug!(
                        agent = %self.config.agent_name,
                        "Stream IntentRouter: Fallback to ReAct"
                    );
                }
            }
        }

        let mut snap = AgentSnapshot::from_agent_with_invocation(self, &invocation);
        snap.current_turn_id = Some(turn_id.clone());
        if snap.current_execution_id.is_none() {
            snap.current_execution_id = Some(format!("execution:{}", uuid::Uuid::new_v4()));
        }
        snap.turn_steer_incarnation = Some(turn_steer_incarnation);
        snap.current_message = message.clone();
        snap.trace_run_id = trace_run_id;
        let consumer_cancel = snap
            .cancel_token
            .as_ref()
            .or(snap.external_cancel.as_deref())
            .map(crate::agent::CancellationToken::child_token)
            .unwrap_or_default();
        snap.cancel_token = Some(consumer_cancel.clone());
        snap.external_cancel = Some(Arc::new(consumer_cancel.clone()));
        let terminal_cancel = consumer_cancel.clone();
        let failure_snapshot = snap.clone();

        let runtime = match tokio::runtime::Handle::try_current() {
            Ok(runtime) => runtime,
            Err(error) => {
                preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);
                return Err(crate::error::ReactError::Other(format!(
                    "stream execution requires a Tokio runtime: {error}"
                )));
            }
        };
        // 流观察身份可使用turn id；它不回填snapshot或current_run_id公共观察值。
        let observation_run_id = snap
            .current_run_id
            .clone()
            .unwrap_or_else(|| turn_id.clone());
        let observation_execution_id = snap.current_execution_id.clone();
        preparation_owner.run_id = Some(observation_run_id.clone());
        preparation_owner.execution_id = observation_execution_id.clone();
        preparation_owner.resource_guards = snap.resource_guards.clone();
        let mut physical_owner = preparation_owner;
        let task = runtime.spawn(async move {
            // The same original resources survive either an explicit unknown
            // result or producer unwind; no parked replacement task is made.
            match snap
                .run_core_loop(
                    context,
                    text,
                    message,
                    label,
                    mode,
                    recalled,
                    true,
                    tx.clone(),
                )
                .await
            {
                Ok(outcome) => physical_owner.settle(outcome),
                Err(error) => {
                    if let crate::error::ReactError::ExecutionNotSettled {
                        run_id,
                        execution_id,
                    } = &error
                    {
                        physical_owner.run_id = Some(run_id.clone());
                        physical_owner.execution_id = execution_id.clone();
                        physical_owner.retain_unknown();
                        let _ = tx.send(Err(error)).await;
                        return;
                    }
                    let outcome = if terminal_cancel.is_cancelled() {
                        crate::agent::AgentSteerTurnOutcome::Cancelled
                    } else {
                        crate::agent::AgentSteerTurnOutcome::Failed
                    };
                    let settlement_already_observed =
                        failure_snapshot.transcript_settlement_was_observed();
                    if failure_snapshot.conversation_store.is_some() && !settlement_already_observed
                    {
                        let settlement = failure_snapshot.observe_persistence_failure(&error).await;
                        let _ = tx
                            .send(Ok(AgentEvent::TranscriptProjectionSettlement(settlement)))
                            .await;
                    }
                    failure_snapshot
                        .finalize_run(
                            if outcome == crate::agent::AgentSteerTurnOutcome::Cancelled {
                                crate::trace::RunStatus::Cancelled
                            } else {
                                crate::trace::RunStatus::Failed
                            },
                            None,
                            Some(&error.to_string()),
                        )
                        .await;
                    let _ = tx.send(AgentEvent::from_error("react_loop", &error)).await;
                    physical_owner.settle(outcome);
                }
            }
        });

        Ok(Box::pin(ManagedAgentEventStream {
            receiver: tokio_stream::wrappers::ReceiverStream::new(rx),
            cancel: consumer_cancel,
            task: Some(task),
            runtime,
            pending_terminal: None,
            pending_publication: std::collections::VecDeque::new(),
            status_sequence: 0,
            terminal_status: None,
            publication_ready: false,
            receiver_closed: false,
            observation_run_id,
            observation_execution_id,
        }))
    }
}

fn message_with_replaced_text(mut message: Message, replacement: &str) -> Message {
    message.content = match message.content {
        MessageContent::Parts(parts) => {
            let mut retained = Vec::with_capacity(parts.len().saturating_add(1));
            retained.push(ContentPart::Text {
                text: replacement.to_string(),
            });
            retained.extend(
                parts
                    .into_iter()
                    .filter(|part| !matches!(part, ContentPart::Text { .. })),
            );
            MessageContent::Parts(retained)
        }
        MessageContent::Text(_) | MessageContent::Empty => {
            MessageContent::Text(replacement.to_string())
        }
    };
    message
}

// ── AgentRunSnapshot: core loop driver ───────────────────────────────

use crate::agent::snapshot::AgentRunSnapshot as AgentSnapshot;

// Helper to create snapshot from agent (keeps the same API for rest of file)

impl AgentSnapshot {
    fn failure_terminal(&self) -> crate::agent::AgentSteerTurnOutcome {
        if self
            .cancel_token
            .as_ref()
            .is_some_and(crate::agent::CancellationToken::is_cancelled)
            || self
                .external_cancel
                .as_deref()
                .is_some_and(crate::agent::CancellationToken::is_cancelled)
        {
            crate::agent::AgentSteerTurnOutcome::Cancelled
        } else {
            crate::agent::AgentSteerTurnOutcome::Failed
        }
    }

    async fn settle_unobserved_terminal(
        &self,
        context: &Arc<tokio::sync::Mutex<crate::compression::ContextManager>>,
        reason: &str,
    ) -> Result<()> {
        let settlement = self
            .save_transcript_projection(context, Some(reason.to_string()))
            .await?;
        match settlement.status {
            crate::memory::TranscriptProjectionSettlementStatus::Settled
            | crate::memory::TranscriptProjectionSettlementStatus::Deferred => Ok(()),
            crate::memory::TranscriptProjectionSettlementStatus::Blocked
            | crate::memory::TranscriptProjectionSettlementStatus::Conflict => {
                Err(crate::error::ReactError::RuntimeState(Box::new(
                    echo_core::error::RuntimeStateError::ManagedStateRequiresCas(format!(
                        "unobserved terminal persistence did not settle: {:?}",
                        settlement.status
                    )),
                )))
            }
        }
    }

    pub(super) fn has_pending_steer(&self) -> bool {
        match (&self.current_turn_id, &self.turn_steer_incarnation) {
            (Some(turn_id), Some(incarnation)) => {
                self.turn_steer_mailbox.has_pending(turn_id, incarnation)
            }
            _ => false,
        }
    }

    pub(super) async fn drain_steer_into_context(
        &self,
        context: &Arc<tokio::sync::Mutex<crate::compression::ContextManager>>,
        assistant_draft: Option<Message>,
    ) -> usize {
        let Some(turn_id) = self.current_turn_id.as_deref() else {
            return 0;
        };
        let Some(incarnation) = self.turn_steer_incarnation.as_ref() else {
            return 0;
        };
        let mut guard = context.lock().await;
        let pending = self.turn_steer_mailbox.take_pending(turn_id, incarnation);
        if pending.is_empty() {
            return 0;
        }
        let count = pending.len();
        if let Some(draft) = assistant_draft {
            guard.push(draft);
        }
        for message in pending.messages() {
            guard.push(message.clone());
        }
        pending.mark_drained();
        count
    }

    /// Unified ReAct core loop — shared by both streaming and non-streaming paths.
    ///
    /// The non-streaming path (`run_react_loop`) creates a channel and runs this
    /// method, then collects `FinalAnswer` from the events. The streaming path
    /// (`run_stream_channel`) spawns this in a `tokio::spawn` and returns the
    /// receiver as a `BoxStream`.
    ///
    /// This body is intentionally thin: each block of work lives in
    /// [`super::phases`]. The single iteration loop
    /// is the project's only ReAct loop — phase functions are called from
    /// here, never from a sibling driver.
    #[allow(clippy::too_many_arguments)]
    pub(crate) async fn run_core_loop(
        self,
        context: Arc<tokio::sync::Mutex<crate::compression::ContextManager>>,
        text: String,
        _message: Option<Message>,
        label: String,
        mode: StreamMode,
        recalled: usize,
        user_prompt_hook_already_run: bool,
        tx: mpsc::Sender<Result<AgentEvent>>,
    ) -> Result<crate::agent::AgentSteerTurnOutcome> {
        // NOTE: execution_mutex is already held by the spawned task
        // (acquired in run_stream_channel via lock_owned()), so we don't
        // need to lock again here.

        let _ = tx
            .send(Ok(phases::finalize::execution_status_event(
                &self,
                echo_core::agent::ExecutionStatusKind::Started,
                echo_core::agent::AgentPhase::Thinking,
                None,
                0,
                None,
            )))
            .await;
        let structured_format_result = self
            .config
            .response_format
            .as_ref()
            .filter(|format| format.is_json())
            .map(crate::agent::react::extract::PreparedResponseFormat::new)
            .transpose();
        let structured_format = match structured_format_result {
            Ok(prepared) => prepared,
            Err(error) => {
                phases::finalize::settle_terminal_projection(
                    &self,
                    &context,
                    Some(error.to_string()),
                    &tx,
                )
                .await?;
                return Err(error);
            }
        };

        // ── Pre-loop preparation ─────────────────────────────────────
        let mut state = match phases::prepare::prepare_turn(
            &self,
            &context,
            &tx,
            &text,
            &label,
            mode,
            recalled,
            user_prompt_hook_already_run,
        )
        .await?
        {
            PrepareOutcome::Continue => LoopState::new(),
            PrepareOutcome::BlockedAndDone => {
                return Ok(crate::agent::AgentSteerTurnOutcome::Failed);
            }
            PrepareOutcome::Abandoned => {
                self.settle_unobserved_terminal(
                    &context,
                    "event consumer disconnected during preparation",
                )
                .await?;
                self.finalize_run(
                    crate::trace::RunStatus::Cancelled,
                    None,
                    Some("event consumer disconnected during preparation"),
                )
                .await;
                return Ok(crate::agent::AgentSteerTurnOutcome::Cancelled);
            }
        };

        let agent_name = self.config.agent_name.clone();

        // ── The single core ReAct loop ───────────────────────────────
        // Builders reject zero. A directly constructed or restored invalid
        // config still remains bounded here and reaches typed finalization.
        let max_iterations = self.config.max_iterations;
        for iteration in 0..max_iterations {
            if phases::cancellation_requested(&self) {
                return phases::finalize::settle_cancelled_final_candidate(&self, &context, &tx)
                    .await;
            }
            for cb in self.config.callbacks.iter() {
                cb.on_iteration(&agent_name, iteration).await;
            }
            debug!(
                agent = %agent_name,
                iteration = iteration + 1,
                "--- Streaming iteration{label} ---",
            );

            let _ = self.drain_steer_into_context(&context, None).await;

            let remaining = max_iterations.saturating_sub(iteration);
            if !state.budget.wind_down_emitted
                && self
                    .config
                    .run_budget
                    .iteration_wind_down_remaining
                    .is_some_and(|threshold| threshold > 0 && remaining <= threshold)
            {
                state.budget.wind_down_emitted = true;
                super::context::push_runtime_context_note(
                    &context,
                    "RunBudget:WindDown",
                    "The iteration budget is nearly exhausted. Stop opening new branches and converge on a final answer.",
                )
                .await;
                let _ = tx
                    .send(Ok(AgentEvent::BudgetDecision {
                        decision: echo_core::agent::BudgetDecision::WindDown,
                        reason: "iteration_wind_down".to_string(),
                        iteration: iteration.saturating_add(1),
                        reported_model_tokens: state.budget.reported_model_tokens,
                        usage_complete: state.budget.usage_complete,
                    }))
                    .await;
                self.record_event(crate::trace::RunEvent::BudgetDecision {
                    decision: "wind_down".to_string(),
                    reason: "iteration_wind_down".to_string(),
                    iteration: iteration.saturating_add(1),
                    reported_model_tokens: state.budget.reported_model_tokens,
                    usage_complete: state.budget.usage_complete,
                })
                .await;
            }

            if state.budget.final_only && !state.budget.final_only_emitted {
                state.budget.final_only_emitted = true;
                super::context::push_runtime_context_note(
                    &context,
                    "RunBudget:FinalOnly",
                    "The model-token budget is exhausted. Produce the best final answer now without calling tools.",
                )
                .await;
            }

            // Compact: PreCompact hook → (stage4 E1) pre_compaction_flush →
            //          checkpoint → ContextManager.prepare → PostCompact hook.
            // The flush itself lives inside `run_compact` so every compaction
            // path benefits and it is gated on `should_compress()`.
            let messages =
                match phases::compact::run_compact(&self, &context, &tx, iteration).await? {
                    phases::CompactOutcome::Continue(m) => m,
                    phases::CompactOutcome::Abandoned => {
                        self.settle_unobserved_terminal(
                            &context,
                            "event consumer disconnected during compaction",
                        )
                        .await?;
                        self.finalize_run(
                            crate::trace::RunStatus::Cancelled,
                            None,
                            Some("event consumer disconnected during compaction"),
                        )
                        .await;
                        return Ok(crate::agent::AgentSteerTurnOutcome::Cancelled);
                    }
                    phases::CompactOutcome::Failed => {
                        let outcome = self.failure_terminal();
                        let status = if outcome == crate::agent::AgentSteerTurnOutcome::Cancelled {
                            crate::trace::RunStatus::Cancelled
                        } else {
                            crate::trace::RunStatus::Failed
                        };
                        self.finalize_run(status, None, Some("context preparation failed"))
                            .await;
                        return Ok(outcome);
                    }
                };

            // Think: callbacks + interventions + LLM stream → buffered output
            let final_only = state.budget.final_only;
            let think = match phases::think::run_think(
                &self, &context, &tx, messages, final_only, iteration,
            )
            .await?
            {
                phases::ThinkOutcome::Continue(t) => *t,
                phases::ThinkOutcome::Abandoned => {
                    self.settle_unobserved_terminal(
                        &context,
                        "event consumer disconnected during model response",
                    )
                    .await?;
                    self.finalize_run(
                        crate::trace::RunStatus::Cancelled,
                        None,
                        Some("event consumer disconnected or intervention blocked the run"),
                    )
                    .await;
                    return Ok(crate::agent::AgentSteerTurnOutcome::Cancelled);
                }
                phases::ThinkOutcome::TerminalSettled { outcome } => return Ok(outcome),
            };

            let iteration_tokens = think.pt.saturating_add(think.ct);
            state
                .budget
                .record_usage(iteration_tokens, think.usage_reported);
            if !state.budget.final_only
                && self
                    .config
                    .run_budget
                    .max_model_tokens
                    .is_some_and(|limit| limit > 0 && state.budget.reported_model_tokens >= limit)
            {
                state.budget.final_only = true;
                let _ = tx
                    .send(Ok(AgentEvent::BudgetDecision {
                        decision: echo_core::agent::BudgetDecision::FinalOnly,
                        reason: "model_token_budget".to_string(),
                        iteration: iteration.saturating_add(1),
                        reported_model_tokens: state.budget.reported_model_tokens,
                        usage_complete: state.budget.usage_complete,
                    }))
                    .await;
                self.record_event(crate::trace::RunEvent::BudgetDecision {
                    decision: "final_only".to_string(),
                    reason: "model_token_budget".to_string(),
                    iteration: iteration.saturating_add(1),
                    reported_model_tokens: state.budget.reported_model_tokens,
                    usage_complete: state.budget.usage_complete,
                })
                .await;
            }

            if state.budget.final_only && !think.tool_call_map.is_empty() {
                super::context::push_runtime_context_note(
                    &context,
                    "RunBudget:BlockedTools",
                    "Tool calls were ignored because this invocation is in final-only mode. Return a text answer.",
                )
                .await;
                continue;
            }

            // Branch: tool calls vs text answer vs no-response
            let outcome = if !think.tool_call_map.is_empty() {
                let _ = tx
                    .send(Ok(phases::finalize::execution_status_event(
                        &self,
                        echo_core::agent::ExecutionStatusKind::ToolPending,
                        echo_core::agent::AgentPhase::Acting,
                        think
                            .assistant_blocks
                            .first()
                            .map(|block| block.request_id.clone())
                            .or_else(|| {
                                think.tool_call_map.values().find_map(|(_, _, _, source)| {
                                    source.as_ref().map(|source| source.request_id.clone())
                                })
                            }),
                        0,
                        None,
                    )))
                    .await;
                phases::tools::run_tools(&self, &context, &tx, iteration, think, &label).await?
            } else if (think.continue_response
                && (!think.assistant_blocks.is_empty()
                    || !think.reasoning_blocks.is_empty()
                    || !think.reasoning_buffer.is_empty()))
                || (think.candidate_answer.is_none()
                    && phases::assistant_progress_only(&think.assistant_blocks))
            {
                // 显式进度/部分回答存原消息后继续同一执行；它不是最终候选，也不调用Stop。
                let mut message = phases::with_reasoning_content(
                    Message::assistant(think.content_buffer),
                    think.reasoning_buffer,
                    think.reasoning_blocks,
                );
                message.assistant_blocks = Some(think.assistant_blocks);
                message.approved_assistant_blocks = Some(think.approved_assistant_blocks);
                context.lock().await.push(message);
                self.save_runtime_checkpoint(&context, None).await?;
                IterOutcome::Continue
            } else if think.candidate_answer.is_some() {
                let mut think = think;
                let mut assistant_draft = phases::with_reasoning_content(
                    Message::assistant(think.content_buffer.clone()),
                    think.reasoning_buffer.clone(),
                    think.reasoning_blocks.clone(),
                );
                assistant_draft.assistant_blocks = Some(think.assistant_blocks.clone());
                assistant_draft.approved_assistant_blocks = Some(Vec::new());
                if self
                    .drain_steer_into_context(&context, Some(assistant_draft))
                    .await
                    > 0
                {
                    continue;
                }
                // 只校验完整响应选出的最终块；前面的进度不是最终回答的前缀。
                let candidate = think.candidate_answer.take().unwrap_or_default();
                think.content_buffer = match self.check_final_answer_guard(&candidate).await {
                    Ok(answer) => answer,
                    Err(error) => {
                        return phases::finalize::settle_final_guard_failure(
                            &self, &context, &tx, error,
                        )
                        .await;
                    }
                };
                match phases::verify::validate_structured_final(
                    structured_format.as_ref(),
                    &self,
                    &context,
                    &mut state,
                    iteration,
                    &think.content_buffer,
                )
                .await
                {
                    Ok(true) => {}
                    Ok(false) => continue,
                    Err(error) => {
                        phases::finalize::settle_terminal_projection(
                            &self,
                            &context,
                            Some(error.to_string()),
                            &tx,
                        )
                        .await?;
                        return Err(error);
                    }
                }
                let pt = think.pt;
                let ct = think.ct;
                if phases::cancellation_requested(&self) {
                    return phases::finalize::settle_cancelled_final_candidate(
                        &self, &context, &tx,
                    )
                    .await;
                }
                let verified = tokio::select! {
                    verified = phases::verify::verify_final_text(
                        &self, &context, &tx, &mut state, iteration, think, &label,
                    ) => verified,
                    _ = phases::wait_for_cancellation(&self) => {
                        return phases::finalize::settle_cancelled_final_candidate(
                            &self, &context, &tx,
                        ).await;
                    }
                };
                if phases::cancellation_requested(&self) {
                    return phases::finalize::settle_cancelled_final_candidate(
                        &self, &context, &tx,
                    )
                    .await;
                }
                match verified? {
                    IterOutcome::Continue => continue,
                    IterOutcome::FinalText {
                        answer,
                        reasoning_content,
                        reasoning_blocks,
                        assistant_blocks,
                    } => {
                        match phases::finalize::emit_final_text(
                            &self,
                            &context,
                            &tx,
                            &mut state,
                            iteration,
                            pt,
                            ct,
                            answer,
                            reasoning_content,
                            reasoning_blocks,
                            assistant_blocks,
                            true,
                        )
                        .await?
                        {
                            ControlFlow::Continue(()) => continue,
                            ControlFlow::Break(outcome) => return Ok(outcome),
                        }
                    }
                    other => other,
                }
            } else {
                IterOutcome::NoResponse
            };

            match outcome {
                IterOutcome::Continue => {
                    continue;
                }
                // FinalText is only produced by verify_final_text and is
                // already handled inline in the text branch above. Reaching
                // it here would mean a phase returned an outcome out of band
                // — guard against future refactors by treating it as a
                // terminal text emission.
                IterOutcome::FinalText {
                    answer,
                    reasoning_content,
                    reasoning_blocks,
                    assistant_blocks,
                } => {
                    let answer = match self.check_final_answer_guard(&answer).await {
                        Ok(answer) => answer,
                        Err(error) => {
                            return phases::finalize::settle_final_guard_failure(
                                &self, &context, &tx, error,
                            )
                            .await;
                        }
                    };
                    match phases::verify::validate_structured_final(
                        structured_format.as_ref(),
                        &self,
                        &context,
                        &mut state,
                        iteration,
                        &answer,
                    )
                    .await
                    {
                        Ok(true) => {}
                        Ok(false) => continue,
                        Err(error) => {
                            phases::finalize::settle_terminal_projection(
                                &self,
                                &context,
                                Some(error.to_string()),
                                &tx,
                            )
                            .await?;
                            return Err(error);
                        }
                    }
                    let pt = 0;
                    let ct = 0;
                    match phases::finalize::emit_final_text(
                        &self,
                        &context,
                        &tx,
                        &mut state,
                        iteration,
                        pt,
                        ct,
                        answer,
                        reasoning_content,
                        reasoning_blocks,
                        assistant_blocks,
                        true,
                    )
                    .await?
                    {
                        ControlFlow::Continue(()) => continue,
                        ControlFlow::Break(outcome) => return Ok(outcome),
                    }
                }
                IterOutcome::NoResponse => {
                    phases::finalize::finalize_no_response(&self, &context, tx).await?;
                    return Ok(crate::agent::AgentSteerTurnOutcome::Failed);
                }
                IterOutcome::TerminalSettled { outcome } => return Ok(outcome),
                IterOutcome::Abandoned => {
                    self.settle_unobserved_terminal(
                        &context,
                        "event consumer disconnected or tool batch was abandoned",
                    )
                    .await?;
                    self.finalize_run(
                        crate::trace::RunStatus::Cancelled,
                        None,
                        Some("event consumer disconnected or tool batch was abandoned"),
                    )
                    .await;
                    return Ok(crate::agent::AgentSteerTurnOutcome::Cancelled);
                }
            }
        }

        // ── Post-loop: max iterations exceeded ───────────────────────
        phases::finalize::finalize_max_iterations(&self, &context, tx).await?;
        Ok(crate::agent::AgentSteerTurnOutcome::Failed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent::config::AgentConfig;
    use crate::compression::{ContextProjection, PreModelContextProjector, ProjectionContext};
    use crate::intent::{Intent, IntentClassifier, IntentRouter, IntentRouterConfig};
    use echo_core::agent::{Agent, AgentInputLifecycle};
    use echo_core::guard::{Guard, GuardDirection, GuardManager, GuardResult};
    use futures::StreamExt;
    use futures::future::BoxFuture;
    use std::sync::Arc;

    /// 验证整个原生事件序列；不剥离新status去满足旧末尾断言。
    fn assert_native_runtime_terminal(
        events: &[AgentEvent],
        expected: echo_core::agent::ExecutionStatusKind,
    ) {
        use echo_core::agent::{AgentPhase, ExecutionStatusKind};
        let statuses: Vec<_> = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::ExecutionStatus(status) => Some(status),
                _ => None,
            })
            .collect();
        assert_eq!(
            statuses
                .iter()
                .filter(|status| status.status == ExecutionStatusKind::Started)
                .count(),
            1,
            "{events:?}"
        );
        let identity = statuses
            .first()
            .map(|status| status.execution_id.as_str())
            .unwrap_or("");
        assert!(!identity.is_empty(), "{events:?}");
        assert!(
            statuses
                .iter()
                .all(|status| status.execution_id == identity),
            "同执行不能换身份：{events:?}"
        );
        for pair in statuses.windows(2) {
            if let Some((left, right)) = pair.first().zip(pair.get(1)) {
                assert!(
                    left.sequence < right.sequence,
                    "状态序号须严格递增：{events:?}"
                );
            }
        }
        assert_eq!(
            events
                .iter()
                .filter(|event| event.is_execution_terminal())
                .count(),
            1,
            "{events:?}"
        );
        assert!(
            matches!(events.last(),Some(AgentEvent::ExecutionStatus(status)) if status.status==expected&&status.phase==AgentPhase::Terminal),
            "最后一次真实status：{events:?}"
        );
        assert!(
            events
                .iter()
                .all(|event| serde_json::to_value(event).is_ok_and(|value| {
                    value
                        .get("type")
                        .and_then(serde_json::Value::as_str)
                        .is_some_and(|kind| !matches!(kind, "token" | "think_start" | "think_end"))
                })),
            "新执行不再重复旧正文/思考事件：{events:?}"
        );
        let answers = events
            .iter()
            .filter(|event| matches!(event, AgentEvent::FinalAnswer(_)))
            .count();
        if expected == ExecutionStatusKind::Settled {
            assert_eq!(answers, 1, "成功确认回答恰一次：{events:?}");
            assert!(
                !events
                    .iter()
                    .any(|event| matches!(event, AgentEvent::Error { .. } | AgentEvent::Cancelled)),
                "失败/取消不能伪成功：{events:?}"
            );
            let answer_position = events
                .iter()
                .position(|event| matches!(event, AgentEvent::FinalAnswer(_)));
            assert!(
                answer_position.is_some_and(|index| index.saturating_add(1) < events.len()),
                "正文先于末尾物理结算：{events:?}"
            );
        } else {
            assert_eq!(answers, 0, "失败/取消不得有成功回答：{events:?}");
        }
    }
    fn last_confirmed_final(events: &[AgentEvent]) -> Option<&AgentEvent> {
        assert_native_runtime_terminal(events, echo_core::agent::ExecutionStatusKind::Settled);
        events
            .iter()
            .find(|event| matches!(event, AgentEvent::FinalAnswer(_)))
    }
    /// 仅是现Mock的原生协议fixture；不增加runner或执行权威。
    fn native_response_script(
        request: &str,
        parts: &[(echo_core::agent::AssistantPhase, &str)],
    ) -> Result<Vec<StreamChunk>> {
        let blocks: Vec<_> = parts
            .iter()
            .enumerate()
            .map(
                |(index, (phase, text))| echo_core::agent::AssistantMessageBlock {
                    block_id: format!("{request}:{index}"),
                    request_id: request.to_string(),
                    sequence: u64::try_from(index).unwrap_or(u64::MAX),
                    phase: *phase,
                    delta: (*text).to_string(),
                    complete: true,
                    provider: Some("mock".into()),
                    provider_source: None,
                    reasoning: None,
                },
            )
            .collect();
        let content: String = parts.iter().map(|(_, text)| *text).collect();
        let delta: DeltaMessage = serde_json::from_value(
            serde_json::json!({"role":"assistant","content":content,"assistant_blocks":blocks}),
        )?;
        Ok(vec![
            StreamChunk::Delta(delta),
            StreamChunk::Terminal {
                finish_reason: Some("stop".into()),
                usage: None,
            },
        ])
    }

    #[tokio::test]
    async fn managed_stream_releases_terminal_after_producer_settlement() -> Result<()> {
        use futures::StreamExt;

        let (tx, rx) = mpsc::channel(1);
        let release = Arc::new(tokio::sync::Notify::new());
        let producer_release = Arc::clone(&release);
        let (terminal_tx, terminal_rx) = tokio::sync::oneshot::channel();
        let task = tokio::spawn(async move {
            if tx
                .send(Ok(AgentEvent::FinalAnswer("done".to_string())))
                .await
                .is_err()
            {
                return;
            }
            let _ = terminal_tx.send(());
            producer_release.notified().await;
        });
        let mut stream = ManagedAgentEventStream {
            receiver: tokio_stream::wrappers::ReceiverStream::new(rx),
            cancel: crate::agent::CancellationToken::new(),
            task: Some(task),
            runtime: tokio::runtime::Handle::current(),
            pending_terminal: None,
            pending_publication: std::collections::VecDeque::new(),
            status_sequence: 0,
            terminal_status: None,
            publication_ready: false,
            receiver_closed: false,
            observation_run_id: "managed-stream-test-run".to_string(),
            observation_execution_id: Some("managed-stream-test-execution".to_string()),
        };

        terminal_rx.await.map_err(|_| {
            crate::error::ReactError::Other("producer did not buffer terminal".to_string())
        })?;
        let mut next = Box::pin(stream.next());
        if !matches!(futures::poll!(&mut next), Poll::Pending) {
            return Err(crate::error::ReactError::Other(
                "terminal escaped before producer settlement".to_string(),
            ));
        }
        release.notify_one();
        let terminal = next.await.ok_or_else(|| {
            crate::error::ReactError::Other("managed stream ended without terminal".to_string())
        })??;
        if !matches!(terminal, AgentEvent::FinalAnswer(answer) if answer == "done") {
            return Err(crate::error::ReactError::Other(
                "managed stream returned the wrong terminal".to_string(),
            ));
        }
        let settled = stream.next().await.ok_or_else(|| {
            crate::error::ReactError::Other("missing physical completion status".into())
        })??;
        assert!(
            matches!(settled,AgentEvent::ExecutionStatus(status) if status.status==echo_core::agent::ExecutionStatusKind::Settled)
        );
        assert!(stream.next().await.is_none(), "terminal status之后必须EOF");
        Ok(())
    }

    #[tokio::test]
    async fn managed_stream_replaces_buffered_terminal_when_producer_fails() -> Result<()> {
        use futures::StreamExt;

        let (tx, rx) = mpsc::channel(1);
        let (terminal_tx, terminal_rx) = tokio::sync::oneshot::channel();
        let task = tokio::spawn(async move {
            if tx
                .send(Ok(AgentEvent::FinalAnswer("must-not-escape".to_string())))
                .await
                .is_err()
            {
                return;
            }
            let _ = terminal_tx.send(());
            std::future::pending::<()>().await;
        });
        let abort = task.abort_handle();
        let mut stream = ManagedAgentEventStream {
            receiver: tokio_stream::wrappers::ReceiverStream::new(rx),
            cancel: crate::agent::CancellationToken::new(),
            task: Some(task),
            runtime: tokio::runtime::Handle::current(),
            pending_terminal: None,
            pending_publication: std::collections::VecDeque::new(),
            status_sequence: 0,
            terminal_status: None,
            publication_ready: false,
            receiver_closed: false,
            observation_run_id: "managed-stream-test-run".to_string(),
            observation_execution_id: Some("managed-stream-test-execution".to_string()),
        };

        terminal_rx.await.map_err(|_| {
            crate::error::ReactError::Other("producer did not buffer terminal".to_string())
        })?;
        abort.abort();
        let failure = stream
            .next()
            .await
            .ok_or_else(|| {
                crate::error::ReactError::Other(
                    "managed stream ended without producer failure".to_string(),
                )
            })?
            .err()
            .ok_or_else(|| {
                crate::error::ReactError::Other(
                    "buffered success escaped after producer failure".to_string(),
                )
            })?;
        if !matches!(
            &failure,
            crate::error::ReactError::ExecutionNotSettled { run_id, execution_id }
                if run_id == "managed-stream-test-run"
                    && execution_id.as_deref() == Some("managed-stream-test-execution")
        ) {
            return Err(crate::error::ReactError::Other(format!(
                "managed stream returned unexpected failure: {failure}"
            )));
        }
        if stream.next().await.is_some() {
            return Err(crate::error::ReactError::Other(
                "managed stream repeated producer failure".to_string(),
            ));
        }
        Ok(())
    }

    /// A guard that blocks every input with a fixed reason.
    struct BlockingGuard;
    impl Guard for BlockingGuard {
        fn name(&self) -> &str {
            "test-blocking-guard"
        }
        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: GuardDirection,
        ) -> BoxFuture<'a, Result<GuardResult>> {
            Box::pin(async move {
                if matches!(direction, GuardDirection::Input) {
                    Ok(GuardResult::Block {
                        reason: "test-input-blocked".into(),
                    })
                } else {
                    Ok(GuardResult::Pass)
                }
            })
        }
    }

    struct AwaitingGuard {
        started: Arc<tokio::sync::Notify>,
    }

    impl Guard for AwaitingGuard {
        fn name(&self) -> &str {
            "awaiting-guard"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            _direction: GuardDirection,
        ) -> BoxFuture<'a, Result<GuardResult>> {
            Box::pin(async move {
                self.started.notify_one();
                std::future::pending::<Result<GuardResult>>().await
            })
        }
    }

    struct CountingGuard {
        calls: Arc<std::sync::atomic::AtomicUsize>,
    }

    struct InvalidFinalJsonGuard;

    struct BlockDraftFinalGuard;

    struct SequentialMarkerTool;

    struct BlockingFinalCritic {
        entered: Arc<tokio::sync::Notify>,
        release: Arc<tokio::sync::Notify>,
    }

    impl echo_core::agent::Critic for BlockingFinalCritic {
        fn critique<'a>(
            &'a self,
            _task: &'a str,
            _answer: &'a str,
            _context: &'a str,
        ) -> BoxFuture<'a, Result<echo_core::agent::Critique>> {
            Box::pin(async move {
                self.entered.notify_one();
                self.release.notified().await;
                Ok(echo_core::agent::Critique {
                    score: 10.0,
                    passed: true,
                    feedback: "accepted".to_string(),
                    suggestions: Vec::new(),
                })
            })
        }
    }

    impl crate::tools::Tool for SequentialMarkerTool {
        fn name(&self) -> &str {
            "sequential_marker"
        }

        fn description(&self) -> &str {
            "Return a marker after the preceding tool call"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type":"object","properties":{}})
        }

        fn execute(
            &self,
            _parameters: crate::tools::ToolParameters,
        ) -> BoxFuture<'_, Result<crate::tools::ToolResult>> {
            Box::pin(async { Ok(crate::tools::ToolResult::success("later tool result")) })
        }

        fn risk_level(&self) -> crate::tools::ToolRiskLevel {
            crate::tools::ToolRiskLevel::ReadOnly
        }

        fn allows_parallel_batch_execution(&self) -> bool {
            false
        }
    }

    impl Guard for BlockDraftFinalGuard {
        fn name(&self) -> &str {
            "block-draft-final"
        }

        fn check<'a>(
            &'a self,
            content: &'a str,
            direction: GuardDirection,
        ) -> BoxFuture<'a, Result<GuardResult>> {
            Box::pin(async move {
                if direction == GuardDirection::Output && content == "draft answer" {
                    Ok(GuardResult::Block {
                        reason: "draft answer is stale".to_string(),
                    })
                } else {
                    Ok(GuardResult::Pass)
                }
            })
        }
    }

    impl Guard for InvalidFinalJsonGuard {
        fn name(&self) -> &str {
            "invalid-final-json"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            direction: GuardDirection,
        ) -> BoxFuture<'a, Result<GuardResult>> {
            Box::pin(async move {
                if direction == GuardDirection::Output {
                    Ok(GuardResult::Transform {
                        content: r#"{"age":"invalid"}"#.to_string(),
                        reasons: vec!["test transform".to_string()],
                    })
                } else {
                    Ok(GuardResult::Pass)
                }
            })
        }
    }

    impl Guard for CountingGuard {
        fn name(&self) -> &str {
            "counting-guard"
        }

        fn check<'a>(
            &'a self,
            _content: &'a str,
            _direction: GuardDirection,
        ) -> BoxFuture<'a, Result<GuardResult>> {
            self.calls.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            Box::pin(async { Ok(GuardResult::Pass) })
        }
    }

    #[derive(Default)]
    struct InputLifecycleProbe {
        drained: std::sync::atomic::AtomicUsize,
    }

    impl AgentInputLifecycle for InputLifecycleProbe {
        fn mark_drained(&self) {
            self.drained
                .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
        }
    }

    #[tokio::test]
    async fn prepare_context_publishes_initial_input_drain_before_provider() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().with_response("done"));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm)
            .system_prompt("system")
            .build()?;
        let probe = Arc::new(InputLifecycleProbe::default());
        let invocation = echo_core::agent::AgentInvocationContext {
            input_lifecycle: Some(probe.clone()),
            ..echo_core::agent::AgentInvocationContext::default()
        };
        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "initial input".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await?;
        let events = stream.collect::<Vec<_>>().await;
        assert!(
            events
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::FinalAnswer(_))))
        );
        assert_eq!(probe.drained.load(std::sync::atomic::Ordering::SeqCst), 1);
        Ok(())
    }

    struct AlwaysDirectClassifier;

    impl IntentClassifier for AlwaysDirectClassifier {
        fn classify<'a>(
            &'a self,
            _user_input: &'a str,
            _context: &'a [Message],
        ) -> BoxFuture<'a, Intent> {
            Box::pin(async { Intent::DirectAnswer { confidence: 1.0 } })
        }
    }

    struct RoutingProjection;

    impl PreModelContextProjector for RoutingProjection {
        fn project(
            &self,
            _context: &ProjectionContext,
        ) -> BoxFuture<'_, Result<Vec<ContextProjection>>> {
            Box::pin(async {
                Ok(vec![ContextProjection {
                    marker: "routing-test".to_string(),
                    message: Some(Message::user("required routing projection".to_string())),
                }])
            })
        }
    }

    struct BlockingRunIdProjection {
        run_ids: std::sync::Mutex<Vec<Option<String>>>,
        calls: std::sync::atomic::AtomicUsize,
        first_started: tokio::sync::Notify,
        release_first: tokio::sync::Notify,
    }

    impl BlockingRunIdProjection {
        fn new() -> Self {
            Self {
                run_ids: std::sync::Mutex::new(Vec::new()),
                calls: std::sync::atomic::AtomicUsize::new(0),
                first_started: tokio::sync::Notify::new(),
                release_first: tokio::sync::Notify::new(),
            }
        }
    }

    impl PreModelContextProjector for BlockingRunIdProjection {
        fn project<'a>(
            &'a self,
            context: &'a ProjectionContext,
        ) -> BoxFuture<'a, Result<Vec<ContextProjection>>> {
            Box::pin(async move {
                self.run_ids
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push(context.run_id.clone());
                let call = self.calls.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                if call == 0 {
                    self.first_started.notify_one();
                    self.release_first.notified().await;
                }
                Ok(Vec::new())
            })
        }
    }

    /// Build a minimal agent with a blocking input guard.
    fn agent_with_blocking_guard() -> ReactAgent {
        let mut agent = ReactAgent::new(AgentConfig::new("test-model", "agent", "sys"));
        let mut gm = echo_core::guard::GuardManager::new();
        gm.add(Arc::new(BlockingGuard));
        agent.set_guard_manager(gm);
        agent
    }

    struct BlockFinalAnswer;

    impl crate::agent::InterventionCallback for BlockFinalAnswer {
        fn on_final_answer<'a>(
            &'a self,
            _agent: &'a str,
            _answer: &'a str,
        ) -> futures::future::BoxFuture<'a, crate::agent::InterventionResult> {
            Box::pin(async { crate::agent::InterventionResult::block("review rejected output") })
        }
    }

    /// A blocked input guard preserves the unconfigured path's single terminal.
    #[tokio::test]
    async fn stream_guard_block_yields_one_failed_runtime_terminal() -> Result<()> {
        let agent = agent_with_blocking_guard();
        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "anything".into(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?;

        let events = stream
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
        assert_native_runtime_terminal(&events, echo_core::agent::ExecutionStatusKind::Failed);
        assert!(
            matches!(events.as_slice(),[AgentEvent::ExecutionStatus(started),AgentEvent::Error{source,message,failure},AgentEvent::ExecutionStatus(terminal)]
            if started.status==echo_core::agent::ExecutionStatusKind::Started && source=="input_guard"
            && message.contains("test-input-blocked") && failure.terminal_kind==crate::error::AgentTerminalKind::Failed
            && terminal.status==echo_core::agent::ExecutionStatusKind::Failed)
        );
        Ok(())
    }

    #[tokio::test]
    async fn managed_guard_block_hydrates_before_terminal_settlement() -> Result<()> {
        let conversation_root = tempfile::tempdir()?;
        let runtime_root = tempfile::tempdir()?;
        let conversations: Arc<dyn echo_core::memory::ConversationStore> = Arc::new(
            crate::memory::FileConversationStore::new(conversation_root.path())?,
        );
        let runtime = Arc::new(crate::state::FileRuntimeStateStore::new(
            runtime_root.path(),
        )?);

        let seed_config =
            AgentConfig::new("test-model", "seed", "system").conversation_id("managed-guard");
        let mut seed = ReactAgent::new(seed_config);
        seed.set_conversation_store(conversations.clone());
        seed.set_state_store(runtime.clone());
        seed.memory
            .context
            .lock()
            .await
            .push(Message::user("durable prior turn".to_string()));
        seed.force_checkpoint().await?;

        let config =
            AgentConfig::new("test-model", "guarded", "system").conversation_id("managed-guard");
        let mut agent = ReactAgent::new(config);
        let run_store = Arc::new(crate::trace::InMemoryRunStore::new());
        agent.set_run_store(run_store.clone());
        let mut guards = echo_core::guard::GuardManager::new();
        guards.add(Arc::new(BlockingGuard));
        agent.set_guard_manager(guards);
        agent.set_conversation_store(conversations);
        agent.set_state_store(runtime);

        let events = agent
            .run_stream_channel(
                StreamInit {
                    text: "blocked new input".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
        assert_native_runtime_terminal(&events, echo_core::agent::ExecutionStatusKind::Failed);
        let settlement_index=events.iter().position(|event|matches!(event,AgentEvent::TranscriptProjectionSettlement(settlement) if settlement.status==crate::memory::TranscriptProjectionSettlementStatus::Settled));
        let error_index=events.iter().position(|event|matches!(event,AgentEvent::Error{source,failure,..} if source=="input_guard"&&failure.terminal_kind==crate::error::AgentTerminalKind::Failed));
        assert!(
            settlement_index.zip(error_index).is_some_and(
                |(settled, error)| settled < error && error.saturating_add(1) < events.len()
            ),
            "水合/持久化结算先于拒绝，运行status最后：{events:?}"
        );
        let messages = agent.memory.context.lock().await.messages().to_vec();
        assert!(
            messages
                .iter()
                .any(|message| { message.text_content().as_deref() == Some("durable prior turn") })
        );
        assert!(
            messages
                .iter()
                .all(|message| { message.text_content().as_deref() != Some("blocked new input") })
        );
        let run = crate::trace::RunStore::list_all(run_store.as_ref(), 1)
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| ReactError::Other("managed guard trace missing".to_string()))?;
        let run = crate::trace::RunStore::load(run_store.as_ref(), &run.run_id)
            .await?
            .ok_or_else(|| ReactError::Other("managed guard trace payload missing".to_string()))?;
        assert_eq!(run.status, crate::trace::RunStatus::Failed);
        assert!(run.events.iter().any(|event| matches!(
            event,
            crate::trace::RunEvent::TranscriptProjectionSettlement { settlement }
                if settlement.status
                    == crate::memory::TranscriptProjectionSettlementStatus::Settled
        )));
        Ok(())
    }

    #[tokio::test]
    async fn retiring_scope_rejects_new_generation_before_admission_side_effects() -> Result<()> {
        let conversation_root = tempfile::tempdir()?;
        let runtime_root = tempfile::tempdir()?;
        let conversations = Arc::new(crate::memory::FileConversationStore::new(
            conversation_root.path(),
        )?);
        let runtime = Arc::new(crate::state::FileRuntimeStateStore::new(
            runtime_root.path(),
        )?);
        let acquired = crate::memory::ConversationStore::ensure_projection_epoch(
            conversations.as_ref(),
            crate::memory::EnsureConversationProjectionRequest {
                conversation: crate::memory::NewConversation {
                    conversation_id: "retiring-admission".to_string(),
                    user_id: "default".to_string(),
                    agent_type: None,
                    title: None,
                },
                expected_tombstone_epoch: None,
            },
        )
        .await?;
        let delete = crate::memory::ManagedConversationDelete::prepare(
            "retiring-admission",
            acquired.authority.epoch,
        )?;
        let retirement = runtime
            .begin_scope_retirement(crate::state::ScopeRetirementRequest::prepare(
                "retiring-admission",
                0,
                &delete,
            )?)
            .await?;
        assert_eq!(
            retirement.scope.lifecycle,
            crate::state::RuntimeScopeLifecycle::Retiring
        );

        let llm = Arc::new(MockLlmClient::new().with_response("must not run"));
        let guard_calls = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let config =
            AgentConfig::new("test-model", "agent", "system").conversation_id("configured-runtime");
        let mut agent = ReactAgent::new(config);
        agent.set_llm_client(llm.clone());
        let mut guards = echo_core::guard::GuardManager::new();
        guards.add(Arc::new(CountingGuard {
            calls: guard_calls.clone(),
        }));
        agent.set_guard_manager(guards);
        agent.set_conversation_store(conversations);
        agent.set_state_store(runtime.clone());
        let before = serde_json::to_value(agent.memory.context.lock().await.messages())?;
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("retiring-admission".to_string()),
                ..echo_core::tools::ExternalRunContext::default()
            }),
            runtime_state_id: Some("new-generation".to_string()),
            transcript_generation_id: Some("new-generation".to_string()),
            ..echo_core::agent::AgentInvocationContext::default()
        };

        let result = agent
            .run_stream_channel(
                StreamInit {
                    text: "must not enter".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await;
        assert!(matches!(result, Err(ReactError::RuntimeState(_))));
        assert_eq!(guard_calls.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert!(llm.last_messages().is_none());
        assert_eq!(
            serde_json::to_value(agent.memory.context.lock().await.messages())?,
            before
        );
        assert!(
            runtime
                .load_runtime_state("retiring-admission", "new-generation")
                .await?
                .is_none()
        );
        Ok(())
    }

    #[tokio::test]
    async fn deleted_conversation_without_runtime_scope_rejects_admission() -> Result<()> {
        let conversation_root = tempfile::tempdir()?;
        let runtime_root = tempfile::tempdir()?;
        let conversations = Arc::new(crate::memory::FileConversationStore::new(
            conversation_root.path(),
        )?);
        let runtime = Arc::new(crate::state::FileRuntimeStateStore::new(
            runtime_root.path(),
        )?);
        let acquired = crate::memory::ConversationStore::ensure_projection_epoch(
            conversations.as_ref(),
            crate::memory::EnsureConversationProjectionRequest {
                conversation: crate::memory::NewConversation {
                    conversation_id: "deleted-without-runtime".to_string(),
                    user_id: "default".to_string(),
                    agent_type: None,
                    title: None,
                },
                expected_tombstone_epoch: None,
            },
        )
        .await?;
        let deleted = crate::memory::ConversationStore::delete_managed_conversation(
            conversations.as_ref(),
            crate::memory::ManagedConversationDelete::prepare(
                "deleted-without-runtime",
                acquired.authority.epoch,
            )?,
        )
        .await?;
        assert_eq!(
            deleted.status,
            crate::memory::ManagedConversationDeleteStatus::Deleted
        );
        assert!(
            runtime
                .load_scope_authority("deleted-without-runtime")
                .await?
                .is_none()
        );

        let llm = Arc::new(MockLlmClient::new().with_response("must not run"));
        let guard_calls = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let config =
            AgentConfig::new("test-model", "agent", "system").conversation_id("configured-runtime");
        let mut agent = ReactAgent::new(config);
        agent.set_llm_client(llm.clone());
        let mut guards = echo_core::guard::GuardManager::new();
        guards.add(Arc::new(CountingGuard {
            calls: guard_calls.clone(),
        }));
        agent.set_guard_manager(guards);
        agent.set_conversation_store(conversations);
        agent.set_state_store(runtime);
        let before = serde_json::to_value(agent.memory.context.lock().await.messages())?;
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("deleted-without-runtime".to_string()),
                ..echo_core::tools::ExternalRunContext::default()
            }),
            runtime_state_id: Some("new-generation".to_string()),
            transcript_generation_id: Some("new-generation".to_string()),
            ..echo_core::agent::AgentInvocationContext::default()
        };

        let result = agent
            .run_stream_channel(
                StreamInit {
                    text: "must not enter".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await;
        assert!(matches!(result, Err(ReactError::RuntimeState(_))));
        assert_eq!(guard_calls.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert!(llm.last_messages().is_none());
        assert_eq!(
            serde_json::to_value(agent.memory.context.lock().await.messages())?,
            before
        );
        Ok(())
    }

    #[tokio::test]
    async fn revisioned_unbound_scope_rejects_managed_admission_before_side_effects() -> Result<()>
    {
        let conversation_root = tempfile::tempdir()?;
        let runtime_root = tempfile::tempdir()?;
        let conversations = Arc::new(crate::memory::FileConversationStore::new(
            conversation_root.path(),
        )?);
        let runtime = Arc::new(crate::state::FileRuntimeStateStore::new(
            runtime_root.path(),
        )?);
        let mut checkpoint = crate::state::AgentCheckpoint::new("unbound-generation");
        checkpoint.messages_json = crate::state::AgentCheckpoint::serialize_managed_payload(
            vec![Message::system("system".to_string())],
            None,
            None,
        )?;
        let prepared = runtime
            .compare_and_save_checkpoint(crate::state::RuntimeCheckpointCasRequest {
                managed_import: None,
                scope_id: "unbound-revision".to_string(),
                runtime_state_id: "unbound-generation".to_string(),
                conversation_epoch: None,
                expected_scope_revision: 0,
                expected_state_version: crate::state::RuntimeStateExpectedVersion::Absent,
                checkpoint,
            })
            .await?;
        assert_eq!(prepared.scope.revision, 1);
        assert!(prepared.scope.conversation_epoch.is_none());

        let llm = Arc::new(MockLlmClient::new().with_response("must not run"));
        let guard_calls = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let config =
            AgentConfig::new("test-model", "agent", "system").conversation_id("configured-runtime");
        let mut agent = ReactAgent::new(config);
        agent.set_llm_client(llm.clone());
        let mut guards = echo_core::guard::GuardManager::new();
        guards.add(Arc::new(CountingGuard {
            calls: guard_calls.clone(),
        }));
        agent.set_guard_manager(guards);
        agent.set_conversation_store(conversations);
        agent.set_state_store(runtime);
        let before = serde_json::to_value(agent.memory.context.lock().await.messages())?;
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("unbound-revision".to_string()),
                ..echo_core::tools::ExternalRunContext::default()
            }),
            runtime_state_id: Some("unbound-generation".to_string()),
            transcript_generation_id: Some("unbound-generation".to_string()),
            ..echo_core::agent::AgentInvocationContext::default()
        };

        let result = agent
            .run_stream_channel(
                StreamInit {
                    text: "must not enter".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await;
        assert!(matches!(result, Err(ReactError::RuntimeState(_))));
        assert_eq!(guard_calls.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert!(llm.last_messages().is_none());
        assert_eq!(
            serde_json::to_value(agent.memory.context.lock().await.messages())?,
            before
        );
        Ok(())
    }

    #[tokio::test]
    async fn text_final_intervention_settles_before_single_error_terminal() -> Result<()> {
        let conversation_root = tempfile::tempdir()?;
        let runtime_root = tempfile::tempdir()?;
        let conversations = Arc::new(crate::memory::FileConversationStore::new(
            conversation_root.path(),
        )?);
        let runtime = Arc::new(crate::state::FileRuntimeStateStore::new(
            runtime_root.path(),
        )?);
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new().with_response("candidate answer"),
            ))
            .system_prompt("system")
            .conversation_id("text-final-intervention")
            .conversation_store(conversations.clone())
            .state_store(runtime)
            .intervention_callback(Arc::new(BlockFinalAnswer))
            .build()?;

        let events = agent
            .run_stream_channel(
                StreamInit {
                    text: "answer this".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
        let settlement_index = events
            .iter()
            .position(|event| matches!(event, AgentEvent::TranscriptProjectionSettlement(_)));
        assert_native_runtime_terminal(&events, echo_core::agent::ExecutionStatusKind::Failed);
        let error_indices: Vec<_> = events
            .iter()
            .enumerate()
            .filter_map(|(index, event)| {
                matches!(event,AgentEvent::Error{source,..} if source=="intervention")
                    .then_some(index)
            })
            .collect();
        assert_eq!(
            error_indices.len(),
            1,
            "原干预拒绝原因须保留恰一次：{events:?}"
        );
        let error_index = error_indices
            .first()
            .copied()
            .ok_or_else(|| ReactError::Other("intervention error missing".into()))?;
        assert!(
            settlement_index.is_some_and(|index| index < error_index)
                && error_index.saturating_add(1) < events.len(),
            "结算先于Error和末status：{events:?}"
        );
        let stored = echo_core::memory::ConversationStore::get_messages(
            conversations.as_ref(),
            "text-final-intervention",
        )
        .await?;
        assert!(stored.iter().all(|message| {
            message
                .content
                .as_deref()
                .is_none_or(|content| !content.contains("candidate answer"))
        }));
        Ok(())
    }

    #[tokio::test]
    async fn invocation_guard_block_trace_uses_current_context() -> Result<()> {
        let mut agent = agent_with_blocking_guard();
        let store = Arc::new(crate::trace::InMemoryRunStore::new());
        agent.set_run_store(store.clone());
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("blocked-conversation".to_string()),
                run_id: Some("blocked-parent".to_string()),
                turn_id: Some("blocked-turn".to_string()),
                execution_id: Some("blocked-execution".to_string()),
                isolation_id: None,
                message_id: Some("blocked-message".to_string()),
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            ..Default::default()
        };

        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "blocked input".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await?;
        let _: Vec<_> = stream.collect().await;

        let traces = crate::trace::RunStore::list_all(store.as_ref(), 10).await?;
        let trace = traces
            .first()
            .ok_or_else(|| ReactError::Other("blocked trace missing".to_string()))?;
        assert_eq!(trace.parent_run_id.as_deref(), Some("blocked-parent"));
        assert_eq!(trace.session_id, "blocked-conversation");
        assert_eq!(trace.turn_id.as_deref(), Some("blocked-turn"));
        assert_eq!(trace.execution_id.as_deref(), Some("blocked-execution"));
        Ok(())
    }

    /// After a guard blocks one stream, the execution mutex must be released so
    /// the very next call can proceed. This guards against the lock-leak
    /// regression where a short-circuited branch forgets to drop the owned
    /// `execution_guard` (the agent would then deadlock forever).
    #[tokio::test]
    async fn stream_guard_block_releases_execution_mutex() -> Result<()> {
        let agent = agent_with_blocking_guard();

        // First call: blocked, must release the lock.
        let s1 = agent
            .run_stream_channel(
                StreamInit {
                    text: "first".into(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?;
        let first = s1
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
        assert_native_runtime_terminal(&first, echo_core::agent::ExecutionStatusKind::Failed);
        assert!(agent.execution_mutex.try_lock().is_ok());

        // Second call must not hang — if the lock leaked, this await never
        // completes and the test times out.
        let s2 = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            agent.run_stream_channel(
                StreamInit {
                    text: "second".into(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            ),
        )
        .await
        .map_err(|_| {
            ReactError::Other("second blocked invocation leaked execution mutex".into())
        })??;

        let events = s2
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
        assert_native_runtime_terminal(&events, echo_core::agent::ExecutionStatusKind::Failed);
        assert!(events.iter().any(|event|matches!(event,AgentEvent::Error{source,message,..} if source=="input_guard"&&message.contains("test-input-blocked"))));
        assert!(agent.execution_mutex.try_lock().is_ok());
        Ok(())
    }

    // ── End-to-end run_core_loop tests driven by MockLlmClient ─────────────
    // These exercise the shared core loop (the one ReAct loop) through the
    // public streaming entrypoint `run_stream_channel`, with a scripted mock
    // LLM. No guard / no intent router on these agents, so the stream falls
    // straight through to run_core_loop.

    use crate::agent::react::builder::ReactAgentBuilder;
    use crate::error::{LlmError, ReactError};
    use crate::llm::types::{DeltaMessage, FunctionCall, ToolCall};
    use crate::state::RuntimeStateStore;
    use crate::testing::{MockLlmClient, MockTool, StreamChunk};

    struct InvocationRewrite;

    impl crate::agent::InterventionCallback for InvocationRewrite {
        fn on_tool_call<'a>(
            &'a self,
            _agent: &'a str,
            _tool: &'a str,
            _args: &'a serde_json::Value,
        ) -> futures::future::BoxFuture<'a, crate::agent::InterventionResult> {
            Box::pin(async {
                crate::agent::InterventionResult {
                    redirect_to: Some("effective_tool".to_string()),
                    modified_args: Some(serde_json::json!({"value": "rewritten"})),
                    ..crate::agent::InterventionResult::default()
                }
            })
        }
    }

    struct CapturingArgsTool {
        name: &'static str,
        calls: Arc<std::sync::Mutex<Vec<crate::tools::ToolParameters>>>,
        permissions: Vec<echo_core::tools::permission::ToolPermission>,
    }

    impl crate::tools::Tool for CapturingArgsTool {
        fn name(&self) -> &str {
            self.name
        }

        fn description(&self) -> &str {
            "Returns the effective value and records the executed arguments"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({
                "type": "object",
                "properties": {"value": {"type": "string"}},
                "required": ["value"]
            })
        }

        fn permissions(&self) -> Vec<echo_core::tools::permission::ToolPermission> {
            self.permissions.clone()
        }

        fn execute(
            &self,
            params: crate::tools::ToolParameters,
        ) -> futures::future::BoxFuture<'_, Result<crate::tools::ToolResult>> {
            Box::pin(async move {
                self.calls
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push(params.clone());
                let value = params
                    .get("value")
                    .and_then(serde_json::Value::as_str)
                    .ok_or_else(|| ReactError::Other("effective value is missing".to_string()))?;
                Ok(crate::tools::ToolResult::success(value))
            })
        }
    }

    #[cfg(feature = "human-loop")]
    struct ModifiedArgsApproval;

    #[cfg(feature = "human-loop")]
    impl crate::human_loop::HumanLoopProvider for ModifiedArgsApproval {
        fn request(
            &self,
            _request: crate::human_loop::HumanLoopRequest,
        ) -> futures::future::BoxFuture<'_, Result<crate::human_loop::HumanLoopResponse>> {
            Box::pin(async {
                Ok(crate::human_loop::HumanLoopResponse::ModifiedArgs {
                    args: serde_json::json!({"value": "approved"}),
                    scope: crate::human_loop::ApprovalScope::Once,
                })
            })
        }
    }

    struct DelayedTerminalTool {
        started: Arc<tokio::sync::Notify>,
        completed: Arc<tokio::sync::Notify>,
        finished: Arc<std::sync::atomic::AtomicBool>,
    }

    impl crate::tools::Tool for DelayedTerminalTool {
        fn name(&self) -> &str {
            "delayed_terminal"
        }

        fn description(&self) -> &str {
            "Finishes a durable terminal write shortly after parent cancellation"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({ "type": "object", "properties": {} })
        }

        fn execute(
            &self,
            _params: crate::tools::ToolParameters,
        ) -> futures::future::BoxFuture<'_, Result<crate::tools::ToolResult>> {
            Box::pin(async move {
                self.started.notify_one();
                tokio::time::sleep(std::time::Duration::from_millis(75)).await;
                self.finished
                    .store(true, std::sync::atomic::Ordering::Release);
                self.completed.notify_one();
                Ok(crate::tools::ToolResult::success(
                    "terminal state persisted",
                ))
            })
        }
    }

    #[derive(Default)]
    struct RecordingRuntimeStateStore {
        checkpoint: std::sync::Mutex<Option<crate::state::AgentCheckpoint>>,
        scopes: std::sync::Mutex<
            std::collections::BTreeMap<String, std::collections::BTreeSet<String>>,
        >,
    }

    impl crate::state::RuntimeStateStore for RecordingRuntimeStateStore {
        fn get_checkpoint<'a>(
            &'a self,
            _conversation_id: &'a str,
        ) -> futures::future::BoxFuture<'a, Result<Option<crate::state::AgentCheckpoint>>> {
            Box::pin(async move {
                Ok(self
                    .checkpoint
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .clone())
            })
        }

        fn save_checkpoint<'a>(
            &'a self,
            checkpoint: &'a crate::state::AgentCheckpoint,
        ) -> futures::future::BoxFuture<'a, Result<()>> {
            self.save_checkpoint_for_scope(&checkpoint.conversation_id, checkpoint)
        }

        fn save_checkpoint_for_scope<'a>(
            &'a self,
            scope_id: &'a str,
            checkpoint: &'a crate::state::AgentCheckpoint,
        ) -> futures::future::BoxFuture<'a, Result<()>> {
            Box::pin(async move {
                self.scopes
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .entry(scope_id.to_string())
                    .or_default()
                    .insert(checkpoint.conversation_id.clone());
                *self
                    .checkpoint
                    .lock()
                    .unwrap_or_else(|error| error.into_inner()) = Some(checkpoint.clone());
                Ok(())
            })
        }

        fn runtime_state_ids<'a>(
            &'a self,
            scope_id: &'a str,
        ) -> futures::future::BoxFuture<'a, Result<Vec<String>>> {
            Box::pin(async move {
                Ok(self
                    .scopes
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .get(scope_id)
                    .map(|ids| ids.iter().cloned().collect())
                    .unwrap_or_default())
            })
        }

        fn clear_runtime_state<'a>(
            &'a self,
            scope_id: &'a str,
            runtime_state_id: &'a str,
        ) -> futures::future::BoxFuture<'a, Result<crate::state::RuntimeStateClearReceipt>>
        {
            Box::pin(async move {
                let mut scopes = self
                    .scopes
                    .lock()
                    .unwrap_or_else(|error| error.into_inner());
                let indexed = scopes
                    .get_mut(scope_id)
                    .is_some_and(|ids| ids.remove(runtime_state_id));
                if scopes.get(scope_id).is_some_and(|ids| ids.is_empty()) {
                    scopes.remove(scope_id);
                }
                drop(scopes);
                let mut checkpoint = self
                    .checkpoint
                    .lock()
                    .unwrap_or_else(|error| error.into_inner());
                let checkpoint_removed = checkpoint.as_ref().is_some_and(|checkpoint| {
                    checkpoint.conversation_id == runtime_state_id
                        && (indexed || scope_id == runtime_state_id)
                });
                if checkpoint_removed {
                    *checkpoint = None;
                }
                Ok(crate::state::RuntimeStateClearReceipt {
                    scope_id: scope_id.to_string(),
                    runtime_state_id: runtime_state_id.to_string(),
                    checkpoint_removed,
                })
            })
        }

        fn clear_runtime_state_scope<'a>(
            &'a self,
            scope_id: &'a str,
        ) -> futures::future::BoxFuture<'a, Result<crate::state::RuntimeStateScopeClearReceipt>>
        {
            Box::pin(async move {
                let mut runtime_state_ids = self
                    .scopes
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .remove(scope_id)
                    .map(|ids| ids.into_iter().collect::<Vec<_>>())
                    .unwrap_or_default();
                let mut checkpoint = self
                    .checkpoint
                    .lock()
                    .unwrap_or_else(|error| error.into_inner());
                if checkpoint
                    .as_ref()
                    .is_some_and(|checkpoint| checkpoint.conversation_id == scope_id)
                    && !runtime_state_ids
                        .iter()
                        .any(|runtime_id| runtime_id == scope_id)
                {
                    runtime_state_ids.push(scope_id.to_string());
                    runtime_state_ids.sort();
                }
                if checkpoint.as_ref().is_some_and(|checkpoint| {
                    runtime_state_ids
                        .iter()
                        .any(|runtime_id| runtime_id == &checkpoint.conversation_id)
                }) {
                    *checkpoint = None;
                }
                Ok(crate::state::RuntimeStateScopeClearReceipt {
                    scope_id: scope_id.to_string(),
                    runtime_state_ids,
                })
            })
        }

        fn clear_conversation<'a>(
            &'a self,
            conversation_id: &'a str,
        ) -> futures::future::BoxFuture<'a, Result<()>> {
            Box::pin(async move {
                self.clear_runtime_state(conversation_id, conversation_id)
                    .await
                    .map(|_receipt| ())
            })
        }
    }

    /// Build a streaming-capable agent backed by a scripted mock LLM, with
    /// no guard and no intent router (so requests reach run_core_loop).
    fn agent_with_mock_llm(llm: MockLlmClient) -> ReactAgent {
        ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("You are a test assistant.")
            .build()
            .expect("agent builds")
    }

    struct RejectingRunStore;

    #[async_trait::async_trait]
    impl crate::trace::RunStore for RejectingRunStore {
        async fn save(&self, _run: crate::trace::Run) -> Result<()> {
            Err(ReactError::Other(
                "injected trace persistence failure".to_string(),
            ))
        }

        async fn load(&self, _run_id: &str) -> Result<Option<crate::trace::Run>> {
            Ok(None)
        }

        async fn list_by_session(
            &self,
            _session_id: &str,
        ) -> Result<Vec<crate::trace::RunSummary>> {
            Ok(Vec::new())
        }

        async fn list_all(&self, _limit: usize) -> Result<Vec<crate::trace::RunSummary>> {
            Ok(Vec::new())
        }
    }

    struct RejectingAuditLogger;

    struct FinalSaveRejectingRunStore {
        inner: crate::trace::InMemoryRunStore,
    }

    #[async_trait::async_trait]
    impl crate::trace::RunStore for FinalSaveRejectingRunStore {
        async fn save(&self, run: crate::trace::Run) -> Result<()> {
            if !matches!(&run.status, crate::trace::RunStatus::Running) {
                return Err(ReactError::Other(
                    "injected terminal trace save failure".to_string(),
                ));
            }
            crate::trace::RunStore::save(&self.inner, run).await
        }

        async fn load(&self, run_id: &str) -> Result<Option<crate::trace::Run>> {
            crate::trace::RunStore::load(&self.inner, run_id).await
        }

        async fn list_by_session(&self, session_id: &str) -> Result<Vec<crate::trace::RunSummary>> {
            crate::trace::RunStore::list_by_session(&self.inner, session_id).await
        }

        async fn list_all(&self, limit: usize) -> Result<Vec<crate::trace::RunSummary>> {
            crate::trace::RunStore::list_all(&self.inner, limit).await
        }
    }

    impl crate::audit::AuditLogger for RejectingAuditLogger {
        fn log<'a>(&'a self, _event: crate::audit::AuditEvent) -> BoxFuture<'a, Result<()>> {
            Box::pin(async {
                Err(ReactError::Other(
                    "injected audit persistence failure".to_string(),
                ))
            })
        }

        fn query<'a>(
            &'a self,
            _filter: crate::audit::AuditFilter,
        ) -> BoxFuture<'a, Result<Vec<crate::audit::AuditEvent>>> {
            Box::pin(async { Ok(Vec::new()) })
        }
    }

    #[derive(Default)]
    struct RecordingDiagnosticObserver {
        failures: std::sync::Mutex<Vec<crate::audit::DiagnosticDeliveryFailure>>,
        changed: std::sync::Condvar,
    }

    impl crate::audit::DiagnosticDeliveryObserver for RecordingDiagnosticObserver {
        fn on_failure(&self, failure: crate::audit::DiagnosticDeliveryFailure) {
            self.failures
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .push(failure);
            self.changed.notify_all();
        }
    }

    impl RecordingDiagnosticObserver {
        fn wait_for_count(
            &self,
            count: usize,
        ) -> Result<Vec<crate::audit::DiagnosticDeliveryFailure>> {
            let failures = self
                .failures
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            let (failures, wait) = self
                .changed
                .wait_timeout_while(failures, std::time::Duration::from_secs(5), |failures| {
                    failures.len() < count
                })
                .map_err(|error| ReactError::Other(format!("observer wait failed: {error}")))?;
            if wait.timed_out() && failures.len() < count {
                return Err(ReactError::Other(format!(
                    "timed out waiting for {count} diagnostic failures"
                )));
            }
            Ok(failures.clone())
        }
    }

    struct BlockingDiagnosticObserver {
        entered: std::sync::mpsc::Sender<()>,
        release: std::sync::Mutex<std::sync::mpsc::Receiver<()>>,
    }

    impl crate::audit::DiagnosticDeliveryObserver for BlockingDiagnosticObserver {
        fn on_failure(&self, _failure: crate::audit::DiagnosticDeliveryFailure) {
            let _ = self.entered.send(());
            let _ = self
                .release
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .recv();
        }
    }

    struct DiagnosticObserverRelease(Option<std::sync::mpsc::Sender<()>>);

    impl DiagnosticObserverRelease {
        fn release(mut self) {
            if let Some(sender) = self.0.take() {
                let _ = sender.send(());
            }
        }
    }

    impl Drop for DiagnosticObserverRelease {
        fn drop(&mut self) {
            if let Some(sender) = self.0.take() {
                let _ = sender.send(());
            }
        }
    }

    fn agent_with_direct_router_and_projection(llm: Arc<MockLlmClient>) -> Result<ReactAgent> {
        let router = IntentRouter::new(
            Box::new(AlwaysDirectClassifier),
            IntentRouterConfig::default(),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm)
            .intent_router(router)
            .system_prompt("You are a test assistant.")
            .build()?;
        agent.set_pre_model_context_projector(Some(Arc::new(RoutingProjection)));
        Ok(agent)
    }

    #[tokio::test]
    async fn checkpoint_resume_trace_is_scoped_for_standalone_cold_chat_and_execute() -> Result<()>
    {
        for mode in [None, Some(StreamMode::Chat), Some(StreamMode::Execute)] {
            let root = tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
            let state = Arc::new(crate::state::FileRuntimeStateStore::new(root.path())?);
            let mut checkpoint = crate::state::AgentCheckpoint::new("current-trace-state");
            checkpoint.messages_json = crate::state::AgentCheckpoint::serialize_payload(
                vec![
                    Message::system("system".into()),
                    Message::user("historical-current-input".into()),
                ],
                None,
            )
            .map_err(|error| ReactError::Other(error.to_string()))?;
            state.save_checkpoint(&checkpoint).await?;
            let traces = Arc::new(crate::trace::InMemoryRunStore::new());
            let client = Arc::new(MockLlmClient::new().with_response("current answer"));
            let agent = ReactAgentBuilder::new()
                .llm_client(client.clone())
                .system_prompt("system")
                .conversation_id("current-trace-state")
                .state_store(state)
                .with_run_store(traces.clone())
                .build()?;
            match mode {
                Some(mode) => {
                    agent
                        .run_stream_channel(
                            StreamInit {
                                text: "current input".into(),
                                message: None,
                                label: String::new(),
                                invocation: Some(echo_core::agent::AgentInvocationContext {
                                    runtime: Some(echo_core::tools::ExternalRunContext::default()),
                                    ..Default::default()
                                }),
                            },
                            mode,
                        )
                        .await?
                        .collect::<Vec<_>>()
                        .await
                        .into_iter()
                        .collect::<Result<Vec<_>>>()?;
                    assert!(
                        client
                            .last_messages()
                            .is_some_and(|messages| messages.iter().any(|message| message
                                .text_content()
                                .is_some_and(|text| text == "historical-current-input")))
                    );
                }
                None => {
                    assert!(agent.resume_from_state_store().await?.is_some());
                }
            }
            assert!(agent.current_run_id().is_none());
            let recorded = crate::trace::RunStore::list_all(traces.as_ref(), 10).await?;
            assert_eq!(recorded.len(), 1);
            let id = &recorded
                .first()
                .ok_or_else(|| ReactError::Other("current trace missing".into()))?
                .run_id;
            let run = crate::trace::RunStore::load(traces.as_ref(), id)
                .await?
                .ok_or_else(|| ReactError::Other("current trace body missing".into()))?;
            assert_eq!(run.session_id, "current-trace-state");
            assert!(run.parent_run_id.is_none());
            assert_eq!(run.events.iter().filter(|event| matches!(event,
                crate::trace::RunEvent::CheckpointResumed { conversation_id, .. } if conversation_id == "current-trace-state"
            )).count(), 1);
            assert_eq!(run.status, crate::trace::RunStatus::Completed);
        }
        Ok(())
    }

    #[tokio::test]
    async fn anonymous_runtime_keeps_run_none_with_configured_trace_conversation() -> Result<()> {
        let mut agent = agent_with_mock_llm(MockLlmClient::new().with_response("answer"));
        agent.config.conversation_id = Some("configured-trace-conversation".into());
        let traces = Arc::new(crate::trace::InMemoryRunStore::new());
        agent.set_run_store(traces.clone());
        let projector = Arc::new(BlockingRunIdProjection::new());
        agent.set_pre_model_context_projector(Some(projector.clone()));
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                turn_id: Some("anonymous-turn".into()),
                execution_id: Some("anonymous-execution".into()),
                ..Default::default()
            }),
            ..Default::default()
        };
        let stream = agent
            .execute_stream_with_invocation_context(
                "input",
                crate::agent::CancellationToken::new(),
                invocation,
            )
            .await?;
        tokio::time::timeout(
            std::time::Duration::from_secs(2),
            projector.first_started.notified(),
        )
        .await
        .map_err(|_| ReactError::Other("anonymous projection did not start".into()))?;
        assert!(agent.current_run_id().is_none());
        let recorded = crate::trace::RunStore::list_all(traces.as_ref(), 10).await?;
        let trace = recorded
            .first()
            .ok_or_else(|| ReactError::Other("anonymous trace missing".into()))?;
        assert_eq!(trace.session_id, "configured-trace-conversation");
        assert!(trace.parent_run_id.is_none());
        assert_eq!(trace.turn_id.as_deref(), Some("anonymous-turn"));
        projector.release_first.notify_one();
        let events = stream
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
        assert!(
            events.iter().any(
                |event| matches!(event, AgentEvent::FinalAnswer(answer) if answer == "answer")
            )
        );
        assert!(agent.current_run_id().is_none());
        assert_eq!(
            projector
                .run_ids
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .as_slice(),
            &[None]
        );
        Ok(())
    }

    #[tokio::test]
    async fn queued_stream_keeps_invocation_run_contexts_atomic() -> Result<()> {
        let llm = MockLlmClient::new().with_responses(["first", "second"]);
        let agent = Arc::new(agent_with_mock_llm(llm));
        let projector = Arc::new(BlockingRunIdProjection::new());
        agent.set_pre_model_context_projector(Some(projector.clone()));
        let invocation_a = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some("run-a".to_string()),
                turn_id: None,
                execution_id: Some("execution-a".to_string()),
                isolation_id: None,
                message_id: Some("message-a".to_string()),
                cancel: None,
                trace_sink: None,
                delegation_policy: Some(echo_core::tools::NestedDelegationPolicy {
                    can_spawn_subagents: true,
                    delegate_depth: 1,
                    max_delegate_depth: 2,
                }),
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            runtime_state_id: None,
            transcript_generation_id: None,
            working_dir: Some(std::path::PathBuf::from("/tmp/worktree-a")),
            cancel: None,
            disabled_tools: None,
            allowed_tools: None,
            tool_access: None,
            visible_tools: None,
            run_budget: None,
            history: None,
            resource_guards: Vec::new(),
            input_lifecycle: None,
        };
        let first_stream = agent
            .execute_stream_with_invocation_context(
                "first",
                crate::agent::CancellationToken::new(),
                invocation_a,
            )
            .await?;
        tokio::time::timeout(
            std::time::Duration::from_secs(2),
            projector.first_started.notified(),
        )
        .await
        .map_err(|_| {
            crate::error::ReactError::Other("first projection did not start".to_string())
        })?;

        assert_eq!(agent.current_run_id().as_deref(), Some("run-a"));
        let invocation_b = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some("run-b".to_string()),
                turn_id: None,
                execution_id: Some("execution-b".to_string()),
                isolation_id: None,
                message_id: Some("message-b".to_string()),
                cancel: None,
                trace_sink: None,
                delegation_policy: Some(echo_core::tools::NestedDelegationPolicy {
                    can_spawn_subagents: true,
                    delegate_depth: 2,
                    max_delegate_depth: 3,
                }),
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            runtime_state_id: None,
            transcript_generation_id: None,
            working_dir: Some(std::path::PathBuf::from("/tmp/worktree-b")),
            cancel: None,
            disabled_tools: None,
            allowed_tools: None,
            tool_access: None,
            visible_tools: None,
            run_budget: None,
            history: None,
            resource_guards: Vec::new(),
            input_lifecycle: None,
        };
        let mut queued = Box::pin(agent.execute_stream_with_invocation_context(
            "second",
            crate::agent::CancellationToken::new(),
            invocation_b,
        ));
        tokio::select! {
            result = &mut queued => {
                return Err(crate::error::ReactError::Other(format!(
                    "queued stream unexpectedly bypassed execution mutex: {:?}",
                    result.is_ok()
                )));
            }
            _ = tokio::task::yield_now() => {}
        }
        assert_eq!(agent.current_run_id().as_deref(), Some("run-a"));
        projector.release_first.notify_one();

        let _: Vec<_> = first_stream.collect().await;
        let second_stream = queued.await?;
        let _: Vec<_> = second_stream.collect().await;
        assert!(agent.current_run_id().is_none());
        let run_ids = projector
            .run_ids
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .clone();
        assert_eq!(
            run_ids,
            vec![Some("run-a".to_string()), Some("run-b".to_string())]
        );
        Ok(())
    }

    #[tokio::test]
    async fn close_cancels_active_and_queued_turns_and_remains_retryable() -> Result<()> {
        let llm = MockLlmClient::new().with_responses(["first", "second"]);
        let agent = Arc::new(agent_with_mock_llm(llm));
        let projector = Arc::new(BlockingRunIdProjection::new());
        agent.set_pre_model_context_projector(Some(projector.clone()));

        let first_stream = agent
            .execute_stream_with_cancel("first", crate::agent::CancellationToken::new())
            .await?;
        tokio::time::timeout(
            std::time::Duration::from_secs(2),
            projector.first_started.notified(),
        )
        .await
        .map_err(|_| {
            crate::error::ReactError::Other("first projection did not start".to_string())
        })?;

        let mut queued = Box::pin(
            agent.execute_stream_with_cancel("second", crate::agent::CancellationToken::new()),
        );
        tokio::select! {
            result = &mut queued => {
                return Err(crate::error::ReactError::Other(format!(
                    "queued stream unexpectedly bypassed execution mutex: {:?}",
                    result.is_ok()
                )));
            }
            _ = tokio::task::yield_now() => {}
        }

        let close_agent = Arc::clone(&agent);
        let close_task = tokio::spawn(async move { close_agent.close().await });
        tokio::task::yield_now().await;
        if close_task.is_finished() {
            return Err(crate::error::ReactError::Other(
                "Agent close returned before active and queued turns settled".to_string(),
            ));
        }

        close_task.abort();
        let _ = close_task.await;
        projector.release_first.notify_one();

        let _: Vec<_> = first_stream.collect().await;
        let queued_result = tokio::time::timeout(std::time::Duration::from_secs(2), &mut queued)
            .await
            .map_err(|_| {
                crate::error::ReactError::Other(
                    "queued turn did not settle after close cancellation".to_string(),
                )
            })?;
        if queued_result.is_ok() {
            return Err(crate::error::ReactError::Other(
                "queued turn was admitted after Agent close began".to_string(),
            ));
        }

        agent.close().await?;
        if agent.execute("after close").await.is_ok() {
            return Err(crate::error::ReactError::Other(
                "Agent accepted a new turn after close".to_string(),
            ));
        }
        Ok(())
    }

    #[tokio::test]
    async fn abort_during_input_guard_becomes_persistent_close_debt() -> Result<()> {
        let started = Arc::new(tokio::sync::Notify::new());
        let mut agent = agent_with_mock_llm(MockLlmClient::new().with_response("unreachable"));
        let mut guards = GuardManager::new();
        guards.add(Arc::new(AwaitingGuard {
            started: started.clone(),
        }));
        agent.set_guard_manager(guards);
        let agent = Arc::new(agent);
        let run_agent = Arc::clone(&agent);
        let caller = tokio::spawn(async move {
            let stream = run_agent
                .execute_stream_with_cancel(
                    "abort during input guard",
                    crate::agent::CancellationToken::new(),
                )
                .await?;
            drop(stream);
            Result::Ok(())
        });
        tokio::time::timeout(std::time::Duration::from_secs(2), started.notified())
            .await
            .map_err(|_| {
                crate::error::ReactError::Other(
                    "input guard did not enter its awaited phase".to_string(),
                )
            })?;
        caller.abort();
        let _ = caller.await;

        for attempt in 1..=2 {
            let close_error = agent.close().await.err().ok_or_else(|| {
                crate::error::ReactError::Other(format!(
                    "Agent close attempt {attempt} ignored abandoned preparation debt"
                ))
            })?;
            assert!(
                close_error
                    .to_string()
                    .contains("without canonical settlement")
            );
        }
        Ok(())
    }

    #[test]
    fn forced_producer_abort_becomes_persistent_close_debt() -> Result<()> {
        let agent = Arc::new(agent_with_mock_llm(
            MockLlmClient::new().with_response("unreachable"),
        ));
        let projector = Arc::new(BlockingRunIdProjection::new());
        agent.set_pre_model_context_projector(Some(projector.clone()));
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|error| {
                crate::error::ReactError::Other(format!("test runtime failed: {error}"))
            })?;
        let stream = runtime.block_on(async {
            let stream = agent
                .execute_stream_with_invocation_context(
                    "abort blocked producer",
                    crate::agent::CancellationToken::new(),
                    echo_core::agent::AgentInvocationContext {
                        runtime: Some(echo_core::tools::ExternalRunContext {
                            run_id: Some("producer-original-run".to_string()),
                            turn_id: Some("distinct-producer-turn".to_string()),
                            execution_id: Some("producer-original-execution".to_string()),
                            ..Default::default()
                        }),
                        ..Default::default()
                    },
                )
                .await?;
            tokio::time::timeout(
                std::time::Duration::from_secs(2),
                projector.first_started.notified(),
            )
            .await
            .map_err(|_| {
                crate::error::ReactError::Other(
                    "blocked producer did not enter projection".to_string(),
                )
            })?;
            Result::Ok(stream)
        })?;
        // Releasing the consumer requests cancellation, but this injected
        // projector ignores it. Runtime shutdown then drops the producer.
        drop(stream);
        drop(runtime);

        let retry_runtime = tokio::runtime::Runtime::new().map_err(|error| {
            crate::error::ReactError::Other(format!("retry runtime failed: {error}"))
        })?;
        for attempt in 1..=2 {
            let close_error = retry_runtime.block_on(agent.close()).err().ok_or_else(|| {
                crate::error::ReactError::Other(format!(
                    "Agent close attempt {attempt} ignored unsettled producer debt"
                ))
            })?;
            assert!(matches!(close_error,
                ReactError::ExecutionNotSettled { run_id, execution_id }
                    if run_id == "producer-original-run"
                        && execution_id.as_deref() == Some("producer-original-execution")
            ));
        }
        Ok(())
    }

    struct ResourceGuardDropProof(Arc<std::sync::atomic::AtomicUsize>);

    impl Drop for ResourceGuardDropProof {
        fn drop(&mut self) {
            self.0.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
        }
    }

    #[tokio::test]
    async fn provider_observation_retains_original_react_admission_steering_and_execution_guard()
    -> Result<()> {
        let invocation_drops = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let runtime_drops = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let agent = agent_with_mock_llm(
            MockLlmClient::new()
                .with_delay(std::time::Duration::from_millis(50))
                .with_error(ReactError::ExecutionNotSettled {
                    run_id: "provider-original".to_string(),
                    execution_id: Some("provider-attempt".to_string()),
                }),
        );
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                turn_id: Some("observed-react-turn".to_string()),
                resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
                    ResourceGuardDropProof(runtime_drops.clone()),
                )],
                ..Default::default()
            }),
            resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
                ResourceGuardDropProof(invocation_drops.clone()),
            )],
            ..Default::default()
        };
        let stream = agent
            .execute_stream_with_invocation_context(
                "observe provider",
                crate::agent::CancellationToken::new(),
                invocation,
            )
            .await?;
        let steering = agent
            .steer_input_tracked(
                Some("observed-react-turn"),
                Message::user("do not lose this input".to_string()),
            )
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let events = stream.collect::<Vec<_>>().await;
        assert_eq!(
            invocation_drops.load(std::sync::atomic::Ordering::SeqCst),
            0
        );
        assert_eq!(runtime_drops.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert!(events.iter().any(|item|matches!(item,Err(ReactError::ExecutionNotSettled{run_id,..})if run_id=="provider-original")));
        assert!(!events.iter().any(|item| matches!(
            item,
            Ok(AgentEvent::Error { .. } | AgentEvent::Cancelled | AgentEvent::FinalAnswer(_))
        )));
        assert!(!matches!(
            steering.state(),
            crate::agent::AgentSteerState::TurnSettled { .. }
        ));
        assert!(
            agent.execution_mutex.try_lock().is_err(),
            "unknown producer still owns the original execution slot"
        );
        assert!(matches!(
            agent
                .execute_stream_with_cancel(
                    "must not start another attempt",
                    crate::agent::CancellationToken::new()
                )
                .await,
            Err(ReactError::ExecutionNotSettled { .. })
        ));
        assert_eq!(
            invocation_drops.load(std::sync::atomic::Ordering::SeqCst),
            0
        );
        assert_eq!(runtime_drops.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert!(matches!(
            agent.close().await,
            Err(ReactError::ExecutionNotSettled { .. })
        ));
        assert!(!matches!(
            steering.state(),
            crate::agent::AgentSteerState::TurnSettled { .. }
        ));
        assert_eq!(
            invocation_drops.load(std::sync::atomic::Ordering::SeqCst),
            0
        );
        assert_eq!(runtime_drops.load(std::sync::atomic::Ordering::SeqCst), 0);
        Ok(())
    }

    struct UnknownSettlementTool {
        parallel: bool,
        executions: Arc<std::sync::atomic::AtomicUsize>,
    }

    impl crate::tools::Tool for UnknownSettlementTool {
        fn name(&self) -> &str {
            "unknown_settlement"
        }
        fn description(&self) -> &str {
            "reports original physical settlement uncertainty"
        }
        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type":"object"})
        }
        fn allows_parallel_batch_execution(&self) -> bool {
            self.parallel
        }
        fn execute<'a>(
            &'a self,
            _parameters: crate::tools::ToolParameters,
        ) -> futures::future::BoxFuture<'a, Result<crate::tools::ToolResult>> {
            Box::pin(async move {
                self.executions
                    .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                Err(ReactError::ExecutionNotSettled {
                    run_id: "tool-original-run".to_string(),
                    execution_id: Some("tool-original-attempt".to_string()),
                })
            })
        }
    }

    #[derive(Default)]
    struct UnknownToolCallbacks {
        start_call_ids: std::sync::Mutex<Vec<String>>,
        starts: std::sync::atomic::AtomicUsize,
        completions: std::sync::atomic::AtomicUsize,
    }

    impl crate::agent::AgentCallback for UnknownToolCallbacks {
        fn on_tool_start_with_id<'a>(
            &'a self,
            _agent: &'a str,
            call_id: &'a str,
            _tool: &'a str,
            _args: &'a serde_json::Value,
        ) -> futures::future::BoxFuture<'a, ()> {
            Box::pin(async move {
                self.start_call_ids
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .push(call_id.to_string());
                self.starts
                    .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            })
        }
        fn on_tool_end_with_id<'a>(
            &'a self,
            _agent: &'a str,
            _call_id: &'a str,
            _tool: &'a str,
            _result: &'a str,
        ) -> futures::future::BoxFuture<'a, ()> {
            Box::pin(async {
                self.completions
                    .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            })
        }
        fn on_tool_error_with_id<'a>(
            &'a self,
            _agent: &'a str,
            _call_id: &'a str,
            _tool: &'a str,
            _error: &'a ReactError,
        ) -> futures::future::BoxFuture<'a, ()> {
            Box::pin(async {
                self.completions
                    .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            })
        }
    }

    #[tokio::test]
    async fn actual_tool_observation_has_no_result_completion_or_model_continuation() -> Result<()>
    {
        use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};
        use crate::trace::{RunEvent, RunStore};
        use std::sync::atomic::{AtomicUsize, Ordering};
        for parallel in [true, false] {
            let executions = Arc::new(AtomicUsize::new(0));
            let hooks = Arc::new(AtomicUsize::new(0));
            let callbacks = Arc::new(UnknownToolCallbacks::default());
            let invocation_drops = Arc::new(AtomicUsize::new(0));
            let runtime_drops = Arc::new(AtomicUsize::new(0));
            let traces = Arc::new(crate::trace::InMemoryRunStore::new());
            let llm = Arc::new(
                MockLlmClient::new()
                    .then_tool_call("unknown-tool-call", "unknown_settlement", "{}")
                    .with_response("must not continue"),
            );
            let agent = ReactAgentBuilder::new()
                .llm_client(llm.clone())
                .system_prompt("Execute the requested tool.")
                .callback(callbacks.clone())
                .with_run_store(traces.clone())
                .tool_execution(crate::tools::ToolExecutionConfig {
                    retry_on_fail: false,
                    ..Default::default()
                })
                .tool(Box::new(UnknownSettlementTool {
                    parallel,
                    executions: executions.clone(),
                }))
                .build()?;
            {
                let mut registry = agent.tools.hook_registry.write().await;
                let count = hooks.clone();
                registry.set_subagent_executor(Arc::new(move |_name, _task| {
                    let count = count.clone();
                    Box::pin(async move {
                        count.fetch_add(1, Ordering::SeqCst);
                        Ok("completion hook ran".to_string())
                    })
                }));
                let mut definition = HooksDefinition::default();
                for event in [HookEvent::PostToolUse, HookEvent::PostToolUseFailure] {
                    definition.add_rules(
                        event,
                        vec![HookRule {
                            matcher: "unknown_settlement".to_string(),
                            hooks: vec![HookAction::Subagent {
                                name: "unknown-completion-probe".to_string(),
                                task: None,
                                timeout: 0,
                            }],
                        }],
                    );
                }
                registry.register_user_hooks(definition);
            }
            let invocation = echo_core::agent::AgentInvocationContext {
                runtime: Some(echo_core::tools::ExternalRunContext {
                    turn_id: Some("tool-original-turn".to_string()),
                    resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
                        ResourceGuardDropProof(runtime_drops.clone()),
                    )],
                    ..Default::default()
                }),
                resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
                    ResourceGuardDropProof(invocation_drops.clone()),
                )],
                ..Default::default()
            };
            let events = agent
                .execute_stream_with_invocation_context(
                    "invoke tool",
                    crate::agent::CancellationToken::new(),
                    invocation,
                )
                .await?
                .collect::<Vec<_>>()
                .await;
            assert_eq!(executions.load(Ordering::SeqCst), 1);
            assert_eq!(callbacks.starts.load(Ordering::SeqCst), 1);
            assert_eq!(
                callbacks
                    .start_call_ids
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .as_slice(),
                &["unknown-tool-call".to_string()]
            );
            assert_eq!(callbacks.completions.load(Ordering::SeqCst), 0);
            assert_eq!(hooks.load(Ordering::SeqCst), 0);
            assert_eq!(llm.call_count(), 1);
            assert!(events.iter().any(|event| matches!(event, Ok(AgentEvent::ToolCall { call_id, .. }) if call_id == "unknown-tool-call")));
            assert!(events.iter().any(|event| matches!(event, Err(ReactError::ExecutionNotSettled { run_id, execution_id })
                if run_id == "tool-original-run" && execution_id.as_deref() == Some("tool-original-attempt"))));
            assert!(!events.iter().any(|event| matches!(
                event,
                Ok(AgentEvent::ToolResult { .. }
                    | AgentEvent::Error { .. }
                    | AgentEvent::Cancelled
                    | AgentEvent::FinalAnswer(_))
            )));
            assert!(
                !agent
                    .get_messages()
                    .await
                    .iter()
                    .any(|message| message.role == crate::llm::types::Role::Tool)
            );
            let runs = traces.list_all(8).await?;
            assert!(!runs.is_empty());
            for summary in runs {
                let run = traces
                    .load(&summary.run_id)
                    .await?
                    .ok_or_else(|| ReactError::Other("tool trace missing".to_string()))?;
                assert!(!run.events.iter().any(|event| matches!(
                    event,
                    RunEvent::ToolResult { .. } | RunEvent::ToolError { .. }
                )));
            }
            assert_eq!(invocation_drops.load(Ordering::SeqCst), 0);
            assert_eq!(runtime_drops.load(Ordering::SeqCst), 0);
            assert!(matches!(
                agent
                    .execute_stream_with_cancel(
                        "no replacement",
                        crate::agent::CancellationToken::new()
                    )
                    .await,
                Err(ReactError::ExecutionNotSettled { .. })
            ));
            assert!(matches!(
                agent.close().await,
                Err(ReactError::ExecutionNotSettled { .. })
            ));
            assert_eq!(llm.call_count(), 1);
            assert_eq!(invocation_drops.load(Ordering::SeqCst), 0);
            assert_eq!(runtime_drops.load(Ordering::SeqCst), 0);
        }
        Ok(())
    }

    #[tokio::test]
    async fn provider_failure_settles_close_lease_and_close_is_idempotent() -> Result<()> {
        let invocation_drops = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let runtime_drops = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let agent = agent_with_mock_llm(MockLlmClient::new().with_error(
            crate::error::ReactError::Other("injected provider failure".to_string()),
        ));
        let events = agent
            .execute_stream_with_invocation_context(
                "provider failure",
                crate::agent::CancellationToken::new(),
                echo_core::agent::AgentInvocationContext {
                    runtime: Some(echo_core::tools::ExternalRunContext {
                        resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
                            ResourceGuardDropProof(runtime_drops.clone()),
                        )],
                        ..Default::default()
                    }),
                    resource_guards: vec![echo_core::tools::InvocationResourceGuard::new(
                        ResourceGuardDropProof(invocation_drops.clone()),
                    )],
                    ..Default::default()
                },
            )
            .await?
            .collect::<Vec<_>>()
            .await;
        assert!(events.iter().any(|event| {
            matches!(event, Ok(AgentEvent::Error { message, .. }) if message.contains("injected provider failure"))
        }));

        agent.close().await?;
        agent.close().await?;
        assert_eq!(
            invocation_drops.load(std::sync::atomic::Ordering::SeqCst),
            1
        );
        assert_eq!(runtime_drops.load(std::sync::atomic::Ordering::SeqCst), 1);
        Ok(())
    }

    #[tokio::test]
    async fn value_scoped_stream_does_not_mutate_agent_run_id() -> Result<()> {
        let mut agent = agent_with_mock_llm(MockLlmClient::new().with_response("done"));
        agent.set_run_store(Arc::new(crate::trace::InMemoryRunStore::new()));
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some("value-run".to_string()),
                turn_id: None,
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            runtime_state_id: None,
            transcript_generation_id: None,
            working_dir: None,
            cancel: None,
            disabled_tools: None,
            allowed_tools: None,
            tool_access: None,
            visible_tools: None,
            run_budget: None,
            history: None,
            resource_guards: Vec::new(),
            input_lifecycle: None,
        };

        let stream = agent
            .execute_stream_with_invocation_context(
                "run",
                crate::agent::CancellationToken::new(),
                invocation,
            )
            .await?;
        let _: Vec<_> = stream.collect().await;
        assert!(agent.current_run_id().is_none());
        Ok(())
    }

    #[tokio::test]
    async fn value_scoped_direct_answer_records_usage_in_child_trace() -> Result<()> {
        use crate::trace::RunStore;

        let usage = crate::llm::types::Usage {
            prompt_tokens: Some(500),
            completion_tokens: Some(40),
            total_tokens: Some(540),
            prompt_tokens_details: Some(crate::llm::types::TokenUsageDetails {
                cached_tokens: Some(400),
                ..Default::default()
            }),
            ..Default::default()
        };
        let router = IntentRouter::new(
            Box::new(AlwaysDirectClassifier),
            IntentRouterConfig::default(),
        );
        let mut agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new().with_response_usage("done", usage),
            ))
            .intent_router(router)
            .system_prompt("You are a test assistant.")
            .build()?;
        let store = Arc::new(crate::trace::InMemoryRunStore::new());
        agent.set_run_store(store.clone());
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some("value-direct-run".to_string()),
                turn_id: None,
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            runtime_state_id: None,
            transcript_generation_id: None,
            working_dir: None,
            cancel: None,
            disabled_tools: None,
            allowed_tools: None,
            tool_access: None,
            visible_tools: None,
            run_budget: None,
            history: None,
            resource_guards: Vec::new(),
            input_lifecycle: None,
        };

        let stream = agent
            .execute_stream_with_invocation_context(
                "run",
                crate::agent::CancellationToken::new(),
                invocation,
            )
            .await?;
        let _: Vec<_> = stream.collect().await;
        let child = store
            .list_by_parent_run("value-direct-run")
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| crate::error::ReactError::Other("child trace missing".into()))?;
        assert_ne!(child.run_id, "value-direct-run");
        assert_eq!(child.parent_run_id.as_deref(), Some("value-direct-run"));
        let run = store
            .load(&child.run_id)
            .await?
            .ok_or_else(|| crate::error::ReactError::Other("child trace run missing".into()))?;
        assert!(run.events.iter().any(|event| matches!(
            event,
            crate::trace::RunEvent::LlmCall {
                prompt_tokens: 500,
                cached_prompt_tokens: 400,
                usage_reported: true,
                ..
            }
        )));
        assert!(agent.current_run_id().is_none());
        Ok(())
    }

    #[tokio::test]
    async fn non_streaming_direct_answer_routes_through_projection_boundary() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().with_response("normal loop answer"));
        let agent = agent_with_direct_router_and_projection(llm.clone())?;

        let _ = agent.run_chat_direct("hello").await?;

        let messages = llm.last_messages().unwrap_or_default();
        assert!(messages.iter().any(|message| {
            message
                .content
                .as_text()
                .is_some_and(|text| text.contains("required routing projection"))
        }));
        Ok(())
    }

    #[tokio::test]
    async fn streaming_direct_answer_routes_through_projection_boundary() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().with_response("normal loop answer"));
        let agent = agent_with_direct_router_and_projection(llm.clone())?;

        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "hello".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?;
        let _: Vec<_> = stream.collect().await;

        let messages = llm.last_messages().unwrap_or_default();
        assert!(messages.iter().any(|message| {
            message
                .content
                .as_text()
                .is_some_and(|text| text.contains("required routing projection"))
        }));
        Ok(())
    }

    #[tokio::test]
    async fn sequential_execute_stream_calls_reset_prior_task_messages() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new()
                .with_response("first answer")
                .with_response("second answer"),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("You are a test assistant.")
            .build()?;

        let first = agent
            .execute_stream_with_cancel("first task", crate::agent::CancellationToken::new())
            .await?;
        let _: Vec<_> = first.collect().await;
        let second = agent
            .execute_stream_with_cancel("second task", crate::agent::CancellationToken::new())
            .await?;
        let _: Vec<_> = second.collect().await;

        let calls = llm.all_calls();
        let second_messages = calls.get(1).ok_or_else(|| {
            crate::error::ReactError::Other("missing second LLM call".to_string())
        })?;
        assert!(second_messages.iter().any(|message| {
            message
                .content
                .as_text()
                .is_some_and(|text| text.contains("second task"))
        }));
        assert!(second_messages.iter().all(|message| {
            message
                .content
                .as_text()
                .is_none_or(|text| !text.contains("first task"))
        }));
        Ok(())
    }

    #[tokio::test]
    async fn sequential_structured_chat_calls_preserve_prior_turn_messages() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new()
                .with_response("first answer")
                .with_response("second answer"),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("You are a test assistant.")
            .build()?;

        let first = agent
            .chat_stream_message_with_invocation_context(
                Message::user("first question".to_string()),
                crate::agent::CancellationToken::new(),
                echo_core::agent::AgentInvocationContext::default(),
            )
            .await?;
        let _: Vec<_> = first.collect().await;
        let second = agent
            .chat_stream_message_with_invocation_context(
                Message::user("second question".to_string()),
                crate::agent::CancellationToken::new(),
                echo_core::agent::AgentInvocationContext::default(),
            )
            .await?;
        let _: Vec<_> = second.collect().await;

        let calls = llm.all_calls();
        let second_messages = calls.get(1).ok_or_else(|| {
            crate::error::ReactError::Other("missing second LLM call".to_string())
        })?;
        for expected in ["first question", "first answer", "second question"] {
            assert!(second_messages.iter().any(|message| {
                message
                    .content
                    .as_text()
                    .is_some_and(|text| text.contains(expected))
            }));
        }
        Ok(())
    }

    /// Collect the AgentEvents emitted by one streaming turn.
    async fn collect_events(agent: &ReactAgent, text: &str) -> Vec<AgentEvent> {
        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: text.into(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await
            .expect("stream starts");
        let results: Vec<_> = stream.collect().await;
        results
            .into_iter()
            .map(|r| r.expect("event is Ok"))
            .collect()
    }

    async fn collect_events_result(agent: &ReactAgent, text: &str) -> Result<Vec<AgentEvent>> {
        let mut stream = agent
            .run_stream_channel(
                StreamInit {
                    text: text.into(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?;
        let mut events = Vec::new();
        while let Some(event) = stream.next().await {
            events.push(event?);
        }
        Ok(events)
    }

    #[tokio::test]
    async fn q_flt_v09_effective_rewrite_is_the_only_executed_invocation() -> Result<()> {
        let calls = Arc::new(std::sync::Mutex::new(Vec::new()));
        let llm = MockLlmClient::new()
            .then_tool_call("rewrite-1", "requested_tool", r#"{"value":"requested"}"#)
            .with_response("done");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("Use the requested tool.")
            .tool(Box::new(
                MockTool::new("requested_tool").with_response("wrong tool"),
            ))
            .tool(Box::new(CapturingArgsTool {
                name: "effective_tool",
                calls: calls.clone(),
                permissions: Vec::new(),
            }))
            .intervention_callback(Arc::new(InvocationRewrite))
            .build()?;

        let events = collect_events_result(&agent, "rewrite the call").await?;
        let invocation = events
            .iter()
            .find_map(|event| match event {
                AgentEvent::ToolCall {
                    call_id,
                    invocation,
                } if call_id == "rewrite-1" => Some(invocation),
                _ => None,
            })
            .ok_or_else(|| ReactError::Other("canonical ToolCall was not emitted".to_string()))?;
        assert_eq!(invocation.requested_name, "requested_tool");
        assert_eq!(
            invocation.requested_args,
            serde_json::json!({"value": "requested"})
        );
        assert_eq!(invocation.name, "effective_tool");
        assert_eq!(invocation.args, serde_json::json!({"value": "rewritten"}));
        assert_eq!(
            invocation.rewrites,
            vec![
                crate::agent::ToolInvocationRewrite::InterventionRedirect,
                crate::agent::ToolInvocationRewrite::InterventionArguments,
            ]
        );
        let terminal = events
            .iter()
            .find_map(|event| match event {
                AgentEvent::ToolResult {
                    call_id,
                    name,
                    result,
                } if call_id == "rewrite-1" => Some((name, result)),
                _ => None,
            })
            .ok_or_else(|| ReactError::Other("typed ToolResult was not emitted".to_string()))?;
        assert_eq!(terminal.0, "effective_tool");
        assert_eq!(terminal.1.output, "rewritten");
        let executed = calls.lock().unwrap_or_else(|error| error.into_inner());
        assert_eq!(executed.len(), 1);
        assert_eq!(
            executed
                .first()
                .and_then(|params| params.get("value"))
                .and_then(serde_json::Value::as_str),
            Some("rewritten")
        );
        Ok(())
    }

    #[cfg(feature = "human-loop")]
    #[tokio::test]
    async fn react_emits_and_executes_approval_modified_arguments() -> Result<()> {
        let calls = Arc::new(std::sync::Mutex::new(Vec::new()));
        let service = Arc::new(crate::human_loop::PermissionService::from_provider(
            Arc::new(ModifiedArgsApproval),
        ));
        let llm = MockLlmClient::new()
            .then_tool_call("approval-1", "approval_tool", r#"{"value":"requested"}"#)
            .with_response("done");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("Use the approval tool.")
            .enable_human_in_loop()
            .permission_service(service)
            .tool(Box::new(CapturingArgsTool {
                name: "approval_tool",
                calls: calls.clone(),
                permissions: vec![echo_core::tools::permission::ToolPermission::Write],
            }))
            .build()?;

        let events = collect_events_result(&agent, "run the approved call").await?;
        let invocation = events
            .iter()
            .find_map(|event| match event {
                AgentEvent::ToolCall {
                    call_id,
                    invocation,
                } if call_id == "approval-1" => Some(invocation),
                _ => None,
            })
            .ok_or_else(|| ReactError::Other("approval ToolCall was not emitted".to_string()))?;
        assert_eq!(
            invocation.requested_args,
            serde_json::json!({"value": "requested"})
        );
        assert_eq!(invocation.args, serde_json::json!({"value": "approved"}));
        assert_eq!(
            invocation.rewrites,
            vec![crate::agent::ToolInvocationRewrite::Approval]
        );
        let result = events
            .iter()
            .find_map(|event| match event {
                AgentEvent::ToolResult {
                    call_id, result, ..
                } if call_id == "approval-1" => Some(result),
                _ => None,
            })
            .ok_or_else(|| ReactError::Other("approval ToolResult was not emitted".to_string()))?;
        assert_eq!(result.output, "approved");
        let executed = calls.lock().unwrap_or_else(|error| error.into_inner());
        assert_eq!(
            executed
                .first()
                .and_then(|params| params.get("value"))
                .and_then(serde_json::Value::as_str),
            Some("approved")
        );
        Ok(())
    }

    async fn assert_spilled_tool_result(
        agent: &ReactAgent,
        call_id: &str,
        marker_key: &str,
        marker_value: &str,
        original: &str,
    ) -> Result<()> {
        let events = collect_events_result(agent, "produce a large result").await?;
        assert!(events.iter().all(|event| {
            !matches!(
                event,
                AgentEvent::ToolStream {
                    event: crate::tools::ToolStreamEvent::Complete(_),
                    ..
                }
            )
        }));
        let result = events
            .iter()
            .find_map(|event| match event {
                AgentEvent::ToolResult {
                    call_id: current,
                    result,
                    ..
                } if current == call_id => Some(result),
                _ => None,
            })
            .ok_or_else(|| ReactError::Other("spilled ToolResult was not emitted".to_string()))?;
        assert!(result.success);
        assert!(result.truncated);
        assert_eq!(
            result.metadata.get(marker_key).map(String::as_str),
            Some(marker_value)
        );
        assert_eq!(
            result.metadata.get("output_handling").map(String::as_str),
            Some("spilled")
        );
        let artifact = result.artifact.as_ref().ok_or_else(|| {
            ReactError::Other("ToolResult lost its artifact reference".to_string())
        })?;
        let recovered = std::fs::read_to_string(&artifact.path)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(recovered, original);
        Ok(())
    }

    #[tokio::test]
    async fn q_flt_v03_huge_output_spills_to_digest_bound_artifact() -> Result<()> {
        let artifact_dir =
            tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let original = format!("{}END", "non-stream 中文🙂\n".repeat(2_000));
        let llm = MockLlmClient::new()
            .then_tool_call("non-stream-1", "large_non_stream", "{}")
            .with_response("done");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("Use the large output tool.")
            .tool_output_artifacts(
                echo_core::tools::artifact::ToolOutputArtifactConfig::new(
                    artifact_dir.path(),
                    "test",
                )
                .threshold_bytes(8),
            )
            .tool(Box::new(
                MockTool::new("large_non_stream").with_result(
                    crate::tools::ToolResult::success(original.clone())
                        .with_meta("transport", "non_stream"),
                ),
            ))
            .build()?;

        assert_spilled_tool_result(&agent, "non-stream-1", "transport", "non_stream", &original)
            .await
    }

    #[tokio::test]
    async fn react_streaming_tool_preserves_rich_spilled_terminal() -> Result<()> {
        let artifact_dir =
            tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let original = format!("{}END", "stream 中文🙂\n".repeat(2_000));
        let llm = MockLlmClient::new()
            .then_tool_call("stream-1", "large_stream", "{}")
            .with_response("done");
        let stream_result =
            crate::tools::ToolResult::success(original.clone()).with_meta("transport", "stream");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("Use the streaming output tool.")
            .tool_output_artifacts(
                echo_core::tools::artifact::ToolOutputArtifactConfig::new(
                    artifact_dir.path(),
                    "test",
                )
                .threshold_bytes(8),
            )
            .tool(Box::new(MockTool::new("large_stream").with_stream_script(
                vec![
                    crate::tools::ToolStreamEvent::Output {
                        channel: crate::tools::ToolOutputChannel::Stdout,
                        chunk: "partial".to_string(),
                    },
                    crate::tools::ToolStreamEvent::Complete(stream_result),
                ],
            )))
            .build()?;

        assert_spilled_tool_result(&agent, "stream-1", "transport", "stream", &original).await
    }

    #[tokio::test]
    async fn activate_skill_tool_replaces_protected_projection_across_compression() -> Result<()> {
        let root = tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let skill_dir = root.path().join("replaceable-skill");
        std::fs::create_dir_all(&skill_dir)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        std::fs::write(
            skill_dir.join("SKILL.md"),
            "---\nname: replaceable-skill\ndescription: Replaceable instructions\n---\nActivation argument: ${ARGUMENTS}\n",
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;

        let llm = MockLlmClient::new()
            .then_tool_call(
                "activate-first",
                "activate_skill",
                r#"{"name":"replaceable-skill","arguments":"first"}"#,
            )
            .then_tool_call(
                "activate-second",
                "activate_skill",
                r#"{"name":"replaceable-skill","arguments":"second"}"#,
            )
            .with_response("done");
        let mut agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("Activate the requested skill.")
            .build()?;
        agent
            .discover_skills(&[crate::skills::external::DiscoveryScope::Custom(
                root.path().to_path_buf(),
            )])
            .await?;

        let events = collect_events_result(&agent, "activate and refresh the skill").await?;
        let activations = events
            .iter()
            .filter(|event| {
                matches!(
                    event,
                    AgentEvent::ToolResult {
                        result: crate::tools::ToolResult {
                            kind: echo_core::tools::ToolResultKind::SkillActivation { name },
                            ..
                        },
                        ..
                    } if name == "replaceable-skill"
                )
            })
            .count();
        assert_eq!(activations, 2);

        let compressor = crate::compression::compressor::SlidingWindowCompressor::new(1);
        agent.force_compress_with(&compressor).await?;
        let messages = agent.memory.context.lock().await.messages().to_vec();
        let projections = messages
            .iter()
            .filter_map(|message| message.content.as_text_ref())
            .filter(|text| text.contains("echo-agent:skill:replaceable-skill"))
            .collect::<Vec<_>>();
        assert_eq!(projections.len(), 1);
        assert!(projections.first().is_some_and(|text| {
            text.contains("Activation argument: second")
                && !text.contains("Activation argument: first")
        }));
        Ok(())
    }

    /// 普通正文经原ReAct校验后发布canonical AssistantMessage及唯一FinalAnswer，
    /// 原owner结算后以唯一ExecutionStatus结束；不再附加Token副本。
    #[tokio::test]
    async fn run_core_loop_text_only_yields_final_answer() -> Result<()> {
        let llm = MockLlmClient::new().with_response("Paris is the capital of France.");
        let agent = agent_with_mock_llm(llm);

        let events = collect_events(&agent, "What is the capital of France?").await;

        assert!(
            matches!(last_confirmed_final(&events),Some(AgentEvent::FinalAnswer(text)) if text.contains("Paris"))
        );
        Ok(())
    }

    #[tokio::test]
    async fn diagnostic_persistence_failures_do_not_replace_producer_final_answer() -> Result<()> {
        let observer = Arc::new(RecordingDiagnosticObserver::default());
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new().with_response("producer answer"),
            ))
            .system_prompt("You are a test assistant.")
            .with_run_store(Arc::new(RejectingRunStore))
            .audit_logger(Arc::new(RejectingAuditLogger))
            .diagnostic_delivery_observer(observer.clone())
            .build()?;

        let events = collect_events_result(&agent, "input").await?;

        assert!(events.iter().any(
            |event| matches!(event, AgentEvent::FinalAnswer(answer) if answer == "producer answer")
        ));
        let failures = observer.wait_for_count(2)?;
        assert!(failures.iter().any(|failure| {
            failure.record_kind == crate::audit::DiagnosticRecordKind::Trace
                && failure.operation == crate::audit::DiagnosticDeliveryOperation::Start
        }));
        assert!(failures.iter().any(|failure| {
            failure.record_kind == crate::audit::DiagnosticRecordKind::Audit
                && failure.operation == crate::audit::DiagnosticDeliveryOperation::Record
        }));
        Ok(())
    }

    #[tokio::test]
    async fn final_trace_save_failure_does_not_replace_stream_final_answer() -> Result<()> {
        let observer = Arc::new(RecordingDiagnosticObserver::default());
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new().with_response("producer answer"),
            ))
            .system_prompt("You are a test assistant.")
            .with_run_store(Arc::new(FinalSaveRejectingRunStore {
                inner: crate::trace::InMemoryRunStore::new(),
            }))
            .diagnostic_delivery_observer(observer.clone())
            .build()?;

        let events = collect_events_result(&agent, "input").await?;
        assert!(
            matches!(last_confirmed_final(&events), Some(AgentEvent::FinalAnswer(answer)) if answer == "producer answer")
        );
        let failures = observer.wait_for_count(1)?;
        assert_eq!(failures.len(), 1);
        let failure = failures
            .first()
            .ok_or_else(|| ReactError::Other("missing final-save failure".to_string()))?;
        assert_eq!(
            failure.record_kind,
            crate::audit::DiagnosticRecordKind::Trace
        );
        assert_eq!(
            failure.operation,
            crate::audit::DiagnosticDeliveryOperation::Finalize
        );
        assert!(failure.record_id.is_some());
        assert!(
            failure
                .error
                .contains("injected terminal trace save failure")
        );
        Ok(())
    }

    #[tokio::test]
    async fn blocking_diagnostic_observer_does_not_delay_final_answer() -> Result<()> {
        let (entered, observer_entered) = std::sync::mpsc::channel();
        let (release, observer_release) = std::sync::mpsc::channel();
        let release_guard = DiagnosticObserverRelease(Some(release));
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new().with_response("producer answer"),
            ))
            .system_prompt("You are a test assistant.")
            .with_run_store(Arc::new(RejectingRunStore))
            .diagnostic_delivery_observer(Arc::new(BlockingDiagnosticObserver {
                entered,
                release: std::sync::Mutex::new(observer_release),
            }))
            .build()?;

        let events = tokio::time::timeout(
            std::time::Duration::from_secs(5),
            collect_events_result(&agent, "input"),
        )
        .await
        .map_err(|_| {
            ReactError::Other("producer was blocked by diagnostic observer".to_string())
        })??;
        observer_entered
            .recv_timeout(std::time::Duration::from_secs(5))
            .map_err(|error| ReactError::Other(format!("observer did not start: {error}")))?;
        assert!(events.iter().any(
            |event| matches!(event, AgentEvent::FinalAnswer(answer) if answer == "producer answer")
        ));
        release_guard.release();
        Ok(())
    }

    /// A full ReAct cycle: the mock LLM first requests a tool call, the tool
    /// returns a scripted result, then the LLM produces a final text answer.
    /// Guards the core-loop tool-call branch (think → tools → think → finalize).
    #[tokio::test]
    async fn run_core_loop_tool_call_cycle_completes() -> Result<()> {
        // The mock tool returns a fixed result; the LLM script is:
        //   1. request tool_call "mock_calc" with args {"x": 6, "y": 7}
        //   2. after seeing the tool result, emit a final text answer.
        let llm = MockLlmClient::new()
            .then_tool_call("call_1", "mock_calc", r#"{"x":6,"y":7}"#)
            .with_response("The result is 42.");

        let tool = MockTool::new("mock_calc").with_response("42");

        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("You are a test assistant. Use tools when asked.")
            .tool(Box::new(tool))
            .build()?;

        let events = collect_events(&agent, "What is 6 times 7?").await;

        assert!(
            matches!(last_confirmed_final(&events),Some(AgentEvent::FinalAnswer(text)) if text.contains("42"))
        );
        let call = events.iter().position(
            |event| matches!(event,AgentEvent::ToolCall{call_id,..} if call_id=="call_1"),
        );
        let result=events.iter().position(|event|matches!(event,AgentEvent::ToolResult{call_id,result,..} if call_id=="call_1"&&result.success&&result.output=="42"));
        let final_position = events
            .iter()
            .position(|event| matches!(event, AgentEvent::FinalAnswer(_)));
        assert!(call.zip(result).is_some_and(|(call, result)| call < result));
        assert!(
            result
                .zip(final_position)
                .is_some_and(|(result, answer)| result < answer)
        );
        Ok(())
    }

    #[tokio::test]
    async fn deepseek_tool_turn_replays_complete_assistant_message() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new()
                .then_reasoning_tool_call(
                    "call_1",
                    "mock_calc",
                    r#"{"x":6,"y":7}"#,
                    "I will calculate that.",
                    "The user requested a multiplication, so I should use the calculator.",
                )
                .with_response("The result is 42."),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("You are a test assistant. Use tools when asked.")
            .tool(Box::new(MockTool::new("mock_calc").with_response("42")))
            .build()?;

        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "What is 6 times 7?".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?;
        let _events = stream
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;

        let calls = llm.all_calls();
        let second_request = calls.get(1).ok_or_else(|| {
            crate::error::ReactError::Other(
                "DeepSeek tool cycle did not issue a second request".to_string(),
            )
        })?;
        let assistant = second_request
            .iter()
            .find(|message| message.role == crate::llm::types::Role::Assistant)
            .ok_or_else(|| {
                crate::error::ReactError::Other(
                    "second DeepSeek request did not replay the assistant tool turn".to_string(),
                )
            })?;

        assert_eq!(
            assistant.reasoning_content.as_deref(),
            Some("The user requested a multiplication, so I should use the calculator.")
        );
        assert_eq!(
            assistant.content.as_text().as_deref(),
            Some("I will calculate that.")
        );
        assert_eq!(
            assistant.tool_calls.as_ref().map(Vec::len),
            Some(1),
            "the replayed assistant message must retain its tool call"
        );
        Ok(())
    }

    #[tokio::test]
    async fn q_flt_v01_malformed_tool_json_has_no_phantom_execution() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new()
                .then_reasoning_tool_call(
                    "call_1",
                    "mock_calc",
                    r#"{"x":6"#,
                    "",
                    "I should call the calculator, but the arguments were truncated.",
                )
                .with_response("I will retry with a complete call next time."),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("You are a test assistant. Use tools when asked.")
            .tool(Box::new(MockTool::new("mock_calc").with_response("42")))
            .build()?;

        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "What is 6 times 7?".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?;
        let _events = stream
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;

        let calls = llm.all_calls();
        let second_request = calls.get(1).ok_or_else(|| {
            crate::error::ReactError::Other(
                "malformed DeepSeek tool turn did not reach its retry request".to_string(),
            )
        })?;
        let assistant = second_request
            .iter()
            .find(|message| message.role == crate::llm::types::Role::Assistant)
            .ok_or_else(|| {
                crate::error::ReactError::Other(
                    "retry request did not contain the recovered assistant turn".to_string(),
                )
            })?;

        assert_eq!(
            assistant.reasoning_content.as_deref(),
            Some("I should call the calculator, but the arguments were truncated.")
        );
        assert!(assistant.tool_calls.is_none());
        assert!(
            assistant.content.as_text().is_some_and(|content| {
                content.contains("流式工具调用参数解析失败")
            })
        );
        Ok(())
    }

    #[tokio::test]
    async fn q_flt_v08_completed_batch_effects_are_checkpointed_before_progress() -> Result<()> {
        let store = Arc::new(RecordingRuntimeStateStore::default());
        let llm = MockLlmClient::new()
            .then_tool_call("write-1", "mock_write", r#"{"path":"结果-🧪.md"}"#)
            .with_response("done");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .tool(Box::new(
                MockTool::new("mock_write").with_response("written"),
            ))
            .conversation_id("resume-conversation")
            .state_store(store.clone())
            .build()?;

        let mut stream = agent.execute_stream("write it").await?;
        while let Some(event) = stream.next().await {
            if matches!(event?, AgentEvent::ToolBatchEnd) {
                break;
            }
        }
        drop(stream);

        let checkpoint = store
            .get_checkpoint("resume-conversation")
            .await?
            .ok_or_else(|| {
                crate::error::ReactError::Other("tool batch checkpoint missing".to_string())
            })?;
        assert_eq!(checkpoint.completed_tool_call_ids()?, vec!["write-1"]);
        assert!(checkpoint.restore_messages()?.len() >= 2);
        Ok(())
    }

    #[tokio::test]
    async fn resume_records_checkpoint_origin_and_completed_tools_in_trace() -> Result<()> {
        use crate::trace::RunStore;

        let store = Arc::new(RecordingRuntimeStateStore::default());
        let checkpoint_messages = vec![
            Message::system("system".to_string()),
            Message::assistant_with_tools(vec![echo_core::llm::types::ToolCall {
                provider_source: None,
                id: "write-1".to_string(),
                call_type: "function".to_string(),
                function: echo_core::llm::types::FunctionCall {
                    name: "mock_write".to_string(),
                    arguments: "{}".to_string(),
                },
            }]),
            Message::tool_result(
                "write-1".to_string(),
                "mock_write".to_string(),
                "written".to_string(),
            ),
        ];
        let mut checkpoint = crate::state::AgentCheckpoint::new("resume-conversation");
        checkpoint.messages_json =
            crate::state::AgentCheckpoint::serialize_payload(checkpoint_messages, None)
                .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;
        store.save_checkpoint(&checkpoint).await?;

        let run_store = Arc::new(crate::trace::InMemoryRunStore::new());
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new().with_response("resumed")))
            .conversation_id("resume-conversation")
            .state_store(store)
            .with_run_store(run_store.clone())
            .build()?;
        let events = agent
            .run_stream_channel(
                StreamInit {
                    text: "continue".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Execute,
            )
            .await?
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
        assert!(
            events.iter().any(|event| matches!(
                event,
                AgentEvent::FinalAnswer(answer) if answer == "resumed"
            )),
            "unexpected resume events: {events:?}"
        );

        let summary = run_store
            .list_all(1)
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| crate::error::ReactError::Other("trace run missing".to_string()))?;
        let run = run_store
            .load(&summary.run_id)
            .await?
            .ok_or_else(|| crate::error::ReactError::Other("trace payload missing".to_string()))?;
        assert!(
            run.events.iter().any(|event| matches!(
                event,
                crate::trace::RunEvent::CheckpointResumed {
                    conversation_id,
                    completed_tool_call_ids,
                    ..
                } if conversation_id == "resume-conversation"
                    && completed_tool_call_ids == &["write-1".to_string()]
            )),
            "resume trace missing from events: {:?}",
            run.events
        );
        Ok(())
    }

    #[tokio::test]
    async fn invocation_runtime_state_identity_controls_restore_and_save() -> Result<()> {
        let root = tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let store = Arc::new(crate::state::FileRuntimeStateStore::new(root.path())?);

        let mut configured = crate::state::AgentCheckpoint::new("configured-state");
        configured.messages_json = crate::state::AgentCheckpoint::serialize_payload(
            vec![
                Message::system("system".to_string()),
                Message::user("configured checkpoint marker".to_string()),
            ],
            None,
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;
        store.save_checkpoint(&configured).await?;

        let mut invocation_checkpoint = crate::state::AgentCheckpoint::new("runtime-incarnation");
        invocation_checkpoint.messages_json = crate::state::AgentCheckpoint::serialize_payload(
            vec![
                Message::system("system".to_string()),
                Message::user("invocation checkpoint marker".to_string()),
            ],
            None,
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;
        store
            .save_checkpoint_for_scope("product-conversation", &invocation_checkpoint)
            .await?;

        let llm = Arc::new(MockLlmClient::new().with_response("new incarnation answer"));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("system")
            .conversation_id("configured-state")
            .state_store(store.clone())
            .build()?;
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("product-conversation".to_string()),
                run_id: Some("run-new".to_string()),
                turn_id: Some("turn-new".to_string()),
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            runtime_state_id: Some("runtime-incarnation".to_string()),
            transcript_generation_id: Some("runtime-incarnation".to_string()),
            ..echo_core::agent::AgentInvocationContext::default()
        };

        let events = agent
            .run_stream_channel(
                StreamInit {
                    text: "continue in the new incarnation".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await?
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
        assert!(events.iter().any(
            |event| matches!(event, AgentEvent::FinalAnswer(answer) if answer == "new incarnation answer")
        ));

        let request = llm
            .last_messages()
            .ok_or_else(|| ReactError::Other("mock LLM request was not recorded".to_string()))?;
        assert!(request.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "invocation checkpoint marker")
        }));
        assert!(!request.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "configured checkpoint marker")
        }));

        let configured_after = store
            .get_checkpoint("configured-state")
            .await?
            .ok_or_else(|| ReactError::Other("configured checkpoint disappeared".to_string()))?;
        assert_eq!(configured_after.messages_json, configured.messages_json);
        let invocation_after = store
            .get_checkpoint("runtime-incarnation")
            .await?
            .ok_or_else(|| ReactError::Other("invocation checkpoint was not saved".to_string()))?;
        let restored = invocation_after.restore_messages()?;
        assert!(restored.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "new incarnation answer")
        }));
        assert!(!restored.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "configured checkpoint marker")
        }));
        Ok(())
    }

    #[tokio::test]
    async fn nonstream_configured_runtime_identity_controls_restore_and_save() -> Result<()> {
        let root = tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let store = Arc::new(crate::state::FileRuntimeStateStore::new(root.path())?);

        let mut configured = crate::state::AgentCheckpoint::new("configured-state");
        configured.messages_json = crate::state::AgentCheckpoint::serialize_payload(
            vec![
                Message::system("system".to_string()),
                Message::user("configured checkpoint marker".to_string()),
            ],
            None,
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;
        store.save_checkpoint(&configured).await?;

        let mut invocation = crate::state::AgentCheckpoint::new("invocation-runtime");
        invocation.messages_json = crate::state::AgentCheckpoint::serialize_payload(
            vec![
                Message::system("system".to_string()),
                Message::user("invocation checkpoint marker".to_string()),
            ],
            None,
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;
        store
            .save_checkpoint_for_scope("invocation-runtime", &invocation)
            .await?;

        let llm = Arc::new(MockLlmClient::new().with_response("invocation answer"));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("system")
            .conversation_id("invocation-runtime")
            .state_store(store.clone())
            .build()?;

        let answer = agent
            .run_react_loop_mode("continue invocation runtime", StreamMode::Chat)
            .await?;
        assert_eq!(answer, "invocation answer");
        let request = llm
            .last_messages()
            .ok_or_else(|| ReactError::Other("mock LLM request was not recorded".to_string()))?;
        assert!(request.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "invocation checkpoint marker")
        }));
        assert!(!request.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "configured checkpoint marker")
        }));
        let configured_after = store
            .get_checkpoint("configured-state")
            .await?
            .ok_or_else(|| ReactError::Other("configured checkpoint disappeared".to_string()))?;
        assert_eq!(configured_after.messages_json, configured.messages_json);
        let invocation_after = store
            .get_checkpoint("invocation-runtime")
            .await?
            .ok_or_else(|| ReactError::Other("invocation checkpoint was not saved".to_string()))?;
        assert!(invocation_after.restore_messages()?.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "invocation answer")
        }));
        Ok(())
    }

    #[tokio::test]
    async fn transcript_generation_runtime_identity_rejects_admission_without_side_effects()
    -> Result<()> {
        let root = tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let store = Arc::new(crate::state::FileRuntimeStateStore::new(root.path())?);
        let llm = Arc::new(MockLlmClient::new().with_response("must not run"));
        let run_store = Arc::new(crate::trace::InMemoryRunStore::new());
        let guard_calls = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let input_lifecycle = Arc::new(InputLifecycleProbe::default());
        let mut agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("system")
            .conversation_id("configured-state")
            .state_store(store.clone())
            .build()?;
        agent.set_run_store(run_store.clone());
        let mut guard_manager = GuardManager::new();
        guard_manager.add(Arc::new(CountingGuard {
            calls: guard_calls.clone(),
        }));
        agent.set_guard_manager(guard_manager);
        let original_message_count = agent.memory.context.lock().await.messages().len();
        let _execution_guard = agent.execution_mutex.lock().await;

        for (runtime_state_id, product_conversation_id) in [
            (Some("runtime-a"), "product-conversation"),
            (None, "product-fallback"),
        ] {
            let invocation = echo_core::agent::AgentInvocationContext {
                runtime_state_id: runtime_state_id.map(str::to_string),
                transcript_generation_id: Some("runtime-b".to_string()),
                runtime: Some(echo_core::tools::ExternalRunContext {
                    conversation_id: Some(product_conversation_id.to_string()),
                    run_id: Some(format!("run-{product_conversation_id}")),
                    ..Default::default()
                }),
                input_lifecycle: Some(input_lifecycle.clone()),
                ..Default::default()
            };
            let admission = tokio::time::timeout(
                std::time::Duration::from_millis(100),
                agent.run_stream_channel(
                    StreamInit {
                        text: "must fail before admission".to_string(),
                        message: None,
                        label: String::new(),
                        invocation: Some(invocation),
                    },
                    StreamMode::Chat,
                ),
            )
            .await
            .map_err(|_| {
                ReactError::Other("identity validation waited for the execution mutex".to_string())
            })?;
            let error = match admission {
                Ok(_stream) => {
                    return Err(ReactError::Other(
                        "mismatched transcript generation unexpectedly admitted".to_string(),
                    ));
                }
                Err(error) => error,
            };
            assert!(matches!(error, ReactError::RuntimeState(_)));
            assert!(error.to_string().contains("transcript generation identity"));
        }

        assert_eq!(llm.call_count(), 0);
        assert!(run_store.is_empty().await);
        assert_eq!(guard_calls.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert_eq!(
            input_lifecycle
                .drained
                .load(std::sync::atomic::Ordering::SeqCst),
            0
        );
        assert_eq!(
            agent.memory.context.lock().await.messages().len(),
            original_message_count
        );
        assert!(store.get_checkpoint("runtime-a").await?.is_none());
        assert!(
            store
                .runtime_state_ids("product-conversation")
                .await?
                .is_empty()
        );
        assert!(
            store
                .runtime_state_ids("product-fallback")
                .await?
                .is_empty()
        );
        Ok(())
    }

    #[tokio::test]
    async fn warm_agent_switches_runtime_state_identity_without_context_leakage() -> Result<()> {
        let root = tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let store = Arc::new(crate::state::FileRuntimeStateStore::new(root.path())?);
        let mut configured = crate::state::AgentCheckpoint::new("configured-state");
        configured.messages_json = crate::state::AgentCheckpoint::serialize_payload(
            vec![
                Message::system("system".to_string()),
                Message::user("configured-only-marker".to_string()),
            ],
            None,
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;
        store.save_checkpoint(&configured).await?;
        let llm = Arc::new(MockLlmClient::new().with_responses([
            "assistant-a-one",
            "assistant-b-one",
            "assistant-a-two",
            "assistant-configured",
        ]));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("system")
            .conversation_id("configured-state")
            .state_store(store.clone())
            .build()?;
        agent.set_snapshot_manager(crate::memory::SnapshotManager::new(
            crate::memory::SnapshotPolicy::Manual,
            4,
        ));
        let invocation =
            |runtime_state_id: &str, turn_id: &str| echo_core::agent::AgentInvocationContext {
                runtime: Some(echo_core::tools::ExternalRunContext {
                    conversation_id: Some("product-conversation".to_string()),
                    run_id: Some(turn_id.to_string()),
                    turn_id: Some(turn_id.to_string()),
                    execution_id: None,
                    isolation_id: None,
                    message_id: None,
                    cancel: None,
                    trace_sink: None,
                    delegation_policy: None,
                    resource_guards: Vec::new(),
                    subagent_lineage: None,
                    uplink: None,
                }),
                runtime_state_id: Some(runtime_state_id.to_string()),
                transcript_generation_id: Some(runtime_state_id.to_string()),
                ..echo_core::agent::AgentInvocationContext::default()
            };

        for (index, (runtime_state_id, turn_id, input)) in [
            ("runtime-a", "turn-a-one", "user-a-one"),
            ("runtime-b", "turn-b-one", "user-b-one"),
            ("runtime-a", "turn-a-two", "user-a-two"),
        ]
        .into_iter()
        .enumerate()
        {
            agent
                .run_stream_channel(
                    StreamInit {
                        text: input.to_string(),
                        message: None,
                        label: String::new(),
                        invocation: Some(invocation(runtime_state_id, turn_id)),
                    },
                    StreamMode::Chat,
                )
                .await?
                .collect::<Vec<_>>()
                .await
                .into_iter()
                .collect::<Result<Vec<_>>>()?;
            if index == 0 {
                let snapshot_id = agent.snapshot().await.ok_or_else(|| {
                    ReactError::Other("runtime A snapshot was not captured".to_string())
                })?;
                assert!(!snapshot_id.is_empty());
                agent
                    .tools
                    .skill_registry
                    .mark_activated("runtime-a-only-skill");
                agent.set_working_dir(Some(std::path::PathBuf::from(
                    "/tmp/runtime-a-only-working-dir",
                )));
            } else if index == 1 {
                assert!(
                    agent.rollback(1).await.is_none(),
                    "runtime B retained runtime A rollback snapshots"
                );
            }
        }

        agent
            .run_stream_channel(
                StreamInit {
                    text: "user-configured".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;

        let calls = llm.all_calls();
        let call = |index: usize| {
            calls
                .get(index)
                .ok_or_else(|| ReactError::Other(format!("mock LLM call {index} was not recorded")))
        };
        let contains = |messages: &[Message], expected: &str| {
            messages.iter().any(|message| {
                message
                    .text_content()
                    .is_some_and(|content| content == expected)
            })
        };
        let first = call(0)?;
        assert!(contains(first, "user-a-one"));
        assert!(!contains(first, "user-b-one"));
        let second = call(1)?;
        assert!(contains(second, "user-b-one"));
        assert!(!contains(second, "user-a-one"));
        assert!(!contains(second, "assistant-a-one"));
        let third = call(2)?;
        assert!(contains(third, "user-a-one"));
        assert!(contains(third, "assistant-a-one"));
        assert!(contains(third, "user-a-two"));
        assert!(!contains(third, "user-b-one"));
        assert!(!contains(third, "assistant-b-one"));
        let configured_call = call(3)?;
        assert!(contains(configured_call, "configured-only-marker"));
        assert!(contains(configured_call, "user-configured"));
        assert!(!contains(configured_call, "user-a-one"));
        assert!(!contains(configured_call, "user-b-one"));

        let runtime_a_checkpoint = store
            .get_checkpoint("runtime-a")
            .await?
            .ok_or_else(|| ReactError::Other("runtime A checkpoint missing".to_string()))?;

        let runtime_a = runtime_a_checkpoint.restore_messages()?;
        let runtime_b_checkpoint = store
            .get_checkpoint("runtime-b")
            .await?
            .ok_or_else(|| ReactError::Other("runtime B checkpoint missing".to_string()))?;

        assert!(runtime_b_checkpoint.active_skills.is_empty());
        assert!(runtime_b_checkpoint.working_dir.is_none());
        let runtime_b = runtime_b_checkpoint.restore_messages()?;
        assert!(contains(&runtime_a, "user-a-one"));
        assert!(contains(&runtime_a, "user-a-two"));
        assert!(!contains(&runtime_a, "user-b-one"));
        assert!(contains(&runtime_b, "user-b-one"));
        assert!(!contains(&runtime_b, "user-a-one"));
        Ok(())
    }

    #[tokio::test]
    async fn cancelled_runtime_switch_cannot_publish_partial_hydration() -> Result<()> {
        use crate::skills::hooks::{HookAction, HookEvent, HookRule, HooksDefinition};
        use std::sync::atomic::{AtomicUsize, Ordering};

        let root = tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let store = Arc::new(crate::state::FileRuntimeStateStore::new(root.path())?);
        let mut runtime_b = crate::state::AgentCheckpoint::new("runtime-b");

        runtime_b.messages_json = crate::state::AgentCheckpoint::serialize_payload(
            vec![
                Message::system("system".to_string()),
                Message::user("runtime-b-checkpoint-marker".to_string()),
            ],
            None,
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;
        store
            .save_checkpoint_for_scope("product-conversation", &runtime_b)
            .await?;
        let llm = Arc::new(
            MockLlmClient::new()
                .with_responses(["runtime-a-first-answer", "runtime-a-recovered-answer"]),
        );
        let agent = Arc::new(
            ReactAgentBuilder::new()
                .llm_client(llm.clone())
                .system_prompt("system")
                .conversation_id("configured-state")
                .state_store(store.clone())
                .build()?,
        );
        let invocation =
            |runtime_state_id: &str, turn_id: &str| echo_core::agent::AgentInvocationContext {
                runtime: Some(echo_core::tools::ExternalRunContext {
                    conversation_id: Some("product-conversation".to_string()),
                    run_id: Some(turn_id.to_string()),
                    turn_id: Some(turn_id.to_string()),
                    execution_id: None,
                    isolation_id: None,
                    message_id: None,
                    cancel: None,
                    trace_sink: None,
                    delegation_policy: None,
                    resource_guards: Vec::new(),
                    subagent_lineage: None,
                    uplink: None,
                }),
                runtime_state_id: Some(runtime_state_id.to_string()),
                transcript_generation_id: Some(runtime_state_id.to_string()),
                ..echo_core::agent::AgentInvocationContext::default()
            };

        agent
            .run_stream_channel(
                StreamInit {
                    text: "runtime-a-first-user".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation("runtime-a", "turn-a-first")),
                },
                StreamMode::Chat,
            )
            .await?
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;

        let hook_entered = Arc::new(tokio::sync::Notify::new());
        let executor_entered = Arc::clone(&hook_entered);
        let attempts = Arc::new(AtomicUsize::new(0));
        let executor_attempts = Arc::clone(&attempts);
        {
            let mut hooks = agent.tools.hook_registry.write().await;
            hooks.set_subagent_executor(Arc::new(move |_name, _task| {
                let entered = Arc::clone(&executor_entered);
                let attempts = Arc::clone(&executor_attempts);
                Box::pin(async move {
                    if attempts.fetch_add(1, Ordering::AcqRel) == 0 {
                        entered.notify_one();
                        std::future::pending::<()>().await;
                    }
                    Ok("session hook settled".to_string())
                })
            }));
            let mut definition = HooksDefinition::default();
            definition.add_rules(
                HookEvent::SessionStart,
                vec![HookRule {
                    matcher: "resume".to_string(),
                    hooks: vec![HookAction::Subagent {
                        name: "hydration-barrier".to_string(),
                        task: None,
                        timeout: 0,
                    }],
                }],
            );
            hooks.register_user_hooks(definition);
        }

        let switching_agent = Arc::clone(&agent);
        let switching_invocation = invocation("runtime-b", "turn-b-cancelled");
        let switching = tokio::spawn(async move {
            switching_agent
                .run_stream_channel(
                    StreamInit {
                        text: "runtime-b-cancelled-user".to_string(),
                        message: None,
                        label: String::new(),
                        invocation: Some(switching_invocation),
                    },
                    StreamMode::Chat,
                )
                .await
                .map(|_stream| ())
        });
        tokio::time::timeout(std::time::Duration::from_secs(2), hook_entered.notified())
            .await
            .map_err(|_| ReactError::Other("runtime B hydration did not reach hook".to_string()))?;
        switching.abort();
        let cancelled = switching
            .await
            .err()
            .ok_or_else(|| ReactError::Other("runtime B switch was not cancelled".to_string()))?;
        assert!(cancelled.is_cancelled());
        let retained = store.get_checkpoint("runtime-b").await?.ok_or_else(|| {
            ReactError::Other("runtime B checkpoint missing after cancellation".to_string())
        })?;
        assert_eq!(retained.messages_json, runtime_b.messages_json);

        // Caller abort is not a physical receipt for an admitted preparation.
        // Preserve the original atomic-hydration assertions without admitting
        // another effect through this now-uncertain Agent.
        let rejected = agent
            .run_stream_channel(
                StreamInit {
                    text: "runtime-a-after-cancel".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation("runtime-a", "turn-a-recovered")),
                },
                StreamMode::Chat,
            )
            .await;
        assert!(matches!(
            rejected,
            Err(ReactError::ExecutionNotSettled { .. })
        ));
        assert_eq!(llm.all_calls().len(), 1);
        // Hydration may have staged B in private memory before the hook.
        // The durable A checkpoint remains authoritative; the unknown fence
        // rejects re-entry rather than silently rehydrating another turn.
        let original_checkpoint = store
            .get_checkpoint("runtime-a")
            .await?
            .ok_or_else(|| ReactError::Other("runtime A checkpoint missing".to_string()))?;

        let original = original_checkpoint.restore_messages()?;
        assert!(original.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "runtime-a-first-user")
        }));
        assert!(!original.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "runtime-b-checkpoint-marker")
        }));
        Ok(())
    }

    #[tokio::test]
    async fn invocation_runtime_conversation_controls_restore_and_save() -> Result<()> {
        let root = tempfile::tempdir().map_err(|error| ReactError::Other(error.to_string()))?;
        let store = Arc::new(crate::state::FileRuntimeStateStore::new(root.path())?);
        let mut configured = crate::state::AgentCheckpoint::new("configured-a");
        configured.messages_json = crate::state::AgentCheckpoint::serialize_payload(
            vec![
                Message::system("system".to_string()),
                Message::user("configured-a-marker".to_string()),
            ],
            None,
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;
        store.save_checkpoint(&configured).await?;
        let mut invocation = crate::state::AgentCheckpoint::new("invocation-b");
        invocation.messages_json = crate::state::AgentCheckpoint::serialize_payload(
            vec![
                Message::system("system".to_string()),
                Message::user("invocation-b-marker".to_string()),
            ],
            None,
        )
        .map_err(|error| ReactError::Other(error.to_string()))?;
        store.save_checkpoint(&invocation).await?;

        let llm = Arc::new(MockLlmClient::new().with_response("invocation-b-answer"));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("system")
            .conversation_id("configured-a")
            .state_store(store.clone())
            .build()?;
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: Some("invocation-b".to_string()),
                run_id: Some("invocation-run".to_string()),
                turn_id: Some("invocation-turn".to_string()),
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            ..Default::default()
        };
        agent
            .run_stream_channel(
                StreamInit {
                    text: "invocation-b-user".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await?
            .collect::<Vec<_>>()
            .await
            .into_iter()
            .collect::<Result<Vec<_>>>()?;

        let request = llm
            .last_messages()
            .ok_or_else(|| ReactError::Other("invocation LLM request missing".to_string()))?;
        assert!(request.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "invocation-b-marker")
        }));
        assert!(!request.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "configured-a-marker")
        }));
        let configured_after = store
            .get_checkpoint("configured-a")
            .await?
            .ok_or_else(|| ReactError::Other("configured checkpoint missing".to_string()))?;
        assert_eq!(configured_after.messages_json, configured.messages_json);
        let invocation_after = store
            .get_checkpoint("invocation-b")
            .await?
            .ok_or_else(|| ReactError::Other("invocation checkpoint missing".to_string()))?
            .restore_messages()?;
        assert!(invocation_after.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|content| content == "invocation-b-answer")
        }));
        Ok(())
    }

    #[tokio::test]
    async fn iteration_wind_down_is_injected_once() {
        let llm = Arc::new(
            MockLlmClient::new()
                .then_tool_call("call_1", "mock_calc", r#"{"x":1}"#)
                .with_response("done"),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .tool(Box::new(MockTool::new("mock_calc").with_response("1")))
            .max_iterations(2)
            .run_budget(echo_core::agent::RunBudgetPolicy {
                iteration_wind_down_remaining: Some(1),
                max_model_tokens: None,
            })
            .build()
            .expect("agent builds");

        let events = collect_events(&agent, "run").await;
        let wind_down_count = events
            .iter()
            .filter(|event| {
                matches!(
                    event,
                    AgentEvent::BudgetDecision {
                        decision: echo_core::agent::BudgetDecision::WindDown,
                        ..
                    }
                )
            })
            .count();
        assert_eq!(wind_down_count, 1);
        let calls = llm.all_calls();
        let second = calls.get(1).expect("second LLM call");
        assert!(second.iter().any(|message| {
            message
                .text_content()
                .is_some_and(|text| text.contains("iteration budget is nearly exhausted"))
        }));
    }

    #[tokio::test]
    async fn react_stream_records_real_usage_in_run_trace() -> Result<()> {
        use crate::trace::RunStore;

        let usage = crate::llm::types::Usage {
            prompt_tokens: Some(1000),
            completion_tokens: Some(80),
            total_tokens: Some(1080),
            prompt_tokens_details: Some(crate::llm::types::TokenUsageDetails {
                cached_tokens: Some(750),
                ..Default::default()
            }),
            ..Default::default()
        };
        let store = Arc::new(crate::trace::InMemoryRunStore::new());
        let mut agent =
            agent_with_mock_llm(MockLlmClient::new().with_response_usage("done", usage));
        agent.set_run_store(store.clone());

        let events = collect_events(&agent, "run").await;
        assert!(events.iter().any(|event| matches!(
            event,
            AgentEvent::LlmUsage {
                prompt_tokens: 1000,
                cached_prompt_tokens: 750,
                usage_reported: true,
                ..
            }
        )));
        let summary = store
            .list_all(1)
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| crate::error::ReactError::Other("trace summary missing".into()))?;
        let run = store
            .load(&summary.run_id)
            .await?
            .ok_or_else(|| crate::error::ReactError::Other("trace run missing".into()))?;
        assert!(
            run.events.iter().any(|event| matches!(
                event,
                crate::trace::RunEvent::LlmCall {
                    cached_prompt_tokens: 750,
                    usage_reported: true,
                    ..
                }
            )),
            "LLM usage event missing from trace: {:?}",
            run.events
        );
        assert_eq!(summary.token_usage.prompt_tokens, 1000);
        assert_eq!(summary.token_usage.cached_prompt_tokens, 750);
        Ok(())
    }

    #[tokio::test]
    async fn model_token_budget_blocks_tools_and_forces_final_only_request() -> Result<()> {
        let usage = crate::llm::types::Usage {
            prompt_tokens: Some(6),
            completion_tokens: Some(5),
            total_tokens: Some(11),
            ..crate::llm::types::Usage::default()
        };
        let llm = Arc::new(
            MockLlmClient::new()
                .then_tool_call_with_usage("blocked", "mock_calc", r#"{"x":1}"#, usage)
                .with_response("final without tools"),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    "mock-model",
                    "openai",
                ),
            )
            .tool(Box::new(
                MockTool::new("mock_calc").with_response("must not run"),
            ))
            .max_iterations(3)
            .run_budget(echo_core::agent::RunBudgetPolicy {
                iteration_wind_down_remaining: None,
                max_model_tokens: Some(10),
            })
            .build()?;

        let events = collect_events(&agent, "run").await;
        assert!(events.iter().any(|event| {
            matches!(
                event,
                AgentEvent::BudgetDecision {
                    decision: echo_core::agent::BudgetDecision::FinalOnly,
                    reported_model_tokens: 11,
                    usage_complete: true,
                    ..
                }
            )
        }));
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::ToolCall { .. }))
        );
        assert!(
            matches!(last_confirmed_final(&events), Some(AgentEvent::FinalAnswer(text)) if text == "final without tools")
        );
        assert_eq!(llm.all_tool_choices(), vec![None, Some("none".to_string())]);
        Ok(())
    }

    #[tokio::test]
    async fn configured_response_format_reaches_every_react_request() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new()
                .then_tool_call("call", "mock_calc", r#"{"x":1}"#)
                .with_response(r#"{"ok":true}"#),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    "mock-model",
                    "openai",
                ),
            )
            .response_format(crate::llm::ResponseFormat::JsonObject)
            .tool(Box::new(MockTool::new("mock_calc").with_response("done")))
            .build()?;

        let events = collect_events(&agent, "run").await;
        assert!(
            matches!(last_confirmed_final(&events), Some(AgentEvent::FinalAnswer(text)) if text == r#"{"ok":true}"#)
        );
        let formats = llm.all_response_formats();
        assert_eq!(formats.len(), 2);
        assert!(
            formats
                .iter()
                .all(|format| matches!(format, Some(crate::llm::ResponseFormat::JsonObject)))
        );
        Ok(())
    }

    #[tokio::test]
    async fn unknown_model_does_not_silently_enable_structured_output() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().with_response(r#"{"ok":true}"#));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .response_format(crate::llm::ResponseFormat::JsonObject)
            .build()?;

        let events = collect_events(&agent, "run").await;
        assert!(events.iter().any(|event| matches!(
            event,
            AgentEvent::Error { message, .. }
                if message.contains("structured-output model capability")
        )));
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        assert_eq!(llm.call_count(), 0);
        Ok(())
    }

    #[tokio::test]
    async fn explicit_text_format_keeps_anthropic_request_unconstrained() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().with_response("plain answer"));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    "mock-model",
                    "anthropic",
                ),
            )
            .response_format(crate::llm::ResponseFormat::Text)
            .build()?;

        let events = collect_events(&agent, "run").await;
        assert!(
            matches!(last_confirmed_final(&events), Some(AgentEvent::FinalAnswer(text)) if text == "plain answer")
        );
        assert_eq!(llm.all_response_formats().len(), 1);
        assert!(llm.all_response_formats().iter().all(Option::is_none));
        Ok(())
    }

    #[tokio::test]
    async fn strict_schema_retries_text_before_success_terminal() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new()
                .with_response(r#"{"age":"wrong"}"#)
                .with_response(r#"{"age":28}"#),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    "mock-model",
                    "openai",
                ),
            )
            .response_format(crate::llm::ResponseFormat::json_schema(
                "person",
                serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
            ))
            .build()?;

        let events = collect_events(&agent, "run").await;
        let final_answers: Vec<_> = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::FinalAnswer(answer) => Some(answer.as_str()),
                _ => None,
            })
            .collect();
        assert_eq!(final_answers, vec![r#"{"age":28}"#]);
        assert_eq!(llm.call_count(), 2);
        Ok(())
    }

    #[tokio::test]
    async fn output_guard_transform_cannot_publish_invalid_strict_json() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().with_response(r#"{"age":28}"#));
        let mut agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    "mock-model",
                    "openai",
                ),
            )
            .response_format(crate::llm::ResponseFormat::json_schema(
                "person",
                serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
            ))
            .max_iterations(1)
            .build()?;
        let mut guards = GuardManager::new();
        guards.add(Arc::new(InvalidFinalJsonGuard));
        agent.set_guard_manager(guards);

        let events = collect_events(&agent, "run").await;
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        assert!(events.iter().any(|event| matches!(
            event,
            AgentEvent::Error { message, .. } if message.contains("does not match JSON Schema")
        )));
        assert_eq!(llm.call_count(), 1);
        Ok(())
    }

    #[tokio::test]
    async fn strict_schema_retries_native_candidate_before_success_terminal() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new()
                .with_stream_script(native_response_script(
                    "bad-native",
                    &[(
                        echo_core::agent::AssistantPhase::FinalAnswer,
                        r#"{"age":"wrong"}"#,
                    )],
                )?)
                .with_stream_script(native_response_script(
                    "good-native",
                    &[(
                        echo_core::agent::AssistantPhase::FinalAnswer,
                        r#"{"age":28}"#,
                    )],
                )?),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    "mock-model",
                    "openai",
                ),
            )
            .response_format(crate::llm::ResponseFormat::json_schema(
                "person",
                serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
            ))
            .build()?;

        let events = collect_events(&agent, "run").await;
        let final_answers: Vec<_> = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::FinalAnswer(answer) => Some(answer.as_str()),
                _ => None,
            })
            .collect();
        assert_eq!(final_answers, vec![r#"{"age":28}"#]);
        assert_eq!(llm.call_count(), 2);
        assert_native_runtime_terminal(&events, echo_core::agent::ExecutionStatusKind::Settled);
        Ok(())
    }

    #[tokio::test]
    async fn strict_final_answer_schema_precedes_optional_critic() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new().with_stream_script(native_response_script(
                "schema-before-critic",
                &[(
                    echo_core::agent::AssistantPhase::FinalAnswer,
                    r#"{"age":"wrong"}"#,
                )],
            )?),
        );
        let mut agent = ReactAgent::new(
            AgentConfig::new("mock-model", "critic-agent", "system")
                .model_profile(
                    echo_core::llm::capabilities::ModelProfile::from_provider_name(
                        "mock-model",
                        "openai",
                    ),
                )
                .response_format(crate::llm::ResponseFormat::json_schema(
                    "person",
                    serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
                ))
                .verifier_enabled(true)
                .max_iterations(1),
        )
        .with_llm_client(llm.clone());
        struct SchemaOrderCritic(Arc<std::sync::atomic::AtomicUsize>);
        impl echo_core::agent::Critic for SchemaOrderCritic {
            fn critique<'a>(
                &'a self,
                _task: &'a str,
                _answer: &'a str,
                _context: &'a str,
            ) -> BoxFuture<'a, Result<echo_core::agent::Critique>> {
                Box::pin(async move {
                    self.0.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                    Ok(echo_core::agent::Critique {
                        score: 9.0,
                        passed: true,
                        feedback: "checked".into(),
                        suggestions: Vec::new(),
                    })
                })
            }
        }
        let critic_calls = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        agent.set_critic(Arc::new(SchemaOrderCritic(critic_calls.clone())));

        let events = collect_events(&agent, "run").await;
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        assert!(events.iter().any(|event| matches!(
            event,
            AgentEvent::Error { message, .. } if message.contains("does not match JSON Schema")
        )));
        assert_eq!(llm.call_count(), 1);
        assert_eq!(critic_calls.load(std::sync::atomic::Ordering::SeqCst), 0);
        assert_native_runtime_terminal(&events, echo_core::agent::ExecutionStatusKind::Failed);
        Ok(())
    }

    #[tokio::test]
    async fn native_progress_in_same_response_does_not_poison_schema_final() -> Result<()> {
        let llm = Arc::new(
            MockLlmClient::new().with_stream_script(native_response_script(
                "same-response-schema",
                &[
                    (
                        echo_core::agent::AssistantPhase::PartialAnswer,
                        r#"{"age":"not-final"}"#,
                    ),
                    (
                        echo_core::agent::AssistantPhase::FinalAnswer,
                        r#"{"age":28}"#,
                    ),
                ],
            )?),
        );
        let agent=ReactAgentBuilder::new().llm_client(llm.clone())
            .model_profile(echo_core::llm::capabilities::ModelProfile::from_provider_name("mock-model","openai"))
            .response_format(crate::llm::ResponseFormat::json_schema("person",serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]})))
            .max_iterations(1).build()?;
        let events = collect_events(&agent, "run").await;
        assert!(
            matches!(last_confirmed_final(&events),Some(AgentEvent::FinalAnswer(answer)) if answer==r#"{"age":28}"#)
        );
        let raw: Vec<_> = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::AssistantMessage { block }
                    if block.request_id == "same-response-schema" =>
                {
                    Some((block.sequence, block.phase, block.delta.as_str()))
                }
                _ => None,
            })
            .collect();
        assert_eq!(
            raw,
            vec![
                (
                    0,
                    echo_core::agent::AssistantPhase::PartialAnswer,
                    r#"{"age":"not-final"}"#
                ),
                (
                    1,
                    echo_core::agent::AssistantPhase::FinalAnswer,
                    r#"{"age":28}"#
                )
            ]
        );
        assert_eq!(llm.call_count(), 1);
        Ok(())
    }

    #[tokio::test]
    async fn retired_control_tool_proposal_is_not_registered_or_a_success_terminal() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().then_tool_call(
            "retired-proposal",
            "final_answer",
            r#"{"answer":"must not complete"}"#,
        ));
        let mut agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .max_iterations(2)
            .build()?;
        agent.config_mut().llm_max_retries = 0;
        assert!(
            !agent
                .tool_names()
                .iter()
                .any(|name| name == "final_answer" || name == "think")
        );
        let raw = agent
            .execute_stream("rejected old control proposal")
            .await?
            .collect::<Vec<_>>()
            .await;
        assert!(
            raw.iter().any(|event| match event {
                Ok(AgentEvent::ToolResult { name, result, .. }) =>
                    name == "final_answer" && !result.success,
                Ok(AgentEvent::Error { message, .. }) => message.contains("final_answer"),
                Err(error) => error.to_string().contains("final_answer"),
                _ => false,
            }),
            "必须保实际退休调用拒绝原因：{raw:?}"
        );
        assert!(
            !raw.iter()
                .any(|event| matches!(event, Err(ReactError::ExecutionNotSettled { .. })))
        );
        assert!(
            matches!(raw.first(),Some(Ok(AgentEvent::ExecutionStatus(status))) if status.status==echo_core::agent::ExecutionStatusKind::Started)
        );
        assert!(
            matches!(raw.last(),Some(Ok(AgentEvent::ExecutionStatus(status))) if status.status==echo_core::agent::ExecutionStatusKind::Failed),
            "原Result通道也必须最后才结算：{raw:?}"
        );
        let events: Vec<_> = raw
            .iter()
            .filter_map(|event| event.as_ref().ok().cloned())
            .collect();
        assert_native_runtime_terminal(&events, echo_core::agent::ExecutionStatusKind::Failed);
        assert!(llm.call_count() <= 2);
        Ok(())
    }

    #[tokio::test]
    async fn invalid_native_final_does_not_preempt_accepted_steer() -> Result<()> {
        use std::time::Duration;

        let llm = Arc::new(
            MockLlmClient::new()
                .with_response(r#"{"age":"wrong"}"#)
                .with_response(r#"{"age":28}"#)
                .with_delay(Duration::from_millis(150)),
        );
        let agent = ReactAgent::new(
            AgentConfig::new("mock-model", "steered", "system")
                .model_profile(
                    echo_core::llm::capabilities::ModelProfile::from_provider_name(
                        "mock-model",
                        "openai",
                    ),
                )
                .response_format(crate::llm::ResponseFormat::json_schema(
                    "person",
                    serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
                ))
                .llm_max_retries(0)
                .max_iterations(2),
        )
        .with_llm_client(llm.clone());

        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "initial request".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?;
        tokio::time::sleep(Duration::from_millis(30)).await;
        let mut receipt = agent
            .steer_input_tracked(None, Message::user("correct the final answer".to_string()))
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let events = stream.collect::<Vec<_>>().await;
        assert!(events.iter().any(|event| matches!(
            event,
            Ok(AgentEvent::FinalAnswer(answer)) if answer == r#"{"age":28}"#
        )));
        assert_eq!(llm.call_count(), 2);
        assert_eq!(
            receipt.wait_for_turn_settled().await,
            crate::agent::AgentSteerState::TurnSettled {
                outcome: crate::agent::AgentSteerTurnOutcome::Completed,
                drained: true,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn cancellation_during_final_critic_cannot_complete_run() -> Result<()> {
        use futures::StreamExt;

        let llm = Arc::new(
            MockLlmClient::new().with_stream_script(native_response_script(
                "explicit-final-critic",
                &[(
                    echo_core::agent::AssistantPhase::FinalAnswer,
                    r#"{"age":28}"#,
                )],
            )?),
        );
        let entered = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        let run_store = Arc::new(crate::trace::InMemoryRunStore::new());
        let mut agent = ReactAgent::new(
            AgentConfig::new("mock-model", "cancellable", "system")
                .model_profile(
                    echo_core::llm::capabilities::ModelProfile::from_provider_name(
                        "mock-model",
                        "openai",
                    ),
                )
                .response_format(crate::llm::ResponseFormat::json_schema(
                    "person",
                    serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
                ))
                .verifier_enabled(true)
                .max_iterations(1),
        )
        .with_llm_client(llm);
        agent.set_critic(Arc::new(BlockingFinalCritic {
            entered: Arc::clone(&entered),
            release: Arc::clone(&release),
        }));
        agent.set_run_store(run_store.clone());
        let cancel = crate::agent::CancellationToken::new();
        let stream = agent
            .execute_stream_with_cancel("run", cancel.clone())
            .await?;
        tokio::time::timeout(std::time::Duration::from_secs(2), entered.notified())
            .await
            .map_err(|_| ReactError::Other("critic did not start".to_string()))?;
        cancel.cancel();
        let remaining_result = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            stream.collect::<Vec<_>>(),
        )
        .await;
        release.notify_one();
        let remaining = remaining_result
            .map_err(|_| ReactError::Other("cancel waited for blocked critic".to_string()))?;
        assert!(
            remaining
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::Cancelled)))
        );
        assert!(
            !remaining
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::FinalAnswer(_))))
        );
        let observed = remaining.into_iter().collect::<Result<Vec<_>>>()?;
        assert_native_runtime_terminal(&observed, echo_core::agent::ExecutionStatusKind::Cancelled);
        let summary = crate::trace::RunStore::list_all(run_store.as_ref(), 1)
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| ReactError::Other("cancelled run trace missing".to_string()))?;
        let run = crate::trace::RunStore::load(run_store.as_ref(), &summary.run_id)
            .await?
            .ok_or_else(|| ReactError::Other("cancelled trace body missing".to_string()))?;
        assert_eq!(run.status, crate::trace::RunStatus::Cancelled);
        Ok(())
    }

    #[tokio::test]
    async fn cancellation_during_text_critic_cannot_complete_run() -> Result<()> {
        use futures::StreamExt;

        let llm = Arc::new(MockLlmClient::new().with_response(r#"{"age":28}"#));
        let entered = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        let run_store = Arc::new(crate::trace::InMemoryRunStore::new());
        let mut agent = ReactAgent::new(
            AgentConfig::new("mock-model", "text-cancellable", "system")
                .model_profile(
                    echo_core::llm::capabilities::ModelProfile::from_provider_name(
                        "mock-model",
                        "openai",
                    ),
                )
                .response_format(crate::llm::ResponseFormat::json_schema(
                    "person",
                    serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
                ))
                .verifier_enabled(true)
                .max_iterations(1),
        )
        .with_llm_client(llm);
        agent.set_critic(Arc::new(BlockingFinalCritic {
            entered: Arc::clone(&entered),
            release: Arc::clone(&release),
        }));
        agent.set_run_store(run_store.clone());
        let cancel = crate::agent::CancellationToken::new();
        let stream = agent
            .execute_stream_with_cancel("run", cancel.clone())
            .await?;
        tokio::time::timeout(std::time::Duration::from_secs(2), entered.notified())
            .await
            .map_err(|_| ReactError::Other("text critic did not start".to_string()))?;
        cancel.cancel();
        let remaining_result = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            stream.collect::<Vec<_>>(),
        )
        .await;
        release.notify_one();
        let remaining = remaining_result
            .map_err(|_| ReactError::Other("cancel waited for blocked text critic".to_string()))?;
        assert!(
            remaining
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::Cancelled)))
        );
        assert!(
            !remaining
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::FinalAnswer(_))))
        );
        let summary = crate::trace::RunStore::list_all(run_store.as_ref(), 1)
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| ReactError::Other("text cancel trace missing".to_string()))?;
        let run = crate::trace::RunStore::load(run_store.as_ref(), &summary.run_id)
            .await?
            .ok_or_else(|| ReactError::Other("text cancel trace body missing".to_string()))?;
        assert_eq!(run.status, crate::trace::RunStatus::Cancelled);
        Ok(())
    }

    async fn assert_cancelled_stop_hook_does_not_project_draft(continue_hook: bool) -> Result<()> {
        let conversation_root = tempfile::tempdir()?;
        let runtime_root = tempfile::tempdir()?;
        let conversations: Arc<dyn echo_core::memory::ConversationStore> = Arc::new(
            crate::memory::FileConversationStore::new(conversation_root.path())?,
        );
        let runtime = Arc::new(crate::state::FileRuntimeStateStore::new(
            runtime_root.path(),
        )?);
        let entered = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        let entered_hook = Arc::clone(&entered);
        let release_hook = Arc::clone(&release);
        let mut agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new().with_response("draft answer")))
            .conversation_id("stop-cancel")
            .build()?;
        agent.set_conversation_store(Arc::clone(&conversations));
        agent.set_state_store(runtime);
        agent.hook_registry().write().await.set_programmatic_hook(
            "blocking-stop",
            &[crate::skills::hooks::HookEvent::Stop],
            Arc::new(move |_context| {
                let entered = Arc::clone(&entered_hook);
                let release = Arc::clone(&release_hook);
                Box::pin(async move {
                    entered.notify_one();
                    release.notified().await;
                    let mut result = crate::skills::hooks::HookResult::allow();
                    if continue_hook {
                        result.continue_reason = Some("keep working".to_string());
                    }
                    result
                })
            }),
        );

        let cancel = crate::agent::CancellationToken::new();
        let stream = agent
            .execute_stream_with_cancel("run", cancel.clone())
            .await?;
        tokio::time::timeout(std::time::Duration::from_secs(2), entered.notified())
            .await
            .map_err(|_| ReactError::Other("stop hook did not start".to_string()))?;
        cancel.cancel();
        release.notify_one();
        let events = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            stream.collect::<Vec<_>>(),
        )
        .await
        .map_err(|_| ReactError::Other("stop cancellation did not settle".to_string()))?;
        assert!(
            events
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::Cancelled)))
        );
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::FinalAnswer(_))))
        );
        let messages = echo_core::memory::ConversationStore::get_messages(
            conversations.as_ref(),
            "stop-cancel",
        )
        .await?;
        assert!(!messages.iter().any(|message| {
            message
                .content
                .as_deref()
                .is_some_and(|content| content.contains("draft answer"))
        }));
        Ok(())
    }

    #[tokio::test]
    async fn schema_retry_note_follows_every_tool_result_in_its_batch() -> Result<()> {
        // 原2轮预算仍保负控；原生修正回复需要第三个真实模型请求，不把预算耗尽当成功。
        for limit in [2, 3] {
            let call = |id: &str| crate::llm::types::ToolCall {
                provider_source: None,
                id: id.into(),
                call_type: "function".into(),
                function: crate::llm::types::FunctionCall {
                    name: "sequential_marker".into(),
                    arguments: "{}".into(),
                },
            };
            let llm = Arc::new(
                MockLlmClient::new()
                    .then_tool_calls(vec![call("earlier"), call("later")])
                    .with_stream_script(native_response_script(
                        "invalid-after-tools",
                        &[(
                            echo_core::agent::AssistantPhase::FinalAnswer,
                            r#"{"age":"wrong"}"#,
                        )],
                    )?)
                    .with_stream_script(native_response_script(
                        "corrected-after-tools",
                        &[(
                            echo_core::agent::AssistantPhase::FinalAnswer,
                            r#"{"age":28}"#,
                        )],
                    )?),
            );
            let agent=ReactAgentBuilder::new().llm_client(llm.clone())
                .model_profile(echo_core::llm::capabilities::ModelProfile::from_provider_name("mock-model","openai"))
                .response_format(crate::llm::ResponseFormat::json_schema("person",serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]})))
                .tool(Box::new(SequentialMarkerTool)).max_iterations(limit).build()?;
            let events = collect_events(&agent, "run").await;
            let result_ids: Vec<_> = events
                .iter()
                .filter_map(|event| match event {
                    AgentEvent::ToolResult {
                        call_id, result, ..
                    } if result.success => Some(call_id.as_str()),
                    _ => None,
                })
                .collect();
            assert_eq!(result_ids, vec!["earlier", "later"]);
            let calls = llm.all_calls();
            let post_tools = calls
                .get(1)
                .ok_or_else(|| ReactError::Other("post-tools request missing".into()))?;
            assert_eq!(
                post_tools
                    .iter()
                    .filter_map(|message| message.tool_call_id.as_deref())
                    .collect::<Vec<_>>(),
                vec!["earlier", "later"]
            );
            assert!(
                !post_tools.iter().any(|message| message
                    .text_content()
                    .is_some_and(|text| text.contains("[runtime_context:StructuredOutput:Retry]"))),
                "工具回填之前没有最终候选schema重试"
            );
            if limit == 2 {
                assert_native_runtime_terminal(
                    &events,
                    echo_core::agent::ExecutionStatusKind::Failed,
                );
                assert_eq!(llm.call_count(), 2);
                let error=events.iter().position(|event|matches!(event,AgentEvent::Error{message,..} if message.contains("does not match JSON Schema")));
                let last_tool = events
                    .iter()
                    .rposition(|event| matches!(event, AgentEvent::ToolResult { .. }));
                assert!(
                    last_tool
                        .zip(error)
                        .is_some_and(|(tool, error)| tool < error),
                    "原预算下真实schema失败也只能在批次结果后：{events:?}"
                );
            } else {
                assert!(
                    matches!(last_confirmed_final(&events),Some(AgentEvent::FinalAnswer(answer)) if answer==r#"{"age":28}"#)
                );
                assert_eq!(llm.call_count(), 3);
                let repair = calls
                    .get(2)
                    .ok_or_else(|| ReactError::Other("schema repair request missing".into()))?;
                let retry = repair
                    .iter()
                    .position(|message| {
                        message.text_content().is_some_and(|text| {
                            text.contains("[runtime_context:StructuredOutput:Retry]")
                        })
                    })
                    .ok_or_else(|| ReactError::Other("schema retry note missing".into()))?;
                let positions: Vec<_> = ["earlier", "later"]
                    .into_iter()
                    .map(|id| {
                        repair
                            .iter()
                            .position(|message| message.tool_call_id.as_deref() == Some(id))
                            .ok_or_else(|| ReactError::Other(format!("tool result missing: {id}")))
                    })
                    .collect::<Result<Vec<_>>>()?;
                assert!(
                    positions
                        .first()
                        .zip(positions.get(1))
                        .is_some_and(|(first, second)| first < second && *second < retry)
                );
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn strict_schema_exhaustion_fails_without_final_answer() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().with_response(r#"{"age":"private-value"}"#));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    "mock-model",
                    "openai",
                ),
            )
            .response_format(crate::llm::ResponseFormat::json_schema(
                "person",
                serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
            ))
            .max_iterations(1)
            .build()?;

        let events = collect_events(&agent, "run").await;
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        assert!(events.iter().any(|event| matches!(
            event,
            AgentEvent::Error { message, .. }
                if message.contains("does not match JSON Schema")
                    && !message.contains("private-value")
        )));
        assert_eq!(llm.call_count(), 1);
        Ok(())
    }

    #[tokio::test]
    async fn structured_input_guard_block_is_failure_in_stream_and_execute() -> Result<()> {
        let mut agent = ReactAgent::new(
            AgentConfig::new("mock-model", "guarded", "system")
                .response_format(crate::llm::ResponseFormat::JsonObject),
        );
        let mut guards = GuardManager::new();
        guards.add(Arc::new(BlockingGuard));
        agent.set_guard_manager(guards);

        let events = collect_events(&agent, "blocked input").await;
        assert!(
            events
                .iter()
                .any(|event| matches!(event, AgentEvent::Error { .. }))
        );
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        assert!(agent.execute("blocked input").await.is_err());
        Ok(())
    }

    #[tokio::test]
    async fn structured_prompt_hook_block_is_failure_in_stream_and_execute() -> Result<()> {
        let mut definition = crate::skills::hooks::HooksDefinition::default();
        definition.add_rules(
            crate::skills::hooks::HookEvent::UserPromptSubmit,
            vec![crate::skills::hooks::HookRule {
                matcher: String::new(),
                hooks: vec![crate::skills::hooks::HookAction::Permission {
                    decision: "deny".to_string(),
                    reason: Some("not allowed".to_string()),
                    suggestions: Vec::new(),
                }],
            }],
        );
        let mut registry = crate::skills::hooks::HookRegistry::new();
        registry.register("structured-blocker", "/tmp", definition);
        let mut agent = ReactAgent::new(
            AgentConfig::new("mock-model", "hooked", "system")
                .response_format(crate::llm::ResponseFormat::JsonObject),
        );
        agent.set_hook_registry(Arc::new(tokio::sync::RwLock::new(registry)));

        let events = collect_events(&agent, "blocked input").await;
        assert!(
            events
                .iter()
                .any(|event| matches!(event, AgentEvent::Error { .. }))
        );
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        assert!(agent.execute("blocked input").await.is_err());
        Ok(())
    }

    #[tokio::test]
    async fn structured_schema_failure_settles_managed_terminal_checkpoint() -> Result<()> {
        let conversation_root = tempfile::tempdir()?;
        let runtime_root = tempfile::tempdir()?;
        let conversations = Arc::new(crate::memory::FileConversationStore::new(
            conversation_root.path(),
        )?);
        let runtime = Arc::new(crate::state::FileRuntimeStateStore::new(
            runtime_root.path(),
        )?);
        let llm = Arc::new(MockLlmClient::new().with_response(r#"{"age":"wrong"}"#));
        let mut agent = ReactAgent::new(
            AgentConfig::new("mock-model", "schema-agent", "system")
                .conversation_id("schema-failure")
                .model_profile(
                    echo_core::llm::capabilities::ModelProfile::from_provider_name(
                        "mock-model",
                        "openai",
                    ),
                )
                .response_format(crate::llm::ResponseFormat::json_schema(
                    "person",
                    serde_json::json!({"type":"object","properties":{"age":{"type":"integer"}},"required":["age"]}),
                ))
                .max_iterations(1),
        )
        .with_llm_client(llm);
        agent.set_conversation_store(conversations);
        agent.set_state_store(runtime.clone());

        let events = collect_events(&agent, "run").await;
        assert!(
            events
                .iter()
                .any(|event| matches!(event, AgentEvent::Error { .. }))
        );
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        let checkpoint = crate::state::RuntimeStateStore::load_runtime_state(
            runtime.as_ref(),
            "schema-failure",
            "schema-failure",
        )
        .await?
        .and_then(|state| state.checkpoint)
        .ok_or_else(|| ReactError::Other("schema failure checkpoint missing".to_string()))?;
        assert!(
            checkpoint
                .blocked_reason
                .as_deref()
                .is_some_and(|reason| reason.contains("does not match JSON Schema"))
        );
        Ok(())
    }

    #[tokio::test]
    async fn cancellation_during_stop_hook_does_not_project_assistant_draft() -> Result<()> {
        assert_cancelled_stop_hook_does_not_project_draft(false).await
    }

    #[tokio::test]
    async fn cancellation_during_stop_continuation_does_not_project_assistant_draft() -> Result<()>
    {
        assert_cancelled_stop_hook_does_not_project_draft(true).await
    }

    #[tokio::test]
    async fn invalid_strict_schema_is_rejected_before_react_model_call() -> Result<()> {
        let llm = Arc::new(MockLlmClient::new().with_response(r#"{"age":28}"#));
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(
                echo_core::llm::capabilities::ModelProfile::from_provider_name(
                    "mock-model",
                    "openai",
                ),
            )
            .response_format(crate::llm::ResponseFormat::json_schema(
                "invalid",
                serde_json::json!({"type":7}),
            ))
            .build()?;

        let events = collect_events(&agent, "run").await;
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        assert!(events.iter().any(|event| matches!(
            event,
            AgentEvent::Error { message, .. } if message.contains("invalid JSON Schema")
        )));
        assert_eq!(llm.call_count(), 0);
        Ok(())
    }

    #[tokio::test]
    async fn final_only_falls_back_to_empty_tool_surface_when_none_is_unsupported() -> Result<()> {
        let usage = crate::llm::types::Usage {
            prompt_tokens: Some(6),
            completion_tokens: Some(5),
            total_tokens: Some(11),
            ..crate::llm::types::Usage::default()
        };
        let llm = Arc::new(
            MockLlmClient::new()
                .then_tool_call_with_usage("blocked", "mock_calc", r#"{"x":1}"#, usage)
                .with_response("fallback final"),
        );
        let profile =
            echo_core::llm::capabilities::ModelProfile::from_provider_name("local-model", "ollama");
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .model_profile(profile)
            .tool(Box::new(
                MockTool::new("mock_calc").with_response("must not run"),
            ))
            .max_iterations(3)
            .run_budget(echo_core::agent::RunBudgetPolicy {
                iteration_wind_down_remaining: None,
                max_model_tokens: Some(10),
            })
            .build()?;

        let events = collect_events(&agent, "run").await;
        assert!(
            matches!(last_confirmed_final(&events), Some(AgentEvent::FinalAnswer(text)) if text == "fallback final")
        );
        assert_eq!(llm.all_tool_choices(), vec![None, None]);
        let tool_counts = llm.all_tool_counts();
        assert!(tool_counts.first().is_some_and(|count| *count > 0));
        assert_eq!(tool_counts.get(1), Some(&0));
        Ok(())
    }

    #[tokio::test]
    async fn missing_provider_usage_does_not_fake_token_budget_exhaustion() {
        let llm = MockLlmClient::new()
            .then_tool_call("allowed", "mock_calc", r#"{"x":1}"#)
            .with_response("done");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .tool(Box::new(MockTool::new("mock_calc").with_response("1")))
            .run_budget(echo_core::agent::RunBudgetPolicy {
                iteration_wind_down_remaining: None,
                max_model_tokens: Some(1),
            })
            .build()
            .expect("agent builds");

        let events = collect_events(&agent, "run").await;
        assert!(
            events
                .iter()
                .any(|event| matches!(event, AgentEvent::ToolCall { .. }))
        );
        assert!(!events.iter().any(|event| {
            matches!(
                event,
                AgentEvent::BudgetDecision {
                    decision: echo_core::agent::BudgetDecision::FinalOnly,
                    ..
                }
            )
        }));
    }

    #[tokio::test]
    async fn schema_overhead_compacts_history_before_model_admission() -> Result<()> {
        use echo_core::tokenizer::{HeuristicTokenizer, Tokenizer};

        let base = HeuristicTokenizer;
        let history: Vec<Message> = (0..6)
            .map(|index| Message::user(format!("history-{index} {}", "old ".repeat(80))))
            .collect();
        let history_tokens = history.iter().fold(0usize, |total, message| {
            total.saturating_add(message.content.estimated_tokens(&base))
        });
        let format = crate::llm::ResponseFormat::json_schema(
            "large_string",
            serde_json::json!({
                "type": "string",
                "description": "schema guidance ".repeat(60)
            }),
        );
        let format_json = serde_json::to_string(&format)?;
        let format_tokens = base.count_tokens(&format_json);
        let window = history_tokens.saturating_add(150);
        assert!(format_tokens > 150);
        assert!(format_tokens < window / 2);

        for budget in [
            echo_core::budget::TokenBudgetConfig::default(),
            echo_core::budget::TokenBudgetConfig::disabled(),
        ] {
            let llm = Arc::new(MockLlmClient::new().with_response("\"done\""));
            let config = AgentConfig::new("mock-model", "schema-compaction", "sys")
                .auto_project_rules(false)
                .enable_tool(false)
                .model_profile(
                    echo_core::llm::capabilities::ModelProfile::from_provider_name(
                        "mock-model",
                        "openai",
                    ),
                )
                .response_format(format.clone())
                .token_limit(window)
                .token_budget(budget);
            let mut agent = ReactAgent::new(config);
            agent.set_llm_client(llm.clone());
            agent
                .set_compressor(crate::compression::compressor::SlidingWindowCompressor::new(1))
                .await;
            {
                let mut context = agent.memory.context.lock().await;
                for message in &history {
                    context.push(message.clone());
                }
            }

            let events = collect_events_result(&agent, "current request").await?;
            assert!(
                events
                    .iter()
                    .any(|event| matches!(event, AgentEvent::ContextCompressed { .. }))
            );
            assert!(events.iter().any(|event| {
                matches!(event, AgentEvent::FinalAnswer(answer) if answer == "\"done\"")
            }));
            assert_eq!(llm.call_count(), 1);
        }
        Ok(())
    }

    /// When the mock LLM exhausts its response queue (returns EmptyResponse
    /// error), the loop must terminate gracefully with an Error event rather
    /// than hanging or panicking. Guards the empty-response / error branch.
    #[tokio::test]
    async fn run_core_loop_empty_llm_response_terminates_gracefully() {
        // No preset responses — first LLM call yields EmptyResponse error.
        let llm = MockLlmClient::new();
        let agent = agent_with_mock_llm(llm);

        // Collect raw results (may include Err — the point of this test is
        // graceful termination, not a specific event shape).
        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "anything".into(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await
            .expect("stream starts");
        let results = tokio::time::timeout(
            std::time::Duration::from_secs(5),
            stream.collect::<Vec<_>>(),
        )
        .await;

        // The loop must TERMINATE within the timeout — not hang forever on
        // repeated retries of an empty mock queue.
        assert!(
            results.is_ok(),
            "stream must terminate, not hang, on empty LLM response"
        );
    }

    /// Phase 3: verify that a running LLM call responds to cancellation.
    /// Uses `MockLlmClient::with_delay` to simulate a slow LLM (30s), then
    /// cancels the agent's token mid-flight. The stream must terminate well
    /// before the 30s delay — proving the cancel propagated to the LLM layer.
    #[tokio::test]
    async fn q_flt_v05_cancellation_stops_the_provider_without_final_success() {
        use std::time::Duration;

        use crate::agent::CancellationToken;

        // A mock LLM that sleeps 30s before responding, but honors cancel.
        let llm = MockLlmClient::new()
            .with_response("slow answer")
            .with_delay(Duration::from_secs(30));
        let agent = agent_with_mock_llm(llm);

        let cancel = CancellationToken::new();
        // Start streaming — the LLM call will block for 30s unless cancelled.
        let stream_fut = agent.chat_stream_with_cancel("hello", cancel.clone());

        // Give the stream a moment to reach the LLM call.
        let stream = tokio::time::timeout(Duration::from_secs(2), stream_fut)
            .await
            .expect("stream init should not hang")
            .expect("stream should start");

        // Cancel after a short delay.
        tokio::time::sleep(Duration::from_millis(100)).await;
        cancel.cancel();

        // Collect events with a short timeout — must terminate WAY before 30s.
        let mut events = Vec::new();
        let collect_result = tokio::time::timeout(Duration::from_secs(5), async {
            let mut stream = stream;
            use futures::StreamExt;
            while let Some(ev) = stream.next().await {
                events.push(ev);
            }
        })
        .await;

        assert!(
            collect_result.is_ok(),
            "stream must terminate within 5s after cancel (not wait for 30s delay)"
        );

        // The stream should NOT have produced a FinalAnswer (it was cancelled
        // before the LLM could respond).
        let has_final = events
            .iter()
            .any(|e| matches!(e, Ok(AgentEvent::FinalAnswer { .. })));
        assert!(!has_final, "cancelled stream must not emit FinalAnswer");
        assert!(matches!(
            agent.steer_input(None, Message::user("late steer".to_string())),
            Err(crate::agent::TurnSteerError::NoActiveTurn)
        ));
    }

    #[tokio::test]
    async fn cancellation_drains_running_tool_before_abandoning_turn() -> Result<()> {
        use futures::StreamExt;

        let finished = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let llm = MockLlmClient::new()
            .then_tool_call("call-1", "delayed_terminal", "{}")
            .with_response("unused");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("Run the requested tool.")
            .tool(Box::new(DelayedTerminalTool {
                started: Arc::new(tokio::sync::Notify::new()),
                completed: Arc::new(tokio::sync::Notify::new()),
                finished: finished.clone(),
            }))
            .build()?;
        let cancel = crate::agent::CancellationToken::new();
        let mut stream = agent
            .execute_stream_with_cancel("persist terminal state", cancel.clone())
            .await?;

        let saw_tool_call = tokio::time::timeout(std::time::Duration::from_secs(1), async {
            while let Some(event) = stream.next().await {
                if matches!(event?, AgentEvent::ToolCall { .. }) {
                    return Ok::<bool, crate::error::ReactError>(true);
                }
            }
            Ok(false)
        })
        .await
        .map_err(|_| crate::error::ReactError::Other("tool call was not emitted".to_string()))??;
        assert!(saw_tool_call);
        cancel.cancel();

        tokio::time::timeout(std::time::Duration::from_secs(1), async {
            while let Some(event) = stream.next().await {
                event?;
            }
            Ok::<(), crate::error::ReactError>(())
        })
        .await
        .map_err(|_| {
            crate::error::ReactError::Other("cancelled tool drain timed out".to_string())
        })??;

        assert!(finished.load(std::sync::atomic::Ordering::Acquire));
        Ok(())
    }

    struct StallingToolIntervention {
        entered: Arc<std::sync::atomic::AtomicBool>,
        tool_name: Option<&'static str>,
        release: Arc<tokio::sync::Notify>,
    }

    impl crate::agent::InterventionCallback for StallingToolIntervention {
        fn on_tool_call<'a>(
            &'a self,
            _agent: &'a str,
            tool: &'a str,
            _args: &'a serde_json::Value,
        ) -> futures::future::BoxFuture<'a, crate::agent::InterventionResult> {
            if self.tool_name.is_none_or(|name| name == tool) {
                self.entered
                    .store(true, std::sync::atomic::Ordering::Release);
                let release = self.release.clone();
                Box::pin(async move {
                    release.notified().await;
                    // This controlled pre-execution owner ends without
                    // admitting Tool work after the batch cancellation.
                    crate::agent::InterventionResult::cancel()
                })
            } else {
                Box::pin(async { crate::agent::InterventionResult::allow() })
            }
        }
    }

    #[tokio::test]
    async fn outer_timeout_during_pre_execution_stage_records_one_complete_tool_trace() -> Result<()>
    {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let entered = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let release = Arc::new(tokio::sync::Notify::new());
        let store = Arc::new(InMemoryRunStore::new());
        let audit = Arc::new(crate::audit::InMemoryAuditLogger::new());
        let audit_callback = Arc::new(crate::audit::AuditCallback::new(
            audit.clone(),
            "agent",
            Some("prehook-timeout".to_string()),
        ));
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new()
                    .then_tool_call(
                        "prehook-timeout",
                        "bounded_tool",
                        r#"{"label":"admitted","password":"tiny-secret"}"#,
                    )
                    .with_response("unused"),
            ))
            .system_prompt("Execute the requested tool.")
            .tool(Box::new(
                MockTool::new("bounded_tool").with_response("never"),
            ))
            .intervention_callback(Arc::new(StallingToolIntervention {
                entered: Arc::clone(&entered),
                release: release.clone(),
                tool_name: None,
            }))
            .tool_execution(crate::tools::ToolExecutionConfig {
                timeout_ms: 10,
                retry_on_fail: false,
                ..Default::default()
            })
            .callback(audit_callback)
            .with_run_store(store.clone())
            .build()?;
        let stream = agent.execute_stream("run bounded tool").await?;
        let collection = stream.collect::<Vec<_>>();
        tokio::pin!(collection);
        // The 10ms configuration plus the existing 250ms batch overhead may
        // record timeout, but the admitted callback still owns its future.
        let observed =
            tokio::time::timeout(std::time::Duration::from_millis(300), &mut collection).await;
        let returned_before_original_callback = observed.is_ok();
        release.notify_one();
        let events = match observed {
            Ok(events) => events,
            Err(_) => tokio::time::timeout(std::time::Duration::from_secs(3), &mut collection)
                .await
                .map_err(|_| ReactError::Other("outer timeout did not settle".to_string()))?,
        }
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
        assert!(
            !returned_before_original_callback,
            "timeout observation must not drop the original admitted callback"
        );
        assert!(entered.load(std::sync::atomic::Ordering::Acquire));
        let call_position = events.iter().position(|event| {
            matches!(
                event,
                AgentEvent::ToolCall { call_id, .. } if call_id == "prehook-timeout"
            )
        });
        let result_position = events.iter().position(|event| {
            matches!(
                event,
                AgentEvent::ToolResult { call_id, .. } if call_id == "prehook-timeout"
            )
        });
        assert!(
            matches!((call_position, result_position), (Some(call), Some(result)) if call < result)
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| matches!(
                    event,
                    AgentEvent::ToolCall { call_id, .. } if call_id == "prehook-timeout"
                ))
                .count(),
            1
        );
        let envelopes = crate::agent::envelope_event_stream(
            Box::pin(futures::stream::iter(events.clone().into_iter().map(Ok))),
            crate::agent::EventIdentity::for_run("prehook-timeout-trajectory")?,
        )
        .collect::<Vec<_>>()
        .await
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
        assert!(crate::agent::validate_event_trajectory(&envelopes).is_empty());
        assert!(events.iter().any(|event| matches!(
            event,
            AgentEvent::ToolResult { call_id, result, .. }
                if call_id == "prehook-timeout" && !result.success
        )));
        let summary = store
            .list_all(1)
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| ReactError::Other("missing tool trace".to_string()))?;
        let run = store
            .load(&summary.run_id)
            .await?
            .ok_or_else(|| ReactError::Other("missing trace body".to_string()))?;
        for kind in ["call", "result", "error"] {
            let count = run
                .events
                .iter()
                .filter(|event| match (kind, event) {
                    ("call", RunEvent::ToolCall { call_id, .. })
                    | ("result", RunEvent::ToolResult { call_id, .. })
                    | ("error", RunEvent::ToolError { call_id, .. }) => {
                        call_id == "prehook-timeout"
                    }
                    _ => false,
                })
                .count();
            assert_eq!(count, 1, "expected one {kind} event: {:?}", run.events);
        }
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::ToolExecutionSkipped { call_id, name, .. }
                if call_id == "prehook-timeout" && name == "bounded_tool"
        )));
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::ToolError { call_id, failure: Some(failure), .. }
                if call_id == "prehook-timeout"
                    && failure.side_effect == crate::tools::ToolSideEffect::None
        )));
        let audit_events =
            crate::audit::AuditLogger::query(audit.as_ref(), crate::audit::AuditFilter::default())
                .await?;
        let tool_audits = audit_events
            .iter()
            .filter_map(|event| match &event.event_type {
                crate::audit::AuditEventType::ToolCall {
                    call_id,
                    input,
                    success,
                    ..
                } => Some((call_id.as_deref(), input, *success)),
                _ => None,
            })
            .collect::<Vec<_>>();
        assert_eq!(tool_audits.len(), 1);
        assert!(matches!(
            tool_audits.first(),
            Some((Some("prehook-timeout"), input, false))
                if input.get("label") == Some(&serde_json::json!("admitted"))
                    && input.get("password") == Some(&serde_json::json!("[REDACTED]"))
        ));
        Ok(())
    }

    #[tokio::test]
    async fn concurrent_timeout_preserves_completed_peer_and_settles_all_assistant_calls()
    -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let entered = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let release = Arc::new(tokio::sync::Notify::new());
        let store = Arc::new(InMemoryRunStore::new());
        let llm = MockLlmClient::new()
            .then_tool_calls(vec![
                ToolCall {
                    provider_source: None,
                    id: "slow-prehook".to_string(),
                    call_type: "function".to_string(),
                    function: FunctionCall {
                        name: "slow_tool".to_string(),
                        arguments: "{}".to_string(),
                    },
                },
                ToolCall {
                    provider_source: None,
                    id: "fast-completed".to_string(),
                    call_type: "function".to_string(),
                    function: FunctionCall {
                        name: "fast_tool".to_string(),
                        arguments: "{}".to_string(),
                    },
                },
            ])
            .with_response("unused");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("Run both tools.")
            .tool(Box::new(MockTool::new("slow_tool").with_response("never")))
            .tool(Box::new(
                MockTool::new("fast_tool").with_response("committed"),
            ))
            .intervention_callback(Arc::new(StallingToolIntervention {
                entered: Arc::clone(&entered),
                release: release.clone(),
                tool_name: Some("slow_tool"),
            }))
            .tool_execution(crate::tools::ToolExecutionConfig {
                timeout_ms: 10,
                retry_on_fail: false,
                ..Default::default()
            })
            .with_run_store(store.clone())
            .build()?;
        let stream = agent.execute_stream("run both").await?;
        let collection = stream.collect::<Vec<_>>();
        tokio::pin!(collection);
        // The 10ms configuration plus the existing 250ms batch overhead may
        // record timeout, but the admitted callback still owns its future.
        let observed =
            tokio::time::timeout(std::time::Duration::from_millis(300), &mut collection).await;
        let returned_before_original_callback = observed.is_ok();
        release.notify_one();
        let events = match observed {
            Ok(events) => events,
            Err(_) => tokio::time::timeout(std::time::Duration::from_secs(3), &mut collection)
                .await
                .map_err(|_| ReactError::Other("concurrent timeout did not settle".to_string()))?,
        }
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
        assert!(
            !returned_before_original_callback,
            "timeout observation must not drop the original admitted callback"
        );
        assert!(entered.load(std::sync::atomic::Ordering::Acquire));
        let results = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::ToolResult {
                    call_id, result, ..
                } => Some((call_id.as_str(), result.success, result.output.as_str())),
                _ => None,
            })
            .collect::<Vec<_>>();
        assert_eq!(results.len(), 2, "{events:?}");
        assert!(matches!(results.first(), Some(("slow-prehook", false, _))));
        assert_eq!(results.get(1), Some(&("fast-completed", true, "committed")));
        let context_results = agent
            .memory
            .context
            .lock()
            .await
            .messages()
            .iter()
            .filter_map(|message| message.tool_call_id.as_deref())
            .map(str::to_string)
            .collect::<Vec<_>>();
        assert_eq!(context_results, ["slow-prehook", "fast-completed"]);
        let envelopes = crate::agent::envelope_event_stream(
            Box::pin(futures::stream::iter(events.clone().into_iter().map(Ok))),
            crate::agent::EventIdentity::for_run("concurrent-timeout-trajectory")?,
        )
        .collect::<Vec<_>>()
        .await
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
        assert!(crate::agent::validate_event_trajectory(&envelopes).is_empty());

        let summary = store
            .list_all(1)
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| ReactError::Other("trace missing".to_string()))?;
        let run = store
            .load(&summary.run_id)
            .await?
            .ok_or_else(|| ReactError::Other("trace body missing".to_string()))?;
        for id in ["slow-prehook", "fast-completed"] {
            assert_eq!(
                run.events
                    .iter()
                    .filter(|event| matches!(event, RunEvent::ToolResult { call_id, .. } if call_id == id))
                    .count(),
                1
            );
        }
        assert!(run.events.iter().any(|event| matches!(
            event,
            RunEvent::ToolResult { call_id, success: true, .. }
                if call_id == "fast-completed"
        )));
        Ok(())
    }

    #[tokio::test]
    async fn q_flt_v06_dropping_consumer_drains_upstream_and_releases_turn() -> Result<()> {
        let started = Arc::new(tokio::sync::Notify::new());
        let completed = Arc::new(tokio::sync::Notify::new());
        let finished = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let llm = MockLlmClient::new()
            .then_tool_call("drop-1", "delayed_terminal", "{}")
            .with_response("second run completed");
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .tool(Box::new(DelayedTerminalTool {
                started: Arc::clone(&started),
                completed: Arc::clone(&completed),
                finished: Arc::clone(&finished),
            }))
            .build()?;
        let mut stream = agent.execute_stream("start durable tool").await?;
        let saw_call = tokio::time::timeout(std::time::Duration::from_secs(1), async {
            while let Some(event) = stream.next().await {
                if matches!(event?, AgentEvent::ToolCall { .. }) {
                    return Ok::<bool, ReactError>(true);
                }
            }
            Ok(false)
        })
        .await
        .map_err(|_| ReactError::Other("durable tool call was not emitted".to_string()))??;
        assert!(saw_call);

        tokio::time::timeout(std::time::Duration::from_secs(1), started.notified())
            .await
            .map_err(|_| ReactError::Other("durable tool did not start".to_string()))?;

        drop(stream);

        tokio::time::timeout(std::time::Duration::from_secs(1), completed.notified())
            .await
            .map_err(|_| ReactError::Other("dropped stream did not drain its tool".to_string()))?;
        assert!(finished.load(std::sync::atomic::Ordering::Acquire));

        let answer = tokio::time::timeout(
            std::time::Duration::from_secs(1),
            agent.execute("run after consumer disconnect"),
        )
        .await
        .map_err(|_| ReactError::Other("dropped stream retained the turn".to_string()))??;
        assert_eq!(answer, "second run completed");
        assert!(matches!(
            agent.steer_input(None, Message::user("late steer".to_string())),
            Err(crate::agent::TurnSteerError::NoActiveTurn)
        ));
        Ok(())
    }

    #[tokio::test]
    async fn steer_during_llm_call_continues_same_turn_with_new_input() -> Result<()> {
        use futures::StreamExt;
        use std::time::Duration;

        let llm = Arc::new(
            MockLlmClient::new()
                .with_responses(["draft answer", "corrected answer"])
                .with_delay(Duration::from_millis(150)),
        );
        let mut agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .system_prompt("You are a test assistant.")
            .build()?;
        agent.config_mut().max_iterations = 4;
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some("turn-steer-1".to_string()),
                turn_id: Some("turn-steer-1".to_string()),
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            runtime_state_id: None,
            transcript_generation_id: None,
            working_dir: None,
            cancel: None,
            disabled_tools: None,
            allowed_tools: None,
            tool_access: None,
            visible_tools: None,
            run_budget: None,
            history: None,
            resource_guards: Vec::new(),
            input_lifecycle: None,
        };
        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "initial request".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await?;

        tokio::time::sleep(Duration::from_millis(30)).await;
        let mut receipt = agent
            .steer_input_tracked(
                Some("turn-steer-1"),
                Message::user("steer correction".to_string()),
            )
            .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;
        assert_eq!(receipt.turn_id(), "turn-steer-1");
        assert_eq!(receipt.state(), crate::agent::AgentSteerState::Accepted);

        let events = stream.collect::<Vec<_>>().await;
        assert!(events.iter().any(|event| {
            matches!(event, Ok(AgentEvent::FinalAnswer(answer)) if answer == "corrected answer")
        }));
        assert_eq!(llm.call_count(), 2);
        let last_messages = llm.last_messages().unwrap_or_default();
        assert!(
            last_messages
                .iter()
                .any(|message| { message.content.as_text().as_deref() == Some("draft answer") })
        );
        assert!(
            last_messages.iter().any(|message| {
                message.content.as_text().as_deref() == Some("steer correction")
            })
        );
        assert_eq!(
            receipt.wait_for_turn_settled().await,
            crate::agent::AgentSteerState::TurnSettled {
                outcome: crate::agent::AgentSteerTurnOutcome::Completed,
                drained: true,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn output_guard_does_not_block_superseded_text_before_steer() -> Result<()> {
        use std::time::Duration;

        let llm = Arc::new(
            MockLlmClient::new()
                .with_responses(["draft answer", "corrected answer"])
                .with_delay(Duration::from_millis(150)),
        );
        let mut agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .max_iterations(4)
            .build()?;
        let mut guards = GuardManager::new();
        guards.add(Arc::new(BlockDraftFinalGuard));
        agent.set_guard_manager(guards);

        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "initial request".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: None,
                },
                StreamMode::Chat,
            )
            .await?;
        tokio::time::sleep(Duration::from_millis(30)).await;
        let mut receipt = agent
            .steer_input_tracked(None, Message::user("steer correction".to_string()))
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let events = stream.collect::<Vec<_>>().await;
        assert!(events.iter().any(|event| matches!(
            event,
            Ok(AgentEvent::FinalAnswer(answer)) if answer == "corrected answer"
        )));
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::Error { .. })))
        );
        assert_eq!(llm.call_count(), 2);
        assert_eq!(
            receipt.wait_for_turn_settled().await,
            crate::agent::AgentSteerState::TurnSettled {
                outcome: crate::agent::AgentSteerTurnOutcome::Completed,
                drained: true,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn tracked_steer_reports_drain_before_provider_failure_terminal() -> Result<()> {
        use futures::StreamExt;
        use std::time::Duration;

        let llm = Arc::new(
            MockLlmClient::new()
                .with_response("draft before failure")
                .with_network_error("provider disconnected")
                .with_delay(Duration::from_millis(100)),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm)
            .system_prompt("You are a test assistant.")
            .build()?;
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime_state_id: None,
            transcript_generation_id: None,
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some("tracked-provider-failure".to_string()),
                turn_id: Some("tracked-provider-failure".to_string()),
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            working_dir: None,
            cancel: None,
            disabled_tools: None,
            allowed_tools: None,
            tool_access: None,
            visible_tools: None,
            run_budget: None,
            history: None,
            resource_guards: Vec::new(),
            input_lifecycle: None,
        };
        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "initial request".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await?;
        tokio::time::sleep(Duration::from_millis(20)).await;
        let mut receipt = agent
            .steer_input_tracked(
                Some("tracked-provider-failure"),
                Message::user("consume before provider failure".to_string()),
            )
            .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;

        assert_eq!(
            receipt.wait_for_drained().await,
            crate::agent::AgentSteerState::Drained
        );
        let events = stream.collect::<Vec<_>>().await;
        assert!(
            events
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::Error { .. })))
        );
        assert_eq!(
            receipt.wait_for_turn_settled().await,
            crate::agent::AgentSteerState::TurnSettled {
                outcome: crate::agent::AgentSteerTurnOutcome::Failed,
                drained: true,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn tracked_steer_typed_resource_survives_active_context_and_checkpoint() -> Result<()> {
        use echo_core::llm::types::LinkedResource;
        let agent = ReactAgent::new(AgentConfig::new("test-model", "agent", "system"));
        let lease = agent
            .turn_steer_mailbox
            .begin("resource-live-turn".to_string());
        lease.set_steerable(true);
        let mut snapshot = AgentSnapshot::from_agent(&agent);
        snapshot.current_turn_id = Some("resource-live-turn".to_string());
        snapshot.turn_steer_incarnation = Some(lease.incarnation());
        let message = Message::user_multimodal(vec![
            ContentPart::Text {
                text: "same text can also be an ordinary quotation".into(),
            },
            ContentPart::ResourceLink {
                resource: Box::new(LinkedResource {
                    annotations: None,
                    description: None,
                    mime_type: Some("text/plain".into()),
                    name: "input".into(),
                    size: Some(8),
                    title: None,
                    uri: "app-resource:identity".into(),
                    meta: Some(
                        serde_json::json!({"application_extension":{"identity":"opaque-producer-proof"}}),
                    ),
                }),
            },
        ]);
        let expected = serde_json::to_value(&message)?;
        let mut receipt = agent
            .steer_input_tracked(Some("resource-live-turn"), message)
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(
            snapshot
                .drain_steer_into_context(&agent.memory.context, None)
                .await,
            1
        );
        assert_eq!(
            receipt.wait_for_drained().await,
            crate::agent::AgentSteerState::Drained
        );
        // Physical turn is still live. Project from the actual active Context, not from a receipt/body match.
        let messages = agent.memory.context.lock().await.messages().to_vec();
        let rows = crate::memory::project_messages("branch", &messages)?;
        let restored = crate::memory::restore_messages(&rows)?;
        assert!(
            restored
                .iter()
                .any(|message| serde_json::to_value(message).ok().as_ref() == Some(&expected))
        );
        assert_eq!(receipt.state(), crate::agent::AgentSteerState::Drained);
        let mut checkpoint = crate::state::AgentCheckpoint::new("branch");
        checkpoint.messages_json =
            crate::state::AgentCheckpoint::serialize_payload(messages, None)?;
        let recovered = checkpoint.restore_messages()?;
        assert!(
            recovered
                .iter()
                .any(|message| serde_json::to_value(message).ok().as_ref() == Some(&expected))
        );
        // No terminal reconciliation runs before canonical Context and checkpoint already carry the link.
        lease.settle(crate::agent::AgentSteerTurnOutcome::Completed);
        Ok(())
    }

    #[tokio::test]
    async fn tracked_steer_reports_cancelled_after_real_drain() -> Result<()> {
        use futures::StreamExt;
        use std::time::Duration;

        let llm = Arc::new(
            MockLlmClient::new()
                .with_responses(["draft before cancellation", "unused final"])
                .with_delay(Duration::from_millis(100)),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm)
            .system_prompt("You are a test assistant.")
            .build()?;
        let cancel = crate::agent::CancellationToken::new();
        let invocation = echo_core::agent::AgentInvocationContext {
            runtime_state_id: None,
            transcript_generation_id: None,
            runtime: Some(echo_core::tools::ExternalRunContext {
                conversation_id: None,
                run_id: Some("tracked-cancel".to_string()),
                turn_id: Some("tracked-cancel".to_string()),
                execution_id: None,
                isolation_id: None,
                message_id: None,
                cancel: None,
                trace_sink: None,
                delegation_policy: None,
                resource_guards: Vec::new(),
                subagent_lineage: None,
                uplink: None,
            }),
            working_dir: None,
            cancel: Some(cancel.clone()),
            disabled_tools: None,
            allowed_tools: None,
            tool_access: None,
            visible_tools: None,
            run_budget: None,
            history: None,
            resource_guards: Vec::new(),
            input_lifecycle: None,
        };
        let stream = agent
            .run_stream_channel(
                StreamInit {
                    text: "initial request".to_string(),
                    message: None,
                    label: String::new(),
                    invocation: Some(invocation),
                },
                StreamMode::Chat,
            )
            .await?;
        tokio::time::sleep(Duration::from_millis(20)).await;
        let mut receipt = agent
            .steer_input_tracked(
                Some("tracked-cancel"),
                Message::user("consume before cancellation".to_string()),
            )
            .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;

        assert_eq!(
            receipt.wait_for_drained().await,
            crate::agent::AgentSteerState::Drained
        );
        cancel.cancel();
        let events = stream.collect::<Vec<_>>().await;
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, Ok(AgentEvent::FinalAnswer(_))))
        );
        assert_eq!(
            receipt.wait_for_turn_settled().await,
            crate::agent::AgentSteerState::TurnSettled {
                outcome: crate::agent::AgentSteerTurnOutcome::Cancelled,
                drained: true,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn tracked_steer_stays_accepted_behind_context_barrier() -> Result<()> {
        let agent = ReactAgent::new(AgentConfig::new("test-model", "agent", "system"));
        let lease = agent
            .turn_steer_mailbox
            .begin("context-barrier".to_string());
        lease.set_steerable(true);
        let mut snapshot = AgentSnapshot::from_agent(&agent);
        snapshot.current_turn_id = Some("context-barrier".to_string());
        snapshot.turn_steer_incarnation = Some(lease.incarnation());
        let snapshot = Arc::new(snapshot);
        let context = agent.memory.context.clone();
        let context_guard = context.lock().await;
        let mut receipt = agent
            .steer_input_tracked(
                Some("context-barrier"),
                Message::user("barrier input".to_string()),
            )
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert!(snapshot.has_pending_steer());
        assert_eq!(receipt.state(), crate::agent::AgentSteerState::Accepted);
        let drain = {
            let snapshot = snapshot.clone();
            let context = context.clone();
            tokio::spawn(async move { snapshot.drain_steer_into_context(&context, None).await })
        };

        tokio::task::yield_now().await;
        assert_eq!(receipt.state(), crate::agent::AgentSteerState::Accepted);
        assert!(!drain.is_finished());
        drop(context_guard);
        assert_eq!(
            drain
                .await
                .map_err(|error| ReactError::Other(format!("drain task failed: {error}")))?,
            1
        );
        assert_eq!(
            receipt.wait_for_drained().await,
            crate::agent::AgentSteerState::Drained
        );
        assert!(!snapshot.has_pending_steer());
        lease.settle(crate::agent::AgentSteerTurnOutcome::Completed);
        Ok(())
    }

    #[tokio::test]
    async fn tracked_turn_settlement_wins_before_blocked_context_drain() -> Result<()> {
        let agent = ReactAgent::new(AgentConfig::new("test-model", "agent", "system"));
        let lease = agent
            .turn_steer_mailbox
            .begin("settle-before-context".to_string());
        lease.set_steerable(true);
        let mut snapshot = AgentSnapshot::from_agent(&agent);
        snapshot.current_turn_id = Some("settle-before-context".to_string());
        snapshot.turn_steer_incarnation = Some(lease.incarnation());
        let snapshot = Arc::new(snapshot);
        let context = agent.memory.context.clone();
        let context_guard = context.lock().await;
        let mut receipt = agent
            .steer_input_tracked(
                Some("settle-before-context"),
                Message::user("must remain unconsumed".to_string()),
            )
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let drain = {
            let snapshot = snapshot.clone();
            let context = context.clone();
            tokio::spawn(async move { snapshot.drain_steer_into_context(&context, None).await })
        };

        tokio::task::yield_now().await;
        lease.settle(crate::agent::AgentSteerTurnOutcome::Cancelled);
        assert_eq!(
            receipt.wait_for_turn_settled().await,
            crate::agent::AgentSteerState::TurnSettled {
                outcome: crate::agent::AgentSteerTurnOutcome::Cancelled,
                drained: false,
            }
        );
        drop(context_guard);
        assert_eq!(
            drain
                .await
                .map_err(|error| ReactError::Other(format!("drain task failed: {error}")))?,
            0
        );
        Ok(())
    }

    #[tokio::test]
    async fn tracked_steer_same_id_stale_snapshot_cannot_drain_new_incarnation() -> Result<()> {
        let agent = ReactAgent::new(AgentConfig::new("test-model", "agent", "system"));
        let stale_lease = agent.turn_steer_mailbox.begin("same-id-drain".to_string());
        stale_lease.set_steerable(true);
        let mut stale_snapshot = AgentSnapshot::from_agent(&agent);
        stale_snapshot.current_turn_id = Some("same-id-drain".to_string());
        stale_snapshot.turn_steer_incarnation = Some(stale_lease.incarnation());

        let current_lease = agent.turn_steer_mailbox.begin("same-id-drain".to_string());
        current_lease.set_steerable(true);
        let mut receipt = agent
            .steer_input_tracked(
                Some("same-id-drain"),
                Message::user("new incarnation input".to_string()),
            )
            .map_err(|error| ReactError::Other(error.to_string()))?;
        let context = agent.memory.context.clone();

        assert!(!stale_snapshot.has_pending_steer());
        assert_eq!(
            stale_snapshot
                .drain_steer_into_context(&context, None)
                .await,
            0
        );
        assert_eq!(receipt.state(), crate::agent::AgentSteerState::Accepted);

        let mut current_snapshot = AgentSnapshot::from_agent(&agent);
        current_snapshot.current_turn_id = Some("same-id-drain".to_string());
        current_snapshot.turn_steer_incarnation = Some(current_lease.incarnation());
        assert!(current_snapshot.has_pending_steer());
        assert_eq!(
            current_snapshot
                .drain_steer_into_context(&context, None)
                .await,
            1
        );
        assert_eq!(
            receipt.wait_for_drained().await,
            crate::agent::AgentSteerState::Drained
        );
        current_lease.settle(crate::agent::AgentSteerTurnOutcome::Completed);
        drop(stale_lease);
        Ok(())
    }

    // ── M1: test-credibility re-basing (mock 隐身衣 removal) ────────────────
    // New fixtures drive the mock through the real provider wire shape:
    // content deltas followed by a separate terminal chunk carrying
    // finish_reason and usage (F-TST-01-P1-01), and concurrent batch results
    // emitted in call order (F-RCT-04-P1-01). Each fixture fails before its
    // fix and passes after.

    #[tokio::test]
    async fn stream_script_terminal_chunk_reports_usage() -> Result<()> {
        // Real providers report usage on a separate terminal chunk; the
        // loop-level `usage_reported` must be true only in that shape.
        let usage = crate::llm::types::Usage {
            prompt_tokens: Some(11),
            completion_tokens: Some(7),
            ..Default::default()
        };
        let llm = MockLlmClient::new().with_stream_script(vec![
            StreamChunk::Delta(DeltaMessage {
                role: Some("assistant".to_string()),
                content: Some("Hello world".to_string()),
                reasoning_content: None,
                reasoning_blocks: None,
                assistant_blocks: None,
                tool_calls: None,
            }),
            StreamChunk::Terminal {
                finish_reason: Some("stop".to_string()),
                usage: Some(usage),
            },
        ]);
        let agent = agent_with_mock_llm(llm);
        let events = collect_events(&agent, "Hi").await;

        let usage_event = events
            .iter()
            .find(|event| matches!(event, AgentEvent::LlmUsage { .. }))
            .ok_or_else(|| ReactError::Other("LlmUsage event missing".into()))?;
        match usage_event {
            AgentEvent::LlmUsage {
                prompt_tokens,
                completion_tokens,
                usage_reported,
                ..
            } => {
                assert!(usage_reported, "usage_reported must be true");
                assert_eq!(*prompt_tokens, 11);
                assert_eq!(*completion_tokens, 7);
            }
            _ => {
                return Err(ReactError::Other(
                    "usage lookup returned another event".into(),
                ));
            }
        }
        let last = last_confirmed_final(&events)
            .ok_or_else(|| ReactError::Other("confirmed final missing".into()))?;
        assert!(matches!(last, AgentEvent::FinalAnswer(t) if t == "Hello world"));
        Ok(())
    }

    #[tokio::test]
    async fn stream_script_without_usage_reports_false() {
        // The provider streamed content but never reported usage — the loop
        // must not fabricate a positive accounting (F-TST-01-P1-01's
        // single-chunk mock certified the impossible; this fixture pins the
        // honest negative).
        let llm = MockLlmClient::new().with_stream_script(vec![
            StreamChunk::Delta(DeltaMessage {
                role: Some("assistant".to_string()),
                content: Some("No usage here".to_string()),
                reasoning_content: None,
                reasoning_blocks: None,
                assistant_blocks: None,
                tool_calls: None,
            }),
            StreamChunk::Terminal {
                finish_reason: Some("stop".to_string()),
                usage: None,
            },
        ]);
        let agent = agent_with_mock_llm(llm);
        let events = collect_events(&agent, "Hi").await;

        let usage_event = events
            .iter()
            .find(|event| matches!(event, AgentEvent::LlmUsage { .. }))
            .expect("LlmUsage event must be emitted");
        match usage_event {
            AgentEvent::LlmUsage { usage_reported, .. } => {
                assert!(!usage_reported, "usage_reported must be false");
            }
            _ => unreachable!("matched LlmUsage above"),
        }
    }

    #[tokio::test]
    async fn concurrent_batch_results_follow_call_order() {
        // Two concurrent tool calls: call_1 is slow, call_2 is fast. Results
        // must be emitted and inserted into context in CALL order (stream
        // index order), not completion order — strict providers reject
        // misordered tool results with HTTP 400 (F-RCT-04-P1-01). Before the
        // fix the second request carried [call_2, call_1] results.
        let llm = MockLlmClient::new()
            .then_tool_calls(vec![
                ToolCall {
                    provider_source: None,
                    id: "call_1".to_string(),
                    call_type: "function".to_string(),
                    function: FunctionCall {
                        name: "slow_tool".to_string(),
                        arguments: r#"{}"#.to_string(),
                    },
                },
                ToolCall {
                    provider_source: None,
                    id: "call_2".to_string(),
                    call_type: "function".to_string(),
                    function: FunctionCall {
                        name: "fast_tool".to_string(),
                        arguments: r#"{}"#.to_string(),
                    },
                },
            ])
            .with_response("The result is 42.");

        let slow_tool = MockTool::new("slow_tool")
            .with_response("slow result")
            .with_delay(std::time::Duration::from_millis(60));
        let fast_tool = MockTool::new("fast_tool").with_response("fast result");

        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(llm))
            .system_prompt("You are a test assistant. Use tools when asked.")
            .tool(Box::new(slow_tool))
            .tool(Box::new(fast_tool))
            .build()
            .expect("agent builds");

        let events = collect_events(&agent, "Run both tools.").await;

        // The ToolResult events must arrive in call order.
        let result_ids: Vec<&str> = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::ToolResult { call_id, .. } => Some(call_id.as_str()),
                _ => None,
            })
            .collect();
        assert_eq!(
            result_ids,
            vec!["call_1", "call_2"],
            "batch results must be emitted in call order, got {result_ids:?}"
        );
        // And the final answer still arrives.
        assert!(
            events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(t) if t.contains("42")))
        );
    }

    struct SteerReturnBarrier {
        inner: MockLlmClient,
        entered: Arc<tokio::sync::Notify>,
        release: Arc<tokio::sync::Notify>,
    }

    impl crate::llm::LlmClient for SteerReturnBarrier {
        fn model_name(&self) -> &str {
            crate::llm::LlmClient::model_name(&self.inner)
        }

        fn chat(
            &self,
            request: crate::llm::ChatRequest,
        ) -> BoxFuture<'_, Result<crate::llm::ChatResponse>> {
            crate::llm::LlmClient::chat(&self.inner, request)
        }

        fn chat_stream(
            &self,
            request: crate::llm::ChatRequest,
        ) -> BoxFuture<'_, Result<futures::stream::BoxStream<'static, Result<crate::llm::ChatChunk>>>>
        {
            Box::pin(async move {
                let first = self.inner.call_count() == 0;
                let stream = crate::llm::LlmClient::chat_stream(&self.inner, request).await?;
                if first {
                    self.entered.notify_one();
                    self.release.notified().await;
                }
                Ok(stream)
            })
        }
    }

    struct SteerEffectTool {
        name: &'static str,
        path: std::path::PathBuf,
        parallel: bool,
        barrier: Option<(Arc<tokio::sync::Notify>, Arc<tokio::sync::Notify>)>,
    }

    impl crate::tools::Tool for SteerEffectTool {
        fn name(&self) -> &str {
            self.name
        }

        fn description(&self) -> &str {
            "Write one owned test sentinel after an optional physical-execution barrier"
        }

        fn parameters(&self) -> serde_json::Value {
            serde_json::json!({"type":"object","properties":{}})
        }

        fn allows_parallel_batch_execution(&self) -> bool {
            self.parallel
        }

        fn execute(
            &self,
            _parameters: crate::tools::ToolParameters,
        ) -> BoxFuture<'_, Result<crate::tools::ToolResult>> {
            Box::pin(async move {
                if let Some((entered, release)) = &self.barrier {
                    entered.notify_one();
                    release.notified().await;
                }
                std::fs::write(&self.path, self.name)?;
                Ok(crate::tools::ToolResult::success(format!(
                    "{} physically completed",
                    self.name
                )))
            })
        }
    }

    fn steer_effect_call(id: &str, name: &str) -> ToolCall {
        ToolCall {
            provider_source: None,
            id: id.to_string(),
            call_type: "function".to_string(),
            function: FunctionCall {
                name: name.to_string(),
                arguments: "{}".to_string(),
            },
        }
    }

    async fn wait_for_steer_barrier(barrier: &tokio::sync::Notify) -> Result<()> {
        tokio::time::timeout(std::time::Duration::from_secs(2), barrier.notified())
            .await
            .map_err(|_| ReactError::Other("steer execution barrier was not reached".to_string()))
    }

    async fn steer_before_model_return_case(parallel: bool, steer: bool) -> Result<()> {
        let directory = tempfile::tempdir()?;
        let path = directory.path().join("must-not-run-after-correction");
        let entered = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        let llm = Arc::new(SteerReturnBarrier {
            inner: MockLlmClient::new()
                .then_tool_call("unpublished-effect", "steer_effect", "{}")
                .with_response("reconsidered answer"),
            entered: entered.clone(),
            release: release.clone(),
        });
        let agent = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .tool(Box::new(SteerEffectTool {
                name: "steer_effect",
                path: path.clone(),
                parallel,
                barrier: None,
            }))
            .max_iterations(4)
            .build()?;
        let stream = agent
            .execute_stream_with_cancel("initial request", crate::agent::CancellationToken::new())
            .await?;
        wait_for_steer_barrier(&entered).await?;
        let mut receipt = if steer {
            let receipt = agent
                .steer_input_tracked(None, Message::user("do not write the sentinel".to_string()))
                .map_err(|error| ReactError::Other(error.to_string()))?;
            assert_eq!(receipt.state(), crate::agent::AgentSteerState::Accepted);
            Some(receipt)
        } else {
            None
        };
        assert!(!path.exists());
        release.notify_one();
        let events = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            stream.collect::<Vec<_>>(),
        )
        .await
        .map_err(|_| ReactError::Other("steer model-return run did not settle".to_string()))?
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
        assert_eq!(path.exists(), !steer);
        assert!(events.iter().any(|event| {
            matches!(event, AgentEvent::FinalAnswer(answer) if answer == "reconsidered answer")
        }));
        let messages = llm.inner.last_messages().unwrap_or_default();
        assert_eq!(
            messages.iter().any(|message| {
                message.content.as_text().as_deref() == Some("do not write the sentinel")
            }),
            steer
        );
        if let Some(receipt) = receipt.as_mut() {
            assert!(
                !events
                    .iter()
                    .any(|event| matches!(event, AgentEvent::ToolCall { .. }))
            );
            assert!(
                messages
                    .iter()
                    .all(|message| { message.tool_calls.as_ref().is_none_or(Vec::is_empty) })
            );
            assert_eq!(
                receipt.wait_for_turn_settled().await,
                crate::agent::AgentSteerState::TurnSettled {
                    outcome: crate::agent::AgentSteerTurnOutcome::Completed,
                    drained: true,
                }
            );
        }
        Ok(())
    }

    #[tokio::test]
    async fn steer_before_sequential_tool_batch_discards_unpublished_effect() -> Result<()> {
        steer_before_model_return_case(false, true).await
    }

    #[tokio::test]
    async fn steer_before_parallel_tool_batch_discards_unpublished_effect() -> Result<()> {
        steer_before_model_return_case(true, true).await
    }

    #[tokio::test]
    async fn no_steer_preserves_sequential_and_parallel_tool_execution() -> Result<()> {
        steer_before_model_return_case(false, false).await?;
        steer_before_model_return_case(true, false).await
    }

    #[cfg(feature = "files")]
    #[tokio::test]
    async fn provider_reader_settles_before_steer_skips_later_provider_wave() -> Result<()> {
        use echo_core::tools::filesystem::FileSystem;
        use echo_core::tools::{InvocationResourceGuard, ToolContext, ToolEffect, ToolResult};
        use std::io::Read;
        use std::sync::atomic::{AtomicUsize, Ordering};

        // The existing provider fixtures are private to their crates. This
        // tool only supplies the original Steer barrier around a real reader;
        // it adds no FileSystem implementation or alternative execution loop.
        struct ProviderReadAtBarrier {
            file_system: Arc<dyn FileSystem>,
            path: std::path::PathBuf,
            entered: Arc<tokio::sync::Notify>,
            release: std::sync::Mutex<Option<std::sync::mpsc::Receiver<()>>>,
            reader_drops: Arc<AtomicUsize>,
        }

        impl crate::tools::Tool for ProviderReadAtBarrier {
            fn name(&self) -> &str {
                "provider_read_at_barrier"
            }

            fn description(&self) -> &str {
                "Hold the actual provider reader at the existing Steer boundary"
            }

            fn parameters(&self) -> serde_json::Value {
                serde_json::json!({"type":"object","properties":{}})
            }

            fn risk_level(&self) -> crate::tools::ToolRiskLevel {
                crate::tools::ToolRiskLevel::ReadOnly
            }

            fn execute_with_context<'a>(
                &'a self,
                _parameters: crate::tools::ToolParameters,
                context: &'a ToolContext,
            ) -> BoxFuture<'a, Result<ToolResult>> {
                Box::pin(async move {
                    let release = self
                        .release
                        .lock()
                        .map_err(|error| ReactError::Other(error.to_string()))?
                        .take()
                        .ok_or_else(|| {
                            ReactError::Other("reader barrier already consumed".into())
                        })?;
                    let file_system = self.file_system.clone();
                    let path = self.path.clone();
                    let entered = self.entered.clone();
                    let reader_drops = self.reader_drops.clone();
                    let guards = context.resource_guards.clone();
                    // Match the original run_file_operation boundary: the
                    // physical closure owns the invocation guards and reader.
                    tokio::task::spawn_blocking(move || {
                        let _guards = guards;
                        let mut reader = file_system.open_read(&path)?;
                        let reader_lifetime = ResourceGuardDropProof(reader_drops);
                        let mut first = [0_u8; 1];
                        reader.read_exact(&mut first)?;
                        entered.notify_one();
                        // A failing assertion cannot leave this physical
                        // fixture parked on a blocking thread indefinitely.
                        let released = release.recv_timeout(std::time::Duration::from_secs(2));
                        let mut bytes = first.to_vec();
                        reader.read_to_end(&mut bytes)?;
                        drop(reader);
                        drop(reader_lifetime);
                        released.map_err(|error| ReactError::Other(error.to_string()))?;
                        let content = String::from_utf8(bytes)
                            .map_err(|error| ReactError::Other(error.to_string()))?;
                        Ok(
                            ToolResult::success(content).with_effect(ToolEffect::FileRead {
                                path: path.display().to_string(),
                            }),
                        )
                    })
                    .await
                    .map_err(|error| ReactError::Other(error.to_string()))?
                })
            }
        }

        // Both controls use the same actual tool manager, provider, wave
        // partition and physical barrier. Only accepted Steer differs.
        for steer in [false, true] {
            let directory = tempfile::tempdir()?;
            let source_path = directory.path().join("source.txt");
            let later_path = directory.path().join("later.txt");
            let source_content = "original provider bytes 中文 🙂";
            let file_system: Arc<dyn FileSystem> =
                Arc::new(echo_tools::filesystem::LocalFileSystem);
            file_system.write(&source_path, source_content.as_bytes())?;
            let entered = Arc::new(tokio::sync::Notify::new());
            let (release_tx, release_rx) = std::sync::mpsc::channel();
            let reader_drops = Arc::new(AtomicUsize::new(0));
            let scope_drops = Arc::new(AtomicUsize::new(0));
            let mut later = steer_effect_call("provider-later", "write_file");
            later.function.arguments = serde_json::json!({
                "path":"later.txt","content":"later provider write"
            })
            .to_string();
            let llm = Arc::new(
                MockLlmClient::new()
                    .then_tool_calls(vec![
                        steer_effect_call("provider-started", "provider_read_at_barrier"),
                        steer_effect_call("provider-wave-boundary", "sequential_marker"),
                        later,
                    ])
                    .with_response("provider work settled"),
            );
            let agent = ReactAgentBuilder::new()
                .llm_client(llm.clone())
                .enable_tools()
                .auto_project_rules(false)
                .file_system(file_system.clone())
                .tool(Box::new(ProviderReadAtBarrier {
                    file_system: file_system.clone(),
                    path: source_path,
                    entered: entered.clone(),
                    release: std::sync::Mutex::new(Some(release_rx)),
                    reader_drops: reader_drops.clone(),
                }))
                // Reuse the original explicit sequential boundary, then the
                // production file tool with the exact same provider instance.
                .tool(Box::new(SequentialMarkerTool))
                .tool(Box::new(
                    echo_tools::files::files::WriteFileTool::with_base_dir(directory.path())
                        .with_file_system(file_system.clone()),
                ))
                .max_iterations(4)
                .build()?;
            let invocation = echo_core::agent::AgentInvocationContext {
                working_dir: Some(directory.path().to_path_buf()),
                resource_guards: vec![InvocationResourceGuard::new(ResourceGuardDropProof(
                    scope_drops.clone(),
                ))],
                ..Default::default()
            };
            let stream = agent
                .execute_stream_with_invocation_context(
                    "read then write on the selected provider",
                    crate::agent::CancellationToken::new(),
                    invocation,
                )
                .await?;
            wait_for_steer_barrier(&entered).await?;
            let mut receipt = if steer {
                let receipt = agent
                    .steer_input_tracked(
                        None,
                        Message::user("do not start the later provider write".to_string()),
                    )
                    .map_err(|error| ReactError::Other(error.to_string()))?;
                assert_eq!(receipt.state(), crate::agent::AgentSteerState::Accepted);
                Some(receipt)
            } else {
                None
            };
            assert_eq!(reader_drops.load(Ordering::SeqCst), 0);
            assert_eq!(scope_drops.load(Ordering::SeqCst), 0);
            assert!(agent.execution_mutex.try_lock().is_err());
            assert!(!file_system.exists(&later_path)?);
            release_tx
                .send(())
                .map_err(|error| ReactError::Other(error.to_string()))?;
            let events = tokio::time::timeout(
                std::time::Duration::from_secs(2),
                stream.collect::<Vec<_>>(),
            )
            .await
            .map_err(|_| ReactError::Other("provider Steer run did not physically settle".into()))?
            .into_iter()
            .collect::<Result<Vec<_>>>()?;
            assert_eq!(reader_drops.load(Ordering::SeqCst), 1);
            assert_eq!(scope_drops.load(Ordering::SeqCst), 1);
            assert!(agent.execution_mutex.try_lock().is_ok());
            for id in [
                "provider-started",
                "provider-wave-boundary",
                "provider-later",
            ] {
                assert_eq!(events.iter().filter(|event| matches!(event, AgentEvent::ToolCall { call_id, .. } if call_id == id)).count(), 1);
                assert_eq!(events.iter().filter(|event| matches!(event, AgentEvent::ToolResult { call_id, .. } if call_id == id)).count(), 1);
            }
            assert!(events.iter().any(|event| matches!(event,
                AgentEvent::ToolResult { call_id, result, .. }
                    if call_id == "provider-started" && result.success && result.output == source_content
            )));
            let later_result = events
                .iter()
                .find_map(|event| match event {
                    AgentEvent::ToolResult {
                        call_id, result, ..
                    } if call_id == "provider-later" => Some(result),
                    _ => None,
                })
                .ok_or_else(|| ReactError::Other("missing later provider result".into()))?;
            if let Some(receipt) = receipt.as_mut() {
                assert!(
                    !file_system.exists(&later_path)?,
                    "Steer must prevent the later provider invocation"
                );
                assert!(!later_result.success);
                assert!(later_result.failure.as_ref().is_some_and(
                    |failure| failure.side_effect == crate::tools::ToolSideEffect::None
                ));
                assert_eq!(
                    receipt.wait_for_turn_settled().await,
                    crate::agent::AgentSteerState::TurnSettled {
                        outcome: crate::agent::AgentSteerTurnOutcome::Completed,
                        drained: true,
                    }
                );
                let messages = llm.last_messages().unwrap_or_default();
                let correction = messages
                    .iter()
                    .position(|message| {
                        message.content.as_text().as_deref()
                            == Some("do not start the later provider write")
                    })
                    .ok_or_else(|| {
                        ReactError::Other("provider correction was not consumed".into())
                    })?;
                for id in [
                    "provider-started",
                    "provider-wave-boundary",
                    "provider-later",
                ] {
                    let result = messages
                        .iter()
                        .position(|message| message.tool_call_id.as_deref() == Some(id))
                        .ok_or_else(|| {
                            ReactError::Other(format!("missing provider result {id}"))
                        })?;
                    assert!(
                        result < correction,
                        "close the original proposal before correction"
                    );
                }
            } else {
                assert!(later_result.success);
                assert_eq!(
                    file_system.read_to_string(&later_path)?,
                    "later provider write"
                );
            }
        }
        Ok(())
    }

    async fn steer_during_started_wave_case(
        parallel: bool,
        cancel_after_steer: bool,
    ) -> Result<()> {
        let directory = tempfile::tempdir()?;
        let started_path = directory.path().join("started-effect");
        let peer_path = directory.path().join("started-peer");
        let later_path = directory.path().join("later-effect");
        let entered = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        let peer_entered = Arc::new(tokio::sync::Notify::new());
        let peer_release = Arc::new(tokio::sync::Notify::new());
        let mut calls = vec![steer_effect_call("started", "started_effect")];
        if parallel {
            calls.push(steer_effect_call("peer", "started_peer"));
        }
        calls.push(steer_effect_call("later", "later_effect"));
        let llm = Arc::new(
            MockLlmClient::new()
                .then_tool_calls(calls)
                .with_response("reconsidered after real settlement"),
        );
        let mut builder = ReactAgentBuilder::new()
            .llm_client(llm.clone())
            .tool(Box::new(SteerEffectTool {
                name: "started_effect",
                path: started_path.clone(),
                parallel,
                barrier: Some((entered.clone(), release.clone())),
            }))
            .tool(Box::new(SteerEffectTool {
                name: "later_effect",
                path: later_path.clone(),
                parallel: false,
                barrier: None,
            }))
            .max_iterations(4);
        if parallel {
            builder = builder.tool(Box::new(SteerEffectTool {
                name: "started_peer",
                path: peer_path.clone(),
                parallel: true,
                barrier: Some((peer_entered.clone(), peer_release.clone())),
            }));
        }
        let agent = builder.build()?;
        let cancel = crate::agent::CancellationToken::new();
        let stream = agent
            .execute_stream_with_cancel("run effects", cancel.clone())
            .await?;
        wait_for_steer_barrier(&entered).await?;
        if parallel {
            wait_for_steer_barrier(&peer_entered).await?;
        }
        let mut receipt = agent
            .steer_input_tracked(
                None,
                Message::user("do not start the later effect".to_string()),
            )
            .map_err(|error| ReactError::Other(error.to_string()))?;
        assert_eq!(receipt.state(), crate::agent::AgentSteerState::Accepted);
        assert!(!started_path.exists());
        assert!(!later_path.exists());
        if cancel_after_steer {
            cancel.cancel();
        }
        release.notify_one();
        peer_release.notify_one();
        let events = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            stream.collect::<Vec<_>>(),
        )
        .await
        .map_err(|_| ReactError::Other("started steer wave did not physically settle".to_string()))?
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
        assert_eq!(std::fs::read_to_string(&started_path)?, "started_effect");
        if parallel {
            assert_eq!(std::fs::read_to_string(&peer_path)?, "started_peer");
        }
        assert!(
            !later_path.exists(),
            "a later wave must not execute the stale proposal"
        );
        for id in if parallel {
            vec!["started", "peer", "later"]
        } else {
            vec!["started", "later"]
        } {
            assert_eq!(events.iter().filter(|event| matches!(event, AgentEvent::ToolCall { call_id, .. } if call_id == id)).count(), 1);
            assert_eq!(events.iter().filter(|event| matches!(event, AgentEvent::ToolResult { call_id, .. } if call_id == id)).count(), 1);
        }
        let later_result = events
            .iter()
            .find_map(|event| match event {
                AgentEvent::ToolResult {
                    call_id, result, ..
                } if call_id == "later" => Some(result),
                _ => None,
            })
            .ok_or_else(|| ReactError::Other("missing genuine not-executed result".to_string()))?;
        assert!(!later_result.success);
        assert!(
            later_result
                .failure
                .as_ref()
                .is_some_and(|failure| failure.side_effect == crate::tools::ToolSideEffect::None)
        );
        let terminal = receipt.wait_for_turn_settled().await;
        if cancel_after_steer {
            assert_eq!(
                terminal,
                crate::agent::AgentSteerState::TurnSettled {
                    outcome: crate::agent::AgentSteerTurnOutcome::Cancelled,
                    drained: false,
                }
            );
            assert!(
                !events
                    .iter()
                    .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
            );
        } else {
            assert_eq!(
                terminal,
                crate::agent::AgentSteerState::TurnSettled {
                    outcome: crate::agent::AgentSteerTurnOutcome::Completed,
                    drained: true,
                }
            );
            let messages = llm.last_messages().unwrap_or_default();
            let correction = messages
                .iter()
                .position(|message| {
                    message.content.as_text().as_deref() == Some("do not start the later effect")
                })
                .ok_or_else(|| {
                    ReactError::Other("correction absent from next model request".to_string())
                })?;
            for id in if parallel {
                vec!["started", "peer", "later"]
            } else {
                vec!["started", "later"]
            } {
                let result_position = messages
                    .iter()
                    .position(|message| message.tool_call_id.as_deref() == Some(id))
                    .ok_or_else(|| {
                        ReactError::Other(format!("model request missing result for {id}"))
                    })?;
                assert!(
                    result_position < correction,
                    "close the original tool batch before adding user input"
                );
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn steer_during_sequential_wave_retains_started_effect_and_skips_later_wave() -> Result<()>
    {
        steer_during_started_wave_case(false, false).await
    }

    #[tokio::test]
    async fn steer_during_parallel_wave_retains_all_started_effects_and_skips_later_wave()
    -> Result<()> {
        steer_during_started_wave_case(true, false).await
    }

    #[tokio::test]
    async fn stop_during_steered_wave_preserves_physical_settlement_and_cancelled_receipt()
    -> Result<()> {
        steer_during_started_wave_case(false, true).await?;
        steer_during_started_wave_case(true, true).await
    }

    async fn steer_with_reused_call_id_case(steer: bool) -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let directory = tempfile::tempdir()?;
        let prior_path = directory.path().join("prior-effect");
        let current_path = directory.path().join("current-started-effect");
        let later_path = directory.path().join("later-reused-id-effect");
        let entered = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        let store = Arc::new(InMemoryRunStore::new());
        let llm = Arc::new(
            MockLlmClient::new()
                .then_tool_call("reused-id", "prior_effect", "{}")
                .then_tool_calls(vec![
                    steer_effect_call("current-wave", "current_effect"),
                    steer_effect_call("reused-id", "later_effect"),
                ])
                .with_response("considered the current request"),
        );
        let agent = ReactAgentBuilder::new()
            .llm_client(llm)
            .tool(Box::new(SteerEffectTool {
                name: "prior_effect",
                path: prior_path.clone(),
                parallel: false,
                barrier: None,
            }))
            .tool(Box::new(SteerEffectTool {
                name: "current_effect",
                path: current_path.clone(),
                parallel: false,
                barrier: Some((entered.clone(), release.clone())),
            }))
            .tool(Box::new(SteerEffectTool {
                name: "later_effect",
                path: later_path.clone(),
                parallel: false,
                barrier: None,
            }))
            .with_run_store(store.clone())
            .max_iterations(5)
            .build()?;
        let stream = agent
            .execute_stream("run the first and next proposals")
            .await?;
        wait_for_steer_barrier(&entered).await?;
        assert_eq!(std::fs::read_to_string(&prior_path)?, "prior_effect");
        let mut receipt = if steer {
            Some(
                agent
                    .steer_input_tracked(None, Message::user("skip the later proposal".to_string()))
                    .map_err(|error| ReactError::Other(error.to_string()))?,
            )
        } else {
            None
        };
        release.notify_one();
        let events = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            stream.collect::<Vec<_>>(),
        )
        .await
        .map_err(|_| ReactError::Other("reused-ID original loop did not settle".to_string()))?
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
        assert_eq!(std::fs::read_to_string(&current_path)?, "current_effect");
        assert_eq!(later_path.exists(), !steer);

        // IDs may repeat after completion. Pair each original proposal, not
        // a synthetic whole-turn map keyed only by the model's string ID.
        let batches: Vec<_> = events
            .split(|event| matches!(event, AgentEvent::ToolBatchEnd))
            .filter(|batch| {
                batch
                    .iter()
                    .any(|event| matches!(event, AgentEvent::ToolBatchStart { .. }))
            })
            .collect();
        assert_eq!(batches.len(), 2);
        for batch in &batches {
            assert_eq!(batch.iter().filter(|event| matches!(event, AgentEvent::ToolCall { call_id, .. } if call_id == "reused-id")).count(), 1);
            assert_eq!(batch.iter().filter(|event| matches!(event, AgentEvent::ToolResult { call_id, .. } if call_id == "reused-id")).count(), 1);
        }
        let later_batch = batches
            .get(1)
            .copied()
            .ok_or_else(|| ReactError::Other("missing second tool proposal".to_string()))?;
        let result = later_batch
            .iter()
            .find_map(|event| match event {
                AgentEvent::ToolResult {
                    call_id,
                    name,
                    result,
                } if call_id == "reused-id" && name == "later_effect" => Some(result),
                _ => None,
            })
            .ok_or_else(|| {
                ReactError::Other("missing current-attempt reused-ID result".to_string())
            })?;
        assert_eq!(result.success, !steer);
        if steer {
            assert!(
                result.failure.as_ref().is_some_and(
                    |failure| failure.side_effect == crate::tools::ToolSideEffect::None
                )
            );
        }
        let summaries = store.list_all(2).await?;
        assert_eq!(summaries.len(), 1);
        let summary = summaries
            .first()
            .ok_or_else(|| ReactError::Other("missing original trace run".to_string()))?;
        let run = store
            .load(&summary.run_id)
            .await?
            .ok_or_else(|| ReactError::Other("missing original trace".to_string()))?;
        assert_eq!(run.events.iter().filter(|event| matches!(event, RunEvent::ToolExecutionSkipped { call_id, name, .. } if call_id == "reused-id" && name == "later_effect")).count(), usize::from(steer));
        assert!(!run.events.iter().any(|event| matches!(event, RunEvent::ToolExecutionSkipped { call_id, name, .. } if call_id == "reused-id" && name == "prior_effect")));
        if let Some(receipt) = receipt.as_mut() {
            assert_eq!(
                receipt.wait_for_turn_settled().await,
                crate::agent::AgentSteerState::TurnSettled {
                    outcome: crate::agent::AgentSteerTurnOutcome::Completed,
                    drained: true,
                }
            );
        }
        Ok(())
    }

    #[tokio::test]
    async fn steer_skips_reused_id_in_later_proposal_without_old_started_fact() -> Result<()> {
        steer_with_reused_call_id_case(true).await
    }

    #[tokio::test]
    async fn no_steer_preserves_reused_ids_across_completed_model_proposals() -> Result<()> {
        steer_with_reused_call_id_case(false).await
    }

    #[tokio::test]
    async fn reused_id_pre_execution_timeout_uses_current_attempt_not_started_fact() -> Result<()> {
        use crate::trace::{InMemoryRunStore, RunEvent, RunStore};

        let directory = tempfile::tempdir()?;
        let prior_path = directory.path().join("prior-completed-effect");
        let later_path = directory.path().join("never-executed-after-prehook");
        let entered = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let release = Arc::new(tokio::sync::Notify::new());
        let store = Arc::new(InMemoryRunStore::new());
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new()
                    .then_tool_call("same-prehook-id", "prior_effect", "{}")
                    .then_tool_call("same-prehook-id", "bounded_effect", "{}")
                    .with_response("must not complete after timeout"),
            ))
            .tool(Box::new(SteerEffectTool {
                name: "prior_effect",
                path: prior_path.clone(),
                parallel: false,
                barrier: None,
            }))
            .tool(Box::new(SteerEffectTool {
                name: "bounded_effect",
                path: later_path.clone(),
                parallel: true,
                barrier: None,
            }))
            .intervention_callback(Arc::new(StallingToolIntervention {
                entered: entered.clone(),
                tool_name: Some("bounded_effect"),
                release: release.clone(),
            }))
            .tool_execution(crate::tools::ToolExecutionConfig {
                timeout_ms: 10,
                retry_on_fail: false,
                ..Default::default()
            })
            .with_run_store(store.clone())
            .max_iterations(5)
            .build()?;
        let stream = agent
            .execute_stream("complete the first attempt then time out before the next executes")
            .await?;
        let collection = stream.collect::<Vec<_>>();
        tokio::pin!(collection);
        let observed =
            tokio::time::timeout(std::time::Duration::from_millis(300), &mut collection).await;
        let returned_before_original_callback = observed.is_ok();
        release.notify_one();
        let events = match observed {
            Ok(events) => events,
            Err(_) => tokio::time::timeout(std::time::Duration::from_secs(3), &mut collection)
                .await
                .map_err(|_| {
                    ReactError::Other("reused-ID pre-execution owner did not settle".to_string())
                })?,
        }
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
        assert!(!returned_before_original_callback);
        assert!(entered.load(std::sync::atomic::Ordering::Acquire));
        assert_eq!(std::fs::read_to_string(&prior_path)?, "prior_effect");
        assert!(!later_path.exists());
        let current = events
            .iter()
            .find_map(|event| match event {
                AgentEvent::ToolResult {
                    call_id,
                    name,
                    result,
                } if call_id == "same-prehook-id" && name == "bounded_effect" => Some(result),
                _ => None,
            })
            .ok_or_else(|| ReactError::Other("missing current pre-execution result".to_string()))?;
        assert!(
            current
                .failure
                .as_ref()
                .is_some_and(|failure| failure.side_effect == crate::tools::ToolSideEffect::None)
        );
        let summary = store
            .list_all(1)
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| ReactError::Other("missing reused-ID timeout trace".to_string()))?;
        let run = store
            .load(&summary.run_id)
            .await?
            .ok_or_else(|| ReactError::Other("missing timeout trace body".to_string()))?;
        assert_eq!(run.events.iter().filter(|event| matches!(event, RunEvent::ToolExecutionSkipped { call_id, name, .. } if call_id == "same-prehook-id" && name == "bounded_effect")).count(), 1);
        assert!(!run.events.iter().any(|event| matches!(event, RunEvent::ToolExecutionSkipped { call_id, name, .. } if call_id == "same-prehook-id" && name == "prior_effect")));
        assert!(events.iter().any(|event| matches!(event, AgentEvent::ToolResult { call_id, name, result } if call_id == "same-prehook-id" && name == "prior_effect" && result.success)));
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_)))
        );
        Ok(())
    }

    // Truncated / clean-disconnect stream: the loop must NOT accept the
    // partial output as a complete final answer (Q-FLT-01-P1-01). This
    // fixture remains active in the mandatory suite so terminal regressions
    // cannot be hidden behind an ignored test.
    #[tokio::test]
    async fn truncated_stream_is_not_accepted_as_complete() {
        let llm = MockLlmClient::new().with_stream_script(vec![
            StreamChunk::Delta(DeltaMessage {
                role: Some("assistant".to_string()),
                content: Some("Partial answer that never finished".to_string()),
                reasoning_content: None,
                reasoning_blocks: None,
                assistant_blocks: None,
                tool_calls: None,
            }),
            StreamChunk::Err(ReactError::Llm(Box::new(LlmError::NetworkError(
                "connection closed mid-stream".to_string(),
            )))),
        ]);
        let agent = agent_with_mock_llm(llm);
        let events = collect_events(&agent, "Hi").await;
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, AgentEvent::FinalAnswer(_))),
            "truncated stream must not produce a FinalAnswer"
        );
        assert!(
            events
                .iter()
                .any(|event| matches!(event, AgentEvent::Error { .. })),
            "truncated stream must surface an error terminal"
        );
        let partial = events
            .iter()
            .filter_map(|event| match event {
                AgentEvent::AssistantMessage { block }
                    if block.phase == echo_core::agent::AssistantPhase::Unknown
                        && !block.complete =>
                {
                    Some(block.delta.as_str())
                }
                _ => None,
            })
            .collect::<String>();
        assert_eq!(partial, "Partial answer that never finished");
    }
}
