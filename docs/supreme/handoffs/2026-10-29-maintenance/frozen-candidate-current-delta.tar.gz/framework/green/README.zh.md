<div align="center">

# echo-agent

### 面向 Rust 的生产级 AI Agent 框架

**ReAct 引擎 • 多 Agent • 记忆 • 流式 • MCP • IM 通道 • 工作流**

[![crates.io](https://img.shields.io/crates/v/echo_agent?color=brightgreen)](https://crates.io/crates/echo_agent)
[![docs.rs](https://docs.rs/echo_agent/badge.svg)](https://docs.rs/echo_agent)
[![CI](https://github.com/EchoYue-lp/echo-agent/actions/workflows/rust-ci.yml/badge.svg)](https://github.com/EchoYue-lp/echo-agent/actions)
[![Rust](https://img.shields.io/badge/Rust-2024%20edition-orange?logo=rust)](https://www.rust-lang.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![OpenAI Compatible](https://img.shields.io/badge/API-OpenAI%20%E5%85%BC%E5%AE%B9-green)](https://platform.openai.com/docs/api-reference)
[![Async](https://img.shields.io/badge/runtime-tokio-blue)](https://tokio.rs/)

[English](./README.md) &middot; [文档中心](./docs/zh/README.md) &middot; [Rust 学习指南](./echo-agent-learning/docs/zh/README.md) &middot; [示例](./echo-agent-learning/examples/) &middot; [更新日志](./CHANGELOG.md)

</div>

> 具名退役：当前源码移除 A2A／LSP 的实现、feature、公开出口和专属示例；
> ACP、MCP、channels、Task/Subagent、通用工具和存储菜单继续保留。
> 旧插件 `lsp.yaml` 由原 prepare owner 冻结并明确诊断，不启动服务，也不删除用户文件。
> 源码同步不代表删后构建、最终锁、SDK正式新Git来源、native或发布资格已通过。
> 边界和恢复锚点见[ADR0090](docs/adr/0090-a2a-lsp-retirement-contract.md)。

---

## 快速上手

添加到 `Cargo.toml`：

```toml
[dependencies]
echo-agent = "0.2.0"
tokio = { version = "1", features = ["full"] }
```

定义工具、运行 Agent——不到 20 行代码：

```rust,no_run
use echo_agent::prelude::*;
use echo_agent::{agent, tool};

#[tool(name = "add", description = "两数相加")]
async fn add(a: f64, b: f64) -> Result<ToolResult> {
    Ok(ToolResult::success(format!("{}", a + b)))
}

#[tokio::main]
async fn main() -> Result<()> {
    let api_key = std::env::var("OPENAI_API_KEY").map_err(|_| {
        echo_agent::error::ConfigError::MissingConfig(
            "quickstart".to_string(),
            "OPENAI_API_KEY".to_string(),
        )
    })?;
    let llm_config = LlmConfig::for_provider(
        "openai",
        "https://api.openai.com/v1",
        api_key,
        "qwen3.7-max",
        LlmApiProtocol::ChatCompletions,
    )?;
    let mut agent = agent! {
        model: "qwen3.7-max",
        llm_config: llm_config,
        system_prompt: "你是一个计算助手",
        tools: [AddTool],
    }?;

    let answer = agent.execute("计算 1337 × 42").await?;
    println!("{answer}");
    Ok(())
}
```

---

## 为什么选择 echo-agent？

绝大多数 AI Agent 框架基于 Python。**echo-agent** 将完整的现代 Agent 框架带入 Rust——与 [LangGraph](https://github.com/langchain-ai/langgraph)、[CrewAI](https://github.com/crewAIInc/crewAI)、[AutoGen](https://github.com/microsoft/autogen) 功能对齐，同时提供只有 Rust 才能带来的**性能、类型安全和可靠性**。

| | echo-agent | LangGraph | CrewAI | AutoGen |
|---|---|---|---|---|
| **语言** | Rust | Python | Python | Python |
| **内存安全** | 编译时保证 | GC | GC | GC |
| **ReAct 循环** | 内置 | 内置 | 内置 | 内置 |
| **工具系统** | `#[tool]` 宏 + JSON Schema | 装饰器 | 装饰器 | 函数调用 |
| **多 Agent** | Subagent 调度 + 团队 | 图结构 | Crew 模式 | 对话模式 |
| **流式输出** | 原生 async stream | 回调 | 有限 | 回调 |
| **MCP 协议** | 原生（stdio/SSE/HTTP） | 通过 LangChain | 无 | 无 |
| **IM 通道** | QQ + 飞书内置 | 无 | 无 | 无 |
| **工作流** | Graph + DAG + Sequential | StateGraph | Sequential | Sequential |
| **上下文压缩** | SlidingWindow + LLM + Hybrid | 无 | 无 | 无 |
| **护栏系统** | 规则 + LLM 过滤 | 无 | 无 | 无 |
| **沙箱** | Local + Docker + K8s | 无 | 无 | Docker |
| **单二进制部署** | 是 | 否 | 否 | 否 |

### 5 行代码接入 IM

```rust
let mut manager = ChannelManager::new();
manager.register(Box::new(QqChannel::new(qq_config)?));
manager.register(Box::new(FeishuChannel::new(feishu_config)?));
for started in manager.start_all(handler).await {
    started.result?;
}
manager.stop_all().await?;
```

### 运行示例

```bash
cargo run -p echo-agent-learning --example demo01_tools          # 自定义工具
cargo run -p echo-agent-learning --example demo25_macros         # 宏系统
cargo test -p echo-agent-learning --test example_contracts --all-features --locked contract_demo34_workflow_stream # 工作流流式
cargo run -p echo-agent-learning --example demo36_multimodal     # 多模态消息
cargo run -p echo-agent-learning --example demo38_im_channels --features channels  # IM 通道
```

---

## 架构

```text
Application / protocol surface
             |
             v
    echo_agent public facade
             |
  core contracts + execution + state + orchestration + integrations + tools
             |
  外部 SDK protocol / Host consumer 和可执行 learning consumer
```

建议从 [Framework 架构](docs/zh/architecture.md)、[核心概念](docs/zh/concepts.md)和
[Framework 生命周期](docs/zh/lifecycles.md)开始。Product Workspace、前端、桌面端和 device policy
仍属于 embedding application。

---

## 功能矩阵

echo-agent 提供跨越 8 个 crate 的 **67 个注册工具**。Prelude 只导出通用 trait 与 builder；具体工具使用 `echo_agent::tools::files::*` 等稳定路径，启用相应 feature 后可通过 `echo_agent::tools::register_all_tools` 批量注册。

### 核心

| 能力 | 描述 | API 预览 |
|------|------|---------|
| **ReAct 引擎** | Thought → Action → Observation 循环 | `agent.execute("task").await?` |
| **工具系统** | `#[tool]` 宏 + 自动 JSON Schema + 超时重试 | `#[tool(name = "calc")] async fn calc(...)` |
| **记忆系统** | `Store`（长期 KV）+ `RuntimeStateStore`（崩溃恢复）+ `ConversationStore`（会话历史） | `.with_memory_tools(store)` |
| **上下文压缩** | 滑动窗口 / LLM 摘要 / 混合管道 | `SlidingWindowCompressor::new(4096)` |
| **Token 预算** | 自动截断 + think 前触发压缩 | `.max_tool_output_tokens(2000)` |
| **统一重试** | 一套策略覆盖 LLM、MCP、沙箱 | `with_retry(&policy, \|\| ...)` |
| **动态工具** | 对话中增 / 删 / 换工具 | `agent.remove_tool("old")` |
| **流式输出** | 实时 `AgentEvent` 流（Token + 工具调用） | `agent.execute_stream(task).await?` |
| **结构化输出** | LLM 输出 → Rust 类型（JSON Schema） | `agent.extract::<Contact>(text)` |
| **多模态** | 文本 + 图片 + 文件混合消息 | `Message::user_with_image(...)` |
| **护栏系统** | 规则 / LLM 内容过滤 | `#[guard(name = "safety")] async fn ...` |
| **权限模型** | 声明式工具权限 + 统一权限服务 | `PermissionService::from_provider(...)` |
| **审计日志** | 结构化事件 + 可插拔后端 | `agent.set_audit_logger(...)` |
| **宏系统** | 11 个宏：`#[tool]`、`agent!{}`、`messages![]`... | `agent! { llm_config: config, tools: [...] }` |

### 多 Agent 与编排

| 能力 | 描述 | API 预览 |
|------|------|---------|
| **Subagent** | Sync / Fork / Teammate 三种模式 | `agent.register_agent(sub)` |
| **任务图** | 单一依赖图上的版本化任务 CRUD | `task_create` / `task_update` / `task_list` |
| **自我审查** | LLM 质量评估作为工具 | `ReviewTool::new(critic)` |
| **图工作流** | 线性、条件、循环、并行扇出/扇入 | `GraphBuilder::new("pipeline")` |
| **DAG 任务** | 版本化 CRUD 与依赖感知执行 | `TaskRevisionService::new(...)` |
| **声明式工作流** | YAML/JSON 定义图——无需 Rust 代码 | `Graph::from_yaml("wf.yaml")?` |

### 集成

| 能力 | 描述 | API 预览 |
|------|------|---------|
| **ACP Agent** | 基于 `AgentTurnDriver` 的稳定 v1 Client-Agent adapter | `AcpAgentAdapter::new(factory)` |
| **MCP 协议** | 接入任意 MCP 服务器（stdio/SSE/HTTP） | `mcp.connect(McpServerConfig::stdio(...))` |
| **Skill 系统** | 渐进式披露：发现 → 激活 → 使用 | `agent.load_skill("web_research")` |
| **IM 通道** | QQ Bot（WebSocket）+ 飞书（Webhook） | `ChannelManager::new()` |
| **Web 工具** | 搜索 + 网页获取 | `WebSearchTool::auto()` |
| **论文检索工具** | ArXiv、Semantic Scholar、PDF 下载、BibTeX 生成 | `ArxivSearchTool` |
| **媒体工具** | PDF、Excel、Word、多模态图片查看 | `ViewImageTool` |
| **数据工具** | Polars 驱动的过滤、聚合、统计 | `DataReadTool` |
| **沙箱** | Local / Docker / K8s 代码执行 | `LocalSandbox::new()` |
| **OpenTelemetry** | 分布式追踪与指标 | `init_telemetry(config)` |
| **快照/回滚** | 任意时刻捕获和恢复 Agent 状态 | `agent.snapshot()` / `agent.rollback(1)` |
| **熔断器** | LLM 不可用时自动快速失败 | `agent.set_circuit_breaker(config)` |

---

## Feature Flags

```toml
# 最小化 —— 仅 ReAct 引擎（默认）
echo-agent = "0.2.0"

# 显式禁用默认 feature（等价于默认安装）
echo-agent = { version = "0.2.0", default-features = false }

# 完整功能
echo-agent = { version = "0.2.0", features = ["full"] }

# 按需选择
echo-agent = { version = "0.2.0", default-features = false, features = ["mcp", "web"] }
```

任务 API 属于框架核心，没有需要单独启用的 feature。

| Feature | 启用 | 关键依赖 |
|---------|------|---------|
| `full` | 启用下列全部 feature | — |
| `acp` | 稳定 ACP v1 Agent adapter | `agent-client-protocol` |
| `mcp` | MCP 协议客户端 | — |
| `sqlite` | SQLite 持久化状态 | `rusqlite` |
| `telemetry` | OpenTelemetry 追踪与指标 | `opentelemetry` |
| `human-loop` | 人工审批 | `tokio-tungstenite` |
| `topology` | Agent 拓扑 | — |
| `subagent` | Subagent 编排 | — |
| `web` | Web 搜索 + 获取工具 | `scraper`, `html2text` |
| `media` | PDF、Excel、Word、图片工具 | `lopdf`, `calamine`, `docx-rs` |
| `data` | Polars 数据分析 | `polars` |
| `statistics` | 统计分析工具 | — |
| `channels` | QQ Bot + 飞书集成 | `echo-channels` |
| `git` | Git 操作工具 | — |
| `database` | 数据库查询工具 | `sqlx` |
| `rag` | RAG 检索工具 | — |
| `research` | ArXiv、Semantic Scholar、PDF 下载、BibTeX 工具 | `quick-xml` |
| `chart` | 图表生成工具 | — |
| `content-guard` | 内容安全护栏 | — |
| `project-rules` | 项目规则加载 | — |
| `shell` | Shell 命令执行工具 | — |
| `files` | 文件读写工具 | — |
| `eval` | 评估原语 | — |
| `improve` | 自改进原语 | — |
| `testing` | Mock 与测试辅助 | — |

---

## Workspace 结构

```
echo-agent/
├── echo-core/           核心 trait：Tool、Agent、LlmClient、Guard、Error、Retry
├── echo-macros/         过程宏：#[tool]、#[callback]、#[guard]、#[handler]
├── echo-execution/      沙箱、技能和工具执行
├── echo-state/          记忆、压缩和审计日志
├── echo-orchestration/  工作流、人工审批和 DAG 任务
├── echo-integration/    LLM 提供方、MCP 和 IM 通道（QQ/飞书）
├── echo-tools/          领域工具：chart、data、database、git、media、web、rag
├── echo-agent-learning/ 不发布的学习课程、Demo、综合示例和 facade 合同
├── src/                 Agent 引擎、重导出和门面层
└── docs/                框架消费者文档（en + zh）
```

> **注意：** `echo-agent` 是纯库框架。开箱即用的应用（含 CLI、Web UI、WebSocket）请参见 [echo-agent-cli](https://github.com/EchoYue-lp/echo-agent-cli)。

---

## 运行时配置

框架接收类型化的 `FrameworkConfig`、`AgentConfig`、`LlmConfig`、`PermissionMode` 和显式 `DataRoot`，不发现产品 YAML，也不选择 home 下的数据目录。参见[运行时配置](docs/zh/28-config-reference.md)。

---

## 亮点

- **67 个注册工具** — ReAct 循环、数据分析、论文检索、Web、媒体、RAG、数据库等
- **可运行示例与教学 crate** — 框架验收示例和 Rust 基础课程分别维护
- **全模块单元测试** — 覆盖核心路径的测试
- **8 个框架/运行时 package + 1 个学习 package** — 多语言 SDK 由独立的 [echo-agent-sdk](https://github.com/EchoYue-lp/echo-agent-sdk) 仓库维护
- **多模态** — 文本、图片（base64 & URL）、文件附件混合消息
- **IM 集成** — QQ Bot（WebSocket）& 飞书（Webhook）开箱即用
- **声明式工作流** — 用 YAML/JSON 定义 Agent 图，无需写 Rust 代码
- **统一重试** — 一套 `RetryPolicy` 覆盖所有外部调用（LLM、MCP、沙箱）
- **零成本抽象** — 编译为原生代码，无运行时开销

---

## 核心概念

echo-agent 围绕多个关键概念构建，支持灵活、生产级的 Agent 开发：

### 1. ReAct 引擎 — Thought → Action → Observation 循环

echo-agent 的基础是 ReAct（Reasoning + Acting）模式，内置 Chain-of-Thought 提示。Agent 逐步思考、决定调用哪个工具、观察结果，直到得出最终答案。

```rust
let agent = ReactAgentBuilder::new()
    .model("qwen3.7-max")
    .system_prompt("你是一个有帮助的助手")
    .build()?;
let answer = agent.execute("42 * 1337 等于多少？").await?;
```

三种 Builder 预设（必须显式提供 LLM client 或 config；需要延迟注入模型时请使用流式 builder 的 `build()`）：

```rust
// 最小化 — 无工具、无记忆，纯对话
let agent = ReactAgentBuilder::simple("qwen3.7-max", "帮助用户")?;

// 标准版 — 工具 + CoT 启用
let agent = ReactAgentBuilder::standard("qwen3.7-max", "assistant", "帮助用户")?;

// 全功能 — 工具 + 记忆 + 任务 + CoT
let agent = ReactAgentBuilder::full_featured("qwen3.7-max", "assistant", "帮助用户")?;
```

### 2. 工具系统 — `#[tool]` 宏 + 自动 JSON Schema

将工具定义为简单的异步函数。`#[tool]` 宏自动生成参数 Schema、描述和 `TypedTool` 实现。

```rust
use echo_agent::{tool, prelude::*};

#[tool(name = "weather", description = "查询城市天气")]
async fn weather(city: String) -> Result<ToolResult> {
    Ok(ToolResult::success(format!("{city} 晴天")))
}

// 使用：agent.add_tool(Box::new(WeatherTool));
```

内置媒体工具（feature `media`）：PDF 提取/信息、Excel 读取/信息/导出CSV、Word 读取/信息/结构、图片分析、文本读取/搜索/统计/处理/导出。

内置数据工具（feature `data`）：基于 Polars 的读取/过滤/聚合/统计/转换/导出。

### 3. 记忆系统 — Store + RuntimeStateStore + ConversationStore

- **Store**：长期键值存储，支持命名空间隔离（`InMemoryStore`、`FileStore`、`SqliteStore`）
- **RuntimeStateStore**：ReAct 运行时检查点保存消息、激活技能、阻塞原因和工作目录，支持合法当前格式的恢复；计划与依赖图由 `TaskRevisionService` 的单一 TaskRun graph 持有，checkpoint 不保存计划副本。
- **ConversationStore**：用户可见的对话历史投影，与 `RuntimeStateStore` 配对并在压缩或终态发布前原子结算

直接 Store API 提供通用 KV 读写；Agent 的 Store 工具只召回已批准记忆。分层 typed memory 会把自动抽取和 remember 工具输出
保存为附有来源证据的 Draft；调用方通过
`MemoryLayerManager::preview_activation` 和 `activate_draft` 显式批准后，
记录才进入自动和分层召回。缺少来源的旧记录仍可检查，但不会被当作已批准记忆召回。
参见[记忆概念](docs/zh/03-memory.md)和
[ADR 0070](docs/adr/0070-memory-provenance-and-recall-authority.md)。

一行代码注册已批准记忆的召回工具；安装 `MemoryLayerManager` 后才提供经过 journal 的 `remember` 与 `forget`：

```rust
let store = Arc::new(InMemoryStore::new());
let agent = ReactAgentBuilder::new()
    .model("qwen3.7-max")
    .with_memory_tools(store)  // 注册 recall + search_memory
    .build()?;
```

### 4. 多模态消息 — 文本、图片、文件合一

在同一条消息中发送/接收图片（base64 或 URL）和文件附件，兼容 OpenAI Vision 和 Anthropic API。

```rust
let msg = Message::user_with_image(
    "这张图片里有什么？",
    "image/png",
    base64_data,
);
```

### 5. 上下文压缩 — 滑动窗口、LLM 摘要、混合

通过可配置的压缩策略管理 Token 限制，保留对话上下文。

```rust
agent.set_compressor(Box::new(SlidingWindowCompressor::new(4096)));
```

三种策略：
- **SlidingWindow** — 在 Token 预算内保留最近的消息
- **SummaryCompressor** — 使用 LLM 摘要旧消息
- **HybridCompressor** — 组合两者以获得最佳质量

### 6. 统一重试策略 — 一套策略覆盖所有外部调用

配置一次重试、超时和退避，应用于 LLM 调用、MCP 请求、沙箱执行。

```rust
let policy = RetryPolicy::new(3, Duration::from_millis(500))
    .max_delay(Duration::from_secs(30))
    .jitter(true);
let response = with_retry(&policy, || llm_client.chat(request)).await?;
```

### 7. 动态工具管理 — 对话中增/删/换工具

无需重启 Agent 即可根据对话阶段或用户需求调整工具集。

```rust
agent.add_tool(Box::new(SearchWebTool));
agent.remove_tool("search_web");
agent.replace_tool(Box::new(SaferExecuteCodeTool));
```

### 8. 人工介入 — 关键操作的审批门控

通过控制台、Webhook 或 WebSocket 接口要求人工审批后执行敏感工具。

```rust
let approval = ConsoleApproval::new();
agent.set_human_loop_handler(Box::new(approval));
```

完整的 7 阶段权限流水线（灵感来自 Claude Code）：

```
Bypass → Plan → Rules(deny-first) → ProtectedPaths → Cache(TTL) → DenialTracker → Mode dispatch
```

- **SessionApprovalCache**：可配置 TTL（默认 30 分钟）
- **审计追踪**：`PermissionAuditSink` trait + InMemory/Logging/Composite 实现
- **ProtectedPathChecker**：`.git`/`.env`/`.ssh` 始终受保护
- **AI 分类器**：RuleClassifier/LlmClassifier/CompositeClassifier 用于 Auto 模式
- **DenialTracker**：连续拒绝后自动降级
- **PermissionMode**：Default/Plan/Auto/AcceptEdits/BypassPermissions/DontAsk/Bubble

### 9. 多 Agent 编排 — Orchestrator + Subagent 团队

取消观察与原 producer 的实际结算分离；请参阅 [Rust 调用迁移与所有权合同](docs/subagent-cancellation-observation.md)。

协调多个专业 Agent，支持上下文隔离和切换协议。

三种执行模式：
- **Sync** — 父 Agent 阻塞等待子 Agent 返回
- **Fork** — 子 Agent 在后台运行，父 Agent 继续执行
- **Teammate** — 独立后台 Subagent，通过 handle 等待或取消

```rust
let orchestrator = Orchestrator::new();
orchestrator.register("math", math_agent);
orchestrator.register("writer", writer_agent);
```

### 10. Skill 系统 — 渐进式能力披露

相关工具和提示的打包，可按需发现、激活和使用。

```rust
agent.load_skill("web_research").await?;  // 加载 SKILL.md + 注册工具
```

预置技能：`code-review`、`data-analyst`、`project-stats`、`python-linter`、`web-researcher`。

### 11. MCP 协议 — 连接任意 Model Context Protocol 服务器

通过标准化 MCP 服务器集成文件系统、数据库、浏览器等资源。

```rust
let mut mcp = McpManager::new();
let tools = mcp.connect(McpServerConfig::stdio(
    "filesystem", "npx", vec!["-y", "@modelcontextprotocol/server-filesystem", "/workspace"]
)).await?;
agent.add_tools(tools);
```

支持三种传输方式：**stdio**、**SSE**、**HTTP**。

### 12. 任务图 — 版本化 TaskRun graph

ReactAgent 提供 `task_create`、`task_update`、`task_list`，共同操作一个版本化任务图。Plan 是可编辑、可审阅的 artifact；产品特定的执行策略由应用层适配器提供。

> 任务 API 属于框架核心，无需单独启用 feature。

```rust,ignore
let agent = ReactAgentBuilder::new()
    .model("qwen3.7-max")
    .enable_tools()
    .build()?;

let result = agent.execute("为量子计算趋势研究创建任务图").await?;
```

### 13. 当前原生流与完整结束

`chat_stream/execute_stream` 保留流式事件能力；消费者使用当前 `AssistantMessage` /
`ExecutionStatus` 及公共 `AgentOutputProjection`，runtime `FinalAnswer` 只确认批准正文。
最终通知不能提前break；同一原source必须读取到物理EOF，处理原错误后才能finish并返回成功。
推理、进度与正文分开，安全最终正文不漏、不双拼，不从普通String补造结算。

完整消费代码统一维护在已纳Cargo example编译链的
[demo17_chat](echo-agent-learning/examples/demo17_chat.rs)，避免README另写一套状态机。
配置模型后可手动运行：

```bash
cargo run -p echo-agent-learning --example demo17_chat
```

例子的默认main只选Part4比较；要实际观察流式输出，请在同文件main启用Part3的
`demo_chat_stream()`。这里保留原默认行为，不自动增加模型调用次数。

当前入门文档的同类片段纳入workspace-only learning crate的`no_run` rustdoc编译链，
[原生协议说明](docs/zh/43-native-message-execution.md)解释结果、显示与物理结算的区别。

### 14. 结构化输出 — LLM 响应转 Rust 类型

使用 JSON Schema 验证从 LLM 响应中提取结构化数据。

```rust
#[derive(Serialize, Deserialize)]
struct Contact { name: String, email: String, phone: String }
let contacts: Vec<Contact> = agent.extract("从这段文本中提取联系人信息...").await?;
```

### 15. 声明式工作流 — YAML/JSON 工作流定义

无需写 Rust 代码即可定义 Agent 图。

```yaml
name: research_pipeline
nodes:
  - name: researcher
    type: agent
    model: qwen3.7-max
    system_prompt: "你是研究助手"
    input_key: task
    output_key: research
  - name: writer
    type: agent
    model: qwen3.7-max
    system_prompt: "你是写作助手"
    input_key: research
    output_key: result
edges:
  - from: researcher
    to: writer
entry: researcher
finish: [writer]
```

```rust
let graph = Graph::from_yaml("workflow.yaml")?;
let result = graph.run(state).await?;
```

### 16. 护栏系统 — 规则和 LLM 驱动的内容过滤

通过可定制的护栏管道在输入和输出端阻止或修改不安全内容。

```rust
#[guard(name = "length-limit")]
async fn check_length(content: &str, _: GuardDirection) -> Result<GuardResult> {
    if content.len() > 50000 {
        Ok(GuardResult::Block { reason: "内容过长".into() })
    } else {
        Ok(GuardResult::Pass)
    }
}
```

### 17. 图工作流引擎 — LangGraph 风格状态机

构建支持线性管道、条件分支、循环和并行扇出/扇入的复杂工作流。

```rust
let graph = GraphBuilder::new("etl_pipeline")
    .add_function_node("extract", |state| Box::pin(async move {
        state.set("data", vec!["hello", "world"])?;
        Ok(())
    }))
    .add_function_node("transform", |state| Box::pin(async move {
        // 转换数据...
        Ok(())
    }))
    .add_edge("extract", "transform")
    .add_edge("transform", Graph::END)
    .build()?;

let result = graph.run(state).await?;
```

还支持**流式执行**：`graph.run_stream(state).await?` 每个节点产生 `WorkflowEvent`。

### 18. IM 通道 — 将 Agent 部署到即时通讯平台

通过 QQ（WebSocket）和飞书（Webhook）连接你的 Agent，自动管理 Token 和重连。

```rust
// QQ Bot — WebSocket 网关
let qq = QqChannel::new(QqConfig::new(app_id, client_secret))?;

// 飞书 — HTTP Webhook
let feishu = FeishuChannel::new(FeishuConfig::new_webhook(
    app_id,
    app_secret,
    "0.0.0.0:8080".into(),
    "/webhook".into(),
    None,
))?;

let mut manager = ChannelManager::new();
manager.register(Box::new(qq));
manager.register(Box::new(feishu));
for started in manager.start_all(handler).await {
    started.result?;
}
manager.stop_all().await?;
```

功能特性：
- **统一 `ChannelPlugin` 接口** — 实现一个 trait 即可添加新平台
- **自动 Token 管理** — OAuth 缓存和刷新，无需手动处理
- **WebSocket 重连** — 指数退避，永不静默断开
- **消息队列** — 异步 `mpsc` 通道防止高负载下消息丢失
- **白名单支持** — `ChatConfig::with_allow_from()` 实现访问控制

### 19. 宏系统 — 常用模式的声明式 API

`#[tool]`、`#[callback]`、`#[guard]`、`#[handler]`、`agent!{}`、`messages![]` 等。

```rust
#[callback]
impl MyCallback {
    async fn on_tool_start_with_id(&self, _agent: &str, call_id: &str, tool: &str, _args: &serde_json::Value) {
        println!("[工具:{call_id}] {tool}");
    }
}
```

### 20. Web 工具 — 搜索互联网和获取网页

让你的 Agent 拥有实时互联网访问能力。

```rust
use echo_agent::tools::web::{WebSearchTool, WebFetchTool};

// 自动选择最佳提供商：Tavily > Brave > DuckDuckGo
agent.add_tool(Box::new(WebSearchTool::auto()));
agent.add_tool(Box::new(WebFetchTool::new()));
```

| 提供商 | 费用 | 质量 | 备注 |
|--------|------|------|------|
| DuckDuckGo | 免费 | 中等 | HTML 抓取，无需 API Key |
| Brave | 免费 2k/月 | 高 | 官方 API |
| Tavily | 付费（有免费额度） | 最高 | 为 Agent AI 优化 |

### 21. 自我审查 — 作为工具的质量评估

使用 ReviewTool 让 Agent 评估和优化自己的输出。这遵循业界最佳实践（Hermes、Claude Code），反思是工具能力而非独立的 Agent 类型。

```rust,ignore
let llm_config = LlmConfig::openai(
    std::env::var("OPENAI_API_KEY").unwrap_or_default(),
    "gpt-5.5",
);
let llm_client: Arc<dyn LlmClient> = Arc::from(llm_config.build_client()?);
let critic = Arc::new(LlmCritic::new(llm_client.clone()));
let review_tool = ReviewTool::new(critic);

let agent = ReactAgentBuilder::new()
    .model("gpt-5.5")
    .llm_config(llm_config)
    .llm_client(llm_client)
    .system_prompt("你是技术写手。使用 review 工具自我审查你的作品。")
    .enable_tools()
    .tool(Box::new(review_tool))
    .build()?;

// Agent 现在可以调用 review(task, output) 来评估自己的作品
let result = agent.execute("撰写量子计算摘要，然后审查它").await?;
```

### 22. 快照与回滚 — 时光机调试

```rust
let snapshot_id = agent.snapshot()?;  // 捕获当前状态
// ... 一些出问题的操作 ...
agent.rollback(1)?;                   // 回退 1 步
agent.rollback_to(&snapshot_id)?;     // 或回退到指定快照
```

### 23. 熔断器 — LLM 不可用时自动快速失败

```rust
let cb_config = CircuitBreakerConfig::new()
    .failure_threshold(5)
    .timeout(Duration::from_secs(30));
agent.set_circuit_breaker(cb_config);
```

---

## 宏速查

| 宏 | 类型 | 生成 |
|----|------|------|
| `#[tool]` | 过程宏 | 从 async fn 生成 TypedTool |
| `#[callback]` | 过程宏 | 从 impl 块生成 AgentCallback |
| `#[guard]` | 过程宏 | 从 async fn 生成 Guard |
| `#[handler]` | 过程宏 | 从 impl 块生成 HumanLoopHandler |
| `#[compressor]` | 过程宏 | 从 async fn 生成 ContextCompressor |
| `#[permission_policy]` | 过程宏 | 从 async fn 生成 PermissionPolicy |
| `#[audit_logger]` | 过程宏 | 从 impl 块生成 AuditLogger |
| `agent!{}` | 声明宏 | Agent 构建 |
| `messages![]` | 声明宏 | 消息列表构建 |
| `tool_params!{}` | 声明宏 | JSON Schema 构建 |
| `chat_request!{}` | 声明宏 | ChatRequest 构建 |

---

## 示例

所有示例现在按 `验收样例`、`条件验收样例`、`教学示例` 三类维护。
完整分层清单和维护规则见 `echo-agent-learning/examples/README.md`。

| # | 示例 | 演示内容 |
|---|------|---------|
| 01 | [`demo01_tools`](echo-agent-learning/examples/demo01_tools.rs) | `#[tool]` 宏自定义工具 |
| 02 | [`demo02_tasks`](echo-agent-learning/examples/demo02_tasks.rs) | DAG 任务规划 |
| 03 | [`demo03_approval`](echo-agent-learning/examples/demo03_approval.rs) | 人工审批 |
| 04 | [`demo04_subagent`](echo-agent-learning/tests/example_contracts/demo04_subagent.rs) | 多 Agent 编排 |
| 05 | [`demo05_compressor`](echo-agent-learning/examples/demo05_compressor.rs) | 上下文压缩 |
| 06 | [`demo06_mcp`](echo-agent-learning/examples/demo06_mcp.rs) | MCP 工具服务器 |
| 07 | [`demo07_skills`](echo-agent-learning/examples/demo07_skills.rs) | 内置技能 |
| 08 | [`demo08_external_skills`](echo-agent-learning/examples/demo08_external_skills.rs) | 外部技能加载 |
| 09 | [`demo09_file_shell`](echo-agent-learning/examples/demo09_file_shell.rs) | 文件 & Shell 工具 |
| 10 | [`demo10_streaming`](echo-agent-learning/examples/demo10_streaming.rs) | 流式输出 |
| 11 | [`demo11_callbacks`](echo-agent-learning/examples/demo11_callbacks.rs) | 生命周期回调 |
| 12 | [`demo12_resilience`](echo-agent-learning/tests/example_contracts/demo12_resilience.rs) | 重试与容错 |
| 13 | [`demo13_tool_execution`](echo-agent-learning/examples/demo13_tool_execution.rs) | 工具执行配置 |
| 15 | [`demo15_structured_output`](echo-agent-learning/examples/demo15_structured_output.rs) | JSON Schema 输出 |
| 17 | [`demo17_chat`](echo-agent-learning/examples/demo17_chat.rs) | 交互式对话 |
| 18 | [`demo18_semantic_memory`](echo-agent-learning/examples/demo18_semantic_memory.rs) | 语义记忆 |
| 19 | [`demo19_guard`](echo-agent-learning/examples/demo19_guard.rs) | 护栏系统 |
| 20 | [`demo20_audit`](echo-agent-learning/examples/demo20_audit.rs) | 审计日志 |
| 24 | [`demo24_topology`](echo-agent-learning/tests/example_contracts/demo24_topology.rs) | 拓扑可视化 |
| 25 | [`demo25_macros`](echo-agent-learning/examples/demo25_macros.rs) | 宏系统展示 |
| 26 | [`demo26_provider_factory`](echo-agent-learning/examples/demo26_provider_factory.rs) | 动态 LLM 工厂 |
| 27 | [`demo27_sqlite_memory`](echo-agent-learning/examples/demo27_sqlite_memory.rs) | SQLite 持久化 |
| 28 | [`demo28_workflow`](echo-agent-learning/examples/demo28_workflow.rs) | 工作流管道 |
| 29 | [`demo29_sandbox`](echo-agent-learning/examples/demo29_sandbox.rs) | 沙箱执行 |
| 30 | [`demo30_mcp_server`](echo-agent-learning/tests/example_contracts/demo30_mcp_server.rs) | MCP 服务端 |
| 31 | [`demo31_memory_tools`](echo-agent-learning/tests/example_contracts/demo31_memory_tools.rs) | 记忆工具注入 |
| 32 | [`demo32_token_budget`](echo-agent-learning/examples/demo32_token_budget.rs) | Token 预算管控 |
| 33 | [`demo33_retry_policy`](echo-agent-learning/examples/demo33_retry_policy.rs) | 统一重试 |
| 34 | [`demo34_workflow_stream`](echo-agent-learning/tests/example_contracts/demo34_workflow_stream.rs) | 工作流流式 |
| 35 | [`demo35_dynamic_tools`](echo-agent-learning/examples/demo35_dynamic_tools.rs) | 动态工具管理 |
| 36 | [`demo36_multimodal`](echo-agent-learning/examples/demo36_multimodal.rs) | 多模态消息 |
| 37 | [`demo37_declarative_workflow`](echo-agent-learning/tests/example_contracts/demo37_declarative_workflow.rs) | YAML/JSON 工作流 |
| 38 | [`demo38_im_channels`](echo-agent-learning/examples/demo38_im_channels.rs) | IM 通道集成 |
| 39 | [`demo39_workflow`](echo-agent-learning/tests/example_contracts/demo39_workflow.rs) | 图工作流引擎 |
| 40 | [`demo40_snapshot`](echo-agent-learning/examples/demo40_snapshot.rs) | 快照与回滚 |
| 41 | [`demo41_web_tools`](echo-agent-learning/examples/demo41_web_tools.rs) | Web 搜索 + 获取 |
| 42 | [`demo42_playwright_mcp`](echo-agent-learning/examples/demo42_playwright_mcp.rs) | Playwright MCP 浏览器自动化 |
| 43 | [`demo43_data_tools`](echo-agent-learning/tests/example_contracts/demo43_data_tools.rs) | Excel / CSV / Word / Text 数据处理 |
| 67 | [`demo67_progress`](echo-agent-learning/tests/example_contracts/demo67_progress.rs) | 进度事件 |
| 68 | [`demo68_human_gate`](echo-agent-learning/examples/demo68_human_gate.rs) | 人工审批门禁 |
| 70 | [`demo70_scheduler`](echo-agent-learning/examples/demo70_scheduler.rs) | 任务调度 |

另有 **6 个综合示例** 展示真实场景应用，并提供一个小型公共门面组合示例：

| 示例 | 场景 |
|------|------|
| [`demo44_code_laboratory`](echo-agent-learning/examples/demo44_code_laboratory.rs) | 代码执行助手 |
| [`demo45_customer_service`](echo-agent-learning/examples/demo45_customer_service.rs) | 智能客服 |
| [`demo46_data_analyst`](echo-agent-learning/examples/demo46_data_analyst.rs) | 数据分析助手 |
| [`demo47_enterprise`](echo-agent-learning/examples/demo47_enterprise.rs) | 企业工作流自动化 |
| [`demo48_personal_assistant`](echo-agent-learning/examples/demo48_personal_assistant.rs) | 个人智能助手 |
| [`demo49_research_agent`](echo-agent-learning/examples/demo49_research_agent.rs) | 研究报告助手 |
| [`comprehensive_agent`](echo-agent-learning/examples/comprehensive_agent.rs) | 确定性的工具 + ReAct 组合 |

---

## 兼容性

支持任意 **OpenAI 兼容** API，以及原生 Anthropic、Ollama：

| Provider | 接入地址 | 说明 |
|----------|---------|------|
| OpenAI | `https://api.openai.com/v1` | GPT-4o, GPT-4-turbo |
| Anthropic | `https://api.anthropic.com/v1` | 原生 Claude API |
| DeepSeek | `https://api.deepseek.com/v1` | DeepSeek-V3/R1 |
| 阿里云 Qwen | `https://dashscope.aliyuncs.com/compatible-mode/v1` | Qwen3-max, Qwen-plus |
| Ollama（本地） | `http://localhost:11434` | 原生协议 |
| LM Studio | `http://localhost:1234/v1` | 任意 GGUF 模型 |

---

## 文档

| 主题 | English | 中文 |
|------|---------|------|
| 面向贡献者的 Rust 教程 | — | [ZH](echo-agent-learning/docs/zh/README.md) |
| ReAct Agent | [EN](docs/en/01-react-agent.md) | [ZH](docs/zh/01-react-agent.md) |
| 工具系统 | [EN](docs/en/02-tools.md) | [ZH](docs/zh/02-tools.md) |
| 记忆系统 | [EN](docs/en/03-memory.md) | [ZH](docs/zh/03-memory.md) |
| 上下文压缩 | [EN](docs/en/04-compression.md) | [ZH](docs/zh/04-compression.md) |
| 人工介入 | [EN](docs/en/05-human-loop.md) | [ZH](docs/zh/05-human-loop.md) |
| 多 Agent | [EN](docs/en/06-subagent.md) | [ZH](docs/zh/06-subagent.md) |
| Skill 系统 | [EN](docs/en/07-skills.md) | [ZH](docs/zh/07-skills.md) |
| MCP 协议 | [EN](docs/en/08-mcp.md) | [ZH](docs/zh/08-mcp.md) |
| DAG 任务 | [EN](docs/en/09-tasks.md) | [ZH](docs/zh/09-tasks.md) |
| 流式输出 | [EN](docs/en/10-streaming.md) | [ZH](docs/zh/10-streaming.md) |
| 结构化输出 | [EN](docs/en/11-structured-output.md) | [ZH](docs/zh/11-structured-output.md) |
| Mock 测试 | [EN](docs/en/12-mock.md) | [ZH](docs/zh/12-mock.md) |
| IM 通道 | [EN](docs/en/15-im-channels.md) | [ZH](docs/zh/15-im-channels.md) |
| 图工作流 | [EN](docs/en/17-graph-workflow.md) | [ZH](docs/zh/17-graph-workflow.md) |
| 护栏系统 | [EN](docs/en/18-guard-system.md) | [ZH](docs/zh/18-guard-system.md) |
| Web 工具 | [EN](docs/en/20-web-tools.md) | [ZH](docs/zh/20-web-tools.md) |
| 常用工具 | [EN](docs/en/21-common-tools.md) | [ZH](docs/zh/21-common-tools.md) |
| 论文检索 | [EN](docs/en/22-research-tools.md) | [ZH](docs/zh/22-research-tools.md) |
| Hooks 系统 | [EN](docs/en/23-hooks.md) | [ZH](docs/zh/23-hooks.md) |
| 评估系统 | [EN](docs/en/24-eval-system.md) | [ZH](docs/zh/24-eval-system.md) |
| 自进化系统 | [EN](docs/en/25-self-improvement.md) | [ZH](docs/zh/25-self-improvement.md) |
| 多 Agent 模式 | [EN](docs/en/26-multi-agent.md) | [ZH](docs/zh/26-multi-agent.md) |
| 追踪系统 | [EN](docs/en/27-tracing.md) | [ZH](docs/zh/27-tracing.md) |
| 配置参考 | [EN](docs/en/28-config-reference.md) | [ZH](docs/zh/28-config-reference.md) |
| 运行时与任务系统 | [EN](docs/en/29-long-running-tasks.md) | [ZH](docs/zh/29-long-running-tasks.md) |
| 安全指南 | [EN](docs/en/security.md) | [ZH](docs/zh/security.md) |
| 多语言 SDK | [echo-agent-sdk](https://github.com/EchoYue-lp/echo-agent-sdk) | — |

### SDK 入口

多语言 SDK、源码构建 ACP Host、`_echo_agent/*` protocol、合同和三语言 Client
统一维护在独立的 [echo-agent-sdk](https://github.com/EchoYue-lp/echo-agent-sdk)
仓库。本仓库仍是 SDK 消费的 framework runtime authority，不再把 SDK 作为 workspace
member 编译或发布。

---

## 参与贡献

欢迎贡献！详见 [CONTRIBUTING.md](./CONTRIBUTING.md)。

```bash
git clone https://github.com/EchoYue-lp/echo-agent
cd echo-agent
cargo fmt --all
./scripts/verify.sh
```

---

## 更新日志

详见 [CHANGELOG.md](./CHANGELOG.md)。

---

## License

MIT &copy; echo-agent contributors


## Star History

<a href="https://www.star-history.com/?repos=EchoYue-lp%2Fecho-agent&type=date&legend=top-left">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/chart?repos=EchoYue-lp/echo-agent&type=date&theme=dark&legend=top-left" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/chart?repos=EchoYue-lp/echo-agent&type=date&legend=top-left" />
   <img alt="Star History Chart" src="https://api.star-history.com/chart?repos=EchoYue-lp/echo-agent&type=date&legend=top-left" />
 </picture>
</a>
