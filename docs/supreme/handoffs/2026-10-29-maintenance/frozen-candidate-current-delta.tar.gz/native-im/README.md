# EKO IM 原生事件消费迁移候选

这是受控续跑中的 ignored 候选，只涉及 EKO 三个语义文件：

- `echo-agent-app-core/src/channel_runtime.rs`
- `echo-agent-app-core/src/channel_runtime/outbound.rs`
- `echo-agent-app-core/src/channel_runtime/native_message_tests.rs`

正式 CLI 源没有修改。候选基底取自当前正式源，未创建 Cargo target、未启动 App、未访问账号、未启动 poller、未发送微信或 SSH 请求。

## 迁移内容

`outbound.rs` 删除 IM sink 对旧 `AgentEvent::Token` 的 coalesce、pending buffer 和 native/legacy 分支。原生 `AssistantMessage`、`ExecutionStatus`、`FinalAnswer` 仍经原 envelope、队列预算和终端保留路径投递。`channel_runtime.rs` 删除本地 `ChannelRenderEvent::Token` 事件及 `AgentEvent::Token` 消费 arm；原先用于 steer 状态和失败提示的内部文本改用已有 `Prompt` 投影。`FinalAnswer` 仍只按原 execution identity 去重，`ExecutionStatus` 和 `Terminal` 仍各自保持原生命周期语义。

`native_message_tests.rs` 去掉两个旧 Token fixture。`channel_runtime.rs` 中原来用 Token 生成的测试输入改为带 `AssistantMessageBlock` envelope 的 native fixture；大块测试改为验证原生块的字节预算与身份保留。没有删除 generic final 通知、HITL、Stop、物理 owner、read/ACK/cursor、原发送或通知 receipt 路径。

当前候选三文件中旧引用计数为零：`AgentEvent::Token`、`AgentEvent::ThinkStart`、`AgentEvent::ThinkEnd`、`ChannelRenderEvent::Token`、`pending_token`、`legacy_tokens_seen` 和 token coalesce helper 均不存在。Frame 仍可保留这些公开 enum 变体供其它消费者使用；本候选只让 EKO IM consumer 停止依赖它们。

## 当前真实用例验证提案

Root 安排安全合流后，EKO 唯一 writer 应在同一当前源快照执行以下 focused 组。命令仅为提案，本线没有执行：

```sh
cargo test -p echo-agent-app-core --features channels,test-utils --locked --lib \
  channel_runtime::native_message_tests::

cargo test -p echo-agent-app-core --features channels,test-utils --locked --lib \
  channel_runtime::tests::large_native_block_is_bounded_and_preserves_identity

cargo test -p echo-agent-app-core --features channels,test-utils --locked --lib \
  channel_runtime::aggregate::

cargo test -p echo-agent-app-core --features channels,test-utils --locked --lib \
  channel_runtime::tests::channel_observation_preserves_identity_without_terminal

cargo test -p echo-agent-app-core --features channels,test-utils --locked --lib \
  channel_runtime::tests::terminal_drains_accepted_final_answer_before_publication

cargo test -p echo-agent-app-core --features channels,test-utils --locked --lib \
  channel_runtime::tests::continuation_prompt_is_delivered_before_foreground_terminal

cargo test -p echo-agent-app-core --features channels,test-utils --locked --lib \
  channel_runtime::tests::forty_deferred_weixin_inputs_release_ingress_and_phone_reply_still_resolves

cargo test -p echo-agent-app-core --features channels,test-utils --locked --lib \
  channel_runtime::tests::retirement_foreground_root_remains_stoppable_until_settlement
```

用例覆盖关系如下：

- native reasoning/commentary/partial blocks 按原身份和顺序进入 IM；重复 envelope 只呈现一次，旧 Token 不生成第二份正文。
- `ExecutionStatus::Settled`、候选 block 和 `FinalAnswer` 不关闭 foreground；只有原 `Terminal` 且 driver 事件排空后才完成渲染。
- HITL 继续使用真实 `response_target`，错误使用 `request_id` 的回复仍拒绝；原 prompt、期限和 response future 不改。
- Weixin 输入仍通过原 input pump 的 ACK、cursor、去重和 read/claim 路径；原始发送 owner、Stop 和物理 join 不新增第二套实现。
- 正常、取消、失败、未收尾和 driver observation 都保留原负控。`FinalAnswer` 不是 TaskRun/手机 Received 的替代信号。

候选格式检查和三份准确 base patch dry-run 已通过；Cargo、完整编译、真实 App、账号、微信、SSH 和扫码均未运行。若当前 Frame 后续删除公开 Token/Think enum，需在同一安全合流中用当前 Frame API 三方对齐，不得把本候选整文件覆盖到新源。

候选指纹、补丁和旧源对账见 `manifest.json`；源级审查见 `source-review.md`。
