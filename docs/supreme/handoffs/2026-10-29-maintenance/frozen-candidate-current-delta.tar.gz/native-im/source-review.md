# 原生 IM consumer 候选源审查

审查模式：只读 source review；plan/design：none。审查快照为 manifest 中三份 candidate SHA，未执行 Rust、App、服务或账号操作。

## 结论

源级结论：没有发现候选范围内的重复 owner、第二 poller、第二 runner、DTO 伪 phase 或把 `FinalAnswer` 当作物理完成的代码。候选可以交给 EKO 唯一 writer 做当前源三方合流和 focused 验证。

运行时结论：`insufficient evidence`。格式检查和 patch dry-run 不能证明 Cargo 编译、真实 input pump、Weixin ACK/cursor、HITL、Stop 或物理 owner 在当前完整源上通过。

## 已核对的不变量

1. native `AssistantMessage` 仍由原 `EventEnvelope` 携带 stream、turn、execution、request 和 block identity；渲染去重使用原 event identity。
2. `ExecutionStatus` 仍只产生可见观察文本，不改变 TaskRun 或 foreground 终态；`FinalAnswer` 仍按 execution identity 去重，`Terminal` 仍是 renderer 关闭边界。
3. HITL 代码路径和 `response_target` 解析未改。候选只删除旧 Token/Think consumer，不改 request pairing、response future、300 秒上限或 cancel/Stop。
4. input pump、Weixin sender、ACK/cursor、通知 receipt 和 physical owner 不在候选三文件中重建；原调用链继续由现有模块提供。
5. 候选内旧引用计数为零，未来 Frame 删除 AgentEvent 的旧 enum 变体时，这三个 EKO consumer 文件不再因旧 arm/fixture 编译依赖而阻塞。

## 需要在正式窗口验证的风险

- 删除 token coalesce 后，任何仍只产生 legacy `AgentEvent::Token` 的 producer 都不会形成 IM 正文。这个候选故意要求 native producer 先成为 EKO 主路径；若当前 Frame/EKO 合流仍有 legacy producer，必须在正式窗口保留其失败证据并修 producer 接线，不能用 `!has_native` 猜成功或自动回退。
- 旧 sentence/newline token 测试已迁成 native block fixture；native incremental block、partial/commentary、ExecutionStatus 和真实 Terminal 组合必须实际运行，不能只看字符串拼接测试。
- 大块 native block 只验证 sink 的字节预算和 envelope 保留；真实 sender 分块、HITL、Stop、ACK/cursor 和手机 Received 仍需各自的 owner 窗口。

唯一下一步是 Root 按当前 EKO/Frame source freeze 安排一个相邻 focused Rust 窗口，先执行上述 native IM 组及现有 lifecycle 正负控，再决定是否让 EKO 正式 writer 合流。作者不提交、不清理、不启动 App 或账号操作。
