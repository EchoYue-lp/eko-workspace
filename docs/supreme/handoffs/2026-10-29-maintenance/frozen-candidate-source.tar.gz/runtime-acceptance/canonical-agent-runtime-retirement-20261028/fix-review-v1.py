from pathlib import Path
D=Path(__file__).parent
for rel in ['candidate/echo-core/src/agent/mod.rs','final-surface-after-owner-migrations/echo-core/src/agent/mod.rs']:
 p=D/rel;s=p.read_text().replace('collect_canonical_agent_output(source).await','collect_canonical_agent_output(source, self.current_run_id()).await')
 a=s.index('async fn collect_canonical_agent_output(');b=s.index('/// Agent lifecycle callback interface',a)
 helper='''async fn collect_canonical_agent_output(
    mut source: BoxStream<'_, Result<AgentEvent>>, owner_run: Option<String>,
) -> Result<String> {
    let mut output = AgentOutputProjection::default();
    let mut first_error = None;
    let mut unresolved = None::<ReactError>;
    while let Some(item) = source.next().await {
        let matches_owner = |error: &ReactError, output: &AgentOutputProjection| {
            matches!(error, ReactError::ExecutionNotSettled { run_id, execution_id }
                if owner_run.as_deref() == Some(run_id.as_str())
                    && execution_id.as_deref().is_some()
                    && execution_id.as_deref() == output.execution_id())
        };
        let observed = match item {
            Err(error @ ReactError::ExecutionNotSettled { .. }) => {
                // Foreign observation remains sticky; own real terminal can clear only its exact pair.
                if unresolved.as_ref().is_none_or(|prior| matches_owner(prior, &output)) { unresolved = Some(error); }
                Ok(())
            }
            Ok(AgentEvent::ExecutionStatus(status)) => {
                let checked = output.observe_status(&status);
                match checked {
                    Err(error) => Err(error),
                    Ok(_) => {
                        if matches!(status.status, ExecutionStatusKind::Settled | ExecutionStatusKind::Failed | ExecutionStatusKind::Cancelled)
                            && unresolved.as_ref().is_some_and(|prior| matches_owner(prior, &output)) { unresolved = None; }
                        if let Some(error) = output.terminal_failure() { first_error.get_or_insert(error); }
                        Ok(())
                    }
                }
            }
            Ok(AgentEvent::AssistantMessage { block }) => output.observe_block(&block).map(|_| ()),
            Ok(AgentEvent::FinalAnswer(answer)) => output.confirm_answer(&answer),
            Ok(AgentEvent::Error { failure, .. }) => {
                if failure.terminal_kind == crate::error::AgentTerminalKind::Cancelled {
                    Err(crate::error::AgentError::Cancelled(failure.message).into())
                } else { Err(ReactError::Other(failure.message)) }
            }
            Ok(AgentEvent::Cancelled) => Err(crate::error::AgentError::Cancelled("source cancelled".into()).into()),
            Err(error) => Err(error),
            Ok(_) => Ok(()),
        };
        if let Err(error) = observed { first_error.get_or_insert(error); }
    }
    if let Some(error) = unresolved { return Err(error); }
    if let Some(error) = first_error { return Err(error); }
    output.finish()
}

'''
 s=s[:a]+helper+s[b:];s+=(D/'observation-tests.fragment.rs').read_text();p.write_text(s)
p=D/'tests-first/echo-core/src/agent/mod.rs';s=p.read_text()+(D/'observation-tests.fragment.rs').read_text();p.write_text(s)
p=D/'candidate/echo-orchestration/src/runtime/turn_driver.rs';s=p.read_text();s=s.replace('''                    native_failure.get_or_insert(TurnOutcome::Cancelled);
''','''                    let cause = native_failure.get_or_insert(TurnOutcome::Cancelled).clone();
                    outcome = Some(cause);
''',1).replace('''                    outcome.get_or_insert(cause);
''','''                    outcome = Some(cause);
''',1)
needle='''            let mut pending = source_progress.lock().unwrap_or_else(|p| p.into_inner());'''
new='''            // Borrow the validated source identity from the one existing projection.
            // This is not another mutable owner cache, nor a guess from final text.
            let checked_source_execution = raw_projection.lock().unwrap_or_else(|error| error.into_inner())
                .0.execution_id().map(str::to_string);
            let matched_execution = source_execution.as_deref().or(checked_source_execution.as_deref());
            let mut pending = source_progress.lock().unwrap_or_else(|p| p.into_inner());'''
assert needle in s;s=s.replace(needle,new,1)
s=s.replace('run_id == &source_run && execution_id == &source_execution','run_id == &source_run && execution_id.as_deref() == matched_execution',1)
s=s.replace('Some(status.execution_id.as_str()) == source_execution.as_deref()','Some(status.execution_id.as_str()) == matched_execution',1)
p.write_text(s)
# Caller scope expansion is explicitly requested from F before writing this separate proposed hunk.
base=Path('/Users/ls/MyWork/code/ylp_agent_learn/lp-agent/echo-agent/echo-core/src/agent/output_projection.rs');before=base.read_text();needle='impl AgentOutputProjection {';new=needle+'\n    /// Original source identity, exposed only after its Started was validated.\n    pub fn execution_id(&self) -> Option<&str> { self.execution_id.as_deref() }\n';assert needle in before;after=before.replace(needle,new,1)
for folder,text in [('prerequisite-base',before),('prerequisite-proposal',after)]:
 p=D/folder/'echo-core/src/agent/output_projection.rs';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
print('review1 four findings addressed in ignored functions; existing projection accessor supplied as owner prerequisite request')
