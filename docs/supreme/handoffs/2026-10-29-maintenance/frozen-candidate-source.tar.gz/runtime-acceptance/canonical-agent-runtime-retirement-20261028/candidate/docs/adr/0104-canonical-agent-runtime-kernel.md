# ADR 0104：Agent完整typed输入与单一原生结算边界

状态：ignored候选，接口窄审方向通过；没有Cargo、正式采用或当前全部消费者迁移资格。适用Root已批准NoCompat和本轮三文件任务。

## 背景

当前trait虽然有Message+invocation方法，默认仍能借Text/聊天→execute回退并保留却不处理history/cwd/tool上界；默认stream wrapper可依据FinalAnswer与EOF合成Started/Settled及重排身份。TurnDriver按是否看到Status选择两套完成语义，普通正文在旧模式能成为Completed。callback带ID默认又降级为旧无ID。这些是旧协议表面，不等价于当前CustomAgent、String、Store或非流能力。

## 候选方案

1. 保原默认多模式加更多flag：仍有约束静默丢失和真假终态混用，不采用。
2. 新建Agent运行请求/执行器或第二source owner：重复现有typed Message/invocation/ReAct，增加权威，不采用。
3. 复用现两个typed producer，String/raw/非流便利沿同kernel，只认原Status与EOF：采用。

## 决策

Chat与Execute各保当前上下文语义，以现chat_stream_message_with_invocation_context和execute_stream_message_with_invocation_context为primitive。默认不支持在source开始前明确拒绝，不压Message/Parts、不吞runtime/history/cwd/readonly/positive bound/cancel/resource/input-drain。String转换只增加Message::user；自定义Agent可以显式实现当前两个primitive，保合理能力。ReactAgent/AgentHandle/ProjectAgentAdapter已有覆写由其owner精确保留，不回灌整文件。

非流String只归并同一source，复用AgentOutputProjection，原EOF后验证真正Started/同owner终态/确认正文，保首个原Result错误和必要观察，不从文字完成。运输层FinalAnswer仍是运行时安全正文通知，不为Execution/TaskRun/Goal签成功。TurnDriver只真实Settled可完成，真实usage只LlmUsage，不依ThinkEnd；tail failure和sink failure不能被晚到成功洗掉。取消仍由原producer结算，不由投影器制造Status。

callback当前*_with_id必须接原call id；旧no-ID实现者先由F/SDK/EKO owner迁完再删方法。Token/Think enum同理，producer processor和所有实际消费者先迁；external setter原共享可变状态同ReactAgent snapshot/Handle/EKO adapter同步退，真实configured cwd不是兼容垃圾不能连删。event_envelope的current合同不能猜外部缺失metadata。

## 取舍与迁移边界

当前三文件生产hunk与最终Core旧表面移除hunk分开交付，以调用表列明同期owner依赖。源与回归在F当前firstbatch期间冻结，本线只候选。原driver raw-only fixture须改为显式current typed producer与真实自身Status，原物理EOF/unknown/首因/资源/投递回归不得删；只旧wrapper自动成功、旧TokenThink/UI兼容要求由人类取消，按retired记录，不加skip/matched。

本轮没有修改Store/持久化schema、SDK pin、EKO产品策略、安全/权限门控。可选数据库Store仍合法，原body/Reasoning/provider签名/opaque保留；恢复和副作用不重放仍是新版本必须功能。

## 参考与证据限制

已按规则查官方OpenAI与Anthropic参考：web404、GitHubreset、OpenAI403、Anthropic区域不可用页，未取得正文。完整尝试回执references/，不以HTTP200或失败搜索声称跨产品共识。此取舍依本仓已存在primitive/collector和实际调用路径，不新造机制；外部实现对等性未验证。

## 验收与文档示例

tests-first定义当前String/typed/rich input、无终态/foreign/尾错、原取消身份/EOFguard、driver完成等反控；原Core output_projection/getter与F首批回归不改。本轮只有静态format/apply/afterSHA资格，实际Cargo与当前18新native定义、原矩阵必须F新窗运行。callback示例demo11的with_id函数hunk单独交F，列其它callback/macro/SDK同步；example原已有可执行链仍须owner同批编译。官网由其owner从正式源投影，不由本线跨写，未正式落地前不宣传完成。
