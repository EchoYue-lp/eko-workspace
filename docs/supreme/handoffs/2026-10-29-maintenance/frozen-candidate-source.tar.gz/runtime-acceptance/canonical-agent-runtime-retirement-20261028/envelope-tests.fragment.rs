
#[cfg(test)]
mod canonical_transport_contract_tests {
    use super::*;
    use crate::agent::{AgentPhase,ExecutionStatus,ExecutionStatusKind};
    fn native_status(kind:ExecutionStatusKind,sequence:u64)->AgentEvent {
        AgentEvent::ExecutionStatus(ExecutionStatus{adapter_generated:false,execution_id:"original-execution".into(),request_id:Some("request".into()),sequence,phase:AgentPhase::Terminal,status:kind,reason:None})
    }
    #[tokio::test]
    async fn canonical_transport_does_not_end_at_confirmed_body_or_rewrite_original_status() -> Result<()> {
        let identity=EventIdentity::for_run("run")?.with_execution_id("original-execution")?;
        let input=futures::stream::iter(vec![Ok(native_status(ExecutionStatusKind::Started,0)),Ok(AgentEvent::FinalAnswer("中文🙂".into())),Ok(native_status(ExecutionStatusKind::Settled,8))]).boxed();
        let events=envelope_event_stream(input,identity).collect::<Vec<_>>().await.into_iter().collect::<Result<Vec<_>>>()?;
        assert_eq!(events.len(),3);
        assert!(matches!(events.last().map(|event|&event.payload),Some(AgentEvent::ExecutionStatus(status)) if status.sequence==8&&status.execution_id=="original-execution"&&!status.adapter_generated));
        Ok(())
    }
    #[tokio::test]
    async fn canonical_transport_final_answer_without_source_terminal_is_not_a_successful_trajectory() -> Result<()> {
        let identity=EventIdentity::for_run("run")?;
        let input=futures::stream::iter(vec![Ok(AgentEvent::FinalAnswer("body only".into()))]).boxed();
        let events=envelope_event_stream(input,identity).collect::<Vec<_>>().await.into_iter().collect::<Result<Vec<_>>>()?;
        assert!(events.iter().all(|event|!matches!(&event.payload,AgentEvent::ExecutionStatus(status) if status.status==ExecutionStatusKind::Settled)));
        assert!(events.iter().any(|event|matches!(event.payload,AgentEvent::Error{..})),"plain body/EOF requires a transport refusal; never Completed");
        Ok(())
    }
}
