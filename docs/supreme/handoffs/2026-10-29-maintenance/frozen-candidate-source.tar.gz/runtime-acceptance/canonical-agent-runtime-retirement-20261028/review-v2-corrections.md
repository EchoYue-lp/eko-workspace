# v2静态意见处理

1. 本次observe_status成功且changed=true才标newly_validated_terminal，driver解unknown必须带此局部结果。projection拒绝/重复的Status即使同ID也不解除；Core collector同步changed条件。没有新增owner缓存。
2. I4合法execution=None夹具改为EventIdentity::new(...).with_run_id("run")，显式assertNone，source仍用原native-source，不改owner迎合调用者。
3. 新增冲突/重复terminal两参数反控，保原ExecutionNotSettled、input Accepted；NativeSource fixture在真正poll到EOF后计1，原source guard Drop计1，证明没有以Status/transport拒绝丢source。

当前18函数定义0运行，v2原a943/source/patch/意见完整在archive-review-v2/。原表外getter00仍必须Fsolewriter采用；03/04必须外部owner同期迁移，未取得wholecompile/正式合流资格。
