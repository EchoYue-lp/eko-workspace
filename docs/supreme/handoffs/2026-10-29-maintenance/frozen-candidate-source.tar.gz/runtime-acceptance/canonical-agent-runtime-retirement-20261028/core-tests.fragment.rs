
#[cfg(test)]
mod canonical_agent_runtime_contract_tests {
    use super::*;
    use std::sync::{Arc, Mutex};
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn status(kind: ExecutionStatusKind, ordinal: u64) -> AgentEvent {
        AgentEvent::ExecutionStatus(ExecutionStatus {
            adapter_generated: false,
            execution_id: "native-source".into(),
            request_id: Some("native-request".into()),
            sequence: ordinal,
            phase: AgentPhase::Terminal,
            status: kind,
            reason: None,
        })
    }

    struct Call {
        chat: bool,
        message: Message,
        invocation: AgentInvocationContext,
    }

    #[derive(Default)]
    struct NativeAgent {
        calls: Arc<Mutex<Vec<Call>>>,
        text_calls: AtomicUsize,
        tail_failure: bool,
        terminal_missing: bool,
    }

    impl NativeAgent {
        fn source<'a>(&'a self, chat: bool, message: Message, invocation: AgentInvocationContext)
        -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
            self.calls.lock().unwrap_or_else(|error| error.into_inner()).push(Call { chat, message, invocation });
            Box::pin(async move {
                let mut events = vec![
                    Ok(status(ExecutionStatusKind::Started, 0)),
                    Ok(AgentEvent::FinalAnswer("安全最终中文🙂".into())),
                ];
                if !self.terminal_missing { events.push(Ok(status(ExecutionStatusKind::Settled, 1))); }
                if self.tail_failure { events.push(Err(ReactError::Other("original tail failure".into()))); }
                Ok(futures::stream::iter(events).boxed())
            })
        }
    }

    impl Agent for NativeAgent {
        fn name(&self) -> &str { "native-current-custom" }
        fn model_name(&self) -> &str { "fixture" }
        fn system_prompt(&self) -> &str { "" }
        // 旧required方法只为tests-first编译；新默认便利方法不得回到它们。
        fn execute<'a>(&'a self, _: &'a str) -> BoxFuture<'a, Result<String>> {
            self.text_calls.fetch_add(1, Ordering::SeqCst);
            Box::pin(async { Err(ReactError::Other("text-only entry was used".into())) })
        }
        fn execute_stream<'a>(&'a self, _: &'a str) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
            self.text_calls.fetch_add(1, Ordering::SeqCst);
            Box::pin(async { Err(ReactError::Other("text-only source was used".into())) })
        }
        fn execute_stream_message_with_invocation_context<'a>(&'a self, message: Message, _: CancellationToken, invocation: AgentInvocationContext)
        -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> { self.source(false, message, invocation) }
        fn chat_stream_message_with_invocation_context<'a>(&'a self, message: Message, _: CancellationToken, invocation: AgentInvocationContext)
        -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> { self.source(true, message, invocation) }
    }

    #[tokio::test]
    async fn canonical_default_chat_and_raw_cancel_route_to_their_original_typed_kernels() -> Result<()> {
        let agent = NativeAgent::default();
        assert_eq!(agent.chat("会话").await?, "安全最终中文🙂");
        let events = agent.execute_stream_with_cancel("执行", CancellationToken::new()).await?.collect::<Vec<_>>().await;
        assert_eq!(events.len(), 3);
        let calls=agent.calls.lock().unwrap_or_else(|error| error.into_inner());
        assert_eq!(calls.len(),2);
        assert!(calls.first().is_some_and(|call| call.chat && call.message.text_content().as_deref()==Some("会话")));
        assert!(calls.get(1).is_some_and(|call| !call.chat && call.message.text_content().as_deref()==Some("执行")));
        assert_eq!(agent.text_calls.load(Ordering::SeqCst),0);
        Ok(())
    }

    #[tokio::test]
    async fn canonical_nonstream_waits_for_real_status_and_preserves_original_tail_error() {
        let missing = NativeAgent { terminal_missing: true, ..Default::default() };
        assert!(missing.chat("no terminal").await.is_err());
        let failed = NativeAgent { tail_failure: true, ..Default::default() };
        assert!(matches!(failed.chat("tail error").await, Err(error) if error.to_string().contains("original tail failure")));
    }

    #[tokio::test]
    async fn canonical_box_forwards_rich_message_and_every_invocation_field() -> Result<()> {
        let mut message=Message::user("输入".into());
        message.content=crate::llm::types::MessageContent::Parts(vec![
            crate::llm::types::ContentPart::Text { text:"中文🙂".into() },
            crate::llm::types::ContentPart::File { name:"附件.txt".into(),content:"binary-safe-text".into() },
        ]);
        message.name=Some("native-user".into());
        message.reasoning_blocks=Some(vec![crate::llm::types::ReasoningBlock::Signed { thinking:"思考原文".into(), signature:"sig".into() }]);
        let expected=serde_json::to_value(&message).map_err(|error|ReactError::Other(error.to_string()))?;
        let agent=NativeAgent::default();
        let invocation=AgentInvocationContext {
            runtime:Some(crate::tools::ExternalRunContext { run_id:Some("run".into()),execution_id:Some("native-source".into()),..Default::default() }),
            runtime_state_id:Some("runtime-state".into()),transcript_generation_id:Some("generation".into()),
            working_dir:Some(std::path::PathBuf::from("/current/workspace")),
            disabled_tools:Some(std::collections::HashSet::from(["shell".into()])),
            allowed_tools:Some(std::collections::HashSet::from(["read_file".into()])),
            visible_tools:Some(std::collections::HashSet::from(["read_file".into()])),
            tool_access:Some(crate::tools::ToolAccess::ReadOnly),
            history:Some(vec![Message::user("原会话".into())]),
            run_budget:Some(RunBudgetPolicy { max_model_tokens:Some(12),..Default::default() }),
            ..Default::default()
        };
        let records=Arc::clone(&agent.calls);let boxed:Box<dyn Agent>=Box::new(agent);
        let _events=boxed.chat_stream_message_with_invocation_context(message,CancellationToken::new(),invocation).await?.collect::<Vec<_>>().await;
        let calls=records.lock().unwrap_or_else(|error| error.into_inner());
        let call=calls.first().ok_or_else(||ReactError::Other("typed source was not invoked".into()))?;
        assert_eq!(serde_json::to_value(&call.message).map_err(|error|ReactError::Other(error.to_string()))?,expected);
        assert_eq!(call.invocation.runtime_state_id.as_deref(),Some("runtime-state"));
        assert_eq!(call.invocation.transcript_generation_id.as_deref(),Some("generation"));
        assert_eq!(call.invocation.tool_access,Some(crate::tools::ToolAccess::ReadOnly));
        assert!(call.invocation.history.as_ref().is_some_and(|history| history.first().is_some_and(|message| message.text_content().as_deref()==Some("原会话"))));
        assert!(call.invocation.allowed_tools.as_ref().is_some_and(|allowed|allowed.contains("read_file")));
        assert!(call.invocation.disabled_tools.as_ref().is_some_and(|disabled|disabled.contains("shell")));
        assert_eq!(call.invocation.run_budget.as_ref().and_then(|budget|budget.max_model_tokens),Some(12));
        Ok(())
    }

    struct UnscopedOnly(Arc<AtomicUsize>);
    impl Agent for UnscopedOnly {
        fn name(&self)->&str{"unscoped"}
        fn model_name(&self)->&str{"fixture"}
        fn system_prompt(&self)->&str{""}
        fn execute<'a>(&'a self,_:&'a str)->BoxFuture<'a,Result<String>> {Box::pin(async {Ok("unscoped".into())})}
        fn execute_stream<'a>(&'a self,_:&'a str)->BoxFuture<'a,Result<BoxStream<'a,Result<AgentEvent>>>> {
            self.0.fetch_add(1,Ordering::SeqCst);
            Box::pin(async{Ok(futures::stream::iter([Ok(AgentEvent::FinalAnswer("must not synthesize native status".into()))]).boxed())})
        }
    }
    #[tokio::test]
    async fn canonical_default_refuses_unsupported_invocation_before_starting_unscoped_source() {
        let calls=Arc::new(AtomicUsize::new(0));let agent=UnscopedOnly(calls.clone());
        let invocation=AgentInvocationContext{history:Some(vec![Message::user("must retain".into())]),..Default::default()};
        let result=agent.execute_stream_with_invocation_context("current",CancellationToken::new(),invocation).await;
        assert!(matches!(result,Err(ReactError::Other(message)) if message.contains("canonical typed")));
        assert_eq!(calls.load(Ordering::SeqCst),0);
    }
}

#[cfg(test)]
mod canonical_physical_source_tests {
    use super::*;
    use std::sync::Arc;
    use std::sync::atomic::{AtomicUsize,Ordering};
    struct OwnerGuard(Arc<AtomicUsize>);
    impl Drop for OwnerGuard { fn drop(&mut self){self.0.fetch_add(1,Ordering::SeqCst);} }
    struct Source { entered:tokio::sync::Notify,release:tokio::sync::Notify,drops:Arc<AtomicUsize> }
    impl Agent for Source {
        fn name(&self)->&str{"physical-source"}
        fn model_name(&self)->&str{"fixture"}
        fn system_prompt(&self)->&str{""}
        fn execute<'a>(&'a self,_:&'a str)->BoxFuture<'a,Result<String>>{Box::pin(async{Err(ReactError::Other("unscoped".into()))})}
        fn execute_stream<'a>(&'a self,_:&'a str)->BoxFuture<'a,Result<BoxStream<'a,Result<AgentEvent>>>>{Box::pin(async{Err(ReactError::Other("unscoped".into()))})}
        fn chat_stream_message_with_invocation_context<'a>(&'a self,_:Message,cancel:CancellationToken,_:AgentInvocationContext)->BoxFuture<'a,Result<BoxStream<'a,Result<AgentEvent>>>>{
            Box::pin(async move {
                let source=async_stream::stream!{
                    let _guard=OwnerGuard(self.drops.clone());
                    yield Ok(AgentEvent::ExecutionStatus(ExecutionStatus{adapter_generated:false,execution_id:"original".into(),request_id:Some("request".into()),sequence:0,phase:AgentPhase::Thinking,status:ExecutionStatusKind::Started,reason:None}));
                    if !cancel.is_cancelled(){yield Ok(AgentEvent::FinalAnswer("安全回答".into()));}
                    let kind=if cancel.is_cancelled(){ExecutionStatusKind::Cancelled}else{ExecutionStatusKind::Settled};
                    yield Ok(AgentEvent::ExecutionStatus(ExecutionStatus{adapter_generated:false,execution_id:"original".into(),request_id:Some("request".into()),sequence:1,phase:AgentPhase::Terminal,status:kind,reason:None}));
                    self.entered.notify_one();
                    self.release.notified().await;
                };
                Ok(Box::pin(source) as BoxStream<'a,Result<AgentEvent>>)
            })
        }
    }
    #[tokio::test]
    async fn canonical_nonstream_does_not_release_original_owner_before_physical_eof()->Result<()> {
        let drops=Arc::new(AtomicUsize::new(0));let agent=Source{entered:tokio::sync::Notify::new(),release:tokio::sync::Notify::new(),drops:drops.clone()};
        let mut result=Box::pin(agent.chat("current"));
        assert!(futures::poll!(result.as_mut()).is_pending());
        agent.entered.notified().await;
        assert_eq!(drops.load(Ordering::SeqCst),0);
        agent.release.notify_one();assert_eq!(result.await?,"安全回答");assert_eq!(drops.load(Ordering::SeqCst),1);
        Ok(())
    }
    #[tokio::test]
    async fn canonical_cancel_stream_keeps_original_status_and_eof_instead_of_inventing_completion()->Result<()> {
        let drops=Arc::new(AtomicUsize::new(0));let agent=Source{entered:tokio::sync::Notify::new(),release:tokio::sync::Notify::new(),drops:drops.clone()};
        let cancel=CancellationToken::new();cancel.cancel();
        let mut source=agent.chat_stream_with_cancel("cancel",cancel).await?;
        let started=source.next().await.transpose()?.ok_or_else(||ReactError::Other("missing start".into()))?;
        let terminal=source.next().await.transpose()?.ok_or_else(||ReactError::Other("missing terminal".into()))?;
        assert!(matches!(started,AgentEvent::ExecutionStatus(status) if status.execution_id=="original"&&!status.adapter_generated));
        assert!(matches!(terminal,AgentEvent::ExecutionStatus(status) if status.execution_id=="original"&&status.status==ExecutionStatusKind::Cancelled&&!status.adapter_generated));
        let mut eof=Box::pin(source.next());assert!(futures::poll!(eof.as_mut()).is_pending());agent.entered.notified().await;assert_eq!(drops.load(Ordering::SeqCst),0);
        agent.release.notify_one();assert!(eof.await.is_none());drop(source);assert_eq!(drops.load(Ordering::SeqCst),1);
        Ok(())
    }
}
