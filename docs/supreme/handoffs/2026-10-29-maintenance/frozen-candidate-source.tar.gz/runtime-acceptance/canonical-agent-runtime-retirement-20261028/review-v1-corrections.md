# 源码独审v1四项的候选处理（未运行）

1. driver主loop看到Settled后的真实Error/Cancelled也必须更新最终outcome，保native_failure首因；原Failed/Cancelled状态进入时即保存，后尾Err不能覆盖。
2. collector不把ExecutionNotSettled当永久业务失败；只有当前run＋projection验证Started得到的source execution完全匹配，真实terminal后且读到原EOF才可解除，foreign sticky；无run proof仍拒绝。
3. collector在观察每个已验证Status时立即复用terminal_failure保存首因。后尾Err不得代替原Failed/Cancelled。
4. driver request.execution_id=None时从原projection.execution_id()只读getter匹配该source，显式request ID仍要相同；不从正文/最后status猜owner，不创建另一owner cache。

职责外1函数需求已先向Root/F共享报告，00-owner-projection-getter-prerequisite.patch只提新增read-only accessor，不改已存在terminal_failure/currentprojection/getter实现、状态或源码冻结。F solewriter当前窗口未采用前，本包不能编译/正式合流；无Cargo许可。

补当前native反控3collector＋2driver定义，连原12共17；只定义未运行，不冒产品RED/GREEN。v1原a4ed patch、candidate与block意见在archive-review-v1/保持。
