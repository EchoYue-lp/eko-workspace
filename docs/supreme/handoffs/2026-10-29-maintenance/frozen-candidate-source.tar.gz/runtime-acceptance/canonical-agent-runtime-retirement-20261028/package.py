from pathlib import Path
import json,hashlib,difflib,datetime,re
D=Path(__file__).parent;entry=json.loads((D/'entry.json').read_text());files=list(entry['base']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def patch(a,b,rel):
 old=a.read_text() if a and a.exists() else '';new=b.read_text()
 if old==new:return ''
 return f'diff --git a/{rel} b/{rel}\n'+('new file mode 100644\n' if not old else '')+''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel,n=3))
def save(name,stages):
 chunks=[patch(a,b,rel) for rel,a,b in stages];p=D/name;p.write_text(''.join(chunks));return {'path':name,'sha256':sha(p),'bytes':p.stat().st_size}
parts={}
rel='echo-core/src/agent/output_projection.rs';parts['projection_getter_prerequisite']=save('00-owner-projection-getter-prerequisite.patch',[(rel,D/'prerequisite-base'/rel,D/'prerequisite-proposal'/rel)])
parts['tests_first']=save('01-new-native-tests.patch',[(rel,D/'base'/rel,D/'tests-first'/rel) for rel in files])
parts['production']=save('02-current-typed-kernel.patch',[(rel,D/'tests-first'/rel,D/'candidate'/rel) for rel in files])
parts['surface_removal_after_owner_migrations']=save('03-final-core-protocol-removal-after-owner-migrations.patch',[(files[0],D/'candidate'/files[0],D/'final-surface-after-owner-migrations'/files[0])])
rel='echo-agent-learning/examples/demo11_callbacks.rs';parts['example_owner_hunk']=save('04-demo11-current-id-callbacks.patch',[(rel,D/'example-bases'/rel,D/'example-hunks'/rel)])
rel='docs/adr/0104-canonical-agent-runtime-kernel.md';parts['adr']=save('05-ADR0104.patch',[(rel,None,D/'candidate'/rel)])
parts['full_kernel_before_surface_removal']=save('kernel-full.patch',[(rel,D/'base'/rel,D/'candidate'/rel) for rel in files])
rows=[]
for rel in files:rows.append({'path':rel,'base_sha256':sha(D/'base'/rel),'tests_first_sha256':sha(D/'tests-first'/rel),'candidate_sha256':sha(D/'candidate'/rel),'final_surface_sha256':sha(D/'final-surface-after-owner-migrations'/rel) if (D/'final-surface-after-owner-migrations'/rel).exists() else None})
modules={}
for rel in files:
 text=(D/'candidate'/rel).read_text();newmods=['canonical_agent_runtime_contract_tests','canonical_physical_source_tests','canonical_source_observation_tests'] if rel==files[0] else ['canonical_transport_contract_tests'] if rel==files[1] else ['canonical_turn_kernel_contract_tests'];names=[]
 for mod in newmods:
  a=text.index('mod '+mod);b=text.find('\n#[cfg(test)]',a);b=b if b!=-1 else len(text);names+=re.findall(r'    (?:async )?fn (canonical_\w+)\(',text[a:b])
 modules[rel]=names
manifest={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_IGNORED_KERNEL_IMPLEMENTATION_STATIC_REVIEW_PENDING_OWNER_MIGRATIONS_UNRUN','author_session':'01a17d8e-23e1-78a3-9d3e-0d8b57c31bef','formal_framework_writer':'01a17d6c-d8ad-7900-869b-ee9e6a559473','formal_source_writes':0,'cargo_runs':0,'native_runs':0,'source_files':rows,'patches':parts,'new_native_test_definitions':modules,'new_native_test_count':sum(len(v) for v in modules.values()),'new_native_tests_executed':0,'current_regressions_preserved':'original F driver tests retained verbatim; raw-only fixture migration boundary listed separately, no new skip','legacy_acceptance_disposition':'retired-acceptance-map.json; cancelled not matched/passed/skipped','layering':'existing typed primitive+AgentOutputProjection+ReAct owner; no new executor/store/validator/source owner','three_file_write_scope':'ignored only; sole formal F writer still handles currentfirstbatch','dependencies':'impact-and-owner-dependencies.md','full_retirement_complete':False,'public_surface_removed_in_main_kernel':'default Message->Text/chat->execute/metadata swallowing and synthesized source statuses; driver legacy outcome mode','final_core_surface_gate':'03 only AFTER all registered TokenThink/noIDcallback/externalSetter implementations and affected fixtures migrated by named owners in same source iteration','sdk_boundary':'consumer-call-table.md; SDK Host exact f7 pin remains independent','official_research':'references contain actual failures/region unavailable, no external parity verified','narrow_interface_review':'narrow-review.md (direction only); concrete error correction in interface-error-correction.md','design':'design.md','plan':'plan.md','implementation_review':'v1 block4 preserved; corrections frozen for v2 review','source_baseline_drift':'formal-source-readback.json','prerequisite_request':'projection-owner-getter-request.json','prerequisite_scope':'one read-only accessor requested from F solewriter, no formal source write; existing terminal_failure preserved'}
(D/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'patches':parts,'test_count':manifest['new_native_test_count'],'files':rows}))
