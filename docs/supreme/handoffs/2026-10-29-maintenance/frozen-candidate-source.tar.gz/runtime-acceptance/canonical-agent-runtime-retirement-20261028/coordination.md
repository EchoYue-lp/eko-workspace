# canonical-agent-runtime三文件实际候选V3独审pass，18定义未跑，具名交F采用

- 唯一入口 **canonical-agent-runtime-retirement-20261028/manifest.json / ready-for-root.json / 给F与Root取件.md**。不是纯调查：已写Agent typed默认kernel、非流原EOF+首因、driver单typed入口/原Status终态、transport不以Final或EOF补成功；18 newnative正负定义。runtimeFinal/String/raw/非流/MessageParts全meta/history/CustomAgent/Store能力保留，不新增executor/Store或source owner。
- V3 **kernel-full SHA b8f486499287d54be482cfdfcb2b3a9e1a734c41997305e833614185333643e5**，独立review.md pass/0遗留；原v1静态block4/v2 block2各code/patch/意见保全，不冒自然RED。00getter6887是硬前置且full本身不含00；projection现terminal_failure原逻辑保，scope外1函数先报owner，不整文件覆盖。03/04当前producer/callback/macro/fixture同期迁完才物理删除Core旧表面，配置cwd/模型步callback/runtimeFinal不顺删。
- 01tests-first d82a34c0 /02prod 1bdd57a1 /03最终退面df5c42df /04实际demo11签名7d056f95 /05ADR0104均精确base/afterSHA。六段scratch check/apply自然0、每阶段SHA一致，最后5formatcheck0；正式三源+projection base0漂移，当前Ffirstbatch freeze未动。本线formal/Fsource/Cargo/target/Native/Stage/Commit0，18测试0编译/0执行，不称整体NoCompat/全表/SDK精pin/运行验收完成。
- consumer-call-table及actual inventory实追Frame/EKO/SDK注册调用，明确SDK当前Host非旧AgentProvider；其它scope owner需求已精确列，不因EKO不用删合理框架菜单。官方research 404/403/reset/regionunavailable真实保，未冒外部parity支持。原blocked/风险/Tag/用户数据均保原，取消compat-only记retired不是matched/skip。
- 即时给F/Root采用顺序和两个focused Cargo argv提案已写取件文稿。原driver当前EOF/首因/unknown/guard/投递/输入receipt测试不删，raw-only fixture必须F同批迁currenttyped后跑完整suite。通信只共享文件，不App跨聊；EKO六类域旧包/20JS+fullsrc0/Rust7待窗保持，未让其阻塞本线实现。

