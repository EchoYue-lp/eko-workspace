
#[cfg(test)]
mod canonical_turn_kernel_contract_tests {
    use super::*;
    use std::sync::{Arc,Mutex};
    use std::sync::atomic::{AtomicUsize,Ordering};
    use futures::stream::BoxStream;
    use futures::future::BoxFuture;
    use echo_core::agent::{AgentPhase,ExecutionStatus,ExecutionStatusKind};

    fn status(owner:&str,kind:ExecutionStatusKind,sequence:u64)->AgentEvent {
        AgentEvent::ExecutionStatus(ExecutionStatus{adapter_generated:false,execution_id:owner.into(),request_id:Some("request".into()),sequence,phase:AgentPhase::Terminal,status:kind,reason:None})
    }
    struct NativeSource {
        events:Mutex<Vec<echo_core::error::Result<AgentEvent>>>,
        typed_calls:AtomicUsize,
        text_calls:AtomicUsize,
        seen:Mutex<Option<(Message,AgentInvocationContext)>>,
    }
    impl NativeSource { fn new(events:Vec<echo_core::error::Result<AgentEvent>>)->Self{Self{events:Mutex::new(events),typed_calls:AtomicUsize::new(0),text_calls:AtomicUsize::new(0),seen:Mutex::new(None)}} }
    impl Agent for NativeSource {
        fn name(&self)->&str{"native-source"}
        fn model_name(&self)->&str{"fixture"}
        fn system_prompt(&self)->&str{""}
        fn execute<'a>(&'a self,_:&'a str)->BoxFuture<'a,echo_core::error::Result<String>> {Box::pin(async{Err(ReactError::Other("unscoped entry".into()))})}
        fn execute_stream<'a>(&'a self,_:&'a str)->BoxFuture<'a,echo_core::error::Result<BoxStream<'a,echo_core::error::Result<AgentEvent>>>> {
            self.text_calls.fetch_add(1,Ordering::SeqCst);
            Box::pin(async{Err(ReactError::Other("unscoped source".into()))})
        }
        fn execute_stream_message_with_invocation_context<'a>(&'a self,message:Message,_:CancellationToken,invocation:AgentInvocationContext)->BoxFuture<'a,echo_core::error::Result<BoxStream<'a,echo_core::error::Result<AgentEvent>>>> {
            self.typed_calls.fetch_add(1,Ordering::SeqCst);
            *self.seen.lock().unwrap_or_else(|error|error.into_inner())=Some((message,invocation));
            let events=std::mem::take(&mut *self.events.lock().unwrap_or_else(|error|error.into_inner()));
            Box::pin(async{Ok(futures::stream::iter(events).boxed())})
        }
    }
    #[derive(Default)]
    struct Sink(Mutex<Vec<EventEnvelope>>);
    #[async_trait]
    impl EventSink for Sink {
        async fn on_event(&self,event:EventEnvelope)->echo_core::error::Result<SinkControl>{self.0.lock().unwrap_or_else(|error|error.into_inner()).push(event);Ok(SinkControl::Continue)}
    }
    fn identity()->echo_core::error::Result<EventIdentity>{EventIdentity::for_run("run")?.with_execution_id("native-source")}
    #[tokio::test]
    async fn canonical_driver_text_uses_typed_input_and_preserves_real_owner_and_usage()->echo_core::error::Result<()> {
        let agent=NativeSource::new(vec![Ok(status("native-source",ExecutionStatusKind::Started,0)),Ok(AgentEvent::LlmUsage{model:"fixture".into(),prompt_tokens:3,completion_tokens:5,total_tokens:8,cached_prompt_tokens:0,cache_creation_prompt_tokens:0,usage_reported:true}),Ok(AgentEvent::FinalAnswer("中文🙂".into())),Ok(status("native-source",ExecutionStatusKind::Settled,1))]);
        let sink=Sink::default();let receipt=AgentTurnDriver.drive(&agent,TurnRequest::new(identity()?,"same input").mode(TurnMode::Execute),&sink).await?;
        assert!(matches!(receipt.outcome,TurnOutcome::Completed));assert_eq!(receipt.final_answer.as_deref(),Some("中文🙂"));
        assert_eq!((receipt.prompt_tokens,receipt.completion_tokens,receipt.llm_calls),(3,5,1));
        assert_eq!(agent.typed_calls.load(Ordering::SeqCst),1);assert_eq!(agent.text_calls.load(Ordering::SeqCst),0);
        let seen=agent.seen.lock().unwrap_or_else(|error|error.into_inner());assert!(seen.as_ref().is_some_and(|(message,_)|message.text_content().as_deref()==Some("same input")));
        assert_eq!(sink.0.lock().unwrap_or_else(|error|error.into_inner()).len(),4);
        Ok(())
    }
    #[test]
    fn canonical_final_answer_notification_is_not_a_turn_completion(){assert!(TurnOutcome::classify(&AgentEvent::FinalAnswer("confirmed body".into())).is_none());}
    #[tokio::test]
    async fn canonical_driver_rejects_final_only_missing_final_and_foreign_owner()->echo_core::error::Result<()> {
        let scripts=[
            vec![Ok(AgentEvent::FinalAnswer("body only".into()))],
            vec![Ok(status("native-source",ExecutionStatusKind::Started,0)),Ok(status("native-source",ExecutionStatusKind::Settled,1))],
            vec![Ok(status("native-source",ExecutionStatusKind::Started,0)),Ok(AgentEvent::FinalAnswer("body".into())),Ok(status("foreign",ExecutionStatusKind::Settled,1))],
        ];
        for events in scripts {
            let agent=NativeSource::new(events);
            let request=TurnRequest::from_message(identity()?,Message::user("input".into())).mode(TurnMode::Execute);
            let receipt=AgentTurnDriver.drive(&agent,request,&Sink::default()).await?;
            assert!(!matches!(receipt.outcome,TurnOutcome::Completed));assert!(receipt.final_answer.is_none());
        }
        Ok(())
    }
    #[tokio::test]
    async fn canonical_driver_preserves_original_post_terminal_failure_through_eof()->echo_core::error::Result<()> {
        let agent=NativeSource::new(vec![Ok(status("native-source",ExecutionStatusKind::Started,0)),Ok(AgentEvent::FinalAnswer("before tail".into())),Ok(status("native-source",ExecutionStatusKind::Settled,1)),Err(ReactError::Other("original tail error".into()))]);
        let request=TurnRequest::from_message(identity()?,Message::user("input".into())).mode(TurnMode::Execute);
        let receipt=AgentTurnDriver.drive(&agent,request,&Sink::default()).await?;
        assert!(matches!(receipt.outcome,TurnOutcome::Failed(_)));assert!(receipt.final_answer.is_none());
        Ok(())
    }
}
