from pathlib import Path
D=Path(__file__).parent
files=['echo-core/src/agent/mod.rs','echo-core/src/agent/event_envelope.rs','echo-orchestration/src/runtime/turn_driver.rs']
for rel in files:
 p=D/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((D/'tests-first'/rel).read_bytes())
p=D/'candidate/echo-core/src/agent/mod.rs';s=p.read_text();a=s.index('    /// Execute a task and return the final answer.',s.index('pub trait Agent:'));b=s.index('    /// Reset in-memory conversational state.',a)
s=s[:a]+'''    /// String convenience for a fresh execution. The current typed producer owns
    /// input admission, context reset/restore, cancellation and physical settlement.
    fn execute<'a>(&'a self, task: &'a str) -> BoxFuture<'a, Result<String>> {
        Box::pin(async move {
            let source = self.execute_stream_message_with_invocation_context(
                Message::user(task.to_string()), CancellationToken::new(), AgentInvocationContext::default(),
            ).await?;
            collect_canonical_agent_output(source).await
        })
    }

    /// Current raw-event convenience, backed by the same typed execution kernel.
    fn execute_stream<'a>(&'a self, task: &'a str)
    -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        self.execute_stream_with_cancel(task, CancellationToken::new())
    }

    fn execute_stream_with_cancel<'a>(&'a self, task: &'a str, cancel: CancellationToken)
    -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        self.execute_stream_message_with_invocation_context(
            Message::user(task.to_string()), cancel.clone(),
            AgentInvocationContext { cancel: Some(cancel), ..Default::default() },
        )
    }

    /// Convert only the caller's explicit String; every invocation field stays intact.
    fn execute_stream_with_invocation_context<'a>(
        &'a self, task: &'a str, cancel: CancellationToken, mut invocation: AgentInvocationContext,
    ) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        invocation.cancel = Some(cancel.clone());
        self.execute_stream_message_with_invocation_context(Message::user(task.to_string()), cancel, invocation)
    }

    /// Multi-turn String convenience. It never falls back to fresh execute semantics.
    fn chat<'a>(&'a self, message: &'a str) -> BoxFuture<'a, Result<String>> {
        Box::pin(async move {
            let source = self.chat_stream_message_with_invocation_context(
                Message::user(message.to_string()), CancellationToken::new(), AgentInvocationContext::default(),
            ).await?;
            collect_canonical_agent_output(source).await
        })
    }

    fn chat_stream<'a>(&'a self, message: &'a str)
    -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        self.chat_stream_with_cancel(message, CancellationToken::new())
    }

    fn chat_stream_with_cancel<'a>(&'a self, message: &'a str, cancel: CancellationToken)
    -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        self.chat_stream_message_with_invocation_context(
            Message::user(message.to_string()), cancel.clone(),
            AgentInvocationContext { cancel: Some(cancel), ..Default::default() },
        )
    }

    fn chat_stream_message_with_cancel<'a>(&'a self, message: Message, cancel: CancellationToken)
    -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        self.chat_stream_message_with_invocation_context(
            message, cancel.clone(), AgentInvocationContext { cancel: Some(cancel), ..Default::default() },
        )
    }

    /// Canonical multi-turn producer. Implementations accept the whole current
    /// Message and invocation or refuse before source admission; no text/metadata fallback.
    fn chat_stream_message_with_invocation_context<'a>(
        &'a self, _message: Message, _cancel: CancellationToken, _invocation: AgentInvocationContext,
    ) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        Box::pin(async { Err(ReactError::Unsupported("canonical typed chat invocation".into())) })
    }

    fn execute_stream_message_with_cancel<'a>(&'a self, message: Message, cancel: CancellationToken)
    -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        self.execute_stream_message_with_invocation_context(
            message, cancel.clone(), AgentInvocationContext { cancel: Some(cancel), ..Default::default() },
        )
    }

    /// Canonical fresh-execution producer. The source retains its original resources,
    /// reports its own native status and closes physically; this default invents none.
    fn execute_stream_message_with_invocation_context<'a>(
        &'a self, _message: Message, _cancel: CancellationToken, _invocation: AgentInvocationContext,
    ) -> BoxFuture<'a, Result<BoxStream<'a, Result<AgentEvent>>>> {
        Box::pin(async { Err(ReactError::Unsupported("canonical typed execute invocation".into())) })
    }

'''+s[b:]
# Remove only the obsolete default-wrapper implementation and wrapper/fallback acceptance modules.
a=s.index('/// A cancellation event is a delivery cause');b=s.index('/// Agent lifecycle callback interface',a)
helper='''/// Thin nonstream projection of the same producer; always drain its physical EOF.
/// A publication or error does not authorize dropping callbacks/effects still owned by it.
async fn collect_canonical_agent_output(mut source: BoxStream<'_, Result<AgentEvent>>) -> Result<String> {
    let mut output = AgentOutputProjection::default();
    let mut first_error = None;
    while let Some(item) = source.next().await {
        let observed = match item {
            Ok(AgentEvent::ExecutionStatus(status)) => output.observe_status(&status).map(|_| ()),
            Ok(AgentEvent::AssistantMessage { block }) => output.observe_block(&block).map(|_| ()),
            Ok(AgentEvent::FinalAnswer(answer)) => output.confirm_answer(&answer),
            Ok(AgentEvent::Error { failure, .. }) => Err(failure.into_error()),
            Ok(AgentEvent::Cancelled) => Err(crate::error::AgentError::Cancelled("source cancelled".into()).into()),
            Err(error) => Err(error),
            Ok(_) => Ok(()),
        };
        if let Err(error) = observed { first_error.get_or_insert(error); }
    }
    if let Some(error) = first_error { return Err(error); }
    output.finish()
}

'''
# Failure has no into_error public method: use retained source-classified typed message via current AgentFailure API.
helper=helper.replace('Err(failure.into_error())','Err(ReactError::Other(failure.message.clone()))')
s=s[:a]+helper+s[b:]
a=s.index('#[cfg(test)]\nmod default_pure_text_chat_tests');b=s.index('#[cfg(test)]\nmod canonical_agent_runtime_contract_tests',a);s=s[:a]+s[b:]
p.write_text(s)
# Strict transport uses runtime terminal only; it still drains later original items instead of cutting at publication/status.
p=D/'candidate/echo-core/src/agent/event_envelope.rs';s=p.read_text().replace('''        // 运输层只识别生产者已有的runtime事实，不再于已确认正文处截掉尾部状态。
        // 旧custom Agent没有runtime事件时仍沿原公开terminal合同读取。
        let mut native_execution = false;''','''        // 当前source的真实状态是唯一执行终态；正文通知不选择另一种运输模式。''')
s=s.replace('''            native_execution |= matches!(payload, AgentEvent::ExecutionStatus(_));
            let is_terminal = if native_execution {
                payload.is_execution_terminal()
            } else {
                payload.is_terminal()
            };''','''            let is_terminal = payload.is_execution_terminal();''',1)
s=s.replace('''            if is_terminal {
                terminal_emitted = true;
                break;
            }''','''            if is_terminal { terminal_emitted = true; }
            // 不提前drop：同一producer仍可能有真正尾错/资源结算。''',1)
# Trajectory validation must not accept an old final-only transport as current success.
s=s.replace('''    let native_execution = events
        .iter()
        .any(|event| matches!(event.payload, AgentEvent::ExecutionStatus(_)));''','',1)
s=s.replace('''        if if native_execution {
            event.payload.is_execution_terminal()
        } else {
            event.payload.is_terminal()
        } {''','''        if event.payload.is_execution_terminal() {''',1)
p.write_text(s)
p=D/'candidate/echo-orchestration/src/runtime/turn_driver.rs';s=p.read_text();s=s.replace('    EventEnvelope, EventIdentity, ExecutionUsage, MessageId, TurnId, envelope_event_stream_after,','    AgentOutputProjection, EventEnvelope, EventIdentity, ExecutionUsage, MessageId, TurnId, envelope_event_stream_after,',1)
s=s.replace('            AgentEvent::FinalAnswer(_) => Some(Self::Completed),','            AgentEvent::FinalAnswer(_) => None,',1)
a=s.index('        let raw = match (&input, request.mode, invocation)');b=s.index('        let mut source_has_runtime_status = false;',a)
s=s[:a]+'''        let message = match input {
            TurnInput::Text(text) => Message::user(text),
            TurnInput::Message(message) => *message,
        };
        let invocation = invocation_with_cancel(invocation, &token);
        let raw = match request.mode {
            TurnMode::Chat => agent.chat_stream_message_with_invocation_context(message, token.clone(), invocation).await,
            TurnMode::Execute => agent.execute_stream_message_with_invocation_context(message, token.clone(), invocation).await,
        };
        // Reuse the existing pure canonical projection, not another completion validator/source.
        let source_projection = std::sync::Arc::new(std::sync::Mutex::new((AgentOutputProjection::default(), None::<ReactError>)));
        let raw_projection = source_projection.clone();
''' +s[b:]
s=s.replace('        let mut source_has_runtime_status = false;\n','',1)
s=s.replace('''            source_has_runtime_status |= matches!(item, Ok(AgentEvent::ExecutionStatus(_)));''','''            {
                let mut state = raw_projection.lock().unwrap_or_else(|error| error.into_inner());
                let checked = match item {
                    Ok(AgentEvent::ExecutionStatus(status)) => state.0.observe_status(status).map(|_| ()),
                    Ok(AgentEvent::AssistantMessage { block }) => state.0.observe_block(block).map(|_| ()),
                    Ok(AgentEvent::FinalAnswer(answer)) => state.0.confirm_answer(answer),
                    _ => Ok(()),
                };
                if let Err(error) = checked { state.1.get_or_insert(error); }
            }''',1)
start=s.index('                Ok(event)\n                    if !source_has_runtime_status');end=s.index('                _ => {}',start);s=s[:start]+s[end:]
s=s.replace('        let mut native_execution = false;\n','',1).replace('                    native_execution = true;\n','',1)
s=s.replace('''                        if !native_execution {
                            outcome = Some(TurnOutcome::Completed);
                        }
''','',1)
s=s.replace('''                    if native_execution {
                        native_failure.get_or_insert(TurnOutcome::Cancelled);
                    } else {
                        outcome.get_or_insert(TurnOutcome::Cancelled);
                    }''','''                    native_failure.get_or_insert(TurnOutcome::Cancelled);''',1)
s=s.replace('''                    if !native_execution {
                        outcome.get_or_insert(cause);
                    }''','''                    outcome.get_or_insert(cause);''',1)
s=s.replace('if outcome.is_none() && !native_execution {','if outcome.is_none() {',1)
# Do not permit a valid status from a foreign execution to override a delivery or source failure.
anchor='''        let outcome = outcome.unwrap_or_else(|| {'''
extra='''        {
            let mut projection = source_projection.lock().unwrap_or_else(|error| error.into_inner());
            let contract_error = projection.1.take().or_else(|| projection.0.finish().err());
            if let Some(error) = contract_error {
                outcome = Some(native_failure.take().unwrap_or(TurnOutcome::Failed(AgentFailure::try_from(&error)?)));
            }
        }
        if let TurnDeliveryOutcome::Failed(failure) = &delivery {
            outcome = Some(TurnOutcome::Failed(failure.clone()));
        }
'''
assert anchor in s;s=s.replace(anchor,extra+anchor,1)
# Exact source status identity must agree with the caller-provided execution coordinate.
old='''            let mut pending = source_progress.lock().unwrap_or_else(|p| p.into_inner());'''
new='''            let mut pending = source_progress.lock().unwrap_or_else(|p| p.into_inner());
            if let Ok(AgentEvent::ExecutionStatus(status)) = item
                && source_execution.as_deref().is_some_and(|owner| owner != status.execution_id)
            {
                let mut projection = raw_projection.lock().unwrap_or_else(|error| error.into_inner());
                projection.1.get_or_insert_with(|| ReactError::Other("source execution does not match the admitted turn identity".into()));
            }'''
assert old in s;s=s.replace(old,new,1)
# Adapter provenance no longer participates in current cause selection; it is rejected by projection.
s=s.replace('''                        let preserve_delivery_cause = status.adapter_generated
                            && matches!(delivery, TurnDeliveryOutcome::Failed(_))''','''                        let preserve_delivery_cause = matches!(delivery, TurnDeliveryOutcome::Failed(_))''',1)
# Unused fixture Arc import is not part of the production change.
s=s.replace('    use std::sync::{Arc,Mutex};','    use std::sync::Mutex;')
p.write_text(s)
print('3-file canonical candidate written; no formal source write or Cargo')
