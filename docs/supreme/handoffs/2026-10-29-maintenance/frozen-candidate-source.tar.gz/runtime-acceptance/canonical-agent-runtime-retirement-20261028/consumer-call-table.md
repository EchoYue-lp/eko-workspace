# 当前实际调用与需同步边界

| 调用方 | 当前真实注册/入口 | 必须保留/同步 |
| --- | --- | --- |
| Framework ReactAgent | src/agent/react/mod.rs impl Agent，全部String/Message/invocation覆写 | 保原run_stream_message_entry及configured cwd/history/provider；不由本线改 |
| Frame AgentHandle | src/agent/handle.rs LockedStreamCall及RwLockAgentWrapper，SDK factory真实to_boxed_agent | 2 typed primitive显式覆写已在；外部setter删时同步forward methods，不能改为text提取 |
| EKO GUI/IM | chat_driver.rs TurnRequest::from_message + Execute + invocation | 保原EventIdentity/Message/Parts/history/资源/输入drain；driver统一Text时不影响rich |
| EKO TaskRuntime/cron | executor/events.rs String TurnRequest::new；unattended.rs rich from_message | String仍合法当前能力；receipt usage与真实terminal，不等TaskRun/Goal自动完成 |
| EKO ProjectAgentAdapter | infra/factory.rs实际注册，project/agent_adapter.rs typed与String覆写 | 保working directory准备与typed projector；external setter转发由EKO owner删，configured cwd不能顺删 |
| SDK Session | factory.rs CoreProfileSessionFactory → AgentHandle::to_boxed_agent → AcpSession → Frame TurnDriver | Host当前没有live AgentProvider，这个名字仅旧A2A inventory；不能误删Session工厂 |
| SDK RunStart | core_profile/handler.rs Chat/Execute String与ChatMessage/ExecuteMessage四输入；wire.rs完整Message转换 | Parts/role/name/toolID/reasoning/native/history沿值传，不压String |
| SDK CustomAgentProxy | extension_bridge.rs:9664真实register_agent，8840/8903显式typed覆写 | run_stream_scoped持原callback owner/lease；转换失败也drain原源；不能让默认wrapper合成成功 |
| SDK输出/callback | wire_envelope保完整EventEnvelope；native_message.rs封闭typed镜像；callback proxy实际9645注册 | TokenThink退enum或callback无ID签名变更须Protocol/Host/三语同步；通用JSON不能证明全消费者已支持 |
| ACP | Session::set_working_dir真实配置；runtime.rs调用TurnDriver | 配置cwd能力保留，不能把外部context退役扩大到配置setter |
| Callback | ProgressBridge、Topology、Audit、macros、learning示例均真实no-ID实现 | 先迁*_with_id保持同call_ID，再删旧方法，不能删方法后让通知静默消失 |

关键sourceRefs完整SHA/命中行见current-source-refs.json；本表来自实际代码探索，SDK精pin仍f7bac62，不能拿本地Frame源当其已构建资格。上表不是旧兼容承诺：取消的是wrapper/text猜测与旧协议双轨；当前合理API和自定义实现仍必须明确承接当前typed kernel。

需要F/Root本轮明确职责外接缝：ReactAgent/Handle external snapshot caller清理；TokenThink的processor/EKO/SDK实际producer-consumer同源迁移；callback ProgressBridge/Topology/Audit/macros/examples当前ID方法。所有这些不在本线正式写权，本线只给Core函数hunk与准确迁移表，不跨写或覆盖F当前projection新getter/回归。
