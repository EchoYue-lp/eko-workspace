# 当前候选静态编辑过程原问题

1. 早期写entry脚本因非UTF8内容解析失败，未执行写入，改ASCII脚本后正常保存。
2. 窄接口报告引用了不存在的ReactError::Unsupported；本线完整核error.rs后改现有Other拒绝路径。没有运行编译，不能称真实Cargo RED。
3. 静态替换collector时首轮string断言不命中（rustfmt已经换行），该脚本在前半部分完成Box记录字段迁移，后半未执行；后续读取精确现源后修正，不回滚/覆盖正式源。

以上不等产品失败或运行票。真正newnative测试定义尚未执行，原CurrentSourceEOF/metadata/guard/取消反控由tests-first提供；无Cargo许可。
