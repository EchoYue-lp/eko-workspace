# 同源采用前必须闭合的实际owner依赖

本线sole ignored责任：echo-core/src/agent/mod.rs、必要event_envelope、echo-orchestration/src/runtime/turn_driver。正式F solewriter/当前firstbatch源冻结不改。当前candidate不是可直接跨库全量采用资格，不能只贴Core最终删除导致实际实现编译缺项。

- Agent trait改变默认路由后，currentraw CustomAgent必须显式实现现两个typed方法；String/execute/chat上下文和richMessage/invocation都保留。FrameMockAgent有完整typed execute覆写但Chat具体支持需owner对照；AgentHandle/ReactAgent、EKOProjectAdapter已有typed转发均保。SDKHost不是旧AgentProvider，注册factory/CustomAgentProxy调用表已列，精pin保持。
- F处理ReactAgent mutable external snapshot、AgentHandle forwarding，EKO owner去ProjectAdapter外部context forwarding；configuredcwd setter为ACPsession/SDKhandler真实配置能力，继续保留。
- F先把processor/回归/ProgressBridge/Topology/Audit/macros等TokenThink/no-ID callback改到当前语义，SDKowner同步typed镜像/语言callback，EKOowner已做部分NoCompat但不能由名字假设全闭合。真实on_think_start/end是模型步骤callback，不因同名Think事件退休而删除；runtimeFinal/callback校验收尾保。
- 新driver unifiedtyped后，旧raw ScriptedAgent等测试fixture必须当前typed source；裸Final成功兼容要求可以取消，但原EOF/unknown/latecause/cancel/sourceguard/usage/inputreceipt/投递各保原意图。driver-regression-migration-boundary.json记精确旧函数，不能当全部兼容删掉。
- 示例demo11_callbacks五个回调签名hunk已准备，只加call_id参数、沿原打印/统计，不重写业务；echo-macros derive callback接口和其它demo必须F同步。这个例子已有既有可执行编译链，本线无Cargo不声称example通过。
- 官网通用Agent/流式说明与例子镜像需其owner在正式发布源后同步；当前未源迁完，中文ADR明确候选/未验，不加假演示。

本线无Cargo/Native/上线/Stage/Commit，旧风险与原blocked source不清；失败恢复与源资料保留。所有新测试定义未跑，格式不是编译，接口窄审不是实现通过。
