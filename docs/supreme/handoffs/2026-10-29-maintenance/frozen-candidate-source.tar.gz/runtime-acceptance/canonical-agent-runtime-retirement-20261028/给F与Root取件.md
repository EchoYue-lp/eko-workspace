# 三文件canonical runtime退旧表面候选已完成源码审查

唯一入口 **manifest.json**。本line SID01a17d8e-23e1-78a3-9d3e-0d8b57c31bef，正式F solewriter仍01a17d6c-d8ad-7900-869b-ee9e6a559473。F currentfirstbatch sourcefreeze/原getter/既有回归不写；本线Cargo/target/正式源/Native/Stage/Commit均0。不是再给纯方案：三文件实际typed kernel/strict outcome生产候选、18新native定义、Core最终退面、实际例子函数hunk和ADR均已备齐。

## 准确采用顺序与硬依赖

1. **00-owner-projection-getter-prerequisite.patch** SHA6887aea3dfb0bc1b803a8411edc5e8ba75676c84103090c50c14ecb9a6435bfe：只读execution_id accessor，请求已先报F/Root，base/after与原terminal_failure保持见manifest。职责外正式只F owner采用，禁止整投影文件替换。
2. **01-new-native-tests.patch** SHAd82a34c00e6b1f814544a18297abcf6ef04ba2227e3cb26abb2b5f259d3b4896：在原3file追加18个测试定义（Core9＋transport2＋driver7），用于F正常tests-first窗口，不冒静态RED。先保source和原命令/自然退出，compilefixture错误不能算产品RED。
3. **02-current-typed-kernel.patch** SHA1bdd57a191a5c29e5ff1cb9eba6e78e5167c5e62245defc8b30b26f3df0d05bc：对01后的3file函数增量；String/raw/nonstream沿现typed primitives，Unsupported明确在source启动前拒绝，不吞rich/invocation；移除Core默认合成source和legacychatfallback，transport/driver只真Status+原EOF，首因与foreign unknown严格保。kernel-full **b8f486499287d54be482cfdfcb2b3a9e1a734c41997305e833614185333643e5**只01+02，**不含必需00**，不要误当独立编译包。
4. **03-final-core-protocol-removal-after-owner-migrations.patch** SHAdf5c42dfbef970d75ae6bd6058e37769beba3424373407f064555c2a3b7b438c：只有当前TokenThink producer/消费者、callback无ID、外部context setter与raw-only fixture同期迁完后才删Core旧表面。它不是为了保兼容长期双轨，未迁前禁止贴Core先破API；configured cwd、模型步骤callback、runtimeFinal当前能力保留。
5. **04-demo11-current-id-callbacks.patch** SHA7d056f95648a8eb7deddce0d90adcddab2a0ad0930fc3f47c746d682a42183df：现有learning示例5函数签名精确hunk，原行为保留，须和其余真实callback/macro同期由F编译。
6. **05-ADR0104.patch** 中文决策与资格限制；candidate表和consumer-call-table/current-source-refs/actual-call-inventory给真实注册/调用与SHA，impact-and-owner-dependencies列准确其它owner边界。

本3file新主路径已切typed，不另store/executor/validator/source owner。TokenThink实际删除要同步processor/EKO/SDK，callback无ID退面要同步ProgressBridge/Topology/Audit/macros/示例，externalsetter须ReactAgent snapshot/Handle和EKOProjectAdapter同期改；不因此删除String/Parts/history/CustomAgent/Store/非流合理能力。driver原EOF/unknown/首因/guard/投递/输入生命周期回归均保字节；F需把其中raw-only test producer迁到当前typed和真实自身Status后同完整suite验证，不能把它们全当兼容删掉。旧compat-only默认成功/吞字段验收取消只记retired，未加skip/未写matched。

## 已核与仍未验

V3独审pass/0未解决，绑定kernel-full同SHA，原v1/v2 block及修复证据全部保留。最终三源、tests-first、最终Core退面、getter、例子rustfmt check自然0。六段真实scratch check/apply都0，每段afterSHA精确同candidate；formal三源+projection当前base零漂移。上述只是静态读回，18测试0编译/0运行，没有产品RED/GREEN、wholeworkspace、SDK新pin或原生验收资格。

官方参考抓取发生404/403/reset/区域不可用，references保真实结果，不把HTTP200假页面称调研成功。方向主要复用本仓已存在机制，外部parity未验证。Core source里ReactError无Unsupported，本候选按现Other拒绝，不错借Store错误/新增公共schema。

## Root待开窗的命令提案（未运行）

准确target/依赖索引/源freeze与jobs≤5、debug=0由Root/F批准后再执行，当前firstbatch不擅开：

```text
cargo test -p echo_core --lib --locked -j 5 canonical_ -- --test-threads=1 --nocapture
cargo test -p echo_orchestration --lib --locked -j 5 canonical_ -- --test-threads=1 --nocapture
```

selector是当前新source合同，01预期部分真实断言RED不能据源码预签；02/03迁完后的完整原workspace/all-targets/all-features与合理CustomAgent/examples/SDK/EKO消费者门禁仍必须全部按本仓流程跑，不用focused过滤掩旧失败。source占用/清理只由原owner管，本线无target可清。
