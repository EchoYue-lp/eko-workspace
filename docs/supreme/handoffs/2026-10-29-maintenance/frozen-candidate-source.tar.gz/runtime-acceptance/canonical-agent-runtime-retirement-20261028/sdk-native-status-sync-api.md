# F／SDK／EKO同步的精确API与原source责任表

本表补充现候选的同源迁移前置；不热并F `684ad1d9d0de9bff57e27e4c04f04232c6af9f1f`，不改SDK/EKO正式源，不开Cargo。SDK F15真实只读trace见`echo-agent-sdk/.echo-semantic/local/sdk-native-consumer-20261027/f15-current-host-input-dependency-trace-20261028/`。准确路径/行号/SHA在`sdk-native-status-source-refs.json`。这是当前**输出producer/consumer合同缺口**，不是Message API缺失。

## 已有能力，保持签名与真实语义

- F两个`Agent::{execute,chat}_stream_message_with_invocation_context(Message, CancellationToken, AgentInvocationContext) -> BoxFuture<Result<BoxStream<Result<AgentEvent>>>>`已被SDK `CustomAgentProxy`真正覆写；当前Message→wire保role/Parts/name/tool IDs/reasoning/native fields/history，`run_stream_scoped`保原invocation/callback owner。四typed输入路径和String便利保留，不重做输入协议，不删CustomAgent/Store/非流能力。
- `AgentEvent::AssistantMessage { block }`、`AgentEvent::FinalAnswer(String)`、`AgentEvent::ExecutionStatus(ExecutionStatus)`都保留真实当前语义。RuntimeFinal是校验/Guard/Stop/持久化之后的通知，不能因旧FinalAnswerTool退休被连删，不能自身完成Turn/TaskRun/Goal。
- `ExecutionStatusWire`已有execution_id/request_id/sequence/phase/status/reason；`AgentEventWire`已有ExecutionStatus。其通用序列化能力不代表反向chunk路径已能传递该事实。

## 最小输出同步表

下述是给各sole owner的具体实现边界；本line不写他们源码，也不以本表代替其当前设计审查。复用原typed DTO／transport／physical owner，不另建executor或source registry。

| owner／准确表面 | 当前缺口 | 需要的当前API／语义变化 |
| --- | --- | --- |
| SDK Protocol `methods.rs::AgentStreamChunkWire` | 只有AssistantMessage/旧TokenThink/usage/tool等，无ExecutionStatus；FinalAnswer仅complete | 反向chunk可表达真实`ExecutionStatus(ExecutionStatusWire)`的非终态Started/Waiting/ToolPending/Candidate；允许RuntimeFinal及Error/Cancelled通知继续作为当前事件流，不能让这些通知强制截断后继source状态。用原ExecutionStatusWire，不创造另一Status DTO。 |
| SDK Protocol `methods.rs::AgentStreamTerminalWire`／`ExtensionStreamCompleteValue::Agent` | complete只FinalAnswer/Error/Cancelled，不能传真正native terminal | complete表达原runtime的ExecutionStatus，限制为Settled/Failed/Cancelled；Started等非终态不得complete。旧FinalAnswer-only complete作为旧协议表面退役，RuntimeFinal转前述通知路径保原能力。错误通知与传输Failed的因果仍分开保存，不把它们升级成execution事实。 |
| SDK Host `extension_bridge.rs::agent_stream_chunk_from_wire`／`agent_stream_terminal_from_wire` | 现经serde转AgentEventWire，但源enum根本发不出Status | 同步新的typed辨别器/合法kind边界，沿已有`agent_event_from_wire -> native_message::status_to_framework`无损转换，保原execution/request/sequence/phase/reason；不写新ID、不改sequence、不以`adapter_generated=false`洗白一个推断状态。 |
| SDK Host `custom_agent_stream_event`／`CustomAgentProxy::observe_original_stream` | complete Final变成正文通知，F纯投影却要求真实Started/Settled | chunk/complete仅薄转换实际源事件；前者不是成功，后者须确有原runtime终态。转换/传输失败继续drain原owner，ExecutionNotSettled原身份保留；不能由普通EOF、Final文本、ToolResult、RPC ACK或complete包形状补造Started/Settled。 |
| SDK reverse实际实现／原`CallbackInvocationOwner` | 拥有invoke/RPC/remote terminal/physical guard，但transport lifetime不是自动业务成功 | **唯一current runtime／physical owner**在真实准入时发自己的Started，在该同scope原执行实际结算时发终态；沿`ExtensionInvocationContext`传原run/execution坐标并保resource/trace/guard归属。若远端没有原native source能力，明确不能完成canonical Task/Subagent链，不能包装一个synthetic success源。 |
| SDK Host `close_factory_stream`／`FactoryInstanceLease` | 当前见FinalAnswer/Error/Cancelled会取走lease并close；新流还需后继原terminal | 关闭资格跟随真实owner结算与原物理release/EOF，不因RuntimeFinal通知提前close；原unknown不取走/重复close，真实conversion failure仍先保原source直到原RPC/guard结束后报告原错。不得让decoder另成physical owner。 |
| TS/Python/Java当前reverse handlers、types/schema、shared task_subagent fixture与rich-message例子 | 示例目前发Final-only complete；原Task/Subagent消费者比输入小批要求更严格 | 同步chunk／terminal判别与source发出真实native的实现路径；只有源runtime给出的身份和状态可以透传。原输入/physical5控制和完整Task/Subagent成功链分开验证，不把旧小批绿票借给新协议；三语不能只补schema不改实际注册handler。 |
| F `AgentOutputProjection`（现有） | F15已拒adapter_generated，要求自己的Started、真terminal与RuntimeFinal | 保现严格规则与`terminal_failure`，不放宽为Final-only成功。00请求只加原已验证source的只读`execution_id()` getter，供matching观察解除；不新建owner/cache或签名字段。 |
| F `AgentTurnDriver`／Core当前便利API（本候选） | 原dual mode/默认wrapper的兼容推断路径已备候选退役 | 采用01/02三文件kernel前须00getter；String转Message并沿原typed kernel，Completed只真实source Settled＋无尾错/未解除观察/投递失败。matching Unknown只有同run+已验证Started执行、成功且新增的真terminal可解除；foreign/冲突/重复不能洗。 |
| F及SDK callback API | *_with_id默认可能降旧无ID，旧noID实现仍实际注册 | 当前`on_tool_start_with_id`、`on_tool_end_with_id`、`on_tool_error_with_id`、`on_tool_interrupted_with_id`保留原call-ID。F/SDK/学习例子先迁真实实现/DTO再退旧降级；不把Current final callback、usage callback或model-step callback删掉。 |
| EKO `EkoTurnEventSink`／TaskRuntime投影与GUI历史 | 应用读取原envelope/receipt，不能在缺Status时另猜成功 | 继续保原identity/hash/order，Reasoning/Tool/Status分离。只读本原execution终态不直接完成PlanTask/TaskRun/Goal，Goal／Steer权威不变；源缺真状态明确未确认，不能以空UI/ACK/EOF补完成。 |

## 可审原source流与禁止替代

当前完整链需要：真实源admission → Started(原execution) → Assistant/Reasoning/Tool/usage与必要原错误事实 → RuntimeFinal确认通知 → 原Settled/Failed/Cancelled → 原RPC与guard的真实物理结算及source EOF。不同坐标域分开：runtime status.sequence不等RPC chunk.index，也不等外层EventEnvelope.sequence；任何一层只透传／附加自己的运输坐标，不能拿transport数值重写原Status。

String只是当前输入便利层，不是终态证明。合理CustomAgent可以由自身当前runtime显式产生typed事实；原physical owner只有关闭事实时不得因此声称用户任务完成。没有真实native producer时，允许当前输入／physical生命周期小批独立验收，但完整Task/Subagent成功链保持未验/受阻。**不通过删String/CustomAgent能力、恢复旧wrapper、放宽F纯投影、重放旧副作用或给假`adapter_generated=false`来绕过。**

## 已见I2在候选里的处理与资格

本line此前静态独审已定位并修复，不再拿v1/v2旧缺陷当当前新故障：

- 晚Err/Cancelled覆盖先前Completed，原Failed/Cancelled Status立即保存首因，后尾错不能取代；候选driver的`canonical_driver_preserves_original_post_terminal_failure_through_eof`与`canonical_driver_original_terminal_failure_precedes_late_tail_failure`。
- collector及driver只在同run/原source execution、本次验证成功且新增的真实terminal后解除matching Unknown，再等原EOF；foreign/冲突/重复保原Unknown、input Accepted和原guard；`canonical_matching_source_observation_resolves_only_at_its_real_terminal_and_eof`、`canonical_foreign_execution_or_run_observation_is_not_cleared_by_own_settlement`、`canonical_conflicting_or_repeated_terminal_cannot_clear_original_observation`。

精确V3 kernel-full SHA `b8f486499287d54be482cfdfcb2b3a9e1a734c41997305e833614185333643e5`；现18定义0编译/0运行，独审pass仅源码资格；00 getter与03/04当前消费者迁移仍硬前置。F15输入/physical五项的当前metadata/tree准备不属于本line运行票，也不证明本lineV3已编译。

## 同源场景验收，交对应owner未来窗口执行

1. 真正注册的custom/factory native producer走完整parent Task/Subagent链：原Started/Final/终态身份逐字段透传、RuntimeFinal恰一次、原call-ID callback及usage到同一owner；旧String和rich Message两入口都保。
2. Final/ToolResult/ACK后无native terminal或仅transport EOF，必须拒绝成功并保原unknown/物理guard；不能重放已完成effect。
3. own matching观察→真实同execution terminal→原EOF可以解除；foreign run/execution、被拒或重复Status不能解除。取消/Failed先因早于tailErr保留。
4. RuntimeFinal后仍有cleanup/真终态时Factory lease保持；真正原guard release后只close一次。F/EKO/SDK三个receiver的完成语义分别按Execution/PlanTask/TaskRun/Goal原权威记录，不互相借票。
5. 当前reverse chunk进错kind、错identity/sequence或Status转换失败，不伪Status/不截源，沿原错误保全和当前root窗口重验。Protocol/Host/三语生成物、实际handlers、例子一起同步，SDK正式pin与controlled来源资格分别报告。

NoCompat只取消旧协议兼容专用义务，记retired；以上全部是新版本真实能力，不造新兼容验收。没有新增store、executor、通用多用户安全门控或依赖风险例外。
