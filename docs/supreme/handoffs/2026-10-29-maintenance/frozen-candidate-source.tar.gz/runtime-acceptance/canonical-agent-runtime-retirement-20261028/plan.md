# 本轮实现轻计划

唯一设计design.md。Root已授权三文件ignored实现和F函数合流，无Cargo/正式写。产出一个可审的canonical输入与终态收敛包，依赖的其它Frame/EKO/SDK调用同期交owner，无重复executor/Store。

1. 全Frame/EKO/SDK实际调用表、分层与最小接口窄review；列旧兼容取消和当前保留能力，不按名字删。
2. 在既有三文件追加真实newnative正负反控，提供tests-first patch；覆盖rich input/String便利/约束拒绝/真实EOF与原Status，不从fixture错误冒生产RED。
3. 同三文件提供typed defaults/无合成源/driver单路径prod函数patch，中文ADR与现例子迁移hunk；其它文件按精确owner依赖交F，不抢其currentbatch源。
4. 静态format/apply/逐SHA读回、独立源码review；实际Cargo由Root明确新窗，当前只写未运行。原F regression与新projection getter内容不覆盖。

执行次序是同一语义权威迁移，不是长期双模式。发布前必须由Fsolewriter先闭合列出的实际consumer和fixture，切真实路径再删旧表面；本线无权以未运行候选给完整框架/API资格。
