
#[cfg(test)]
mod canonical_source_observation_tests {
    use super::*;
    struct ObservedSource { run:&'static str, execution:&'static str, kind:ExecutionStatusKind, tail_error:bool }
    impl Agent for ObservedSource {
        fn name(&self)->&str{"current-observed-source"}
        fn model_name(&self)->&str{"fixture"}
        fn system_prompt(&self)->&str{""}
        fn current_run_id(&self)->Option<String>{Some("original-run".into())}
        fn execute<'a>(&'a self,_:&'a str)->BoxFuture<'a,Result<String>>{Box::pin(async{Err(ReactError::Other("unscoped".into()))})}
        fn execute_stream<'a>(&'a self,_:&'a str)->BoxFuture<'a,Result<BoxStream<'a,Result<AgentEvent>>>>{Box::pin(async{Err(ReactError::Other("unscoped".into()))})}
        fn chat_stream_message_with_invocation_context<'a>(&'a self,_:Message,_:CancellationToken,_:AgentInvocationContext)->BoxFuture<'a,Result<BoxStream<'a,Result<AgentEvent>>>>{
            Box::pin(async move{
                let status=|kind,sequence|AgentEvent::ExecutionStatus(ExecutionStatus{adapter_generated:false,execution_id:"original-source".into(),request_id:Some("request".into()),sequence,phase:AgentPhase::Terminal,status:kind,reason:Some("original first cause".into())});
                let mut items=vec![Ok(status(ExecutionStatusKind::Started,0)),Err(ReactError::ExecutionNotSettled{run_id:self.run.into(),execution_id:Some(self.execution.into())})];
                if self.kind==ExecutionStatusKind::Settled {items.push(Ok(AgentEvent::FinalAnswer("safe current".into())));}
                items.push(Ok(status(self.kind.clone(),1)));
                if self.tail_error {items.push(Err(ReactError::Other("later tail cause".into())));}
                Ok(futures::stream::iter(items).boxed())
            })
        }
    }
    #[tokio::test]
    async fn canonical_matching_source_observation_resolves_only_at_its_real_terminal_and_eof()->Result<()> {
        let agent=ObservedSource{run:"original-run",execution:"original-source",kind:ExecutionStatusKind::Settled,tail_error:false};
        assert_eq!(agent.chat("request").await?,"safe current");Ok(())
    }
    #[tokio::test]
    async fn canonical_foreign_execution_or_run_observation_is_not_cleared_by_own_settlement(){
        for (run,execution) in [("foreign-run","original-source"),("original-run","foreign-source")] {
            let agent=ObservedSource{run,execution,kind:ExecutionStatusKind::Settled,tail_error:false};
            assert!(matches!(agent.chat("request").await,Err(ReactError::ExecutionNotSettled{run_id,execution_id:Some(id)}) if run_id==run&&id==execution));
        }
    }
    #[tokio::test]
    async fn canonical_original_failed_or_cancelled_status_precedes_late_tail_error(){
        for kind in [ExecutionStatusKind::Failed,ExecutionStatusKind::Cancelled] {
            let agent=ObservedSource{run:"original-run",execution:"original-source",kind:kind.clone(),tail_error:true};
            let result=agent.chat("request").await;
            match kind {
                ExecutionStatusKind::Cancelled=>assert!(matches!(result,Err(ReactError::Agent(error)) if matches!(*error,crate::error::AgentError::Cancelled(ref text) if text=="original first cause"))),
                _=>assert!(matches!(result,Err(error) if error.to_string().contains("original first cause")&&!error.to_string().contains("later tail cause"))),
            }
        }
    }
}
