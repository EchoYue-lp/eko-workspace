"""Consumer test proposals only; each formal writer owns adoption and revision pin."""
from pathlib import Path
import difflib,hashlib,json
P=Path(__file__).resolve().parent
ROOT=P.parents[5]
result={}

def save(rel,before,after,name):
 for directory,text in [('consumer-base',before),('consumer-candidate',after)]:
  f=P/directory/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text)
 patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 (P/name).write_text(patch)
 result[rel]={'base_sha256':hashlib.sha256(before.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(after.encode()).hexdigest(),'patch':name,'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'status':'test source proposal not executed; needs new F variant available under consumer-approved dependency'}

rel='echo-agent-sdk/echo-sdk-host/src/core_profile/wire.rs';before=(ROOT/rel).read_text()
anchor='''            (
                ReactError::from(LlmError::ApiError {
                    status: 403,
                    message: "forbidden".to_string(),
                }),
                ExtensionErrorCode::FrameworkError,
            ),'''
assert before.count(anchor)==1
addition='''
            (
                ReactError::from(LlmError::ProviderError {
                    provider:"anthropic".to_string(),error_type:Some("overloaded_error".to_string()),
                    code:Some(serde_json::Value::Null),message:"original provider message".to_string(),retryable:false,
                }),
                ExtensionErrorCode::FrameworkError,
            ),'''
save(rel,before,before.replace(anchor,anchor+addition,1),'sdk-bounded-error-test.patch')

rel='echo-agent-cli/echo-agent-app-core/src/chat_driver.rs';before=(ROOT/rel).read_text()
anchor='''    #[tokio::test]
    async fn retryable_non_llm_failure_requires_input_instead_of_provider_retry()'''
assert before.count(anchor)==1
addition='''    #[tokio::test]
    async fn typed_nonretryable_sse_provider_error_does_not_schedule_another_turn() -> Result<(), String> {
        let store=prepare_run_turn_for_finalization("sse-error","sse-error-turn")?;
        let error=echo_agent::error::ReactError::from(echo_agent::error::LlmError::ProviderError {
            provider:"anthropic".into(),error_type:Some("overloaded_error".into()),code:Some(serde_json::Value::Null),
            message:"original 429 529 timeout words".into(),retryable:false,
        });
        let failure=echo_agent::error::AgentFailure::try_from(&error).map_err(|error|error.to_string())?;
        assert_eq!(failure.code,"llm_provider");assert!(!failure.retryable);assert_eq!(failure.http_status,None);
        let outcome=TurnReceipt::failed("sse-error-turn",failure).map_err(|error|error.to_string())?;
        assert_eq!(finalize_run_turn(&store,"sse-error",&outcome,None).await?,RunTurnDecision::Stop);
        let continuation=store.get_run_state("sse-error").map_err(|error|error.to_string())?
            .and_then(|state|state.continuation).ok_or("missing original continuation")?;
        assert!(continuation.provider_retry.is_none(),"SSE error默认不准入新的模型/RunTurn");
        Ok(())
    }

'''
save(rel,before,before.replace(anchor,addition+anchor,1),'eko-original-turn-error-test.patch')
(P/'consumer-hunks-manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('prepared2bounded consumer test hunks, no formal writes')
