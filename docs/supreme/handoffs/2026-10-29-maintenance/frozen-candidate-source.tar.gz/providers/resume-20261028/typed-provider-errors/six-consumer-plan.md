# Root 选定的 typed 上游错误：六层消费者验证

本目录仅供 F 下一源批审查合流。当前 F source9988／v02 冻结不变；本线没运行 Cargo、真实模型或 NativeApp。旧四个 per-fix、原 main source、原 source-only review 和失败原件不回写；新 typed 方案不得继承它们的 runtime 资格。

## 唯一形状与行为

`LlmError::ProviderError { provider, error_type, code: Option<Value>, message, retryable }` 是唯一新增运行期错误变体。供应商 error.code 缺字段为 None，显式 null 为 Some(Null)，数字和对象等保原 Value；type 与 message 不从措辞改判。所有当前 provider 适配器统一 `retryable=false`，包括看似 overloaded／rate-limit 的结构值。官方 SDK 原件只证明保 body＋raise，不证明可自动重试已开始的流。

AgentFailure 仍原 category/terminal_kind/retryable/code/http_status/message 六字段：该 cause 为 Llm／Failed、`llm_provider`、false、`http_status=None`，原字段经已有文本投影进入消费者。这里不增加 provider_code/rawValue 等 wire 字段，不承诺运行期 Value 在有界 SDK/持久化投影中端到端原样公开。

真实 HTTP429/5xx仍使用原 ApiError 实际 status 与策略。InvalidResponse 仍用于非法协议、截断和错误终帧；取消仍取原 cancellation事实。旧 retry kernel 的次数、退避、circuit permit、取消和所有 loop 不改；provider流内 Err仍沿原失败收尾，不重新请求已开始的流。SDK outer operation Never 保持。

## 测试与生产分离

- `00-old-api-transport-tests-first.patch`：只引用既有 HTTP fixture／AgentFailure API；可以在原生产实现上编译后运行真实 RED。根本没有新 variant 名称，不能把 missing-variant 编译失败当行为 RED。
- `10-typed-production-and-new-api-contract-tests.patch`：新增声明、生产薄适配、Core/重试新 API 合同测试；后两类新 API 测试在声明存在后执行，不声称声明前有可运行 RED。
- `after-previous4-to-selected-typed.increment.patch`：已采用前四小修时只应用这个后继差分，不能与新全量 typed 生产补丁重复采用。
- `split-manifest.json`：原 base、tests-first、after SHA；scratch 已实际应用两阶段并逐文件核回 8 个 after。只证明补丁组合，不证明 Rust 编译或通过。
- `sdk-bounded-error-test.patch` 与 `eko-original-turn-error-test.patch`：各消费者唯一 writer 的测试提案，需其实际批准的新 F revision可用后才能编译；本线不替 SDK 改 pin／accepted。

## 六层真实消费者

| 层 | 实际源码／现路径 | selector 或最小执行计划 | 必须证明 |
|---|---|---|---|
| 1 Core 运行期与失败投影 | `echo-core/src/error.rs::AgentFailure::try_from` | `provider_error_preserves_runtime_code_shape_without_new_failure_wire`；原 `preserves_terminal_and_retry_facts` | missing/null/number/string在ProviderError中保真；AgentFailure恰原六字段、false、NoneHTTP；真实HTTP状态不变 |
| 2 provider真实HTTP/SSE | `client.rs::collect_provider_sse/collect_provider_json`、原Chat/Anthropic/Responses适配器 | `all_provider_sse_errors_are_typed_nonretryable_without_synthetic_http`、`provider_error_code_missing_null_and_numeric_are_not_coerced`、Chat finish前/后error、signed后error、原usage/plaintext selectors | 通过真实HTTP200 SSE消费typed错误；provider/type/code/message保原、unknownfalse；无成功finish／usage，不伪HTTP；签名/正文和usage既有正控继续 |
| 3 ReAct与原retry kernel | `src/agent/react/mod.rs::is_retryable_llm_error`、`run/retry.rs::retry_llm_call`、`phases/think.rs`流Err原收尾 | `typed_sse_provider_failure_does_not_repeat_the_original_call`；原 `cancellation_during_backoff_starts_no_next_attempt`；原native stop/truncation组 | 同一次provider调用计数1；SSE cause false；真实HTTP429仍按原可取消预算；流Err无FinalAnswer，不恢复控制工具或额外模型循环 |
| 4 Subagent／Workflow真实facade | `src/agent/subagent/executor.rs`、`echo-orchestration/src/workflow/node.rs`现AgentFailure／原事件终态消费 | 复用 `canonical_workflow_preserves_native_first_cause_through_cleanup`、`raw_error_waits_for_original_stream_cleanup` 和 `final_answer_tail_cleanup_error_fails_dispatch_in_every_mode` 原夹具，加 LlmClient Err(ProviderError)／AgentEvent::from_error 脚本，经现pub执行／原节点执行 | 原执行失败cause=llm_provider，无额外工具/模型副作用；结果不会因已有partial／签名或普通正文变success；owner/EOF收尾不改。该层新case尚仅计划，未填通过 |
| 5 EKO原有限RunTurn | `echo-agent-app-core/src/chat_driver.rs::finalize_run_turn` → `task_runtime/turn_lifecycle.rs` | `eko-original-turn-error-test.patch` 的 `typed_nonretryable_sse_provider_error_does_not_schedule_another_turn`；原HTTP可重试test仍保 | ProviderError投影false后Stop、continuation.provider_retry为空，不新RunTurn；真实HTTP可重试cause沿原预算而非新loop；不持久化provider私有body来假补分类 |
| 6 SDK Host有界投影 | `echo-sdk-host/src/core_profile/wire.rs::framework_error` → `failure_wire`／已有JSON-RPC错误 | `sdk-bounded-error-test.patch` 扩原 `framework_error_preserves_cause_without_reclassifying_reverse_deadlines` | 原code/terminal/framework_retryable字段可消费，http字段None不加rawValue；外层Retryability::Never、operation/handle身份仍保；三语言协议没有暗增字段。Rust inventory真实记录enum增量，正式pin另验 |

第4层不能用只读源码审查替实际消费者通过；第5/6层也不能由F source check自动覆盖。所有新实际运行结果、完整selector／filter数量、源码与原件SHA由各层writer保存；当前状态均待执行。

## 资料、原件与公开影响

primary源索引在相邻 `next-batch-split/primary-source-index.json`。固定官方 OpenAI／Anthropic SDK streaming 原件保完整 body 并raise的事实，不支持旧提案三个type自动retry allowlist；该allowlist已被Root明确取消，不应用其旧建议。DeepSeek用户给primary支持标准reasoning usage字段与明文Responses内容。

`ProviderError` 为真实 Rust public enum增量，`echo_agent::error`原通配再导出可见；Core exhaustive classifier和ReAct predicate已在候选同步，SDK完整Rust inventory必须记真实delta，不能称无API变化。新增前已核四仓相关调用，未发现必须为本形状增加AgentFailure／SDK wire字段的caller；若消费者将来确有需要，先给具体caller和字段证据，不另造generic Error API。

架构ADR hunk见本目录独立文稿补丁。现 LlmClient examples 无新增调用写法，仍应在正式writer适用编译链验证；新反控都接现可执行测试模块。官网只由Delivery在真实新源固定后同步，不手改mirror／manifest，不借本提案宣告actual API/native/mainCI通过。
