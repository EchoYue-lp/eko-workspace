
## 2026-10-28：有效 SSE 上游错误的统一运行期分类

用户已明确选择仅扩展一个 `LlmError::ProviderError` 变体，保存 provider、error_type、
原 `code: Option<Value>`、message 与 retryable。code 缺字段和显式 null 分别保留，未知
type／code 不按 message 措辞归类。它是运行期 Rust 公共增量，不是新的错误 bus、loop 或 Store。

不采用将 HTTP200 流内错误包装为 ApiError529、ToolError 或 InvalidResponse 的方案：前者
伪造传输事实，后两者丢失供应商明确失败与协议损坏的区别。Malformed payload 仍可沿原
解析错误拒绝；有效 Chat／Anthropic／Responses SSE error 和 response.failed 明确 error
走 typed cause，先于 pending finish／usage 处理，不能被后续 DONE 成功覆盖。

本次所有 provider 适配器一律 `retryable=false`。固定官方 SDK 只支持保 body 并 raise，
不能据此给 overloaded／rate-limit／api_error 自动重试许可。真实 HTTP429／5xx 仍按原
实际 status 和 retry kernel 处理；ProviderError 分类接原 predicate，不改变次数、退避、
取消或 circuit permit，不在已开始的流内重新请求模型。截断、停止原因和 runtime 最终
回答规则保持原义。

AgentFailure／SDK 仍用既有有界投影，不新增 rawValue/provider_code 等 wire 字段；
http_status 为 None，normalized cause code 为 llm_provider，原 type/code/message 只按原
预算呈现，不承诺运行期 Value 端到端公开。SDK 外层 operation Retryability 仍 Never，
可重试 cause 也不能授权重做已经可能产生副作用的 operation。EKO 沿原有限 RunTurn
失败路径，不另起重试循环。

采用后须分别验证 Core、真实 provider HTTP/SSE、ReAct 原 retry／流收尾、Subagent／
Workflow 实际 facade、EKO 原有限 RunTurn、SDK Host 有界投影。旧公开 API 可运行的
transport 反控先取得真实 RED；依赖新 variant 声明的合同在生产 hunk 后验证，不把
编译缺类型当产品 RED。

当前仅完成 ignored 候选、source review、格式与静态应用检查，Rust、消费者、实际 API
和新版 native 资格待各自真实执行；当前冻结批不热并。旧提案三类型 retry allowlist 已
取消，不把旧 static pass 当 runtime retry 通过，不自动晋升 SDK pin 或官网镜像来源。
