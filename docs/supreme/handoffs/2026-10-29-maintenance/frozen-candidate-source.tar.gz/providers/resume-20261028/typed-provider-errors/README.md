# 选定的统一 ProviderError 后继包

Root 已明确选择五字段运行期 `LlmError::ProviderError`，所有有效 SSE 200 上游 error 默认
`retryable=false`。旧三类型自动 retry allowlist **未采纳并已取消**。本包只在 ignored
准备供 Framework 唯一 writer 下一源批审查，当前 source9988／v02 冻结不热并。

## 精确内容与采用方式

- `combined-with-prior4.patch`：从各 manifest 原 main base 一次采用；含前四项小修及本次
  typed 后继，8 个 F 文件。不要与旧四项生产 patch 重复 apply。
- `00-old-api-transport-tests-first.patch`：只依赖旧 AgentFailure／原 HTTP fixture，可先在
  原实现上编译、执行行为 RED；没有 ProviderError／新 helper 名称。编译失败不是产品 RED。
- `10-typed-production-and-new-api-contract-tests.patch`：声明、生产与需要新 variant 的
  Core／code形状／retry-calls 合同。只在声明存在后运行后者，不假称新增 API 声明前已有
  可执行 RED。两阶段 scratch 实际应用并逐个 SHA 核回，见 `split-manifest.json`。
- `after-previous4-to-selected-typed.increment.patch`：已采用原四项包后仅用这个增量。
  旧包的 InvalidResponse detail 断言在此改为现 AgentFailure 结构断言，不能同时要求
  provider 明确失败仍叫 InvalidResponse。
- `sdk-bounded-error-test.patch`／`eko-original-turn-error-test.patch`：SDK／EKO 各自 owner
  的最小测试提案；不得在旧正式 pin 上强行合入编译。相关原 base/after 哈希与检查在
  `consumer-hunks-manifest.json`。
- `adr-0101-selected-provider-error.patch`：现 ADR0101 的中文后继小 hunk；包括背景、
  取消方案、选择、原内核边界和当前未验证状态。仅 apply-check，不提前声明正式采用。

当前 private conversion 仍在原 client 适配边界。Chat/Anthropic/Responses 传入真实配置的
provider，原 type/code/message 结构保留；code missing/显式 null/number 等不强转。
没有新 parser/executor/store/bus，也没有额外 retry loop。无 explicit provider error 的
incomplete/cancelled/EOF/truncation 仍沿原规则失败，不能“为了 typed”补成功或伪 HTTP。

AgentFailure 原六字段与 SDK 原有界投影不改；cause code 为 llm_provider，http_status=None。
运行期原 code Value 不承诺原样穿过 SDK／持久化 wire；SDK outer Retryability 仍 Never。
当前新 variant 是真实 Rust public 增量，Core exhaustive classifier 和原 ReAct predicate
已同步，SDK Rust inventory、formal pin 和消费者资格仍由其独立 owner 验证。

## 已有证据与未验证

本包 8 源已独立源码审查，0 个新增 finding；rustfmt 语法／格式和静态 apply-check 0。
消费者两 test hunk 和 ADR 亦仅静态准备。**没有运行本包 Cargo、Rust 测试或外部模型。**
六层实际 consumer 计划与准确旧 selector／新增 selector 见 `six-consumer-plan.md`，未执行
项继续保留，不以 SDK／EKO 的旧绿色或原 capture1/actual16 晋级新源。

primary 原件与失败分开保存于相邻 `primary/` 和 `next-batch-split/primary-source-index.json`。
官方 pinned SDK 只支持保 body＋raise；HTTP 200不授权虚构529，message写429/overloaded
也不构成 retry许可。真实HTTP429/5xx和原已可取消／有预算的retry kernel保持。

新增反控挂现可执行 Core／HTTP／ReAct 测试入口，无新 API 操作示例。正式 owner 仍需按
适用门禁编译 examples；官网仅由 Delivery 在真实批准源固定后同步，不手改镜像／manifest。
原四小包、原 main source、失败、capture与恢复材料保原；本目录不 stage/commit/push，
不授予整体 Goal、实际API、native或mainCI完成资格。
