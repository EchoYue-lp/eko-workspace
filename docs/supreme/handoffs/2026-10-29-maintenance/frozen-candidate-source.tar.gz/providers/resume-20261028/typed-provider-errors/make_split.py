"""Preserve old public-API tests-first RED path; never treat missing-variant compile as RED."""
from pathlib import Path
import json,hashlib,difflib,subprocess
P=Path(__file__).resolve().parent;ROOT=P.parents[5]
m=json.loads((P/'manifest.json').read_text());base={};after={}
for rel,facts in m['files'].items():
 base[rel]=(P/'base'/rel).read_text();after[rel]=(P/'candidate'/rel).read_text()
client='echo-agent/echo-integration/src/providers/client.rs';responses='echo-agent/echo-integration/src/providers/responses.rs'
start=after[client].index('    #[tokio::test]\n    async fn chat_provider_error_before_or_after_finish_never_publishes_success')
end=after[client].index('    #[test]\n    fn provider_error_code_missing_null_and_numeric_are_not_coerced',start)
tests=after[client][start:end]
# Every test in this slice uses the already-existing AgentFailure/HTTP fixtures.
assert 'LlmError::ProviderError' not in tests
first={**base};at=base[client].rfind('\n}')
first[client]=base[client][:at]+'\n'+tests+base[client][at:]
marker='#[cfg(test)]\nmod plaintext_reasoning_contract_tests {'
first[responses]=base[responses]+'\n'+after[responses][after[responses].index(marker):]
def patch(old,new,paths):
 return ''.join(''.join(difflib.unified_diff(old[rel].splitlines(True),new[rel].splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))for rel in paths)
test_patch=patch(base,first,[client,responses]);prod_patch=patch(first,after,after)
(P/'00-old-api-transport-tests-first.patch').write_text(test_patch)
(P/'10-typed-production-and-new-api-contract-tests.patch').write_text(prod_patch)
# Incremental option for a writer who has already accepted the previous4 pair;
# includes no second usage/plaintext implementation.
old={**base}
for folder in ['provider-errors','responses-plaintext']:
 prior=json.loads((P.parent/folder/'manifest.json').read_text())
 for rel in prior['files']:old[rel]=(P.parent/folder/'candidate'/rel).read_text()
increment=patch(old,after,after)
(P/'after-previous4-to-selected-typed.increment.patch').write_text(increment)
scratch=P/'split-check';scratch.mkdir(exist_ok=True)
for rel,text in base.items():
 f=scratch/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text)
checks=[]
for name in ['00-old-api-transport-tests-first.patch','10-typed-production-and-new-api-contract-tests.patch']:
 x=subprocess.run(['git','apply','-p1',str(P/name)],cwd=scratch,text=True,capture_output=True)
 checks.append({'patch':name,'exit_code':x.returncode,'stderr':x.stderr});assert x.returncode==0,x.stderr
 target=first if name.startswith('00')else after
 assert all(hashlib.sha256((scratch/rel).read_bytes()).hexdigest()==hashlib.sha256(text.encode()).hexdigest()for rel,text in target.items())
manifest={'status':'Root-selected typed classification tests/prod split; no Rust run','files':{rel:{'base_sha256':hashlib.sha256(base[rel].encode()).hexdigest(),'tests_first_sha256':hashlib.sha256(first[rel].encode()).hexdigest(),'after_sha256':hashlib.sha256(after[rel].encode()).hexdigest()}for rel in base},'patches':{name:hashlib.sha256((P/name).read_bytes()).hexdigest()for name in ['00-old-api-transport-tests-first.patch','10-typed-production-and-new-api-contract-tests.patch','after-previous4-to-selected-typed.increment.patch']},'scratch_apply':checks,'new_api_tests':'Core ProviderError runtime raw shape and retrycalls1 contract require production declaration; not a pre-API RED oracle','old_api_RED_selectors':['chat_provider_error_before_or_after_finish_never_publishes_success','anthropic_signed_stream_error_preserves_payload_and_does_not_finish','all_provider_sse_errors_are_typed_nonretryable_without_synthetic_http','chat_reasoning_usage_survives_actual_json_and_final_choice_sse','responses_plaintext_reasoning_survives_actual_json_and_sse','plaintext_reasoning_contract_tests'],'GREEN_plus_new_API_selectors':['provider_error_preserves_runtime_code_shape_without_new_failure_wire','provider_error_code_missing_null_and_numeric_are_not_coerced','typed_sse_provider_failure_does_not_repeat_the_original_call'],'qualification':'exact source/diff restore only; no compiler or behavior result'}
(P/'split-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('typed split exact8 afterfiles; old API tests-first contains no new variant references')
