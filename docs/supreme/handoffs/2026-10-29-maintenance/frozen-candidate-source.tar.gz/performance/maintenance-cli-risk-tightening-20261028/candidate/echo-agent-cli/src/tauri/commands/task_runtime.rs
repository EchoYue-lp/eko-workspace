//! Tauri IPC commands for the TaskRuntime.
//!
//! Read-only query commands, mutations for creating/managing task runs,
//! subagent execution, and route feedback learning.

use crate::tauri::commands::chat::TauriExecutionProjector;
use crate::tauri::error::IpcError;
use crate::tauri::state::TauriState;

use echo_agent_app_core::api::state::ScopedChatRuntime;
use echo_agent_app_core::api::tasks::task_runtime::types::*;
use echo_agent_app_core::api::tasks::task_runtime::{TaskRuntimeOperation, TaskRuntimeStore};
use std::sync::Arc;

// ── Exact workspace runtime resolution ───────────────────────────────────

async fn task_runtime_for_workspace(
    state: &echo_agent_app_core::api::AppState,
    workspace_id: &str,
) -> Result<(ScopedChatRuntime, Arc<TaskRuntimeStore>), IpcError> {
    if workspace_id.trim().is_empty() {
        return Err(IpcError::Validation(
            "workspace_id must not be empty".to_string(),
        ));
    }
    let runtime = state
        .chat_runtime_for_scope(workspace_id)
        .await
        .map_err(internal)?;
    let store = runtime.task_runtime().ok_or_else(|| {
        IpcError::Internal(format!(
            "TaskRuntime store is not initialized for workspace '{workspace_id}'"
        ))
    })?;
    validate_store_workspace(&store, workspace_id)?;
    Ok((runtime, store))
}

// Capture the existing registered generation before borrowing its TaskRuntime.
// A late history request must not read a replacement under the same workspace id.
async fn task_runtime_for_generation(
    state: &echo_agent_app_core::api::AppState,
    workspace_id: &str,
    generation: Option<&str>,
) -> Result<(ScopedChatRuntime, Arc<TaskRuntimeStore>), IpcError> {
    let Some(generation) = generation else {
        return task_runtime_for_workspace(state, workspace_id).await;
    };
    let control = state
        .workspace_control_for_generation(workspace_id, generation)
        .await
        .map_err(|error| {
            if error.is::<echo_agent_app_core::api::state::ScopedWorkspaceGenerationError>() {
                IpcError::Validation(error.to_string())
            } else {
                internal(error)
            }
        })?;
    let runtime = control.runtime().clone();
    let store = runtime.task_runtime().ok_or_else(|| {
        IpcError::Internal("TaskRuntime is not initialized for this workspace".into())
    })?;
    validate_store_workspace(&store, workspace_id)?;
    Ok((runtime, store))
}

async fn task_runtime_for_generation_run(
    state: &echo_agent_app_core::api::AppState,
    workspace_id: &str,
    run_id: &str,
    generation: Option<&str>,
) -> Result<(ScopedChatRuntime, Arc<TaskRuntimeStore>, TaskRun), IpcError> {
    let (runtime, store) = task_runtime_for_generation(state, workspace_id, generation).await?;
    let run = require_scoped_run(&store, workspace_id, run_id).await?;
    Ok((runtime, store, run))
}

fn validate_store_workspace(store: &TaskRuntimeStore, workspace_id: &str) -> Result<(), IpcError> {
    let active_workspace_id = store.active_workspace_id();
    if active_workspace_id != workspace_id {
        return Err(IpcError::Internal(format!(
            "TaskRuntime scope mismatch: requested workspace '{workspace_id}', store owns '{active_workspace_id}'"
        )));
    }
    Ok(())
}

fn validate_run_workspace(run: &TaskRun, workspace_id: &str) -> Result<(), IpcError> {
    if run.workspace_id != workspace_id {
        return Err(IpcError::Validation(format!(
            "TaskRun '{}' belongs to workspace '{}', not requested workspace '{}'",
            run.run_id, run.workspace_id, workspace_id
        )));
    }
    Ok(())
}

async fn task_runtime_io<T, F>(
    store: &Arc<TaskRuntimeStore>,
    operation: &'static str,
    function: F,
) -> Result<T, IpcError>
where
    T: Send + 'static,
    F: FnOnce(
            Arc<TaskRuntimeStore>,
        ) -> Result<T, echo_agent_app_core::api::tasks::task_runtime::StoreError>
        + Send
        + 'static,
{
    TaskRuntimeOperation::new(store.clone())
        .run_store(operation, function)
        .await
        .map_err(internal)
}

async fn get_scoped_run(
    store: &Arc<TaskRuntimeStore>,
    workspace_id: &str,
    run_id: &str,
) -> Result<Option<TaskRun>, IpcError> {
    let run_id = run_id.to_string();
    let run = task_runtime_io(store, "load scoped TaskRun", move |store| {
        store.get_run(&run_id)
    })
    .await?;
    if let Some(run) = run.as_ref() {
        validate_run_workspace(run, workspace_id)?;
    }
    Ok(run)
}

async fn require_scoped_run(
    store: &Arc<TaskRuntimeStore>,
    workspace_id: &str,
    run_id: &str,
) -> Result<TaskRun, IpcError> {
    get_scoped_run(store, workspace_id, run_id)
        .await?
        .ok_or_else(|| {
            IpcError::NotFound(format!(
                "TaskRun '{run_id}' was not found in workspace '{workspace_id}'"
            ))
        })
}

async fn task_runtime_for_run(
    state: &echo_agent_app_core::api::AppState,
    workspace_id: &str,
    run_id: &str,
) -> Result<(ScopedChatRuntime, Arc<TaskRuntimeStore>, TaskRun), IpcError> {
    let (runtime, store) = task_runtime_for_workspace(state, workspace_id).await?;
    let run = require_scoped_run(&store, workspace_id, run_id).await?;
    Ok((runtime, store, run))
}

// ── Commands ─────────────────────────────────────────────────────────────

/// Fetch a single run by id.
#[tauri::command]
pub async fn get_task_run(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<Option<TaskRun>, IpcError> {
    let (_runtime, store) = task_runtime_for_generation(
        &state.app_state,
        &workspace_id,
        workspace_generation.as_deref(),
    )
    .await?;
    get_scoped_run(&store, &workspace_id, &run_id).await
}

/// The one Requirement/Evidence completion report shared by every surface.
#[tauri::command]
pub async fn get_task_completion_gate(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<CompletionGateReport, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "load TaskRun completion gate", move |store| {
        store.completion_gate_report(&run_id)
    })
    .await
}

/// Confirm a Skip for one exact current-Goal requirement from the GUI.
#[tauri::command]
pub async fn skip_task_goal_requirement(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
    expected_goal_revision: u64,
    requirement_id: String,
    reason: String,
) -> Result<CompletionGateReport, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    task_runtime_io(&store, "skip TaskRun requirement", move |store| {
        store.skip_goal_requirement(
            &run_id,
            expected_goal_revision,
            &requirement_id,
            &reason,
            RunGoalActorSource::Gui,
        )
    })
    .await
}

/// Event-folded long-horizon control state for the existing TaskRun.
#[tauri::command]
pub async fn get_task_continuation(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<Option<RunContinuationState>, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "load TaskRun continuation", move |store| {
        store
            .get_run_state(&run_id)
            .map(|snapshot| snapshot.and_then(|state| state.continuation))
    })
    .await
}

/// Update finite-turn budgets for an existing long-horizon TaskRun. Restart
/// auto-resume remains disabled until a surface can reconstruct its HITL owner;
/// changing a budget never bypasses an existing pause.
#[tauri::command]
pub async fn configure_task_continuation(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
    token_budget: Option<u64>,
    time_budget_seconds: Option<u64>,
) -> Result<RunContinuationState, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    task_runtime_io(&store, "configure TaskRun continuation", move |store| {
        store.update_run_continuation_budgets(&run_id, token_budget, time_budget_seconds)
    })
    .await
}

/// Update the authoritative Goal only from an explicit GUI action. The store
/// enforces paused/quiescent state and optimistic Goal revision matching.
#[tauri::command]
pub async fn update_task_run_goal(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
    expected_goal_revision: u64,
    new_goal: String,
    reason: String,
) -> Result<TaskRun, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    task_runtime_io(&store, "update TaskRun goal", move |store| {
        store.update_run_goal(
            &run_id,
            expected_goal_revision,
            &new_goal,
            &reason,
            RunGoalActorSource::Gui,
        )
    })
    .await
}

/// Send guidance through the safe point of one exact active Subagent attempt.
#[tauri::command]
pub async fn send_task_subagent_message(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    identity: SubagentControlIdentity,
    instruction: String,
) -> Result<SubagentControlReceipt, IpcError> {
    let (_runtime, store, _run) =
        task_runtime_for_run(&state.app_state, &workspace_id, &identity.run_id).await?;
    echo_agent_app_core::api::tasks::task_runtime::SubagentControlService::new(store)
        .send_message(identity, &instruction, SubagentControlActorSource::Gui)
        .await
        .map_err(internal)
}

/// Queue guidance for one exact future Subagent attempt.
#[tauri::command]
pub async fn queue_task_subagent_guidance(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    identity: SubagentControlIdentity,
    instruction: String,
) -> Result<SubagentControlReceipt, IpcError> {
    let (_runtime, store, _run) =
        task_runtime_for_run(&state.app_state, &workspace_id, &identity.run_id).await?;
    echo_agent_app_core::api::tasks::task_runtime::SubagentControlService::new(store)
        .queue_guidance_async(identity, instruction, SubagentControlActorSource::Gui)
        .await
        .map_err(internal)
}

/// Interrupt one exact Subagent attempt without pausing its parent TaskRun.
#[tauri::command]
pub async fn interrupt_task_subagent(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    identity: SubagentControlIdentity,
) -> Result<SubagentControlReceipt, IpcError> {
    let (_runtime, store, _run) =
        task_runtime_for_run(&state.app_state, &workspace_id, &identity.run_id).await?;
    echo_agent_app_core::api::tasks::task_runtime::SubagentControlService::new(store)
        .interrupt_subagent(identity, SubagentControlActorSource::Gui)
        .await
        .map_err(internal)
}

/// Background command cells owned by the run, including bounded terminal facts.
#[tauri::command]
pub async fn list_task_background_cells(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<Vec<BackgroundCellState>, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "list TaskRun background cells", move |store| {
        store.list_background_cells(&run_id)
    })
    .await
}

/// Latest run for a conversation — binds a chat thread to its runtime run.
#[tauri::command]
pub async fn latest_task_run_for_conversation(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    conversation_id: String,
    workspace_generation: Option<String>,
) -> Result<Option<TaskRun>, IpcError> {
    let (_runtime, store) = task_runtime_for_generation(
        &state.app_state,
        &workspace_id,
        workspace_generation.as_deref(),
    )
    .await?;
    let lookup_conversation_id = conversation_id.clone();
    let run = task_runtime_io(&store, "load latest conversation TaskRun", move |store| {
        store.latest_task_ui_run_for_conversation(&lookup_conversation_id)
    })
    .await?;
    if let Some(run) = run.as_ref() {
        validate_run_workspace(run, &workspace_id)?;
        if run.conversation_id != conversation_id {
            return Err(IpcError::Internal(format!(
                "TaskRuntime conversation mismatch: requested '{conversation_id}', resolved '{}'",
                run.conversation_id
            )));
        }
    }
    Ok(run)
}

/// Finite formal-task inventory. This is a live read, not a snapshot session.
#[tauri::command]
pub async fn list_task_runs(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    workspace_generation: String,
    statuses: Option<Vec<TaskRunStatus>>,
    limit: usize,
    continuation: Option<String>,
) -> Result<TaskRunPage, IpcError> {
    let (_runtime, store) =
        task_runtime_for_generation(&state.app_state, &workspace_id, Some(&workspace_generation))
            .await?;
    task_runtime_io(&store, "list finite formal TaskRuns", move |store| {
        store.query_task_runs_page(
            &workspace_generation,
            &statuses.unwrap_or_default(),
            limit,
            continuation.as_deref(),
        )
    })
    .await
}

/// The structured plan attached to a run, or `None` if not yet generated.
#[tauri::command]
pub async fn get_task_plan(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<Option<PlanRevision>, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "load TaskRun plan", move |store| {
        store.get_plan_revision(&run_id)
    })
    .await
}

/// Todo projection for a run — what the right-rail Todo panel renders from.
#[tauri::command]
pub async fn list_task_todos(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<Vec<TodoItem>, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "list TaskRun todos", move |store| {
        store.list_todos(&run_id)
    })
    .await
}

/// One bounded journal page; an unread suffix remains explicit to the GUI.
#[tauri::command]
pub async fn list_task_events(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    since_seq: Option<String>,
    limit: Option<usize>,
    workspace_generation: Option<String>,
) -> Result<TaskEventPage, IpcError> {
    let since = since_seq
        .as_deref()
        .unwrap_or("0")
        .parse::<i64>()
        .map_err(|error| IpcError::Validation(format!("invalid event sequence: {error}")))?;
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "read finite TaskRun event page", move |store| {
        store.query_task_event_page(&run_id, since, limit.unwrap_or(256))
    })
    .await
}

/// Artifacts produced by a run (files, reports, charts, traces).
#[tauri::command]
pub async fn list_task_artifacts(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<Vec<Artifact>, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "list TaskRun artifacts", move |store| {
        store.list_artifacts(&run_id)
    })
    .await
}

/// Reviews recorded against a task within a run (scoped to run_id + task_id
/// so task-id collisions across runs don't bleed history).
#[tauri::command]
pub async fn list_task_reviews(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    task_id: String,
    workspace_generation: Option<String>,
) -> Result<Vec<ReviewResult>, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "list TaskRun reviews", move |store| {
        store.list_reviews(&run_id, &task_id)
    })
    .await
}

/// The execution summary a subagent produced for a task — used by the Summary
/// Chain (downstream subagents consume this instead of raw chat history).
#[tauri::command]
pub async fn get_task_summary(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    task_id: String,
    workspace_generation: Option<String>,
) -> Result<Option<TaskExecutionSummary>, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "load TaskRun summary", move |store| {
        store.get_summary(&run_id, &task_id)
    })
    .await
}

/// Recovery barriers created when a mutating subagent/tool was interrupted
/// between its durable start and terminal boundaries.
#[tauri::command]
pub async fn list_recovery_blockers(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<Vec<RecoveryBlocker>, IpcError> {
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    task_runtime_io(&store, "list TaskRun recovery blockers", move |store| {
        store.list_recovery_blockers(&run_id)
    })
    .await
}

/// Resolve an indeterminate side effect after the user inspected the
/// workspace. Retry must use `retry_blocked_task` so driver admission,
/// generation pinning, and blocker classification remain one transaction.
#[tauri::command]
pub async fn resolve_recovery_task(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
    task_id: String,
    decision: String,
) -> Result<(), IpcError> {
    let decision = match decision.as_str() {
        "skip" => RecoveryDecision::Skip,
        _ => {
            return Err(IpcError::Validation(
                "recovery decision must be 'skip'; use retry_blocked_task for retry".to_string(),
            ));
        }
    };
    let (_runtime, store, _run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    task_runtime_io(&store, "resolve TaskRun recovery", move |store| {
        store.resolve_recovery_task(&run_id, &task_id, decision)
    })
    .await
}

// ── Error mapping ────────────────────────────────────────────────────────

fn internal<E: std::fmt::Display>(e: E) -> IpcError {
    IpcError::Internal(e.to_string())
}

async fn settle_gui_resume_error(
    lease: echo_agent_app_core::api::foreground_turn::ForegroundTurnLease,
    error: echo_agent_app_core::api::chat_driver::ChatTurnError,
) -> Result<(), echo_agent_app_core::api::foreground_turn::ForegroundTurnError> {
    if error.is_observation() {
        // Preparation and execution waits share the original foreground owner;
        // neither an unresolved fence nor an observer result is a terminal.
        lease.retain_observation(error);
        return Ok(());
    }
    lease
        .settle_after_observers(echo_agent_app_core::api::chat_driver::TurnOutcome::Failed(
            echo_agent::error::AgentFailure::message("planned_resume", error.to_string()),
        ))
        .await
        .map(|_| ())
}

/// Resume a paused run. Transitions `Paused → Running` and re-launches the
/// executor, which re-reads the plan from the store and skips already-completed
/// tasks.
#[tauri::command]
pub async fn resume_task_run(
    state: tauri::State<'_, TauriState>,
    app: tauri::AppHandle,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
) -> Result<TaskRunResumeReceipt, IpcError> {
    let (runtime, store, _) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    let state_run_id = run_id.clone();
    let run_state = task_runtime_io(&store, "load TaskRun resume state", move |store| {
        store.get_run_state(&state_run_id)
    })
    .await?;
    if run_state.as_ref().is_some_and(|snapshot| {
        snapshot.execution_profile.is_conversation_turn()
            && snapshot
                .continuation
                .as_ref()
                .is_some_and(|continuation| continuation.enabled)
    }) {
        return resume_continuation_run(&state, app, runtime, store, run_id, run_state).await;
    }
    let conversation_id = run_state
        .as_ref()
        .map(|snapshot| snapshot.run.conversation_id.clone())
        .ok_or_else(|| IpcError::Validation("TaskRun not found".to_string()))?;
    let expected_resume =
        echo_agent_app_core::api::tasks::task_runtime::TaskRunResumeIdentity::capture(
            run_state
                .as_ref()
                .ok_or_else(|| IpcError::Validation("TaskRun not found".to_string()))?,
        );
    let turn_id = uuid::Uuid::new_v4().to_string();
    let lease = runtime
        .begin_turn(
            &state.app_state.session.foreground_turns,
            echo_agent_app_core::api::foreground_turn::ForegroundTurnSurface::Gui,
            &conversation_id,
            turn_id,
        )
        .await
        .map_err(|error| IpcError::Validation(error.to_string()))?;
    let pool_execution = match runtime.agent_for(&conversation_id).await {
        Ok(execution) => execution,
        Err(error) => {
            lease
                .settle_after_observers(echo_agent_app_core::api::chat_driver::TurnOutcome::Failed(
                    echo_agent::error::AgentFailure::message("agent_pool", error.to_string()),
                ))
                .await
                .map_err(internal)?;
            return Err(IpcError::Validation(error.to_string()));
        }
    };
    let primary_agent = pool_execution.agent();
    let cancel = lease.cancellation_token();
    let execution_projector = Arc::new(TauriExecutionProjector::new(
        app,
        state.app_state.storage.tool_executions.clone(),
        state.app_state.storage.chat_events.clone(),
        store.clone(),
    ));
    let trace_sink: echo_agent_app_core::api::tasks::task_runtime::ExecSink = Arc::new(move |ev| {
        execution_projector.emit(ev);
    });
    let launch = match echo_agent_app_core::api::tasks::task_runtime::launch_task_run_resume(
        store,
        expected_resume,
        primary_agent,
        Some(pool_execution),
        runtime.review_integration(),
        Some(trace_sink),
        cancel,
        Some(runtime.workspace_io_invocation()),
    )
    .await
    {
        Ok(launch) => launch,
        Err(error) => {
            let driver_error = echo_agent_app_core::api::chat_driver::ChatTurnError::from(error);
            let error = internal(&driver_error);
            settle_gui_resume_error(lease, driver_error)
                .await
                .map_err(internal)?;
            return Err(error);
        }
    };
    tokio::spawn(async move {
        let launched_run_id = launch.run_id.clone();
        let outcome = match launch.wait().await {
            Ok(echo_agent_app_core::api::tasks::task_runtime::RunOutcome::Completed) => {
                tracing::info!(run_id = %launched_run_id, "resumed run completed");
                echo_agent_app_core::api::chat_driver::TurnOutcome::Completed
            }
            Ok(echo_agent_app_core::api::tasks::task_runtime::RunOutcome::Cancelled) => {
                echo_agent_app_core::api::chat_driver::TurnOutcome::Cancelled
            }
            Ok(other) => {
                tracing::warn!(run_id = %launched_run_id, ?other, "resumed run ended non-completed");
                echo_agent_app_core::api::chat_driver::TurnOutcome::Failed(
                    echo_agent::error::AgentFailure::message(
                        "planned_resume",
                        format!("planned resume ended with {other:?}"),
                    ),
                )
            }
            Err(error) => {
                tracing::error!(run_id = %launched_run_id, %error, "resumed run executor error");
                if let Err(error) = settle_gui_resume_error(lease, error).await {
                    tracing::error!(run_id = %launched_run_id, %error, "resumed run foreground settlement failed");
                }
                return;
            }
        };
        if let Err(error) = lease.settle_after_observers(outcome).await {
            tracing::error!(run_id = %launched_run_id, %error, "resumed run foreground settlement failed");
        }
    });
    tracing::info!(run_id = %run_id, "task run resumed -> Running");

    Ok(TaskRunResumeReceipt {
        kind: TaskRunResumeKind::Resumed,
        run_id,
        turn_id: None,
    })
}

async fn resume_continuation_run(
    state: &tauri::State<'_, TauriState>,
    app: tauri::AppHandle,
    runtime: ScopedChatRuntime,
    store: Arc<TaskRuntimeStore>,
    run_id: String,
    run_state: Option<RunStateSnapshot>,
) -> Result<TaskRunResumeReceipt, IpcError> {
    let snapshot =
        run_state.ok_or_else(|| IpcError::Validation("TaskRun not found".to_string()))?;
    if snapshot.run.status != TaskRunStatus::Paused {
        return Err(IpcError::Validation(format!(
            "long-horizon run {run_id} is {}; resume requires paused",
            snapshot.run.status.as_str()
        )));
    }
    if let Some(continuation) = snapshot.continuation.as_ref() {
        if continuation
            .token_budget
            .is_some_and(|budget| continuation.tokens_used >= budget)
        {
            return Err(IpcError::Validation(
                "the TaskRun token budget is exhausted; increase or remove the budget before resume"
                    .to_string(),
            ));
        }
        if continuation
            .time_budget_seconds
            .is_some_and(|budget| continuation.time_used_seconds >= budget)
        {
            return Err(IpcError::Validation(
                "the TaskRun time budget is exhausted; increase or remove the budget before resume"
                    .to_string(),
            ));
        }
    }
    let blocker_run_id = run_id.clone();
    let blockers = task_runtime_io(&store, "load TaskRun resume blockers", move |store| {
        store.list_recovery_blockers(&blocker_run_id)
    })
    .await?;
    if !blockers.is_empty() {
        return Err(IpcError::Validation(format!(
            "run {run_id} has unresolved recovery blockers"
        )));
    }

    // Pause is durable before the cancelled finite turn necessarily releases
    // its exact driver. Do not mutate Paused -> Running until that old claim
    // has closed, otherwise an immediate resume can lose to its own old turn.
    store.wait_for_run_driver_idle(&run_id).await;
    let settled_run_id = run_id.clone();
    let snapshot = task_runtime_io(&store, "reload settled TaskRun resume", move |store| {
        store.get_run_state(&settled_run_id)
    })
    .await?
    .ok_or_else(|| IpcError::Validation("TaskRun not found after driver settlement".to_string()))?;
    validate_run_workspace(&snapshot.run, runtime.execution_scope().workspace_id())?;
    if snapshot.run.status != TaskRunStatus::Paused {
        return Err(IpcError::Validation(format!(
            "long-horizon run {run_id} became {}; resume requires paused",
            snapshot.run.status.as_str()
        )));
    }
    if snapshot
        .continuation
        .as_ref()
        .is_some_and(|continuation| continuation.active_turn.is_some())
    {
        return Err(IpcError::Validation(format!(
            "long-horizon run {run_id} still has an active RunTurn after driver settlement"
        )));
    }

    let turn_id = uuid::Uuid::new_v4().to_string();
    let conversation_id = snapshot.run.conversation_id.clone();
    let expected_resume =
        echo_agent_app_core::api::tasks::task_runtime::TaskRunResumeIdentity::capture(&snapshot);
    let lease = runtime
        .begin_turn(
            &state.app_state.session.foreground_turns,
            echo_agent_app_core::api::foreground_turn::ForegroundTurnSurface::Gui,
            &conversation_id,
            turn_id.clone(),
        )
        .await
        .map_err(|error| IpcError::Validation(error.to_string()))?;
    let pool_execution = match runtime.agent_for(&conversation_id).await {
        Ok(execution) => execution,
        Err(error) => {
            lease
                .settle_after_observers(echo_agent_app_core::api::chat_driver::TurnOutcome::Failed(
                    echo_agent::error::AgentFailure::message("agent_pool", error.to_string()),
                ))
                .await
                .map_err(internal)?;
            return Err(IpcError::Validation(error.to_string()));
        }
    };
    let sink = crate::tauri::commands::chat::tauri_chat_sink(
        app.clone(),
        runtime.execution_scope().workspace_id().to_string(),
        turn_id.clone(),
        Some(conversation_id.clone()),
        state.app_state.storage.tool_executions.clone(),
        state.app_state.storage.chat_events.clone(),
    );
    let _ = sink.on_event(
        echo_agent_app_core::api::chat_driver::ChatDriverEvent::TurnStatus {
            status: "running".to_string(),
        },
    );
    let turn = echo_agent_app_core::api::prepared_turn::PreparedUserTurn::runtime_instruction(
        format!(
            "Resume the existing TaskRun {run_id} toward its unchanged Goal. Reload the authoritative runtime projection and continue the next useful work."
        ),
    );
    let hitl_scope = echo_agent_app_core::api::hitl::HitlRequestScope {
        workspace_id: Some(runtime.execution_scope().workspace_id().to_string()),
        host_generation: Some(runtime.workspace_io_receipt().host_generation().to_string()),
        conversation_id: Some(conversation_id.clone()),
        root_turn_id: Some(turn_id.clone()),
        turn_id: Some(turn_id.clone()),
        run_id: Some(run_id.clone()),
        ..Default::default()
    };
    let hitl_provider: Arc<dyn echo_agent::human_loop::HumanLoopProvider> = Arc::new(
        crate::tauri::commands::chat::TauriHumanLoopHandler::new(
            sink.clone(),
            turn_id.clone(),
            hitl_scope.clone(),
        )
        .with_scope_resolver(crate::tauri::commands::chat::gui_hitl_scope_resolver(
            &state.app_state,
            hitl_scope,
        )),
    );
    let resources = Arc::new(echo_agent_app_core::api::chat_resources::ChatResources {
        execution_scope: runtime.execution_scope().clone(),
        workspace_io_receipt: Some(runtime.workspace_io_receipt()),
        pool: runtime.pool(),
        store: Some(store.clone()),
        sink: sink.clone(),
        webhook_emitter: Some(state.app_state.webhook.emitter.clone()),
        conv_id: Some(conversation_id.clone()),
        root_message_id: turn_id.clone(),
        attachments: snapshot.run.attachments,
        cancel: lease.cancellation_token(),
        review_integration: runtime.review_integration(),
        memory_generation: None,
        human_loop_provider: Some(hitl_provider),
    });
    let binding = RunTurnBinding::resume_expected_with_visibility(
        expected_resume,
        turn_id.clone(),
        TurnVisibility::Internal,
    );
    let agent = pool_execution.agent();
    let spawned_run_id = run_id.clone();
    let status_store = store;
    tokio::spawn(async move {
        lease.retain_execution(pool_execution);
        let outcome = echo_agent_app_core::api::foreground_turn::drive_foreground_chat_turn(
            lease, &agent, &turn, resources, binding,
        )
        .await;
        if let Err(error) = outcome.as_ref() {
            tracing::warn!(%error, run_id = %spawned_run_id, "long-horizon GUI resume failed");
        }
        if outcome
            .as_ref()
            .err()
            .is_some_and(|error| error.is_observation())
        {
            return;
        }
        let terminal_run_id = spawned_run_id.clone();
        let terminal_status = TaskRuntimeOperation::new(status_store)
            .run_store("load resumed TaskRun terminal", move |store| {
                store.get_run(&terminal_run_id)
            })
            .await
            .ok()
            .flatten()
            .map(|run| run.status.as_str().to_string())
            .unwrap_or_else(|| {
                outcome
                    .as_ref()
                    .map(|terminal| terminal.status().to_string())
                    .unwrap_or_else(|_| "failed".to_string())
            });
        let _ = sink.on_event(
            echo_agent_app_core::api::chat_driver::ChatDriverEvent::TurnStatus {
                status: terminal_status,
            },
        );
    });

    Ok(TaskRunResumeReceipt {
        kind: TaskRunResumeKind::ContinuationResumed,
        run_id,
        turn_id: Some(turn_id),
    })
}

/// Explicitly retry a Blocked (or Failed) task in a Paused (or Failed) run.
///
/// This is the only sanctioned way to re-run a task whose previous attempt
/// completed but failed acceptance/review: the executor no longer
/// auto-redispatches on acceptance failure (M7). Bumps `retry_count`,
/// resets the task to Pending, transitions the run to Running, and spawns
/// the executor. Title and description are preserved; the next attempt
/// gets a fresh `execution_id = "{run_id}:{task_id}:{plan_revision}:{attempt}"`.
///
/// Honors the `max_retries` budget: returns a validation error when
/// `retry_count >= max_retries`.
#[tauri::command]
pub async fn retry_blocked_task(
    state: tauri::State<'_, TauriState>,
    app: tauri::AppHandle,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
    task_id: String,
) -> Result<TaskRetryReceipt, IpcError> {
    let (runtime, store, run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    let pool_execution = runtime
        .agent_for(&run.conversation_id)
        .await
        .map_err(|error| IpcError::Validation(error.to_string()))?;
    let primary_agent = pool_execution.agent();
    let review_integration = runtime.review_integration();
    let cancel = echo_agent::agent::CancellationToken::new();
    // The pinned retry facade selects recovery or acceptance and mutates the
    // run only after exact driver registration has completed.
    let execution_projector = Arc::new(TauriExecutionProjector::new(
        app,
        state.app_state.storage.tool_executions.clone(),
        state.app_state.storage.chat_events.clone(),
        store.clone(),
    ));
    let trace_sink: echo_agent_app_core::api::tasks::task_runtime::ExecSink = Arc::new(move |ev| {
        execution_projector.emit(ev);
    });
    let preparation = spawn_tauri_task_retry(
        store,
        primary_agent,
        Some(pool_execution),
        review_integration,
        trace_sink,
        cancel,
        run_id.clone(),
        task_id.clone(),
        Some(runtime.workspace_io_invocation()),
    )
    .await
    .map_err(|error| match error {
        echo_agent_app_core::api::tasks::task_runtime::StoreError::InvalidPlan(message) => {
            IpcError::Validation(message)
        }
        other => internal(other),
    })?;
    let (kind, next_attempt) = match preparation {
        echo_agent_app_core::api::tasks::task_runtime::TaskRetryPreparation::Acceptance {
            next_attempt,
        } => (TaskRetryKind::RetryScheduled, Some(next_attempt)),
        echo_agent_app_core::api::tasks::task_runtime::TaskRetryPreparation::Recovery => {
            (TaskRetryKind::RecoveryRetryRecorded, None)
        }
    };
    tracing::info!(run_id = %run_id, task_id = %task_id, ?preparation, "task retry prepared atomically");
    Ok(TaskRetryReceipt {
        kind,
        run_id,
        task_id,
        next_attempt,
    })
}

#[allow(clippy::too_many_arguments)]
async fn spawn_tauri_task_retry(
    store: Arc<TaskRuntimeStore>,
    primary_agent: echo_agent_app_core::api::agent_handle::AgentHandle,
    pool_execution: Option<echo_agent_app_core::api::agent_pool::AgentPoolExecutionLease>,
    review_integration: Option<Arc<echo_agent_app_core::api::evolution::ReviewIntegration>>,
    trace_sink: echo_agent_app_core::api::tasks::task_runtime::ExecSink,
    cancel: echo_agent::agent::CancellationToken,
    run_id: String,
    task_id: String,
    workspace_io: Option<echo_agent_app_core::api::state::WorkspaceIoInvocation>,
) -> Result<
    echo_agent_app_core::api::tasks::task_runtime::TaskRetryPreparation,
    echo_agent_app_core::api::tasks::task_runtime::StoreError,
> {
    let driver_store = store.clone();
    let driver_run_id = run_id.clone();
    let supervisor_cancel = cancel.clone();
    let (preparation, result_waiter) = store
        .spawn_supervised_task_retry_async(
        run_id,
        task_id,
        supervisor_cancel,
        move || {
            let memory_generation = review_integration
                .as_ref()
                .map(|integration| integration.lease_generation())
                .transpose()
                .map_err(|error| {
                    echo_agent_app_core::api::tasks::task_runtime::StoreError::InvalidPlan(format!(
                        "memory generation unavailable: {error}"
                    ))
                })?;
            Ok(memory_generation)
        },
        move |memory_generation, mut receipt_owner| async move {
            if let Some(generation) = memory_generation.as_ref() {
                receipt_owner.retain(generation.clone())?;
            }
            if let Some(execution) = pool_execution {
                receipt_owner.retain(execution)?;
            }
            let run_store = primary_agent.read(|agent| agent.run_store().cloned()).await;
            let reviewer_llm = primary_agent
                .read(|agent| agent.llm_client().cloned())
                .await;
            let outcome = echo_agent_app_core::api::tasks::task_runtime::execute_run(
                driver_store.clone(),
                Some(primary_agent),
                reviewer_llm,
                memory_generation,
                run_store,
                Some(trace_sink),
                &driver_run_id,
                cancel,
                echo_agent_app_core::api::tasks::task_runtime::MemoryPolicy::BestEffortSettled,
                workspace_io,
            )
            .await;
            match outcome {
                Ok(echo_agent_app_core::api::tasks::task_runtime::RunOutcome::Completed) => {
                    tracing::info!(run_id = %driver_run_id, "retried run completed");
                }
                Ok(other) => {
                    tracing::warn!(run_id = %driver_run_id, ?other, "retried run ended non-completed");
                }
                Err(error) => {
                    tracing::error!(run_id = %driver_run_id, %error, "retried run executor error");
                    return Err(echo_agent_app_core::api::chat_driver::ChatTurnError::from(error));
                }
            }
            Ok(())
        },
        )
        .await?;
    drop(result_waiter);
    Ok(preparation)
}

/// Atomically update tasks and their relations against an expected revision.
#[tauri::command]
pub async fn update_tasks(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
    request: TaskUpdateRequest,
) -> Result<PlanRevision, IpcError> {
    let (runtime, store, run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    let execution = runtime
        .agent_for(&run.conversation_id)
        .await
        .map_err(|error| IpcError::Validation(error.to_string()))?;
    let agent = execution.agent();
    let service = echo_agent_app_core::api::tasks::task_runtime::task_revision_service_for_agent(
        &agent,
        store.clone(),
        echo_agent_app_core::api::tasks::task_runtime::default_subagent_catalog(),
    )
    .await;
    echo_agent_app_core::api::tasks::task_runtime::apply_task_update(
        &service, store, &run_id, request,
    )
    .await
    .map_err(|error| match error {
        echo_agent::tasks::TaskRevisionError::RevisionConflict { .. }
        | echo_agent::tasks::TaskRevisionError::InvalidInput { .. }
        | echo_agent::tasks::TaskRevisionError::TaskNotFound { .. }
        | echo_agent::tasks::TaskRevisionError::InvalidPatch { .. }
        | echo_agent::tasks::TaskRevisionError::PolicyRejected { .. }
        | echo_agent::tasks::TaskRevisionError::StoreRejected { .. } => {
            IpcError::Validation(error.to_string())
        }
        echo_agent::tasks::TaskRevisionError::GraphNotFound { .. }
        | echo_agent::tasks::TaskRevisionError::StoreUnsupported { .. }
        | echo_agent::tasks::TaskRevisionError::Backend { .. } => internal(error),
    })
}

/// Cancel an executing run. Cancels every in-flight subagent via the run's
/// CancellationToken and lets the executor wind down (the run ends Cancelled).
#[tauri::command]
pub async fn cancel_task_run(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
) -> Result<TaskRunControlReceipt, IpcError> {
    let (_runtime, store, run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    let message_key = Some(run.root_message_id);
    let cancel_run_id = run_id.clone();
    let cancelled = task_runtime_io(&store, "cancel TaskRun", move |store| {
        store.request_cancel(&cancel_run_id)
    })
    .await?;
    if cancelled {
        super::chat::cancel_pending_hitl(
            &workspace_id,
            &run.conversation_id,
            message_key.as_deref(),
            "task run cancelled",
        )
        .await;
        store.wait_for_run_driver_idle(&run_id).await;
    }
    Ok(TaskRunControlReceipt {
        success: cancelled,
        run_id,
    })
}

/// Pause a running TaskRun through the same cancellation token that owns its
/// executor. Unlike cancellation, completed work remains resumable.
#[tauri::command]
pub async fn pause_task_run(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    workspace_generation: String,
    run_id: String,
) -> Result<TaskRunControlReceipt, IpcError> {
    let (_runtime, store, run) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        Some(&workspace_generation),
    )
    .await?;
    let message_key = Some(run.root_message_id);
    let pause_run_id = run_id.clone();
    let paused = task_runtime_io(&store, "pause TaskRun", move |store| {
        store.request_pause(&pause_run_id)
    })
    .await?;
    if paused {
        super::chat::cancel_pending_hitl(
            &workspace_id,
            &run.conversation_id,
            message_key.as_deref(),
            "task run paused",
        )
        .await;
    }
    Ok(TaskRunControlReceipt {
        success: paused,
        run_id,
    })
}

/// Render the human-readable progress ledger derived from canonical run files.
/// It is also written to `.eko/runtime/{run_id}/progress.md` for compact agent
/// recovery context.
#[tauri::command]
pub async fn get_progress_ledger(
    state: tauri::State<'_, TauriState>,
    workspace_id: String,
    run_id: String,
    workspace_generation: Option<String>,
) -> Result<String, IpcError> {
    let (runtime, store, _) = task_runtime_for_generation_run(
        &state.app_state,
        &workspace_id,
        &run_id,
        workspace_generation.as_deref(),
    )
    .await?;
    let workspace_root = runtime.execution_scope().root().to_path_buf();
    task_runtime_io(&store, "write TaskRun progress ledger", move |store| {
        echo_agent_app_core::api::tasks::task_runtime::write_progress(
            &store,
            &run_id,
            Some(&workspace_root),
        )
    })
    .await
}

#[cfg(test)]
mod tests {
    use super::*;
    use echo_agent::error::Result as ReactResult;
    use echo_agent::llm::types::{ChatCompletionResponse, DeltaMessage, Message};
    use echo_agent::llm::{ChatChunk, ChatRequest, ChatResponse, LlmClient};
    use futures::future::BoxFuture;
    use futures::stream::{self, BoxStream};

    #[tokio::test]
    async fn gui_resume_pending_owner_rejection_keeps_foreground_nonterminal() -> anyhow::Result<()>
    {
        use echo_agent::state::journal::{EventJournal, FileEventJournal};
        use echo_agent::utils::fs::FileDurability;
        use echo_agent_app_core::api::chat_driver::ChatTurnError;
        use echo_agent_app_core::api::foreground_turn::{
            ForegroundTurnControl, ForegroundTurnSurface,
        };
        use echo_agent_app_core::api::tasks::task_runtime::{
            TaskRunResumeIdentity, launch_task_run_resume,
        };

        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        store.create_run(
            "gui-owner",
            "test",
            "gui-conversation",
            "message",
            DomainProfile::General,
            "preserve original owner",
            "agent_task_plan",
            AttendedMode::Attended,
        )?;
        store.transition_run("gui-owner", TaskRunStatus::Running)?;
        store.transition_run("gui-owner", TaskRunStatus::Paused)?;
        drop(store);
        // Persist an unresolved original-owner fact with the official journal
        // before reopening; this is a restart fixture, not completion evidence.
        let journal_path = directory.path().join("gui-owner/events.jsonl");
        let journal =
            FileEventJournal::<serde_json::Value>::open(&journal_path, FileDurability::SyncData)?;
        journal
            .append(serde_json::json!({
                "run_id":"gui-owner", "task_id":null, "step_id":"original-execution",
                "event_type":"recovery_blocked", "timestamp":chrono::Utc::now(),
                "payload":{"physical_owner_intent":{
                    "run_id":"gui-owner", "owner_id":"original-owner",
                    "execution_id":"original-execution", "workspace_id":"test",
                    "physical_terminal_observed":false
                }}
            }))
            .map_err(|error| anyhow::anyhow!("persist original owner: {error:?}"))?;
        drop(journal);
        let store = Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(
            directory.path(),
        )?);
        let snapshot = store
            .get_run_state("gui-owner")?
            .ok_or_else(|| anyhow::anyhow!("original run absent"))?;
        let expected = TaskRunResumeIdentity::capture(&snapshot);
        let before = std::fs::read(&journal_path)?;
        let control = ForegroundTurnControl::default();
        let lease = control.begin_scoped(
            "test",
            ForegroundTurnSurface::Gui,
            "gui-conversation",
            "resume-turn",
        )?;
        let error = launch_task_run_resume(
            store.clone(),
            expected,
            test_agent().map_err(anyhow::Error::msg)?,
            None,
            None,
            None,
            lease.cancellation_token(),
            None,
        )
        .await
        .err()
        .ok_or_else(|| anyhow::anyhow!("unresolved owner unexpectedly admitted"))?;
        assert!(
            matches!(&error, echo_agent_app_core::api::tasks::task_runtime::StoreError::RecoveryBlocked { run_id, .. } if run_id == "gui-owner")
        );
        let error = ChatTurnError::from(error);
        assert!(
            matches!(&error, ChatTurnError::Observation {run_id, execution_id:None} if run_id == "gui-owner")
        );
        settle_gui_resume_error(lease, error).await?;
        assert_eq!(std::fs::read(&journal_path)?, before);
        assert!(!store.is_run_active("gui-owner"));
        assert!(
            control
                .snapshot_scoped("test", ForegroundTurnSurface::Gui, "gui-conversation")
                .is_some(),
            "GUI launch rejection projected original pending ownership as a Failed terminal"
        );
        assert_eq!(
            store
                .get_run("gui-owner")?
                .ok_or_else(|| anyhow::anyhow!("original run disappeared"))?
                .status,
            TaskRunStatus::Paused
        );
        Ok(())
    }

    #[tokio::test]
    async fn gui_resume_ordinary_error_keeps_failed_settlement() -> anyhow::Result<()> {
        use echo_agent_app_core::api::chat_driver::{ChatTurnError, TurnOutcome};
        use echo_agent_app_core::api::foreground_turn::{
            ForegroundTurnControl, ForegroundTurnSurface,
        };
        let control = ForegroundTurnControl::default();
        let lease = control.begin_scoped(
            "test",
            ForegroundTurnSurface::Gui,
            "ordinary",
            "ordinary-resume",
        )?;
        let waiter = control.settlement_waiter_scoped(
            "test",
            ForegroundTurnSurface::Gui,
            "ordinary",
            "ordinary-resume",
        )?;
        settle_gui_resume_error(
            lease,
            ChatTurnError::Error("ordinary preparation failure".into()),
        )
        .await?;
        let result = waiter.wait().await?;
        assert!(
            matches!(result.outcome, TurnOutcome::Failed(failure) if failure.message == "ordinary preparation failure")
        );
        assert!(
            control
                .snapshot_scoped("test", ForegroundTurnSurface::Gui, "ordinary")
                .is_none()
        );
        Ok(())
    }

    #[tokio::test]
    async fn task_runtime_scope_validation_fails_closed() -> Result<(), String> {
        let store = Arc::new(TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?);
        validate_store_workspace(&store, "test").map_err(|error| error.to_string())?;

        let store_error = validate_store_workspace(&store, "workspace-b")
            .err()
            .ok_or_else(|| "cross-workspace store validation unexpectedly succeeded".to_string())?;
        if !matches!(store_error, IpcError::Internal(_)) {
            return Err(format!(
                "cross-workspace store validation returned the wrong error: {store_error}"
            ));
        }

        store
            .create_run(
                "scope-run",
                "workspace-a",
                "scope-conversation",
                "scope-root",
                DomainProfile::General,
                "scope validation",
                "agent_task_plan",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        let run = get_scoped_run(&store, "workspace-a", "scope-run")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "workspace A run is missing".to_string())?;
        assert_eq!(run.workspace_id, "workspace-a");

        let run_error = get_scoped_run(&store, "workspace-b", "scope-run")
            .await
            .err()
            .ok_or_else(|| "cross-workspace run validation unexpectedly succeeded".to_string())?;
        if !matches!(run_error, IpcError::Validation(_)) {
            return Err(format!(
                "cross-workspace run validation returned the wrong error: {run_error}"
            ));
        }
        Ok(())
    }

    struct TestLlmClient;

    impl LlmClient for TestLlmClient {
        fn chat(&self, _request: ChatRequest) -> BoxFuture<'_, ReactResult<ChatResponse>> {
            Box::pin(async {
                Ok(ChatResponse {
                    message: Message::assistant("done".to_string()),
                    finish_reason: Some("stop".to_string()),
                    usage: None,
                    raw: ChatCompletionResponse::default(),
                })
            })
        }

        fn chat_stream(
            &self,
            _request: ChatRequest,
        ) -> BoxFuture<'_, ReactResult<BoxStream<'static, ReactResult<ChatChunk>>>> {
            Box::pin(async {
                let chunks = vec![
                    Ok(ChatChunk {
                        delta: DeltaMessage {
                            content: Some("done".to_string()),
                            ..DeltaMessage::default()
                        },
                        finish_reason: None,
                        usage: None,
                    }),
                    Ok(ChatChunk {
                        delta: DeltaMessage::default(),
                        finish_reason: Some("stop".to_string()),
                        usage: None,
                    }),
                ];
                Ok(Box::pin(stream::iter(chunks)) as BoxStream<'static, ReactResult<ChatChunk>>)
            })
        }

        fn model_name(&self) -> &str {
            "test"
        }
    }

    fn test_agent() -> Result<echo_agent_app_core::api::agent_handle::AgentHandle, String> {
        echo_agent::agent::ReactAgentBuilder::new()
            .model("test")
            .llm_client(Arc::new(TestLlmClient))
            .build()
            .map(echo_agent_app_core::api::agent_handle::AgentHandle::new)
            .map_err(|error| error.to_string())
    }

    async fn prepare_retry_run(
        store: Arc<echo_agent_app_core::api::tasks::task_runtime::TaskRuntimeStore>,
        run_id: &str,
        task_id: &str,
        recovery: bool,
    ) -> Result<(), String> {
        store
            .create_run(
                run_id,
                "default",
                "tauri:test",
                "",
                DomainProfile::General,
                "retry from GUI",
                "agent_task_plan",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        echo_agent_app_core::api::tasks::task_runtime::commit_task_plan(
            store.clone(),
            TaskPlan {
                domain_binding: None,
                plan_id: format!("{run_id}-plan"),
                run_id: run_id.to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: echo_agent_app_core::api::tasks::task_runtime::task_goal_sha256(
                    "retry from GUI",
                ),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: task_id.to_string(),
                    title: "Retry task".to_string(),
                    max_retries: 2,
                    ..PlanTask::default()
                }],
            },
        )
        .await
        .map_err(|error| error.to_string())?;
        store
            .transition_run(run_id, TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        let (task_status, summary, run_status) = if recovery {
            (
                echo_agent::tasks::TaskStatus::Blocked(
                    "mutating side effect is indeterminate after restart".to_string(),
                ),
                "mutating side effect is indeterminate after restart",
                TaskRunStatus::Paused,
            )
        } else {
            (
                echo_agent::tasks::TaskStatus::Failed("acceptance failed".to_string()),
                "acceptance failed",
                TaskRunStatus::Failed,
            )
        };
        store
            .set_task_status(run_id, task_id, task_status, None, Some(summary))
            .map_err(|error| error.to_string())?;
        store
            .transition_run(run_id, run_status)
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    type RetryRuntimeSnapshot = (TaskRunStatus, Option<(TodoStatus, u32)>, usize);

    fn snapshot(
        store: &echo_agent_app_core::api::tasks::task_runtime::TaskRuntimeStore,
        run_id: &str,
    ) -> Result<RetryRuntimeSnapshot, String> {
        let run = store
            .get_run(run_id)
            .map_err(|error| error.to_string())?
            .ok_or_else(|| format!("run missing: {run_id}"))?;
        let task = store
            .list_todos(run_id)
            .map_err(|error| error.to_string())?
            .first()
            .map(|task| (task.status, task.retry_count));
        let event_count = store
            .list_events(run_id, 0)
            .map_err(|error| error.to_string())?
            .len();
        Ok((run.status, task, event_count))
    }

    fn trace_sink() -> echo_agent_app_core::api::tasks::task_runtime::ExecSink {
        Arc::new(|_| {})
    }

    #[tokio::test]
    async fn gui_retry_selects_acceptance_and_recovery_with_one_pinned_facade() -> Result<(), String>
    {
        for (run_id, recovery, expected) in [
            (
                "gui-acceptance",
                false,
                echo_agent_app_core::api::tasks::task_runtime::TaskRetryPreparation::Acceptance {
                    next_attempt: 1,
                },
            ),
            (
                "gui-recovery",
                true,
                echo_agent_app_core::api::tasks::task_runtime::TaskRetryPreparation::Recovery,
            ),
        ] {
            let store = Arc::new(
                echo_agent_app_core::api::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                    .map_err(|error| error.to_string())?,
            );
            // Keep the original application owner alive through driver settlement.
            let mut lifecycle = echo_agent_app_core::api::runtime::ApplicationLifecycleOwner::new(
                echo_agent::agent::CancellationToken::new(),
            );
            lifecycle.bind_task_runtime(store.clone());
            prepare_retry_run(store.clone(), run_id, "retry-task", recovery).await?;
            let preparation = spawn_tauri_task_retry(
                store.clone(),
                test_agent()?,
                None,
                None,
                trace_sink(),
                echo_agent::agent::CancellationToken::new(),
                run_id.to_string(),
                "retry-task".to_string(),
                None,
            )
            .await
            .map_err(|error| error.to_string())?;
            assert_eq!(preparation, expected);
            store
                .shutdown_run_drivers()
                .await
                .map_err(|error| error.to_string())?;
            lifecycle
                .settle(
                    echo_agent_app_core::api::runtime::ApplicationLifecycleReason::Shutdown,
                    None,
                )
                .await
                .into_result()
                .map_err(|error| error.to_string())?;
        }
        Ok(())
    }

    #[tokio::test]
    async fn gui_recovery_retry_closed_admission_does_not_mutate_runtime() -> Result<(), String> {
        let store = Arc::new(
            echo_agent_app_core::api::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                .map_err(|error| error.to_string())?,
        );
        prepare_retry_run(store.clone(), "gui-closed", "retry-task", true).await?;
        let before = snapshot(&store, "gui-closed")?;
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        let result = spawn_tauri_task_retry(
            store.clone(),
            test_agent()?,
            None,
            None,
            trace_sink(),
            echo_agent::agent::CancellationToken::new(),
            "gui-closed".to_string(),
            "retry-task".to_string(),
            None,
        )
        .await;
        assert!(result.is_err());
        assert_eq!(before, snapshot(&store, "gui-closed")?);
        Ok(())
    }

    #[tokio::test]
    async fn gui_retry_registration_infrastructure_failure_does_not_mutate_runtime()
    -> Result<(), String> {
        let store = Arc::new(
            echo_agent_app_core::api::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                .map_err(|error| error.to_string())?,
        );
        prepare_retry_run(store.clone(), "gui-registration", "retry-task", false).await?;
        let before = snapshot(&store, "gui-registration")?;
        store.fail_next_run_driver_registration_for_test();
        let error = spawn_tauri_task_retry(
            store.clone(),
            test_agent()?,
            None,
            None,
            trace_sink(),
            echo_agent::agent::CancellationToken::new(),
            "gui-registration".to_string(),
            "retry-task".to_string(),
            None,
        )
        .await
        .err()
        .ok_or_else(|| "GUI retry registration unexpectedly succeeded".to_string())?;
        assert!(
            error
                .to_string()
                .contains("injected TaskRun driver registration failure")
        );
        assert_eq!(before, snapshot(&store, "gui-registration")?);
        Ok(())
    }
}
