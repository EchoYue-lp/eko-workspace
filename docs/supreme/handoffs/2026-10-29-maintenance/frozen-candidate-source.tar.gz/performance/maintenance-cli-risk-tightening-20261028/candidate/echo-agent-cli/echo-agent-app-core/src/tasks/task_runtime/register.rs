//! Register the full task-management tool suite on an existing agent.
//!
//! Shared post-bootstrap composition for retained GUI/IM/cron capabilities.
//! The primary agent is built before AppState exposes its TaskRuntimeStore;
//! ApplicationServices then installs these tools with the canonical store.
//! Pool initialization passes that same store through SharedResources.
//! Legacy entrypoints still call this existing hook during console retirement;
//! those current callers do not establish a permanent surface-parity contract.
//!
//! Registers the revisioned TaskCreate/TaskUpdate/TaskList contract plus
//! CreateComplexTask / CheckRunStatus / CancelRun and `task_execute`.

use std::sync::Arc;

use crate::agent_handle::AgentHandle;
use crate::subagent_loader::SubagentCatalogSnapshot;
use crate::tasks::task_runtime::store::TaskRuntimeStore;
use crate::tasks::task_runtime::task_execute_tool::ExecuteTaskTool;
use crate::tasks::task_runtime::task_tools::{
    CancelRunTool, CheckRunStatusTool, CreateComplexTaskTool, TaskCapabilityCatalog,
};

/// Build EKO's revision service from the live Agent capability catalog.
pub async fn task_revision_service_for_agent(
    agent_handle: &AgentHandle,
    store: Arc<TaskRuntimeStore>,
    subagent_catalog: Arc<SubagentCatalogSnapshot>,
) -> Arc<echo_agent::tasks::TaskRevisionService> {
    let tool_names = agent_handle.read(|agent| agent.tool_names()).await;
    let registry = agent_handle
        .read(|agent| agent.subagent_registry().clone())
        .await;
    let capabilities =
        Arc::new(TaskCapabilityCatalog::new(subagent_catalog, tool_names).with_registry(registry));
    super::revisioned_runtime::build_task_revision_service(store, capabilities)
}

/// Register the task-management tools + `task_execute` (with store) on
/// `agent_handle`. See module docs for why this is post-hoc.
pub async fn register_task_tools_on_agent(
    agent_handle: &AgentHandle,
    store: Arc<TaskRuntimeStore>,
    subagent_catalog: Arc<SubagentCatalogSnapshot>,
) {
    let admission = super::executor::process_subagent_admission();
    agent_handle
        .write_async(|agent| {
            Box::pin(async move {
                agent.set_subagent_admission(admission).await;
            })
        })
        .await;
    let tool_names = agent_handle.read(|agent| agent.tool_names()).await;
    let registry = agent_handle
        .read(|agent| agent.subagent_registry().clone())
        .await;
    let capabilities = Arc::new(
        TaskCapabilityCatalog::new(subagent_catalog.clone(), tool_names).with_registry(registry),
    );
    let revision_service =
        super::revisioned_runtime::build_task_revision_service(store.clone(), capabilities);
    let added = agent_handle
        .write(|agent| {
            echo_agent::tasks::register_task_tools(agent, revision_service);
            // Phase B3: agent-autonomous complex-task tools. These read
            // pool/store/sink from the chat turn's task_local
            // (current_chat_resources), so no store injection is needed.
            agent.add_tool(Box::new(CreateComplexTaskTool {
                subagent_catalog: subagent_catalog.clone(),
            }));
            agent.add_tool(Box::new(CheckRunStatusTool));
            agent.add_tool(Box::new(CancelRunTool));
            true
        })
        .await;
    if added {
        tracing::info!("Registered revisioned task-management tools on primary agent");
    } else {
        tracing::warn!(
            "Failed to register task-management tools on primary agent (write lock poisoned)"
        );
    }

    // Also register task_execute tool (only on main agent per §10.2).
    // The existing router resolves each run's route; constructing this tool
    // does not select a fixed delegation policy.
    let tool = ExecuteTaskTool::new(store.clone(), agent_handle.clone());
    let ep_added = agent_handle
        .write(|agent| {
            agent.add_tool(Box::new(tool));
            true
        })
        .await;
    if ep_added {
        tracing::info!("Registered task_execute tool on primary agent");
    } else {
        tracing::warn!(
            "Failed to register task_execute tool on primary agent (write lock poisoned)"
        );
    }

    agent_handle
        .write(|agent| {
            crate::subagent_prompt::refresh_primary_system_prompt(
                agent,
                &crate::tool_exposure::disabled_tools(),
            );
        })
        .await;

    // A one-node task graph and a dependency DAG share this execution path.
    // `agent_tool` remains only for ephemeral side work with no TaskRun.

    // Attach the HookEventDispatcher so every task/subagent event written by
    // the store is translated into framework HookEvents (P: Task/Subagent
    // event integration). Built from this agent's own hook registry so events
    // fire into the same registry its hooks see. Idempotent (first call wins),
    // so the pooled/cron paths calling this again on the same store are safe.
    let task_bridge = agent_handle
        .read(|agent| std::sync::Arc::new(agent.create_task_hook_bridge()))
        .await;
    let subagent_bridge = agent_handle
        .read(|agent| std::sync::Arc::new(agent.create_subagent_hook_bridge()))
        .await;
    let dispatcher = match super::hook_event_dispatcher::HookEventDispatcher::new(
        Some(task_bridge),
        Some(subagent_bridge),
    ) {
        Ok(dispatcher) => dispatcher,
        Err(error) => {
            tracing::warn!(%error, "HookEventDispatcher was not attached");
            return;
        }
    };
    match store.attach_hook_event_dispatcher(dispatcher) {
        Ok(true) => tracing::info!("HookEventDispatcher attached to TaskRuntimeStore"),
        Ok(false) => {}
        Err(error) => tracing::warn!(%error, "HookEventDispatcher was not attached"),
    }
}

pub fn default_subagent_catalog() -> Arc<SubagentCatalogSnapshot> {
    let definitions = crate::subagent_loader::discover_subagents(None, None);
    Arc::new(SubagentCatalogSnapshot::from_definitions(&definitions))
}

/// Rebind the shared `task_execute` entry after the AgentPool is wrapped in an
/// Arc. The tool resolves the current conversation's existing pooled agent at
/// invocation time, so one shared ToolManager never captures a cron or another
/// conversation's AgentHandle.
pub async fn bind_task_execute_to_pool(
    agent_handle: &AgentHandle,
    store: Arc<TaskRuntimeStore>,
    pool: &Arc<crate::agent_pool::AgentPool>,
) {
    let tool =
        ExecuteTaskTool::new(store, agent_handle.clone()).with_agent_pool(Arc::downgrade(pool));
    let added = agent_handle
        .write(|agent| {
            agent.replace_tool(Box::new(tool));
            true
        })
        .await;
    if added {
        tracing::info!("Bound shared task_execute tool to AgentPool conversation resolution");
    } else {
        tracing::warn!("Failed to bind task_execute tool to AgentPool");
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn registration_replaces_default_task_store_with_eko_task_store()
    -> std::result::Result<(), String> {
        let agent = echo_agent::agent::ReactAgentBuilder::new()
            .llm_client(Arc::new(echo_agent::testing::MockLlmClient::new()))
            .system_prompt("unified task api test")
            .build()
            .map_err(|error| error.to_string())?;
        let handle = AgentHandle::new(agent);
        let before = handle.read(|agent| agent.tool_names()).await;
        for expected in ["task_create", "task_update", "task_list"] {
            assert!(before.iter().any(|name| name == expected));
        }

        let store = Arc::new(TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?);
        register_task_tools_on_agent(&handle, store, default_subagent_catalog()).await;

        let after = handle.read(|agent| agent.tool_names()).await;
        for expected in ["task_create", "task_update", "task_list", "task_execute"] {
            assert!(after.iter().any(|name| name == expected));
        }
        let weak_agent = Arc::downgrade(handle.inner());
        drop(handle);
        assert!(
            weak_agent.upgrade().is_none(),
            "task tools retained their owning Agent"
        );
        Ok(())
    }
}
