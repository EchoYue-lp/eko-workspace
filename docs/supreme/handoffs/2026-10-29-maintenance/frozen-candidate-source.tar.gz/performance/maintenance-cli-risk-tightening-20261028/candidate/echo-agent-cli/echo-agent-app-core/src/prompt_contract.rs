//! Static prompt contract auditing for EKO-owned prompt surfaces.

use echo_agent::tokenizer::{HeuristicTokenizer, Tokenizer};

pub const DEMO_PHRASES: &[&str] = &[
    "you are a helpful assistant",
    "do your best",
    "just answer",
    "demo only",
    "for demonstration",
    "lorem ipsum",
    "pretend you",
];

#[derive(Debug, Clone)]
pub struct PromptContractSpec<'a> {
    pub name: &'a str,
    pub max_tokens: usize,
    pub required_phrases: &'a [&'a str],
    pub forbidden_phrases: &'a [&'a str],
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PromptAuditReport {
    pub name: String,
    pub estimated_tokens: usize,
    pub missing_phrases: Vec<String>,
    pub forbidden_phrases: Vec<String>,
    pub over_budget: bool,
}

impl PromptAuditReport {
    pub fn is_compliant(&self) -> bool {
        !self.over_budget && self.missing_phrases.is_empty() && self.forbidden_phrases.is_empty()
    }

    pub fn summary(&self) -> String {
        format!(
            "{}: tokens={}, over_budget={}, missing=[{}], forbidden=[{}]",
            self.name,
            self.estimated_tokens,
            self.over_budget,
            self.missing_phrases.join(", "),
            self.forbidden_phrases.join(", ")
        )
    }
}

pub fn audit_prompt(spec: &PromptContractSpec<'_>, content: &str) -> PromptAuditReport {
    let tokenizer = HeuristicTokenizer;
    let normalized = content.to_lowercase();
    let missing_phrases = spec
        .required_phrases
        .iter()
        .filter(|phrase| !content.contains(**phrase))
        .map(|phrase| (*phrase).to_string())
        .collect();
    let forbidden_phrases = spec
        .forbidden_phrases
        .iter()
        .filter(|phrase| normalized.contains(&phrase.to_lowercase()))
        .map(|phrase| (*phrase).to_string())
        .collect();
    let estimated_tokens = tokenizer.count_tokens(content);

    PromptAuditReport {
        name: spec.name.to_string(),
        estimated_tokens,
        missing_phrases,
        forbidden_phrases,
        over_budget: estimated_tokens > spec.max_tokens,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::infra::TASK_MANAGEMENT_GUIDE;
    use crate::project::prompt::CORE_ASSISTANT_PROMPT;
    use crate::subagent_loader::discover_subagents;
    use crate::tasks::task_runtime::profiles::ProfileTemplate;

    fn assert_compliant(report: PromptAuditReport) -> Result<(), String> {
        if report.is_compliant() {
            Ok(())
        } else {
            Err(report.summary())
        }
    }

    #[test]
    fn core_prompt_has_a_bounded_production_contract() -> Result<(), String> {
        assert_compliant(audit_prompt(
            &PromptContractSpec {
                name: "core",
                max_tokens: 1_800,
                required_phrases: &[
                    "## Collaboration",
                    "## Execution",
                    "## Evidence And Verification",
                    "## Local Safety And Side Effects",
                    "## Domain Baselines",
                    "## Delivery",
                ],
                forbidden_phrases: DEMO_PHRASES,
            },
            CORE_ASSISTANT_PROMPT,
        ))?;
        assert_compliant(audit_prompt(
            &PromptContractSpec {
                name: "task_management",
                max_tokens: 900,
                required_phrases: &[
                    "## Task And Delegation Tools",
                    "### Task Graph Contract",
                    "### Complex Run Contract",
                    "verification",
                ],
                forbidden_phrases: DEMO_PHRASES,
            },
            TASK_MANAGEMENT_GUIDE,
        ))
    }

    #[test]
    fn builtin_subagents_leave_shared_sections_to_the_compiler() -> Result<(), String> {
        for subagent in discover_subagents(None, None) {
            assert_compliant(audit_prompt(
                &PromptContractSpec {
                    name: subagent.name.as_str(),
                    max_tokens: 700,
                    required_phrases: &["# Role"],
                    forbidden_phrases: DEMO_PHRASES,
                },
                subagent.system_prompt.as_str(),
            ))?;
            for compiler_owned in [
                "# Delivery",
                "# Boundary",
                "## Response Language",
                "## Result",
                "suggested_tasks",
            ] {
                if subagent.system_prompt.contains(compiler_owned) {
                    return Err(format!(
                        "{}: role markdown duplicates compiler-owned section {compiler_owned}",
                        subagent.name
                    ));
                }
            }
            if !subagent.system_prompt.contains("# Method")
                && !subagent.system_prompt.contains("# Execution")
                && !subagent.system_prompt.contains("# Review Standard")
            {
                return Err(format!(
                    "{}: role markdown does not define a role-specific method",
                    subagent.name
                ));
            }
        }
        Ok(())
    }

    #[test]
    fn general_and_bound_domain_cover_evidence_without_compiled_professional_methods()
    -> Result<(), String> {
        let template = ProfileTemplate::general();
        assert_compliant(audit_prompt(
            &PromptContractSpec {
                name: template.key,
                max_tokens: 320,
                required_phrases: &["evidence", "complete"],
                forbidden_phrases: DEMO_PHRASES,
            },
            template.prompt_suffix,
        ))?;
        let binding = crate::domain_plugin::test_binding(true)?;
        let prompt = binding.prompt_instructions();
        assert!(prompt.contains(&binding.snapshot.method));
        assert!(prompt.contains("cargo test --locked"));
        assert!(prompt.contains("reports/result.md"));
        assert!(prompt.contains(&binding.binding_sha256));
        Ok(())
    }
}
