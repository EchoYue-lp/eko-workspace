//! File-backed, coding-first data analysis workspaces.
//!
//! An analysis is ordinary workspace content under `analysis/<id>/`: a
//! reviewable Python/R script, a small manifest, output files, and immutable
//! per-run records. Execution delegates to the framework `run_code` tool so
//! sandbox, timeout, cancellation, and output limits stay on one path.

use std::collections::{BTreeMap, BTreeSet};
use std::fs::{self, File};
use std::io::Read;
use std::path::{Component, Path, PathBuf};
use std::sync::Arc;
use std::time::Instant;

use chrono::{DateTime, Utc};
use echo_agent::tools::{ToolContext, ToolResultKind};
use echo_agent::tools::{ToolFailureCategory, ToolManager, ToolParameters};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha2::{Digest, Sha256};
use thiserror::Error;
use tokio_util::sync::CancellationToken;

const ANALYSIS_ROOT: &str = "analysis";
const MANIFEST_FILE: &str = "manifest.json";
const LATEST_RUN_FILE: &str = "latest-run.json";
const OWNER_INTENT_FILE: &str = ".physical-owner-intent.json";
const RUNS_DIR: &str = "runs";
const CONTRACT_VERSION: u32 = 1;
const MAX_SCRIPT_BYTES: u64 = 2 * 1024 * 1024;
const MAX_JSON_BYTES: u64 = 2 * 1024 * 1024;
const MAX_OUTPUT_FILES: usize = 200;
const MAX_CAPTURE_CHARS: usize = 200_000;

#[derive(Debug, Error)]
pub enum AnalysisError {
    #[error("invalid analysis input: {0}")]
    Invalid(String),
    #[error("analysis not found: {0}")]
    NotFound(String),
    #[error("analysis changed on disk; reload before saving")]
    Conflict,
    #[error("analysis I/O failed: {0}")]
    Io(#[from] std::io::Error),
    #[error("analysis JSON failed: {0}")]
    Json(#[from] serde_json::Error),
    #[error("analysis execution failed: {0}")]
    Execution(String),
    #[error("analysis execution for run {run_id} is not physically settled")]
    Observation {
        run_id: String,
        execution_id: Option<String>,
    },
    #[error("analysis runtime is unavailable: {0}")]
    RuntimeUnavailable(String),
}

pub type AnalysisResult<T> = Result<T, AnalysisError>;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct AnalysisOwnerIntent {
    run_id: String,
    analysis_id: String,
    workspace_generation: String,
    owner_id: String,
    execution_id: Option<String>,
}

// Named projections of the same admitted owner; neither creates a supervisor
// nor changes the durable intent or original cleanup slot.
#[derive(Clone)]
struct AnalysisOwnerObservation {
    intent: AnalysisOwnerIntent,
    execution_started: Arc<std::sync::atomic::AtomicBool>,
    pending_settlement: Arc<std::sync::Mutex<Option<PendingAnalysisSettlement>>>,
}

#[derive(Default)]
struct AnalysisExecutionContext<'a> {
    runtime: Option<&'a crate::analysis_runtime::PreparedAnalyticsRuntime>,
    prepare_managed_runtime: bool,
    product_data: Option<&'a crate::product_data_io::ProductDataIoFlow>,
    owner: Option<AnalysisOwnerObservation>,
}

pub(crate) fn require_analysis_owner_settled(root: &Path, id: &str) -> AnalysisResult<()> {
    let directory = analysis_dir(root, id)?;
    let path = directory.join(OWNER_INTENT_FILE);
    match fs::read(&path) {
        Ok(bytes) => {
            let intent: AnalysisOwnerIntent = serde_json::from_slice(&bytes)?;
            if intent.analysis_id != id
                || intent.owner_id.trim().is_empty()
                || intent.run_id.trim().is_empty()
            {
                return Err(AnalysisError::Invalid(
                    "analysis owner intent is corrupt".to_string(),
                ));
            }
            let terminal_path = directory
                .join(RUNS_DIR)
                .join(format!("{}.json", intent.run_id));
            match fs::read(&terminal_path) {
                Ok(bytes) => {
                    let terminal: AnalysisRunRecord = serde_json::from_slice(&bytes)?;
                    if terminal.run_id == intent.run_id
                        && terminal.analysis_id == intent.analysis_id
                    {
                        acknowledge_analysis_owner_intent(root, &intent)?;
                        return Ok(());
                    }
                    return Err(AnalysisError::Conflict);
                }
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(error.into()),
            }
            Err(AnalysisError::Observation {
                run_id: intent.run_id,
                execution_id: intent.execution_id,
            })
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error.into()),
    }
}

fn begin_analysis_owner_intent(
    root: &Path,
    id: &str,
    generation: String,
) -> AnalysisResult<AnalysisOwnerIntent> {
    require_analysis_owner_settled(root, id)?;
    let intent = AnalysisOwnerIntent {
        run_id: uuid::Uuid::new_v4().to_string(),
        analysis_id: id.to_string(),
        workspace_generation: generation,
        owner_id: uuid::Uuid::new_v4().to_string(),
        execution_id: None,
    };
    write_json(&analysis_dir(root, id)?.join(OWNER_INTENT_FILE), &intent)?;
    Ok(intent)
}

pub(crate) fn acknowledge_analysis_owner_intent(
    root: &Path,
    intent: &AnalysisOwnerIntent,
) -> AnalysisResult<()> {
    let directory = analysis_dir(root, &intent.analysis_id)?;
    let path = directory.join(OWNER_INTENT_FILE);
    let current: AnalysisOwnerIntent = serde_json::from_slice(&fs::read(&path)?)?;
    if current != *intent {
        return Err(AnalysisError::Conflict);
    }
    let record: AnalysisRunRecord = serde_json::from_slice(&fs::read(
        directory
            .join(RUNS_DIR)
            .join(format!("{}.json", intent.run_id)),
    )?)?;
    if record.run_id != intent.run_id {
        return Err(AnalysisError::Conflict);
    }
    fs::remove_file(path)?;
    Ok(())
}

pub(crate) fn reject_unstarted_analysis_owner(
    root: &Path,
    intent: &AnalysisOwnerIntent,
) -> AnalysisResult<()> {
    let path = analysis_dir(root, &intent.analysis_id)?.join(OWNER_INTENT_FILE);
    let current: AnalysisOwnerIntent = read_json(&path)?;
    if current != *intent {
        return Err(AnalysisError::Conflict);
    }
    fs::remove_file(path)?;
    Ok(())
}

impl From<String> for AnalysisError {
    fn from(message: String) -> Self {
        Self::Execution(message)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AnalysisLanguage {
    Python,
    R,
}

impl AnalysisLanguage {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Python => "python",
            Self::R => "r",
        }
    }

    fn script_name(self) -> &'static str {
        match self {
            Self::Python => "analysis.py",
            Self::R => "analysis.R",
        }
    }

    fn starter_script(self) -> &'static str {
        match self {
            Self::Python => {
                r#"from pathlib import Path
import json
import platform
import random

OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

manifest = json.loads(Path("manifest.json").read_text(encoding="utf-8"))
if manifest.get("random_seed") is not None:
    random.seed(manifest["random_seed"])

environment = {
    "python": platform.python_version(),
}
Path("environment.json").write_text(
    json.dumps(environment, indent=2), encoding="utf-8"
)

result = {
    "status": "ok",
    "message": "Replace this starter analysis with reviewable code.",
    "parameters": manifest.get("parameters", {}),
}
Path("result.json").write_text(
    json.dumps(result, indent=2), encoding="utf-8"
)
print(json.dumps(result))
"#
            }
            Self::R => {
                r#"dir.create("outputs", showWarnings = FALSE)

writeLines(
  sprintf('{\n  "r": "%s"\n}', paste(R.version$major, R.version$minor, sep = ".")),
  "environment.json"
)

writeLines(
  '{\n  "status": "ok",\n  "message": "Replace this starter analysis with reviewable code."\n}',
  "result.json"
)
cat('{"status":"ok","message":"Replace this starter analysis with reviewable code."}')
"#
            }
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisManifest {
    pub contract_version: u32,
    pub analysis_id: String,
    pub title: String,
    pub language: AnalysisLanguage,
    pub script_path: String,
    #[serde(default)]
    pub input_paths: Vec<String>,
    #[serde(default)]
    pub parameters: Value,
    pub random_seed: Option<u64>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisFileFingerprint {
    pub path: String,
    pub available: bool,
    pub bytes: Option<u64>,
    pub sha256: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AnalysisRunStatus {
    Succeeded,
    Failed,
    Cancelled,
    TimedOut,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisOutputArtifact {
    pub path: String,
    pub absolute_path: String,
    pub kind: String,
    pub bytes: u64,
    pub sha256: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisRunRecord {
    pub contract_version: u32,
    pub run_id: String,
    pub analysis_id: String,
    pub status: AnalysisRunStatus,
    pub started_at: DateTime<Utc>,
    pub finished_at: DateTime<Utc>,
    pub duration_ms: u64,
    pub script: AnalysisFileFingerprint,
    pub inputs: Vec<AnalysisFileFingerprint>,
    pub parameters: Value,
    pub parameters_sha256: String,
    pub random_seed: Option<u64>,
    pub outputs: Vec<AnalysisOutputArtifact>,
    pub environment: BTreeMap<String, String>,
    pub exit_code: Option<i32>,
    pub sandbox_type: Option<String>,
    #[serde(default)]
    pub runtime_profile: Option<String>,
    pub output: String,
    pub error: Option<String>,
    pub output_truncated: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisSummary {
    pub analysis_id: String,
    pub title: String,
    pub language: AnalysisLanguage,
    pub script_path: String,
    pub updated_at: DateTime<Utc>,
    pub stale: bool,
    pub stale_reasons: Vec<String>,
    pub last_run_status: Option<AnalysisRunStatus>,
    pub last_run_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisDocument {
    pub manifest: AnalysisManifest,
    pub script: String,
    pub script_revision: String,
    pub stale: bool,
    pub stale_reasons: Vec<String>,
    pub last_run: Option<AnalysisRunRecord>,
    pub outputs: Vec<AnalysisOutputArtifact>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SaveAnalysisRequest {
    pub title: String,
    pub script: String,
    pub expected_script_revision: String,
    #[serde(default)]
    pub input_paths: Vec<String>,
    #[serde(default)]
    pub parameters: Value,
    pub random_seed: Option<u64>,
}

pub fn list_analyses(workspace_root: &Path) -> AnalysisResult<Vec<AnalysisSummary>> {
    let root = workspace_root.join(ANALYSIS_ROOT);
    if !root.is_dir() {
        return Ok(Vec::new());
    }

    let mut summaries = Vec::new();
    for entry in fs::read_dir(root)? {
        let entry = match entry {
            Ok(entry) => entry,
            Err(error) => {
                tracing::warn!(%error, "skipping unreadable analysis entry");
                continue;
            }
        };
        if !entry.path().is_dir() {
            continue;
        }
        let Some(analysis_id) = entry.file_name().to_str().map(str::to_string) else {
            continue;
        };
        match load_analysis(workspace_root, &analysis_id) {
            Ok(document) => summaries.push(summary_from_document(&document)),
            Err(error) => {
                tracing::warn!(analysis_id, %error, "skipping invalid analysis workspace");
            }
        }
    }
    summaries.sort_by_key(|summary| std::cmp::Reverse(summary.updated_at));
    Ok(summaries)
}

pub fn create_analysis(
    workspace_root: &Path,
    title: &str,
    language: AnalysisLanguage,
) -> AnalysisResult<AnalysisDocument> {
    let title = title.trim();
    if title.is_empty() {
        return Err(AnalysisError::Invalid(
            "analysis title cannot be empty".to_string(),
        ));
    }

    let analysis_id = new_analysis_id(title);
    let analysis_dir = workspace_root.join(ANALYSIS_ROOT).join(&analysis_id);
    fs::create_dir_all(&analysis_dir)?;
    let now = Utc::now();
    let manifest = AnalysisManifest {
        contract_version: CONTRACT_VERSION,
        analysis_id: analysis_id.clone(),
        title: title.to_string(),
        language,
        script_path: language.script_name().to_string(),
        input_paths: Vec::new(),
        parameters: Value::Object(serde_json::Map::new()),
        random_seed: None,
        created_at: now,
        updated_at: now,
    };

    echo_agent::utils::fs::atomic_write(
        &analysis_dir.join(language.script_name()),
        language.starter_script().as_bytes(),
    )?;
    write_json(&analysis_dir.join(MANIFEST_FILE), &manifest)?;
    load_analysis(workspace_root, &analysis_id)
}

pub fn load_analysis(workspace_root: &Path, analysis_id: &str) -> AnalysisResult<AnalysisDocument> {
    validate_analysis_id(analysis_id)?;
    let analysis_dir = analysis_dir(workspace_root, analysis_id)?;
    let manifest: AnalysisManifest = read_json(&analysis_dir.join(MANIFEST_FILE))?;
    if manifest.contract_version != CONTRACT_VERSION || manifest.analysis_id != analysis_id {
        return Err(AnalysisError::Invalid(
            "analysis manifest identity or version is invalid".to_string(),
        ));
    }
    let script_path = safe_existing_relative_file(&analysis_dir, &manifest.script_path)?;
    let metadata = fs::metadata(&script_path)?;
    if metadata.len() > MAX_SCRIPT_BYTES {
        return Err(AnalysisError::Invalid(
            "analysis script exceeds 2 MiB".to_string(),
        ));
    }
    let script_bytes = fs::read(&script_path)?;
    let script = String::from_utf8(script_bytes.clone()).map_err(|error| {
        AnalysisError::Invalid(format!("analysis script is not valid UTF-8: {error}"))
    })?;
    let script_revision = hash_bytes(&script_bytes);
    let last_run = read_optional_json(&analysis_dir.join(LATEST_RUN_FILE))?;
    let (stale, stale_reasons) = stale_status(workspace_root, &manifest, last_run.as_ref())?;
    let outputs = last_run
        .as_ref()
        .map(|run: &AnalysisRunRecord| run.outputs.clone())
        .unwrap_or_default();
    Ok(AnalysisDocument {
        manifest,
        script,
        script_revision,
        stale,
        stale_reasons,
        last_run,
        outputs,
    })
}

pub fn save_analysis(
    workspace_root: &Path,
    analysis_id: &str,
    request: SaveAnalysisRequest,
) -> AnalysisResult<AnalysisDocument> {
    require_analysis_owner_settled(workspace_root, analysis_id)?;
    if request.script.len() as u64 > MAX_SCRIPT_BYTES {
        return Err(AnalysisError::Invalid(
            "analysis script exceeds 2 MiB".to_string(),
        ));
    }
    let mut document = load_analysis(workspace_root, analysis_id)?;
    if document.script_revision != request.expected_script_revision {
        return Err(AnalysisError::Conflict);
    }
    let title = request.title.trim();
    if title.is_empty() {
        return Err(AnalysisError::Invalid(
            "analysis title cannot be empty".to_string(),
        ));
    }
    let input_paths = normalized_input_paths(&request.input_paths)?;
    let analysis_dir = analysis_dir(workspace_root, analysis_id)?;
    let script_path = safe_existing_relative_file(&analysis_dir, &document.manifest.script_path)?;

    echo_agent::utils::fs::atomic_write(&script_path, request.script.as_bytes())?;
    document.manifest.title = title.to_string();
    document.manifest.input_paths = input_paths;
    document.manifest.parameters = request.parameters;
    document.manifest.random_seed = request.random_seed;
    document.manifest.updated_at = Utc::now();
    write_json(&analysis_dir.join(MANIFEST_FILE), &document.manifest)?;
    load_analysis(workspace_root, analysis_id)
}

pub fn delete_analysis(workspace_root: &Path, analysis_id: &str) -> AnalysisResult<()> {
    require_analysis_owner_settled(workspace_root, analysis_id)?;
    let directory = analysis_dir(workspace_root, analysis_id)?;
    fs::remove_dir_all(directory)?;
    Ok(())
}

pub async fn run_analysis_with_product_data(
    product_data: &crate::product_data_io::ScopedProductData,
    flow: &crate::product_data_io::ProductDataIoFlow,
    analysis_id: &str,
    cancel: Option<Arc<CancellationToken>>,
) -> AnalysisResult<AnalysisDocument> {
    let root = product_data.data_root().to_path_buf();
    let id = analysis_id.to_string();
    let generation = product_data.generation();
    let intent = run_analysis_io(Some(flow), "persist analysis owner intent", move || {
        begin_analysis_owner_intent(&root, &id, generation)
    })
    .await?;
    let conversation_id = format!("analysis:{analysis_id}");
    let execution = match product_data.runtime().agent_for(&conversation_id).await {
        Ok(execution) => execution,
        Err(error) => {
            let original = error.to_string();
            let root = product_data.data_root().to_path_buf();
            let cleanup_intent = intent.clone();
            if let Err(cleanup) =
                run_analysis_io(Some(flow), "reject unstarted analysis owner", move || {
                    reject_unstarted_analysis_owner(&root, &cleanup_intent)
                })
                .await
            {
                product_data.retain_analysis_cleanup(
                    analysis_id,
                    intent.clone(),
                    true,
                    Err(original.clone()),
                );
                return Err(AnalysisError::Execution(format!(
                    "{original}; original owner rollback failed: {cleanup}"
                )));
            }
            return Err(AnalysisError::Execution(original));
        }
    };
    let agent = execution.agent();
    let tool_manager = agent.read(|agent| agent.tool_manager().clone()).await;
    product_data
        .retain_analysis_resource(analysis_id, execution)
        .map_err(|_| {
            AnalysisError::Execution("original analysis owner is not admitted".to_string())
        })?;
    let execution_started = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let pending_settlement = Arc::new(std::sync::Mutex::new(None));
    let result = run_analysis_with_runtime(
        tool_manager.as_ref(),
        product_data.data_root(),
        analysis_id,
        cancel,
        AnalysisExecutionContext {
            runtime: None,
            prepare_managed_runtime: true,
            product_data: Some(flow),
            owner: Some(AnalysisOwnerObservation {
                intent: intent.clone(),
                execution_started: execution_started.clone(),
                pending_settlement: pending_settlement.clone(),
            }),
        },
    )
    .await;
    if result.is_ok() {
        let root = product_data.data_root().to_path_buf();
        let cleanup_intent = intent.clone();
        if let Err(error) =
            run_analysis_io(Some(flow), "acknowledge analysis owner intent", move || {
                acknowledge_analysis_owner_intent(&root, &cleanup_intent)
            })
            .await
        {
            product_data.retain_analysis_cleanup(
                analysis_id,
                intent,
                false,
                result
                    .as_ref()
                    .map(Clone::clone)
                    .map_err(ToString::to_string),
            );
            return Err(error);
        }
    } else if !execution_started.load(std::sync::atomic::Ordering::Acquire)
        && !matches!(&result, Err(AnalysisError::Observation { .. }))
    {
        let root = product_data.data_root().to_path_buf();
        let cleanup_intent = intent.clone();
        if let Err(error) =
            run_analysis_io(Some(flow), "reject unstarted analysis owner", move || {
                reject_unstarted_analysis_owner(&root, &cleanup_intent)
            })
            .await
        {
            product_data.retain_analysis_cleanup(
                analysis_id,
                intent,
                true,
                result
                    .as_ref()
                    .map(Clone::clone)
                    .map_err(ToString::to_string),
            );
            return Err(error);
        }
    } else if !matches!(&result, Err(AnalysisError::Observation { .. }))
        && let Some(pending) = pending_settlement
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .take()
    {
        // The original tool has returned a real result. Retain its exact
        // pending durable writes; a later poll only retries these writes.
        product_data.retain_analysis_pending_settlement(
            analysis_id,
            intent,
            pending,
            result
                .as_ref()
                .err()
                .map(ToString::to_string)
                .unwrap_or_default(),
        );
    }
    result
}

#[cfg(test)]
async fn run_analysis(
    tool_manager: &ToolManager,
    workspace_root: &Path,
    analysis_id: &str,
    cancel: Option<Arc<CancellationToken>>,
) -> AnalysisResult<AnalysisDocument> {
    run_analysis_with_runtime(
        tool_manager,
        workspace_root,
        analysis_id,
        cancel,
        AnalysisExecutionContext {
            runtime: None,
            prepare_managed_runtime: false,
            product_data: None,
            owner: None,
        },
    )
    .await
}

async fn run_analysis_with_runtime(
    tool_manager: &ToolManager,
    workspace_root: &Path,
    analysis_id: &str,
    cancel: Option<Arc<CancellationToken>>,
    context: AnalysisExecutionContext<'_>,
) -> AnalysisResult<AnalysisDocument> {
    let AnalysisExecutionContext {
        runtime,
        prepare_managed_runtime,
        product_data,
        owner: intent,
    } = context;
    let pending_settlement = intent.clone();
    let execution_started = intent.as_ref().map(|owner| owner.execution_started.clone());
    let timer = Instant::now();
    let root = workspace_root.to_path_buf();
    let id = analysis_id.to_string();
    let prepared = run_analysis_io(product_data, "prepare analysis execution", move || {
        let document = load_analysis(&root, &id)?;
        let analysis_dir = analysis_dir(&root, &id)?;
        let script = fingerprint_required(
            &analysis_dir.join(&document.manifest.script_path),
            &document.manifest.script_path,
        )?;
        let inputs = fingerprint_inputs(&root, &document.manifest.input_paths)?;
        let parameters_sha256 = hash_json(&document.manifest.parameters)?;
        let run_id = intent
            .as_ref()
            .map(|owner| owner.intent.run_id.clone())
            .unwrap_or_else(|| uuid::Uuid::new_v4().to_string());
        let started_at = Utc::now();
        Ok(PreparedAnalysisRun {
            document,
            analysis_dir,
            script,
            inputs,
            parameters_sha256,
            run_id,
            started_at,
        })
    })
    .await?;

    if let Some(started) = execution_started {
        started.store(true, std::sync::atomic::Ordering::Release);
    }
    let clear_directory = prepared.analysis_dir.clone();
    if let Err(error) =
        run_analysis_io(product_data, "clear original analysis outputs", move || {
            clear_generated_outputs(&clear_directory)
        })
        .await
    {
        // No tool was started, so this is a known physical preparation
        // failure; retain a failed record for ordinary durable-write retry.
        let detail = error.to_string();
        let terminal = AnalysisTerminal {
            status: AnalysisRunStatus::Failed,
            exit_code: None,
            sandbox_type: None,
            output: String::new(),
            error: Some(detail.clone()),
            output_truncated: false,
        };
        settle_analysis_run(
            workspace_root,
            analysis_id,
            prepared,
            terminal,
            timer,
            AnalysisExecutionContext {
                runtime: None,
                product_data,
                owner: pending_settlement,
                ..Default::default()
            },
        )
        .await?;
        return Err(AnalysisError::Execution(detail));
    }

    let managed_runtime = if runtime.is_none()
        && prepare_managed_runtime
        && prepared.document.manifest.language == AnalysisLanguage::Python
    {
        let prepared_runtime = match product_data {
            Some(product_data) => {
                crate::analysis_runtime::AnalyticsRuntime::with_product_data_io(
                    product_data.service(),
                )
                .prepare_python_with_product_flow(product_data, cancel.clone())
                .await
            }
            #[cfg(test)]
            None => {
                crate::analysis_runtime::AnalyticsRuntime::default()
                    .prepare_python_with_cancel(cancel.clone())
                    .await
            }
            #[cfg(not(test))]
            None => {
                return Err(AnalysisError::Execution(
                    "analysis runtime preparation requires an application-owned product-data scope"
                        .to_string(),
                ));
            }
        };
        match prepared_runtime {
            Ok(runtime) => Some(runtime),
            Err(error) => {
                let terminal = classify_runtime_error(&error);
                return settle_analysis_run(
                    workspace_root,
                    analysis_id,
                    prepared,
                    terminal,
                    timer,
                    AnalysisExecutionContext {
                        runtime: None,
                        product_data,
                        owner: pending_settlement,
                        ..Default::default()
                    },
                )
                .await;
            }
        }
    } else {
        None
    };
    let runtime = runtime.or(managed_runtime.as_ref());
    let mut parameters = ToolParameters::new();
    parameters.insert(
        "language".to_string(),
        Value::String(prepared.document.manifest.language.as_str().to_string()),
    );
    parameters.insert(
        "script_path".to_string(),
        Value::String(prepared.document.manifest.script_path.clone()),
    );
    let context = ToolContext {
        working_dir: Some(prepared.analysis_dir.clone()),
        execution_id: Some(prepared.run_id.clone()),
        call_id: Some(format!("analysis:{}", prepared.run_id)),
        script_execution_profile: runtime.map(|runtime| runtime.profile.clone()),
        cancel,
        ..ToolContext::default()
    };
    let execution = tool_manager
        .execute_tool_with_context_draining_started("run_code", parameters, &context)
        .await;
    let terminal = match execution {
        Ok(result) => {
            let status = run_status(&result);
            let exit_code = match &result.kind {
                ToolResultKind::CommandOutput { exit_code } => *exit_code,
                _ => result
                    .metadata
                    .get("exit_code")
                    .and_then(|value| value.parse::<i32>().ok()),
            };
            AnalysisTerminal {
                status,
                exit_code,
                sandbox_type: result.metadata.get("sandbox_type").cloned(),
                output: bounded_text(&result.output, MAX_CAPTURE_CHARS),
                error: result.error.map(|value| bounded_text(&value, 8_000)),
                output_truncated: result.truncated,
            }
        }
        Err(error) => terminal_from_react_error(&error)?,
    };
    settle_analysis_run(
        workspace_root,
        analysis_id,
        prepared,
        terminal,
        timer,
        AnalysisExecutionContext {
            runtime,
            product_data,
            owner: pending_settlement,
            ..Default::default()
        },
    )
    .await
}

#[derive(Clone)]
struct PreparedAnalysisRun {
    document: AnalysisDocument,
    analysis_dir: PathBuf,
    script: AnalysisFileFingerprint,
    inputs: Vec<AnalysisFileFingerprint>,
    parameters_sha256: String,
    run_id: String,
    started_at: DateTime<Utc>,
}

#[derive(Clone)]
struct AnalysisTerminal {
    status: AnalysisRunStatus,
    exit_code: Option<i32>,
    sandbox_type: Option<String>,
    output: String,
    error: Option<String>,
    output_truncated: bool,
}

#[derive(Clone)]
pub(crate) struct PendingAnalysisSettlement {
    root: PathBuf,
    analysis_id: String,
    prepared: PreparedAnalysisRun,
    terminal: AnalysisTerminal,
    finished_at: DateTime<Utc>,
    duration_ms: u64,
    runtime_environment: BTreeMap<String, String>,
    runtime_profile: Option<String>,
    owner_intent: Option<AnalysisOwnerIntent>,
}

pub(crate) fn retry_analysis_settlement(
    pending: &PendingAnalysisSettlement,
) -> AnalysisResult<AnalysisDocument> {
    let prepared = &pending.prepared;
    if let Some(expected) = pending.owner_intent.as_ref() {
        let current: AnalysisOwnerIntent =
            read_json(&prepared.analysis_dir.join(OWNER_INTENT_FILE))?;
        if current != *expected
            || pending.analysis_id != expected.analysis_id
            || prepared.run_id != expected.run_id
        {
            return Err(AnalysisError::Conflict);
        }
    }
    let terminal = &pending.terminal;
    let outputs = archive_outputs(&pending.root, &prepared.analysis_dir, &prepared.run_id)?;
    let mut environment = read_environment(&prepared.analysis_dir.join("environment.json"))?;
    environment.extend(pending.runtime_environment.clone());
    let record = AnalysisRunRecord {
        contract_version: CONTRACT_VERSION,
        run_id: prepared.run_id.clone(),
        analysis_id: pending.analysis_id.clone(),
        status: terminal.status,
        started_at: prepared.started_at,
        finished_at: pending.finished_at,
        duration_ms: pending.duration_ms,
        script: prepared.script.clone(),
        inputs: prepared.inputs.clone(),
        parameters: prepared.document.manifest.parameters.clone(),
        parameters_sha256: prepared.parameters_sha256.clone(),
        random_seed: prepared.document.manifest.random_seed,
        outputs,
        environment,
        exit_code: terminal.exit_code,
        sandbox_type: terminal.sandbox_type.clone(),
        runtime_profile: pending.runtime_profile.clone(),
        output: terminal.output.clone(),
        error: terminal.error.clone(),
        output_truncated: terminal.output_truncated,
    };
    let runs_dir = prepared.analysis_dir.join(RUNS_DIR);
    fs::create_dir_all(&runs_dir)?;
    write_json(&runs_dir.join(format!("{}.json", prepared.run_id)), &record)?;
    write_json(&prepared.analysis_dir.join(LATEST_RUN_FILE), &record)?;
    load_analysis(&pending.root, &pending.analysis_id)
}

async fn settle_analysis_run(
    workspace_root: &Path,
    analysis_id: &str,
    prepared: PreparedAnalysisRun,
    terminal: AnalysisTerminal,
    timer: Instant,
    context: AnalysisExecutionContext<'_>,
) -> AnalysisResult<AnalysisDocument> {
    let AnalysisExecutionContext {
        runtime,
        product_data,
        owner: owner_pending,
        ..
    } = context;
    let pending = PendingAnalysisSettlement {
        root: workspace_root.to_path_buf(),
        analysis_id: analysis_id.to_string(),
        prepared,
        terminal,
        finished_at: Utc::now(),
        duration_ms: u64::try_from(timer.elapsed().as_millis()).unwrap_or(u64::MAX),
        runtime_environment: runtime
            .map(|runtime| runtime.environment.clone())
            .unwrap_or_default(),
        runtime_profile: runtime.map(|runtime| runtime.profile.id.clone()),
        owner_intent: owner_pending.as_ref().map(|owner| owner.intent.clone()),
    };
    if let Some(owner) = owner_pending.as_ref() {
        *owner
            .pending_settlement
            .lock()
            .unwrap_or_else(|e| e.into_inner()) = Some(pending.clone());
    }
    let result = run_analysis_io(product_data, "settle analysis execution", move || {
        retry_analysis_settlement(&pending)
    })
    .await;
    // The original caller may still need to acknowledge the durable intent.
    // The private slot dies normally on success and is retained only on error.
    result
}

async fn run_analysis_io<T, F>(
    product_data: Option<&crate::product_data_io::ProductDataIoFlow>,
    operation: &'static str,
    function: F,
) -> AnalysisResult<T>
where
    T: Send + 'static,
    F: FnOnce() -> AnalysisResult<T> + Send + 'static,
{
    match product_data {
        Some(product_data) => product_data
            .run(operation, function)
            .await
            .map_err(|error| AnalysisError::Execution(error.to_string()))?,
        #[cfg(test)]
        None => crate::product_data_io::ProductDataIoService::new()
            .run(operation, function)
            .await
            .map_err(|error| AnalysisError::Execution(error.to_string()))?,
        #[cfg(not(test))]
        None => Err(AnalysisError::Execution(
            "analysis product-data I/O requires an application-owned scope".to_string(),
        )),
    }
}

pub fn format_analysis_list(summaries: &[AnalysisSummary]) -> String {
    if summaries.is_empty() {
        return "No file-backed analyses found.".to_string();
    }
    let mut output = String::from("Analyses:\n");
    for summary in summaries {
        let status = summary
            .last_run_status
            .map(|status| format!("{status:?}").to_ascii_lowercase())
            .unwrap_or_else(|| "not-run".to_string());
        let stale = if summary.stale { "stale" } else { "current" };
        output.push_str(&format!(
            "- {} [{}; {}] {} ({})\n",
            summary.analysis_id,
            summary.language.as_str(),
            status,
            summary.title,
            stale
        ));
    }
    output
}

pub fn format_analysis_document(document: &AnalysisDocument) -> String {
    let status = document
        .last_run
        .as_ref()
        .map(|run| format!("{:?}", run.status).to_ascii_lowercase())
        .unwrap_or_else(|| "not-run".to_string());
    let mut output = format!(
        "Analysis {}\nTitle: {}\nLanguage: {}\nScript: analysis/{}/{}\nStatus: {}\nStale: {}\n",
        document.manifest.analysis_id,
        document.manifest.title,
        document.manifest.language.as_str(),
        document.manifest.analysis_id,
        document.manifest.script_path,
        status,
        document.stale
    );
    if !document.stale_reasons.is_empty() {
        output.push_str("Stale reasons:\n");
        for reason in &document.stale_reasons {
            output.push_str(&format!("- {reason}\n"));
        }
    }
    if let Some(run) = &document.last_run {
        if !run.output.is_empty() {
            output.push_str("Output:\n");
            output.push_str(&bounded_text(&run.output, 4_000));
            output.push('\n');
        }
        if let Some(error) = &run.error {
            output.push_str(&format!("Error: {}\n", bounded_text(error, 2_000)));
        }
        if !run.outputs.is_empty() {
            output.push_str("Artifacts:\n");
            for artifact in &run.outputs {
                output.push_str(&format!(
                    "- {} ({}, {} bytes)\n",
                    artifact.path, artifact.kind, artifact.bytes
                ));
            }
        }
    }
    output
}

fn summary_from_document(document: &AnalysisDocument) -> AnalysisSummary {
    AnalysisSummary {
        analysis_id: document.manifest.analysis_id.clone(),
        title: document.manifest.title.clone(),
        language: document.manifest.language,
        script_path: document.manifest.script_path.clone(),
        updated_at: document.manifest.updated_at,
        stale: document.stale,
        stale_reasons: document.stale_reasons.clone(),
        last_run_status: document.last_run.as_ref().map(|run| run.status),
        last_run_at: document.last_run.as_ref().map(|run| run.finished_at),
    }
}

fn new_analysis_id(title: &str) -> String {
    let mut slug = String::new();
    let mut last_was_separator = false;
    for character in title.chars() {
        if slug.chars().count() >= 32 {
            break;
        }
        if character.is_ascii_alphanumeric() {
            slug.push(character.to_ascii_lowercase());
            last_was_separator = false;
        } else if !last_was_separator && !slug.is_empty() {
            slug.push('-');
            last_was_separator = true;
        }
    }
    while slug.ends_with('-') {
        slug.pop();
    }
    if slug.is_empty() {
        slug.push_str("analysis");
    }
    let suffix: String = uuid::Uuid::new_v4()
        .simple()
        .to_string()
        .chars()
        .take(8)
        .collect();
    format!("{slug}-{suffix}")
}

fn validate_analysis_id(analysis_id: &str) -> AnalysisResult<()> {
    if analysis_id.is_empty()
        || !analysis_id.chars().all(|character| {
            character.is_ascii_alphanumeric() || character == '-' || character == '_'
        })
    {
        return Err(AnalysisError::Invalid(
            "analysis id contains unsupported characters".to_string(),
        ));
    }
    Ok(())
}

fn analysis_dir(workspace_root: &Path, analysis_id: &str) -> AnalysisResult<PathBuf> {
    validate_analysis_id(analysis_id)?;
    let path = workspace_root.join(ANALYSIS_ROOT).join(analysis_id);
    if !path.is_dir() {
        return Err(AnalysisError::NotFound(analysis_id.to_string()));
    }
    Ok(path)
}

fn normalized_input_paths(paths: &[String]) -> AnalysisResult<Vec<String>> {
    let mut unique = BTreeSet::new();
    for raw in paths {
        let trimmed = raw.trim();
        if trimmed.is_empty() {
            continue;
        }
        let path = Path::new(trimmed);
        if path.is_absolute()
            || path.components().any(|component| {
                matches!(
                    component,
                    Component::ParentDir | Component::RootDir | Component::Prefix(_)
                )
            })
        {
            return Err(AnalysisError::Invalid(format!(
                "input path must be workspace-relative: {trimmed}"
            )));
        }
        unique.insert(path.to_string_lossy().to_string());
    }
    Ok(unique.into_iter().collect())
}

fn safe_existing_relative_file(base: &Path, relative: &str) -> AnalysisResult<PathBuf> {
    let path = Path::new(relative);
    if path.is_absolute()
        || path.components().any(|component| {
            matches!(
                component,
                Component::ParentDir | Component::RootDir | Component::Prefix(_)
            )
        })
    {
        return Err(AnalysisError::Invalid(
            "analysis file path escapes its directory".to_string(),
        ));
    }
    let canonical_base = base.canonicalize()?;
    let candidate = base.join(path);
    let canonical_candidate = candidate.canonicalize()?;
    if !canonical_candidate.starts_with(&canonical_base) || !canonical_candidate.is_file() {
        return Err(AnalysisError::Invalid(
            "analysis file must stay inside its directory".to_string(),
        ));
    }
    Ok(canonical_candidate)
}

fn stale_status(
    workspace_root: &Path,
    manifest: &AnalysisManifest,
    last_run: Option<&AnalysisRunRecord>,
) -> AnalysisResult<(bool, Vec<String>)> {
    let Some(last_run) = last_run else {
        return Ok((true, vec!["analysis has not been run".to_string()]));
    };
    let analysis_dir = analysis_dir(workspace_root, &manifest.analysis_id)?;
    let current_script = fingerprint_required(
        &analysis_dir.join(&manifest.script_path),
        &manifest.script_path,
    )?;
    let current_inputs = fingerprint_inputs(workspace_root, &manifest.input_paths)?;
    let mut reasons = Vec::new();
    if current_script.sha256 != last_run.script.sha256 {
        reasons.push("script changed since the last run".to_string());
    }
    if current_inputs.len() != last_run.inputs.len() {
        reasons.push("input list changed since the last run".to_string());
    } else {
        for current in &current_inputs {
            let previous = last_run
                .inputs
                .iter()
                .find(|item| item.path == current.path);
            if previous.is_none_or(|item| {
                item.available != current.available || item.sha256 != current.sha256
            }) {
                reasons.push(format!("input changed or is unavailable: {}", current.path));
            }
        }
    }
    if hash_json(&manifest.parameters)? != last_run.parameters_sha256 {
        reasons.push("parameters changed since the last run".to_string());
    }
    if manifest.random_seed != last_run.random_seed {
        reasons.push("random seed changed since the last run".to_string());
    }
    Ok((!reasons.is_empty(), reasons))
}

fn fingerprint_inputs(
    workspace_root: &Path,
    input_paths: &[String],
) -> AnalysisResult<Vec<AnalysisFileFingerprint>> {
    let mut fingerprints = Vec::with_capacity(input_paths.len());
    let canonical_root = workspace_root.canonicalize()?;
    for path in input_paths {
        let candidate = workspace_root.join(path);
        let canonical = match candidate.canonicalize() {
            Ok(canonical) if canonical.starts_with(&canonical_root) && canonical.is_file() => {
                canonical
            }
            _ => {
                fingerprints.push(AnalysisFileFingerprint {
                    path: path.clone(),
                    available: false,
                    bytes: None,
                    sha256: None,
                });
                continue;
            }
        };
        fingerprints.push(fingerprint_required(&canonical, path)?);
    }
    Ok(fingerprints)
}

fn fingerprint_required(
    path: &Path,
    display_path: &str,
) -> AnalysisResult<AnalysisFileFingerprint> {
    let metadata = fs::metadata(path)?;
    Ok(AnalysisFileFingerprint {
        path: display_path.to_string(),
        available: true,
        bytes: Some(metadata.len()),
        sha256: Some(hash_file(path)?),
    })
}

fn clear_generated_outputs(analysis_dir: &Path) -> AnalysisResult<()> {
    for file_name in ["environment.json", "result.json"] {
        remove_generated_path(&analysis_dir.join(file_name))?;
    }
    let outputs_dir = analysis_dir.join("outputs");
    remove_generated_path(&outputs_dir)?;
    fs::create_dir_all(&outputs_dir)?;
    Ok(())
}

fn remove_generated_path(path: &Path) -> AnalysisResult<()> {
    match fs::symlink_metadata(path) {
        Ok(metadata) if metadata.is_dir() && !metadata.file_type().is_symlink() => {
            fs::remove_dir_all(path)?;
        }
        Ok(_) => fs::remove_file(path)?,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => return Err(error.into()),
    }
    Ok(())
}

fn collect_outputs(
    workspace_root: &Path,
    analysis_dir: &Path,
) -> AnalysisResult<Vec<AnalysisOutputArtifact>> {
    let mut paths = Vec::new();
    for file_name in ["environment.json", "result.json"] {
        let path = analysis_dir.join(file_name);
        if path.is_file() {
            paths.push(path);
        }
    }
    let outputs_dir = analysis_dir.join("outputs");
    if outputs_dir.is_dir() {
        collect_output_paths(&outputs_dir, &mut paths)?;
    }
    let mut outputs = Vec::new();
    for path in paths.into_iter().take(MAX_OUTPUT_FILES) {
        let metadata = fs::metadata(&path)?;
        let relative = path
            .strip_prefix(workspace_root)
            .unwrap_or(&path)
            .to_string_lossy()
            .to_string();
        outputs.push(AnalysisOutputArtifact {
            path: relative,
            absolute_path: path.display().to_string(),
            kind: output_kind(&path).to_string(),
            bytes: metadata.len(),
            sha256: hash_file(&path)?,
        });
    }
    outputs.sort_by(|left, right| left.path.cmp(&right.path));
    Ok(outputs)
}

fn archive_outputs(
    workspace_root: &Path,
    analysis_dir: &Path,
    run_id: &str,
) -> AnalysisResult<Vec<AnalysisOutputArtifact>> {
    let generated = collect_outputs(workspace_root, analysis_dir)?;
    let artifact_root = analysis_dir.join(RUNS_DIR).join(run_id).join("artifacts");
    let canonical_analysis = analysis_dir.canonicalize()?;
    let mut archived = Vec::with_capacity(generated.len());

    for artifact in generated {
        let source = PathBuf::from(&artifact.absolute_path).canonicalize()?;
        let relative = source.strip_prefix(&canonical_analysis).map_err(|_| {
            AnalysisError::Invalid(format!(
                "generated artifact is outside analysis directory: {}",
                source.display()
            ))
        })?;
        let target = artifact_root.join(relative);
        copy_artifact_atomically(&source, &target)?;
        let metadata = fs::metadata(&target)?;
        let path = target
            .strip_prefix(workspace_root)
            .map_err(|_| {
                AnalysisError::Invalid("archived artifact is outside workspace".to_string())
            })?
            .to_string_lossy()
            .to_string();
        archived.push(AnalysisOutputArtifact {
            path,
            absolute_path: target.display().to_string(),
            kind: output_kind(&target).to_string(),
            bytes: metadata.len(),
            sha256: hash_file(&target)?,
        });
    }
    archived.sort_by(|left, right| left.path.cmp(&right.path));
    Ok(archived)
}

fn copy_artifact_atomically(source: &Path, target: &Path) -> AnalysisResult<()> {
    let parent = target.parent().ok_or_else(|| {
        AnalysisError::Invalid(format!("artifact path has no parent: {}", target.display()))
    })?;
    fs::create_dir_all(parent)?;
    let file_name = target
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| AnalysisError::Invalid("artifact file name is not UTF-8".to_string()))?;
    let temporary = parent.join(format!(".{file_name}.{}.tmp", uuid::Uuid::new_v4()));
    let copy_result = (|| -> std::io::Result<()> {
        let mut input = File::open(source)?;
        let mut output = File::create(&temporary)?;
        std::io::copy(&mut input, &mut output)?;
        output.sync_all()?;
        fs::rename(&temporary, target)
    })();
    if let Err(error) = copy_result {
        let _ = fs::remove_file(&temporary);
        return Err(error.into());
    }
    Ok(())
}

fn collect_output_paths(current: &Path, paths: &mut Vec<PathBuf>) -> AnalysisResult<()> {
    if paths.len() >= MAX_OUTPUT_FILES {
        return Ok(());
    }
    for entry in fs::read_dir(current)? {
        let entry = entry?;
        let path = entry.path();
        let metadata = fs::symlink_metadata(&path)?;
        if metadata.file_type().is_symlink() {
            continue;
        }
        if metadata.is_dir() {
            collect_output_paths(&path, paths)?;
        } else if metadata.is_file() {
            paths.push(path);
            if paths.len() >= MAX_OUTPUT_FILES {
                return Ok(());
            }
        }
    }
    Ok(())
}

fn output_kind(path: &Path) -> &'static str {
    match path
        .extension()
        .and_then(|extension| extension.to_str())
        .map(str::to_ascii_lowercase)
        .as_deref()
    {
        Some("png" | "jpg" | "jpeg" | "webp" | "svg") => "chart",
        Some("csv" | "tsv" | "parquet" | "xlsx") => "table",
        Some("md" | "html" | "pdf" | "txt") => "report",
        Some("json") => "result",
        _ => "file",
    }
}

fn read_environment(path: &Path) -> AnalysisResult<BTreeMap<String, String>> {
    if !path.is_file() {
        return Ok(BTreeMap::new());
    }
    let value: Value = read_json(path)?;
    let Some(object) = value.as_object() else {
        return Ok(BTreeMap::new());
    };
    Ok(object
        .iter()
        .take(64)
        .map(|(key, value)| {
            let rendered = value
                .as_str()
                .map(str::to_string)
                .unwrap_or_else(|| value.to_string());
            (key.clone(), bounded_text(&rendered, 256))
        })
        .collect())
}

fn run_status(result: &echo_agent::tools::ToolResult) -> AnalysisRunStatus {
    if result.success {
        return AnalysisRunStatus::Succeeded;
    }
    match result.failure.as_ref().map(|failure| failure.category) {
        Some(ToolFailureCategory::Cancelled) => AnalysisRunStatus::Cancelled,
        Some(ToolFailureCategory::Timeout) => AnalysisRunStatus::TimedOut,
        _ => AnalysisRunStatus::Failed,
    }
}

fn terminal_from_react_error(
    error: &echo_agent::error::ReactError,
) -> AnalysisResult<AnalysisTerminal> {
    let failure =
        echo_agent::error::AgentFailure::try_from(error).map_err(
            |observation| match observation {
                echo_agent::error::ReactError::ExecutionNotSettled {
                    run_id,
                    execution_id,
                } => AnalysisError::Observation {
                    run_id,
                    execution_id,
                },
                other => AnalysisError::Execution(other.to_string()),
            },
        )?;
    let status = match failure.terminal_kind {
        echo_agent::error::AgentTerminalKind::Cancelled => AnalysisRunStatus::Cancelled,
        echo_agent::error::AgentTerminalKind::TimedOut => AnalysisRunStatus::TimedOut,
        echo_agent::error::AgentTerminalKind::Failed
        | echo_agent::error::AgentTerminalKind::PermissionDenied => AnalysisRunStatus::Failed,
    };
    Ok(AnalysisTerminal {
        status,
        exit_code: None,
        sandbox_type: None,
        output: String::new(),
        error: Some(bounded_text(&failure.message, 8_000)),
        output_truncated: false,
    })
}

fn classify_runtime_error(
    error: &crate::analysis_runtime::AnalyticsRuntimeError,
) -> AnalysisTerminal {
    let status = match error {
        crate::analysis_runtime::AnalyticsRuntimeError::Cancelled(_) => {
            AnalysisRunStatus::Cancelled
        }
        crate::analysis_runtime::AnalyticsRuntimeError::CommandTimedOut(_) => {
            AnalysisRunStatus::TimedOut
        }
        _ => AnalysisRunStatus::Failed,
    };
    AnalysisTerminal {
        status,
        exit_code: None,
        sandbox_type: None,
        output: String::new(),
        error: Some(bounded_text(&error.to_string(), 8_000)),
        output_truncated: false,
    }
}

fn hash_file(path: &Path) -> AnalysisResult<String> {
    let mut file = File::open(path)?;
    let mut hasher = Sha256::new();
    let mut buffer = [0_u8; 64 * 1024];
    loop {
        let count = file.read(&mut buffer)?;
        if count == 0 {
            break;
        }
        let Some(chunk) = buffer.get(..count) else {
            return Err(AnalysisError::Invalid(
                "file read exceeded the hash buffer".to_string(),
            ));
        };
        hasher.update(chunk);
    }
    Ok(hex::encode(hasher.finalize()))
}

fn hash_bytes(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}

fn hash_json(value: &Value) -> AnalysisResult<String> {
    Ok(hash_bytes(&serde_json::to_vec(value)?))
}

fn bounded_text(value: &str, max_chars: usize) -> String {
    value.chars().take(max_chars).collect()
}

fn read_json<T: for<'de> Deserialize<'de>>(path: &Path) -> AnalysisResult<T> {
    let metadata = fs::metadata(path)?;
    if metadata.len() > MAX_JSON_BYTES {
        return Err(AnalysisError::Invalid(format!(
            "analysis JSON exceeds {} bytes: {}",
            MAX_JSON_BYTES,
            path.display()
        )));
    }
    let bytes = fs::read(path)?;
    Ok(serde_json::from_slice(&bytes)?)
}

fn read_optional_json<T: for<'de> Deserialize<'de>>(path: &Path) -> AnalysisResult<Option<T>> {
    if !path.is_file() {
        return Ok(None);
    }
    read_json(path).map(Some)
}

fn write_json<T: Serialize>(path: &Path, value: &T) -> AnalysisResult<()> {
    let bytes = serde_json::to_vec_pretty(value)?;
    echo_agent::utils::fs::atomic_write(path, &bytes)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    #[test]
    fn unknown_analysis_owner_survives_restart_without_clearing_outputs()
    -> Result<(), Box<dyn std::error::Error>> {
        let root = tempfile::tempdir()?;
        let created =
            super::create_analysis(root.path(), "owner proof", super::AnalysisLanguage::Python)?;
        let id = created.manifest.analysis_id;
        let output = root
            .path()
            .join(super::ANALYSIS_ROOT)
            .join(&id)
            .join("outputs")
            .join("sentinel.txt");
        std::fs::create_dir_all(output.parent().ok_or("output parent missing")?)?;
        std::fs::write(&output, "中文🙂 unchanged")?;
        let intent = super::begin_analysis_owner_intent(
            root.path(),
            &id,
            "original-generation".to_string(),
        )?;
        // A fresh owner must consult the same file authority before any clear
        // or new work; no in-memory supervisor record is available here.
        assert!(
            matches!(super::begin_analysis_owner_intent(root.path(), &id, "new-generation".to_string()), Err(super::AnalysisError::Observation { run_id, .. }) if run_id == intent.run_id)
        );
        assert!(matches!(
            super::delete_analysis(root.path(), &id),
            Err(super::AnalysisError::Observation { .. })
        ));
        assert_eq!(std::fs::read_to_string(output)?, "中文🙂 unchanged");
        assert!(
            super::acknowledge_analysis_owner_intent(root.path(), &intent).is_err(),
            "no durable terminal receipt may be synthesized for cleanup"
        );
        assert!(super::require_analysis_owner_settled(root.path(), &id).is_err());
        Ok(())
    }

    #[tokio::test]
    async fn analysis_prepare_rejection_preserves_outputs_and_releases_only_same_unstarted_intent()
    -> AnalysisResult<()> {
        let root = tempfile::tempdir()?;
        let created = create_analysis(root.path(), "prepare rejection", AnalysisLanguage::Python)?;
        let id = created.manifest.analysis_id;
        let directory = analysis_dir(root.path(), &id)?;
        let mut manifest: AnalysisManifest = read_json(&directory.join(MANIFEST_FILE))?;
        manifest.input_paths = vec!["missing-input.csv".to_string()];
        write_json(&directory.join(MANIFEST_FILE), &manifest)?;
        fs::write(directory.join("result.json"), "中文🙂 original")?;
        let intent =
            begin_analysis_owner_intent(root.path(), &id, "original-generation".to_string())?;
        // A missing dataset is valid metadata; make the required script truly
        // unavailable after admission and before any execution/output clear.
        let script = directory.join(&manifest.script_path);
        let saved_script = directory.join("saved-script.py");
        fs::rename(&script, &saved_script)?;
        let started = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let manager = ToolManager::new();
        manager.register(Box::new(ScriptTool));
        let result = run_analysis_with_runtime(
            &manager,
            root.path(),
            &id,
            None,
            AnalysisExecutionContext {
                runtime: None,
                prepare_managed_runtime: false,
                product_data: None,
                owner: Some(AnalysisOwnerObservation {
                    intent: intent.clone(),
                    execution_started: started.clone(),
                    pending_settlement: Arc::new(std::sync::Mutex::new(None)),
                }),
            },
        )
        .await;
        assert!(result.is_err());
        assert!(!started.load(std::sync::atomic::Ordering::Acquire));
        assert_eq!(
            fs::read_to_string(directory.join("result.json"))?,
            "中文🙂 original"
        );
        let mut wrong = intent.clone();
        wrong.owner_id = "other-owner".to_string();
        assert!(reject_unstarted_analysis_owner(root.path(), &wrong).is_err());
        reject_unstarted_analysis_owner(root.path(), &intent)?;
        fs::rename(&saved_script, &script)?;
        let retry = begin_analysis_owner_intent(root.path(), &id, "next-generation".to_string())?;
        assert_ne!(retry.run_id, intent.run_id);
        reject_unstarted_analysis_owner(root.path(), &retry)?;
        Ok(())
    }

    #[tokio::test]
    async fn analysis_known_completion_retries_original_intent_cleanup_without_running_tool_again()
    -> AnalysisResult<()> {
        let root = tempfile::tempdir()?;
        let created = create_analysis(root.path(), "known completion", AnalysisLanguage::Python)?;
        let id = created.manifest.analysis_id;
        let intent =
            begin_analysis_owner_intent(root.path(), &id, "original-generation".to_string())?;
        let manager = ToolManager::new();
        manager.register(Box::new(ScriptTool));
        let completed = run_analysis_with_runtime(
            &manager,
            root.path(),
            &id,
            None,
            AnalysisExecutionContext {
                runtime: None,
                prepare_managed_runtime: false,
                product_data: None,
                owner: Some(AnalysisOwnerObservation {
                    intent: intent.clone(),
                    execution_started: Arc::new(std::sync::atomic::AtomicBool::new(false)),
                    pending_settlement: Arc::new(std::sync::Mutex::new(None)),
                }),
            },
        )
        .await?;
        assert_eq!(
            completed
                .last_run
                .as_ref()
                .map(|record| record.run_id.as_str()),
            Some(intent.run_id.as_str())
        );
        let directory = analysis_dir(root.path(), &id)?;
        let path = directory.join(OWNER_INTENT_FILE);
        let saved = directory.join("owner-intent-saved.json");
        fs::rename(&path, &saved)?;
        fs::create_dir(&path)?;
        assert!(acknowledge_analysis_owner_intent(root.path(), &intent).is_err());
        let record_before = fs::read(
            directory
                .join(RUNS_DIR)
                .join(format!("{}.json", intent.run_id)),
        )?;
        fs::remove_dir(&path)?;
        fs::rename(&saved, &path)?;
        require_analysis_owner_settled(root.path(), &id)?;
        require_analysis_owner_settled(root.path(), &id)?;
        assert!(!path.exists());
        assert_eq!(
            fs::read(
                directory
                    .join(RUNS_DIR)
                    .join(format!("{}.json", intent.run_id))
            )?,
            record_before
        );
        assert_eq!(
            load_analysis(root.path(), &id)?
                .last_run
                .as_ref()
                .map(|record| record.run_id.as_str()),
            Some(intent.run_id.as_str())
        );
        Ok(())
    }

    #[tokio::test]
    async fn completed_analysis_retries_archive_runs_and_latest_writes_without_reexecuting()
    -> AnalysisResult<()> {
        for phase in ["archive", "run-record", "latest-record"] {
            let root = tempfile::tempdir()?;
            let created = create_analysis(root.path(), phase, AnalysisLanguage::Python)?;
            let id = created.manifest.analysis_id;
            let directory = analysis_dir(root.path(), &id)?;
            let intent =
                begin_analysis_owner_intent(root.path(), &id, "original-generation".to_string())?;
            fs::create_dir_all(directory.join(RUNS_DIR))?;
            let blocked = match phase {
                "archive" => directory.join(RUNS_DIR).join(&intent.run_id),
                "run-record" => directory
                    .join(RUNS_DIR)
                    .join(format!("{}.json", intent.run_id)),
                _ => directory.join(LATEST_RUN_FILE),
            };
            if phase == "archive" {
                fs::write(&blocked, "block archive directory")?;
            } else {
                fs::create_dir(&blocked)?;
            }
            let calls = Arc::new(std::sync::atomic::AtomicUsize::new(0));
            let manager = ToolManager::new();
            manager.register(Box::new(CountedScriptTool(calls.clone())));
            let pending = Arc::new(std::sync::Mutex::new(None));
            let result = run_analysis_with_runtime(
                &manager,
                root.path(),
                &id,
                None,
                AnalysisExecutionContext {
                    runtime: None,
                    prepare_managed_runtime: false,
                    product_data: None,
                    owner: Some(AnalysisOwnerObservation {
                        intent: intent.clone(),
                        execution_started: Arc::new(std::sync::atomic::AtomicBool::new(false)),
                        pending_settlement: pending.clone(),
                    }),
                },
            )
            .await;
            assert!(
                result.is_err(),
                "{phase} fault did not reject its durable write"
            );
            assert_eq!(calls.load(std::sync::atomic::Ordering::SeqCst), 1);
            assert!(directory.join(OWNER_INTENT_FILE).is_file());
            let retained = pending
                .lock()
                .unwrap_or_else(|e| e.into_inner())
                .take()
                .ok_or_else(|| {
                    AnalysisError::Execution("original terminal write evidence missing".to_string())
                })?;
            if phase == "archive" {
                fs::remove_file(&blocked)?;
            } else {
                fs::remove_dir(&blocked)?;
            }
            if phase == "latest-record" {
                let original_output = fs::read(directory.join("result.json"))?;
                let mut replacement = intent.clone();
                replacement.owner_id = "replacement-owner".to_string();
                write_json(&directory.join(OWNER_INTENT_FILE), &replacement)?;
                fs::write(
                    directory.join(LATEST_RUN_FILE),
                    "replacement latest sentinel",
                )?;
                fs::write(directory.join("result.json"), "replacement output sentinel")?;
                assert!(matches!(
                    retry_analysis_settlement(&retained),
                    Err(AnalysisError::Conflict)
                ));
                assert_eq!(
                    fs::read_to_string(directory.join(LATEST_RUN_FILE))?,
                    "replacement latest sentinel"
                );
                assert_eq!(
                    fs::read_to_string(directory.join("result.json"))?,
                    "replacement output sentinel"
                );
                write_json(&directory.join(OWNER_INTENT_FILE), &intent)?;
                fs::remove_file(directory.join(LATEST_RUN_FILE))?;
                fs::write(directory.join("result.json"), original_output)?;
            }
            let completed = retry_analysis_settlement(&retained)?;
            acknowledge_analysis_owner_intent(root.path(), &intent)?;
            assert_eq!(
                completed.last_run.as_ref().map(|run| run.run_id.as_str()),
                Some(intent.run_id.as_str())
            );
            assert_eq!(calls.load(std::sync::atomic::Ordering::SeqCst), 1);
            assert!(!directory.join(OWNER_INTENT_FILE).exists());
        }
        Ok(())
    }

    #[test]
    fn analysis_terminal_classification_refuses_nonterminal_observation()
    -> Result<(), Box<dyn std::error::Error>> {
        let error = echo_agent::error::ReactError::ExecutionNotSettled {
            run_id: "original-run".to_string(),
            execution_id: Some("original-execution".to_string()),
        };
        assert!(
            matches!(super::terminal_from_react_error(&error), Err(super::AnalysisError::Observation { run_id, execution_id }) if run_id == "original-run" && execution_id.as_deref() == Some("original-execution"))
        );
        assert!(
            super::terminal_from_react_error(&echo_agent::error::ReactError::Other(
                "ordinary failure".to_string()
            ))
            .is_ok()
        );
        Ok(())
    }

    use super::*;
    use echo_agent::error::Result as AgentResult;
    use echo_agent::tools::{Tool, ToolResult};
    use futures::future::BoxFuture;

    struct ScriptTool;
    struct ArtifactFailureTool;
    struct CancellationAwareTool {
        started: Arc<tokio::sync::Notify>,
    }

    struct ProfileScriptTool {
        seen_profile: Arc<std::sync::Mutex<Option<String>>>,
    }

    struct CountedScriptTool(Arc<std::sync::atomic::AtomicUsize>);
    impl Tool for CountedScriptTool {
        fn name(&self) -> &str {
            "run_code"
        }
        fn description(&self) -> &str {
            "count original analysis execution"
        }
        fn parameters(&self) -> Value {
            ScriptTool.parameters()
        }
        fn execute_with_context<'a>(
            &'a self,
            parameters: ToolParameters,
            context: &'a ToolContext,
        ) -> BoxFuture<'a, AgentResult<ToolResult>> {
            self.0.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            ScriptTool.execute_with_context(parameters, context)
        }
    }

    impl Tool for ScriptTool {
        fn name(&self) -> &str {
            "run_code"
        }

        fn description(&self) -> &str {
            "test persisted script runner"
        }

        fn parameters(&self) -> Value {
            serde_json::json!({"type": "object"})
        }

        fn execute_with_context<'a>(
            &'a self,
            parameters: ToolParameters,
            context: &'a ToolContext,
        ) -> BoxFuture<'a, AgentResult<ToolResult>> {
            Box::pin(async move {
                let directory = context.working_dir.as_ref().ok_or_else(|| {
                    echo_agent::error::ReactError::Other("missing working directory".to_string())
                })?;
                let script = parameters
                    .get("script_path")
                    .and_then(Value::as_str)
                    .ok_or_else(|| {
                        echo_agent::error::ReactError::Other("missing script path".to_string())
                    })?;
                let execution_id = context.execution_id.as_deref().unwrap_or("missing");
                fs::write(
                    directory.join("result.json"),
                    format!("{{\"execution_id\":\"{execution_id}\"}}\n"),
                )?;
                fs::write(
                    directory.join("environment.json"),
                    "{\"python\": \"test\"}\n",
                )?;
                Ok(ToolResult::success(format!("ran {script}"))
                    .with_meta("exit_code", "0")
                    .with_meta("sandbox_type", "test"))
            })
        }
    }

    impl Tool for ArtifactFailureTool {
        fn name(&self) -> &str {
            "run_code"
        }

        fn description(&self) -> &str {
            "test artifact persistence failure"
        }

        fn parameters(&self) -> Value {
            serde_json::json!({"type": "object"})
        }

        fn execute_with_context<'a>(
            &'a self,
            _parameters: ToolParameters,
            context: &'a ToolContext,
        ) -> BoxFuture<'a, AgentResult<ToolResult>> {
            Box::pin(async move {
                let directory = context.working_dir.as_ref().ok_or_else(|| {
                    echo_agent::error::ReactError::Other("missing working directory".to_string())
                })?;
                let run_id = context.execution_id.as_deref().ok_or_else(|| {
                    echo_agent::error::ReactError::Other("missing execution id".to_string())
                })?;
                fs::write(directory.join("result.json"), "new output")?;
                fs::write(directory.join(RUNS_DIR).join(run_id), "blocks artifact dir")?;
                Ok(ToolResult::success(
                    "ran but artifact persistence will fail",
                ))
            })
        }
    }

    impl Tool for CancellationAwareTool {
        fn name(&self) -> &str {
            "run_code"
        }

        fn description(&self) -> &str {
            "test started analysis cancellation"
        }

        fn parameters(&self) -> Value {
            serde_json::json!({"type": "object"})
        }

        fn execute_with_context<'a>(
            &'a self,
            _parameters: ToolParameters,
            context: &'a ToolContext,
        ) -> BoxFuture<'a, AgentResult<ToolResult>> {
            Box::pin(async move {
                self.started.notify_one();
                let cancel = context.cancel.as_ref().ok_or_else(|| {
                    echo_agent::error::ReactError::Other(
                        "missing analysis cancellation token".to_string(),
                    )
                })?;
                cancel.cancelled().await;
                Err(echo_agent::error::ReactError::Sandbox(Box::new(
                    echo_agent::error::SandboxError::Cancelled(
                        "started analysis cancelled".to_string(),
                    ),
                )))
            })
        }
    }

    impl Tool for ProfileScriptTool {
        fn name(&self) -> &str {
            "run_code"
        }

        fn description(&self) -> &str {
            "test managed analysis script runner"
        }

        fn parameters(&self) -> Value {
            serde_json::json!({"type": "object"})
        }

        fn execute_with_context<'a>(
            &'a self,
            _parameters: ToolParameters,
            context: &'a ToolContext,
        ) -> BoxFuture<'a, AgentResult<ToolResult>> {
            Box::pin(async move {
                let directory = context.working_dir.as_ref().ok_or_else(|| {
                    echo_agent::error::ReactError::Other("missing working directory".to_string())
                })?;
                let profile_id = context
                    .script_execution_profile
                    .as_ref()
                    .map(|profile| profile.id.clone())
                    .ok_or_else(|| {
                        echo_agent::error::ReactError::Other(
                            "missing script execution profile".to_string(),
                        )
                    })?;
                *self
                    .seen_profile
                    .lock()
                    .unwrap_or_else(|poisoned| poisoned.into_inner()) = Some(profile_id);
                fs::write(directory.join("result.json"), "{\"status\":\"ok\"}\n")?;
                fs::write(
                    directory.join("environment.json"),
                    "{\"analysis.script\":\"managed\"}\n",
                )?;
                Ok(ToolResult::success("managed analysis completed")
                    .with_meta("exit_code", "0")
                    .with_meta("sandbox_type", "test"))
            })
        }
    }

    #[test]
    fn create_save_and_stale_detection_are_file_backed() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        fs::write(workspace.path().join("data.csv"), "value\n1\n")?;
        let created =
            create_analysis(workspace.path(), "Revenue Review", AnalysisLanguage::Python)?;
        assert!(created.stale);
        assert!(created.script.contains("result.json"));

        let saved = save_analysis(
            workspace.path(),
            &created.manifest.analysis_id,
            SaveAnalysisRequest {
                title: "Revenue Review".to_string(),
                script: "print('saved')\n".to_string(),
                expected_script_revision: created.script_revision,
                input_paths: vec!["data.csv".to_string()],
                parameters: serde_json::json!({"group": "region"}),
                random_seed: Some(7),
            },
        )?;
        assert_eq!(saved.manifest.input_paths, vec!["data.csv".to_string()]);
        assert_eq!(saved.manifest.random_seed, Some(7));
        assert!(saved.stale);
        Ok(())
    }

    #[test]
    fn r_starter_requires_only_the_base_runtime() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "R Review", AnalysisLanguage::R)?;
        assert!(created.script.contains("R.version"));
        assert!(!created.script.contains("jsonlite"));
        Ok(())
    }

    #[test]
    fn unicode_titles_and_input_paths_remain_valid() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        fs::write(workspace.path().join("数据📈.csv"), "数值\n1\n")?;
        let created =
            create_analysis(workspace.path(), "医学数据分析📊", AnalysisLanguage::Python)?;
        let saved = save_analysis(
            workspace.path(),
            &created.manifest.analysis_id,
            SaveAnalysisRequest {
                title: "医学数据分析📊".to_string(),
                script: created.script,
                expected_script_revision: created.script_revision,
                input_paths: vec!["数据📈.csv".to_string()],
                parameters: Value::Null,
                random_seed: None,
            },
        )?;
        assert_eq!(saved.manifest.title, "医学数据分析📊");
        assert_eq!(saved.manifest.input_paths, vec!["数据📈.csv".to_string()]);
        Ok(())
    }

    #[tokio::test]
    async fn run_records_hashes_outputs_environment_and_staleness() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        fs::write(workspace.path().join("data.csv"), "value\n1\n")?;
        let created = create_analysis(workspace.path(), "Model", AnalysisLanguage::Python)?;
        let saved = save_analysis(
            workspace.path(),
            &created.manifest.analysis_id,
            SaveAnalysisRequest {
                title: "Model".to_string(),
                script: "print('model')\n".to_string(),
                expected_script_revision: created.script_revision,
                input_paths: vec!["data.csv".to_string()],
                parameters: Value::Object(serde_json::Map::new()),
                random_seed: Some(11),
            },
        )?;
        let manager = ToolManager::new();
        manager.register(Box::new(ScriptTool));
        let completed = run_analysis(
            &manager,
            workspace.path(),
            &saved.manifest.analysis_id,
            None,
        )
        .await?;
        assert!(!completed.stale);
        let run = completed
            .last_run
            .as_ref()
            .ok_or_else(|| AnalysisError::Invalid("missing run record".to_string()))?;
        assert_eq!(run.status, AnalysisRunStatus::Succeeded);
        assert_eq!(
            run.environment.get("python").map(String::as_str),
            Some("test")
        );
        assert!(
            run.outputs
                .iter()
                .any(|output| output.path.ends_with("result.json"))
        );
        assert!(run.script.sha256.is_some());
        assert!(run.inputs.iter().all(|input| input.sha256.is_some()));
        assert_eq!(run.random_seed, Some(11));
        assert_eq!(run.parameters, Value::Object(serde_json::Map::new()));

        let parameter_changed = save_analysis(
            workspace.path(),
            &saved.manifest.analysis_id,
            SaveAnalysisRequest {
                title: "Model".to_string(),
                script: saved.script.clone(),
                expected_script_revision: saved.script_revision.clone(),
                input_paths: vec!["data.csv".to_string()],
                parameters: serde_json::json!({"group": "region"}),
                random_seed: Some(11),
            },
        )?;
        assert!(parameter_changed.stale);
        assert!(
            parameter_changed
                .stale_reasons
                .iter()
                .any(|reason| reason.contains("parameters changed"))
        );

        fs::write(workspace.path().join("data.csv"), "value\n2\n")?;
        let changed = load_analysis(workspace.path(), &saved.manifest.analysis_id)?;
        assert!(changed.stale);
        assert!(
            changed
                .stale_reasons
                .iter()
                .any(|reason| reason.contains("input changed"))
        );
        Ok(())
    }

    #[tokio::test]
    async fn cancellation_before_tool_start_is_durably_cancelled() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "Before Start", AnalysisLanguage::R)?;
        let manager = ToolManager::new();
        manager.register(Box::new(ScriptTool));
        let cancel = Arc::new(CancellationToken::new());
        cancel.cancel();

        let completed = run_analysis(
            &manager,
            workspace.path(),
            &created.manifest.analysis_id,
            Some(cancel),
        )
        .await?;
        assert_eq!(
            completed.last_run.as_ref().map(|run| run.status),
            Some(AnalysisRunStatus::Cancelled)
        );
        Ok(())
    }

    #[tokio::test]
    async fn cancellation_after_tool_start_is_durably_cancelled() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "Started", AnalysisLanguage::R)?;
        let started = Arc::new(tokio::sync::Notify::new());
        let manager = Arc::new(ToolManager::new());
        manager.register(Box::new(CancellationAwareTool {
            started: Arc::clone(&started),
        }));
        let cancel = Arc::new(CancellationToken::new());
        let manager_for_run = Arc::clone(&manager);
        let cancel_for_run = Arc::clone(&cancel);
        let root = workspace.path().to_path_buf();
        let analysis_id = created.manifest.analysis_id.clone();
        let operation = tokio::spawn(async move {
            run_analysis(
                manager_for_run.as_ref(),
                &root,
                &analysis_id,
                Some(cancel_for_run),
            )
            .await
        });
        started.notified().await;
        cancel.cancel();
        let completed = operation
            .await
            .map_err(|error| AnalysisError::Execution(error.to_string()))??;
        assert_eq!(
            completed.last_run.as_ref().map(|run| run.status),
            Some(AnalysisRunStatus::Cancelled)
        );
        Ok(())
    }

    #[tokio::test]
    async fn runtime_prepare_cancellation_creates_a_durable_cancelled_record() -> AnalysisResult<()>
    {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "Prepare", AnalysisLanguage::Python)?;
        let manager = ToolManager::new();
        manager.register(Box::new(ScriptTool));
        let cancel = Arc::new(CancellationToken::new());
        cancel.cancel();

        let completed = run_analysis_with_runtime(
            &manager,
            workspace.path(),
            &created.manifest.analysis_id,
            Some(cancel),
            AnalysisExecutionContext {
                runtime: None,
                prepare_managed_runtime: true,
                product_data: None,
                owner: None,
            },
        )
        .await?;
        let run = completed
            .last_run
            .as_ref()
            .ok_or_else(|| AnalysisError::Invalid("missing cancelled run record".to_string()))?;
        assert_eq!(run.status, AnalysisRunStatus::Cancelled);
        assert!(
            run.error
                .as_deref()
                .is_some_and(|error| error.contains("cancelled"))
        );
        Ok(())
    }

    #[tokio::test]
    async fn managed_runtime_profile_reaches_run_code_and_run_record() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "Managed", AnalysisLanguage::Python)?;
        let seen_profile = Arc::new(std::sync::Mutex::new(None));
        let manager = ToolManager::new();
        manager.register(Box::new(ProfileScriptTool {
            seen_profile: seen_profile.clone(),
        }));
        let prepared = crate::analysis_runtime::PreparedAnalyticsRuntime {
            profile: Arc::new(echo_agent::tools::ScriptExecutionProfile::new(
                "eko-analytics:test-lock",
                "python",
                "/tmp/eko-analytics/.venv/bin/python",
            )),
            environment: BTreeMap::from([
                (
                    "analytics.profile".to_string(),
                    "eko-analytics:test-lock".to_string(),
                ),
                ("python".to_string(), "3.12.4".to_string()),
                ("python.package.pandas".to_string(), "3.0.5".to_string()),
            ]),
        };

        let completed = run_analysis_with_runtime(
            &manager,
            workspace.path(),
            &created.manifest.analysis_id,
            None,
            AnalysisExecutionContext {
                runtime: Some(&prepared),
                prepare_managed_runtime: false,
                product_data: None,
                owner: None,
            },
        )
        .await?;
        let run = completed
            .last_run
            .ok_or_else(|| AnalysisError::Invalid("missing managed run".to_string()))?;
        assert_eq!(
            seen_profile
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner())
                .as_deref(),
            Some("eko-analytics:test-lock")
        );
        assert_eq!(
            run.runtime_profile.as_deref(),
            Some("eko-analytics:test-lock")
        );
        assert_eq!(
            run.environment.get("python").map(String::as_str),
            Some("3.12.4")
        );
        assert_eq!(
            run.environment
                .get("python.package.pandas")
                .map(String::as_str),
            Some("3.0.5")
        );
        assert_eq!(
            run.environment.get("analysis.script").map(String::as_str),
            Some("managed")
        );
        Ok(())
    }

    #[tokio::test]
    async fn failed_rerun_does_not_inherit_previous_outputs() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "Refresh", AnalysisLanguage::Python)?;
        let successful_manager = ToolManager::new();
        successful_manager.register(Box::new(ScriptTool));
        let completed = run_analysis(
            &successful_manager,
            workspace.path(),
            &created.manifest.analysis_id,
            None,
        )
        .await?;
        assert!(!completed.outputs.is_empty());

        let failed = run_analysis(
            &ToolManager::new(),
            workspace.path(),
            &created.manifest.analysis_id,
            None,
        )
        .await?;
        assert_eq!(
            failed.last_run.as_ref().map(|run| run.status),
            Some(AnalysisRunStatus::Failed)
        );
        assert!(failed.outputs.is_empty());
        assert!(
            failed
                .last_run
                .as_ref()
                .is_some_and(|run| run.environment.is_empty())
        );
        Ok(())
    }

    #[tokio::test]
    async fn rerun_preserves_prior_run_artifacts() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "History", AnalysisLanguage::Python)?;
        let manager = ToolManager::new();
        manager.register(Box::new(ScriptTool));

        let first = run_analysis(
            &manager,
            workspace.path(),
            &created.manifest.analysis_id,
            None,
        )
        .await?;
        let first_run = first
            .last_run
            .ok_or_else(|| AnalysisError::Invalid("missing first run".to_string()))?;
        let first_result = first_run
            .outputs
            .iter()
            .find(|artifact| artifact.path.ends_with("result.json"))
            .ok_or_else(|| AnalysisError::Invalid("missing first result artifact".to_string()))?;
        let first_path = PathBuf::from(&first_result.absolute_path);
        let first_hash = first_result.sha256.clone();
        assert!(first_result.path.contains(&first_run.run_id));

        let second = run_analysis(
            &manager,
            workspace.path(),
            &created.manifest.analysis_id,
            None,
        )
        .await?;
        let second_run = second
            .last_run
            .ok_or_else(|| AnalysisError::Invalid("missing second run".to_string()))?;
        let second_result = second_run
            .outputs
            .iter()
            .find(|artifact| artifact.path.ends_with("result.json"))
            .ok_or_else(|| AnalysisError::Invalid("missing second result artifact".to_string()))?;

        assert_ne!(first_run.run_id, second_run.run_id);
        assert_ne!(first_result.path, second_result.path);
        assert_ne!(first_result.sha256, second_result.sha256);
        assert!(first_path.is_file());
        assert_eq!(hash_file(&first_path)?, first_hash);
        Ok(())
    }

    #[tokio::test]
    async fn artifact_failure_does_not_publish_a_new_run_record() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "Publish", AnalysisLanguage::Python)?;
        let successful_manager = ToolManager::new();
        successful_manager.register(Box::new(ScriptTool));
        let completed = run_analysis(
            &successful_manager,
            workspace.path(),
            &created.manifest.analysis_id,
            None,
        )
        .await?;
        let previous_run_id = completed
            .last_run
            .as_ref()
            .map(|run| run.run_id.clone())
            .ok_or_else(|| AnalysisError::Invalid("missing previous run".to_string()))?;

        let failed_manager = ToolManager::new();
        failed_manager.register(Box::new(ArtifactFailureTool));
        let result = run_analysis(
            &failed_manager,
            workspace.path(),
            &created.manifest.analysis_id,
            None,
        )
        .await;
        assert!(matches!(result, Err(AnalysisError::Io(_))));

        let reloaded = load_analysis(workspace.path(), &created.manifest.analysis_id)?;
        assert_eq!(
            reloaded.last_run.map(|run| run.run_id),
            Some(previous_run_id)
        );
        Ok(())
    }

    #[test]
    fn save_rejects_stale_revision_and_parent_inputs() -> AnalysisResult<()> {
        let workspace = tempfile::tempdir()?;
        let created = create_analysis(workspace.path(), "Guard", AnalysisLanguage::Python)?;
        let conflict = save_analysis(
            workspace.path(),
            &created.manifest.analysis_id,
            SaveAnalysisRequest {
                title: "Guard".to_string(),
                script: "print(1)\n".to_string(),
                expected_script_revision: "old".to_string(),
                input_paths: Vec::new(),
                parameters: Value::Null,
                random_seed: None,
            },
        );
        assert!(matches!(conflict, Err(AnalysisError::Conflict)));

        let invalid_input = save_analysis(
            workspace.path(),
            &created.manifest.analysis_id,
            SaveAnalysisRequest {
                title: "Guard".to_string(),
                script: created.script,
                expected_script_revision: created.script_revision,
                input_paths: vec!["../secret.csv".to_string()],
                parameters: Value::Null,
                random_seed: None,
            },
        );
        assert!(matches!(invalid_input, Err(AnalysisError::Invalid(_))));
        Ok(())
    }
}
