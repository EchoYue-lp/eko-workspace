//! Background task trigger adapter backed exclusively by EKO TaskRuntime.
//!
//! CLI, Tauri, cron-style background work and structured pipelines all create
//! an EKO TaskRun and use the same product persistence, recovery, and terminal
//! contracts. DAG execution itself is delegated to the framework's generic
//! runtime executor.

use std::sync::Arc;

use async_trait::async_trait;
use echo_agent::agent::CancellationToken;
use echo_agent::tasks::progress::TaskProgress;

use super::background::BackgroundTaskKind;
use super::task_runtime::{
    AttendedMode, DomainProfile, ExecuteTaskTool, ExecutionMode, MemoryPolicy, PlanRevision,
    PlanTask, RecoveryBlocker, RecoveryDecision, TaskPlan, TaskRetryPreparation, TaskRun,
    TaskRunBootOutcome, TaskRunBootReconciler, TaskRunStatus, TaskRuntimeOperation,
    TaskRuntimeStore, TodoItem, TodoStatus, UnattendedWriteMode,
};
use crate::agent_handle::AgentHandle;
#[cfg(test)]
use crate::tasks::task_runtime::BootAutoResumeDecision;

#[derive(Debug, Clone)]
pub struct BackgroundTaskServiceConfig {
    pub max_concurrent: usize,
    pub reserve_foreground_agents: usize,
    pub composite_parallelism: usize,
}

impl Default for BackgroundTaskServiceConfig {
    fn default() -> Self {
        Self {
            max_concurrent: 1,
            reserve_foreground_agents: 0,
            composite_parallelism: 1,
        }
    }
}

struct PromptRunRequest<'a> {
    prompt: &'a str,
    description: &'a str,
    source: &'a str,
    task_kind: &'a str,
    priority: u8,
    domain_profile: DomainProfile,
}

#[derive(Debug, Clone, serde::Serialize)]
pub struct UnifiedTaskInfo {
    pub id: String,
    pub description: String,
    pub status: String,
    pub created_at: String,
    pub updated_at: String,
    pub result: Option<String>,
    pub error: Option<String>,
    pub kind: Option<String>,
    pub source: &'static str,
    pub priority: u8,
}

#[async_trait]
trait TaskAgentProvider: Send + Sync {
    async fn acquire_for_task(
        &self,
        task_key: &str,
        domain_binding: Option<&crate::domain_plugin::DomainBinding>,
        run_projection: Option<
            Arc<super::task_runtime::compact_context::TaskRuntimeProjectionRegistration>,
        >,
    ) -> Result<TaskAgentLease, echo_agent::error::ReactError>;
}

struct TaskAgentLease {
    agent: AgentHandle,
    pool_receipt: Option<crate::agent_pool::OwnedRunPoolReceipt>,
    invocation_resources: Vec<echo_agent::tools::InvocationResourceGuard>,
}

impl TaskAgentLease {
    fn agent(&self) -> AgentHandle {
        self.agent.clone()
    }
}

impl super::task_runtime::store::RunDriverExecutionReceipt for TaskAgentLease {
    fn observe_unsettled(&self, run_id: &str, execution_id: Option<&str>) {
        if let Some(receipt) = self.pool_receipt.as_ref() {
            super::task_runtime::store::RunDriverExecutionReceipt::observe_unsettled(
                receipt,
                run_id,
                execution_id,
            );
        }
    }
    fn release(mut self: Box<Self>) -> futures::future::BoxFuture<'static, ()> {
        Box::pin(async move {
            if let Some(receipt) = self.pool_receipt.take() {
                super::task_runtime::store::RunDriverExecutionReceipt::release(Box::new(receipt))
                    .await;
            }
        })
    }
}

struct SingleAgentTaskProvider {
    agent: AgentHandle,
}

#[async_trait]
impl TaskAgentProvider for SingleAgentTaskProvider {
    async fn acquire_for_task(
        &self,
        _task_key: &str,
        domain_binding: Option<&crate::domain_plugin::DomainBinding>,
        _run_projection: Option<
            Arc<super::task_runtime::compact_context::TaskRuntimeProjectionRegistration>,
        >,
    ) -> Result<TaskAgentLease, echo_agent::error::ReactError> {
        if domain_binding.is_some() {
            return Err(echo_agent::error::ReactError::Other(
                "domain execution requires the original pooled plugin generation".to_string(),
            ));
        }
        Ok(TaskAgentLease {
            agent: self.agent.clone(),
            pool_receipt: None,
            invocation_resources: Vec::new(),
        })
    }
}

struct PoolTaskAgentProvider {
    pool: Arc<crate::agent_pool::AgentPool>,
}

#[async_trait]
impl TaskAgentProvider for PoolTaskAgentProvider {
    async fn acquire_for_task(
        &self,
        task_key: &str,
        domain_binding: Option<&crate::domain_plugin::DomainBinding>,
        run_projection: Option<
            Arc<super::task_runtime::compact_context::TaskRuntimeProjectionRegistration>,
        >,
    ) -> Result<TaskAgentLease, echo_agent::error::ReactError> {
        let key = format!("__task__:{task_key}");
        let pool_execution = self.pool.acquire(&key).await.map_err(|error| {
            echo_agent::error::ReactError::Other(format!("Failed to acquire task agent: {error}"))
        })?;
        if let Some(binding) = domain_binding {
            self.pool
                .verify_domain_binding(&pool_execution, binding)
                .await
                .map_err(echo_agent::error::ReactError::Other)?;
        }
        let invocation_resources = match domain_binding {
            Some(binding) => vec![
                pool_execution
                    .domain_resource_guard(task_key, binding, run_projection)
                    .map_err(echo_agent::error::ReactError::Other)?,
            ],
            None => Vec::new(),
        };
        let agent = pool_execution.agent();
        let pool_receipt = self.pool.retain_for_supervised_run(key, pool_execution);
        Ok(TaskAgentLease {
            agent,
            pool_receipt: Some(pool_receipt),
            invocation_resources,
        })
    }
}

pub struct BackgroundTaskService {
    cancel: CancellationToken,
    config: BackgroundTaskServiceConfig,
    task_runtime_store: Arc<TaskRuntimeStore>,
    agent_provider: Arc<dyn TaskAgentProvider>,
    run_semaphore: Arc<tokio::sync::Semaphore>,
    review_integration: Option<Arc<crate::evolution::ReviewIntegration>>,
    boot_reconciler: Arc<TaskRunBootReconciler>,
}

impl BackgroundTaskService {
    pub async fn new(
        agent: AgentHandle,
        cancel: CancellationToken,
        task_runtime_store: Option<Arc<TaskRuntimeStore>>,
    ) -> anyhow::Result<Self> {
        Self::with_agent_provider(
            Arc::new(SingleAgentTaskProvider { agent }),
            BackgroundTaskServiceConfig::default(),
            cancel,
            task_runtime_store,
        )
    }

    pub async fn with_pool(
        pool: Arc<crate::agent_pool::AgentPool>,
        cancel: CancellationToken,
        task_runtime_store: Option<Arc<TaskRuntimeStore>>,
    ) -> anyhow::Result<Self> {
        let config = BackgroundTaskServiceConfig {
            max_concurrent: pool.background_task_concurrency(),
            reserve_foreground_agents: pool.foreground_agent_reserve(),
            composite_parallelism: pool.composite_parallelism(),
        };
        Self::with_agent_provider(
            Arc::new(PoolTaskAgentProvider { pool }),
            config,
            cancel,
            task_runtime_store,
        )
    }

    fn with_agent_provider(
        agent_provider: Arc<dyn TaskAgentProvider>,
        config: BackgroundTaskServiceConfig,
        cancel: CancellationToken,
        task_runtime_store: Option<Arc<TaskRuntimeStore>>,
    ) -> anyhow::Result<Self> {
        let task_runtime_store = task_runtime_store
            .ok_or_else(|| anyhow::anyhow!("TaskRuntimeStore is required for background tasks"))?;
        let boot_reconciler = TaskRunBootReconciler::for_store(&task_runtime_store);
        Ok(Self {
            cancel,
            run_semaphore: Arc::new(tokio::sync::Semaphore::new(config.max_concurrent.max(1))),
            config,
            task_runtime_store,
            agent_provider,
            review_integration: None,
            boot_reconciler,
        })
    }

    pub fn with_review_integration(
        mut self,
        review_integration: Option<Arc<crate::evolution::ReviewIntegration>>,
    ) -> Self {
        self.review_integration = review_integration;
        self
    }

    pub async fn submit(
        &self,
        kind: BackgroundTaskKind,
        description: &str,
        submitted_via: Option<String>,
    ) -> anyhow::Result<String> {
        self.submit_with_options(kind, description, submitted_via, None)
            .await
    }

    pub async fn submit_with_options(
        &self,
        kind: BackgroundTaskKind,
        description: &str,
        submitted_via: Option<String>,
        priority: Option<u8>,
    ) -> anyhow::Result<String> {
        let domain_profile = kind.domain_profile();
        let prompt = kind.to_prompt();
        let task_kind = kind.tag();
        let source = submitted_via.unwrap_or_else(|| "background".to_string());
        self.submit_prompt_run(PromptRunRequest {
            prompt: &prompt,
            description,
            source: &source,
            task_kind: &task_kind,
            priority: priority.unwrap_or(5),
            domain_profile,
        })
        .await
    }

    pub async fn submit_run(
        &self,
        prompt: &str,
        description: &str,
        source_kind: &str,
        source_id: &str,
    ) -> anyhow::Result<String> {
        let task_kind = format!("bg:kind:{source_kind}_agent_chat");
        self.submit_prompt_run(PromptRunRequest {
            prompt,
            description,
            source: source_id,
            task_kind: &task_kind,
            priority: 5,
            domain_profile: DomainProfile::General,
        })
        .await
    }

    async fn submit_prompt_run(&self, request: PromptRunRequest<'_>) -> anyhow::Result<String> {
        let run_id = uuid::Uuid::new_v4().to_string();
        let cancel = self.cancel.child_token();
        let admission = self
            .task_runtime_store
            .reserve_run_driver_admission(run_id.clone(), cancel.clone())?;
        let generation_lease = self
            .task_runtime_store
            .lease_active_workspace_generation()?;
        let registration = self
            .task_runtime_store
            .register_observed_run_driver::<()>(admission, generation_lease)?;
        let conversation_id = format!("background:{}:{}", request.source, uuid::Uuid::new_v4());
        let goal = if request.description.trim().is_empty() {
            request.prompt
        } else {
            request.description
        };
        let preparation_run_id = run_id.clone();
        let preparation_conversation_id = conversation_id.clone();
        let preparation_goal = goal.to_string();
        let preparation_kind = request.task_kind.to_string();
        let preparation_source = request.source.to_string();
        let preparation_prompt = request.prompt.to_string();
        let preparation_domain_profile = request.domain_profile;
        let preparation_priority = request.priority;
        let preparation_store = self.task_runtime_store.clone();
        let registration = TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_owned("prepare background TaskRun", move || {
                let mut registration = registration;
                registration.mark_preparation_started();
                if let Err(error) = preparation_store.create_run_for_active_workspace_with_profile(
                    &preparation_run_id,
                    &preparation_conversation_id,
                    "",
                    preparation_domain_profile,
                    &preparation_goal,
                    &preparation_kind,
                    AttendedMode::Unattended,
                    super::task_runtime::TaskRunExecutionProfile::orchestrated(
                        super::task_runtime::RunPlanPolicy::AllowDirect,
                    ),
                ) {
                    registration.fail_preparation(error.to_string());
                    return Err(error);
                }
                if let Err(error) = preparation_store.configure_run_continuation(
                    &preparation_run_id,
                    true,
                    true,
                    None,
                    None,
                ) {
                    registration.fail_preparation(error.to_string());
                    return Err(error);
                }
                if let Err(error) = preparation_store.record_trigger_metadata(
                    &preparation_run_id,
                    &preparation_source,
                    &preparation_kind,
                    &preparation_prompt,
                    preparation_priority,
                ) {
                    registration.fail_preparation(error.to_string());
                    return Err(error);
                }
                Ok(registration)
            })
            .await?;
        self.start_run_driver(
            run_id.clone(),
            request.prompt.to_string(),
            registration,
            cancel,
        )?;
        Ok(run_id)
    }

    pub async fn submit_dag(
        &self,
        plan_tasks: Vec<PlanTask>,
        description: &str,
        source_kind: &str,
        source_id: &str,
    ) -> anyhow::Result<String> {
        let run_id = uuid::Uuid::new_v4().to_string();
        let cancel = self.cancel.child_token();
        let admission = self
            .task_runtime_store
            .reserve_run_driver_admission(run_id.clone(), cancel.clone())?;
        let generation_lease = self
            .task_runtime_store
            .lease_active_workspace_generation()?;
        let registration = self
            .task_runtime_store
            .register_observed_run_driver::<()>(admission, generation_lease)?;
        let conversation_id = format!("background:{source_id}:{}", uuid::Uuid::new_v4());
        let goal = if description.trim().is_empty() {
            "composite"
        } else {
            description
        };
        let task_kind = format!("bg:kind:{source_kind}_composite");
        let preparation_store = self.task_runtime_store.clone();
        let preparation_run_id = run_id.clone();
        let preparation_conversation_id = conversation_id.clone();
        let preparation_goal = goal.to_string();
        let preparation_kind = task_kind.clone();
        let (registration, run) = TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_owned("prepare background TaskRun DAG", move || {
                let mut registration = registration;
                registration.mark_preparation_started();
                match preparation_store.prepare_run_for_active_workspace(
                    &preparation_run_id,
                    &preparation_conversation_id,
                    "",
                    DomainProfile::General,
                    &preparation_goal,
                    &preparation_kind,
                    AttendedMode::Unattended,
                ) {
                    Ok(run) => Ok((registration, run)),
                    Err(error) => {
                        registration.reject(error.to_string());
                        Err(error)
                    }
                }
            })
            .await?;
        if let Err(error) = super::task_runtime::revisioned_runtime::publish_task_plan(
            self.task_runtime_store.clone(),
            run,
            super::task_runtime::store::InitialRunTriggerMetadata {
                source: source_id.to_string(),
                kind: task_kind.clone(),
                prompt: goal.to_string(),
                priority: 5,
            },
            Some((true, true, None, None)),
            TaskPlan {
                domain_binding: None,
                plan_id: uuid::Uuid::new_v4().to_string(),
                run_id: run_id.clone(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: super::task_runtime::task_goal_sha256(goal),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::default(),
                tasks: plan_tasks,
            },
        )
        .await
        {
            registration.reject(error.to_string());
            return Err(error.into());
        }
        self.start_run_driver(run_id.clone(), goal.to_string(), registration, cancel)?;
        Ok(run_id)
    }

    fn start_run_driver(
        &self,
        run_id: String,
        prompt: String,
        registration: super::task_runtime::store::RegisteredRunDriver<
            (),
            super::task_runtime::store::RunDriverFailure,
        >,
        cancel: echo_agent::agent::CancellationToken,
    ) -> anyhow::Result<()> {
        let store = self.task_runtime_store.clone();
        let agent_provider = self.agent_provider.clone();
        let review_integration = self.review_integration.clone();
        let run_semaphore = self.run_semaphore.clone();
        let result_waiter = registration.start(move |receipt_owner| {
            drive_background_run(
                store,
                agent_provider,
                review_integration,
                run_semaphore,
                run_id,
                prompt,
                cancel,
                receipt_owner,
            )
        });
        drop(result_waiter);
        Ok(())
    }

    pub async fn cancel(&self, id: &str) -> bool {
        let run_id = id.to_string();
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("cancel background TaskRun", move |store| {
                store.request_cancel(&run_id)
            })
            .await
            .is_ok_and(|cancelled| cancelled)
    }

    pub async fn pause(&self, id: &str) -> anyhow::Result<bool> {
        let run_id = id.to_string();
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("pause background TaskRun", move |store| {
                store.request_pause(&run_id)
            })
            .await
            .map_err(Into::into)
    }

    pub async fn resume(&self, id: &str) -> anyhow::Result<()> {
        let cancel = self.cancel.child_token();
        let admission = self
            .task_runtime_store
            .reserve_run_driver_admission(id.to_string(), cancel.clone())?;
        let generation_lease = self
            .task_runtime_store
            .lease_active_workspace_generation()?;
        let registration = self
            .task_runtime_store
            .register_observed_run_driver::<()>(admission, generation_lease)?;
        let run_id = id.to_string();
        let store = self.task_runtime_store.clone();
        let agent_provider = self.agent_provider.clone();
        let review_integration = self.review_integration.clone();
        let run_semaphore = self.run_semaphore.clone();
        TaskRuntimeOperation::new(store.clone())
            .run_owned("prepare exact background resume", move || {
                let mut registration = registration;
                let snapshot = store
                    .get_run_state(&run_id)?
                    .ok_or_else(|| super::task_runtime::StoreError::RunNotFound(run_id.clone()))?;
                if !snapshot.run.conversation_id.starts_with("background:") {
                    let error = super::task_runtime::StoreError::InvalidPlan(format!(
                        "task run is not owned by the background service: {run_id}"
                    ));
                    registration.reject(error.to_string());
                    return Err(error);
                }
                let metadata = trigger_metadata(&store, &run_id);
                let prompt = metadata.prompt.unwrap_or_else(|| snapshot.run.goal.clone());
                let expected =
                    crate::tasks::task_runtime::TaskRunResumeIdentity::capture(&snapshot);
                if let Err(error) = store.resume_task_run_expected(&expected) {
                    let detail = error.to_string();
                    if matches!(
                        error,
                        super::task_runtime::StoreError::ResumeOutcomeUnknown { .. }
                    ) {
                        registration.fail_preparation(detail);
                    } else {
                        registration.reject(detail);
                    }
                    return Err(error);
                }
                registration.mark_preparation_started();
                let result_waiter = registration.start(move |receipt_owner| {
                    drive_background_run(
                        store,
                        agent_provider,
                        review_integration,
                        run_semaphore,
                        run_id,
                        prompt,
                        cancel,
                        receipt_owner,
                    )
                });
                drop(result_waiter);
                Ok(())
            })
            .await?;
        Ok(())
    }

    pub async fn recovery_blockers(&self, id: &str) -> anyhow::Result<Vec<RecoveryBlocker>> {
        let run_id = id.to_string();
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("load background recovery blockers", move |store| {
                store.list_recovery_blockers(&run_id)
            })
            .await
            .map_err(Into::into)
    }

    pub async fn resolve_recovery_task(
        &self,
        id: &str,
        task_id: &str,
        decision: RecoveryDecision,
    ) -> anyhow::Result<()> {
        let run_id = id.to_string();
        let task_id = task_id.to_string();
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("resolve background recovery task", move |store| {
                store.resolve_recovery_task(&run_id, &task_id, decision)
            })
            .await
            .map_err(Into::into)
    }

    /// Atomically retry a Blocked/Failed task on a Paused/Failed run. Mirrors
    /// the Tauri `retry_blocked_task` command and the GUI retry button so
    /// CLI/TUI users get the same acceptance-retry semantics.
    pub async fn retry_blocked_task(
        &self,
        run_id: &str,
        task_id: &str,
    ) -> anyhow::Result<TaskRetryPreparation> {
        let cancel = self.cancel.child_token();
        let store = self.task_runtime_store.clone();
        let preflight_store = store.clone();
        let preflight_run_id = run_id.to_string();
        let agent_provider = self.agent_provider.clone();
        let review_integration = self.review_integration.clone();
        let run_semaphore = self.run_semaphore.clone();
        let driver_store = store.clone();
        let driver_run_id = run_id.to_string();
        let driver_cancel = cancel.clone();
        let (preparation, result_waiter) = store
            .spawn_supervised_task_retry_async(
                run_id.to_string(),
                task_id.to_string(),
                cancel,
                move || {
                    let run = preflight_store.get_run(&preflight_run_id)?.ok_or_else(|| {
                        super::task_runtime::StoreError::RunNotFound(preflight_run_id.clone())
                    })?;
                    if !run.conversation_id.starts_with("background:") {
                        return Err(super::task_runtime::StoreError::InvalidPlan(format!(
                            "task run is not owned by the background service: {preflight_run_id}"
                        )));
                    }
                    let metadata = trigger_metadata(&preflight_store, &preflight_run_id);
                    Ok(metadata.prompt.unwrap_or(run.goal))
                },
                move |prompt, receipt_owner| {
                    drive_background_run(
                        driver_store,
                        agent_provider,
                        review_integration,
                        run_semaphore,
                        driver_run_id,
                        prompt,
                        driver_cancel,
                        receipt_owner,
                    )
                },
            )
            .await?;
        drop(result_waiter);
        Ok(preparation)
    }

    pub async fn list_unified(&self, status_filter: Option<&str>) -> Vec<UnifiedTaskInfo> {
        let status_filter = status_filter.map(str::to_string);
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("list background TaskRuns", move |store| {
                store.list_runs_in(&all_run_statuses()).map(|runs| {
                    runs.into_iter()
                        .filter(|run| run.conversation_id.starts_with("background:"))
                        .map(|run| run_to_unified(&store, &run))
                        .filter(|task| {
                            status_filter
                                .as_deref()
                                .is_none_or(|status| task.status == status)
                        })
                        .collect()
                })
            })
            .await
            .unwrap_or_default()
    }

    pub async fn get_unified(&self, id: &str) -> Option<UnifiedTaskInfo> {
        let run_id = id.to_string();
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("load background TaskRun", move |store| {
                store.get_run(&run_id).map(|run| {
                    run.filter(|run| run.conversation_id.starts_with("background:"))
                        .map(|run| run_to_unified(&store, &run))
                })
            })
            .await
            .ok()
            .flatten()
    }

    pub fn workspace_id(&self) -> String {
        self.task_runtime_store.active_workspace_id()
    }

    pub async fn get_task_plan(&self, run_id: &str) -> anyhow::Result<Option<PlanRevision>> {
        let run_id = run_id.to_string();
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("load background TaskRun plan", move |store| {
                store.get_plan_revision(&run_id)
            })
            .await
            .map_err(Into::into)
    }

    pub async fn list_task_todos(&self, run_id: &str) -> anyhow::Result<Vec<TodoItem>> {
        let run_id = run_id.to_string();
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("list background TaskRun todos", move |store| {
                store.list_todos(&run_id)
            })
            .await
            .map_err(Into::into)
    }

    pub async fn resume_pending(&self) -> anyhow::Result<usize> {
        self.boot_reconciler
            .recover_once()
            .await
            .map_err(anyhow::Error::msg)?;
        let mut runs = TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("load pending background TaskRuns", move |store| {
                store
                    .list_runs_in(&[TaskRunStatus::Pending, TaskRunStatus::Paused])
                    .map(|runs| {
                        runs.into_iter()
                            .filter(|run| run.conversation_id.starts_with("background:"))
                            .map(|run| {
                                let metadata = trigger_metadata(&store, &run.run_id);
                                (run, metadata)
                            })
                            .collect::<Vec<_>>()
                    })
            })
            .await?;
        runs.sort_by_key(|(run, _)| run.status == TaskRunStatus::Paused);
        let mut resumed = 0usize;
        for (run, metadata) in runs {
            let cancel = self.cancel.child_token();
            let admission = self
                .task_runtime_store
                .reserve_run_driver_admission(run.run_id.clone(), cancel.clone())?;
            let generation_lease = self
                .task_runtime_store
                .lease_active_workspace_generation()?;
            let mut registration = self
                .task_runtime_store
                .register_observed_run_driver::<()>(admission, generation_lease)?;
            let prompt = metadata.prompt.unwrap_or(run.goal);
            registration.mark_preparation_started();
            if run.status == TaskRunStatus::Paused {
                match self
                    .boot_reconciler
                    .resume(&run.run_id, true, false, &cancel)
                    .await
                    .map_err(anyhow::Error::msg)?
                {
                    TaskRunBootOutcome::Resumed(_) => {}
                    TaskRunBootOutcome::Blocked(blockers) => {
                        registration.reject(format!(
                            "boot auto-resume rejected for {}: {}",
                            run.run_id,
                            blockers
                                .iter()
                                .map(|blocker| blocker.as_str())
                                .collect::<Vec<_>>()
                                .join(",")
                        ));
                        continue;
                    }
                    TaskRunBootOutcome::Cancelled => {
                        registration
                            .reject(format!("boot auto-resume cancelled for {}", run.run_id));
                        return Ok(resumed);
                    }
                }
            }
            self.start_run_driver(run.run_id, prompt, registration, cancel)?;
            resumed = resumed.saturating_add(1);
        }
        Ok(resumed)
    }

    pub fn spawn(self: Arc<Self>) {
        tokio::spawn(async move {
            match self.resume_pending().await {
                Ok(count) if count > 0 => {
                    tracing::info!(count, "resumed background TaskRuntime runs")
                }
                Ok(_) => {}
                Err(error) => tracing::warn!(%error, "background run recovery failed"),
            }
        });
    }

    pub async fn get_progress(&self, run_id: &str) -> Option<TaskProgress> {
        let run_id = run_id.to_string();
        TaskRuntimeOperation::new(self.task_runtime_store.clone())
            .run_store("load background TaskRun progress", move |store| {
                let Some(run) = store.get_run(&run_id)? else {
                    return Ok(None);
                };
                let todos = store.list_todos(&run_id)?;
                Ok(Some(task_progress(&run_id, run, todos)))
            })
            .await
            .ok()
            .flatten()
    }

    pub fn config(&self) -> &BackgroundTaskServiceConfig {
        &self.config
    }
}

fn task_progress(run_id: &str, run: TaskRun, todos: Vec<TodoItem>) -> TaskProgress {
    let total = todos.len();
    let completed = todos
        .iter()
        .filter(|todo| {
            matches!(
                todo.status,
                TodoStatus::Completed | TodoStatus::Failed | TodoStatus::Skipped
            )
        })
        .count();
    let percentage = if total == 0 {
        if run.status == TaskRunStatus::Completed {
            100.0
        } else {
            0.0
        }
    } else {
        (completed as f64 / total as f64) * 100.0
    };
    TaskProgress {
        task_id: run_id.to_string(),
        percentage,
        current_phase: run_status_string(run.status).to_string(),
        phase_index: completed.min(total),
        total_phases: total,
        message: todos
            .iter()
            .find(|todo| todo.status == TodoStatus::Running)
            .map(|todo| todo.title.clone()),
        eta_secs: None,
        updated_at: run.updated_at,
    }
}

#[allow(clippy::too_many_arguments)]
async fn drive_background_run(
    store: Arc<TaskRuntimeStore>,
    agent_provider: Arc<dyn TaskAgentProvider>,
    review_integration: Option<Arc<crate::evolution::ReviewIntegration>>,
    run_semaphore: Arc<tokio::sync::Semaphore>,
    run_id: String,
    prompt: String,
    cancel: CancellationToken,
    mut receipt_owner: super::task_runtime::store::RunDriverReceiptOwner,
) -> Result<(), super::task_runtime::store::RunDriverFailure> {
    let blocking = TaskRuntimeOperation::new(store.clone());
    if cancel.is_cancelled() {
        let failure_run_id = run_id.clone();
        let failure_store = store.clone();
        blocking
            .run_owned("settle cancelled background run", move || {
                finish_pre_execution_failure(&failure_store, &failure_run_id, "run cancelled", true)
                    .map_err(super::task_runtime::StoreError::InvalidPlan)
            })
            .await
            .map_err(|settlement| settlement.to_string())?;
        return Ok(());
    }
    let _run_permit = tokio::select! {
        _ = cancel.cancelled() => {
            let failure_run_id = run_id.clone();
            let failure_store = store.clone();
            blocking
                .run_owned("settle cancelled background admission", move || {
                    finish_pre_execution_failure(&failure_store, &failure_run_id, "run cancelled", true)
                        .map_err(super::task_runtime::StoreError::InvalidPlan)
                })
                .await
                .map_err(|settlement| settlement.to_string())?;
            return Ok(());
        }
        permit = run_semaphore.acquire_owned() => match permit {
            Ok(permit) => permit,
            Err(error) => {
                let message = format!("background concurrency closed: {error}");
                let failure_run_id = run_id.clone();
                let failure_store = store.clone();
                let failure = message.clone();
                blocking
                    .run_owned("settle background admission failure", move || {
                        finish_pre_execution_failure(&failure_store, &failure_run_id, &failure, false)
                            .map_err(super::task_runtime::StoreError::InvalidPlan)
                    })
                    .await
                    .map_err(|settlement| settlement.to_string())?;
                return Err(message.into());
            }
        }
    };
    let transition_run_id = run_id.clone();
    let transition = blocking
        .run_store("start background TaskRun", move |store| {
            transition_to_running(&store, &transition_run_id)
                .map_err(super::task_runtime::StoreError::InvalidPlan)
        })
        .await;
    if let Err(error) = transition {
        let message = error.to_string();
        let failure_run_id = run_id.clone();
        let failure_store = store.clone();
        let failure = message.clone();
        blocking
            .run_owned("settle background start failure", move || {
                finish_pre_execution_failure(&failure_store, &failure_run_id, &failure, false)
                    .map_err(super::task_runtime::StoreError::InvalidPlan)
            })
            .await
            .map_err(|settlement| settlement.to_string())?;
        return Err(message.into());
    }
    let memory_generation = review_integration
        .as_ref()
        .map(|integration| integration.lease_generation())
        .transpose()
        .map_err(|error| format!("memory generation unavailable: {error}"))?;
    if let Some(generation) = memory_generation.as_ref() {
        receipt_owner.retain(generation.clone())?;
    }
    let layer_manager = memory_generation
        .as_ref()
        .map(crate::evolution::ReviewGenerationLease::layer_manager)
        .transpose()
        .map_err(|error| format!("memory layer unavailable: {error}"))?;
    let domain_run_id = run_id.clone();
    let domain_state = blocking
        .run_store("load original background domain binding", move |store| {
            store
                .get_run_state(&domain_run_id)?
                .ok_or(super::task_runtime::StoreError::RunNotFound(domain_run_id))
        })
        .await
        .map_err(|error| error.to_string())?;
    let run_projection = if domain_state.domain_binding.is_some() {
        Some(Arc::new(
            super::task_runtime::compact_context::task_runtime_projection_registry()
                .retain_for_invocation(&run_id, store.clone())?,
        ))
    } else {
        None
    };
    let acquisition = if domain_state.domain_binding.is_none()
        && domain_state.run.domain_profile != super::task_runtime::DomainProfile::General
    {
        Err(echo_agent::error::ReactError::Other("historical professional TaskRun has no trusted plugin binding; create a new domain-bound task".to_string()))
    } else {
        agent_provider
            .acquire_for_task(
                &run_id,
                domain_state.domain_binding.as_ref(),
                run_projection,
            )
            .await
    };
    let mut lease = match acquisition {
        Ok(lease) => lease,
        Err(error) => {
            let message = format!("acquire agent: {error}");
            let failure_run_id = run_id.clone();
            let failure_store = store.clone();
            let failure = message.clone();
            blocking
                .run_owned("settle background agent acquisition", move || {
                    finish_running_failure(&failure_store, &failure_run_id, &failure)
                        .map_err(super::task_runtime::StoreError::InvalidPlan)
                })
                .await
                .map_err(|settlement| settlement.to_string())?;
            return Err(message.into());
        }
    };
    let agent = lease.agent();
    let invocation_resources = std::mem::take(&mut lease.invocation_resources);
    receipt_owner.retain(lease)?;
    if let Some(manager) = layer_manager.as_ref() {
        let manager = manager.clone();
        agent
            .write(|value| value.install_memory_layer_manager(manager))
            .await
            .map_err(|error| error.to_string())?;
    }
    let reviewer_llm = agent.read(|agent| agent.llm_client().cloned()).await;
    let plan_run_id = run_id.clone();
    let has_plan = blocking
        .run_store("load background TaskRun plan", move |store| {
            store.get_plan(&plan_run_id).map(|plan| plan.is_some())
        })
        .await
        .map_err(|error| format!("read plan before background execution: {error}"))?;
    let result = if has_plan {
        super::task_runtime::executor::execute_run_with_resources(
            store.clone(),
            Some(agent),
            reviewer_llm,
            memory_generation,
            None,
            None,
            &run_id,
            cancel,
            MemoryPolicy::None,
            None,
            invocation_resources,
        )
        .await
        .map(|_| run_id.clone())
    } else {
        register_task_execute(&agent, store.clone()).await;
        super::task_runtime::executor::drive_agent_run_with_resources(
            store.clone(),
            agent,
            &run_id,
            "background",
            &run_id,
            &prompt,
            cancel,
            UnattendedWriteMode::default(),
            domain_state.execution_profile.plan_policy,
            None,
            None,
            invocation_resources,
        )
        .await
    };
    if let Err(error) = result {
        if matches!(
            &error,
            super::task_runtime::executor::ExecError::Framework(
                echo_agent::error::ReactError::ExecutionNotSettled { .. }
            )
        ) {
            return Err(error.into());
        }
        let message = error.to_string();
        let failure_run_id = run_id.clone();
        let failure_store = store;
        let failure = message.clone();
        blocking
            .run_owned("settle background execution failure", move || {
                finish_running_failure(&failure_store, &failure_run_id, &failure)
                    .map_err(super::task_runtime::StoreError::InvalidPlan)
            })
            .await
            .map_err(|settlement| settlement.to_string())?;
        return Err(message.into());
    }
    Ok(())
}

#[derive(Default)]
struct TriggerMetadata {
    kind: Option<String>,
    prompt: Option<String>,
    priority: u8,
}

fn trigger_metadata(store: &TaskRuntimeStore, run_id: &str) -> TriggerMetadata {
    let Ok(events) = store.list_events(run_id, 0) else {
        return TriggerMetadata::default();
    };
    events
        .iter()
        .rev()
        .find(|event| {
            event.payload.get("kind").and_then(|value| value.as_str()) == Some("trigger_metadata")
        })
        .map(|event| TriggerMetadata {
            kind: event
                .payload
                .get("task_kind")
                .and_then(|value| value.as_str())
                .map(str::to_string),
            prompt: event
                .payload
                .get("prompt")
                .and_then(|value| value.as_str())
                .map(str::to_string),
            priority: event
                .payload
                .get("priority")
                .and_then(|value| value.as_u64())
                .and_then(|value| u8::try_from(value).ok())
                .unwrap_or(5)
                .min(10),
        })
        .unwrap_or_default()
}

fn run_to_unified(store: &TaskRuntimeStore, run: &TaskRun) -> UnifiedTaskInfo {
    let metadata = trigger_metadata(store, &run.run_id);
    let todos = store.list_todos(&run.run_id).unwrap_or_default();
    let summaries: Vec<String> = todos
        .iter()
        .filter_map(|todo| todo.summary.clone())
        .filter(|summary| !summary.trim().is_empty())
        .collect();
    let result = (!summaries.is_empty()).then(|| summaries.join("\n"));
    let error = todos
        .iter()
        .find(|todo| todo.status == TodoStatus::Failed)
        .and_then(|todo| todo.summary.clone());
    UnifiedTaskInfo {
        id: run.run_id.clone(),
        description: run.goal.clone(),
        status: run_status_string(run.status).to_string(),
        created_at: echo_agent::utils::time::to_local(run.created_at).to_rfc3339(),
        updated_at: echo_agent::utils::time::to_local(run.updated_at).to_rfc3339(),
        result,
        error,
        kind: metadata.kind.or_else(|| Some(run.route.clone())),
        source: "run",
        priority: if metadata.priority == 0 {
            5
        } else {
            metadata.priority
        },
    }
}

fn run_status_string(status: TaskRunStatus) -> &'static str {
    match status {
        TaskRunStatus::Pending => "pending",
        TaskRunStatus::Running => "in_progress",
        TaskRunStatus::Paused => "paused",
        TaskRunStatus::Cancelled => "cancelled",
        TaskRunStatus::Failed => "failed",
        TaskRunStatus::Completed => "completed",
    }
}

fn all_run_statuses() -> [TaskRunStatus; 6] {
    [
        TaskRunStatus::Pending,
        TaskRunStatus::Running,
        TaskRunStatus::Paused,
        TaskRunStatus::Cancelled,
        TaskRunStatus::Failed,
        TaskRunStatus::Completed,
    ]
}

fn transition_to_running(store: &TaskRuntimeStore, run_id: &str) -> Result<(), String> {
    let run = store
        .get_run(run_id)
        .map_err(|error| error.to_string())?
        .ok_or_else(|| format!("run not found: {run_id}"))?;
    match run.status {
        TaskRunStatus::Pending | TaskRunStatus::Paused | TaskRunStatus::Failed => store
            .transition_run(run_id, TaskRunStatus::Running)
            .map(|_| ())
            .map_err(|error| error.to_string()),
        TaskRunStatus::Running => Ok(()),
        TaskRunStatus::Cancelled | TaskRunStatus::Completed => {
            Err(format!("run {run_id} is already {}", run.status.as_str()))
        }
    }
}

fn finish_pre_execution_failure(
    store: &TaskRuntimeStore,
    run_id: &str,
    error: &str,
    cancelled: bool,
) -> Result<(), String> {
    let target = if cancelled {
        TaskRunStatus::Cancelled
    } else {
        TaskRunStatus::Failed
    };
    store
        .finalize_run(run_id, target, Some(error))
        .map(|_| ())
        .map_err(|settlement_error| settlement_error.to_string())
}

fn finish_running_failure(
    store: &TaskRuntimeStore,
    run_id: &str,
    error: &str,
) -> Result<(), String> {
    store
        .finalize_run(run_id, TaskRunStatus::Failed, Some(error))
        .map(|_| ())
        .map_err(|settlement_error| settlement_error.to_string())
}

async fn register_task_execute(agent: &AgentHandle, store: Arc<TaskRuntimeStore>) {
    if agent
        .read(|inner| inner.tool_names().iter().any(|name| name == "task_execute"))
        .await
    {
        return;
    }
    let tool = ExecuteTaskTool::new(store, agent.clone());
    agent
        .write(|agent| {
            agent.add_tool(Box::new(tool));
        })
        .await;
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tasks::task_runtime::PlanTaskKind;

    fn test_agent() -> Result<AgentHandle, String> {
        let llm = Arc::new(
            echo_agent::testing::MockLlmClient::new()
                .with_model_name("test-model")
                .with_response("done"),
        );
        echo_agent::agent::ReactAgentBuilder::new()
            .model("test-model")
            .llm_client(llm)
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())
    }

    fn prepare_background_retry_run(
        store: &TaskRuntimeStore,
        run_id: &str,
        task_id: &str,
        recovery: bool,
    ) -> Result<(), String> {
        store
            .create_run(
                run_id,
                "default",
                &format!("background:test:{run_id}"),
                "",
                DomainProfile::General,
                "retry run",
                "bg:kind:test",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,
                plan_id: format!("{run_id}-plan"),
                run_id: run_id.to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: crate::tasks::task_runtime::task_goal_sha256("retry run"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: task_id.to_string(),
                    title: "Retry task".to_string(),
                    kind: PlanTaskKind::Investigation,
                    agent_role: "researcher".to_string(),
                    max_retries: 2,
                    ..PlanTask::default()
                }],
            })
            .map_err(|error| error.to_string())?;
        store
            .transition_run(run_id, TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        let (task_status, summary, run_status) = if recovery {
            (
                echo_agent::tasks::TaskStatus::Blocked(
                    "mutating side effect is indeterminate after restart".to_string(),
                ),
                "mutating side effect is indeterminate after restart",
                TaskRunStatus::Paused,
            )
        } else {
            (
                echo_agent::tasks::TaskStatus::Failed("execution failed".to_string()),
                "execution failed",
                TaskRunStatus::Failed,
            )
        };
        store
            .set_task_status(
                run_id,
                task_id,
                task_status,
                Some("researcher"),
                Some(summary),
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run(run_id, run_status)
            .map_err(|error| error.to_string())?;
        store
            .record_trigger_metadata(run_id, "test", "research", "retry run", 5)
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    fn retry_snapshot(
        store: &TaskRuntimeStore,
        run_id: &str,
    ) -> Result<(TaskRunStatus, TodoStatus, u32, usize), String> {
        let run = store
            .get_run(run_id)
            .map_err(|error| error.to_string())?
            .ok_or_else(|| format!("run missing: {run_id}"))?;
        let task = store
            .list_todos(run_id)
            .map_err(|error| error.to_string())?
            .into_iter()
            .next()
            .ok_or_else(|| format!("task missing: {run_id}"))?;
        Ok((
            run.status,
            task.status,
            task.retry_count,
            store
                .list_events(run_id, 0)
                .map_err(|error| error.to_string())?
                .len(),
        ))
    }

    #[tokio::test]
    async fn pipeline_submission_creates_only_task_runtime_run() -> Result<(), String> {
        let store = Arc::new(TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?);
        let _resource_scope = store.test_resource_scope();
        let service = BackgroundTaskService::new(
            test_agent()?,
            CancellationToken::new(),
            Some(store.clone()),
        )
        .await
        .map_err(|error| error.to_string())?;
        let run_id = service
            .submit(
                BackgroundTaskKind::Research {
                    topic: "runtime".to_string(),
                    max_papers: 2,
                    output_format: Default::default(),
                },
                "research runtime",
                Some("test".to_string()),
            )
            .await
            .map_err(|error| error.to_string())?;
        let run = store
            .get_run(&run_id)
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "run missing".to_string())?;
        assert!(run.conversation_id.starts_with("background:"));
        assert_eq!(run.route, "bg:kind:research");
        let continuation = store
            .get_run_state(&run_id)
            .map_err(|error| error.to_string())?
            .and_then(|snapshot| snapshot.continuation)
            .ok_or_else(|| "background continuation policy missing".to_string())?;
        assert!(continuation.enabled);
        assert!(continuation.auto_resume_after_restart);
        Ok(())
    }

    #[tokio::test]
    async fn dag_submission_crash_before_publish_leaves_no_visible_run_or_driver()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        std::fs::create_dir_all(&root).map_err(|error| error.to_string())?;
        let store = Arc::new(
            TaskRuntimeStore::new_in_memory_with_shadow_root(root.clone())
                .map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        store.fail_next_initial_publish_before_rename();
        let service = BackgroundTaskService::new(
            test_agent()?,
            CancellationToken::new(),
            Some(store.clone()),
        )
        .await
        .map_err(|error| error.to_string())?;

        let result = service
            .submit_dag(
                vec![PlanTask {
                    id: "inspect".to_string(),
                    title: "Inspect runtime".to_string(),
                    kind: PlanTaskKind::Investigation,
                    agent_role: "explorer".to_string(),
                    ..PlanTask::default()
                }],
                "inspect runtime",
                "test",
                "atomic-publish",
            )
            .await;
        assert!(result.is_err());
        store
            .clone()
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            store
                .active_run_driver_count()
                .map_err(|error| error.to_string())?,
            0
        );
        let has_visible_run = std::fs::read_dir(&root)
            .map_err(|error| error.to_string())?
            .filter_map(Result::ok)
            .any(|entry| {
                entry
                    .file_name()
                    .to_str()
                    .is_some_and(|name| !name.starts_with(".preparing-"))
            });
        assert!(!has_visible_run);
        drop(service);
        drop(store);

        let restarted = Arc::new(
            TaskRuntimeStore::new_in_memory_with_shadow_root(root.clone())
                .map_err(|error| error.to_string())?,
        );
        assert!(
            std::fs::read_dir(&root)
                .map_err(|error| error.to_string())?
                .filter_map(Result::ok)
                .all(|entry| entry
                    .file_name()
                    .to_str()
                    .is_none_or(|name| !name.starts_with(".preparing-")))
        );
        restarted
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn same_run_dependency_graph_is_the_only_background_dag() -> Result<(), String> {
        let store = Arc::new(TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?);
        let _resource_scope = store.test_resource_scope();
        let service = BackgroundTaskService::new(
            test_agent()?,
            CancellationToken::new(),
            Some(store.clone()),
        )
        .await
        .map_err(|error| error.to_string())?;
        let run_id = service
            .submit_dag(
                vec![
                    PlanTask {
                        id: "inspect".to_string(),
                        title: "Inspect".to_string(),
                        kind: PlanTaskKind::Investigation,
                        ..PlanTask::default()
                    },
                    PlanTask {
                        id: "report".to_string(),
                        title: "Report".to_string(),
                        kind: PlanTaskKind::Investigation,
                        depends_on: vec!["inspect".to_string()],
                        ..PlanTask::default()
                    },
                ],
                "same run graph",
                "test",
                "same-run-dag",
            )
            .await
            .map_err(|error| error.to_string())?;
        let plan = service
            .get_task_plan(&run_id)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "same-run plan missing".to_string())?;
        let report = plan
            .tasks
            .iter()
            .find(|task| task.id == "report")
            .ok_or_else(|| "dependent task missing".to_string())?;
        assert_eq!(report.depends_on, vec!["inspect".to_string()]);
        let trigger = store
            .list_events(&run_id, 0)
            .map_err(|error| error.to_string())?
            .into_iter()
            .find(|event| {
                event
                    .payload
                    .get("kind")
                    .and_then(serde_json::Value::as_str)
                    == Some("trigger_metadata")
            })
            .ok_or_else(|| "trigger metadata missing".to_string())?;
        assert!(trigger.payload.get("dependencies").is_none());
        assert_eq!(
            service
                .list_task_todos(&run_id)
                .await
                .map_err(|error| error.to_string())?
                .len(),
            2
        );
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn retry_registers_driver_immediately_instead_of_leaving_fake_running()
    -> Result<(), String> {
        let store = Arc::new(TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?);
        let _resource_scope = store.test_resource_scope();
        store
            .create_run(
                "retry-run",
                "default",
                "background:test:retry-run",
                "",
                DomainProfile::General,
                "retry run",
                "bg:kind:test",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        let task = PlanTask {
            id: "retry-task".to_string(),
            title: "Retry task".to_string(),
            kind: PlanTaskKind::Investigation,
            agent_role: "researcher".to_string(),
            max_retries: 2,
            ..PlanTask::default()
        };
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,
                plan_id: "retry-plan".to_string(),
                run_id: "retry-run".to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: crate::tasks::task_runtime::task_goal_sha256("retry run"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![task],
            })
            .map_err(|error| error.to_string())?;
        store
            .transition_run("retry-run", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .set_task_status(
                "retry-run",
                "retry-task",
                echo_agent::tasks::TaskStatus::Failed(String::new()),
                Some("researcher"),
                Some("execution failed"),
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("retry-run", TaskRunStatus::Failed)
            .map_err(|error| error.to_string())?;
        store
            .record_trigger_metadata("retry-run", "test", "research", "retry run", 5)
            .map_err(|error| error.to_string())?;

        let service = BackgroundTaskService::new(
            test_agent()?,
            CancellationToken::new(),
            Some(store.clone()),
        )
        .await
        .map_err(|error| error.to_string())?;
        let preparation = service
            .retry_blocked_task("retry-run", "retry-task")
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            preparation,
            TaskRetryPreparation::Acceptance { next_attempt: 1 }
        );
        assert_eq!(store.active_run_driver_count()?, 1);
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(store.active_run_driver_count()?, 0);
        Ok(())
    }

    #[tokio::test]
    async fn cli_retry_selects_recovery_without_acceptance_mutation() -> Result<(), String> {
        let store = Arc::new(TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?);
        let _resource_scope = store.test_resource_scope();
        prepare_background_retry_run(&store, "recovery-run", "recovery-task", true)?;
        let service = BackgroundTaskService::new(
            test_agent()?,
            CancellationToken::new(),
            Some(store.clone()),
        )
        .await
        .map_err(|error| error.to_string())?;

        let preparation = service
            .retry_blocked_task("recovery-run", "recovery-task")
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(preparation, TaskRetryPreparation::Recovery);
        assert!(
            store
                .list_recovery_blockers("recovery-run")
                .map_err(|error| error.to_string())?
                .is_empty()
        );
        let plan = store
            .get_plan("recovery-run")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "recovery plan missing".to_string())?;
        assert_eq!(
            plan.tasks.first().map(|task| task.retry_count),
            Some(1),
            "recovery retry must apply the canonical framework retry exactly once"
        );
        assert_eq!(
            store
                .list_events("recovery-run", 0)
                .map_err(|error| error.to_string())?
                .into_iter()
                .filter(|event| {
                    event.event_type
                        == crate::tasks::task_runtime::RuntimeEventKind::RecoveryResolved
                })
                .count(),
            1,
            "recovery retry must publish one resolution fact"
        );
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn cli_retry_admission_and_registration_failures_do_not_mutate_runtime()
    -> Result<(), String> {
        for failure in ["closed-admission", "registration"] {
            let store =
                Arc::new(TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?);
            let run_id = format!("{failure}-run");
            prepare_background_retry_run(&store, &run_id, "retry-task", false)?;
            let service = BackgroundTaskService::new(
                test_agent()?,
                CancellationToken::new(),
                Some(store.clone()),
            )
            .await
            .map_err(|error| error.to_string())?;
            let before = retry_snapshot(&store, &run_id)?;
            if failure == "closed-admission" {
                store
                    .shutdown_run_drivers()
                    .await
                    .map_err(|error| error.to_string())?;
            } else {
                store.fail_next_run_driver_registration_for_test();
            }

            if service
                .retry_blocked_task(&run_id, "retry-task")
                .await
                .is_ok()
            {
                return Err(format!("{failure} retry unexpectedly succeeded"));
            }
            assert_eq!(before, retry_snapshot(&store, &run_id)?);
        }
        Ok(())
    }

    #[tokio::test]
    async fn auto_resume_only_accepts_boot_recovery_pause() -> Result<(), String> {
        let store = TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        let workspace_id = store.active_workspace_id();
        store
            .create_run(
                "run",
                &workspace_id,
                "background:test:run",
                "",
                DomainProfile::General,
                "goal",
                "bg:kind:test",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,
                plan_id: "run-plan".to_string(),
                run_id: "run".to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: crate::tasks::task_runtime::task_goal_sha256("goal"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: "run-task".to_string(),
                    title: "Resume after recovery".to_string(),
                    ..Default::default()
                }],
            })
            .map_err(|error| error.to_string())?;
        store
            .transition_run("run", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .configure_run_continuation("run", true, true, None, None)
            .map_err(|error| error.to_string())?;
        store
            .transition_run("run", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            store
                .boot_auto_resume_decision("run", true, false)
                .map_err(|error| error.to_string())?,
            BootAutoResumeDecision::Blocked(blockers)
                if blockers.contains(&crate::tasks::task_runtime::store::BootAutoResumeBlocker::NotBootRecovery)
        ));

        store
            .resume_task_run("run")
            .map_err(|error| error.to_string())?;
        assert_eq!(
            store
                .recover_incomplete()
                .map_err(|error| error.to_string())?,
            1
        );
        assert!(matches!(
            store
                .boot_auto_resume_decision("run", true, false)
                .map_err(|error| error.to_string())?,
            BootAutoResumeDecision::Ready { .. }
        ));
        let store = Arc::new(store);
        let _resource_scope = store.test_resource_scope();
        let service = BackgroundTaskService::new(
            test_agent()?,
            CancellationToken::new(),
            Some(store.clone()),
        )
        .await
        .map_err(|error| error.to_string())?;
        assert_eq!(
            service
                .resume_pending()
                .await
                .map_err(|error| error.to_string())?,
            1
        );
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }
}
