//! Layered instruction-file loader.
//!
//! Loads five tiers of instruction Markdown files and
//! concatenates them as a system-prompt suffix:
//! - `~/.eko/user.md`              — user-level (cross-project)
//! - `<root..cwd>/AGENTS[.override].md` — repository-standard chain
//! - `<project-root>/.eko/project.md` — project-level
//! - `<project-root>/.eko/learned-rules.md` — auto-promoted rules (evolution)
//! - `<cwd>/.eko/local.md`         — local directory
//!
//! Also loads hot-layer memory from `.eko/MEMORY.md`.
//!
//! Static, file-only loader: no DB, no embeddings, no recall. Query-dependent
//! dynamic memories are handled separately by the layered memory store.
//!
use std::path::{Path, PathBuf};

/// File name for auto-promoted rules (evolution system output).
const LEARNED_RULES_FILE: &str = "learned-rules.md";

/// Layered instruction-file loader (user / repository / project / learned / local).
pub struct InstructionProvider {
    pub project_level: Option<String>,
    pub user_level: Option<String>,
    /// Standard `AGENTS.override.md` / `AGENTS.md` chain, root to working dir.
    pub repository_level: Option<String>,
    pub local_level: Option<String>,
    /// Auto-promoted rules and learned constraints (learned-rules.md body, frontmatter stripped).
    pub agents_level: Option<String>,
    /// Hot-layer memory content (MEMORY.md body, frontmatter stripped).
    pub hot_memory: Option<String>,
}

impl InstructionProvider {
    /// Read project tiers through one selected provider while user memory and
    /// EKO learned rules stay under their original local product-data owner.
    /// Run this synchronous phase on the existing owned blocking boundary.
    pub(crate) fn load_for_file_system(
        working_dir: Option<&Path>,
        state_dir: Option<&Path>,
        files: &dyn echo_agent::tools::filesystem::FileSystem,
    ) -> echo_agent::error::Result<Self> {
        let project_root = working_dir
            .map(|path| {
                crate::utils::find_project_root_with_file_system(path, files)
                    .map(|root| root.unwrap_or_else(|| path.to_path_buf()))
            })
            .transpose()?;
        let project_level = project_optional_text(
            files,
            project_root
                .as_deref()
                .map(|root| root.join(".eko/project.md"))
                .as_deref(),
        )?;
        let local_level = project_optional_text(
            files,
            working_dir
                .map(|root| root.join(".eko/local.md"))
                .as_deref(),
        )?;
        let repository_level =
            repository_instructions_with_reader(working_dir, project_root.as_deref(), |path| {
                project_optional_text(files, Some(path))
            })?;
        let user_level = strict_optional_text(Some(&crate::data_root::user_data_path("user.md")))?;
        let agents_level = match state_dir {
            Some(root) => strict_optional_text(Some(&root.join(LEARNED_RULES_FILE)))?,
            None => None,
        }
        .map(|raw| crate::utils::strip_yaml_frontmatter(&raw));
        let global_memory = crate::data_root::user_data_path("MEMORY.md");
        let local_memory = match state_dir {
            Some(root) => strict_optional_text(Some(&root.join("MEMORY.md")))?,
            None => None,
        };
        let hot_memory = match local_memory {
            Some(raw) => Some(raw),
            None => strict_optional_text(Some(&global_memory))?,
        }
        .map(|raw| crate::utils::strip_yaml_frontmatter(&raw));
        Ok(Self {
            project_level,
            user_level,
            repository_level,
            local_level,
            agents_level,
            hot_memory,
        })
    }

    /// Load every tier from disk.
    pub fn load() -> Self {
        let working_dir = std::env::current_dir().ok();
        Self::load_for(working_dir.as_deref())
    }

    /// Load every tier for one explicit working directory.
    ///
    /// `None` means global context only: user instructions plus user-level
    /// `MEMORY.md`. It intentionally does not consult process cwd, so exiting a
    /// workspace can remove project-local instructions deterministically.
    ///
    pub fn load_for(working_dir: Option<&Path>) -> Self {
        let project_root = working_dir.map(|path| {
            crate::utils::find_project_root(path).unwrap_or_else(|| path.to_path_buf())
        });
        let project_level = Self::load_project_instructions(project_root.as_deref());
        let user_level = Self::load_user_instructions();
        let repository_level =
            Self::load_repository_instructions(working_dir, project_root.as_deref());
        let local_level = Self::load_local_instructions(working_dir);
        let agents_level = Self::load_agents_instructions(project_root.as_deref());
        let hot_memory = Self::load_hot_memory(project_root.as_deref());

        Self {
            project_level,
            user_level,
            repository_level,
            local_level,
            agents_level,
            hot_memory,
        }
    }

    /// Load the complete instruction projection without silently dropping an
    /// existing but unreadable source.
    ///
    /// Promotion and workspace bootstrap transactions use this path before
    /// publishing a runtime generation. Missing optional files are valid;
    /// symlinks, non-regular entries, invalid UTF-8, and read failures are not.
    pub(crate) fn load_for_strict(working_dir: Option<&Path>) -> std::io::Result<Self> {
        Self::load_for_strict_with_state(working_dir, None)
    }

    /// Strictly load project/repository instructions from one path while
    /// optionally taking EKO-owned learned rules and hot memory from another
    /// state directory (used by linked workspaces).
    pub(crate) fn load_for_strict_with_state(
        working_dir: Option<&Path>,
        state_dir: Option<&Path>,
    ) -> std::io::Result<Self> {
        let project_root = working_dir.map(|path| {
            crate::utils::find_project_root(path).unwrap_or_else(|| path.to_path_buf())
        });
        let project_level = strict_optional_text(
            project_root
                .as_deref()
                .map(|root| root.join(".eko").join("project.md"))
                .as_deref(),
        )?;
        let user_path = crate::data_root::user_data_path("user.md");
        let user_level = strict_optional_text(Some(&user_path))?;
        let repository_level =
            strict_repository_instructions(working_dir, project_root.as_deref())?;
        let local_level = strict_optional_text(
            working_dir
                .map(|root| root.join(".eko").join("local.md"))
                .as_deref(),
        )?;
        let agents_level = match state_dir {
            Some(root) => strict_optional_text(Some(&root.join(LEARNED_RULES_FILE)))?,
            None => strict_learned_rules(project_root.as_deref())?,
        }
        .map(|raw| crate::utils::strip_yaml_frontmatter(&raw));
        let global_memory = crate::data_root::user_data_path("MEMORY.md");
        let hot_memory = if let Some(state_dir) = state_dir {
            match strict_optional_text(Some(&state_dir.join("MEMORY.md")))? {
                Some(raw) => Some(raw),
                None => strict_optional_text(Some(&global_memory))?,
            }
        } else {
            match project_root.as_deref() {
                Some(root) => strict_optional_text(Some(&root.join(".eko").join("MEMORY.md")))?,
                None => strict_optional_text(Some(&global_memory))?,
            }
        }
        .map(|raw| crate::utils::strip_yaml_frontmatter(&raw));

        Ok(Self {
            project_level,
            user_level,
            repository_level,
            local_level,
            agents_level,
            hot_memory,
        })
    }

    /// Concatenate the instruction tiers and hot-layer memory into a single
    /// system-prompt suffix.
    ///
    /// Compatibility aggregation for callers that need one string. Runtime
    /// context injection uses [`get_instruction_suffix`] and
    /// [`get_memory_suffix`] as two independently replaceable projections.
    pub fn get_system_prompt_suffix(&self) -> String {
        let mut parts = Vec::new();
        if let Some(suffix) = self.get_instruction_suffix() {
            parts.push(suffix);
        }
        if let Some(suffix) = self.get_memory_suffix() {
            parts.push(suffix);
        }
        if parts.is_empty() {
            String::new()
        } else {
            format!("\n\n{}", parts.join("\n\n"))
        }
    }

    /// Concatenate only the instruction tiers
    /// (user / repository / project / learned-rules / local).
    ///
    /// Excludes hot-layer memory. Returns `None` when no instruction tier has
    /// content.
    pub fn get_instruction_suffix(&self) -> Option<String> {
        let mut parts = Vec::new();
        if let Some(ref user) = self.user_level {
            parts.push(format!("## User-level instructions\n{}", user));
        }
        if let Some(ref repository) = self.repository_level {
            parts.push(format!("## Repository instructions\n{}", repository));
        }
        if let Some(ref project) = self.project_level {
            parts.push(format!("## Project-level instructions\n{}", project));
        }
        if let Some(ref agents) = self.agents_level {
            parts.push(format!("## Auto-promoted rules\n{}", agents));
        }
        if let Some(ref local) = self.local_level {
            parts.push(format!("## Local directory instructions\n{}", local));
        }
        if parts.is_empty() {
            None
        } else {
            Some(parts.join("\n\n"))
        }
    }

    /// Format only the hot-layer memory (MEMORY.md body).
    ///
    /// Returns `None` when no memory content is loaded. Separated from
    /// [`get_instruction_suffix`] because runtime context owns instruction and
    /// hot-memory projections independently.
    pub fn get_memory_suffix(&self) -> Option<String> {
        self.hot_memory
            .as_ref()
            .map(|hot| format!("## Active Memories (Hot Layer)\n{}", hot))
    }

    /// Load project-level instructions from `<project-root>/.eko/project.md`.
    fn load_project_instructions(project_root: Option<&Path>) -> Option<String> {
        project_root
            .map(|root| root.join(".eko").join("project.md"))
            .filter(|path| path.exists())
            .and_then(|path| std::fs::read_to_string(path).ok())
    }

    /// Load user-level instructions from `~/.eko/user.md`.
    fn load_user_instructions() -> Option<String> {
        Some(crate::data_root::user_data_path("user.md"))
            .filter(|path| path.exists())
            .and_then(|path| std::fs::read_to_string(path).ok())
    }

    /// Load the standard root-to-working-directory AGENTS chain.
    ///
    /// EKO deliberately requests the framework resolver's AGENTS-only mode:
    /// `.echo-agent/*` and `CLAUDE.md` are not part of EKO's file protocol.
    fn load_repository_instructions(
        working_dir: Option<&Path>,
        project_root: Option<&Path>,
    ) -> Option<String> {
        let working_dir = working_dir?;
        let resolver =
            echo_agent::project_rules::InstructionResolver::new(working_dir).agents_files_only();
        let resolved = match project_root {
            Some(root) => resolver.project_root(root).resolve(),
            None => resolver.resolve(),
        };
        resolved.annotated()
    }

    /// Load local-directory instructions from `<cwd>/.eko/local.md`.
    fn load_local_instructions(root: Option<&Path>) -> Option<String> {
        root.map(|path| path.join(".eko").join("local.md"))
            .filter(|path| path.exists())
            .and_then(|path| std::fs::read_to_string(path).ok())
    }

    /// Save project-level instructions to `<cwd>/.eko/project.md`.
    pub fn save_project_instructions(content: &str) -> std::io::Result<()> {
        let path = Self::project_instructions_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(path, content)
    }

    /// Save user-level instructions to `~/.eko/user.md`.
    pub fn save_user_instructions(content: &str) -> std::io::Result<()> {
        let path = Self::user_instructions_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(path, content)
    }

    /// Path to the project-level instructions file.
    fn project_instructions_path() -> PathBuf {
        let working_dir = std::env::current_dir().unwrap_or_else(|_| std::path::PathBuf::from("."));
        crate::utils::find_project_root(&working_dir)
            .unwrap_or(working_dir)
            .join(".eko")
            .join("project.md")
    }

    /// Path to the user-level instructions file.
    fn user_instructions_path() -> PathBuf {
        crate::data_root::user_data_path("user.md")
    }

    /// Load hot-layer memory content from `.eko/MEMORY.md`.
    ///
    /// Returns the body (frontmatter stripped) so it can be included in the system prompt.
    fn load_hot_memory(project_root: Option<&Path>) -> Option<String> {
        let project_path = project_root.map(|root| root.join(".eko").join("MEMORY.md"));
        let path = project_path
            .filter(|path| path.exists())
            .unwrap_or_else(|| crate::data_root::user_data_path("MEMORY.md"));
        let raw = std::fs::read_to_string(path).ok()?;

        Some(crate::utils::strip_yaml_frontmatter(&raw))
    }

    /// Load auto-promoted rules from `<project-root>/.eko/learned-rules.md`.
    ///
    /// Contains rules that were automatically promoted from high-confidence
    /// memories by the evolution system's `RulePromoter`.
    fn load_agents_instructions(project_root: Option<&Path>) -> Option<String> {
        let root = project_root?;
        let path = root.join(".eko").join(LEARNED_RULES_FILE);
        let raw = std::fs::read_to_string(path).ok()?;
        Some(crate::utils::strip_yaml_frontmatter(&raw))
    }

    /// Path to the learned-rules file (auto-promoted rules written by `RulePromoter`).
    ///
    /// Resolves the project root via marker-based discovery. Returns a relative
    /// `.eko/learned-rules.md` path when no project root is found so callers get
    /// a deterministic write target.
    pub fn agents_instructions_path() -> PathBuf {
        std::env::current_dir()
            .ok()
            .and_then(|pwd| crate::utils::find_project_root(&pwd))
            .map(|root| root.join(".eko").join(LEARNED_RULES_FILE))
            .unwrap_or_else(|| std::path::PathBuf::from(".eko").join(LEARNED_RULES_FILE))
    }

    /// Save auto-promoted rules to the learned-rules file.
    pub fn save_agents_instructions(content: &str) -> std::io::Result<()> {
        let path = Self::agents_instructions_path();
        Self::save_agents_instructions_at(&path, content)
    }

    /// Save auto-promoted rules to one previously resolved authority path.
    pub fn save_agents_instructions_at(path: &Path, content: &str) -> std::io::Result<()> {
        echo_agent::utils::fs::atomic_write(path, content.as_bytes())
    }
}

pub(crate) fn strict_optional_text(path: Option<&Path>) -> std::io::Result<Option<String>> {
    let Some(path) = path else {
        return Ok(None);
    };
    let metadata = match std::fs::symlink_metadata(path) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(error),
    };
    if metadata.file_type().is_symlink() || !metadata.file_type().is_file() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!(
                "instruction source {} must be a regular non-symlink file",
                path.display()
            ),
        ));
    }
    std::fs::read_to_string(path).map(Some)
}

fn strict_learned_rules(project_root: Option<&Path>) -> std::io::Result<Option<String>> {
    let Some(root) = project_root else {
        return Ok(None);
    };
    let current = root.join(".eko").join(LEARNED_RULES_FILE);
    strict_optional_text(Some(&current))
}

fn strict_repository_instructions(
    working_dir: Option<&Path>,
    project_root: Option<&Path>,
) -> std::io::Result<Option<String>> {
    repository_instructions_with_reader(working_dir, project_root, |path| {
        strict_optional_text(Some(path))
    })
}

fn repository_instructions_with_reader<E: From<std::io::Error>>(
    working_dir: Option<&Path>,
    project_root: Option<&Path>,
    read: impl Fn(&Path) -> Result<Option<String>, E>,
) -> Result<Option<String>, E> {
    let Some(working_dir) = working_dir else {
        return Ok(None);
    };
    let scan_root = project_root.unwrap_or(working_dir);
    if !working_dir.starts_with(scan_root) {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!(
                "instruction working directory {} escapes project root {}",
                working_dir.display(),
                scan_root.display()
            ),
        )
        .into());
    }
    let mut directories = working_dir
        .ancestors()
        .take_while(|directory| directory.starts_with(scan_root))
        .map(Path::to_path_buf)
        .collect::<Vec<_>>();
    directories.reverse();
    let mut blocks = Vec::new();
    for directory in directories {
        for name in ["AGENTS.override.md", "AGENTS.md"] {
            let path = directory.join(name);
            let Some(content) = read(&path)? else {
                continue;
            };
            if content.trim().is_empty() {
                continue;
            }
            blocks.push(format!(
                "<!-- PROJECT INSTRUCTIONS: {} -->\n{}\n<!-- END PROJECT INSTRUCTIONS -->",
                path.display(),
                content.trim()
            ));
            break;
        }
    }
    Ok((!blocks.is_empty()).then(|| blocks.join("\n\n")))
}

fn project_optional_text(
    files: &dyn echo_agent::tools::filesystem::FileSystem,
    path: Option<&Path>,
) -> echo_agent::error::Result<Option<String>> {
    let Some(path) = path else {
        return Ok(None);
    };
    let metadata = match files.symlink_metadata(path) {
        Ok(metadata) => metadata,
        Err(echo_agent::error::ReactError::Io(error))
            if error.kind() == std::io::ErrorKind::NotFound =>
        {
            return Ok(None);
        }
        Err(error) => return Err(error),
    };
    if !metadata.is_file() || metadata.file_type.is_symlink() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!(
                "instruction source {} must be a regular non-symlink file",
                path.display()
            ),
        )
        .into());
    }
    String::from_utf8(files.read(path)?)
        .map(Some)
        .map_err(|error| std::io::Error::new(std::io::ErrorKind::InvalidData, error).into())
}

impl Default for InstructionProvider {
    fn default() -> Self {
        Self::load()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_load_empty_instructions() {
        // This test assumes no instruction files exist
        let instructions = InstructionProvider {
            project_level: None,
            user_level: None,
            repository_level: None,
            local_level: None,
            agents_level: None,
            hot_memory: None,
        };
        assert!(instructions.get_system_prompt_suffix().is_empty());
    }

    #[test]
    fn load_agents_instructions_reads_new_name() -> std::io::Result<()> {
        let temp = tempfile::tempdir()?;
        let root = temp.path();
        let eko = root.join(".eko");
        std::fs::create_dir_all(&eko)?;
        std::fs::write(eko.join(LEARNED_RULES_FILE), "RULE_BODY")?;

        let provider = InstructionProvider::load_for(Some(root));
        assert_eq!(provider.agents_level.as_deref(), Some("RULE_BODY"));
        Ok(())
    }

    #[test]
    fn learned_rules_do_not_interpret_eko_agents_file() -> std::io::Result<()> {
        let temp = tempfile::tempdir()?;
        let eko = temp.path().join(".eko");
        std::fs::create_dir_all(&eko)?;
        std::fs::write(eko.join("AGENTS.md"), "NOT_LEARNED_RULES")?;

        let provider = InstructionProvider::load_for(Some(temp.path()));
        assert!(provider.agents_level.is_none());
        assert!(eko.join("AGENTS.md").exists());
        Ok(())
    }

    #[test]
    fn loads_agents_chain_without_echo_agent_namespace() -> std::io::Result<()> {
        let temp = tempfile::tempdir()?;
        let root = temp.path().join("repo");
        let child = root.join("src");
        std::fs::create_dir_all(root.join(".git"))?;
        std::fs::create_dir_all(root.join(".echo-agent"))?;
        std::fs::create_dir_all(&child)?;
        std::fs::write(root.join("AGENTS.md"), "ROOT_RULE")?;
        std::fs::write(child.join("AGENTS.override.md"), "CHILD_RULE")?;
        std::fs::write(root.join(".echo-agent/AGENT.md"), "NOT_EKO_PROTOCOL")?;

        let provider = InstructionProvider::load_for(Some(&child));
        let repository = provider.repository_level.unwrap_or_default();
        assert!(repository.contains("ROOT_RULE"));
        assert!(repository.contains("CHILD_RULE"));
        assert!(!repository.contains("NOT_EKO_PROTOCOL"));
        Ok(())
    }

    #[test]
    fn strict_loader_keeps_project_agents_and_eko_state_rules_distinct() -> std::io::Result<()> {
        let temp = tempfile::tempdir()?;
        let project = temp.path().join("project");
        let state = temp.path().join("state/.eko");
        std::fs::create_dir_all(project.join(".git"))?;
        std::fs::create_dir_all(project.join(".eko"))?;
        std::fs::create_dir_all(&state)?;
        std::fs::write(project.join("AGENTS.md"), "PROJECT_AGENT_RULE")?;
        std::fs::write(state.join("learned-rules.md"), "STATE_LEARNED_RULE")?;

        let provider =
            InstructionProvider::load_for_strict_with_state(Some(&project), Some(&state))?;
        let repository = provider.repository_level.unwrap_or_default();
        let learned = provider.agents_level.unwrap_or_default();
        assert!(repository.contains("PROJECT_AGENT_RULE"));
        assert_eq!(learned, "STATE_LEARNED_RULE");
        Ok(())
    }

    #[test]
    fn strict_loader_does_not_fallback_to_project_state_files() -> std::io::Result<()> {
        let temp = tempfile::tempdir()?;
        let project = temp.path().join("project");
        let state = temp.path().join("state/.eko");
        std::fs::create_dir_all(project.join(".git"))?;
        std::fs::create_dir_all(project.join(".eko"))?;
        std::fs::create_dir_all(&state)?;
        std::fs::write(project.join(".eko/learned-rules.md"), "PROJECT_LEARNED")?;
        std::fs::write(project.join(".eko/MEMORY.md"), "PROJECT_MEMORY")?;

        let provider =
            InstructionProvider::load_for_strict_with_state(Some(&project), Some(&state))?;
        assert!(provider.agents_level.is_none());
        assert!(
            !provider
                .hot_memory
                .as_deref()
                .is_some_and(|memory| memory.contains("PROJECT_MEMORY"))
        );
        Ok(())
    }

    #[test]
    fn local_instructions_are_relative_to_working_directory() -> std::io::Result<()> {
        let temp = tempfile::tempdir()?;
        let root = temp.path().join("repo");
        let child = root.join("src");
        std::fs::create_dir_all(root.join(".git"))?;
        std::fs::create_dir_all(child.join(".eko"))?;
        std::fs::write(child.join(".eko/local.md"), "LOCAL_CHILD_RULE")?;

        let provider = InstructionProvider::load_for(Some(&child));
        assert_eq!(provider.local_level.as_deref(), Some("LOCAL_CHILD_RULE"));
        Ok(())
    }

    #[test]
    fn strict_loader_rejects_invalid_utf8_in_learned_rules() -> std::io::Result<()> {
        let temp = tempfile::tempdir()?;
        let root = temp.path().join("repo");
        std::fs::create_dir_all(root.join(".git"))?;
        std::fs::create_dir_all(root.join(".eko"))?;
        std::fs::write(root.join(".eko/learned-rules.md"), [0xff, 0xfe])?;

        assert!(InstructionProvider::load_for_strict(Some(&root)).is_err());
        Ok(())
    }

    #[cfg(unix)]
    #[test]
    fn strict_loader_rejects_symlinked_instruction_source() -> std::io::Result<()> {
        let temp = tempfile::tempdir()?;
        let root = temp.path().join("repo");
        std::fs::create_dir_all(root.join(".git"))?;
        std::fs::create_dir_all(root.join(".eko"))?;
        let outside = temp.path().join("outside.md");
        std::fs::write(&outside, "outside")?;
        std::os::unix::fs::symlink(&outside, root.join(".eko/learned-rules.md"))?;

        assert!(InstructionProvider::load_for_strict(Some(&root)).is_err());
        Ok(())
    }
}
