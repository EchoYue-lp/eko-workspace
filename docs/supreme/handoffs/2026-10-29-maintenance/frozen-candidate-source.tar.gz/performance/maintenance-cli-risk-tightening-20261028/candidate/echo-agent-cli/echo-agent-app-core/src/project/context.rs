use std::path::{Path, PathBuf};

use super::gitignore::GitIgnore;

/// Structural project context: directory tree + git state + ignore rules.
///
/// Instruction/rules content is NOT loaded here — that responsibility belongs
/// solely to [`crate::instruction_provider::InstructionProvider`] (which
/// produces the `eko:instruction-context` projection). Earlier versions read
/// the same files here too, which split one logical instruction stream across
/// two projections. `AGENTS.md` remains supported through that single owner;
/// `ECHO_AGENT.md` and the old global aliases are no longer consulted.
#[derive(Debug, Clone)]
pub struct ProjectContext {
    pub root: PathBuf,
    pub name: String,
    pub file_tree_summary: String,
    /// Parsed .gitignore rules (empty if no .gitignore exists).
    pub gitignore: GitIgnore,
    /// Captured from this project's executor, never a late local process call.
    pub git_context: Option<String>,
    git_repository: bool,
}

pub fn discover_project_root(start: Option<&Path>) -> Option<PathBuf> {
    let start = start.unwrap_or_else(|| Path::new("."));
    let dir = if start.is_absolute() {
        start.to_path_buf()
    } else {
        std::env::current_dir().ok()?.join(start)
    };
    crate::utils::find_project_root(&dir)
}

/// Resolve one explicit project path, or discover the project containing the
/// supplied working directory/current process directory.
///
/// The returned path is the authority for repository `AGENTS.md` files and
/// project-local `.eko/skills/`. EKO workspace data remains a separate root.
pub fn resolve_project_root(project: Option<&str>, working_dir: Option<&Path>) -> Option<PathBuf> {
    let candidate = project
        .filter(|value| !value.trim().is_empty())
        .map(PathBuf::from)
        .or_else(|| working_dir.map(Path::to_path_buf))
        .or_else(|| std::env::current_dir().ok())?;
    discover_project_root(Some(&candidate)).or_else(|| {
        if candidate.is_absolute() {
            Some(candidate)
        } else {
            candidate.canonicalize().ok()
        }
    })
}

pub fn load_project_context(project_root: &Path) -> ProjectContext {
    let name = project_root
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| "unknown".to_string());

    let file_tree_summary = generate_file_tree_summary(project_root);
    let gitignore = GitIgnore::load(project_root);

    ProjectContext {
        root: project_root.to_path_buf(),
        name,
        file_tree_summary,
        gitignore,
        git_context: load_git_context(project_root),
        git_repository: project_root.join(".git").exists(),
    }
}

pub fn load_project_context_with_file_system(
    project_root: &Path,
    files: &dyn echo_agent::tools::filesystem::FileSystem,
) -> echo_agent::error::Result<ProjectContext> {
    let mut entries = Vec::new();
    collect_dir_entries_with_file_system(project_root, &mut entries, 0, 3, files)?;
    Ok(ProjectContext {
        root: project_root.to_path_buf(),
        name: project_root
            .file_name()
            .map(|name| name.to_string_lossy().into_owned())
            .unwrap_or_else(|| "unknown".to_string()),
        file_tree_summary: entries.join("\n"),
        gitignore: GitIgnore::load_with_file_system(project_root, files)?,
        git_context: None,
        git_repository: files.exists(&project_root.join(".git"))?,
    })
}

/// The selected executor retains its real capability/isolation and process
/// owner. This phase runs before a host/agent can be published to a model.
pub async fn load_project_git_context(
    context: &mut ProjectContext,
    executor: &dyn echo_agent::sandbox::SandboxExecutor,
    resource_guards: Vec<echo_agent::tools::InvocationResourceGuard>,
) -> echo_agent::error::Result<()> {
    if !context.git_repository {
        return Ok(());
    }
    let mut command = echo_agent::sandbox::SandboxCommand::program(
        "git",
        vec!["status".to_string(), "--short".to_string()],
    );
    command.working_dir = Some(context.root.clone());
    command.resource_guards = resource_guards.clone();
    let status = executor.execute(command).await?;
    if status.exit_code != 0 {
        return Err(echo_agent::error::ReactError::Other(
            "Project git status failed".to_string(),
        ));
    }
    let mut command = echo_agent::sandbox::SandboxCommand::program(
        "git",
        vec!["diff".to_string(), "--stat".to_string()],
    );
    command.working_dir = Some(context.root.clone());
    command.resource_guards = resource_guards;
    let diff = executor.execute(command).await?;
    if diff.exit_code != 0 {
        return Err(echo_agent::error::ReactError::Other(
            "Project git diff failed".to_string(),
        ));
    }
    let mut text = String::new();
    if !status.stdout.trim().is_empty() {
        text.push_str(&format!("```\n{}\n```\n", status.stdout.trim()));
    }
    if !diff.stdout.trim().is_empty() {
        text.push_str(&format!("```\n{}\n```\n", diff.stdout.trim()));
    }
    context.git_context = (!text.is_empty()).then_some(text);
    Ok(())
}

impl ProjectContext {
    /// Check whether a path (relative to the project root) should be ignored
    /// by file tools. The check combines:
    ///
    /// 1. Built-in skip directories (`target`, `node_modules`, `.git`, etc.)
    /// 2. `.gitignore` rules loaded from the project root
    pub fn should_ignore_path(&self, relative_path: &str, is_dir: bool) -> bool {
        // Check built-in skip dirs first
        let first_component = relative_path.split('/').next().unwrap_or(relative_path);
        if SKIP_DIRS.contains(&first_component) {
            return true;
        }
        // Then check gitignore rules
        self.gitignore.is_ignored(relative_path, is_dir)
    }
}

/// Build a system prompt from a base prompt plus structural project context.
///
/// Instruction/rules content is injected separately via the
/// `eko:instruction-context` projection (see [`crate::unified_memory`]).
pub fn build_system_prompt_with_context(base_prompt: &str, context: &ProjectContext) -> String {
    let mut prompt = base_prompt.to_string();

    if !context.file_tree_summary.is_empty() {
        prompt.push_str(&format!(
            "\n## Project Structure ({})\n\n```\n{}\n```\n",
            context.name, context.file_tree_summary
        ));
    }

    // Inject git context if available
    if let Some(git_ctx) = &context.git_context {
        prompt.push_str("\n## Git Status\n\n");
        prompt.push_str(git_ctx);
        prompt.push('\n');
    }

    prompt
}

/// Load git status and diff summary from the project root.
pub fn load_git_context(project_root: &std::path::Path) -> Option<String> {
    let git_dir = project_root.join(".git");
    if !git_dir.exists() {
        return None;
    }

    let status = std::process::Command::new("git")
        .args(["status", "--short"])
        .current_dir(project_root)
        .output()
        .ok()?;
    let status_str = String::from_utf8_lossy(&status.stdout).to_string();

    let diff = std::process::Command::new("git")
        .args(["diff", "--stat"])
        .current_dir(project_root)
        .output()
        .ok()?;
    let diff_str = String::from_utf8_lossy(&diff.stdout).to_string();

    let mut result = String::new();
    if !status_str.trim().is_empty() {
        result.push_str(&format!("```\n{}\n```\n", status_str.trim()));
    }
    if !diff_str.trim().is_empty() {
        result.push_str(&format!("```\n{}\n```\n", diff_str.trim()));
    }
    if result.is_empty() {
        return None;
    }
    Some(result)
}

fn generate_file_tree_summary(root: &Path) -> String {
    let mut entries = Vec::new();
    collect_dir_entries(root, &mut entries, 0, 3);
    entries.join("\n")
}

fn collect_dir_entries(dir: &Path, out: &mut Vec<String>, depth: usize, max_depth: usize) {
    let _ = collect_dir_entries_with_file_system(
        dir,
        out,
        depth,
        max_depth,
        &echo_agent::tools::files::LocalFileSystem,
    );
}

fn collect_dir_entries_with_file_system(
    dir: &Path,
    out: &mut Vec<String>,
    depth: usize,
    max_depth: usize,
    filesystem: &dyn echo_agent::tools::filesystem::FileSystem,
) -> echo_agent::error::Result<()> {
    if depth > max_depth {
        return Ok(());
    }

    let rd = filesystem.read_dir(dir)?;

    let mut dirs = Vec::new();
    let mut files = Vec::new();

    for entry in rd {
        let name = entry.file_name.to_string_lossy().to_string();
        if name.starts_with('.') && name != ".env.example" {
            continue;
        }
        if SKIP_DIRS.contains(&name.as_str()) {
            continue;
        }

        if entry.file_type.is_dir() {
            dirs.push(name);
        } else {
            files.push(name);
        }
    }

    dirs.sort();
    files.sort();

    let indent = "  ".repeat(depth);

    for name in &files {
        if files.len() > 20 && out.len() > 50 {
            out.push(format!("{}  ... ({} more files)", indent, files.len() - 20));
            break;
        }
        out.push(format!("{}{}", indent, name));
    }

    for dir_name in &dirs {
        if out.len() > 80 {
            out.push(format!("{}  ... (truncated)", indent));
            return Ok(());
        }
        out.push(format!("{}{}/", indent, dir_name));
        collect_dir_entries_with_file_system(
            &dir.join(dir_name),
            out,
            depth + 1,
            max_depth,
            filesystem,
        )?;
    }
    Ok(())
}

const SKIP_DIRS: &[&str] = &[
    "target",
    "node_modules",
    ".git",
    ".hg",
    ".svn",
    "dist",
    "build",
    "out",
    ".next",
    ".nuxt",
    "vendor",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    ".DS_Store",
];
