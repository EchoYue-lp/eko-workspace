#[cfg(test)]
#[allow(clippy::items_after_test_module)] // usage-record impls below are production code kept here for locality with their tests; reordering is pure churn
mod tests {
    use super::*;

    mod performance_baseline {
        use super::*;
        include!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/runtime_baseline.rs"
        ));
    }

    fn durable_input_source(
        store: &TaskRuntimeStore,
        input_id: &str,
        revision: u64,
        text: &str,
        channel: bool,
    ) -> Result<RunInputSnapshot, Box<dyn std::error::Error>> {
        use crate::conversation_input::{
            ChannelExecutionIntent, ChannelInputBinding, ConversationInputAddress,
            ConversationInputIdentity, ConversationInputPayload, ConversationInputSource,
            FrozenChannelContext,
        };
        let address = ConversationInputAddress {
            workspace_id: store.active_workspace_id().to_string(),
            conversation_id: "same-conversation".to_string(),
        };
        let payload = if channel {
            ConversationInputPayload::new_for_channel(
                &address,
                text.to_string(),
                Vec::new(),
                None,
                ChannelInputBinding {
                    version: 1,
                    channel_id: "weixin".to_string(),
                    account_id: "original-account".to_string(),
                    credential_generation: "original-generation".to_string(),
                    peer_id: "original-peer".to_string(),
                    provider_message_id: input_id.to_string(),
                    workspace_generation: "workspace-generation".to_string(),
                    context: FrozenChannelContext::Absent,
                    execution: ChannelExecutionIntent::Chat,
                },
            )?
        } else {
            ConversationInputPayload::new(text.to_string(), Vec::new())?
        };
        let identity = ConversationInputIdentity {
            address,
            input_id: input_id.to_string(),
            revision,
            payload_sha256: payload.payload_sha256.clone(),
        };
        Ok(RunInputSnapshot {
            source: if channel {
                ConversationInputSource::Channel
            } else {
                ConversationInputSource::Gui
            },
            identity,
            payload,
        })
    }

    fn raw_history_descriptor(
        history: &RawInputHistoryReference,
        config: &echo_agent::tools::artifact::ToolOutputArtifactConfig,
    ) -> Result<echo_agent::tools::artifact::ToolOutputArtifactRef, Box<dyn std::error::Error>>
    {
        let artifact = history.artifact.as_ref().ok_or("原文历史文件缺失")?;
        Ok(echo_agent::tools::artifact::ToolOutputArtifactRef {
            path: artifact.path.clone(),
            artifact_bytes: artifact.bytes,
            payload_bytes: artifact.bytes,
            sha256: artifact.sha256.clone().ok_or("原文历史SHA缺失")?,
            retention: config.retention.clone(),
        })
    }

    #[test]
    fn raw_input_history_fixed_prefix_crosses_scan_pages_and_keeps_legacy_duplicates()
    -> Result<(), Box<dyn std::error::Error>> {
        use echo_agent::tools::files::artifact::{ArtifactPageLimit, read_artifact_page};
        let directory = tempfile::tempdir()?;
        let root = directory.path().join(".eko/tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?;
        seed_task_query_run(
            &store,
            "raw-run",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let text = "相同文字是合法重复输入，不能按文字合并🧭";
        let first = durable_input_source(&store, "first-source", 1, text, false)?;
        store.accept_run_steer_input(
            "raw-run",
            "same-turn",
            first.source,
            &first.identity,
            &first.payload,
        )?;
        store.record_run_steer("raw-run", "same-turn", text)?;
        let old = store.raw_input_history_reference("raw-run", None)?;
        let old_family = std::fs::read(root.join("raw-run/raw-input-history.jsonl"))?;
        let old_family_metadata = std::fs::read(root.join("raw-run/raw-input-history.meta.jsonl"))?;
        assert_eq!(old.source_records, 2);
        let config = crate::infra::tool_output_artifact_config(Some(directory.path()));
        let old_descriptor = raw_history_descriptor(&old, &config)?;
        let old_metadata = std::fs::metadata(&old_descriptor.path)?;
        let first_page =
            read_artifact_page(&config, &old_descriptor, None, ArtifactPageLimit::Bytes(31))?;
        let old_cursor = first_page.next_cursor.ok_or("原文第一页缺cursor")?;
        for index in 0..270 {
            store.commit_runtime_event(RuntimeJournalEvent::for_append(
                "raw-run",
                None,
                None,
                RuntimeEventKind::Note,
                serde_json::json!({"index":index,"message":"无关工具/执行事实"}),
            ))?;
        }
        let no_new_input = store.raw_input_history_reference("raw-run", None)?;
        assert!(no_new_input.observed_through_sequence > old.observed_through_sequence);
        assert_eq!(no_new_input.source_records, old.source_records);
        assert_eq!(no_new_input.last_source_sequence, old.last_source_sequence);
        let no_new_descriptor = raw_history_descriptor(&no_new_input, &config)?;
        assert_eq!(no_new_descriptor.path, old_descriptor.path);
        assert_eq!(no_new_descriptor.sha256, old_descriptor.sha256);
        assert_eq!(
            std::fs::metadata(&no_new_descriptor.path)?.modified()?,
            old_metadata.modified()?
        );
        #[cfg(unix)]
        {
            use std::os::unix::fs::MetadataExt;
            assert_eq!(
                std::fs::metadata(&no_new_descriptor.path)?.ino(),
                old_metadata.ino()
            );
        }
        let second = durable_input_source(&store, "second-source", 1, text, false)?;
        store.accept_run_steer_input(
            "raw-run",
            "same-turn",
            second.source,
            &second.identity,
            &second.payload,
        )?;
        store.record_run_steer("raw-run", "same-turn", text)?;
        let current = store.raw_input_history_reference("raw-run", None)?;
        assert_eq!(current.source_records, 4);
        assert!(current.last_source_sequence > 256);
        let current_descriptor = raw_history_descriptor(&current, &config)?;
        assert_ne!(current_descriptor.path, old_descriptor.path);
        store.qualify_raw_input_history_reference("raw-run", &old)?;
        // 旧引用的坏段恢复不能回滚整个暖族；后继非source事件也不能把丢失尾部重新盖成Current。
        std::fs::write(
            root.join("raw-run/raw-input-history.jsonl"),
            "旧快照资格校验时发现坏段",
        )?;
        store.qualify_raw_input_history_reference("raw-run", &old)?;
        store.commit_runtime_event(RuntimeJournalEvent::for_append(
            "raw-run",
            None,
            None,
            RuntimeEventKind::Note,
            serde_json::json!({"message":"恢复旧快照后的无关事件"}),
        ))?;
        assert_eq!(
            store
                .raw_input_history_reference("raw-run", None)?
                .source_records,
            4
        );
        assert!(
            read_artifact_page(
                &config,
                &old_descriptor,
                Some(&old_cursor),
                ArtifactPageLimit::Bytes(31)
            )
            .is_ok()
        );
        assert!(
            read_artifact_page(
                &config,
                &current_descriptor,
                Some(&old_cursor),
                ArtifactPageLimit::Bytes(31)
            )
            .is_err()
        );
        let duplicate = store.accept_run_steer_input(
            "raw-run",
            "same-turn",
            first.source,
            &first.identity,
            &first.payload,
        )?;
        assert!(duplicate.duplicate);
        assert_eq!(
            store
                .raw_input_history_reference("raw-run", None)?
                .source_records,
            4
        );
        let contents = std::fs::read_to_string(&current_descriptor.path)?;
        let records = contents
            .lines()
            .skip(1)
            .map(serde_json::from_str::<serde_json::Value>)
            .collect::<Result<Vec<_>, _>>()?;
        assert_eq!(records.len(), 4);
        assert_eq!(
            records
                .iter()
                .filter(|record| record
                    .pointer("/event/payload/input_snapshot/identity/input_id")
                    .and_then(serde_json::Value::as_str)
                    == Some("first-source"))
                .count(),
            1
        );
        assert_eq!(
            records
                .iter()
                .filter(|record| record
                    .pointer("/event/payload/input_snapshot/identity/input_id")
                    .and_then(serde_json::Value::as_str)
                    == Some("second-source"))
                .count(),
            1
        );
        assert_eq!(
            records
                .iter()
                .filter(|record| record
                    .pointer("/event/event_type")
                    .and_then(serde_json::Value::as_str)
                    == Some("run_steer_recorded"))
                .count(),
            2
        );
        drop(store);
        // 段及其CRC仍互相自洽，但落后于同代cursor；必须核完整族身份并重建，不能丢后两条。
        std::fs::write(root.join("raw-run/raw-input-history.jsonl"), old_family)?;
        std::fs::write(
            root.join("raw-run/raw-input-history.meta.jsonl"),
            old_family_metadata,
        )?;
        let stale_segment = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?;
        let repaired = stale_segment.raw_input_history_reference("raw-run", None)?;
        assert_eq!(repaired.source_records, 4);
        assert_eq!(
            raw_history_descriptor(&repaired, &config)?.sha256,
            current_descriptor.sha256
        );
        drop(stale_segment);
        // 移除派生族迫使固定256扫描跨越270无关事件，不能只取第一个匹配页。
        std::fs::remove_file(root.join("raw-run/raw-input-history.jsonl"))?;
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?;
        let restored = reopened.raw_input_history_reference("raw-run", None)?;
        assert_eq!(restored.journal_identity, current.journal_identity);
        assert_eq!(restored.source_records, 4);
        let restored_descriptor = raw_history_descriptor(&restored, &config)?;
        assert_eq!(restored_descriptor.path, current_descriptor.path);
        assert_eq!(restored_descriptor.sha256, current_descriptor.sha256);
        Ok(())
    }

    #[test]
    fn raw_input_history_cache_rebuild_rejects_old_cursor_and_preserves_updated_goal()
    -> Result<(), Box<dyn std::error::Error>> {
        use echo_agent::tools::files::artifact::{ArtifactPageLimit, read_artifact_page};
        let directory = tempfile::tempdir()?;
        let root = directory.path().join(".eko/tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?;
        let original = format!("{}初始Goal原文尾部🧭", "完整源背景 ".repeat(300));
        let source = durable_input_source(&store, "initial-source", 1, &original, false)?;
        store.create_run_for_active_workspace_with_source(
            "raw-goal",
            "same-conversation",
            "initial-turn",
            DomainProfile::General,
            &original,
            "agent_task_plan",
            AttendedMode::Attended,
            TaskRunExecutionProfile::conversation_turn(),
            None,
            &source,
        )?;
        let config = crate::infra::tool_output_artifact_config(Some(directory.path()));
        let first = store.raw_input_history_reference("raw-goal", None)?;
        let descriptor = raw_history_descriptor(&first, &config)?;
        let cursor = read_artifact_page(&config, &descriptor, None, ArtifactPageLimit::Bytes(31))?
            .next_cursor
            .ok_or("原cursor缺失")?;
        store.transition_run("raw-goal", TaskRunStatus::Running)?;
        store.transition_run("raw-goal", TaskRunStatus::Paused)?;
        let updated = store.update_run_goal(
            "raw-goal",
            1,
            "用户显式修改后的新Goal",
            "用户操作",
            RunGoalActorSource::Gui,
        )?;
        let after_update = store.raw_input_history_reference("raw-goal", None)?;
        assert_eq!(
            raw_history_descriptor(&after_update, &config)?.sha256,
            descriptor.sha256
        );
        assert!(std::fs::read_to_string(&descriptor.path)?.contains(&original));
        std::fs::write(
            root.join("raw-goal/raw-input-history.jsonl"),
            "损坏的派生来源族",
        )?;
        assert_eq!(
            raw_history_descriptor(
                &store.raw_input_history_reference("raw-goal", None)?,
                &config
            )?
            .sha256,
            descriptor.sha256
        );
        std::fs::write(&descriptor.path, "已损坏的原文缓存")?;
        let rebuilt =
            store.raw_input_history_reference("raw-goal", Some(first.observed_through_sequence))?;
        let rebuilt_descriptor = raw_history_descriptor(&rebuilt, &config)?;
        assert_eq!(rebuilt_descriptor.sha256, descriptor.sha256);
        assert!(
            read_artifact_page(
                &config,
                &rebuilt_descriptor,
                Some(&cursor),
                ArtifactPageLimit::Bytes(31)
            )
            .is_err()
        );
        assert!(
            read_artifact_page(
                &config,
                &rebuilt_descriptor,
                None,
                ArtifactPageLimit::Bytes(31)
            )
            .is_ok()
        );
        std::fs::remove_file(&rebuilt_descriptor.path)?;
        let regenerated =
            store.raw_input_history_reference("raw-goal", Some(first.observed_through_sequence))?;
        assert_eq!(
            raw_history_descriptor(&regenerated, &config)?.sha256,
            descriptor.sha256
        );
        let after = store.get_run("raw-goal")?.ok_or("原Goal缺失")?;
        assert_eq!(
            (after.goal, after.goal_revision, after.goal_sha256),
            (
                updated.goal.clone(),
                updated.goal_revision,
                updated.goal_sha256.clone()
            )
        );
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?;
        let restored = reopened.raw_input_history_reference("raw-goal", None)?;
        assert_eq!(
            raw_history_descriptor(&restored, &config)?.sha256,
            descriptor.sha256
        );
        assert_eq!(
            reopened.get_run("raw-goal")?.ok_or("原Goal缺失")?.goal,
            updated.goal
        );
        Ok(())
    }

    #[test]
    fn raw_input_history_snapshots_isolate_runs_generations_and_concurrent_append()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let root = directory.path().join(".eko/tasks");
        let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?);
        for run_id in ["raw-first", "raw-second"] {
            seed_task_query_run(&store, run_id, TaskRunExecutionProfile::conversation_turn())?;
            store.record_run_steer(run_id, "same-turn", "同样文字，仍是不同Run")?;
        }
        let old = store.raw_input_history_reference("raw-first", None)?;
        let other = store.raw_input_history_reference("raw-second", None)?;
        assert_ne!(old.journal_identity, other.journal_identity);
        assert!(
            store
                .qualify_raw_input_history_reference("raw-second", &old)
                .is_err()
        );
        let mut wrong_generation = old.clone();
        wrong_generation.journal_identity = other.journal_identity;
        assert!(
            store
                .qualify_raw_input_history_reference("raw-first", &wrong_generation)
                .is_err()
        );
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(2));
        let reader = store.clone();
        let reader_barrier = barrier.clone();
        let writer = store.clone();
        let raced = std::thread::scope(
            |scope| -> Result<RawInputHistoryReference, Box<dyn std::error::Error>> {
                let read = scope.spawn(move || {
                    reader_barrier.wait();
                    reader.raw_input_history_reference("raw-first", None)
                });
                let write = scope.spawn(move || {
                    barrier.wait();
                    writer.record_run_steer("raw-first", "later-turn", "并发新输入")
                });
                let snapshot = read.join().map_err(|_| "原文快照线程异常")??;
                write.join().map_err(|_| "原输入追加线程异常")??;
                Ok(snapshot)
            },
        )?;
        assert!(raced.source_records == 1 || raced.source_records == 2);
        store.qualify_raw_input_history_reference("raw-first", &raced)?;
        store.qualify_raw_input_history_reference("raw-first", &old)?;
        let final_snapshot = store.raw_input_history_reference("raw-first", None)?;
        assert_eq!(final_snapshot.source_records, 2);
        let mut future = final_snapshot.clone();
        future.observed_through_sequence = future.observed_through_sequence.saturating_add(1);
        assert!(
            store
                .qualify_raw_input_history_reference("raw-first", &future)
                .is_err()
        );
        drop(store);
        let new_root = directory.path().join("another-workspace/.eko/tasks");
        let replacement = TaskRuntimeStore::new_in_memory_with_shadow_root(&new_root)?;
        seed_task_query_run(
            &replacement,
            "raw-first",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        replacement.record_run_steer("raw-first", "same-turn", "另工作空间自己的第一条")?;
        replacement.record_run_steer("raw-first", "later-turn", "另工作空间自己的第二条")?;
        let new = replacement.raw_input_history_reference("raw-first", None)?;
        assert_ne!(new.journal_identity, old.journal_identity);
        assert!(
            replacement
                .qualify_raw_input_history_reference("raw-first", &old)
                .is_err()
        );
        assert_eq!(
            new.observed_through_sequence,
            final_snapshot.observed_through_sequence
        );
        drop(replacement);
        for name in [
            "raw-input-history.jsonl",
            "raw-input-history.meta.jsonl",
            "history-cursor.json",
        ] {
            std::fs::copy(
                root.join("raw-first").join(name),
                new_root.join("raw-first").join(name),
            )?;
        }
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&new_root)?;
        let recovered = reopened.raw_input_history_reference("raw-first", None)?;
        assert_eq!(recovered.journal_identity, new.journal_identity);
        assert_eq!(
            recovered
                .artifact
                .as_ref()
                .and_then(|artifact| artifact.sha256.as_ref()),
            new.artifact
                .as_ref()
                .and_then(|artifact| artifact.sha256.as_ref())
        );
        Ok(())
    }

    #[test]
    fn raw_input_history_missing_journal_never_reuses_warm_cache()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let root = directory.path().join(".eko/tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?;
        seed_task_query_run(
            &store,
            "raw-unavailable",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        store.record_run_steer("raw-unavailable", "original-turn", "原文必须仍可验证")?;
        let snapshot = store.raw_input_history_reference("raw-unavailable", None)?;
        assert_eq!(snapshot.source_records, 1);
        let original = root.join("raw-unavailable/events.jsonl");
        let held = root.join("raw-unavailable/events.held");
        std::fs::rename(&original, &held)?;
        let rejected = store
            .raw_input_history_reference("raw-unavailable", None)
            .is_err();
        std::fs::rename(&held, &original)?;
        assert!(rejected, "暖缓存不能冒原journal当前可读");
        store.qualify_raw_input_history_reference("raw-unavailable", &snapshot)?;
        Ok(())
    }

    #[test]
    fn canonical_goal_host_refs_keep_legacy_and_user_versions_without_inventing_inputs()
    -> Result<(), Box<dyn std::error::Error>> {
        use echo_agent::tools::files::artifact::{ArtifactPageLimit, read_artifact_page};
        let directory = tempfile::tempdir()?;
        let root = directory.path().join(".eko/tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?;
        let initial = format!(
            "{}LEGACY_INITIAL_GOAL_TAIL_3872🧭",
            "initial goal detail ".repeat(600)
        );
        store.create_run(
            "goal-host",
            "default",
            "same-conversation",
            "initial-turn",
            DomainProfile::General,
            &initial,
            "agent_task_plan",
            AttendedMode::Attended,
        )?;
        assert_eq!(
            store
                .raw_input_history_reference("goal-host", None)?
                .source_records,
            0
        );
        let first = store
            .canonical_goal_reference("goal-host")?
            .ok_or("legacy长Goal缺host ref")?;
        let config = crate::infra::tool_output_artifact_config(Some(directory.path()));
        let descriptor =
            |goal: &CanonicalGoalReference| echo_agent::tools::artifact::ToolOutputArtifactRef {
                path: goal.artifact.path.clone(),
                artifact_bytes: goal.artifact.bytes,
                payload_bytes: goal.artifact.bytes,
                sha256: goal.goal_sha256.clone(),
                retention: config.retention.clone(),
            };
        let old = descriptor(&first);
        assert!(
            old.path
                .starts_with(directory.path().join(".eko/artifacts"))
        );
        assert!(read_artifact_page(&config, &old, None, ArtifactPageLimit::Bytes(31)).is_ok());
        let cursor = read_artifact_page(&config, &old, None, ArtifactPageLimit::Bytes(31))?
            .next_cursor
            .ok_or("旧Goal cursor缺失")?;
        store.transition_run("goal-host", TaskRunStatus::Running)?;
        store.transition_run("goal-host", TaskRunStatus::Paused)?;
        let revised = format!(
            "{}USER_UPDATED_GOAL_TAIL_5739🧭",
            "updated user goal detail ".repeat(600)
        );
        let updated = store.update_run_goal(
            "goal-host",
            1,
            &revised,
            "用户显式修改长Goal",
            RunGoalActorSource::Gui,
        )?;
        let current = store
            .canonical_goal_reference("goal-host")?
            .ok_or("用户长Goal缺host ref")?;
        assert_eq!(current.goal_revision, 2);
        assert_eq!(current.goal_sha256, updated.goal_sha256);
        assert_ne!(current.artifact.path, first.artifact.path);
        assert_eq!(
            store
                .raw_input_history_reference("goal-host", None)?
                .source_records,
            0,
            "canonical Goal引用不能伪造成新的用户输入事实"
        );
        assert!(
            store
                .qualify_canonical_goal_reference("goal-host", &first)
                .is_err()
        );
        store.qualify_canonical_goal_reference("goal-host", &current)?;
        assert!(
            read_artifact_page(&config, &old, Some(&cursor), ArtifactPageLimit::Bytes(31)).is_ok()
        );
        assert_eq!(std::fs::read_to_string(&first.artifact.path)?, initial);
        assert_eq!(std::fs::read_to_string(&current.artifact.path)?, revised);
        let new_descriptor = descriptor(&current);
        assert!(
            read_artifact_page(
                &config,
                &new_descriptor,
                Some(&cursor),
                ArtifactPageLimit::Bytes(31)
            )
            .is_err()
        );
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?;
        let restored = reopened
            .canonical_goal_reference("goal-host")?
            .ok_or("冷重开Goal ref缺失")?;
        assert_eq!(restored.artifact.path, current.artifact.path);
        assert_eq!(restored.goal_sha256, current.goal_sha256);
        std::fs::write(&restored.artifact.path, "坏Goal缓存")?;
        let repaired = reopened
            .canonical_goal_reference("goal-host")?
            .ok_or("Goal缓存重建缺失")?;
        assert_eq!(std::fs::read_to_string(&repaired.artifact.path)?, revised);
        let current_run = reopened.get_run("goal-host")?.ok_or("当前Goal缺失")?;
        assert_eq!(
            (
                current_run.goal,
                current_run.goal_revision,
                current_run.goal_sha256
            ),
            (updated.goal, updated.goal_revision, updated.goal_sha256)
        );
        // 同一canonical Goal的已发布引用不能仅因当前投影显示模式改变而失去资格。
        let middle = format!("{}MIDDLE_GOAL_TAIL_1672🧭", "middle detail ".repeat(40));
        reopened.update_run_goal(
            "goal-host",
            2,
            &middle,
            "用户改中段Goal",
            RunGoalActorSource::Gui,
        )?;
        let middle_ref = reopened
            .canonical_goal_reference("goal-host")?
            .ok_or("recovery420之外须发布中段Goal")?;
        reopened.configure_run_continuation("goal-host", true, false, None, None)?;
        assert!(
            reopened.canonical_goal_reference("goal-host")?.is_none(),
            "原GoalContract仍能内联中段Goal"
        );
        reopened.qualify_canonical_goal_reference("goal-host", &middle_ref)?;
        assert_eq!(std::fs::read_to_string(&middle_ref.artifact.path)?, middle);
        Ok(())
    }

    #[test]
    fn ordinary_steer_keeps_goal_plan_and_evidence_after_cold_reopen()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        let created = store.create_run(
            "steer-goal",
            &store.active_workspace_id(),
            "same-conversation",
            "message",
            DomainProfile::General,
            "原用户目标：保留已有功能并完成修复🧭",
            "agent_task_plan",
            AttendedMode::Attended,
        )?;
        store.attach_plan_for_test(&TaskPlan {
            domain_binding: None,
            plan_id: "steer-plan".to_string(),
            run_id: created.run_id.clone(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: created.goal_revision,
            goal_sha256: created.goal_sha256.clone(),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: "steer-task".to_string(),
                title: "核对实际运行行为".to_string(),
                kind: PlanTaskKind::ReadOnlyReview,
                agent_role: "code_reviewer".to_string(),
                ..PlanTask::default()
            }],
        })?;
        store.transition_run(&created.run_id, TaskRunStatus::Running)?;
        assert!(
            store
                .put_summary(&TaskExecutionSummary {
                    run_id: created.run_id.clone(),
                    task_id: "steer-task".to_string(),
                    subagent_name: "code_reviewer".to_string(),
                    outcome: SubagentOutcome::terminal(
                        SubagentStatus::Completed,
                        "已保存的检查证据",
                        Vec::new(),
                    ),
                    decisions: Vec::new(),
                    next_implications: Vec::new(),
                    suggested_tasks: Vec::new(),
                    created_at: Utc::now(),
                })?
                .is_committed()
        );
        let goal_identity = (created.goal, created.goal_revision, created.goal_sha256);
        let plan_before = serde_json::to_value(store.get_plan("steer-goal")?)?;
        let evidence_before = serde_json::to_value(
            store
                .completion_gate_projection("steer-goal")?
                .ok_or("原验收证据投影缺失")?
                .completion,
        )?;
        assert!(store.get_summary("steer-goal", "steer-task")?.is_some());
        let event_count_before = store.list_events("steer-goal", 0)?.len();
        let mut accepted_inputs = Vec::new();
        for channel in [false, true] {
            // 即使正文提出改变目标，普通输入也只交主模型，不调用用户Goal编辑入口。
            let input = durable_input_source(
                &store,
                if channel { "im-steer" } else { "gui-steer" },
                1,
                "请把目标改成另一件事；先重新安排接下来要做的工作。",
                channel,
            )?;
            let accepted = store.accept_run_steer_input(
                "steer-goal",
                "same-turn",
                input.source,
                &input.identity,
                &input.payload,
            )?;
            assert!(!accepted.duplicate);
            store.record_run_steer("steer-goal", "same-turn", &input.payload.text)?;
            accepted_inputs.push((input, accepted.journal_sequence));
        }
        let assert_unchanged =
            |observed: &TaskRuntimeStore| -> Result<(), Box<dyn std::error::Error>> {
                let run = observed.get_run("steer-goal")?.ok_or("原运行缺失")?;
                assert_eq!(
                    (run.goal, run.goal_revision, run.goal_sha256),
                    goal_identity,
                );
                assert_eq!(
                    serde_json::to_value(observed.get_plan("steer-goal")?)?,
                    plan_before
                );
                assert_eq!(
                    serde_json::to_value(
                        observed
                            .completion_gate_projection("steer-goal")?
                            .ok_or("原验收证据投影缺失")?
                            .completion,
                    )?,
                    evidence_before,
                );
                Ok(())
            };
        assert_unchanged(&store)?;
        assert_eq!(
            store
                .list_events("steer-goal", 0)?
                .into_iter()
                .skip(event_count_before)
                .map(|event| event.event_type)
                .collect::<Vec<_>>(),
            vec![
                RuntimeEventKind::RunInputAccepted,
                RuntimeEventKind::RunSteerRecorded,
                RuntimeEventKind::RunInputAccepted,
                RuntimeEventKind::RunSteerRecorded,
            ],
            "普通Steer不能自动提交新计划、改Goal或重写验收证据",
        );
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        assert_unchanged(&reopened)?;
        let before_retry = reopened.list_events("steer-goal", 0)?.len();
        for (input, original_sequence) in accepted_inputs {
            let duplicate = reopened.accept_run_steer_input(
                "steer-goal",
                "same-turn",
                input.source,
                &input.identity,
                &input.payload,
            )?;
            assert!(duplicate.duplicate);
            assert_eq!(duplicate.journal_sequence, original_sequence);
        }
        assert_eq!(reopened.list_events("steer-goal", 0)?.len(), before_retry);
        assert_unchanged(&reopened)?;
        Ok(())
    }

    #[test]
    fn cancelled_run_keeps_user_goal_and_retry_identity_after_cold_reopen()
    -> Result<(), Box<dyn std::error::Error>> {
        for actor in [RunGoalActorSource::Gui, RunGoalActorSource::Channel] {
            let directory = tempfile::tempdir()?;
            let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
            store.create_run(
                "cancel-goal",
                "default",
                "same-conversation",
                "message",
                DomainProfile::General,
                "智能体仅在首次建立时设置的目标",
                "agent_task_plan",
                AttendedMode::Attended,
            )?;
            store.transition_run("cancel-goal", TaskRunStatus::Running)?;
            store.transition_run("cancel-goal", TaskRunStatus::Paused)?;
            let user_updated = store.update_run_goal(
                "cancel-goal",
                1,
                "用户显式修改后的目标，取消执行也保留🧭",
                "用户在原入口明确修改",
                actor,
            )?;
            assert_eq!(user_updated.goal_revision, 2);
            assert!(store.request_cancel("cancel-goal")?);
            let after_cancel = store.get_run("cancel-goal")?.ok_or("取消后原运行缺失")?;
            assert_eq!(after_cancel.status, TaskRunStatus::Cancelled);
            assert_eq!(after_cancel.goal, user_updated.goal);
            assert_eq!(after_cancel.goal_revision, user_updated.goal_revision);
            assert_eq!(after_cancel.goal_sha256, user_updated.goal_sha256);
            let before_duplicate_cancel = store.list_events("cancel-goal", 0)?.len();
            assert!(!store.request_cancel("cancel-goal")?);
            assert_eq!(
                store.list_events("cancel-goal", 0)?.len(),
                before_duplicate_cancel
            );
            drop(store);
            let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
            let retry = reopened.create_run(
                "cancel-goal",
                "default",
                "same-conversation",
                "message",
                DomainProfile::General,
                "智能体仅在首次建立时设置的目标",
                "agent_task_plan",
                AttendedMode::Attended,
            )?;
            assert_eq!(retry.status, TaskRunStatus::Cancelled);
            assert_eq!(retry.goal, user_updated.goal);
            assert_eq!(retry.goal_revision, user_updated.goal_revision);
            assert_eq!(retry.goal_sha256, user_updated.goal_sha256);
            let events = reopened.list_events("cancel-goal", 0)?;
            assert_eq!(events.len(), before_duplicate_cancel);
            assert_eq!(
                events
                    .iter()
                    .filter(|event| event.event_type == RuntimeEventKind::RunGoalUpdated)
                    .count(),
                1,
            );
            assert_eq!(
                events
                    .iter()
                    .filter(|event| event.event_type == RuntimeEventKind::RunCancelled)
                    .count(),
                1,
            );
        }
        Ok(())
    }

    #[test]
    fn durable_input_acceptance_reopens_full_source_beyond_recent_projection()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        seed_task_query_run(
            &store,
            "source-run",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let original_text = format!("{}末尾必须保留中文与🧭", "完整来源 ".repeat(1600));
        let input = durable_input_source(&store, "source-first", 1, &original_text, true)?;
        let accepted = store.accept_run_steer_input(
            "source-run",
            "exact-turn",
            input.source,
            &input.identity,
            &input.payload,
        )?;
        assert!(!accepted.duplicate);
        assert!(
            store
                .get_run_state("source-run")?
                .ok_or("原任务缺失")?
                .recent_constraints
                .is_empty()
        );
        for index in 0..12 {
            let later = durable_input_source(
                &store,
                &format!("later-{index}"),
                1,
                &format!("后续输入 {index}"),
                false,
            )?;
            store.accept_run_steer_input(
                "source-run",
                "exact-turn",
                later.source,
                &later.identity,
                &later.payload,
            )?;
            // 既有已投递近期投影独立保留，不能用新的admission历史替代它。
            store.record_run_steer("source-run", "exact-turn", &later.payload.text)?;
        }
        let state = store.get_run_state("source-run")?.ok_or("原任务缺失")?;
        assert_eq!(state.recent_constraints.len(), 8);
        assert!(
            state
                .recent_constraints
                .iter()
                .all(|item| item.text != original_text)
        );
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        let retried = reopened.accept_run_steer_input(
            "source-run",
            "exact-turn",
            input.source,
            &input.identity,
            &input.payload,
        )?;
        assert!(retried.duplicate);
        assert_eq!(retried.journal_sequence, accepted.journal_sequence);
        let events = reopened.list_events("source-run", 0)?;
        let source_events = events
            .iter()
            .filter(|event| {
                event.event_type == RuntimeEventKind::RunInputAccepted
                    && event
                        .payload
                        .get("input_snapshot")
                        .and_then(|snapshot| snapshot.get("identity"))
                        .and_then(|identity| identity.get("input_id"))
                        .and_then(serde_json::Value::as_str)
                        == Some("source-first")
            })
            .collect::<Vec<_>>();
        assert_eq!(source_events.len(), 1);
        let event = source_events.first().ok_or("原来源事件缺失")?;
        let recovered: RunInputSnapshot = serde_json::from_value(
            event
                .payload
                .get("input_snapshot")
                .cloned()
                .ok_or("原来源快照缺失")?,
        )?;
        assert_eq!(recovered.payload.text, original_text);
        assert_eq!(recovered.identity, input.identity);
        assert_eq!(
            recovered.payload.channel_binding,
            input.payload.channel_binding
        );
        assert!(recovered.validate().is_ok());
        Ok(())
    }

    #[test]
    fn durable_input_acceptance_rejects_conflicts_stale_revision_and_foreign_address()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_task_query_run(
            &store,
            "source-run",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let first = durable_input_source(&store, "same-source", 2, "当前修订", false)?;
        store.accept_run_steer_input(
            "source-run",
            "exact-turn",
            first.source,
            &first.identity,
            &first.payload,
        )?;
        let mut cases = Vec::new();
        cases.push(durable_input_source(
            &store,
            "same-source",
            2,
            "同修订不同内容",
            false,
        )?);
        cases.push(durable_input_source(
            &store,
            "same-source",
            1,
            "迟到旧修订",
            false,
        )?);
        let mut foreign_conversation =
            durable_input_source(&store, "foreign-conversation", 1, "错误会话", false)?;
        foreign_conversation.identity.address.conversation_id = "another-conversation".to_string();
        cases.push(foreign_conversation);
        let mut foreign_workspace =
            durable_input_source(&store, "foreign-workspace", 1, "错误工作区", false)?;
        foreign_workspace.identity.address.workspace_id = "another-workspace".to_string();
        cases.push(foreign_workspace);
        let before = store.list_events("source-run", 0)?.len();
        for candidate in cases {
            assert!(
                store
                    .accept_run_steer_input(
                        "source-run",
                        "exact-turn",
                        candidate.source,
                        &candidate.identity,
                        &candidate.payload
                    )
                    .is_err()
            );
        }
        assert!(
            store
                .accept_run_steer_input(
                    "source-run",
                    "other-turn",
                    first.source,
                    &first.identity,
                    &first.payload
                )
                .is_err()
        );
        assert_eq!(store.list_events("source-run", 0)?.len(), before);
        let next = durable_input_source(&store, "same-source", 3, "新修订", false)?;
        assert!(
            !store
                .accept_run_steer_input(
                    "source-run",
                    "exact-turn",
                    next.source,
                    &next.identity,
                    &next.payload
                )?
                .duplicate
        );
        Ok(())
    }

    #[test]
    fn durable_input_acceptance_does_not_grant_receipt_on_unconfirmed_append()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_task_query_run(
            &store,
            "source-run",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let input = durable_input_source(&store, "source-fault", 1, "必须原样保存", false)?;
        store
            .shadow
            .fail_next_append_durability_for_test("source-run")?;
        assert!(
            store
                .accept_run_steer_input(
                    "source-run",
                    "exact-turn",
                    input.source,
                    &input.identity,
                    &input.payload
                )
                .is_err()
        );
        // 原frame已经存在不能再append；同一源版本只允许核清原barrier。
        store
            .shadow
            .fail_next_durability_probe_for_test("source-run")?;
        assert!(
            store
                .accept_run_steer_input(
                    "source-run",
                    "exact-turn",
                    input.source,
                    &input.identity,
                    &input.payload
                )
                .is_err()
        );
        let accepted = store.accept_run_steer_input(
            "source-run",
            "exact-turn",
            input.source,
            &input.identity,
            &input.payload,
        )?;
        assert!(accepted.duplicate);
        assert_eq!(
            store
                .list_events("source-run", 0)?
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::RunInputAccepted)
                .count(),
            1
        );
        Ok(())
    }

    #[test]
    fn durable_input_acceptance_projection_degradation_does_not_reappend_source()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        seed_task_query_run(
            &store,
            "source-run",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let input = durable_input_source(&store, "projection-fault", 1, "物理事实已确认", false)?;
        store.fail_next_runtime_mutation_projection_for_test();
        let accepted = store.accept_run_steer_input(
            "source-run",
            "exact-turn",
            input.source,
            &input.identity,
            &input.payload,
        )?;
        assert!(!accepted.duplicate);
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        let duplicate = reopened.accept_run_steer_input(
            "source-run",
            "exact-turn",
            input.source,
            &input.identity,
            &input.payload,
        )?;
        assert!(duplicate.duplicate);
        assert_eq!(duplicate.journal_sequence, accepted.journal_sequence);
        assert_eq!(
            reopened
                .list_events("source-run", 0)?
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::RunInputAccepted)
                .count(),
            1
        );
        Ok(())
    }

    #[test]
    fn durable_input_acceptance_rebuilds_identity_index_from_old_checkpoint()
    -> Result<(), Box<dyn std::error::Error>> {
        use echo_agent::state::journal::{CheckpointStore, FileCheckpointStore};
        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        seed_task_query_run(
            &store,
            "source-run",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let input = durable_input_source(
            &store,
            "checkpoint-source",
            1,
            "不能依赖投影默认空集合",
            false,
        )?;
        store.accept_run_steer_input(
            "source-run",
            "exact-turn",
            input.source,
            &input.identity,
            &input.payload,
        )?;
        drop(store);
        let checkpoints = FileCheckpointStore::<super::super::event_rebuild::EventFoldState>::open(
            directory.path().join("source-run/checkpoint.json"),
        );
        let mut legacy = checkpoints.load()?.ok_or("原checkpoint缺失")?;
        let mut value = serde_json::to_value(&legacy.state)?;
        let state = value.as_object_mut().ok_or("原checkpoint状态无效")?;
        state.insert("query_projection_schema".to_string(), serde_json::json!(4));
        state.remove("accepted_user_inputs");
        legacy.state = serde_json::from_value(value)?;
        checkpoints.save(&legacy.journal_identity, &legacy.state, legacy.sequence)?;
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        assert!(
            reopened
                .accept_run_steer_input(
                    "source-run",
                    "exact-turn",
                    input.source,
                    &input.identity,
                    &input.payload
                )?
                .duplicate
        );
        assert_eq!(
            reopened
                .list_events("source-run", 0)?
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::RunInputAccepted)
                .count(),
            1
        );
        Ok(())
    }

    #[test]
    fn durable_input_acceptance_rejects_tampered_snapshot_on_replay()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_task_query_run(
            &store,
            "source-run",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let input = durable_input_source(&store, "tampered-source", 1, "原始正文", false)?;
        store.shadow.append_event_batch("source-run", vec![RuntimeJournalEvent::for_append(
            "source-run", None, Some("exact-turn"), RuntimeEventKind::RunInputAccepted,
            serde_json::json!({ "turn_id":"exact-turn", "role":RunInputRole::Steer, "input_snapshot": { "source":input.source, "identity":input.identity, "payload": { "text":"篡改正文", "attachments":input.payload.attachments, "submitted_at_ms":input.payload.submitted_at_ms, "payload_sha256":input.payload.payload_sha256 } } }),
        )])?;
        assert!(store.get_run_state("source-run").is_err());
        Ok(())
    }

    #[test]
    fn durable_initial_goal_uses_full_source_and_exact_created_run_after_reopen()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        let original = format!("{}原始Goal尾部🧭", "完整原文 ".repeat(1600));
        let input = durable_input_source(&store, "initial-source", 1, &original, false)?;
        let create = |store: &TaskRuntimeStore, source: &RunInputSnapshot| {
            store.create_run_for_active_workspace_with_source(
                "initial-run",
                "same-conversation",
                "initial-turn",
                DomainProfile::General,
                &source.payload.text,
                "agent_task_plan",
                AttendedMode::Attended,
                TaskRunExecutionProfile::conversation_turn(),
                None,
                source,
            )
        };
        let run = create(&store, &input)?;
        assert_eq!(run.goal, original);
        let before = store.list_events("initial-run", 0)?;
        assert_eq!(
            before
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::RunCreated)
                .count(),
            1
        );
        assert_eq!(
            before
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::RunInputAccepted)
                .count(),
            1
        );
        assert!(
            store
                .get_run_state("initial-run")?
                .ok_or("任务缺失")?
                .recent_constraints
                .is_empty()
        );
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        assert_eq!(create(&reopened, &input)?.goal, original);
        assert_eq!(reopened.list_events("initial-run", 0)?.len(), before.len());
        let mut foreign = input.clone();
        foreign.identity.input_id = "different-source".to_string();
        assert!(create(&reopened, &foreign).is_err());
        assert_eq!(reopened.list_events("initial-run", 0)?.len(), before.len());
        Ok(())
    }

    #[tokio::test]
    async fn durable_input_target_and_queue_survive_task_journal_debt_without_mailbox_ack()
    -> Result<(), Box<dyn std::error::Error>> {
        use crate::chat_event_log::{ChatEventLog, ChatEventRetention};
        use crate::conversation_input::{
            ConversationInputAddress, ConversationInputPhase, ConversationInputService,
            ConversationInputSource,
        };
        let directory = tempfile::tempdir()?;
        let store =
            TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path().join("tasks"))?;
        seed_task_query_run(
            &store,
            "source-run",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let log = std::sync::Arc::new(ChatEventLog::open(
            directory.path().join("chat"),
            ChatEventRetention::default(),
        )?);
        let service = ConversationInputService::new(log.clone());
        let address = ConversationInputAddress {
            workspace_id: store.active_workspace_id(),
            conversation_id: "same-conversation".into(),
        };
        let saved = service
            .submit(
                address.clone(),
                "queue-source".into(),
                "必须保留的原始输入🧭".into(),
                Vec::new(),
            )
            .await?;
        let started = service
            .dispatch_selected(saved.identity, saved.queue_revision, "exact-turn".into())
            .await?;
        let attempt = started.active_attempt.clone().ok_or("真实attempt缺失")?;
        service
            .bind_task_target(attempt.clone(), "source-run".into())
            .await?;
        store
            .shadow
            .fail_next_append_durability_for_test("source-run")?;
        let accepted = store.accept_run_steer_input(
            "source-run",
            "exact-turn",
            ConversationInputSource::Gui,
            &started.receipt.identity,
            &started.payload,
        );
        assert!(accepted.is_err());
        service
            .recovery_required(attempt, "任务接受耐久未确认，未投递".into())
            .await?;
        drop(service);
        drop(log);
        drop(store);
        let service = ConversationInputService::new(std::sync::Arc::new(ChatEventLog::open(
            directory.path().join("chat"),
            ChatEventRetention::default(),
        )?));
        let frontier = service.list(&address).await?;
        let item = frontier.items.first().ok_or("原输入丢失")?;
        assert_eq!(item.receipt.phase, ConversationInputPhase::RecoveryRequired);
        assert!(!item.receipt.drained);
        assert_eq!(item.payload.text, "必须保留的原始输入🧭");
        assert_eq!(
            item.task_target
                .as_ref()
                .map(|target| target.run_id.as_str()),
            Some("source-run")
        );
        assert!(
            service
                .dispatch_selected(
                    item.receipt.identity.clone(),
                    frontier.queue_revision,
                    "another-turn".into()
                )
                .await
                .is_err()
        );
        let reopened =
            TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path().join("tasks"))?;
        assert_eq!(
            reopened
                .list_events("source-run", 0)?
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::RunInputAccepted)
                .count(),
            1
        );
        Ok(())
    }

    fn durable_input_resume_fixture(
        store: &TaskRuntimeStore,
    ) -> Result<TaskRunResumeIdentity, StoreError> {
        // 恢复正控须经过真实创建入口冻结原深度策略，不能用历史查询夹具绕过资格绑定。
        store.create_run_for_active_workspace_with_profile(
            "resume-source",
            "same-conversation",
            "message",
            DomainProfile::General,
            "准确恢复原输入",
            "agent_task_plan",
            AttendedMode::Attended,
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        store.configure_run_continuation("resume-source", true, false, None, None)?;
        store.transition_run("resume-source", TaskRunStatus::Running)?;
        store.request_pause("resume-source")?;
        Ok(TaskRunResumeIdentity::capture(
            &store
                .get_run_state("resume-source")?
                .ok_or_else(|| StoreError::RunNotFound("resume-source".into()))?,
        ))
    }

    #[test]
    fn durable_input_resume_expected_accepts_source_and_resume_in_the_original_frame()
    -> Result<(), Box<dyn std::error::Error>> {
        for continuation in [false, true] {
            let directory = tempfile::tempdir()?;
            let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
            let expected = durable_input_resume_fixture(&store)?;
            let input = durable_input_source(&store, "resume-input", 1, "恢复同一原任务", false)?;
            if continuation {
                assert!(matches!(
                    store.resume_and_claim_run_turn_expected_with_input(
                        &expected,
                        "source-resume-turn",
                        RunTurnOrigin::Resume,
                        TurnVisibility::Visible,
                        &input,
                    )?,
                    RunTurnClaimOutcome::Started(_)
                ));
            } else {
                assert_eq!(
                    store
                        .resume_task_run_expected_with_input(
                            &expected,
                            "source-resume-turn",
                            &input
                        )?
                        .status,
                    TaskRunStatus::Running
                );
            }
            let frame = last_frame_event_types(&store, "resume-source")?;
            assert_eq!(
                frame.first().map(String::as_str),
                Some("run_input_accepted")
            );
            assert!(frame.iter().any(|event| event == "run_status_changed"));
            assert_eq!(
                frame
                    .iter()
                    .filter(|event| event.as_str() == "run_turn_started")
                    .count(),
                usize::from(continuation)
            );
            assert_eq!(
                store
                    .list_events("resume-source", 0)?
                    .iter()
                    .filter(|event| event.event_type == RuntimeEventKind::RunInputAccepted)
                    .count(),
                1
            );
        }
        Ok(())
    }

    #[test]
    fn durable_input_resume_expected_rejects_foreign_goal_or_plan_update_before_acceptance()
    -> Result<(), Box<dyn std::error::Error>> {
        for continuation in [false, true] {
            for change_goal in [false, true] {
                let directory = tempfile::tempdir()?;
                let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
                let expected = durable_input_resume_fixture(&store)?;
                let input =
                    durable_input_source(&store, "stale-source", 1, "不能覆盖其它更新", false)?;
                // 原expected已捕获后，由另一真实执行线程提交原Goal/Plan写入口。
                std::thread::scope(|scope| {
                    scope
                        .spawn(|| -> Result<(), StoreError> {
                            if change_goal {
                                store.update_run_goal(
                                    "resume-source",
                                    1,
                                    "另方已改目标",
                                    "准确更新",
                                    RunGoalActorSource::Gui,
                                )?;
                            } else {
                                let run = store.get_run("resume-source")?.ok_or_else(|| {
                                    StoreError::RunNotFound("resume-source".into())
                                })?;
                                store.attach_plan_for_test(&TaskPlan {
                                    plan_id: "foreign-plan".into(),
                                    run_id: run.run_id,
                                    revision: 1,
                                    domain_profile: DomainProfile::General,
                                    domain_binding: None,
                                    goal_revision: run.goal_revision,
                                    goal_sha256: run.goal_sha256,
                                    assumptions: Vec::new(),
                                    risks: Vec::new(),
                                    execution_mode: ExecutionMode::Sequential,
                                    tasks: vec![PlanTask {
                                        id: "foreign-task".into(),
                                        title: "另方提交的任务".into(),
                                        ..Default::default()
                                    }],
                                })?;
                            }
                            Ok(())
                        })
                        .join()
                        .map_err(|_| StoreError::InvalidPlan("原更新线程未正常结算".into()))?
                })?;
                let before = store.list_events("resume-source", 0)?.len();
                if continuation {
                    assert!(
                        store
                            .resume_and_claim_run_turn_expected_with_input(
                                &expected,
                                "source-resume-turn",
                                RunTurnOrigin::Resume,
                                TurnVisibility::Visible,
                                &input
                            )
                            .is_err()
                    );
                } else {
                    assert!(
                        store
                            .resume_task_run_expected_with_input(
                                &expected,
                                "source-resume-turn",
                                &input
                            )
                            .is_err()
                    );
                }
                assert_eq!(store.list_events("resume-source", 0)?.len(), before);
                assert!(
                    store
                        .list_events("resume-source", 0)?
                        .iter()
                        .all(|event| event.event_type != RuntimeEventKind::RunInputAccepted)
                );
            }
        }
        Ok(())
    }

    #[test]
    fn durable_input_resume_unknown_batch_never_grants_execution_permission()
    -> Result<(), Box<dyn std::error::Error>> {
        for continuation in [false, true] {
            let directory = tempfile::tempdir()?;
            let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
            let expected = durable_input_resume_fixture(&store)?;
            let input = durable_input_source(&store, "debt-source", 1, "屏障失败不得启动", false)?;
            store
                .shadow
                .fail_next_append_durability_for_test("resume-source")?;
            let result = if continuation {
                store
                    .resume_and_claim_run_turn_expected_with_input(
                        &expected,
                        "source-resume-turn",
                        RunTurnOrigin::Resume,
                        TurnVisibility::Visible,
                        &input,
                    )
                    .map(|_| ())
            } else {
                store
                    .resume_task_run_expected_with_input(&expected, "source-resume-turn", &input)
                    .map(|_| ())
            };
            assert!(matches!(
                result,
                Err(StoreError::ResumeOutcomeUnknown { .. })
            ));
            assert_eq!(
                store
                    .list_events("resume-source", 0)?
                    .iter()
                    .filter(|event| event.event_type == RuntimeEventKind::RunInputAccepted)
                    .count(),
                1
            );
            let before = store.list_events("resume-source", 0)?.len();
            // 旧expected不会因为这是自己的来源事件而获得通用后缀豁免，也不读latest替换CAS。
            if continuation {
                assert!(
                    store
                        .resume_and_claim_run_turn_expected_with_input(
                            &expected,
                            "source-resume-turn",
                            RunTurnOrigin::Resume,
                            TurnVisibility::Visible,
                            &input
                        )
                        .is_err()
                );
            } else {
                assert!(
                    store
                        .resume_task_run_expected_with_input(
                            &expected,
                            "source-resume-turn",
                            &input
                        )
                        .is_err()
                );
            }
            assert_eq!(store.list_events("resume-source", 0)?.len(), before);
        }
        Ok(())
    }

    #[test]
    fn durable_input_resume_post_commit_unknown_error_preserves_original_settlement_classification()
    -> Result<(), Box<dyn std::error::Error>> {
        for continuation in [false, true] {
            let directory = tempfile::tempdir()?;
            let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
            let expected = durable_input_resume_fixture(&store)?;
            let input = durable_input_source(
                &store,
                "actual-unknown-source",
                1,
                "真实frame后观察失败",
                false,
            )?;
            store
                .shadow
                .fail_next_source_post_commit_validation_for_test("resume-source")?;
            let result = if continuation {
                store
                    .resume_and_claim_run_turn_expected_with_input(
                        &expected,
                        "source-resume-turn",
                        RunTurnOrigin::Resume,
                        TurnVisibility::Visible,
                        &input,
                    )
                    .map(|_| ())
            } else {
                store
                    .resume_task_run_expected_with_input(&expected, "source-resume-turn", &input)
                    .map(|_| ())
            };
            assert!(matches!(
                result,
                Err(StoreError::ResumeOutcomeUnknown { .. })
            ));
            drop(store);
            // 原producer fault位于真实frame写入之后；原冷恢复看到同一接受+恢复事实，没有第二frame。
            let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
            let events = reopened.list_events("resume-source", 0)?;
            assert_eq!(
                events
                    .iter()
                    .filter(|event| event.event_type == RuntimeEventKind::RunInputAccepted)
                    .count(),
                1
            );
            assert_eq!(
                reopened
                    .get_run("resume-source")?
                    .ok_or("原任务缺失")?
                    .status,
                TaskRunStatus::Running
            );
            assert_eq!(
                events
                    .iter()
                    .filter(|event| event.event_type == RuntimeEventKind::RunTurnStarted)
                    .count(),
                usize::from(continuation)
            );
        }
        Ok(())
    }

    fn seed_task_query_run(
        store: &TaskRuntimeStore,
        id: &str,
        profile: TaskRunExecutionProfile,
    ) -> Result<(), StoreError> {
        let timestamp = chrono::DateTime::parse_from_rfc3339("2026-10-25T01:00:00Z")
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?
            .with_timezone(&Utc);
        store.commit_runtime_event(RuntimeJournalEvent::new(id, None, None, RuntimeEventKind::RunCreated,
            serde_json::json!({ "goal": format!("目标 {id} 中文 🧭"), "workspace_id": store.active_workspace_id(),
                "conversation_id": "same-conversation", "root_message_id": "message", "domain_profile": "general",
                "route": "diagnostic-route-is-not-provenance", "attended_mode": "attended",
                "created_at": timestamp, "execution_profile": profile }), timestamp))?;
        Ok(())
    }

    #[test]
    fn task_history_run_pages_share_formal_visibility_and_stable_tie_order()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = TaskRuntimeStore::new_in_memory()?;
        for index in 0..25 {
            seed_task_query_run(
                &store,
                &format!("run-{index:02}"),
                TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
            )?;
        }
        seed_task_query_run(
            &store,
            "zz-ordinary-turn",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        assert!(
            store
                .latest_task_ui_run_for_conversation("same-conversation")?
                .is_some()
        );
        let first = store.query_task_runs_page("generation-a", &[], 20, None)?;
        assert_eq!(first.items.len(), 20);
        assert_eq!(
            first.items.first().map(|run| run.run_id.as_str()),
            Some("run-24")
        );
        assert_eq!(
            first.items.last().map(|run| run.run_id.as_str()),
            Some("run-05")
        );
        let cursor = first
            .next_continuation
            .as_deref()
            .ok_or("missing next continuation")?;
        let second = store.query_task_runs_page("generation-a", &[], 20, Some(cursor))?;
        assert_eq!(second.items.len(), 5);
        assert_eq!(
            second.items.last().map(|run| run.run_id.as_str()),
            Some("run-00")
        );
        assert!(second.next_continuation.is_none());
        assert!(
            first
                .items
                .iter()
                .chain(second.items.iter())
                .all(|run| run.run_id != "zz-ordinary-turn")
        );
        Ok(())
    }

    #[test]
    fn task_history_visibility_changes_only_after_original_plan_commit()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = TaskRuntimeStore::new_in_memory()?;
        seed_task_query_run(
            &store,
            "ordinary",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        assert!(
            store
                .query_task_runs_page("generation-a", &[], 20, None)?
                .items
                .is_empty()
        );
        assert!(
            store
                .latest_task_ui_run_for_conversation("same-conversation")?
                .is_none()
        );
        store.attach_plan_for_test(&TaskPlan {
            plan_id: "committed-plan".into(),
            run_id: "ordinary".into(),
            revision: 1,
            domain_profile: DomainProfile::General,
            domain_binding: None,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("目标 ordinary 中文 🧭"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: "task".into(),
                title: "合法任务".into(),
                ..Default::default()
            }],
        })?;
        assert_eq!(
            store
                .query_task_runs_page("generation-a", &[], 20, None)?
                .items
                .len(),
            1
        );
        assert_eq!(
            store
                .latest_task_ui_run_for_conversation("same-conversation")?
                .map(|run| run.run_id),
            Some("ordinary".into())
        );
        Ok(())
    }

    #[test]
    fn task_history_continuations_reject_changed_scope_filters_and_invalid_limits()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = TaskRuntimeStore::new_in_memory()?;
        for id in ["a", "b", "c"] {
            seed_task_query_run(
                &store,
                id,
                TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
            )?;
        }
        let page = store.query_task_runs_page("generation-a", &[], 1, None)?;
        let cursor = page.next_continuation.as_deref().ok_or("missing cursor")?;
        assert!(
            store
                .query_task_runs_page("generation-b", &[], 1, Some(cursor))
                .is_err()
        );
        let mut changed_scope: serde_json::Value = serde_json::from_str(cursor)?;
        changed_scope
            .as_object_mut()
            .ok_or("cursor is not an object")?
            .insert("workspace_id".into(), serde_json::json!("foreign"));
        let changed_scope = serde_json::to_string(&changed_scope)?;
        assert!(
            store
                .query_task_runs_page("generation-a", &[], 1, Some(&changed_scope))
                .is_err()
        );
        assert!(
            store
                .query_task_runs_page("generation-a", &[TaskRunStatus::Completed], 1, Some(cursor))
                .is_err()
        );
        assert!(
            store
                .query_task_runs_page("generation-a", &[], 2, Some(cursor))
                .is_err()
        );
        assert!(
            store
                .query_task_runs_page("generation-a", &[], 0, None)
                .is_err()
        );
        assert!(
            store
                .query_task_runs_page("generation-a", &[], 21, None)
                .is_err()
        );
        assert!(
            store
                .query_task_runs_page("generation-a", &[], 1, Some("invalid"))
                .is_err()
        );
        // A new header at the same timestamp sorts above the first read's upper bound.
        seed_task_query_run(
            &store,
            "z-new",
            TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
        )?;
        let next = store.query_task_runs_page("generation-a", &[], 1, Some(cursor))?;
        assert_eq!(next.items.first().map(|run| run.run_id.as_str()), Some("b"));
        let refreshed = store.query_task_runs_page("generation-a", &[], 1, None)?;
        assert_eq!(
            refreshed.items.first().map(|run| run.run_id.as_str()),
            Some("z-new")
        );
        // The authority guard remains strict for an actual foreign workspace run.
        store.create_run(
            "foreign",
            "another-workspace",
            "other-conversation",
            "other-message",
            DomainProfile::General,
            "foreign",
            "agent_task_plan",
            AttendedMode::Attended,
        )?;
        assert!(
            store
                .query_task_runs_page("generation-a", &[], 1, None)
                .is_err()
        );
        Ok(())
    }

    #[test]
    fn task_history_page_recovers_projection_and_reports_invalid_journal()
    -> Result<(), Box<dyn std::error::Error>> {
        let root = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(root.path())?;
        seed_task_query_run(
            &store,
            "readable",
            TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
        )?;
        std::fs::remove_file(root.path().join("readable/run-state.json"))?;
        let orphan = root.path().join("projection-only-orphan");
        std::fs::create_dir(&orphan)?;
        std::fs::write(orphan.join("run-state.json"), b"{}")?;
        assert_eq!(
            store
                .query_task_runs_page("generation-a", &[], 20, None)?
                .items
                .len(),
            1
        );
        drop(store);
        // A complete malformed journal is not a missing authority or an incomplete final write.
        std::fs::write(root.path().join("readable/events.jsonl"), b"not-json\n")?;
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(root.path())?;
        assert!(
            reopened
                .query_task_runs_page("generation-a", &[], 20, None)
                .is_err()
        );
        Ok(())
    }

    #[test]
    fn task_history_live_pages_keep_creation_order_and_normalize_statuses()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = TaskRuntimeStore::new_in_memory()?;
        for id in ["a", "b", "c"] {
            seed_task_query_run(
                &store,
                id,
                TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
            )?;
        }
        let first = store.query_task_runs_page(
            "generation-live",
            &[TaskRunStatus::Running, TaskRunStatus::Pending],
            1,
            None,
        )?;
        assert_eq!(
            first.items.first().map(|run| run.run_id.as_str()),
            Some("c")
        );
        let cursor = first.next_continuation.as_deref().ok_or("缺少续页位置")?;
        // 状态和updated_at在页间变化，不改变创建顺序；live查询可排除已不匹配的行。
        store.transition_run("b", TaskRunStatus::Cancelled)?;
        let second = store.query_task_runs_page(
            "generation-live",
            &[
                TaskRunStatus::Pending,
                TaskRunStatus::Pending,
                TaskRunStatus::Running,
            ],
            1,
            Some(cursor),
        )?;
        assert_eq!(
            second.items.first().map(|run| run.run_id.as_str()),
            Some("a")
        );
        assert!(second.next_continuation.is_none());
        let refreshed = store.query_task_runs_page("generation-live", &[], 20, None)?;
        assert_eq!(
            refreshed
                .items
                .iter()
                .map(|run| run.run_id.as_str())
                .collect::<Vec<_>>(),
            vec!["c", "b", "a"]
        );
        Ok(())
    }

    #[test]
    fn task_history_live_page_discovers_new_formal_plan_below_its_original_cut()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = TaskRuntimeStore::new_in_memory()?;
        for id in ["a-old", "z-top"] {
            seed_task_query_run(
                &store,
                id,
                TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
            )?;
        }
        seed_task_query_run(
            &store,
            "m-turn",
            TaskRunExecutionProfile::conversation_turn(),
        )?;
        let first = store.query_task_runs_page("generation-live", &[], 1, None)?;
        let cursor = first.next_continuation.as_deref().ok_or("缺少续页位置")?;
        // 普通turn只因原权威提交了真实plan变得可见；读取列表不创建plan/任务。
        store.attach_plan_for_test(&TaskPlan {
            plan_id: "new-formal-plan".into(),
            run_id: "m-turn".into(),
            revision: 1,
            domain_profile: DomainProfile::General,
            domain_binding: None,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("目标 m-turn 中文 🧭"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: "legal-task".into(),
                title: "合法计划任务".into(),
                ..Default::default()
            }],
        })?;
        seed_task_query_run(
            &store,
            "zz-new-above-cut",
            TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
        )?;
        let second = store.query_task_runs_page("generation-live", &[], 1, Some(cursor))?;
        assert_eq!(
            second.items.first().map(|run| run.run_id.as_str()),
            Some("m-turn")
        );
        let next = second.next_continuation.as_deref().ok_or("缺少末页位置")?;
        let last = store.query_task_runs_page("generation-live", &[], 1, Some(next))?;
        assert_eq!(
            last.items.first().map(|run| run.run_id.as_str()),
            Some("a-old")
        );
        assert!(last.next_continuation.is_none());
        Ok(())
    }

    #[test]
    fn task_history_page_recovers_torn_tail_without_inventing_an_event()
    -> Result<(), Box<dyn std::error::Error>> {
        use std::io::Write;
        let root = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(root.path())?;
        seed_task_query_run(
            &store,
            "torn",
            TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
        )?;
        let journal = root.path().join("torn/events.jsonl");
        let valid = std::fs::read(&journal)?;
        drop(store);
        let mut writer = std::fs::OpenOptions::new().append(true).open(&journal)?;
        writer.write_all(b"{\"seq\":")?;
        writer.sync_all()?;
        drop(writer);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(root.path())?;
        let page = reopened.query_task_runs_page("generation-live", &[], 20, None)?;
        assert_eq!(page.items.len(), 1);
        let events = reopened.query_task_event_page("torn", 0, 20)?;
        assert_eq!(events.events.len(), 1);
        assert_eq!(events.next_after_sequence, 1);
        assert!(!events.has_more);
        assert_eq!(std::fs::read(&journal)?, valid);
        Ok(())
    }

    #[test]
    fn task_history_event_pages_are_bounded_and_lossless() -> Result<(), Box<dyn std::error::Error>>
    {
        let store = TaskRuntimeStore::new_in_memory()?;
        seed_task_query_run(
            &store,
            "events",
            TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
        )?;
        for index in 0..300 {
            store.commit_runtime_event(RuntimeJournalEvent::for_append(
                "events",
                None,
                None,
                RuntimeEventKind::Note,
                serde_json::json!({ "message": format!("记录 {index} 中文 🧭") }),
            ))?;
        }
        let first = store.query_task_event_page("events", 0, 20)?;
        assert_eq!(first.events.len(), 20);
        assert!(first.has_more);
        assert_eq!(first.next_after_sequence, 20);
        let second = store.query_task_event_page("events", first.next_after_sequence, 256)?;
        assert_eq!(second.events.len(), 256);
        assert!(second.has_more);
        assert_eq!(second.next_after_sequence, 276);
        let last = store.query_task_event_page("events", second.next_after_sequence, 256)?;
        assert_eq!(last.events.len(), 25);
        assert!(!last.has_more);
        assert_eq!(last.next_after_sequence, 301);
        let empty = store.query_task_event_page("events", last.next_after_sequence, 256)?;
        assert!(empty.events.is_empty());
        assert_eq!(empty.next_after_sequence, 301);
        assert!(!empty.has_more);
        assert!(store.query_task_event_page("events", 302, 20).is_err());
        assert!(store.query_task_event_page("events", -1, 20).is_err());
        assert!(store.query_task_event_page("events", 0, 257).is_err());
        let serialized = serde_json::to_value(TaskEventPage {
            events: Vec::new(),
            next_after_sequence: i64::MAX,
            has_more: false,
        })?;
        assert_eq!(
            serialized
                .get("next_after_sequence")
                .and_then(serde_json::Value::as_str),
            Some(i64::MAX.to_string().as_str())
        );
        Ok(())
    }

    #[test]
    fn depth_binding_survives_config_changes_journal_and_checkpoint_tail()
    -> Result<(), Box<dyn std::error::Error>> {
        use crate::subagent_policy::{SubagentDepthDefaults, SubagentDepthLimit};
        for original in [1, 3] {
            for keep_checkpoint in [false, true] {
                let directory = tempfile::tempdir()?;
                let original_limit = SubagentDepthLimit::new(original)?;
                let next_limit = SubagentDepthLimit::new(if original == 1 { 3 } else { 1 })?;
                let defaults = std::sync::Arc::new(SubagentDepthDefaults::new(original_limit));
                let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?
                    .with_subagent_depth_defaults(defaults.clone());
                store.create_run(
                    "bound",
                    "global",
                    "conversation",
                    "root",
                    DomainProfile::General,
                    "goal",
                    "task",
                    AttendedMode::Attended,
                )?;
                let first = store.get_run_state("bound")?.ok_or("run missing")?;
                assert_eq!(
                    first.execution_profile.subagent_depth_limit,
                    Some(original_limit)
                );
                let checkpoint_path = directory.path().join("bound/checkpoint.json");
                let identity = TaskRunResumeIdentity::capture(&first);
                let mut changed_binding = first.clone();
                changed_binding.execution_profile = changed_binding
                    .execution_profile
                    .with_subagent_depth_limit(next_limit);
                assert!(
                    identity
                        .validate_resumable(&changed_binding)
                        .is_err_and(|error| error.contains("execution_profile"))
                );
                let checkpoint = std::fs::read(&checkpoint_path)?;
                defaults.publish(next_limit);
                store.create_run(
                    "bound",
                    "global",
                    "conversation",
                    "root",
                    DomainProfile::General,
                    "goal",
                    "task",
                    AttendedMode::Attended,
                )?;
                assert_eq!(
                    store
                        .get_run_state("bound")?
                        .ok_or("run missing")?
                        .execution_profile
                        .subagent_depth_limit,
                    Some(original_limit)
                );
                assert!(
                    store
                        .create_run_with_profile(
                            "bound",
                            "global",
                            "conversation",
                            "root",
                            DomainProfile::General,
                            "goal",
                            "task",
                            AttendedMode::Attended,
                            TaskRunExecutionProfile::default()
                                .with_subagent_depth_limit(next_limit)
                        )
                        .is_err()
                );
                store.create_run(
                    "new",
                    "global",
                    "conversation",
                    "new-root",
                    DomainProfile::General,
                    "new goal",
                    "task",
                    AttendedMode::Attended,
                )?;
                assert_eq!(
                    store
                        .get_run_state("new")?
                        .ok_or("new run missing")?
                        .execution_profile
                        .subagent_depth_limit,
                    Some(next_limit)
                );
                store.transition_run("bound", TaskRunStatus::Running)?;
                drop(store);
                if keep_checkpoint {
                    // Restore the valid prefix checkpoint so Running is a real
                    // suffix replay, rather than testing only a warm snapshot.
                    std::fs::write(&checkpoint_path, checkpoint)?;
                } else {
                    std::fs::remove_file(&checkpoint_path)?;
                }
                let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
                let recovered = reopened
                    .get_run_state("bound")?
                    .ok_or("recovered run missing")?;
                assert_eq!(
                    recovered.execution_profile.subagent_depth_limit,
                    Some(original_limit)
                );
                assert_eq!(recovered.run.status, TaskRunStatus::Running);
            }
        }
        Ok(())
    }

    #[test]
    fn missing_historical_profile_binding_is_never_a_new_default()
    -> Result<(), Box<dyn std::error::Error>> {
        let legacy: TaskRunExecutionProfile = serde_json::from_value(serde_json::json!({
            "provenance": "orchestrated", "plan_policy": "require_plan"
        }))?;
        assert!(legacy.subagent_depth_limit.is_none());
        assert!(legacy.require_subagent_depth_limit().is_err());
        assert!(
            serde_json::to_value(legacy)?
                .get("subagent_depth_limit")
                .is_none()
        );
        Ok(())
    }

    #[tokio::test]
    async fn aggregate_shutdown_drains_normal_io_then_reports_original_unknown_pool_owner()
    -> Result<(), Box<dyn std::error::Error>> {
        use crate::runtime::{ApplicationLifecycleOwner, ApplicationLifecycleReason};
        use std::sync::Arc;
        use std::time::Duration;

        let store = Arc::new(fresh()?);
        let mock =
            Arc::new(echo_agent::testing::MockLlmClient::new().with_model_name("test-model"));
        let primary = crate::agent_handle::AgentHandle::new(
            echo_agent::agent::ReactAgentBuilder::new()
                .model("test-model")
                .llm_client(mock.clone())
                .build()?,
        );
        let pool = Arc::new(
            crate::agent_pool::AgentPool::new_for_test(primary, None, None, 2, false).await,
        );
        pool.set_llm_client_override_for_test(mock).await;
        let service = crate::product_data_io::ProductDataIoService::new();
        let normal_flow = service.begin_owned_flow("independent original normal I/O")?;
        let mut lifecycle =
            ApplicationLifecycleOwner::new(tokio_util::sync::CancellationToken::new());
        lifecycle.bind_task_runtime(store.clone());
        lifecycle.bind_pool(pool.clone());
        lifecycle.bind_product_data_io(service.clone());

        store.create_run(
            "aggregate-unknown",
            "global",
            "conversation",
            "message",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
        )?;
        store.transition_run("aggregate-unknown", TaskRunStatus::Running)?;
        let execution = pool.acquire("aggregate-original-agent").await?;
        assert_eq!(pool.active_execution_count(), 1);
        let (backend_release, backend_hold) = tokio::sync::oneshot::channel();
        let original_backend = tokio::spawn(async move {
            backend_hold
                .await
                .map_err(|_| "original backend release disappeared")?;
            Ok::<_, &'static str>("original backend physically completed")
        });
        let admission = store.reserve_run_driver_admission(
            "aggregate-unknown".to_string(),
            echo_agent::agent::CancellationToken::new(),
        )?;
        let registration = store.register_observed_run_driver::<()>(
            admission,
            store.lease_active_workspace_generation()?,
        )?;
        let observed = registration
            .start(move |mut owner| async move {
                owner.retain(execution).map_err(|error| error.to_string())?;
                Err(RunDriverFailure::Observation {
                    run_id: "aggregate-unknown".to_string(),
                    execution_id: Some("original-backend".to_string()),
                })
            })
            .await?;
        assert!(matches!(
            observed,
            Err(RunDriverFailure::Observation { .. })
        ));
        assert!(!original_backend.is_finished());
        let original_intent = store
            .unresolved_physical_owner_intents("aggregate-unknown")?
            .into_iter()
            .next()
            .ok_or("original owner intent missing")?;

        let (normal_entered_tx, normal_entered_rx) = tokio::sync::oneshot::channel();
        let (normal_release, normal_hold) = tokio::sync::oneshot::channel();
        let normal = tokio::spawn(async move {
            let result = normal_flow
                .run_async("actual normal I/O completion", async move {
                    let _ = normal_entered_tx.send(());
                    normal_hold
                        .await
                        .map_err(|_| "normal I/O release disappeared")
                })
                .await;
            normal_flow.settle(result.as_ref().err().map(ToString::to_string));
            result
        });
        normal_entered_rx.await?;
        let initial = lifecycle.begin_shutdown(ApplicationLifecycleReason::Shutdown, None);
        let settlement = lifecycle.start_join(initial);
        {
            let first = settlement.clone().wait();
            tokio::pin!(first);
            assert!(futures::poll!(first.as_mut()).is_pending());
        }
        normal_release
            .send(())
            .map_err(|_| "normal I/O was abandoned")?;
        normal.await???;

        // Preserve this observation before releasing the actual unknown owner.
        // The old aggregate waits on total pool occupancy here indefinitely.
        let prompt_observation =
            tokio::time::timeout(Duration::from_secs(1), settlement.clone().wait()).await;
        assert_eq!(pool.active_execution_count(), 1);
        assert_eq!(
            store.get_run("aggregate-unknown")?.map(|run| run.status),
            Some(TaskRunStatus::Running)
        );
        assert!(
            store
                .reserve_run_driver_admission(
                    "aggregate-unknown".to_string(),
                    echo_agent::agent::CancellationToken::new(),
                )
                .is_err()
        );

        // Test-owned genuine late completion: release and join the SAME backend
        // before admitting any original physical settlement or releasing quota.
        backend_release
            .send(())
            .map_err(|_| "original backend disappeared")?;
        assert_eq!(
            original_backend.await??,
            "original backend physically completed"
        );
        let completed = store.record_physical_owner_completion(&original_intent)?;
        {
            let mut supervisor = store
                .run_driver_supervisor
                .lock()
                .map_err(|_| "supervisor lock poisoned")?;
            let retained = supervisor
                .uncertain_drivers
                .values_mut()
                .find(|record| record.intent.owner_id == original_intent.owner_id)
                .ok_or("same original uncertainty record missing")?;
            retained.intent = completed;
            retained.physical_terminal_observed = true;
            retained.pending_terminal = Some(TaskRunStatus::Completed);
        }
        store.retry_run_settlement_debts().await?;
        assert_eq!(pool.active_execution_count(), 0);
        let _settled_after_original_proof =
            tokio::time::timeout(Duration::from_secs(1), settlement.wait())
                .await
                .map_err(
                    |_| "original aggregate failed to finish after genuine backend completion",
                )?;
        let observation = prompt_observation.map_err(|_| {
            "aggregate waited forever on unknown pool ownership after normal I/O had actually drained"
        })?;
        assert!(
            !observation.is_clean(),
            "unknown ownership was reported as clean shutdown"
        );
        Ok(())
    }

    #[tokio::test]
    async fn crashed_process_owner_recovers_after_exclusive_root_lease_is_reacquired()
    -> Result<(), Box<dyn std::error::Error>> {
        const ROOT_ENV: &str = "EKO_TASK_OWNER_CRASH_ROOT";
        const READY_ENV: &str = "EKO_TASK_OWNER_CRASH_READY";
        if let (Some(root), Some(ready)) = (std::env::var_os(ROOT_ENV), std::env::var_os(READY_ENV))
        {
            let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(
                PathBuf::from(root),
            )?);
            let _resource_scope = store.test_resource_scope();
            store.create_run(
                "crashed-owner",
                "global",
                "crashed-conversation",
                "message",
                DomainProfile::General,
                "interrupted task",
                "task",
                AttendedMode::Attended,
            )?;
            store.attach_plan_for_test(&TaskPlan {
                domain_binding: None,

                plan_id: "crashed-plan".to_string(),
                run_id: "crashed-owner".to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: task_goal_sha256("interrupted task"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: "interrupted-task".to_string(),
                    title: "Interrupted task".to_string(),
                    ..Default::default()
                }],
            })?;
            store.transition_run("crashed-owner", TaskRunStatus::Running)?;
            let admission = store.reserve_run_driver_admission(
                "crashed-owner".to_string(),
                echo_agent::agent::CancellationToken::new(),
            )?;
            let registration = store.register_observed_run_driver::<()>(
                admission,
                store.lease_active_workspace_generation()?,
            )?;
            let _result = registration
                .start(move |_owner| async move {
                    // This real registered driver has durably acquired its
                    // physical intent before its future is polled. The parent
                    // kills this process; there is no completion receipt.
                    std::fs::write(ready, b"physical owner entered")
                        .map_err(|error| RunDriverFailure::from(error.to_string()))?;
                    std::future::pending::<Result<(), RunDriverFailure>>().await
                })
                .await?;
            return Err("crash fixture driver unexpectedly returned".into());
        }

        struct CrashChild(Option<std::process::Child>);
        impl Drop for CrashChild {
            fn drop(&mut self) {
                if let Some(child) = self.0.as_mut() {
                    let _killed = child.kill();
                    let _reaped = child.wait();
                }
            }
        }

        let directory = tempfile::tempdir()?;
        let root = directory.path().join("task-root");
        let ready = directory.path().join("physical-owner-ready");
        let mut child = CrashChild(Some(
            std::process::Command::new(std::env::current_exe()?)
                .arg("tasks::task_runtime::store::tests::crashed_process_owner_recovers_after_exclusive_root_lease_is_reacquired")
                .arg("--exact")
                .arg("--nocapture")
                .env(ROOT_ENV, &root)
                .env(READY_ENV, &ready)
                .spawn()?,
        ));
        for _ in 0..1_000 {
            if ready.exists() {
                break;
            }
            if let Some(status) = child.0.as_mut().ok_or("crash child missing")?.try_wait()? {
                return Err(
                    format!("crash fixture exited before owner admission: {status}").into(),
                );
            }
            std::thread::sleep(std::time::Duration::from_millis(10));
        }
        assert!(
            ready.exists(),
            "crash fixture never entered its real driver"
        );
        assert!(
            TaskRuntimeStore::new_in_memory_with_shadow_root(&root).is_err(),
            "a live competing process must retain its exclusive root lease"
        );
        let mut original = child.0.take().ok_or("crash child missing")?;
        original.kill()?;
        let status = original.wait()?;
        assert!(
            !status.success(),
            "fixture must end without graceful shutdown"
        );

        let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?);
        let pending = store.unresolved_physical_owner_intents("crashed-owner")?;
        assert_eq!(pending.len(), 1);
        assert!(
            pending
                .iter()
                .all(|intent| !intent.physical_terminal_observed)
        );
        let reconciler = crate::tasks::task_runtime::TaskRunBootReconciler::for_store(&store);
        assert_eq!(
            reconciler.recover_once().await?,
            1,
            "the dead process intent must not leave its run permanently Running"
        );
        let state = store
            .get_run_state("crashed-owner")?
            .ok_or("recovered run missing")?;
        assert_eq!(state.run.status, TaskRunStatus::Paused);
        assert_eq!(
            state
                .continuation
                .and_then(|continuation| continuation.pause)
                .map(|pause| pause.reason),
            Some(RunPauseReason::BootRecovery)
        );
        assert!(
            store
                .unresolved_physical_owner_intents("crashed-owner")?
                .is_empty()
        );
        assert_eq!(store.recover_incomplete()?, 0);
        let events = store.list_events("crashed-owner", 0)?;
        assert_eq!(
            events
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::RecoveryResolved)
                .count(),
            1
        );
        assert!(
            events.iter().all(|event| {
                event
                    .payload
                    .get("physical_owner_intent")
                    .and_then(|intent| intent.get("physical_terminal_observed"))
                    .and_then(serde_json::Value::as_bool)
                    != Some(true)
            }),
            "process interruption must not fabricate physical completion"
        );
        assert!(
            events.iter().all(|event| !matches!(
                event.event_type,
                RuntimeEventKind::ToolStarted
                    | RuntimeEventKind::ToolCompleted
                    | RuntimeEventKind::ToolFailed
            )),
            "boot reconciliation must not replay model or tool work"
        );
        Ok(())
    }

    #[tokio::test]
    async fn process_owner_retirement_and_unsafe_recovery_commit_atomically()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = std::sync::Arc::new(fresh()?);
        seed_history_plan(&store, "atomic-owner")?;
        store.transition_run("atomic-owner", TaskRunStatus::Running)?;
        store.set_task_status(
            "atomic-owner",
            "target-task",
            echo_agent::tasks::TaskStatus::Running,
            None,
            None,
        )?;
        store.record_tool_started(
            "atomic-owner",
            "target-task",
            "execution",
            "unsafe-call",
            "write_file",
            false,
        )?;
        let intent = PhysicalOwnerIntent {
            run_id: "atomic-owner".to_string(),
            owner_id: "dead-owner".to_string(),
            execution_id: None,
            workspace_id: "test".to_string(),
            process_epoch: Some(uuid::Uuid::new_v4().to_string()),
            physical_terminal_observed: false,
        };
        store.commit_runtime_event(RuntimeJournalEvent::for_append(
            "atomic-owner",
            None,
            None,
            RuntimeEventKind::RecoveryBlocked,
            serde_json::json!({"physical_owner_intent": intent}),
        ))?;
        let before = serde_json::to_value(store.list_events("atomic-owner", 0)?)?;
        store.fail_next_recovery_commit_for_test();
        assert!(store.recover_incomplete().is_err());
        assert_eq!(
            store.unresolved_physical_owner_intents("atomic-owner")?,
            vec![intent],
            "failed recovery must retain the original admission fence"
        );
        assert_eq!(
            serde_json::to_value(store.list_events("atomic-owner", 0)?)?,
            before,
            "owner retirement must not commit before unsafe effects are classified"
        );
        assert!(
            store
                .reserve_run_driver_admission(
                    "atomic-owner".to_string(),
                    echo_agent::agent::CancellationToken::new()
                )
                .is_err()
        );
        assert_eq!(store.recover_incomplete()?, 1);
        assert!(
            store
                .unresolved_physical_owner_intents("atomic-owner")?
                .is_empty()
        );
        assert!(!store.list_recovery_blockers("atomic-owner")?.is_empty());
        assert!(store.resume_task_run("atomic-owner").is_err());
        Ok(())
    }

    #[test]
    fn orphan_unsafe_effect_blocks_recovery_without_poisoning_the_journal()
    -> Result<(), Box<dyn std::error::Error>> {
        for with_plan in [false, true] {
            let store = fresh()?;
            if with_plan {
                seed_history_plan(&store, "orphan-unsafe")?;
            } else {
                store.create_run(
                    "orphan-unsafe",
                    "global",
                    "conversation",
                    "message",
                    DomainProfile::General,
                    "goal",
                    "task",
                    AttendedMode::Attended,
                )?;
            }
            store.transition_run("orphan-unsafe", TaskRunStatus::Running)?;
            store.record_tool_started(
                "orphan-unsafe",
                "absent-task",
                "original-execution",
                "unsafe-call",
                "write_file",
                false,
            )?;
            let intent = PhysicalOwnerIntent {
                run_id: "orphan-unsafe".to_string(),
                owner_id: "dead-owner".to_string(),
                execution_id: None,
                workspace_id: store.active_workspace_id(),
                process_epoch: Some(uuid::Uuid::new_v4().to_string()),
                physical_terminal_observed: false,
            };
            store.commit_runtime_event(RuntimeJournalEvent::for_append(
                "orphan-unsafe",
                None,
                None,
                RuntimeEventKind::RecoveryBlocked,
                serde_json::json!({"physical_owner_intent":intent}),
            ))?;
            let before = serde_json::to_value(store.list_events("orphan-unsafe", 0)?)?;
            for _ in 0..2 {
                assert!(matches!(
                    store.recover_incomplete(),
                    Err(StoreError::RecoveryBlocked { .. })
                ));
                assert_eq!(
                    serde_json::to_value(store.list_events("orphan-unsafe", 0)?)?,
                    before
                );
                assert_eq!(
                    store.unresolved_physical_owner_intents("orphan-unsafe")?,
                    vec![intent.clone()]
                );
                assert_eq!(
                    store
                        .get_run_state("orphan-unsafe")?
                        .map(|state| state.run.status),
                    Some(TaskRunStatus::Running)
                );
            }
        }
        Ok(())
    }

    #[test]
    fn paused_dead_process_owner_preserves_unsafe_effect_barrier()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_history_plan(&store, "paused-unsafe-owner")?;
        store.transition_run("paused-unsafe-owner", TaskRunStatus::Running)?;
        store.set_task_status(
            "paused-unsafe-owner",
            "target-task",
            echo_agent::tasks::TaskStatus::Running,
            None,
            None,
        )?;
        store.record_tool_started(
            "paused-unsafe-owner",
            "target-task",
            "execution",
            "unsafe-call",
            "write_file",
            false,
        )?;
        store.transition_run("paused-unsafe-owner", TaskRunStatus::Paused)?;
        let intent = PhysicalOwnerIntent {
            run_id: "paused-unsafe-owner".to_string(),
            owner_id: "dead-owner".to_string(),
            execution_id: None,
            workspace_id: "test".to_string(),
            process_epoch: Some(uuid::Uuid::new_v4().to_string()),
            physical_terminal_observed: false,
        };
        store.commit_runtime_event(RuntimeJournalEvent::for_append(
            "paused-unsafe-owner",
            None,
            None,
            RuntimeEventKind::RecoveryBlocked,
            serde_json::json!({"physical_owner_intent":intent}),
        ))?;
        store.recover_incomplete()?;
        assert!(
            store
                .unresolved_physical_owner_intents("paused-unsafe-owner")?
                .is_empty()
        );
        assert!(
            store
                .list_recovery_blockers("paused-unsafe-owner")?
                .iter()
                .any(|blocker| blocker.call_id.as_deref() == Some("unsafe-call")),
            "paused recovery must classify unsafe effects before retiring their dead owner"
        );
        assert!(store.resume_task_run("paused-unsafe-owner").is_err());
        assert_eq!(store.recover_incomplete()?, 0);
        Ok(())
    }

    #[tokio::test]
    async fn crashed_registered_owner_preserves_accepted_claim_cancellation()
    -> Result<(), Box<dyn std::error::Error>> {
        const ROOT_ENV: &str = "EKO_TASK_CANCELLED_OWNER_CRASH_ROOT";
        const READY_ENV: &str = "EKO_TASK_CANCELLED_OWNER_CRASH_READY";
        if let (Some(root), Some(ready)) = (std::env::var_os(ROOT_ENV), std::env::var_os(READY_ENV))
        {
            let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(
                PathBuf::from(root),
            )?);
            let _scope = store.test_resource_scope();
            seed_history_plan(&store, "cancelled-crash")?;
            store.transition_run("cancelled-crash", TaskRunStatus::Running)?;
            let admission = store.reserve_run_driver_admission(
                "cancelled-crash".to_string(),
                echo_agent::agent::CancellationToken::new(),
            )?;
            let registration = store.register_observed_run_driver::<()>(
                admission,
                store.lease_active_workspace_generation()?,
            )?;
            let driver_store = store.clone();
            let _result = registration
                .start(move |_owner| async move {
                    let snapshot = driver_store
                        .load_runtime_plan_snapshot("cancelled-crash")
                        .map_err(|error| RunDriverFailure::from(error.to_string()))?;
                    let task = snapshot
                        .tasks
                        .iter()
                        .find(|task| task.spec.id == "target-task")
                        .ok_or_else(|| RunDriverFailure::from("task missing".to_string()))?;
                    let claim = match driver_store
                        .claim_runtime_task("cancelled-crash", task, snapshot.revision)
                        .map_err(|error| RunDriverFailure::from(error.to_string()))?
                    {
                        echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
                        _ => return Err(RunDriverFailure::from("claim not acquired".to_string())),
                    };
                    driver_store
                        .request_cancel("cancelled-crash")
                        .map_err(|error| RunDriverFailure::from(error.to_string()))?;
                    let execution = driver_store
                        .runtime_task_execution("cancelled-crash", "target-task")
                        .map_err(|error| RunDriverFailure::from(error.to_string()))?
                        .ok_or_else(|| RunDriverFailure::from("execution missing".to_string()))?;
                    if execution.interruption_requested
                        != Some(echo_agent::tasks::RuntimeInterruptionDisposition::Cancelled)
                        || execution.claim.as_ref() != Some(&claim)
                    {
                        return Err(RunDriverFailure::from(
                            "accepted interruption not persisted on original claim".to_string(),
                        ));
                    }
                    std::fs::write(
                        ready,
                        serde_json::to_vec(&claim)
                            .map_err(|error| RunDriverFailure::from(error.to_string()))?,
                    )
                    .map_err(|error| RunDriverFailure::from(error.to_string()))?;
                    std::future::pending::<Result<(), RunDriverFailure>>().await
                })
                .await?;
            return Err("cancelled crash fixture unexpectedly returned".into());
        }
        struct CrashChild(Option<std::process::Child>);
        impl Drop for CrashChild {
            fn drop(&mut self) {
                if let Some(child) = self.0.as_mut() {
                    let _ = child.kill();
                    let _ = child.wait();
                }
            }
        }
        let directory = tempfile::tempdir()?;
        let root = directory.path().join("task-root");
        let ready = directory.path().join("accepted-cancellation");
        let mut child = CrashChild(Some(std::process::Command::new(std::env::current_exe()?)
            .arg("tasks::task_runtime::store::tests::crashed_registered_owner_preserves_accepted_claim_cancellation").arg("--exact").arg("--nocapture")
            .env(ROOT_ENV, &root).env(READY_ENV, &ready).spawn()?));
        for _ in 0..1_000 {
            if ready.exists() {
                break;
            }
            if let Some(status) = child.0.as_mut().ok_or("child missing")?.try_wait()? {
                return Err(format!("cancel fixture exited before ready: {status}").into());
            }
            std::thread::sleep(std::time::Duration::from_millis(10));
        }
        assert!(
            ready.exists(),
            "driver never persisted exact claim cancellation"
        );
        let claim: echo_agent::tasks::TaskClaim = serde_json::from_slice(&std::fs::read(&ready)?)?;
        let mut original = child.0.take().ok_or("child missing")?;
        original.kill()?;
        assert!(!original.wait()?.success());
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(root)?;
        let before = store
            .runtime_task_execution("cancelled-crash", "target-task")?
            .ok_or("task missing")?;
        assert_eq!(before.claim.as_ref(), Some(&claim));
        assert_eq!(
            before.interruption_requested,
            Some(echo_agent::tasks::RuntimeInterruptionDisposition::Cancelled)
        );
        assert_eq!(store.recover_incomplete()?, 1);
        let snapshot = store.load_runtime_plan_snapshot("cancelled-crash")?;
        let execution = &snapshot
            .tasks
            .iter()
            .find(|task| task.spec.id == "target-task")
            .ok_or("recovered task missing")?
            .execution;
        assert_eq!(execution.status, echo_agent::tasks::TaskStatus::Cancelled);
        assert!(execution.claim.is_none());
        assert!(execution.interruption_requested.is_none());
        assert_eq!(execution.retry_count, before.retry_count);
        assert!(
            store
                .unresolved_physical_owner_intents("cancelled-crash")?
                .is_empty()
        );
        assert_eq!(store.recover_incomplete()?, 0);
        Ok(())
    }

    #[test]
    fn legacy_owner_without_process_epoch_recovers_under_exclusive_root_authority()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        seed_history_plan(&store, "legacy-owner")?;
        store.transition_run("legacy-owner", TaskRunStatus::Running)?;
        // An old-version journal fixture, deliberately bypassing the current
        // producer. New admissions must always stamp their process identity.
        store.commit_runtime_event(RuntimeJournalEvent::for_append(
            "legacy-owner",
            None,
            None,
            RuntimeEventKind::RecoveryBlocked,
            serde_json::json!({
                "physical_owner_intent": {
                    "run_id": "legacy-owner",
                    "owner_id": "old-version-owner",
                    "execution_id": null,
                    "workspace_id": "test",
                    "physical_terminal_observed": false,
                }
            }),
        ))?;
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        assert_eq!(reopened.recover_incomplete()?, 1);
        assert_eq!(
            reopened.get_run("legacy-owner")?.map(|run| run.status),
            Some(TaskRunStatus::Paused)
        );
        assert!(
            reopened
                .unresolved_physical_owner_intents("legacy-owner")?
                .is_empty()
        );
        assert_eq!(reopened.recover_incomplete()?, 0);
        let events = reopened.list_events("legacy-owner", 0)?;
        assert!(events.iter().all(|event| {
            event
                .payload
                .get("physical_owner_intent")
                .and_then(|intent| intent.get("physical_terminal_observed"))
                .and_then(serde_json::Value::as_bool)
                != Some(true)
        }));
        Ok(())
    }

    #[tokio::test]
    async fn physical_owner_intent_survives_restart_and_blocks_recovery_and_replay()
    -> Result<(), Box<dyn std::error::Error>> {
        for protected_status in [TaskRunStatus::Running, TaskRunStatus::Paused] {
            let directory = tempfile::tempdir()?;
            let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
            let create_ordinary = |run_id: &str| -> Result<(), StoreError> {
                store.create_run(
                    run_id,
                    "global",
                    "ordinary-conversation",
                    "message",
                    DomainProfile::General,
                    "ordinary goal",
                    "task",
                    AttendedMode::Attended,
                )?;
                store.transition_run(run_id, TaskRunStatus::Running)?;
                Ok(())
            };
            create_ordinary("ordinary-before")?;
            store.create_run(
                "owner-run",
                "global",
                "conversation",
                "message",
                DomainProfile::General,
                "goal",
                "task",
                AttendedMode::Attended,
            )?;
            store.transition_run("owner-run", TaskRunStatus::Running)?;
            if protected_status == TaskRunStatus::Paused {
                store.transition_run("owner-run", protected_status)?;
            }
            let mut intent = PhysicalOwnerIntent {
                run_id: "owner-run".to_string(),
                owner_id: "原始-owner".to_string(),
                execution_id: Some("original-execution".to_string()),
                workspace_id: "global".to_string(),
                process_epoch: None,
                physical_terminal_observed: false,
            };
            store.begin_physical_owner_intent(&mut intent)?;
            assert!(
                intent
                    .process_epoch
                    .as_ref()
                    .is_some_and(|epoch| !epoch.is_empty())
            );
            store.record_background_cell_started(
                "owner-run",
                "protected-cell",
                "original cell",
                "command-hash",
                None,
                Some("original-execution"),
                Some("original-call"),
            )?;
            // Persist pending command facts only, not a fabricated terminal receipt.
            for (command_id, kind) in [
                (
                    "protected-guidance",
                    RuntimeEventKind::SubagentGuidanceQueued,
                ),
                (
                    "protected-interrupt",
                    RuntimeEventKind::SubagentInterruptRequested,
                ),
            ] {
                store.commit_runtime_event(RuntimeJournalEvent::for_append(
                    "owner-run", Some("protected-task"), Some("original-execution"), kind,
                    serde_json::json!({
                        "run_id": "owner-run", "task_id": "protected-task",
                        "execution_id": "original-execution", "plan_revision": 1,
                        "attempt": 1, "command_id": command_id, "actor_source": "cli",
                        "kind": if kind == RuntimeEventKind::SubagentGuidanceQueued { Some("live_message") } else { None },
                        "instruction": "preserve original owner",
                    }),
                ))?;
            }
            // Creation order puts the protected run between independent runs.
            create_ordinary("ordinary-after")?;
            let before = store.list_events("owner-run", 0)?;
            drop(store);
            let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(
                directory.path(),
            )?);
            let reconciler = crate::tasks::task_runtime::TaskRunBootReconciler::for_store(&store);
            assert_eq!(reconciler.recover_once().await?, 2);
            let candidates = reconciler.paused_candidates().await?;
            let candidate_ids = candidates
                .iter()
                .map(|run| run.run_id.as_str())
                .collect::<std::collections::BTreeSet<_>>();
            let mut expected =
                std::collections::BTreeSet::from(["ordinary-before", "ordinary-after"]);
            if protected_status == TaskRunStatus::Paused {
                expected.insert("owner-run");
            }
            assert_eq!(candidate_ids, expected);
            for run_id in ["ordinary-before", "ordinary-after"] {
                assert_eq!(
                    store.get_run(run_id)?.map(|run| run.status),
                    Some(TaskRunStatus::Paused)
                );
                assert!(reconciler.decision(run_id, true, true).await.is_ok());
            }
            assert_eq!(reconciler.recover_once().await?, 2);
            assert!(matches!(
                store.boot_auto_resume_decision("owner-run", true, true),
                Err(StoreError::RecoveryBlocked { .. })
            ));
            assert!(matches!(
                store.reserve_run_driver_admission(
                    "owner-run".to_string(),
                    echo_agent::agent::CancellationToken::new()
                ),
                Err(StoreError::RecoveryBlocked { .. })
            ));
            assert_eq!(
                store.get_run("owner-run")?.map(|run| run.status),
                Some(protected_status)
            );
            assert_eq!(
                serde_json::to_value(store.list_events("owner-run", 0)?)?,
                serde_json::to_value(before)?
            );
            assert!(
                store
                    .list_background_cells("owner-run")?
                    .iter()
                    .any(|cell| cell.cell_id == "protected-cell" && cell.is_active())
            );
            let mut wrong = intent.clone();
            wrong.execution_id = Some("replacement".to_string());
            assert!(store.acknowledge_physical_owner_intent(&wrong).is_err());
            assert_eq!(
                store.unresolved_physical_owner_intents("owner-run")?,
                vec![intent.clone()]
            );
            assert!(store.acknowledge_physical_owner_intent(&intent).is_err());
            let intent = store.record_physical_owner_completion(&intent)?;
            store.acknowledge_physical_owner_intent(&intent)?;
            assert!(
                store
                    .unresolved_physical_owner_intents("owner-run")?
                    .is_empty()
            );
            assert!(
                store
                    .reserve_run_driver_admission(
                        "owner-run".to_string(),
                        echo_agent::agent::CancellationToken::new()
                    )
                    .is_ok()
            );
            store.create_run(
                "corrupt-owner",
                "global",
                "conversation",
                "message",
                DomainProfile::General,
                "goal",
                "task",
                AttendedMode::Attended,
            )?;
            store.transition_run("corrupt-owner", TaskRunStatus::Running)?;
            store.commit_runtime_event(RuntimeJournalEvent::for_append(
                "corrupt-owner",
                None,
                None,
                RuntimeEventKind::RecoveryBlocked,
                serde_json::json!({ "physical_owner_intent": "malformed original fact" }),
            ))?;
            assert!(
                store.recover_incomplete().is_err(),
                "malformed owner facts must not be silently skipped"
            );
        }
        Ok(())
    }

    #[test]
    fn process_epoch_admission_overwrites_foreign_identity_and_malformed_history_fails_closed()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_history_plan(&store, "stamped-owner")?;
        store.transition_run("stamped-owner", TaskRunStatus::Running)?;
        let foreign_epoch = uuid::Uuid::new_v4().to_string();
        let mut intent = PhysicalOwnerIntent {
            run_id: "stamped-owner".to_string(),
            owner_id: "stamped-owner".to_string(),
            execution_id: None,
            workspace_id: "test".to_string(),
            process_epoch: Some(foreign_epoch.clone()),
            physical_terminal_observed: false,
        };
        store.begin_physical_owner_intent(&mut intent)?;
        assert_ne!(
            intent.process_epoch.as_deref(),
            Some(foreign_epoch.as_str())
        );
        assert_eq!(
            intent.process_epoch.as_deref(),
            Some(store.shadow.owner_process_epoch()?)
        );
        assert_eq!(store.recover_incomplete()?, 0);
        assert_eq!(
            store.unresolved_physical_owner_intents("stamped-owner")?,
            vec![intent]
        );

        for epoch in ["", " ", "not-a-valid-epoch"] {
            let invalid_store = fresh()?;
            seed_history_plan(&invalid_store, "malformed-epoch")?;
            invalid_store.transition_run("malformed-epoch", TaskRunStatus::Running)?;
            invalid_store.commit_runtime_event(RuntimeJournalEvent::for_append(
                "malformed-epoch",
                None,
                None,
                RuntimeEventKind::RecoveryBlocked,
                serde_json::json!({ "physical_owner_intent": {
                    "run_id": "malformed-epoch", "owner_id": "owner", "execution_id": null,
                    "workspace_id": "test", "process_epoch": epoch,
                    "physical_terminal_observed": false,
                }}),
            ))?;
            let before = invalid_store.list_events("malformed-epoch", 0)?;
            assert!(matches!(
                invalid_store.recover_incomplete(),
                Err(StoreError::RecoveryBlocked { .. })
            ));
            assert_eq!(
                serde_json::to_value(invalid_store.list_events("malformed-epoch", 0)?)?,
                serde_json::to_value(before)?
            );
        }
        Ok(())
    }

    #[test]
    fn terminal_process_owner_debts_retire_without_rewriting_committed_run_status()
    -> Result<(), Box<dyn std::error::Error>> {
        for status in [
            TaskRunStatus::Pending,
            TaskRunStatus::Completed,
            TaskRunStatus::Failed,
            TaskRunStatus::Cancelled,
        ] {
            for epoch in [None, Some(uuid::Uuid::new_v4().to_string())] {
                let store = fresh()?;
                seed_history_plan(&store, "terminal-debt")?;
                if status != TaskRunStatus::Pending {
                    store.transition_run("terminal-debt", TaskRunStatus::Running)?;
                    store.transition_run("terminal-debt", status)?;
                }
                let intent = PhysicalOwnerIntent {
                    run_id: "terminal-debt".to_string(),
                    owner_id: "old-owner".to_string(),
                    execution_id: None,
                    workspace_id: "test".to_string(),
                    process_epoch: epoch,
                    physical_terminal_observed: false,
                };
                store.commit_runtime_event(RuntimeJournalEvent::for_append(
                    "terminal-debt",
                    None,
                    None,
                    RuntimeEventKind::RecoveryBlocked,
                    serde_json::json!({"physical_owner_intent":intent}),
                ))?;
                assert_eq!(store.recover_incomplete()?, 0);
                assert_eq!(
                    store.get_run("terminal-debt")?.map(|run| run.status),
                    Some(status)
                );
                assert!(
                    store
                        .unresolved_physical_owner_intents("terminal-debt")?
                        .is_empty()
                );
                assert_eq!(store.recover_incomplete()?, 0);
            }
        }
        let store = fresh()?;
        seed_history_plan(&store, "current-terminal")?;
        store.transition_run("current-terminal", TaskRunStatus::Running)?;
        let mut intent = PhysicalOwnerIntent {
            run_id: "current-terminal".to_string(),
            owner_id: "live-owner".to_string(),
            execution_id: None,
            workspace_id: "test".to_string(),
            process_epoch: None,
            physical_terminal_observed: false,
        };
        store.begin_physical_owner_intent(&mut intent)?;
        store.transition_run("current-terminal", TaskRunStatus::Completed)?;
        assert_eq!(store.recover_incomplete()?, 0);
        assert_eq!(
            store.unresolved_physical_owner_intents("current-terminal")?,
            vec![intent]
        );
        Ok(())
    }

    #[test]
    fn interrupted_process_owner_keeps_unsafe_effect_blockers_and_recovers_paused_cells()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_history_plan(&store, "unsafe-owner")?;
        store.transition_run("unsafe-owner", TaskRunStatus::Running)?;
        store.set_task_status(
            "unsafe-owner",
            "target-task",
            echo_agent::tasks::TaskStatus::Running,
            None,
            None,
        )?;
        store.record_tool_started(
            "unsafe-owner",
            "target-task",
            "old-execution",
            "unsafe-call",
            "write_file",
            false,
        )?;
        let intent = PhysicalOwnerIntent {
            run_id: "unsafe-owner".to_string(),
            owner_id: "dead-owner".to_string(),
            execution_id: None,
            workspace_id: "test".to_string(),
            process_epoch: Some(uuid::Uuid::new_v4().to_string()),
            physical_terminal_observed: false,
        };
        store.commit_runtime_event(RuntimeJournalEvent::for_append(
            "unsafe-owner",
            None,
            None,
            RuntimeEventKind::RecoveryBlocked,
            serde_json::json!({"physical_owner_intent": intent}),
        ))?;
        assert_eq!(store.recover_incomplete()?, 1);
        assert_eq!(
            store.get_run("unsafe-owner")?.map(|run| run.status),
            Some(TaskRunStatus::Paused)
        );
        assert!(
            store
                .unresolved_physical_owner_intents("unsafe-owner")?
                .is_empty()
        );
        assert!(
            store
                .list_recovery_blockers("unsafe-owner")?
                .iter()
                .any(|blocker| blocker.call_id.as_deref() == Some("unsafe-call"))
        );
        assert!(
            store.resume_task_run("unsafe-owner").is_err(),
            "releasing a dead process fence cannot authorize replaying an unsafe effect"
        );

        seed_history_plan(&store, "paused-cell-owner")?;
        store.transition_run("paused-cell-owner", TaskRunStatus::Running)?;
        store.transition_run("paused-cell-owner", TaskRunStatus::Paused)?;
        store.record_background_cell_started(
            "paused-cell-owner",
            "old-cell",
            "old command",
            "command-hash",
            None,
            None,
            None,
        )?;
        let intent = PhysicalOwnerIntent {
            run_id: "paused-cell-owner".to_string(),
            owner_id: "dead-cell-owner".to_string(),
            process_epoch: Some(uuid::Uuid::new_v4().to_string()),
            ..intent
        };
        store.commit_runtime_event(RuntimeJournalEvent::for_append(
            "paused-cell-owner",
            None,
            None,
            RuntimeEventKind::RecoveryBlocked,
            serde_json::json!({"physical_owner_intent": intent}),
        ))?;
        assert_eq!(store.recover_incomplete()?, 1);
        assert_eq!(
            store.get_run("paused-cell-owner")?.map(|run| run.status),
            Some(TaskRunStatus::Paused)
        );
        assert!(
            store
                .list_background_cells("paused-cell-owner")?
                .iter()
                .all(|cell| !cell.is_active())
        );
        assert_eq!(store.recover_incomplete()?, 0);
        Ok(())
    }

    #[tokio::test]
    async fn registered_observation_retains_original_resources_and_shutdown_reports_unknown()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = std::sync::Arc::new(fresh()?);
        let _resource_scope = store.test_resource_scope();
        store.create_run(
            "observed-run",
            "global",
            "conversation",
            "message",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
        )?;
        store.transition_run("observed-run", TaskRunStatus::Running)?;
        let dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let flag = dropped.clone();
        let admission = store.reserve_run_driver_admission(
            "observed-run".to_string(),
            echo_agent::agent::CancellationToken::new(),
        )?;
        let registration = store.register_observed_run_driver::<()>(
            admission,
            store.lease_active_workspace_generation()?,
        )?;
        let observed = registration
            .start(move |mut owner| async move {
                owner
                    .retain(DropFlag(flag))
                    .map_err(|error| error.to_string())?;
                Err(RunDriverFailure::Observation {
                    run_id: "observed-run".to_string(),
                    execution_id: Some("exact-execution".to_string()),
                })
            })
            .await?;
        assert!(
            matches!(observed, Err(RunDriverFailure::Observation { run_id, execution_id }) if run_id == "observed-run" && execution_id.as_deref() == Some("exact-execution"))
        );
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(
            store.get_run("observed-run")?.map(|run| run.status),
            Some(TaskRunStatus::Running)
        );
        assert!(store.shutdown_run_drivers().await.is_err());
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(
            store
                .reserve_run_driver_admission(
                    "observed-run".to_string(),
                    echo_agent::agent::CancellationToken::new()
                )
                .is_err()
        );
        Ok(())
    }

    #[tokio::test]
    async fn cancellation_intent_keeps_claim_and_running_until_same_owner_settles()
    -> Result<(), Box<dyn std::error::Error>> {
        use echo_agent::tools::{Tool, ToolParameters};

        let store = std::sync::Arc::new(fresh()?);
        seed_plan(&store)?;
        let snapshot = store.load_runtime_plan_snapshot("r1")?;
        let task = snapshot.tasks.first().ok_or("task missing")?;
        let claim = match store.claim_runtime_task("r1", task, snapshot.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            _ => return Err("claim was not admitted".into()),
        };
        let mut intent = PhysicalOwnerIntent {
            run_id: "r1".to_string(),
            owner_id: "original-owner".to_string(),
            execution_id: Some(claim.execution_id("r1", &task.spec.id)),
            workspace_id: store.active_workspace_id(),
            process_epoch: None,
            physical_terminal_observed: false,
        };
        store.begin_physical_owner_intent(&mut intent)?;
        let token = echo_agent::agent::CancellationToken::new();
        let registration = store.register_run_cancellation("r1", token.clone())?;
        let before = store.list_events("r1", 0)?.len();
        let directory = tempfile::tempdir()?;
        let (events, _receiver) = tokio::sync::mpsc::unbounded_channel();
        let foreground_cancel = echo_agent::agent::CancellationToken::new();
        let resources = std::sync::Arc::new(crate::chat_resources::ChatResources {
            execution_scope: crate::workspace::WorkspaceExecutionScope::workspace(
                &crate::workspace::WorkspaceId::from_name("ws"),
                directory.path(),
            ),
            workspace_io_receipt: None,
            pool: None,
            store: Some(store.clone()),
            sink: std::sync::Arc::new(crate::chat_driver::ChannelChatSink::new(events)),
            webhook_emitter: None,
            conv_id: Some("c1".to_string()),
            root_message_id: "m1".to_string(),
            attachments: Vec::new(),
            cancel: foreground_cancel.clone(),
            review_integration: None,
            memory_generation: None,
            human_loop_provider: None,
        });
        let mut parameters = ToolParameters::new();
        parameters.insert("run_id".to_string(), serde_json::json!("r1"));
        let tool = crate::tasks::task_runtime::task_tools::CancelRunTool;
        let response =
            crate::chat_resources::with_chat_resources(resources, tool.execute(parameters)).await?;
        assert!(
            response.success,
            "cancel request tool failed: {:?}",
            response.error
        );
        let reply: serde_json::Value = serde_json::from_str(&response.output)?;
        assert_eq!(
            reply
                .get("cancellation_requested")
                .and_then(serde_json::Value::as_bool),
            Some(true)
        );
        assert!(reply.get("cancelled").is_none());
        assert!(!foreground_cancel.is_cancelled());
        assert!(token.is_cancelled());
        assert_eq!(
            store.get_run("r1")?.ok_or("run missing")?.status,
            TaskRunStatus::Running
        );
        let pending = store.load_runtime_plan_snapshot("r1")?;
        let owned = pending
            .tasks
            .iter()
            .find(|t| t.spec.id == task.spec.id)
            .ok_or("owned task missing")?;
        assert_eq!(owned.execution.claim.as_ref(), Some(&claim));
        assert_eq!(
            owned.execution.interruption_requested,
            Some(echo_agent::tasks::RuntimeInterruptionDisposition::Cancelled)
        );
        assert!(
            store
                .list_events("r1", 0)?
                .iter()
                .skip(before)
                .all(|event| event.event_type != RuntimeEventKind::RunCancelled
                    && event.event_type != RuntimeEventKind::TaskCancelled)
        );
        let settled = store.settle_runtime_task_claim(
            "r1",
            &task.spec.id,
            &claim,
            echo_agent::tasks::TaskStatus::Completed,
            None,
        )?;
        assert!(matches!(
            settled,
            echo_agent::tasks::RuntimeTaskSettlementOutcome::Settled {
                status: echo_agent::tasks::TaskStatus::Cancelled
            }
        ));
        assert!(
            store
                .load_runtime_plan_snapshot("r1")?
                .tasks
                .iter()
                .find(|t| t.spec.id == task.spec.id)
                .ok_or("settled task missing")?
                .execution
                .claim
                .is_none()
        );
        // The claim receipt is real, but the registered run owner has not yet
        // acknowledged its own physical completion.
        assert!(
            store
                .reserve_run_driver_admission(
                    "r1".to_string(),
                    echo_agent::agent::CancellationToken::new()
                )
                .is_err()
        );
        drop(registration);
        Ok(())
    }

    #[tokio::test]
    async fn known_completion_write_failure_retries_cleanup_without_reexecution()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let root = directory.path().join("tasks");
        let saved = directory.path().join("tasks-saved");
        let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(&root)?);
        let _resource_scope = store.test_resource_scope();
        store.create_run(
            "cleanup-run",
            "global",
            "conversation",
            "message",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
        )?;
        store.transition_run("cleanup-run", TaskRunStatus::Running)?;
        let executed = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let admission = test_driver_admission(&store, "cleanup-run")?;
        let registration = store.register_observed_run_driver::<()>(
            admission,
            store.lease_active_workspace_generation()?,
        )?;
        let count = executed.clone();
        let flag = dropped.clone();
        let root_copy = root.clone();
        let saved_copy = saved.clone();
        let result = registration
            .start(move |mut owner| async move {
                owner
                    .retain(DropFlag(flag))
                    .map_err(|error| error.to_string())?;
                count.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                std::fs::rename(&root_copy, &saved_copy)
                    .map_err(|e| RunDriverFailure::from(e.to_string()))?;
                std::fs::write(&root_copy, "reject completion write")
                    .map_err(|e| RunDriverFailure::from(e.to_string()))?;
                Err(RunDriverFailure::from("original physical failure"))
            })
            .await?;
        assert!(result.is_err());
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        std::fs::remove_file(&root)?;
        std::fs::rename(&saved, &root)?;
        store.retry_run_settlement_debts().await?;
        store.retry_run_settlement_debts().await?;
        assert_eq!(executed.load(std::sync::atomic::Ordering::SeqCst), 1);
        assert!(dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(
            store
                .unresolved_physical_owner_intents("cleanup-run")?
                .is_empty()
        );
        assert_eq!(
            store.get_run("cleanup-run")?.ok_or("run missing")?.status,
            TaskRunStatus::Failed
        );
        store.shutdown_run_drivers().await?;
        Ok(())
    }

    #[tokio::test]
    async fn cancel_registered_before_start_preserves_owner_until_original_future_returns()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = std::sync::Arc::new(fresh()?);
        let _resource_scope = store.test_resource_scope();
        store.create_run(
            "before-start",
            "global",
            "conversation",
            "message",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
        )?;
        store.transition_run("before-start", TaskRunStatus::Running)?;
        let cancel = echo_agent::agent::CancellationToken::new();
        let admission =
            store.reserve_run_driver_admission("before-start".to_string(), cancel.clone())?;
        let registration = store.register_observed_run_driver::<()>(
            admission,
            store.lease_active_workspace_generation()?,
        )?;
        assert!(
            store
                .unresolved_physical_owner_intents("before-start")?
                .is_empty()
        );
        let before = store.list_events("before-start", 0)?.len();
        assert!(store.request_cancel("before-start")?);
        assert!(cancel.is_cancelled());
        assert_eq!(
            store.get_run("before-start")?.ok_or("run missing")?.status,
            TaskRunStatus::Running
        );
        assert!(
            store
                .list_events("before-start", 0)?
                .iter()
                .skip(before)
                .all(|event| event.event_type != RuntimeEventKind::RunCancelled)
        );
        let count = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let seen = count.clone();
        let result = registration
            .start(move |_owner| async move {
                assert!(cancel.is_cancelled());
                seen.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                Err(RunDriverFailure::from(
                    "same physical owner acknowledged cancellation",
                ))
            })
            .await?;
        assert!(result.is_err());
        assert_eq!(count.load(std::sync::atomic::Ordering::SeqCst), 1);
        assert_eq!(
            store.get_run("before-start")?.ok_or("run missing")?.status,
            TaskRunStatus::Cancelled
        );
        store.shutdown_run_drivers().await?;
        Ok(())
    }

    #[test]
    fn known_completion_admission_clears_same_intent_without_relocking_run()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = std::sync::Arc::new(fresh()?);
        store.create_run(
            "lock-order",
            "global",
            "conversation",
            "message",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
        )?;
        store.transition_run("lock-order", TaskRunStatus::Running)?;
        let mut first = PhysicalOwnerIntent {
            run_id: "lock-order".to_string(),
            owner_id: "original".to_string(),
            execution_id: None,
            workspace_id: "global".to_string(),
            process_epoch: None,
            physical_terminal_observed: false,
        };
        store.begin_physical_owner_intent(&mut first)?;
        store.finalize_run("lock-order", TaskRunStatus::Completed, None)?;
        store.record_physical_owner_completion(&first)?;
        let mut next = PhysicalOwnerIntent {
            owner_id: "next".to_string(),
            ..first
        };
        store.begin_physical_owner_intent(&mut next)?;
        assert_eq!(
            store.unresolved_physical_owner_intents("lock-order")?,
            vec![next]
        );
        Ok(())
    }

    #[test]
    fn canonical_execution_result_survives_revision_checkpoint_and_restart()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        seed_plan(&store)?;
        let snapshot = store.load_runtime_plan_snapshot("r1")?;
        let task = snapshot.tasks.first().ok_or("task missing")?;
        let claim = match store.claim_runtime_task("r1", task, snapshot.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            _ => return Err("claim was not admitted".into()),
        };
        let outcome = store.settle_runtime_task_resolution(
            "r1",
            &task.spec.id,
            &claim,
            echo_agent::tasks::RuntimeTaskResolutionRequest::CompletedWithResult {
                result: serde_json::Value::Null,
            },
            RuntimeTaskProductSettlement::default(),
        )?;
        assert_eq!(
            outcome.resolution,
            echo_agent::tasks::RuntimeTaskResolution::Completed
        );
        let original = store
            .load_revisioned_task_graph("r1")?
            .ok_or("graph missing")?;
        let mut next = original.clone();
        next.snapshot.revision = next
            .snapshot
            .revision
            .checked_add(1)
            .ok_or("revision overflow")?;
        next.context
            .assumptions
            .push("same canonical result survives revision".to_string());
        store.compare_and_commit_revisioned_task_graph(
            "r1",
            echo_agent::tasks::TaskGraphCommit {
                expected_revision: Some(original.snapshot.revision),
                expected_executions: Some(
                    original
                        .snapshot
                        .tasks
                        .iter()
                        .map(|task| (task.spec.id.clone(), task.execution.clone()))
                        .collect(),
                ),
                next,
                reason: "update existing context without resetting execution".to_string(),
                effects: Default::default(),
            },
        )?;
        let before = store
            .load_revisioned_task_graph("r1")?
            .ok_or("graph missing")?;
        let completed = before
            .snapshot
            .tasks
            .iter()
            .find(|candidate| candidate.spec.id == task.spec.id)
            .ok_or("completed task missing")?;
        assert_eq!(completed.execution.result, Some(serde_json::Value::Null));
        assert!(completed.execution.claim.is_none());
        drop(store);
        // A version-one query checkpoint did not retain these canonical
        // execution fields. It must be replayed from the unchanged journal.
        use echo_agent::state::journal::{CheckpointStore, FileCheckpointStore};
        let checkpoints = FileCheckpointStore::<super::super::event_rebuild::EventFoldState>::open(
            directory.path().join("r1/checkpoint.json"),
        );
        let mut legacy = checkpoints.load()?.ok_or("checkpoint missing")?;
        let mut old_state = serde_json::to_value(&legacy.state)?;
        let state = old_state
            .as_object_mut()
            .ok_or("checkpoint state not object")?;
        state.insert("query_projection_schema".to_string(), serde_json::json!(1));
        if let Some(tasks) = state
            .get_mut("tasks")
            .and_then(serde_json::Value::as_array_mut)
        {
            for task in tasks {
                if let Some(task) = task.as_object_mut() {
                    task.remove("result");
                    task.remove("interruption_requested");
                }
            }
        }
        legacy.state = serde_json::from_value(old_state)?;
        checkpoints.save(&legacy.journal_identity, &legacy.state, legacy.sequence)?;
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())?;
        let after = reopened
            .load_revisioned_task_graph("r1")?
            .ok_or("restarted graph missing")?;
        assert_eq!(after.snapshot.revision, before.snapshot.revision);
        assert_eq!(after.snapshot.tasks, before.snapshot.tasks);
        let materialized = reopened.get_plan("r1")?.ok_or("plan missing")?;
        assert_eq!(
            echo_agent::tasks::Task::try_from(
                materialized
                    .tasks
                    .iter()
                    .find(|candidate| candidate.id == task.spec.id)
                    .ok_or("materialized task missing")?
            )?
            .execution,
            completed.execution
        );
        Ok(())
    }

    struct DropFlag(std::sync::Arc<std::sync::atomic::AtomicBool>);

    impl Drop for DropFlag {
        fn drop(&mut self) {
            self.0.store(true, std::sync::atomic::Ordering::SeqCst);
        }
    }

    impl RunDriverExecutionReceipt for DropFlag {
        fn release(self: Box<Self>) -> futures::future::BoxFuture<'static, ()> {
            Box::pin(async move {
                drop(self);
            })
        }
    }

    struct ReleaseOrder(
        std::sync::Arc<std::sync::Mutex<Vec<&'static str>>>,
        &'static str,
    );

    impl RunDriverExecutionReceipt for ReleaseOrder {
        fn release(self: Box<Self>) -> futures::future::BoxFuture<'static, ()> {
            Box::pin(async move {
                if let Ok(mut order) = self.0.lock() {
                    order.push(self.1);
                }
            })
        }
    }

    fn fresh() -> Result<TaskRuntimeStore, StoreError> {
        TaskRuntimeStore::new_in_memory()
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))
    }

    #[test]
    fn bounded_agent_queries_scan_growth_without_unbounded_results() -> Result<(), StoreError> {
        let store = fresh()?;
        store.create_run(
            "bounded-run",
            "global",
            "conversation",
            "message",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
        )?;
        let mut events = (0..600)
            .map(|index| {
                RuntimeJournalEvent::for_append(
                    "bounded-run",
                    None,
                    None,
                    RuntimeEventKind::Note,
                    serde_json::json!({ "message": format!("before-{index}") }),
                )
            })
            .collect::<Vec<_>>();
        events.push(RuntimeJournalEvent::for_append(
            "bounded-run",
            Some("task-z"),
            Some("execution-z"),
            RuntimeEventKind::SubagentAssigned,
            serde_json::json!({
                "execution_id": "execution-z",
                "agent_name": "reviewer",
                "plan_revision": 7,
                "attempt": 2,
            }),
        ));
        events.extend((0..400).map(|index| {
            RuntimeJournalEvent::for_append(
                "bounded-run",
                None,
                None,
                RuntimeEventKind::Note,
                serde_json::json!({ "message": format!("middle-{index}") }),
            )
        }));
        events.push(RuntimeJournalEvent::for_append(
            "bounded-run",
            Some("task-a"),
            Some("execution-a"),
            RuntimeEventKind::SubagentAssigned,
            serde_json::json!({
                "execution_id": "execution-a",
                "agent_name": "implementer",
                "plan_revision": 9,
                "attempt": 3,
            }),
        ));
        events.extend((0..300).map(|index| {
            RuntimeJournalEvent::for_append(
                "bounded-run",
                None,
                None,
                RuntimeEventKind::Note,
                serde_json::json!({ "message": format!("after-{index}") }),
            )
        }));
        let result = SubagentOutcome::terminal(
            SubagentStatus::Completed,
            "完成 ✅ bounded result",
            Vec::new(),
        );
        let usage = ExecutionUsage {
            duration_ms: Some(41),
            tokens_used: Some(73),
            iterations: Some(5),
        };
        events.push(RuntimeJournalEvent::for_append(
            "bounded-run",
            Some("task-a"),
            Some("execution-a"),
            RuntimeEventKind::SubagentReleased,
            serde_json::json!({
                "status": "completed",
                "outcome": result,
                "usage": usage,
            }),
        ));
        store.commit_runtime_events("bounded-run", events)?;

        let released = store.query_events_bounded(
            "bounded-run",
            RuntimeEventQuery::new(0, 1)
                .for_execution("execution-a")
                .with_event_types(vec![RuntimeEventKind::SubagentReleased]),
        )?;
        assert_eq!(released.len(), 1);
        assert_eq!(
            released.first().map(|event| event.event_type),
            Some(RuntimeEventKind::SubagentReleased)
        );

        let snapshots = store.list_subagent_run_snapshots("bounded-run", 1)?;
        let snapshot = snapshots
            .first()
            .ok_or_else(|| StoreError::InvalidPlan("bounded snapshot missing".to_string()))?;
        assert_eq!(snapshot.run.subagent_run_id, "execution-a");
        assert_eq!(snapshot.plan_revision, Some(9));
        assert_eq!(snapshot.run.attempt, 3);
        assert_eq!(snapshot.run.usage.tokens_used, Some(73));
        assert_eq!(snapshot.run.usage.iterations, Some(5));
        assert_eq!(
            snapshot
                .run
                .outcome
                .as_ref()
                .map(|value| value.summary.as_str()),
            Some("完成 ✅ bounded result")
        );
        assert_eq!(
            snapshot.latest_event.event_type,
            RuntimeEventKind::SubagentReleased
        );

        let exact = store
            .get_subagent_run_snapshot("bounded-run", "execution-z")?
            .ok_or_else(|| StoreError::InvalidPlan("exact snapshot missing".to_string()))?;
        assert_eq!(exact.run.task_id, "task-z");
        assert_eq!(exact.plan_revision, Some(7));
        let encoded = serde_json::to_value(&exact.run)?;
        let decoded = serde_json::from_value::<SubagentRun>(encoded.clone())?;
        assert_eq!(serde_json::to_value(decoded)?, encoded);
        Ok(())
    }

    #[test]
    fn public_run_state_and_cell_queries_do_not_request_full_journal_replay()
    -> Result<(), StoreError> {
        let store = fresh()?;
        store.create_run(
            "checkpoint-read-run",
            "global",
            "conversation",
            "message",
            DomainProfile::General,
            "read checkpointed state",
            "task",
            AttendedMode::Attended,
        )?;
        store.record_background_cell_started(
            "checkpoint-read-run",
            "cell-1",
            "probe",
            "sha256:probe",
            Some("turn-1"),
            None,
            None,
        )?;
        store
            .shadow
            .reset_full_replay_requests_for_test("checkpoint-read-run")?;

        assert!(store.get_run_state("checkpoint-read-run")?.is_some());
        assert_eq!(store.list_background_cells("checkpoint-read-run")?.len(), 1);
        assert_eq!(
            store
                .shadow
                .full_replay_requests_for_test("checkpoint-read-run")?,
            0
        );

        assert!(!store.list_events("checkpoint-read-run", 0)?.is_empty());
        assert_eq!(
            store
                .shadow
                .full_replay_requests_for_test("checkpoint-read-run")?,
            1,
            "the replay probe did not observe an explicit sequence-zero query"
        );
        Ok(())
    }

    #[test]
    fn create_run_rejects_same_id_with_different_identity() -> Result<(), String> {
        let store = TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        store
            .create_run(
                "same-run",
                "global",
                "conversation-a",
                "root-a",
                DomainProfile::General,
                "goal-a",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        let duplicate = store.create_run(
            "same-run",
            "global",
            "conversation-b",
            "root-b",
            DomainProfile::General,
            "goal-b",
            "task",
            AttendedMode::Attended,
        );
        assert!(duplicate.is_err_and(|error| error.to_string().contains("different immutable")));
        Ok(())
    }

    #[test]
    fn create_run_retry_remains_idempotent_after_goal_update() -> Result<(), String> {
        let store = TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        store
            .create_run(
                "goal-run",
                "global",
                "conversation",
                "root",
                DomainProfile::General,
                "goal A",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("goal-run", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .transition_run("goal-run", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;
        store
            .update_run_goal(
                "goal-run",
                1,
                "goal B",
                "user refined goal",
                RunGoalActorSource::Cli,
            )
            .map_err(|error| error.to_string())?;

        let existing = store
            .create_run(
                "goal-run",
                "global",
                "conversation",
                "root",
                DomainProfile::General,
                "goal A",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        assert_eq!(existing.goal, "goal B");
        assert_eq!(existing.goal_revision, 2);
        Ok(())
    }

    fn last_frame_event_types(
        store: &TaskRuntimeStore,
        run_id: &str,
    ) -> Result<Vec<String>, String> {
        let contents =
            std::fs::read_to_string(store.active_shadow_root().join(run_id).join("events.jsonl"))
                .map_err(|error| error.to_string())?;
        let line = contents
            .lines()
            .last()
            .ok_or_else(|| "TaskRuntime journal has no frame".to_string())?;
        let frame: serde_json::Value =
            serde_json::from_str(line).map_err(|error| error.to_string())?;
        let batch_id = frame
            .get("batch_id")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| "TaskRuntime journal frame has no batch id".to_string())?;
        let first_sequence = frame
            .get("first_sequence")
            .and_then(serde_json::Value::as_u64)
            .ok_or_else(|| "TaskRuntime journal frame has no first sequence".to_string())?;
        let records = frame
            .get("records")
            .and_then(serde_json::Value::as_array)
            .ok_or_else(|| "TaskRuntime journal frame has no records".to_string())?;
        for (index, record) in records.iter().enumerate() {
            let expected = first_sequence
                .checked_add(u64::try_from(index).map_err(|error| error.to_string())?)
                .ok_or_else(|| "TaskRuntime test sequence overflow".to_string())?;
            if record.get("batch_id").and_then(serde_json::Value::as_str) != Some(batch_id)
                || record.get("sequence").and_then(serde_json::Value::as_u64) != Some(expected)
            {
                return Err("TaskRuntime batch record identity is not contiguous".to_string());
            }
        }
        records
            .iter()
            .map(|record| {
                record
                    .get("event")
                    .and_then(|event| event.get("event_type"))
                    .and_then(serde_json::Value::as_str)
                    .map(str::to_string)
                    .ok_or_else(|| "TaskRuntime record has no event type".to_string())
            })
            .collect()
    }

    fn seed_public_state_fixture(
        event_count: usize,
    ) -> Result<(tempfile::TempDir, TaskRuntimeStore, String), String> {
        if event_count == 0 {
            return Err("performance fixture requires at least one event".to_string());
        }
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        let run_id = format!("public-state-{event_count}");
        let mut pending = Vec::with_capacity(512);
        for index in 0..event_count {
            let (task_id, step_id, event_type, payload) = match index {
                0 => (
                    None,
                    None,
                    RuntimeEventKind::RunCreated,
                    serde_json::json!({
                        "goal": "public state performance",
                        "goal_revision": 1,
                        "goal_sha256": task_goal_sha256("public state performance"),
                        "domain_profile": "general",
                        "workspace_id": "test",
                        "conversation_id": "ordinary-conversation",
                        "root_message_id": "root-message",
                        "route": "task",
                        "attended_mode": "unattended",
                    }),
                ),
                1 => (
                    None,
                    None,
                    RuntimeEventKind::RunContinuationConfigured,
                    serde_json::json!({"enabled": true}),
                ),
                2 => (
                    None,
                    None,
                    RuntimeEventKind::RunTurnStarted,
                    serde_json::json!({
                        "turn_id": "fixture-turn",
                        "ordinal": 1,
                        "origin": "continuation",
                        "transcript_visibility": "internal",
                    }),
                ),
                3 => (
                    None,
                    None,
                    RuntimeEventKind::RunTurnUsageAccounted,
                    serde_json::json!({
                        "event_id": "fixture-usage",
                        "turn_id": "fixture-turn",
                        "input_tokens": 2,
                        "output_tokens": 3,
                        "elapsed_seconds": 1,
                    }),
                ),
                4 => (
                    None,
                    None,
                    RuntimeEventKind::RunTurnCompacted,
                    serde_json::json!({
                        "event_id": "fixture-compaction",
                        "turn_id": "fixture-turn",
                    }),
                ),
                5 => (
                    None,
                    None,
                    RuntimeEventKind::RunTurnFinished,
                    serde_json::json!({
                        "turn_id": "fixture-turn",
                        "status": "ended",
                        "elapsed_seconds": 1,
                        "made_progress": true,
                    }),
                ),
                6 => (
                    Some("fixture-task-a".to_string()),
                    Some("fixture-execution-a".to_string()),
                    RuntimeEventKind::SubagentAssigned,
                    serde_json::json!({"replay_safe": false}),
                ),
                7 => (
                    Some("fixture-task-a".to_string()),
                    Some("fixture-call-a".to_string()),
                    RuntimeEventKind::ToolStarted,
                    serde_json::json!({
                        "execution_id": "fixture-execution-a",
                        "call_id": "fixture-call-a",
                        "tool_name": "write_file",
                        "replay_safe": false,
                    }),
                ),
                8 => (
                    Some("fixture-task-a".to_string()),
                    None,
                    RuntimeEventKind::RecoveryBlocked,
                    serde_json::json!({
                        "execution_id": "fixture-execution-a",
                        "call_id": "fixture-call-a",
                        "tool_name": "write_file",
                        "reason": "fixture uncertain side effect",
                    }),
                ),
                9 => (
                    None,
                    Some("fixture-call-a".to_string()),
                    RuntimeEventKind::BackgroundCellStarted,
                    serde_json::json!({
                        "cell_id": "fixture-cell",
                        "name": "fixture command",
                        "command_hash": "fixture-hash",
                        "phase": "running",
                        "artifact_status": "not_requested",
                    }),
                ),
                10 => (
                    Some("fixture-task-a".to_string()),
                    Some("fixture-call-a".to_string()),
                    RuntimeEventKind::ToolCompleted,
                    serde_json::json!({"call_id": "fixture-call-a"}),
                ),
                11 => (
                    Some("fixture-task-a".to_string()),
                    Some("fixture-execution-a".to_string()),
                    RuntimeEventKind::SubagentReleased,
                    serde_json::json!({}),
                ),
                12 => (
                    Some("fixture-task-a".to_string()),
                    None,
                    RuntimeEventKind::RecoveryResolved,
                    serde_json::json!({}),
                ),
                13 => (
                    None,
                    Some("fixture-call-a".to_string()),
                    RuntimeEventKind::BackgroundCellFinished,
                    serde_json::json!({
                        "cell_id": "fixture-cell",
                        "phase": "succeeded",
                        "terminal_cause": "exited",
                        "exit_code": 0,
                        "artifact_status": "not_requested",
                    }),
                ),
                14 => (
                    Some("fixture-task-b".to_string()),
                    Some("fixture-execution-b".to_string()),
                    RuntimeEventKind::SubagentAssigned,
                    serde_json::json!({"replay_safe": false}),
                ),
                15 => (
                    Some("fixture-task-b".to_string()),
                    Some("fixture-call-b".to_string()),
                    RuntimeEventKind::ToolStarted,
                    serde_json::json!({
                        "execution_id": "fixture-execution-b",
                        "call_id": "fixture-call-b",
                        "tool_name": "shell",
                        "replay_safe": false,
                    }),
                ),
                16 => (
                    Some("fixture-task-b".to_string()),
                    None,
                    RuntimeEventKind::RecoveryBlocked,
                    serde_json::json!({
                        "execution_id": "fixture-execution-b",
                        "call_id": "fixture-call-b",
                        "tool_name": "shell",
                        "reason": "fixture active recovery blocker",
                    }),
                ),
                _ => (
                    None,
                    None,
                    RuntimeEventKind::Note,
                    serde_json::json!({
                        "kind": "performance_fixture",
                        "ordinal": index,
                        "detail": "fixed diagnostic payload for public checkpoint-backed state reads",
                    }),
                ),
            };
            pending.push(RuntimeJournalEvent::for_append(
                &run_id,
                task_id.as_deref(),
                step_id.as_deref(),
                event_type,
                payload,
            ));
            if pending.len() == 512 || index.saturating_add(1) == event_count {
                store
                    .shadow
                    .append_event_batch(&run_id, std::mem::take(&mut pending))
                    .map_err(|error| error.to_string())?;
            }
        }
        store
            .shadow
            .rewrite_plan(&run_id)
            .map_err(|error| error.to_string())?;
        Ok((temp, store, run_id))
    }

    fn median_duration(samples: &mut [std::time::Duration]) -> Option<std::time::Duration> {
        samples.sort_unstable();
        samples.get(samples.len() / 2).copied()
    }

    fn seed_public_query_fixture(
        event_count: usize,
    ) -> Result<(tempfile::TempDir, TaskRuntimeStore, String), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        let run_id = format!("public-query-{event_count}");
        store
            .create_run(
                &run_id,
                "test",
                "conversation",
                "root-message",
                DomainProfile::General,
                "bounded public query",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        let plan = TaskPlan {
            domain_binding: None,

            plan_id: format!("plan-{event_count}"),
            run_id: run_id.clone(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("bounded public query"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: "task-a".to_string(),
                title: "Project bounded state".to_string(),
                description: "Exercise the production Todo and completion queries".to_string(),
                kind: PlanTaskKind::Investigation,
                agent_role: "subagent".to_string(),
                domain_profile: DomainProfile::General,
                sort_order: 1,
                ..Default::default()
            }],
        };
        store
            .attach_plan_for_test(&plan)
            .map_err(|error| error.to_string())?;
        store
            .set_task_status(
                &run_id,
                "task-a",
                echo_agent::tasks::TaskStatus::Completed,
                Some("subagent"),
                Some("projected"),
            )
            .map_err(|error| error.to_string())?;
        store
            .put_summary(&TaskExecutionSummary {
                run_id: run_id.clone(),
                task_id: "task-a".to_string(),
                subagent_name: "subagent".to_string(),
                outcome: SubagentOutcome::terminal(
                    SubagentStatus::Completed,
                    "bounded query complete",
                    Vec::new(),
                ),
                decisions: Vec::new(),
                next_implications: Vec::new(),
                suggested_tasks: Vec::new(),
                created_at: Utc::now(),
            })
            .map_err(|error| error.to_string())?;
        store
            .add_artifact(&Artifact {
                id: "artifact-a".to_string(),
                run_id: run_id.clone(),
                task_id: Some("task-a".to_string()),
                kind: ArtifactKind::Report,
                title: "Bounded report".to_string(),
                path: None,
                metadata: serde_json::json!({"source": "fixture"}),
            })
            .map_err(|error| error.to_string())?;
        store
            .add_review(&ReviewResult {
                id: "review-a".to_string(),
                run_id: run_id.clone(),
                task_id: "task-a".to_string(),
                reviewer_agent: "reviewer".to_string(),
                outcome: ReviewOutcome::Pass,
                issues: Vec::new(),
                failure_fingerprint: None,
                created_fix_task_id: None,
                created_at: Utc::now(),
            })
            .map_err(|error| error.to_string())?;
        let current = store
            .list_events(&run_id, 0)
            .map_err(|error| error.to_string())?
            .len();
        if current > event_count {
            return Err(format!(
                "query fixture needs {current} semantic events, target was {event_count}"
            ));
        }
        let mut pending = Vec::with_capacity(512);
        for ordinal in current..event_count {
            pending.push(RuntimeJournalEvent::for_append(
                &run_id,
                None,
                None,
                RuntimeEventKind::Note,
                serde_json::json!({"kind": "bounded_query_fixture", "ordinal": ordinal}),
            ));
            if pending.len() == 512 || ordinal.saturating_add(1) == event_count {
                store
                    .shadow
                    .append_event_batch(&run_id, std::mem::take(&mut pending))
                    .map_err(|error| error.to_string())?;
            }
        }
        store
            .shadow
            .rewrite_plan(&run_id)
            .map_err(|error| error.to_string())?;
        Ok((temp, store, run_id))
    }

    fn seed_history_plan(store: &TaskRuntimeStore, run_id: &str) -> Result<(), String> {
        store
            .create_run(
                run_id,
                "test",
                "conversation",
                "root",
                DomainProfile::General,
                "history projection",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,

                plan_id: format!("plan-{run_id}"),
                run_id: run_id.to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: task_goal_sha256("history projection"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: ["other-task", "target-task"]
                    .into_iter()
                    .enumerate()
                    .map(|(index, task_id)| PlanTask {
                        id: task_id.to_string(),
                        title: task_id.to_string(),
                        description: "history scale".to_string(),
                        kind: PlanTaskKind::Investigation,
                        agent_role: "subagent".to_string(),
                        domain_profile: DomainProfile::General,
                        sort_order: i64::try_from(index).unwrap_or_default(),
                        ..Default::default()
                    })
                    .collect(),
            })
            .map_err(|error| error.to_string())
    }

    fn history_artifact(run_id: &str, id: &str) -> Artifact {
        Artifact {
            id: id.to_string(),
            run_id: run_id.to_string(),
            task_id: Some("target-task".to_string()),
            kind: ArtifactKind::Report,
            title: id.to_string(),
            path: None,
            metadata: serde_json::json!({"fixture": true}),
        }
    }

    fn history_review(run_id: &str, task_id: &str, id: &str) -> ReviewResult {
        ReviewResult {
            id: id.to_string(),
            run_id: run_id.to_string(),
            task_id: task_id.to_string(),
            reviewer_agent: "reviewer".to_string(),
            outcome: ReviewOutcome::Pass,
            issues: Vec::new(),
            failure_fingerprint: None,
            created_fix_task_id: None,
            created_at: Utc::now(),
        }
    }

    fn artifact_history_event(run_id: &str, id: &str) -> RuntimeJournalEvent {
        let artifact = history_artifact(run_id, id);
        RuntimeJournalEvent::for_append(
            run_id,
            artifact.task_id.as_deref(),
            None,
            RuntimeEventKind::ArtifactProduced,
            serde_json::json!({
                "artifact_id": artifact.id,
                "kind": artifact.kind.as_str(),
                "title": artifact.title,
                "task_id": artifact.task_id,
                "path": artifact.path,
                "metadata": artifact.metadata,
            }),
        )
    }

    fn review_history_event(run_id: &str, task_id: &str, id: &str) -> RuntimeJournalEvent {
        review_runtime_event(&history_review(run_id, task_id, id), None)
    }

    fn line_count(path: &std::path::Path) -> Result<usize, String> {
        Ok(std::fs::read(path)
            .map_err(|error| error.to_string())?
            .split(|byte| *byte == b'\n')
            .filter(|line| !line.is_empty())
            .count())
    }

    fn retain_first_jsonl_record(path: &std::path::Path) -> Result<(), String> {
        let bytes = std::fs::read(path).map_err(|error| error.to_string())?;
        let first = bytes
            .split_inclusive(|byte| *byte == b'\n')
            .next()
            .ok_or_else(|| "history segment has no first record".to_string())?;
        std::fs::write(path, first).map_err(|error| error.to_string())
    }

    fn history_cursor_sequence(path: &std::path::Path) -> Result<u64, String> {
        serde_json::from_slice::<serde_json::Value>(
            &std::fs::read(path).map_err(|error| error.to_string())?,
        )
        .map_err(|error| error.to_string())?
        .get("through_sequence")
        .and_then(serde_json::Value::as_u64)
        .ok_or_else(|| "history cursor has no through_sequence".to_string())
    }

    fn flush_history_batch(
        store: &TaskRuntimeStore,
        run_id: &str,
        pending: &mut Vec<RuntimeJournalEvent>,
        samples: &mut Vec<std::time::Duration>,
    ) -> Result<(), String> {
        if pending.is_empty() {
            return Ok(());
        }
        let started = std::time::Instant::now();
        store
            .commit_runtime_events(run_id, std::mem::take(pending))
            .map_err(|error| error.to_string())?;
        samples.push(started.elapsed());
        Ok(())
    }

    type HistoryScaleFixture = (
        tempfile::TempDir,
        TaskRuntimeStore,
        String,
        std::time::Duration,
        std::time::Duration,
    );

    fn seed_history_scale_fixture(review_count: usize) -> Result<HistoryScaleFixture, String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        let run_id = format!("history-scale-{review_count}");
        seed_history_plan(&store, &run_id)?;

        let split = review_count / 2;
        let mut pending = vec![
            artifact_history_event(&run_id, "only-artifact"),
            review_history_event(&run_id, "target-task", "only-target-review"),
        ];
        let mut first_half = Vec::new();
        let mut second_half = Vec::new();
        for ordinal in 0..review_count {
            pending.push(review_history_event(
                &run_id,
                "other-task",
                &format!("other-review-{ordinal}"),
            ));
            if pending.len() == 512 {
                let samples = if ordinal < split {
                    &mut first_half
                } else {
                    &mut second_half
                };
                flush_history_batch(&store, &run_id, &mut pending, samples)?;
            }
        }
        flush_history_batch(&store, &run_id, &mut pending, &mut second_half)?;
        let first_median = median_duration(&mut first_half)
            .ok_or_else(|| "history first-half append samples are empty".to_string())?;
        let second_median = median_duration(&mut second_half)
            .ok_or_else(|| "history second-half append samples are empty".to_string())?;
        Ok((temp, store, run_id, first_median, second_median))
    }

    type ArtifactScaleFixture = (
        tempfile::TempDir,
        TaskRuntimeStore,
        String,
        std::time::Duration,
        std::time::Duration,
        usize,
        u64,
    );

    fn seed_artifact_scale_fixture(artifact_count: usize) -> Result<ArtifactScaleFixture, String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        let run_id = format!("artifact-scale-{artifact_count}");
        seed_history_plan(&store, &run_id)?;
        let (scans_before, bytes_before) = store
            .shadow
            .history_stats_for_test(&run_id)
            .map_err(|error| error.to_string())?;
        let split = artifact_count / 2;
        let mut pending = Vec::with_capacity(512);
        let mut first_half = Vec::new();
        let mut second_half = Vec::new();
        for ordinal in 0..artifact_count {
            pending.push(artifact_history_event(
                &run_id,
                &format!("artifact-{ordinal}"),
            ));
            if pending.len() == 512 {
                let samples = if ordinal < split {
                    &mut first_half
                } else {
                    &mut second_half
                };
                flush_history_batch(&store, &run_id, &mut pending, samples)?;
            }
        }
        flush_history_batch(&store, &run_id, &mut pending, &mut second_half)?;
        let first_median = median_duration(&mut first_half)
            .ok_or_else(|| "artifact first-half append samples are empty".to_string())?;
        let second_median = median_duration(&mut second_half)
            .ok_or_else(|| "artifact second-half append samples are empty".to_string())?;
        let (scans_after, bytes_after) = store
            .shadow
            .history_stats_for_test(&run_id)
            .map_err(|error| error.to_string())?;
        let scan_delta = scans_after.saturating_sub(scans_before);
        let byte_delta = bytes_after.saturating_sub(bytes_before);
        Ok((
            temp,
            store,
            run_id,
            first_median,
            second_median,
            scan_delta,
            byte_delta,
        ))
    }

    fn time_history_target_queries(
        store: &TaskRuntimeStore,
        run_id: &str,
    ) -> Result<std::time::Duration, String> {
        let started = std::time::Instant::now();
        let artifacts = store
            .list_artifacts(run_id)
            .map_err(|error| error.to_string())?;
        let reviews = store
            .list_reviews(run_id, "target-task")
            .map_err(|error| error.to_string())?;
        if artifacts.len() != 1 || reviews.len() != 1 {
            return Err("targeted history projection returned incomplete facts".to_string());
        }
        Ok(started.elapsed())
    }

    fn time_public_queries(
        store: &TaskRuntimeStore,
        run_id: &str,
    ) -> Result<std::time::Duration, String> {
        let started = std::time::Instant::now();
        let todos = store
            .list_todos(run_id)
            .map_err(|error| error.to_string())?;
        let artifacts = store
            .list_artifacts(run_id)
            .map_err(|error| error.to_string())?;
        let completion = store
            .completion_gate_report(run_id)
            .map_err(|error| error.to_string())?;
        let reviews = store
            .list_reviews(run_id, "task-a")
            .map_err(|error| error.to_string())?;
        let summary = store
            .get_summary(run_id, "task-a")
            .map_err(|error| error.to_string())?;
        if todos.len() != 1
            || artifacts.len() != 1
            || reviews.len() != 1
            || summary.is_none()
            || !completion.ready
        {
            return Err("production TaskRuntime query projection is incomplete".to_string());
        }
        Ok(started.elapsed())
    }

    fn boot_recovery_event_count(store: &TaskRuntimeStore) -> Result<usize, StoreError> {
        Ok(store
            .list_events("r1", 0)?
            .iter()
            .filter(|event| boot_recovery_payload(event).is_some())
            .count())
    }

    fn create_paused_run(store: &TaskRuntimeStore, run_id: &str) -> Result<TaskRun, StoreError> {
        store.create_run(
            run_id,
            "ws",
            "conversation",
            "message",
            DomainProfile::General,
            "original goal",
            "",
            AttendedMode::Attended,
        )?;
        store.transition_run(run_id, TaskRunStatus::Running)?;
        store.transition_run(run_id, TaskRunStatus::Paused)
    }

    fn test_driver_admission(
        store: &std::sync::Arc<TaskRuntimeStore>,
        run_id: &str,
    ) -> Result<RunDriverAdmissionReservation, String> {
        store
            .reserve_run_driver_admission(
                run_id.to_string(),
                echo_agent::agent::CancellationToken::new(),
            )
            .map_err(|error| error.to_string())
    }

    fn prepare_retryable_run(
        store: &TaskRuntimeStore,
        run_id: &str,
        task_id: &str,
    ) -> Result<(), StoreError> {
        store.create_run(
            run_id,
            "workspace-a",
            "conversation",
            "message",
            DomainProfile::General,
            "retry through the TUI facade",
            "",
            AttendedMode::Attended,
        )?;
        store.attach_plan_for_test(&TaskPlan {
            domain_binding: None,

            plan_id: format!("{run_id}-plan"),
            run_id: run_id.to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("retry through the TUI facade"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: task_id.to_string(),
                title: "Retry task".to_string(),
                max_retries: 2,
                ..PlanTask::default()
            }],
        })?;
        store.transition_run(run_id, TaskRunStatus::Running)?;
        store.set_task_status(
            run_id,
            task_id,
            echo_agent::tasks::TaskStatus::Failed(String::new()),
            None,
            Some("acceptance failed"),
        )?;
        store.transition_run(run_id, TaskRunStatus::Failed)?;
        Ok(())
    }

    fn retry_state_snapshot(
        store: &TaskRuntimeStore,
        run_id: &str,
    ) -> Result<(serde_json::Value, serde_json::Value, serde_json::Value), String> {
        Ok((
            serde_json::to_value(
                store
                    .list_events(run_id, 0)
                    .map_err(|error| error.to_string())?,
            )
            .map_err(|error| error.to_string())?,
            serde_json::to_value(store.get_run(run_id).map_err(|error| error.to_string())?)
                .map_err(|error| error.to_string())?,
            serde_json::to_value(store.get_plan(run_id).map_err(|error| error.to_string())?)
                .map_err(|error| error.to_string())?,
        ))
    }

    #[test]
    fn tui_retry_registration_failure_leaves_events_run_and_plan_unchanged() -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        prepare_retryable_run(&store, "registration-failure", "retry-task")
            .map_err(|error| error.to_string())?;
        let before = retry_state_snapshot(&store, "registration-failure")?;
        store.fail_next_run_driver_registration_for_test();

        let error = store
            .spawn_supervised_task_retry(
                "registration-failure".to_string(),
                "retry-task".to_string(),
                echo_agent::agent::CancellationToken::new(),
                || Ok(()),
                |(), _receipt_owner| async { Ok(()) },
            )
            .err()
            .ok_or_else(|| "injected driver registration unexpectedly succeeded".to_string())?;
        assert!(
            error
                .to_string()
                .contains("injected TaskRun driver registration failure")
        );
        assert_eq!(
            before,
            retry_state_snapshot(&store, "registration-failure")?
        );
        Ok(())
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn tui_retry_registration_pins_generation_before_recovery_classification()
    -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        prepare_retryable_run(&store, "generation-race", "retry-task")
            .map_err(|error| error.to_string())?;
        let before = retry_state_snapshot(&store, "generation-race")?;
        let (registered, release) = store.park_next_run_driver_registration_for_test()?;
        let retry_store = std::sync::Arc::clone(&store);
        let retry = tokio::spawn(async move {
            retry_store.spawn_supervised_task_retry(
                "generation-race".to_string(),
                "retry-task".to_string(),
                echo_agent::agent::CancellationToken::new(),
                || Ok(()),
                |(), _receipt_owner| async { Ok(()) },
            )
        });
        tokio::task::spawn_blocking(move || {
            registered
                .recv_timeout(std::time::Duration::from_secs(2))
                .map_err(|error| format!("retry registration was not parked: {error}"))
        })
        .await
        .map_err(|error| error.to_string())??;

        let transition_error = store
            .begin_workspace_transition()
            .await
            .err()
            .ok_or_else(|| "workspace transition overtook registered TUI retry".to_string())?;
        assert!(matches!(
            transition_error,
            StoreError::WorkspaceTransitionBusy { .. }
        ));
        assert_eq!(before, retry_state_snapshot(&store, "generation-race")?);

        release
            .send(())
            .map_err(|_| "retry registration release receiver closed".to_string())?;
        let (preparation, waiter) = retry
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        assert_eq!(
            preparation,
            TaskRetryPreparation::Acceptance { next_attempt: 1 }
        );
        let _driver_result = waiter.await.map_err(|error| error.to_string())?;
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn rejected_pre_execution_debt_releases_only_its_unstarted_resources()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let saved = temp.path().join("tasks-saved");
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
                .map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        store.create_run(
            "unstarted-debt",
            "workspace-a",
            "conversation",
            "message",
            DomainProfile::General,
            "reject before physical start",
            "",
            AttendedMode::Unattended,
        )?;
        store.transition_run("unstarted-debt", TaskRunStatus::Running)?;
        let admission = test_driver_admission(&store, "unstarted-debt")?;
        let mut registration = store.register_observed_run_driver::<()>(
            admission,
            store.lease_active_workspace_generation()?,
        )?;
        let dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        registration
            .receipt_owner
            .as_mut()
            .ok_or_else(|| "registered resource owner missing".to_string())?
            .retain(DropFlag(dropped.clone()))
            .map_err(|_| "receipt not retained".to_string())?;
        registration.mark_preparation_started();
        std::fs::rename(&root, &saved).map_err(|error| error.to_string())?;
        std::fs::write(&root, b"block only the pre-execution terminal write")
            .map_err(|error| error.to_string())?;
        // No Execute future was supplied. Only the original preparation failure
        // path can create this None-identity debt.
        registration.fail_preparation("known preparation rejection before physical start");
        tokio::time::timeout(
            std::time::Duration::from_secs(2),
            store.wait_for_run_driver_idle("unstarted-debt"),
        )
        .await
        .map_err(|_| "unstarted owner failed to report preparation".to_string())?;
        {
            let supervisor = store
                .run_driver_supervisor
                .lock()
                .map_err(|_| "supervisor lock poisoned".to_string())?;
            assert_eq!(supervisor.settlement_debts.len(), 1);
            assert!(
                supervisor
                    .settlement_debts
                    .first()
                    .ok_or_else(|| "unstarted debt missing".to_string())?
                    .physical_owner_intent
                    .is_none()
            );
            assert!(supervisor.uncertain_drivers.is_empty());
        }
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        let events = std::fs::read_to_string(saved.join("unstarted-debt/events.jsonl"))
            .map_err(|error| error.to_string())?;
        let mut record_count = 0_usize;
        // Reuse the original journal's public event DTO and projection. The
        // on-disk lines are batch frames, not IPC RuntimeTaskEvent records;
        // never open a second differently typed FileEventJournal owner.
        for line in events.lines() {
            let frame: serde_json::Value = serde_json::from_str(line)?;
            let records = frame
                .get("records")
                .and_then(serde_json::Value::as_array)
                .ok_or_else(|| "original journal frame records missing".to_string())?;
            assert!(!records.is_empty());
            for record in records {
                let sequence = record
                    .get("sequence")
                    .and_then(serde_json::Value::as_u64)
                    .ok_or_else(|| "original journal sequence missing".to_string())?;
                let event: RuntimeJournalEvent = serde_json::from_value(
                    record
                        .get("event")
                        .cloned()
                        .ok_or_else(|| "original journal event missing".to_string())?,
                )?;
                let projected = event.project(sequence).map_err(|sequence| {
                    format!("original journal sequence overflow: {sequence}")
                })?;
                assert_eq!(projected.run_id, "unstarted-debt");
                assert!(projected.payload.get("physical_owner_intent").is_none());
                record_count = record_count.saturating_add(1);
            }
        }
        assert!(record_count > 0);
        let diagnostic = store
            .shutdown_run_drivers()
            .await
            .err()
            .ok_or_else(|| "uncommitted pre-execution terminal write hidden".to_string())?;
        assert_eq!(diagnostic.abandoned_settlements.len(), 1);
        let debt = diagnostic
            .abandoned_settlements
            .first()
            .ok_or_else(|| "unstarted diagnostic missing".to_string())?;
        assert_eq!(debt.run_id, "unstarted-debt");
        assert_eq!(debt.target, TaskRunStatus::Failed);
        assert!(dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(store.active_run_driver_count()?, 0);
        assert_eq!(store.active_run_driver_receipt_count()?, 0);
        std::fs::remove_file(&root).map_err(|error| error.to_string())?;
        std::fs::rename(&saved, &root).map_err(|error| error.to_string())?;
        assert!(
            store
                .unresolved_physical_owner_intents("unstarted-debt")?
                .is_empty()
        );
        drop(
            store
                .begin_workspace_transition()
                .await
                .map_err(|error| error.to_string())?,
        );
        Ok(())
    }

    #[tokio::test]
    async fn physical_completion_read_error_preserves_original_driver_target()
    -> Result<(), Box<dyn std::error::Error>> {
        // All three cases inject real I/O failure only after the original
        // owner's physical completion was durably appended. Successful return
        // without business settlement remains a protocol failure, even cancelled.
        for (cancel_requested, driver_failed, expected) in [
            (true, true, TaskRunStatus::Cancelled),
            (false, true, TaskRunStatus::Failed),
            (true, false, TaskRunStatus::Failed),
        ] {
            let temp = tempfile::tempdir()?;
            let root = temp.path().join("tasks");
            let saved = temp.path().join("original-tasks");
            let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(
                root.clone(),
            )?);
            let _resource_scope = store.test_resource_scope();
            let expected_root = std::fs::canonicalize(temp.path())?.join("tasks");
            let injected_root = root.clone();
            let saved_root = saved.clone();
            let physical_fault = store.inject_after_physical_completion_for_test(
                "read-error-target",
                move || {
                    std::fs::rename(&injected_root, &saved_root)?;
                    std::fs::create_dir_all(injected_root.join("read-error-target/run-state.json"))
                },
            )?;
            store.create_run(
                "read-error-target",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "retain the original cancellation target",
                "",
                AttendedMode::Unattended,
            )?;
            store.transition_run("read-error-target", TaskRunStatus::Running)?;
            let dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
            let retained = dropped.clone();
            let (started_tx, started_rx) = tokio::sync::oneshot::channel();
            let (release_tx, release_rx) = tokio::sync::oneshot::channel();
            let cancel = echo_agent::agent::CancellationToken::new();
            let admission = store
                .reserve_run_driver_admission("read-error-target".to_string(), cancel.clone())?;
            let waiter = store.spawn_run_driver(
                admission,
                store.lease_active_workspace_generation()?,
                move |mut receipt_owner| async move {
                    receipt_owner
                        .retain(DropFlag(retained))
                        .map_err(|e| e.to_string())?;
                    started_tx
                        .send(receipt_owner.execution_context_id().to_owned())
                        .map_err(|_| "start receiver closed".to_string())?;
                    release_rx.await.map_err(|e| e.to_string())?;
                    if driver_failed {
                        Err::<(), String>("original driver error".to_string())
                    } else {
                        Ok(())
                    }
                },
            )?;
            let owner_id = started_rx.await?;
            if cancel_requested {
                assert!(store.request_cancel("read-error-target")?);
            }
            assert_eq!(cancel.is_cancelled(), cancel_requested);
            assert_eq!(
                store
                    .get_run("read-error-target")?
                    .ok_or("run missing")?
                    .status,
                TaskRunStatus::Running
            );
            release_tx.send(()).map_err(|_| "release receiver closed")?;
            let error = waiter.await?.err().ok_or("unsettled driver error hidden")?;
            assert!(error.contains("terminal settlement failed"), "{error}");
            store.wait_for_run_driver_idle("read-error-target").await;
            let physical_event = physical_fault
                .lock()
                .map_err(|_| "fault lock poisoned")?
                .clone()
                .ok_or("physical completion fault not reached")??;
            let original: PhysicalOwnerIntent = serde_json::from_value(
                physical_event
                    .payload
                    .get("physical_owner_intent")
                    .cloned()
                    .ok_or("original intent missing")?,
            )?;
            assert_eq!(original.owner_id, owner_id);
            assert_eq!(original.run_id, "read-error-target");
            assert!(original.physical_terminal_observed);
            assert!(store.get_run("read-error-target").is_err());
            let journal_path = saved.join("read-error-target/events.jsonl");
            let original_journal = std::fs::read(&journal_path)?;
            {
                let supervisor = store
                    .run_driver_supervisor
                    .lock()
                    .map_err(|_| "supervisor lock poisoned")?;
                assert!(supervisor.driver_cancels.is_empty());
                assert_eq!(supervisor.pending_admissions, 0);
                assert!(supervisor.uncertain_drivers.is_empty());
                assert_eq!(supervisor.settlement_debts.len(), 1);
                let debt = supervisor.settlement_debts.first().ok_or("debt missing")?;
                assert_eq!(debt.run_id, original.run_id);
                assert_eq!(debt.root, expected_root);
                assert_eq!(debt.target, expected);
                assert_eq!(debt.physical_owner_intent.as_ref(), Some(&original));
                let context = supervisor
                    .driver_contexts
                    .get(&owner_id)
                    .ok_or("original execution context missing")?;
                assert_eq!(debt.driver_token, Some(context.driver_token));
            }
            assert_eq!(store.active_run_driver_receipt_count()?, 1);
            assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
            assert!(store.retry_run_settlement_debts().await.is_err());
            assert_eq!(std::fs::read(&journal_path)?, original_journal);
            assert_eq!(store.active_run_driver_receipt_count()?, 1);
            assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));

            // Preserve the injected projection directory; restore only the
            // unchanged original canonical journal, never synthesize a receipt.
            std::fs::rename(&root, temp.path().join("injected-projections"))?;
            std::fs::rename(&saved, &root)?;
            let restored_journal = root.join("read-error-target/events.jsonl");
            assert_eq!(std::fs::read(&restored_journal)?, original_journal);
            store.retry_run_settlement_debts().await?;
            assert_eq!(
                store
                    .get_run("read-error-target")?
                    .ok_or("run missing")?
                    .status,
                expected
            );
            assert!(
                store
                    .unresolved_physical_owner_intents("read-error-target")?
                    .is_empty()
            );
            assert_eq!(store.active_run_driver_count()?, 0);
            assert_eq!(store.active_run_driver_receipt_count()?, 0);
            assert!(dropped.load(std::sync::atomic::Ordering::SeqCst));
            let settled = std::fs::read(&restored_journal)?;
            let acknowledgements = store
                .list_events("read-error-target", 0)?
                .into_iter()
                .filter(|event| {
                    event.event_type == RuntimeEventKind::RecoveryResolved
                        && event
                            .payload
                            .get("physical_owner_intent")
                            .and_then(|value| value.get("owner_id"))
                            .and_then(serde_json::Value::as_str)
                            == Some(owner_id.as_str())
                })
                .count();
            assert_eq!(acknowledgements, 1);
            store.retry_run_settlement_debts().await?;
            store.acknowledge_physical_owner_intent(&original)?;
            assert_eq!(std::fs::read(&restored_journal)?, settled);
        }
        Ok(())
    }

    #[tokio::test]
    async fn terminal_write_debt_retains_execution_receipt_until_retry()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let blocked_root = temp.path().join("tasks-blocked");
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory_with_shadow_root(root.clone())
                .map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        let physical_fault = store.block_shadow_after_physical_completion_for_test(
            "receipt-debt",
            blocked_root.clone(),
        )?;
        store
            .create_run(
                "receipt-debt",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "retain execution receipt",
                "",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("receipt-debt", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        let generation_lease = store
            .lease_active_workspace_generation()
            .map_err(|error| error.to_string())?;
        let dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let dropped_for_driver = std::sync::Arc::clone(&dropped);
        let admission = test_driver_admission(&store, "receipt-debt")?;
        let waiter = store
            .spawn_run_driver(
                admission,
                generation_lease,
                move |mut receipt_owner| async move {
                    receipt_owner
                        .retain(DropFlag(dropped_for_driver))
                        .map_err(|error| error.to_string())?;

                    Err::<(), String>("injected driver failure".to_string())
                },
            )
            .map_err(|error| error.to_string())?;
        let driver_error = waiter
            .await
            .map_err(|error| error.to_string())?
            .err()
            .ok_or_else(|| "driver failure was not reported".to_string())?;
        let physical_event = physical_fault
            .lock()
            .map_err(|_| "physical completion fixture lock poisoned".to_string())?
            .clone()
            .ok_or_else(|| "physical completion did not reach fault boundary".to_string())??;
        assert_eq!(physical_event.run_id, "receipt-debt");
        assert_eq!(
            physical_event
                .payload
                .get("physical_owner_intent")
                .and_then(|intent| intent.get("physical_terminal_observed"))
                .and_then(serde_json::Value::as_bool),
            Some(true)
        );
        assert!(
            driver_error.contains("terminal settlement failed"),
            "actual: {driver_error}"
        );
        store.wait_for_run_driver_idle("receipt-debt").await;
        assert_eq!(store.active_run_driver_count()?, 1);
        assert_eq!(store.active_run_driver_receipt_count()?, 1);
        {
            let supervisor = store
                .run_driver_supervisor
                .lock()
                .map_err(|_| "supervisor lock poisoned".to_string())?;
            assert!(supervisor.driver_cancels.is_empty());
            assert_eq!(supervisor.pending_admissions, 0);
            assert!(supervisor.uncertain_drivers.is_empty());
            let debt = supervisor
                .settlement_debts
                .first()
                .ok_or_else(|| "terminal debt missing".to_string())?;
            assert_eq!(supervisor.settlement_debts.len(), 1);
            assert_eq!(debt.run_id, "receipt-debt");
            assert!(debt.driver_token.is_some());
            assert_eq!(debt.target, TaskRunStatus::Failed);
            assert!(!debt.last_error.is_empty());
        }
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(store.begin_workspace_transition().await.is_err());

        assert!(store.retry_run_settlement_debts().await.is_err());
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(store.active_run_driver_receipt_count()?, 1);
        std::fs::remove_file(temp.path().join("tasks")).map_err(|error| error.to_string())?;
        std::fs::rename(temp.path().join("tasks-blocked"), temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        let original: PhysicalOwnerIntent = serde_json::from_value(
            physical_event
                .payload
                .get("physical_owner_intent")
                .cloned()
                .ok_or_else(|| "original physical receipt missing".to_string())?,
        )
        .map_err(|error| error.to_string())?;
        let event_path = temp.path().join("tasks/receipt-debt/events.jsonl");
        let before_wrong_owner = std::fs::read(&event_path).map_err(|error| error.to_string())?;
        {
            let mut supervisor = store
                .run_driver_supervisor
                .lock()
                .map_err(|_| "supervisor lock poisoned".to_string())?;
            let debt = supervisor
                .settlement_debts
                .first_mut()
                .ok_or_else(|| "original debt missing".to_string())?;
            let identity = debt
                .physical_owner_intent
                .as_mut()
                .ok_or_else(|| "admitted debt lost original identity".to_string())?;
            assert_eq!(&*identity, &original);
            identity.owner_id = "wrong-owner".to_string();
        }
        let wrong_owner = store
            .retry_run_settlement_debts()
            .await
            .err()
            .ok_or_else(|| "wrong owner cleared original terminal debt".to_string())?;
        assert!(wrong_owner.to_string().contains("does not match"));
        assert_eq!(
            std::fs::read(&event_path).map_err(|error| error.to_string())?,
            before_wrong_owner
        );
        assert_eq!(
            store
                .get_run("receipt-debt")?
                .ok_or_else(|| "run missing".to_string())?
                .status,
            TaskRunStatus::Running
        );
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(store.active_run_driver_receipt_count()?, 1);
        {
            let mut supervisor = store
                .run_driver_supervisor
                .lock()
                .map_err(|_| "supervisor lock poisoned".to_string())?;
            supervisor
                .settlement_debts
                .first_mut()
                .ok_or_else(|| "wrong-owner retry lost original debt".to_string())?
                .physical_owner_intent = Some(original.clone());
        }
        store
            .retry_run_settlement_debts()
            .await
            .map_err(|error| error.to_string())?;
        assert!(dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(
            store
                .get_run("receipt-debt")?
                .ok_or_else(|| "run missing".to_string())?
                .status,
            TaskRunStatus::Failed
        );
        assert!(
            store
                .unresolved_physical_owner_intents("receipt-debt")?
                .is_empty()
        );
        let before_duplicate_ack = std::fs::read(&event_path).map_err(|error| error.to_string())?;
        store.acknowledge_physical_owner_intent(&original)?;
        assert_eq!(
            std::fs::read(&event_path).map_err(|error| error.to_string())?,
            before_duplicate_ack
        );
        assert_eq!(store.active_run_driver_count()?, 0);
        assert_eq!(store.active_run_driver_receipt_count()?, 0);
        let transition = store
            .begin_workspace_transition()
            .await
            .map_err(|error| error.to_string())?;
        drop(transition);
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn dropped_waiter_shutdown_settles_run_and_releases_execution_receipt()
    -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        store
            .create_run(
                "dropped-waiter",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "settle dropped waiter",
                "",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("dropped-waiter", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        let generation_lease = store
            .lease_active_workspace_generation()
            .map_err(|error| error.to_string())?;
        let cancel = echo_agent::agent::CancellationToken::new();
        let driver_cancel = cancel.clone();
        let admission = store
            .reserve_run_driver_admission("dropped-waiter".to_string(), cancel)
            .map_err(|error| error.to_string())?;
        let dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let dropped_for_driver = std::sync::Arc::clone(&dropped);
        let waiter = store
            .spawn_run_driver(
                admission,
                generation_lease,
                move |mut receipt_owner| async move {
                    receipt_owner
                        .retain(DropFlag(dropped_for_driver))
                        .map_err(|error| error.to_string())?;
                    driver_cancel.cancelled().await;
                    Err::<(), String>("driver cancelled during shutdown".to_string())
                },
            )
            .map_err(|error| error.to_string())?;
        drop(waiter);

        tokio::time::timeout(
            std::time::Duration::from_secs(2),
            store.shutdown_run_drivers(),
        )
        .await
        .map_err(|_| "TaskRun driver shutdown timed out".to_string())?
        .map_err(|error| error.to_string())?;
        let run = store
            .get_run("dropped-waiter")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "settled run disappeared".to_string())?;
        assert_eq!(run.status, TaskRunStatus::Cancelled);
        assert!(dropped.load(std::sync::atomic::Ordering::SeqCst));
        Ok(())
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn shutdown_reporter_failure_is_published_once_to_all_waiters() -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        store.abort_next_run_driver_shutdown_reporter_for_test();

        let first_store = std::sync::Arc::clone(&store);
        let second_store = std::sync::Arc::clone(&store);
        let (first, second) = tokio::time::timeout(std::time::Duration::from_secs(2), async move {
            tokio::join!(
                first_store.shutdown_run_drivers(),
                second_store.shutdown_run_drivers()
            )
        })
        .await
        .map_err(|_| "concurrent TaskRun shutdown waiters timed out".to_string())?;
        let first = first.err().ok_or_else(|| {
            "first shutdown waiter did not observe the reporter failure".to_string()
        })?;
        let second = second.err().ok_or_else(|| {
            "second shutdown waiter did not observe the reporter failure".to_string()
        })?;
        assert_eq!(first, second);
        assert!(
            first
                .driver_errors
                .iter()
                .any(|error| error.contains("shutdown reporter failed"))
        );

        let repeated = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            store.shutdown_run_drivers(),
        )
        .await
        .map_err(|_| "repeated TaskRun shutdown waiter timed out".to_string())?
        .err()
        .ok_or_else(|| "repeated shutdown waiter lost the reporter failure".to_string())?;
        assert_eq!(first, repeated);
        assert_eq!(store.active_run_driver_count()?, 0);
        assert_eq!(store.active_run_driver_receipt_count()?, 0);
        Ok(())
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn shutdown_waits_for_parked_prepare_and_reports_its_permanent_debt() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let blocked_root = temp.path().join("tasks-blocked");
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory_with_shadow_root(root.clone())
                .map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        let physical_fault = store.block_shadow_after_physical_completion_for_test(
            "parked-prepare",
            blocked_root.clone(),
        )?;

        store
            .create_run(
                "parked-prepare",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "settle an accepted preparation",
                "",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,

                plan_id: "parked-prepare-plan".to_string(),
                run_id: "parked-prepare".to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: task_goal_sha256("settle an accepted preparation"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: "parked-prepare-task".to_string(),
                    title: "Settle preparation".to_string(),
                    ..Default::default()
                }],
            })
            .map_err(|error| error.to_string())?;
        store
            .transition_run("parked-prepare", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .transition_run("parked-prepare", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;

        let dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let retained = dropped.clone();
        let (prepare_started_tx, prepare_started_rx) = tokio::sync::oneshot::channel::<()>();
        let (continue_prepare_tx, continue_prepare_rx) = std::sync::mpsc::channel::<()>();
        let preparation_store = std::sync::Arc::clone(&store);
        let run_store = std::sync::Arc::clone(&store);
        let preparation = tokio::task::spawn_blocking(move || {
            preparation_store.spawn_supervised_run_driver(
                "parked-prepare".to_string(),
                echo_agent::agent::CancellationToken::new(),
                || Ok(()),
                move |()| {
                    prepare_started_tx.send(()).map_err(|_| {
                        StoreError::InvalidPlan(
                            "shutdown test stopped before prepare admission".to_string(),
                        )
                    })?;
                    continue_prepare_rx
                        .recv_timeout(std::time::Duration::from_secs(2))
                        .map_err(|error| {
                            StoreError::InvalidPlan(format!(
                                "parked prepare was not released: {error}"
                            ))
                        })?;
                    run_store.resume_task_run("parked-prepare")?;
                    Ok((
                        (),
                        move |mut receipt_owner: RunDriverReceiptOwner| async move {
                            receipt_owner
                                .retain(DropFlag(retained))
                                .map_err(|error| error.to_string())?;

                            Err::<(), String>("injected prepared driver failure".to_string())
                        },
                    ))
                },
            )
        });
        tokio::time::timeout(std::time::Duration::from_secs(2), prepare_started_rx)
            .await
            .map_err(|_| "parked prepare did not start".to_string())?
            .map_err(|_| "parked prepare start sender closed".to_string())?;

        let shutdown_store = std::sync::Arc::clone(&store);
        let shutdown = tokio::spawn(async move { shutdown_store.shutdown_run_drivers().await });
        tokio::time::timeout(
            std::time::Duration::from_secs(2),
            store.wait_run_driver_shutdown_started(),
        )
        .await
        .map_err(|_| "TaskRun shutdown did not close driver admission".to_string())?;
        if store
            .reserve_run_driver_admission(
                "late-after-shutdown".to_string(),
                echo_agent::agent::CancellationToken::new(),
            )
            .is_ok()
        {
            return Err("TaskRun shutdown accepted a late driver reservation".to_string());
        }
        if shutdown.is_finished() {
            return Err("shutdown overtook an accepted parked preparation".to_string());
        }

        continue_prepare_tx
            .send(())
            .map_err(|_| "parked prepare receiver closed".to_string())?;
        let (_, result_waiter) =
            tokio::time::timeout(std::time::Duration::from_secs(2), preparation)
                .await
                .map_err(|_| "parked prepare did not register its driver".to_string())?
                .map_err(|error| error.to_string())?
                .map_err(|error| error.to_string())?;
        drop(result_waiter);

        let shutdown_error = tokio::time::timeout(std::time::Duration::from_secs(2), shutdown)
            .await
            .map_err(|_| "TaskRun shutdown did not settle parked preparation".to_string())?
            .map_err(|error| error.to_string())?
            .err()
            .ok_or_else(|| "permanent prepared driver debt was not reported".to_string())?;
        let physical_event = physical_fault
            .lock()
            .map_err(|_| "physical completion fixture lock poisoned".to_string())?
            .clone()
            .ok_or_else(|| "physical completion did not reach fault boundary".to_string())??;
        assert_eq!(physical_event.run_id, "parked-prepare");
        assert_eq!(
            physical_event
                .payload
                .get("physical_owner_intent")
                .and_then(|intent| intent.get("physical_terminal_observed"))
                .and_then(serde_json::Value::as_bool),
            Some(true)
        );
        assert_eq!(shutdown_error.abandoned_settlements.len(), 1);
        let debt = shutdown_error
            .abandoned_settlements
            .first()
            .ok_or_else(|| "original terminal debt diagnostic missing".to_string())?;
        assert_eq!(debt.run_id, "parked-prepare");
        assert!(debt.driver_token.is_some());
        assert_eq!(
            debt.root,
            std::fs::canonicalize(temp.path())
                .map_err(|error| error.to_string())?
                .join("tasks")
        );
        assert_eq!(debt.target, TaskRunStatus::Cancelled);
        assert!(!debt.error.is_empty());
        assert_eq!(store.active_run_driver_count()?, 1);
        assert_eq!(store.active_run_driver_receipt_count()?, 1);
        assert!(!dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(store.begin_workspace_transition().await.is_err());

        std::fs::remove_file(temp.path().join("tasks")).map_err(|error| error.to_string())?;
        std::fs::rename(blocked_root, temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        store
            .retry_run_settlement_debts()
            .await
            .map_err(|error| error.to_string())?;
        assert!(dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(store.active_run_driver_receipt_count()?, 0);
        let transition = store
            .begin_workspace_transition()
            .await
            .map_err(|error| error.to_string())?;
        drop(transition);
        let run = store
            .get_run("parked-prepare")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "parked prepared run disappeared".to_string())?;
        assert_eq!(run.status, TaskRunStatus::Cancelled);
        Ok(())
    }

    #[tokio::test]
    async fn independent_run_drivers_release_only_their_exact_receipts() -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        store
            .create_run(
                "overlap",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "exact driver receipt",
                "",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("overlap", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .transition_run("overlap", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;

        store
            .create_run(
                "overlap-second",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "independent receipt",
                "",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("overlap-second", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .transition_run("overlap-second", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;
        let (first_started_tx, first_started_rx) = tokio::sync::oneshot::channel();
        let first_dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let second_dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let (first_tx, first_rx) = tokio::sync::oneshot::channel::<()>();
        let (second_tx, second_rx) = tokio::sync::oneshot::channel::<()>();
        let first_flag = std::sync::Arc::clone(&first_dropped);
        let first_admission = test_driver_admission(&store, "overlap")?;
        let first_waiter = store
            .spawn_run_driver(
                first_admission,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
                move |mut receipt_owner| async move {
                    receipt_owner
                        .retain(DropFlag(first_flag))
                        .map_err(|error| error.to_string())?;
                    first_started_tx
                        .send(())
                        .map_err(|_| "first start observer closed".to_string())?;
                    first_rx.await.map_err(|error| error.to_string())
                },
            )
            .map_err(|error| error.to_string())?;
        first_started_rx.await.map_err(|error| error.to_string())?;
        let rejection = store
            .reserve_run_driver_admission(
                "overlap".to_string(),
                echo_agent::agent::CancellationToken::new(),
            )
            .err()
            .ok_or_else(|| "same unsettled run accepted a second physical owner".to_string())?;
        assert!(
            matches!(rejection, StoreError::RecoveryBlocked { run_id, .. } if run_id == "overlap")
        );
        let second_flag = std::sync::Arc::clone(&second_dropped);
        let second_admission = test_driver_admission(&store, "overlap-second")?;
        let second_waiter = store
            .spawn_run_driver(
                second_admission,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
                move |mut receipt_owner| async move {
                    receipt_owner
                        .retain(DropFlag(second_flag))
                        .map_err(|error| error.to_string())?;
                    second_rx.await.map_err(|error| error.to_string())
                },
            )
            .map_err(|error| error.to_string())?;

        first_tx
            .send(())
            .map_err(|_| "first driver receiver closed".to_string())?;
        first_waiter.await.map_err(|error| error.to_string())??;
        assert!(first_dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(!second_dropped.load(std::sync::atomic::Ordering::SeqCst));

        second_tx
            .send(())
            .map_err(|_| "second driver receiver closed".to_string())?;
        second_waiter.await.map_err(|error| error.to_string())??;
        assert!(second_dropped.load(std::sync::atomic::Ordering::SeqCst));
        store.wait_for_run_driver_idle("overlap").await;
        store.wait_for_run_driver_idle("overlap-second").await;
        assert!(!store.is_run_active("overlap"));
        assert!(!store.is_run_active("overlap-second"));
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())
    }

    #[test]
    fn overlapping_run_cancellation_tokens_release_in_any_order_and_cancel_together()
    -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        store
            .create_run(
                "cancel-overlap",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "cancel every active driver",
                "",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("cancel-overlap", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        let first = echo_agent::agent::CancellationToken::new();
        let second = echo_agent::agent::CancellationToken::new();
        let first_guard = store
            .register_run_cancellation("cancel-overlap", first.clone())
            .map_err(|error| error.to_string())?;
        let second_guard = store
            .register_run_cancellation("cancel-overlap", second.clone())
            .map_err(|error| error.to_string())?;
        assert!(
            store
                .request_pause("cancel-overlap")
                .map_err(|error| error.to_string())?
        );
        assert!(first.is_cancelled());
        assert!(second.is_cancelled());

        drop(first_guard);
        assert!(store.is_run_active("cancel-overlap"));
        drop(second_guard);
        assert!(!store.is_run_active("cancel-overlap"));

        let shared = echo_agent::agent::CancellationToken::new();
        let third_guard = store
            .register_run_cancellation("cancel-overlap", shared.clone())
            .map_err(|error| error.to_string())?;
        let fourth_guard = store
            .register_run_cancellation("cancel-overlap", shared)
            .map_err(|error| error.to_string())?;
        drop(fourth_guard);
        assert!(store.is_run_active("cancel-overlap"));
        drop(third_guard);
        assert!(!store.is_run_active("cancel-overlap"));
        Ok(())
    }

    #[tokio::test]
    async fn opaque_driver_context_rejects_forged_wrong_stale_and_cross_run_receipts()
    -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        for run_id in ["context-overlap", "context-second", "context-other"] {
            store
                .create_run(
                    run_id,
                    "workspace-a",
                    "conversation",
                    "message",
                    DomainProfile::General,
                    "opaque driver execution context",
                    "",
                    AttendedMode::Unattended,
                )
                .map_err(|error| error.to_string())?;
            store
                .transition_run(run_id, TaskRunStatus::Running)
                .map_err(|error| error.to_string())?;
        }

        let (first_context_tx, first_context_rx) = std::sync::mpsc::sync_channel(1);
        let (finish_first_tx, finish_first_rx) = tokio::sync::oneshot::channel::<()>();
        let first_store = std::sync::Arc::clone(&store);
        let first_waiter = store
            .spawn_run_driver(
                test_driver_admission(&store, "context-overlap")?,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
                move |receipt_owner| {
                    let context_sent = first_context_tx
                        .send(receipt_owner.execution_context_id())
                        .map_err(|_| "first context receiver closed".to_string());
                    async move {
                        context_sent?;
                        finish_first_rx.await.map_err(|error| error.to_string())?;
                        first_store
                            .finalize_run("context-overlap", TaskRunStatus::Completed, None)
                            .map(|_| ())
                            .map_err(|error| error.to_string())
                    }
                },
            )
            .map_err(|error| error.to_string())?;
        let first_context = first_context_rx
            .recv_timeout(std::time::Duration::from_secs(2))
            .map_err(|error| format!("first driver context was not published: {error}"))?;

        let second_store = store.clone();
        let (second_context_tx, second_context_rx) = std::sync::mpsc::sync_channel(1);
        let (finish_second_tx, finish_second_rx) = tokio::sync::oneshot::channel::<()>();
        let second_waiter = store
            .spawn_run_driver(
                test_driver_admission(&store, "context-second")?,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
                move |receipt_owner| {
                    let context_sent = second_context_tx
                        .send(receipt_owner.execution_context_id())
                        .map_err(|_| "second context receiver closed".to_string());
                    async move {
                        context_sent?;
                        finish_second_rx.await.map_err(|error| error.to_string())?;
                        second_store
                            .finalize_run("context-second", TaskRunStatus::Completed, None)
                            .map(|_| ())
                            .map_err(|error| error.to_string())
                    }
                },
            )
            .map_err(|error| error.to_string())?;
        let second_context = second_context_rx
            .recv_timeout(std::time::Duration::from_secs(2))
            .map_err(|error| format!("second driver context was not published: {error}"))?;
        assert_ne!(first_context, second_context);

        let (other_context_tx, other_context_rx) = std::sync::mpsc::sync_channel(1);
        let (finish_other_tx, finish_other_rx) = tokio::sync::oneshot::channel::<()>();
        let other_store = std::sync::Arc::clone(&store);
        let other_waiter = store
            .spawn_run_driver(
                test_driver_admission(&store, "context-other")?,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
                move |receipt_owner| {
                    let context_sent = other_context_tx
                        .send(receipt_owner.execution_context_id())
                        .map_err(|_| "other context receiver closed".to_string());
                    async move {
                        context_sent?;
                        finish_other_rx.await.map_err(|error| error.to_string())?;
                        other_store
                            .finalize_run("context-other", TaskRunStatus::Completed, None)
                            .map(|_| ())
                            .map_err(|error| error.to_string())
                    }
                },
            )
            .map_err(|error| error.to_string())?;
        let other_context = other_context_rx
            .recv_timeout(std::time::Duration::from_secs(2))
            .map_err(|error| format!("other driver context was not published: {error}"))?;

        let first_released = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        store
            .retain_run_driver_receipt_from_context(
                "context-overlap",
                &first_context,
                DropFlag(std::sync::Arc::clone(&first_released)),
            )
            .map_err(|_| "first exact context was rejected".to_string())?;
        let second_released = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        store
            .retain_run_driver_receipt_from_context(
                "context-second",
                &second_context,
                DropFlag(std::sync::Arc::clone(&second_released)),
            )
            .map_err(|_| "second exact context was rejected".to_string())?;

        for (label, run_id, context_id) in [
            (
                "forged sequential token",
                "context-overlap",
                "eko-task-driver:2".to_string(),
            ),
            (
                "wrong nonce",
                "context-overlap",
                format!("{first_context}-wrong"),
            ),
            (
                "cross-run context",
                "context-overlap",
                other_context.clone(),
            ),
        ] {
            let rejected_released = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
            let rejected = store
                .retain_run_driver_receipt_from_context(
                    run_id,
                    &context_id,
                    DropFlag(std::sync::Arc::clone(&rejected_released)),
                )
                .err()
                .ok_or_else(|| format!("{label} unexpectedly retained a receipt"))?;
            drop(rejected);
            assert!(rejected_released.load(std::sync::atomic::Ordering::SeqCst));
        }
        assert_eq!(store.active_run_driver_receipt_count()?, 2);

        finish_first_tx
            .send(())
            .map_err(|_| "first driver receiver closed".to_string())?;
        first_waiter.await.map_err(|error| error.to_string())??;
        assert!(first_released.load(std::sync::atomic::Ordering::SeqCst));
        assert!(!second_released.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(store.active_run_driver_receipt_count()?, 1);

        let stale_released = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let stale = store
            .retain_run_driver_receipt_from_context(
                "context-overlap",
                &first_context,
                DropFlag(std::sync::Arc::clone(&stale_released)),
            )
            .err()
            .ok_or_else(|| "stale driver context unexpectedly retained a receipt".to_string())?;
        drop(stale);
        assert!(stale_released.load(std::sync::atomic::Ordering::SeqCst));
        assert!(!second_released.load(std::sync::atomic::Ordering::SeqCst));

        finish_second_tx
            .send(())
            .map_err(|_| "second driver receiver closed".to_string())?;
        second_waiter.await.map_err(|error| error.to_string())??;
        assert!(second_released.load(std::sync::atomic::Ordering::SeqCst));

        finish_other_tx
            .send(())
            .map_err(|_| "other driver receiver closed".to_string())?;
        other_waiter.await.map_err(|error| error.to_string())??;
        assert_eq!(store.active_run_driver_receipt_count()?, 0);
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn independent_driver_cleanup_failure_retains_only_its_exact_receipt()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let blocked_root = temp.path().join("tasks-blocked");
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory_with_shadow_root(root.clone())
                .map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        store
            .create_run(
                "overlap-abandon",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "exact abandoned driver receipt",
                "",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("overlap-abandon", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;

        store
            .create_run(
                "independent-completed",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "independent completion",
                "",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("independent-completed", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        let first_store = store.clone();
        let first_dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let second_dropped = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let (first_started_tx, first_started_rx) = tokio::sync::oneshot::channel::<()>();
        let (finish_first_tx, finish_first_rx) = tokio::sync::oneshot::channel::<()>();
        let first_flag = std::sync::Arc::clone(&first_dropped);
        let first_admission = test_driver_admission(&store, "overlap-abandon")?;
        let first_waiter = store
            .spawn_run_driver(
                first_admission,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
                move |mut receipt_owner| async move {
                    receipt_owner
                        .retain(DropFlag(first_flag))
                        .map_err(|error| error.to_string())?;
                    first_started_tx
                        .send(())
                        .map_err(|_| "first driver start receiver closed".to_string())?;
                    finish_first_rx.await.map_err(|error| error.to_string())?;
                    first_store
                        .finalize_run("overlap-abandon", TaskRunStatus::Completed, None)
                        .map_err(|error| error.to_string())?;
                    std::fs::rename(&root, &blocked_root)
                        .map_err(|error| format!("block task root: {error}"))?;
                    std::fs::write(&root, b"block directory recreation")
                        .map_err(|error| format!("replace task root: {error}"))?;
                    Err::<(), String>("injected first driver failure".to_string())
                },
            )
            .map_err(|error| error.to_string())?;
        first_started_rx.await.map_err(|error| error.to_string())?;

        let second_flag = std::sync::Arc::clone(&second_dropped);
        let store_for_second = std::sync::Arc::clone(&store);
        let second_admission = test_driver_admission(&store, "independent-completed")?;
        let second_waiter = store
            .spawn_run_driver(
                second_admission,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
                move |mut receipt_owner| async move {
                    receipt_owner
                        .retain(DropFlag(second_flag))
                        .map_err(|error| error.to_string())?;
                    store_for_second
                        .finalize_run("independent-completed", TaskRunStatus::Completed, None)
                        .map(|_| ())
                        .map_err(|error| error.to_string())
                },
            )
            .map_err(|error| error.to_string())?;
        second_waiter.await.map_err(|error| error.to_string())??;
        assert!(second_dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(!first_dropped.load(std::sync::atomic::Ordering::SeqCst));

        finish_first_tx
            .send(())
            .map_err(|_| "first driver receiver closed".to_string())?;
        let first_error = first_waiter
            .await
            .map_err(|error| error.to_string())?
            .err()
            .ok_or_else(|| "first driver failure was not reported".to_string())?;
        assert!(
            first_error.contains("physical receipt identity"),
            "actual first_error: {first_error}"
        );
        assert_eq!(store.active_run_driver_receipt_count()?, 1);
        let shutdown_error = store
            .shutdown_run_drivers()
            .await
            .err()
            .ok_or_else(|| "original first driver cleanup failure was hidden".to_string())?;
        assert!(shutdown_error.abandoned_settlements.is_empty());
        assert!(
            shutdown_error
                .driver_errors
                .iter()
                .any(|error| error.contains("overlap-abandon") && error.contains("owner"))
        );
        assert!(!first_dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(second_dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(store.active_run_driver_count()?, 1);
        {
            let supervisor = store
                .run_driver_supervisor
                .lock()
                .map_err(|_| "supervisor lock poisoned".to_string())?;
            assert_eq!(supervisor.uncertain_drivers.len(), 1);
            assert!(supervisor.settlement_debts.is_empty());
            let original = supervisor
                .uncertain_drivers
                .values()
                .next()
                .ok_or_else(|| "original completion-write owner missing".to_string())?;
            assert_eq!(original.intent.run_id, "overlap-abandon");
            assert!(original.physical_terminal_observed);
            assert!(!original.intent.physical_terminal_observed);
        }
        assert_eq!(store.active_run_driver_receipt_count()?, 1);

        std::fs::remove_file(temp.path().join("tasks")).map_err(|error| error.to_string())?;
        std::fs::rename(temp.path().join("tasks-blocked"), temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        store
            .retry_run_settlement_debts()
            .await
            .map_err(|error| error.to_string())?;
        assert!(first_dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert!(second_dropped.load(std::sync::atomic::Ordering::SeqCst));
        assert_eq!(store.active_run_driver_receipt_count()?, 0);
        let run = store
            .get_run("overlap-abandon")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "overlap run disappeared".to_string())?;
        assert_eq!(run.status, TaskRunStatus::Completed);
        Ok(())
    }

    #[tokio::test]
    async fn exact_driver_releases_pool_before_memory_generation() -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        let _resource_scope = store.test_resource_scope();
        store
            .create_run(
                "lifo-receipts",
                "workspace-a",
                "conversation",
                "message",
                DomainProfile::General,
                "release pool before memory",
                "",
                AttendedMode::Unattended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("lifo-receipts", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .transition_run("lifo-receipts", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;

        let release_order = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let memory_order = std::sync::Arc::clone(&release_order);
        let pool_order = std::sync::Arc::clone(&release_order);
        let admission = test_driver_admission(&store, "lifo-receipts")?;
        let waiter = store
            .spawn_run_driver(
                admission,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
                move |mut receipt_owner| async move {
                    receipt_owner
                        .retain(ReleaseOrder(memory_order, "memory"))
                        .map_err(|error| error.to_string())?;
                    receipt_owner
                        .retain(ReleaseOrder(pool_order, "pool"))
                        .map_err(|error| error.to_string())?;
                    Ok::<(), String>(())
                },
            )
            .map_err(|error| error.to_string())?;
        waiter.await.map_err(|error| error.to_string())??;
        let observed = release_order
            .lock()
            .map_err(|_| "release order lock is poisoned".to_string())?
            .clone();
        assert_eq!(observed, ["pool", "memory"]);
        store
            .shutdown_run_drivers()
            .await
            .map_err(|error| error.to_string())
    }

    #[test]
    fn create_run_emits_run_created_event() -> Result<(), StoreError> {
        let s = fresh()?;
        let run = s.create_run(
            "r1",
            "ws",
            "c1",
            "m1",
            DomainProfile::AiCoding,
            "review runtime",
            "",
            AttendedMode::Attended,
        )?;
        assert_eq!(run.status, TaskRunStatus::Pending);
        let evs = s.list_events("r1", 0)?;
        assert_eq!(evs.len(), 1);
        assert_eq!(evs[0].event_type, RuntimeEventKind::RunCreated);
        Ok(())
    }

    #[test]
    fn artifact_round_trip_preserves_path_and_metadata() -> std::result::Result<(), String> {
        let store = TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        store
            .create_run(
                "artifact-run",
                "ws",
                "conversation",
                "message",
                DomainProfile::General,
                "artifact round trip",
                "",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        let artifact = Artifact {
            id: "artifact-1".to_string(),
            run_id: "artifact-run".to_string(),
            task_id: None,
            kind: ArtifactKind::Trace,
            title: "Complete tool output".to_string(),
            path: Some("/tmp/tool-output.log".to_string()),
            metadata: serde_json::json!({
                "sha256": "abcdef",
                "retention": "conversation_or_30d",
            }),
        };
        store
            .add_artifact(&artifact)
            .map_err(|error| error.to_string())?;

        let artifacts = store
            .list_artifacts("artifact-run")
            .map_err(|error| error.to_string())?;
        let restored = artifacts
            .first()
            .ok_or_else(|| "artifact was not restored".to_string())?;
        assert_eq!(restored.path, artifact.path);
        assert_eq!(restored.metadata, artifact.metadata);
        Ok(())
    }

    #[test]
    fn transition_run_appends_status_event_atomically() -> Result<(), StoreError> {
        let s = fresh()?;
        s.create_run(
            "r1",
            "ws",
            "c1",
            "m1",
            DomainProfile::General,
            "g",
            "",
            AttendedMode::Attended,
        )?;
        let run = s.transition_run("r1", TaskRunStatus::Running)?;
        assert_eq!(run.status, TaskRunStatus::Running);
        let evs = s.list_events("r1", 0)?;
        // RunCreated + RunStatusChanged
        assert_eq!(evs.len(), 2);
        assert_eq!(evs[1].event_type, RuntimeEventKind::RunStatusChanged);
        Ok(())
    }

    #[test]
    fn run_goal_update_is_revisioned_audited_and_deferred() -> Result<(), String> {
        let store = TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        let created = store
            .create_run(
                "goal-run",
                "ws",
                "conversation",
                "message",
                DomainProfile::General,
                "original goal",
                "",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        assert_eq!(created.goal_revision, 1);
        assert_eq!(created.goal_sha256, task_goal_sha256("original goal"));
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,

                plan_id: "goal-plan".to_string(),
                run_id: "goal-run".to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: task_goal_sha256("original goal"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: "goal-task".to_string(),
                    title: "Satisfy the original goal".to_string(),
                    description: "Produce traceable evidence".to_string(),
                    ..PlanTask::default()
                }],
            })
            .map_err(|error| error.to_string())?;
        store
            .transition_run("goal-run", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .transition_run("goal-run", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;

        let updated = store
            .update_run_goal(
                "goal-run",
                1,
                "revised goal",
                "user narrowed the requested scope",
                RunGoalActorSource::Cli,
            )
            .map_err(|error| error.to_string())?;
        assert_eq!(updated.goal, "revised goal");
        assert_eq!(updated.goal_revision, 2);
        assert_eq!(updated.goal_sha256, task_goal_sha256("revised goal"));

        let event = store
            .list_events("goal-run", 0)
            .map_err(|error| error.to_string())?
            .into_iter()
            .find(|event| event.event_type == RuntimeEventKind::RunGoalUpdated)
            .ok_or_else(|| "RunGoalUpdated was not persisted".to_string())?;
        assert_eq!(event.payload["old_goal_revision"], 1);
        assert_eq!(event.payload["new_goal_revision"], 2);
        assert_eq!(
            event.payload["old_goal_sha256"],
            task_goal_sha256("original goal")
        );
        assert_eq!(
            event.payload["new_goal_sha256"],
            task_goal_sha256("revised goal")
        );
        assert_eq!(event.payload["actor_source"], "cli");
        assert!(
            event
                .payload
                .get("actor_user_id")
                .and_then(serde_json::Value::as_str)
                .is_some_and(|value| !value.is_empty())
        );

        let continuation = store
            .get_run_state("goal-run")
            .map_err(|error| error.to_string())?
            .and_then(|state| state.continuation)
            .ok_or_else(|| "continuation projection was not created".to_string())?;
        assert!(continuation.deferred);
        assert_eq!(
            continuation.deferred_reason.as_deref(),
            Some("goal_revision_unbound")
        );
        assert_eq!(
            last_frame_event_types(&store, "goal-run")?,
            ["run_goal_updated", "requirement_evidence_invalidated"]
        );
        Ok(())
    }

    #[test]
    fn run_goal_update_rejects_stale_revision_without_an_event() -> Result<(), String> {
        let store = TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        create_paused_run(&store, "goal-conflict").map_err(|error| error.to_string())?;
        let before = store
            .list_events("goal-conflict", 0)
            .map_err(|error| error.to_string())?
            .len();

        let error = store
            .update_run_goal(
                "goal-conflict",
                9,
                "revised goal",
                "explicit correction",
                RunGoalActorSource::Tui,
            )
            .err()
            .ok_or_else(|| "stale goal revision was accepted".to_string())?;
        assert!(matches!(error, StoreError::GoalConflict { .. }));
        assert_eq!(
            store
                .list_events("goal-conflict", 0)
                .map_err(|error| error.to_string())?
                .len(),
            before
        );
        Ok(())
    }

    #[test]
    fn run_goal_update_requires_a_quiescent_paused_run() -> Result<(), String> {
        let active_turn = TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        active_turn
            .create_run(
                "active-turn",
                "ws",
                "conversation",
                "message",
                DomainProfile::General,
                "original goal",
                "",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        active_turn
            .configure_run_continuation("active-turn", true, false, None, None)
            .map_err(|error| error.to_string())?;
        active_turn
            .transition_run("active-turn", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        let claim = active_turn
            .claim_run_turn(
                "active-turn",
                "turn-1",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(claim, RunTurnClaimOutcome::Started(_)));
        active_turn
            .transition_run("active-turn", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;

        let active_subagent =
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        create_paused_run(&active_subagent, "active-subagent")
            .map_err(|error| error.to_string())?;
        active_subagent
            .record_subagent_assigned(
                "active-subagent",
                "task-1",
                "execution-1",
                "researcher",
                "research",
                1,
                1,
                false,
                false,
            )
            .map_err(|error| error.to_string())?;

        let active_cell = TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?;
        create_paused_run(&active_cell, "active-cell").map_err(|error| error.to_string())?;
        active_cell
            .record_background_cell_started(
                "active-cell",
                "cell-1",
                "test cell",
                "command-hash",
                None,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;

        let active_driver = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        create_paused_run(active_driver.as_ref(), "active-driver")
            .map_err(|error| error.to_string())?;
        let _driver_registration = active_driver
            .register_run_cancellation("active-driver", echo_agent::agent::CancellationToken::new())
            .map_err(|error| error.to_string())?;

        for (store, run_id, expected_reason) in [
            (&active_turn, "active-turn", "active RunTurn"),
            (&active_subagent, "active-subagent", "active Subagent"),
            (&active_cell, "active-cell", "active command cell"),
            (active_driver.as_ref(), "active-driver", "active driver"),
        ] {
            let error = store
                .update_run_goal(
                    run_id,
                    1,
                    "revised goal",
                    "explicit correction",
                    RunGoalActorSource::Gui,
                )
                .err()
                .ok_or_else(|| format!("goal update was accepted for {run_id}"))?;
            assert!(matches!(
                error,
                StoreError::GoalUpdateRejected { reason, .. }
                    if reason.contains(expected_reason)
            ));
        }
        Ok(())
    }

    #[test]
    fn task_update_rebinds_plan_before_goal_updated_run_can_resume() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.transition_run("r1", TaskRunStatus::Paused)?;
        store.update_run_goal(
            "r1",
            1,
            "revised goal",
            "user changed the acceptance target",
            RunGoalActorSource::Tui,
        )?;

        let stale_plan = store
            .get_plan("r1")?
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?;
        assert_eq!(stale_plan.goal_revision, 1);
        let resume_error = store
            .resume_task_run("r1")
            .err()
            .ok_or_else(|| StoreError::InvalidPlan("stale plan resumed".to_string()))?;
        assert!(
            matches!(
                &resume_error,
                StoreError::PlanGoalMismatch {
                    plan_goal_revision: 1,
                    run_goal_revision: 2,
                    ..
                }
            ),
            "unexpected resume error: {resume_error}"
        );

        let rebound = store.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "align the task graph with goal revision 2".to_string(),
                operations: vec![TaskUpdateOperation::Update {
                    task_id: "t1".to_string(),
                    patch: Box::new(TaskPatch {
                        title: Some("Review revised runtime scope".to_string()),
                        ..Default::default()
                    }),
                }],
            },
        )?;
        assert_eq!(rebound.revision, 2);
        assert_eq!(rebound.goal_revision, 2);
        assert_eq!(rebound.goal_sha256, task_goal_sha256("revised goal"));
        assert_eq!(store.resume_task_run("r1")?.status, TaskRunStatus::Running);

        let latest_plan_event = store
            .list_events("r1", 0)?
            .into_iter()
            .rev()
            .find(|event| event.event_type == RuntimeEventKind::PlanRevisionCommitted)
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?;
        assert!(latest_plan_event.payload["plan"].get("goal").is_none());
        Ok(())
    }

    #[test]
    fn illegal_transition_is_rejected_and_leaves_no_event() -> Result<(), StoreError> {
        let s = fresh()?;
        s.create_run(
            "r1",
            "ws",
            "c1",
            "m1",
            DomainProfile::General,
            "g",
            "",
            AttendedMode::Attended,
        )?;
        // First transition to Running (was Pending → now legal).
        s.transition_run("r1", TaskRunStatus::Running)?;
        // Running → Completed is legal. Now test that Completed → Running is
        // illegal (terminal state → non-terminal is always rejected).
        let _before = s.list_events("r1", 0)?.len();
        s.transition_run("r1", TaskRunStatus::Completed)?;
        let before_terminal = s.list_events("r1", 0)?.len();
        let err = s
            .transition_run("r1", TaskRunStatus::Running)
            .err()
            .ok_or_else(|| {
                StoreError::InvalidPlan("illegal transition unexpectedly succeeded".to_string())
            })?;
        assert!(matches!(err, StoreError::IllegalTransition { .. }));
        // No new event was appended — the tx rolled back.
        assert_eq!(s.list_events("r1", 0)?.len(), before_terminal);
        Ok(())
    }

    #[test]
    fn attach_plan_creates_tasks_and_todos() -> Result<(), StoreError> {
        let s = fresh()?;
        s.create_run(
            "r1",
            "ws",
            "c1",
            "m1",
            DomainProfile::General,
            "g",
            "",
            AttendedMode::Attended,
        )?;
        // attach_plan no longer changes the run status; caller decides.
        let plan = TaskPlan {
            domain_binding: None,

            plan_id: "p1".into(),
            run_id: "r1".into(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("g"),
            assumptions: vec!["a".into()],
            risks: vec![],
            execution_mode: ExecutionMode::Parallel,
            tasks: vec![PlanTask {
                id: "t1".into(),
                title: "Review runtime".into(),
                kind: PlanTaskKind::ReadOnlyReview,
                agent_role: "code_reviewer".into(),
                ..Default::default()
            }],
        };
        s.attach_plan_for_test(&plan)?;

        let loaded = s
            .get_plan("r1")?
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?;
        assert_eq!(loaded.tasks.len(), 1);
        assert_eq!(loaded.tasks[0].id, "t1");

        let todos = s.list_todos("r1")?;
        assert_eq!(todos.len(), 1);
        assert_eq!(todos[0].task_id, "t1");
        assert_eq!(todos[0].status, TodoStatus::Pending);

        let run = s
            .get_run("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        // attach_plan no longer transitions status; run stays Pending.
        assert_eq!(run.status, TaskRunStatus::Pending);
        assert_eq!(run.plan_id.as_deref(), Some("p1"));
        Ok(())
    }

    #[test]
    fn set_task_status_updates_task_todo_and_event_together() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        s.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("code_reviewer"),
            None,
        )?;
        let todos = s.list_todos("r1")?;
        assert_eq!(todos[0].status, TodoStatus::Running);
        assert_eq!(todos[0].owner_agent.as_deref(), Some("code_reviewer"));
        assert!(todos[0].started_at.is_some());

        let evs = s.list_events("r1", 0)?;
        assert!(
            evs.iter()
                .any(|e| e.event_type == RuntimeEventKind::TaskStarted)
        );
        Ok(())
    }

    #[test]
    fn task_terminal_events_follow_typed_status_not_detail_text() -> Result<(), StoreError> {
        let failed = fresh()?;
        seed_plan(&failed)?;
        failed.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Failed(String::new()),
            Some("code_reviewer"),
            Some("the report mentions timeout and cancelled behavior"),
        )?;
        let failed_events = failed.list_events("r1", 0)?;
        assert!(
            failed_events
                .iter()
                .any(|event| event.event_type == RuntimeEventKind::TaskFailed)
        );
        assert!(failed_events.iter().all(|event| {
            !matches!(
                event.event_type,
                RuntimeEventKind::TaskTimedOut | RuntimeEventKind::TaskCancelled
            )
        }));

        let timed_out = fresh()?;
        seed_plan(&timed_out)?;
        timed_out.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::TimedOut {
                error: String::new(),
            },
            Some("code_reviewer"),
            Some("provider deadline elapsed"),
        )?;
        assert!(
            timed_out
                .list_events("r1", 0)?
                .iter()
                .any(|event| event.event_type == RuntimeEventKind::TaskTimedOut)
        );

        let cancelled = fresh()?;
        seed_plan(&cancelled)?;
        cancelled.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Cancelled,
            Some("code_reviewer"),
            Some("stopped by parent run"),
        )?;
        assert!(
            cancelled
                .list_events("r1", 0)?
                .iter()
                .any(|event| event.event_type == RuntimeEventKind::TaskCancelled)
        );
        Ok(())
    }

    #[test]
    fn task_todo_characterization_tracks_dynamic_graph_run_state_todo_and_recovery()
    -> Result<(), StoreError> {
        let temp =
            tempfile::tempdir().map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        let run_id = "task-todo-characterization";
        store.create_run(
            run_id,
            "ws",
            "conversation",
            "message",
            DomainProfile::General,
            "characterize TaskRuntime projections",
            "task",
            AttendedMode::Attended,
        )?;

        let mut upstream = sample_task_body("upstream");
        upstream.max_retries = 2;
        let mut dependent = sample_task_body("dependent");
        dependent.depends_on = vec![upstream.id.clone()];
        let blocked = sample_task_body("blocked");
        let timed_out = sample_task_body("timed-out");
        let skipped = sample_task_body("skipped");
        store.attach_plan_for_test(&TaskPlan {
            domain_binding: None,

            plan_id: "task-todo-characterization-plan".to_string(),
            run_id: run_id.to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("characterize TaskRuntime projections"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Parallel,
            tasks: vec![upstream, dependent, blocked, timed_out, skipped],
        })?;
        store.transition_run(run_id, TaskRunStatus::Running)?;

        let assert_graph_and_projections =
            |store: &TaskRuntimeStore, expected_revision: u64| -> Result<(), StoreError> {
                let plan = store
                    .get_plan(run_id)?
                    .ok_or_else(|| StoreError::PlanNotFound(run_id.to_string()))?;
                let snapshot = store
                    .get_run_state(run_id)?
                    .ok_or_else(|| StoreError::RunNotFound(run_id.to_string()))?;
                let runtime = store.load_runtime_plan_snapshot(run_id)?;
                let todos = store.list_todos(run_id)?;
                assert_eq!(plan.revision, expected_revision);
                assert_eq!(runtime.revision, expected_revision);
                assert_eq!(plan.tasks.len(), snapshot.tasks.len());
                assert_eq!(plan.tasks.len(), runtime.tasks.len());
                assert_eq!(plan.tasks.len(), todos.len());
                for task in &plan.tasks {
                    if !snapshot.tasks.iter().any(|state| state.task_id == task.id) {
                        return Err(StoreError::TaskNotFound(format!(
                            "run-state task {} missing",
                            task.id
                        )));
                    }
                    if !runtime.tasks.iter().any(|state| state.spec.id == task.id) {
                        return Err(StoreError::TaskNotFound(format!(
                            "runtime graph task {} missing",
                            task.id
                        )));
                    }
                    if !todos.iter().any(|todo| todo.task_id == task.id) {
                        return Err(StoreError::TaskNotFound(format!(
                            "Todo projection {} missing",
                            task.id
                        )));
                    }
                }
                Ok(())
            };

        assert_graph_and_projections(&store, 1)?;

        let mut patched = sample_task_body("patched");
        patched.title = "Inserted during characterization".to_string();
        let patched_plan = store.apply_task_patch_for_test(
            run_id,
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "exercise dynamic graph insertion".to_string(),
                operations: vec![TaskUpdateOperation::Insert {
                    after_task_id: Some("upstream".to_string()),
                    task: Box::new(patched.spec()),
                }],
            },
        )?;
        assert_eq!(patched_plan.revision, 2);
        assert_graph_and_projections(&store, 2)?;
        assert_eq!(
            store
                .list_todos(run_id)?
                .iter()
                .find(|todo| todo.task_id == "patched")
                .map(|todo| todo.status),
            Some(TodoStatus::Pending)
        );

        store.set_task_status(
            run_id,
            "upstream",
            echo_agent::tasks::TaskStatus::Failed(String::new()),
            Some("implementer"),
            Some("upstream failed"),
        )?;
        store.set_task_status(
            run_id,
            "blocked",
            echo_agent::tasks::TaskStatus::Blocked(String::new()),
            Some("reviewer"),
            Some("awaiting explicit decision"),
        )?;
        store.set_task_status(
            run_id,
            "timed-out",
            echo_agent::tasks::TaskStatus::TimedOut {
                error: String::new(),
            },
            Some("reviewer"),
            Some("deadline elapsed"),
        )?;
        let skipped_plan = store.apply_task_patch_for_test(
            run_id,
            &TaskUpdateRequest {
                base_revision: 2,
                reason: "exercise explicit skip projection".to_string(),
                operations: vec![TaskUpdateOperation::Skip {
                    task_id: "skipped".to_string(),
                }],
            },
        )?;
        assert_eq!(skipped_plan.revision, 3);
        assert_graph_and_projections(&store, 3)?;

        let runtime = store.load_runtime_plan_snapshot(run_id)?;
        let runtime_status = |task_id: &str| {
            runtime
                .tasks
                .iter()
                .find(|task| task.spec.id == task_id)
                .map(|task| &task.execution.status)
        };
        assert!(matches!(
            runtime_status("upstream"),
            Some(echo_agent::tasks::TaskStatus::Failed(detail)) if detail == "upstream failed"
        ));
        assert_eq!(
            runtime_status("dependent"),
            Some(&echo_agent::tasks::TaskStatus::Pending)
        );
        assert!(matches!(
            runtime_status("blocked"),
            Some(echo_agent::tasks::TaskStatus::Blocked(detail)) if detail == "awaiting explicit decision"
        ));
        assert!(matches!(
            runtime_status("timed-out"),
            Some(echo_agent::tasks::TaskStatus::TimedOut { error }) if error == "deadline elapsed"
        ));
        assert_eq!(
            runtime_status("skipped"),
            Some(&echo_agent::tasks::TaskStatus::Skipped)
        );
        let todos = store.list_todos(run_id)?;
        assert_eq!(
            todos
                .iter()
                .find(|todo| todo.task_id == "dependent")
                .map(|todo| todo.status),
            Some(TodoStatus::Blocked)
        );
        assert_eq!(
            todos
                .iter()
                .find(|todo| todo.task_id == "timed-out")
                .map(|todo| todo.status),
            Some(TodoStatus::TimedOut)
        );
        assert_eq!(
            todos
                .iter()
                .find(|todo| todo.task_id == "skipped")
                .map(|todo| todo.status),
            Some(TodoStatus::Skipped)
        );

        store.transition_run(run_id, TaskRunStatus::Failed)?;
        assert_eq!(store.retry_blocked_task(run_id, "upstream")?, 1);
        assert_graph_and_projections(&store, 3)?;
        let retried = store.load_runtime_plan_snapshot(run_id)?;
        let retried_upstream = retried
            .tasks
            .iter()
            .find(|task| task.spec.id == "upstream")
            .ok_or_else(|| StoreError::TaskNotFound("upstream".to_string()))?;
        assert_eq!(
            &retried_upstream.execution.status,
            &echo_agent::tasks::TaskStatus::Pending
        );
        assert_eq!(retried_upstream.execution.retry_count, 1);
        assert_eq!(
            store
                .get_run(run_id)?
                .ok_or_else(|| StoreError::RunNotFound(run_id.to_string()))?
                .status,
            TaskRunStatus::Running
        );
        assert_eq!(
            store
                .list_todos(run_id)?
                .iter()
                .find(|todo| todo.task_id == "dependent")
                .map(|todo| todo.status),
            Some(TodoStatus::Pending)
        );

        assert!(store.request_cancel(run_id)?);
        let cancelled_runtime = store.load_runtime_plan_snapshot(run_id)?;
        for task in &cancelled_runtime.tasks {
            if task.spec.id == "timed-out" || task.spec.id == "skipped" {
                continue;
            }
            assert_eq!(
                &task.execution.status,
                &echo_agent::tasks::TaskStatus::Cancelled
            );
        }
        assert_eq!(
            store
                .get_run(run_id)?
                .ok_or_else(|| StoreError::RunNotFound(run_id.to_string()))?
                .status,
            TaskRunStatus::Cancelled
        );
        let cancelled_todos = store.list_todos(run_id)?;
        assert_eq!(
            cancelled_todos
                .iter()
                .find(|todo| todo.task_id == "upstream")
                .map(|todo| todo.status),
            Some(TodoStatus::Cancelled)
        );
        assert_eq!(
            cancelled_todos
                .iter()
                .find(|todo| todo.task_id == "blocked")
                .map(|todo| todo.status),
            Some(TodoStatus::Cancelled)
        );
        assert_eq!(
            cancelled_todos
                .iter()
                .find(|todo| todo.task_id == "timed-out")
                .map(|todo| todo.status),
            Some(TodoStatus::TimedOut)
        );
        assert_eq!(
            cancelled_todos
                .iter()
                .find(|todo| todo.task_id == "skipped")
                .map(|todo| todo.status),
            Some(TodoStatus::Skipped)
        );

        let recovery_id = "restart-recovery-characterization";
        store.create_run(
            recovery_id,
            "ws",
            "conversation",
            "recovery-message",
            DomainProfile::General,
            "characterize restart recovery",
            "task",
            AttendedMode::Attended,
        )?;
        store.attach_plan_for_test(&TaskPlan {
            domain_binding: None,

            plan_id: "restart-recovery-characterization-plan".to_string(),
            run_id: recovery_id.to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("characterize restart recovery"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![sample_task_body("recovery-task")],
        })?;
        store.transition_run(recovery_id, TaskRunStatus::Running)?;
        store.set_task_status(
            recovery_id,
            "recovery-task",
            echo_agent::tasks::TaskStatus::Running,
            Some("subagent"),
            Some("interrupted before completion"),
        )?;
        drop(store);

        let restarted = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        assert_eq!(
            restarted
                .get_run(recovery_id)?
                .ok_or_else(|| StoreError::RunNotFound(recovery_id.to_string()))?
                .status,
            TaskRunStatus::Running
        );
        assert_eq!(
            restarted
                .list_todos(recovery_id)?
                .iter()
                .find(|todo| todo.task_id == "recovery-task")
                .map(|todo| todo.status),
            Some(TodoStatus::Running)
        );
        assert_eq!(restarted.recover_incomplete()?, 1);
        let recovered_state = restarted
            .get_run_state(recovery_id)?
            .ok_or_else(|| StoreError::RunNotFound(recovery_id.to_string()))?;
        assert_eq!(recovered_state.run.status, TaskRunStatus::Paused);
        let recovered_task = recovered_state
            .tasks
            .iter()
            .find(|task| task.task_id == "recovery-task")
            .ok_or_else(|| StoreError::TaskNotFound("recovery-task".to_string()))?;
        // Current recovery pauses the Run but resets an interrupted task to
        // Pending so it can be reclaimed explicitly on resume. Todo is the
        // matching read-only projection of that canonical task status.
        assert_eq!(
            recovered_task.status,
            echo_agent::tasks::TaskStatus::Pending
        );
        assert_eq!(
            restarted
                .list_todos(recovery_id)?
                .iter()
                .find(|todo| todo.task_id == "recovery-task")
                .map(|todo| todo.status),
            Some(TodoStatus::Pending)
        );
        Ok(())
    }

    #[test]
    fn list_todos_is_read_only_and_does_not_append_journal() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let events_path = store.active_shadow_root().join("r1").join("events.jsonl");
        let before_events = std::fs::read(&events_path)
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        let before_count = store.list_events("r1", 0)?.len();
        let first = store.list_todos("r1")?;
        let second = store.list_todos("r1")?;
        let first_value = serde_json::to_value(&first)
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        let second_value = serde_json::to_value(&second)
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        assert_eq!(first_value, second_value);
        assert_eq!(store.list_events("r1", 0)?.len(), before_count);
        let after_events = std::fs::read(&events_path)
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        assert_eq!(before_events, after_events);
        Ok(())
    }

    #[test]
    fn put_summary_upserts_and_get_summary_reads() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        let sum = TaskExecutionSummary {
            run_id: "r1".into(),
            task_id: "t1".into(),
            subagent_name: "code_reviewer".into(),
            outcome: SubagentOutcome {
                contract_version: 1,
                status: SubagentStatus::Completed,
                summary: "read chat.rs".into(),
                artifacts: Vec::new(),
                evidence: Vec::new(),
                verification: vec![SubagentVerification {
                    check: "cargo check".into(),
                    status: SubagentVerificationStatus::Passed,
                    details: String::new(),
                    source: SubagentEvidenceSource::Observed,
                }],
                remaining_work: Vec::new(),
                touched_files: SubagentTouchedFiles {
                    read: vec!["chat.rs".into()],
                    written: Vec::new(),
                },
            },
            decisions: vec!["route via TaskRuntime".into()],
            next_implications: vec!["implement router".into()],
            suggested_tasks: vec![],
            created_at: Utc::now(),
        };
        s.put_summary(&sum)?;
        let got = s
            .get_summary("r1", "t1")?
            .ok_or_else(|| StoreError::TaskNotFound("t1 summary".to_string()))?;
        assert_eq!(got.outcome.summary, "read chat.rs");
        assert_eq!(got.next_implications.len(), 1);
        Ok(())
    }

    #[test]
    fn latest_run_for_conversation_orders_by_created_desc() -> Result<(), StoreError> {
        let s = fresh()?;
        s.create_run(
            "r1",
            "ws",
            "c1",
            "m1",
            DomainProfile::General,
            "g1",
            "",
            AttendedMode::Attended,
        )?;
        std::thread::sleep(std::time::Duration::from_millis(10));
        s.create_run(
            "r2",
            "ws",
            "c1",
            "m2",
            DomainProfile::General,
            "g2",
            "",
            AttendedMode::Attended,
        )?;
        let latest = s
            .latest_run_for_conversation("c1")?
            .ok_or_else(|| StoreError::RunNotFound("latest run for c1".to_string()))?;
        assert_eq!(latest.run_id, "r2");
        Ok(())
    }

    #[test]
    fn task_ui_query_skips_planless_conversation_run() -> Result<(), String> {
        let store = fresh().map_err(|error| error.to_string())?;
        seed_plan(&store).map_err(|error| error.to_string())?;
        let conversation_id = store
            .get_run("r1")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "seeded plan run disappeared".to_string())?
            .conversation_id;
        store
            .create_run_with_profile(
                "taskrun:new-chat",
                "test",
                &conversation_id,
                "new-chat",
                DomainProfile::General,
                "hello",
                "agent_task_plan",
                AttendedMode::Attended,
                TaskRunExecutionProfile::conversation_turn(),
            )
            .map_err(|error| error.to_string())?;

        let visible = store
            .latest_task_ui_run_for_conversation(&conversation_id)
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "formal task run should remain visible".to_string())?;
        assert_eq!(visible.run_id, "r1");
        Ok(())
    }

    fn seed_plan(s: &TaskRuntimeStore) -> Result<(), StoreError> {
        s.create_run(
            "r1",
            "ws",
            "c1",
            "m1",
            DomainProfile::General,
            "g",
            "",
            AttendedMode::Attended,
        )?;
        let plan = TaskPlan {
            domain_binding: None,

            plan_id: "p1".into(),
            run_id: "r1".into(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("g"),
            assumptions: vec![],
            risks: vec![],
            execution_mode: ExecutionMode::Parallel,
            tasks: vec![PlanTask {
                id: "t1".into(),
                title: "Review runtime".into(),
                kind: PlanTaskKind::ReadOnlyReview,
                agent_role: "code_reviewer".into(),
                ..Default::default()
            }],
        };
        s.attach_plan_for_test(&plan)?;
        s.transition_run("r1", TaskRunStatus::Running)?;
        Ok(())
    }

    #[test]
    fn budget_update_requires_existing_continuation_and_preserves_policy() -> Result<(), StoreError>
    {
        let store = fresh()?;
        seed_plan(&store)?;
        assert!(
            store
                .update_run_continuation_budgets("r1", Some(100), Some(60))
                .is_err()
        );
        store.configure_run_continuation("r1", true, true, None, None)?;
        let updated = store.update_run_continuation_budgets("r1", Some(100), Some(60))?;
        assert_eq!(updated.token_budget, Some(100));
        assert_eq!(updated.time_budget_seconds, Some(60));
        assert!(updated.auto_resume_after_restart);
        assert!(
            store
                .update_run_continuation_budgets("r1", Some(0), None)
                .is_err()
        );
        Ok(())
    }

    #[test]
    fn lowering_budget_atomically_pauses_and_cancels_active_driver() -> Result<(), StoreError> {
        let store = std::sync::Arc::new(fresh()?);
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, true, None, None)?;
        assert!(matches!(
            store.claim_run_turn("r1", "turn-1", RunTurnOrigin::User, TurnVisibility::Visible)?,
            RunTurnClaimOutcome::Started(_)
        ));
        assert!(!store.account_run_turn_usage("r1", "turn-1", "usage-1", 40, 20)?);
        let token = echo_agent::agent::CancellationToken::new();
        let registration = store.register_run_cancellation("r1", token.clone())?;

        let updated = store.update_run_continuation_budgets("r1", Some(60), None)?;

        assert!(token.is_cancelled());
        assert_eq!(updated.token_budget, Some(60));
        assert_eq!(
            updated.pause.as_ref().map(|pause| pause.reason),
            Some(RunPauseReason::TokenBudget)
        );
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Paused
        );
        let budget_event = store
            .list_events("r1", 0)?
            .into_iter()
            .rev()
            .find(|event| event.event_type == RuntimeEventKind::RunContinuationConfigured)
            .ok_or_else(|| StoreError::InvalidPlan("budget event missing".to_string()))?;
        assert_eq!(
            budget_event
                .payload
                .get("pause_reason")
                .and_then(serde_json::Value::as_str),
            Some("token_budget")
        );
        drop(registration);
        Ok(())
    }

    #[test]
    fn subagent_usage_is_idempotent_and_parent_turn_owns_wall_clock() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, Some(100), Some(20))?;
        assert!(matches!(
            store.claim_run_turn("r1", "turn-1", RunTurnOrigin::User, TurnVisibility::Visible)?,
            RunTurnClaimOutcome::Started(_)
        ));
        store.record_subagent_assigned(
            "r1",
            "t1",
            "execution-1",
            "code_reviewer",
            "Review runtime",
            1,
            1,
            true,
            false,
        )?;

        assert!(!store.account_subagent_usage(
            "r1",
            "execution-1",
            "provider-total",
            12,
            8,
            2_500,
        )?);
        assert!(!store.account_subagent_usage(
            "r1",
            "execution-1",
            "provider-total",
            12,
            8,
            2_500,
        )?);
        let during_turn = store
            .get_run_state("r1")?
            .and_then(|state| state.continuation)
            .ok_or_else(|| StoreError::InvalidPlan("continuation missing".to_string()))?;
        assert_eq!(during_turn.tokens_used, 20);
        assert_eq!(during_turn.time_used_seconds, 0);
        let subagent_runs = store.list_subagent_runs("r1")?;
        let subagent_run = subagent_runs
            .first()
            .ok_or_else(|| StoreError::InvalidPlan("SubagentRun projection missing".to_string()))?;
        assert_eq!(subagent_run.subagent_run_id, "execution-1");
        assert_eq!(subagent_run.usage.tokens_used, Some(20));
        assert_eq!(subagent_run.usage.duration_ms, Some(2_500));
        let result =
            SubagentOutcome::terminal(SubagentStatus::Completed, "review complete", Vec::new());
        let terminal_usage = ExecutionUsage {
            duration_ms: Some(2_500),
            tokens_used: Some(20),
            iterations: Some(2),
        };
        store.record_subagent_released(SubagentReleaseRecord {
            run_id: "r1",
            task_id: "t1",
            execution_id: "execution-1",
            agent_name: "code_reviewer",
            task_subject: "Review runtime",
            plan_revision: 1,
            attempt: 1,
            status: "completed",
            outcome: Some(&result),
            full_output: Some("review complete"),
            usage: Some(&terminal_usage),
            dispatch_hook: false,
        })?;
        let settled_runs = store.list_subagent_runs("r1")?;
        let settled = settled_runs.first().ok_or_else(|| {
            StoreError::InvalidPlan("settled SubagentRun projection missing".to_string())
        })?;
        assert_eq!(settled.status, SubagentStatus::Completed);
        assert_eq!(settled.outcome.as_ref(), Some(&result));
        assert_eq!(settled.usage, terminal_usage);
        assert_eq!(
            store
                .list_events("r1", 0)?
                .iter()
                .filter(|event| {
                    event.event_type == RuntimeEventKind::RunTurnUsageAccounted
                        && event
                            .payload
                            .get("source_scope")
                            .and_then(serde_json::Value::as_str)
                            == Some("subagent")
                })
                .count(),
            1
        );

        let finished = store.finish_run_turn(
            "r1",
            RunTurnCompletion {
                turn_id: "turn-1",
                status: RunTurnStatus::Ended,
                elapsed_seconds: 3,
                final_message_id: None,
                error_fingerprint: None,
            },
        )?;
        assert_eq!(finished.tokens_used, 20);
        assert_eq!(finished.time_used_seconds, 3);
        Ok(())
    }

    #[test]
    fn cell_terminal_and_defer_race_cannot_leave_lost_wakeup() -> Result<(), String> {
        let store = std::sync::Arc::new(fresh().map_err(|error| error.to_string())?);
        seed_plan(&store).map_err(|error| error.to_string())?;
        store
            .configure_run_continuation("r1", true, false, None, None)
            .map_err(|error| error.to_string())?;
        store
            .record_background_cell_started(
                "r1",
                "cell-1",
                "cargo test",
                "hash",
                Some("turn-1"),
                None,
                Some("call-1"),
            )
            .map_err(|error| error.to_string())?;
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(2));

        let defer_store = store.clone();
        let defer_barrier = barrier.clone();
        let defer = std::thread::spawn(move || {
            defer_barrier.wait();
            defer_store.defer_continuation_for_active_cells("r1")
        });
        let terminal_store = store.clone();
        let terminal = std::thread::spawn(move || {
            barrier.wait();
            terminal_store.record_background_cell_finished(
                "r1",
                "cell-1",
                "cargo test",
                BackgroundCellPhase::Succeeded,
                Some(BackgroundCellTerminalCause::Exited),
                None,
                Some(0),
                BackgroundCellArtifactStatus::NotRequested,
                None,
                2,
                false,
                Some("ok"),
                None,
                None,
                Some("call-1"),
            )?;
            super::super::continuation::wake_deferred_when_runtime_quiet(&terminal_store, "r1");
            Ok::<(), StoreError>(())
        });

        defer
            .join()
            .map_err(|_| "defer thread panicked".to_string())?
            .map_err(|error| error.to_string())?;
        terminal
            .join()
            .map_err(|_| "terminal thread panicked".to_string())?
            .map_err(|error| error.to_string())?;
        let continuation = store
            .get_run_state("r1")
            .map_err(|error| error.to_string())?
            .and_then(|state| state.continuation)
            .ok_or_else(|| "continuation missing".to_string())?;
        assert!(!continuation.deferred);
        Ok(())
    }

    #[test]
    fn quiet_wake_holds_deferral_while_plan_tasks_are_running() -> Result<(), String> {
        let store = std::sync::Arc::new(fresh().map_err(|error| error.to_string())?);
        seed_plan(&store).map_err(|error| error.to_string())?;
        store
            .configure_run_continuation("r1", true, false, None, None)
            .map_err(|error| error.to_string())?;
        store
            .set_task_status(
                "r1",
                "t1",
                echo_agent::tasks::TaskStatus::Running,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        assert!(
            store
                .defer_continuation_if_runtime_active("r1")
                .map_err(|error| error.to_string())?,
            "new runtime activity must restore continuation deferral"
        );

        // In-flight subagent work keeps the deferral even when no background
        // cell is active — the wake must not resume a turn mid-execution.
        super::super::continuation::wake_deferred_when_runtime_quiet(&store, "r1");
        let held = store
            .get_run_state("r1")
            .map_err(|error| error.to_string())?
            .and_then(|state| state.continuation)
            .ok_or_else(|| "continuation missing".to_string())?;
        assert!(held.deferred, "running plan task must hold the deferral");

        // Once the task settles the same wake clears the deferral.
        store
            .set_task_status(
                "r1",
                "t1",
                echo_agent::tasks::TaskStatus::Completed,
                None,
                Some("done"),
            )
            .map_err(|error| error.to_string())?;
        super::super::continuation::wake_deferred_when_runtime_quiet(&store, "r1");
        let cleared = store
            .get_run_state("r1")
            .map_err(|error| error.to_string())?
            .and_then(|state| state.continuation)
            .ok_or_else(|| "continuation missing".to_string())?;
        assert!(
            !cleared.deferred,
            "settled task with no cells must wake the run"
        );
        Ok(())
    }

    #[test]
    fn continuation_claim_rechecks_runtime_activity_after_quiet_wake() -> Result<(), String> {
        let store = std::sync::Arc::new(fresh().map_err(|error| error.to_string())?);
        seed_plan(&store).map_err(|error| error.to_string())?;
        store
            .configure_run_continuation("r1", true, false, None, None)
            .map_err(|error| error.to_string())?;
        store
            .set_continuation_deferred("r1", true)
            .map_err(|error| error.to_string())?;
        assert!(
            store
                .resume_deferred_continuation_if_quiet("r1")
                .map_err(|error| error.to_string())?,
            "quiet wake should clear the initial deferral"
        );

        // Model the forward race: task activity appears after eligibility
        // observed quiet but before the next continuation claims its RunTurn.
        store
            .set_task_status(
                "r1",
                "t1",
                echo_agent::tasks::TaskStatus::Running,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        let claim = store
            .claim_run_turn(
                "r1",
                "raced-continuation",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            )
            .map_err(|error| error.to_string())?;
        assert_eq!(
            claim,
            RunTurnClaimOutcome::NotSubmitted(ContinuationNotSubmittedReason::Deferred)
        );
        let snapshot = store
            .get_run_state("r1")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "quiet-wake race snapshot disappeared".to_string())?;
        assert!(snapshot.continuation.is_some_and(
            |continuation| continuation.deferred && continuation.active_turn.is_none()
        ));
        Ok(())
    }

    #[test]
    fn cell_terminal_retry_uses_the_exact_checkpointed_terminal_fact() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.record_background_cell_started(
            "r1",
            "cell-retry",
            "prepared name",
            "hash",
            None,
            None,
            Some("start-call"),
        )?;

        for _ in 0..2 {
            store.record_background_cell_finished(
                "r1",
                "cell-retry",
                "terminal name",
                BackgroundCellPhase::Succeeded,
                Some(BackgroundCellTerminalCause::Exited),
                None,
                Some(0),
                BackgroundCellArtifactStatus::NotRequested,
                None,
                2,
                false,
                Some("ok"),
                None,
                None,
                None,
            )?;
        }

        let cells = store.list_background_cells("r1")?;
        let cell = cells
            .iter()
            .find(|cell| cell.cell_id == "cell-retry")
            .ok_or_else(|| StoreError::InvalidPlan("terminal cell missing".to_string()))?;
        assert_eq!(cell.name, "terminal name");
        assert_eq!(cell.call_id, None);
        assert_eq!(cell.phase, BackgroundCellPhase::Succeeded);
        assert_eq!(
            store
                .list_events("r1", 0)?
                .iter()
                .filter(|event| {
                    event.event_type == RuntimeEventKind::BackgroundCellFinished
                        && event
                            .payload
                            .get("cell_id")
                            .and_then(serde_json::Value::as_str)
                            == Some("cell-retry")
                })
                .count(),
            1
        );
        Ok(())
    }

    #[test]
    fn concurrent_run_turn_claim_has_one_authoritative_winner() -> Result<(), String> {
        let store = std::sync::Arc::new(fresh().map_err(|error| error.to_string())?);
        seed_plan(&store).map_err(|error| error.to_string())?;
        store
            .configure_run_continuation("r1", true, false, None, None)
            .map_err(|error| error.to_string())?;
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(16));
        let mut threads = Vec::new();
        for index in 0..16 {
            let store = store.clone();
            let barrier = barrier.clone();
            threads.push(std::thread::spawn(move || {
                barrier.wait();
                store.claim_run_turn(
                    "r1",
                    &format!("turn-{index}"),
                    RunTurnOrigin::Continuation,
                    TurnVisibility::Internal,
                )
            }));
        }
        let mut started = Vec::new();
        let mut already_running = 0_usize;
        for thread in threads {
            let outcome = thread
                .join()
                .map_err(|_| "RunTurn claim thread panicked".to_string())?
                .map_err(|error| error.to_string())?;
            match outcome {
                RunTurnClaimOutcome::Started(summary) => started.push(summary),
                RunTurnClaimOutcome::NotSubmitted(
                    ContinuationNotSubmittedReason::AlreadyRunning,
                ) => already_running = already_running.saturating_add(1),
                other => return Err(format!("unexpected claim outcome: {other:?}")),
            }
        }
        assert_eq!(started.len(), 1);
        assert_eq!(already_running, 15);
        assert_eq!(started.first().map(|turn| turn.ordinal), Some(1));
        assert_eq!(
            store
                .get_run_state("r1")
                .map_err(|error| error.to_string())?
                .and_then(|state| state.continuation)
                .and_then(|state| state.active_turn)
                .map(|turn| turn.ordinal),
            Some(1)
        );
        Ok(())
    }

    #[test]
    fn run_turn_accounting_is_idempotent_and_rejects_cross_turn_events() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, Some(100), None)?;
        assert!(matches!(
            store.claim_run_turn("r1", "turn-1", RunTurnOrigin::User, TurnVisibility::Visible,)?,
            RunTurnClaimOutcome::Started(_)
        ));
        assert!(
            store
                .account_run_turn_usage("r1", "wrong-turn", "usage-1", 10, 20)
                .is_err()
        );
        assert!(
            store
                .record_run_turn_compaction("r1", "wrong-turn", "compact-1")
                .is_err()
        );
        assert!(
            store
                .finish_run_turn(
                    "r1",
                    RunTurnCompletion {
                        turn_id: "wrong-turn",
                        status: RunTurnStatus::Ended,
                        elapsed_seconds: 7,
                        final_message_id: None,
                        error_fingerprint: None,
                    },
                )
                .is_err()
        );
        assert!(!store.account_run_turn_usage("r1", "turn-1", "usage-1", 10, 20)?);
        assert!(!store.account_run_turn_usage("r1", "turn-1", "usage-1", 10, 20)?);
        store.record_run_turn_compaction("r1", "turn-1", "compact-1")?;
        store.record_run_turn_compaction("r1", "turn-1", "compact-1")?;
        let first = store.finish_run_turn(
            "r1",
            RunTurnCompletion {
                turn_id: "turn-1",
                status: RunTurnStatus::Ended,
                elapsed_seconds: 7,
                final_message_id: Some("message-1"),
                error_fingerprint: None,
            },
        )?;
        let replay = store.finish_run_turn(
            "r1",
            RunTurnCompletion {
                turn_id: "turn-1",
                status: RunTurnStatus::Failed,
                elapsed_seconds: 99,
                final_message_id: None,
                error_fingerprint: Some("must-not-overwrite"),
            },
        )?;
        assert_eq!(first, replay);
        assert_eq!(replay.tokens_used, 30);
        assert_eq!(replay.time_used_seconds, 7);
        assert_eq!(replay.compaction_count, 1);
        let last = replay
            .last_turn
            .ok_or_else(|| StoreError::InvalidPlan("finished RunTurn missing".to_string()))?;
        assert_eq!(last.input_tokens, 10);
        assert_eq!(last.output_tokens, 20);
        assert_eq!(last.compaction_count, 1);
        assert_eq!(last.status, RunTurnStatus::Ended);
        assert_eq!(last.final_message_id.as_deref(), Some("message-1"));
        assert!(matches!(
            store.claim_run_turn(
                "r1",
                "turn-1",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            ),
            Err(StoreError::InvalidPlan(_))
        ));
        Ok(())
    }

    #[test]
    fn time_budget_stops_at_exact_boundary_and_cannot_be_bypassed_by_resume()
    -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, Some(7))?;
        assert!(matches!(
            store.claim_run_turn("r1", "turn-1", RunTurnOrigin::User, TurnVisibility::Visible)?,
            RunTurnClaimOutcome::Started(_)
        ));
        let state = store.finish_run_turn(
            "r1",
            RunTurnCompletion {
                turn_id: "turn-1",
                status: RunTurnStatus::Ended,
                elapsed_seconds: 7,
                final_message_id: None,
                error_fingerprint: None,
            },
        )?;
        assert_eq!(state.time_budget_seconds, Some(7));
        assert_eq!(state.time_used_seconds, 7);
        assert!(matches!(
            store.claim_run_turn(
                "r1",
                "turn-2",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            )?,
            RunTurnClaimOutcome::NotSubmitted(ContinuationNotSubmittedReason::TimeBudgetExhausted)
        ));

        assert!(store.request_pause_with_reason(
            "r1",
            RunPauseReason::TimeBudget,
            Some("configured time budget exhausted"),
        )?);
        let error = store
            .resume_task_run("r1")
            .err()
            .ok_or_else(|| StoreError::InvalidPlan("resume unexpectedly succeeded".to_string()))?;
        assert!(error.to_string().contains("time budget"));
        Ok(())
    }

    #[test]
    fn one_hundred_turns_and_compactions_replay_without_double_accounting() -> Result<(), StoreError>
    {
        let store = fresh()?;
        seed_plan(&store)?;
        let initial_goal_sha256 = store
            .get_run("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
            .goal_sha256;
        store.configure_run_continuation("r1", true, false, None, None)?;
        for ordinal in 1..=100_u64 {
            let turn_id = format!("soak-turn-{ordinal}");
            assert!(matches!(
                store.claim_run_turn(
                    "r1",
                    &turn_id,
                    RunTurnOrigin::Continuation,
                    TurnVisibility::Internal,
                )?,
                RunTurnClaimOutcome::Started(_)
            ));
            let provider_event_id = format!("usage-{ordinal}");
            assert!(!store.account_run_turn_usage("r1", &turn_id, &provider_event_id, 1, 2,)?);
            assert!(!store.account_run_turn_usage("r1", &turn_id, &provider_event_id, 1, 2,)?);
            let compaction_event_id = format!("compact-{ordinal}");
            store.record_run_turn_compaction("r1", &turn_id, &compaction_event_id)?;
            store.record_run_turn_compaction("r1", &turn_id, &compaction_event_id)?;
            store.finish_run_turn(
                "r1",
                RunTurnCompletion {
                    turn_id: &turn_id,
                    status: RunTurnStatus::Ended,
                    elapsed_seconds: 1,
                    final_message_id: None,
                    error_fingerprint: None,
                },
            )?;
        }

        let events = store.list_events("r1", 0)?;
        let journal_sequence = events
            .last()
            .and_then(|event| u64::try_from(event.seq).ok())
            .ok_or_else(|| StoreError::InvalidPlan("replay sequence is unavailable".to_string()))?;
        let replayed = super::super::event_rebuild::fold_fixture_for_test(&events)
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?
            .run_state_with_sequence(journal_sequence)
            .continuation
            .ok_or_else(|| StoreError::InvalidPlan("soak continuation missing".to_string()))?;
        assert_eq!(replayed.tokens_used, 300);
        assert_eq!(replayed.time_used_seconds, 100);
        assert_eq!(replayed.compaction_count, 100);
        assert_eq!(replayed.next_turn_ordinal, 101);
        assert!(replayed.active_turn.is_none());
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .goal_sha256,
            initial_goal_sha256
        );
        Ok(())
    }

    #[test]
    fn provider_retry_schedule_rebuilds_and_counts_across_fingerprints() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        let base = Utc::now() - chrono::Duration::hours(1);

        for (turn_id, fingerprint, expected_attempt, offset) in [
            ("retry-turn-1", "provider-a", 1_u32, 0_i64),
            ("retry-turn-2", "provider-a", 2_u32, 1_i64),
            ("retry-turn-3", "provider-b", 3_u32, 2_i64),
        ] {
            assert!(matches!(
                store.claim_run_turn(
                    "r1",
                    turn_id,
                    RunTurnOrigin::Continuation,
                    TurnVisibility::Internal,
                )?,
                RunTurnClaimOutcome::Started(_)
            ));
            store.finish_run_turn(
                "r1",
                RunTurnCompletion {
                    turn_id,
                    status: RunTurnStatus::Failed,
                    elapsed_seconds: 1,
                    final_message_id: None,
                    error_fingerprint: Some(fingerprint),
                },
            )?;
            let scheduled = store.schedule_provider_retry_at(
                "r1",
                fingerprint,
                base + chrono::Duration::seconds(offset),
            )?;
            assert_eq!(scheduled.state().attempt_count, expected_attempt);
            assert_eq!(scheduled.state().error_fingerprint, fingerprint);
        }

        let events = store.list_events("r1", 0)?;
        let journal_sequence = events
            .last()
            .and_then(|event| u64::try_from(event.seq).ok())
            .ok_or_else(|| StoreError::InvalidPlan("replay sequence is unavailable".to_string()))?;
        let replayed = super::super::event_rebuild::fold_fixture_for_test(&events)
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?
            .run_state_with_sequence(journal_sequence)
            .continuation
            .and_then(|state| state.provider_retry)
            .ok_or_else(|| StoreError::InvalidPlan("provider retry did not rebuild".to_string()))?;
        assert_eq!(replayed.attempt_count, 3);
        assert_eq!(replayed.error_fingerprint, "provider-b");
        assert_eq!(replayed.first_failure_at, base);
        assert_eq!(
            stable_provider_retry_delay_millis("r1", "provider-b", 1),
            stable_provider_retry_delay_millis("r1", "provider-b", 1)
        );
        Ok(())
    }

    #[test]
    fn provider_retry_claim_waits_then_success_clears_schedule() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        assert!(matches!(
            store.claim_run_turn(
                "r1",
                "failed-turn",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            )?,
            RunTurnClaimOutcome::Started(_)
        ));
        store.finish_run_turn(
            "r1",
            RunTurnCompletion {
                turn_id: "failed-turn",
                status: RunTurnStatus::Failed,
                elapsed_seconds: 1,
                final_message_id: None,
                error_fingerprint: Some("provider-a"),
            },
        )?;
        store.schedule_provider_retry_at("r1", "provider-a", Utc::now())?;
        assert!(matches!(
            store.claim_run_turn(
                "r1",
                "too-early",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            )?,
            RunTurnClaimOutcome::NotSubmitted(ContinuationNotSubmittedReason::ProviderRetryBackoff)
        ));

        let past = Utc::now() - chrono::Duration::hours(1);
        store.schedule_provider_retry_at("r1", "provider-b", past)?;
        assert!(matches!(
            store.claim_run_turn(
                "r1",
                "successful-retry",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            )?,
            RunTurnClaimOutcome::Started(_)
        ));
        let state = store.finish_run_turn(
            "r1",
            RunTurnCompletion {
                turn_id: "successful-retry",
                status: RunTurnStatus::Ended,
                elapsed_seconds: 1,
                final_message_id: None,
                error_fingerprint: None,
            },
        )?;
        assert!(state.provider_retry.is_none());
        Ok(())
    }

    #[test]
    fn fifth_provider_failure_atomically_pauses_and_explicit_resume_resets_retry()
    -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, true, None, None)?;
        let base = Utc::now() - chrono::Duration::hours(1);
        for attempt in 1..=MAX_PROVIDER_RETRY_ATTEMPTS {
            let turn_id = format!("retry-exhaustion-{attempt}");
            assert!(matches!(
                store.claim_run_turn(
                    "r1",
                    &turn_id,
                    RunTurnOrigin::Continuation,
                    TurnVisibility::Internal,
                )?,
                RunTurnClaimOutcome::Started(_)
            ));
            store.finish_run_turn(
                "r1",
                RunTurnCompletion {
                    turn_id: &turn_id,
                    status: RunTurnStatus::Failed,
                    elapsed_seconds: 1,
                    final_message_id: None,
                    error_fingerprint: Some("provider-a"),
                },
            )?;
            let disposition = store.schedule_provider_retry_at(
                "r1",
                "provider-a",
                base + chrono::Duration::seconds(i64::from(attempt)),
            )?;
            assert_eq!(disposition.state().attempt_count, attempt);
        }
        let snapshot = store
            .get_run_state("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        assert_eq!(snapshot.run.status, TaskRunStatus::Paused);
        let continuation = snapshot
            .continuation
            .ok_or_else(|| StoreError::InvalidPlan("continuation missing".to_string()))?;
        assert!(
            continuation
                .provider_retry
                .as_ref()
                .is_some_and(|retry| retry.exhausted)
        );
        assert_eq!(
            continuation.pause.map(|pause| pause.reason),
            Some(RunPauseReason::ProviderUnavailable)
        );

        store.resume_task_run("r1")?;
        let resumed = store
            .get_run_state("r1")?
            .and_then(|snapshot| snapshot.continuation)
            .ok_or_else(|| StoreError::InvalidPlan("resumed continuation missing".to_string()))?;
        assert!(resumed.provider_retry.is_none());
        Ok(())
    }

    fn prepare_boot_auto_resume_run(
        store: &TaskRuntimeStore,
        run_id: &str,
        attended_mode: AttendedMode,
    ) -> Result<(), StoreError> {
        let workspace_id = store.active_workspace_id();
        store.create_run(
            run_id,
            &workspace_id,
            &format!("background:test:{run_id}"),
            "root",
            DomainProfile::General,
            "boot goal",
            "bg:kind:test",
            attended_mode,
        )?;
        store.attach_plan_for_test(&TaskPlan {
            domain_binding: None,

            plan_id: format!("{run_id}-plan"),
            run_id: run_id.to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("boot goal"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: format!("{run_id}-task"),
                title: "Resume safely".to_string(),
                ..PlanTask::default()
            }],
        })?;
        store.transition_run(run_id, TaskRunStatus::Running)?;
        store.configure_run_continuation(run_id, true, true, None, None)?;
        store.record_run_pause_reason(
            run_id,
            RunPauseReason::BootRecovery,
            Some("test process interruption"),
        )?;
        store.transition_run(run_id, TaskRunStatus::Paused)?;
        Ok(())
    }

    #[test]
    fn boot_auto_resume_admission_rejects_missing_owner_workspace_and_unsafe_boundary()
    -> Result<(), StoreError> {
        let store = fresh()?;
        prepare_boot_auto_resume_run(&store, "attended", AttendedMode::Attended)?;
        let attended = store.boot_auto_resume_decision("attended", true, false)?;
        assert!(matches!(
            attended,
            BootAutoResumeDecision::Blocked(blockers)
                if blockers.contains(&BootAutoResumeBlocker::InteractiveOwnerUnavailable)
        ));

        prepare_boot_auto_resume_run(&store, "disabled", AttendedMode::Unattended)?;
        store.configure_run_continuation("disabled", true, false, None, None)?;
        assert!(matches!(
            store.boot_auto_resume_decision("disabled", true, false)?,
            BootAutoResumeDecision::Blocked(blockers)
                if blockers.contains(&BootAutoResumeBlocker::AutoResumeDisabled)
        ));

        prepare_boot_auto_resume_run(&store, "launcher", AttendedMode::Unattended)?;
        assert!(matches!(
            store.boot_auto_resume_decision("launcher", false, false)?,
            BootAutoResumeDecision::Blocked(blockers)
                if blockers.contains(&BootAutoResumeBlocker::LauncherUnavailable)
        ));

        prepare_boot_auto_resume_run(&store, "unsafe", AttendedMode::Unattended)?;
        store.record_recovery_blocker(
            "unsafe",
            "unsafe-task",
            Some("execution"),
            Some("call"),
            Some("shell"),
            "indeterminate side effect",
        )?;
        let unsafe_decision = store.boot_auto_resume_decision("unsafe", true, false)?;
        assert!(matches!(
            unsafe_decision,
            BootAutoResumeDecision::Blocked(blockers)
                if blockers.contains(&BootAutoResumeBlocker::RecoveryBlocker)
        ));

        let mismatched = fresh()?;
        mismatched.create_run(
            "mismatch",
            "different-workspace",
            "background:test:mismatch",
            "root",
            DomainProfile::General,
            "boot goal",
            "bg:kind:test",
            AttendedMode::Unattended,
        )?;
        mismatched.attach_plan_for_test(&TaskPlan {
            domain_binding: None,

            plan_id: "mismatch-plan".to_string(),
            run_id: "mismatch".to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("boot goal"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: "mismatch-task".to_string(),
                title: "Stay paused".to_string(),
                ..PlanTask::default()
            }],
        })?;
        mismatched.transition_run("mismatch", TaskRunStatus::Running)?;
        mismatched.configure_run_continuation("mismatch", true, true, None, None)?;
        mismatched.record_run_pause_reason(
            "mismatch",
            RunPauseReason::BootRecovery,
            Some("test process interruption"),
        )?;
        mismatched.transition_run("mismatch", TaskRunStatus::Paused)?;
        assert!(matches!(
            mismatched.boot_auto_resume_decision("mismatch", true, false)?,
            BootAutoResumeDecision::Blocked(blockers)
                if blockers.contains(&BootAutoResumeBlocker::WorkspaceMismatch)
        ));
        Ok(())
    }

    #[test]
    fn competing_boot_launchers_have_one_atomic_resume_winner() -> Result<(), String> {
        let store = std::sync::Arc::new(
            TaskRuntimeStore::new_in_memory().map_err(|error| error.to_string())?,
        );
        prepare_boot_auto_resume_run(&store, "race", AttendedMode::Unattended)
            .map_err(|error| error.to_string())?;
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(3));
        let mut threads = Vec::new();
        for _ in 0..2 {
            let thread_store = std::sync::Arc::clone(&store);
            let thread_barrier = std::sync::Arc::clone(&barrier);
            threads.push(std::thread::spawn(move || {
                thread_barrier.wait();
                thread_store.resume_task_run_after_boot("race", true, false)
            }));
        }
        barrier.wait();
        let mut resumed = 0_usize;
        for thread in threads {
            let outcome = thread
                .join()
                .map_err(|_| "boot resume thread panicked".to_string())?
                .map_err(|error| error.to_string())?;
            if matches!(outcome, BootAutoResumeOutcome::Resumed(_)) {
                resumed = resumed.saturating_add(1);
            }
        }
        assert_eq!(resumed, 1);
        Ok(())
    }

    #[test]
    fn resume_task_run_transitions_paused_to_running() -> Result<(), String> {
        let s = fresh().map_err(|error| error.to_string())?;
        seed_plan(&s).map_err(|error| error.to_string())?;
        // Simulate user interrupt: Running -> Paused.
        s.transition_run("r1", TaskRunStatus::Paused)
            .map_err(|error| error.to_string())?;
        let run = s
            .get_run("r1")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "resumable TaskRun missing".to_string())?;
        assert_eq!(run.status, TaskRunStatus::Paused);

        // Resume: Paused -> Running.
        let run = s.resume_task_run("r1").map_err(|error| error.to_string())?;
        assert_eq!(run.status, TaskRunStatus::Running);

        // Event log contains the Paused and Running transitions.
        let evs = s.list_events("r1", 0).map_err(|error| error.to_string())?;
        let status_changes: Vec<_> = evs
            .iter()
            .filter(|e| e.event_type == RuntimeEventKind::RunStatusChanged)
            .collect();
        assert!(status_changes.len() >= 2);
        assert_eq!(
            last_frame_event_types(&s, "r1")?,
            [
                "run_status_changed",
                "run_pause_reason_changed",
                "run_continuation_resumed",
            ]
        );
        Ok(())
    }

    #[test]
    fn expected_resume_and_run_turn_claim_commit_in_one_frame() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        store.request_pause("r1")?;
        let expected = TaskRunResumeIdentity::capture(
            &store
                .get_run_state("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?,
        );
        let before_events = store.list_events("r1", 0)?.len();
        assert!(
            store
                .resume_and_claim_run_turn_expected(
                    &expected,
                    "invalid-origin-turn",
                    RunTurnOrigin::Continuation,
                    TurnVisibility::Internal,
                )
                .is_err()
        );
        assert_eq!(store.list_events("r1", 0)?.len(), before_events);

        assert!(matches!(
            store.resume_and_claim_run_turn_expected(
                &expected,
                "resume-turn",
                RunTurnOrigin::Resume,
                TurnVisibility::Visible,
            )?,
            RunTurnClaimOutcome::Started(ref turn) if turn.turn_id == "resume-turn"
        ));
        assert_eq!(
            last_frame_event_types(&store, "r1").map_err(StoreError::InvalidPlan)?,
            [
                "run_status_changed",
                "run_pause_reason_changed",
                "run_continuation_resumed",
                "run_turn_started",
            ]
        );
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Running
        );
        Ok(())
    }

    #[test]
    fn expected_resume_allows_only_execution_path_diagnostic_suffix() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        store.request_pause("r1")?;
        let expected = TaskRunResumeIdentity::capture(
            &store
                .get_run_state("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?,
        );
        store.record_execution_path("r1", "formal_plan")?;

        assert!(matches!(
            store.resume_and_claim_run_turn_expected(
                &expected,
                "diagnostic-race-resume",
                RunTurnOrigin::Resume,
                TurnVisibility::Visible,
            )?,
            RunTurnClaimOutcome::Started(ref turn)
                if turn.turn_id == "diagnostic-race-resume"
        ));
        Ok(())
    }

    #[test]
    fn expected_resume_sequence_rejects_status_attachment_and_continuation_aba()
    -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        store.request_pause("r1")?;
        let first = store
            .get_run_state("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        let status_epoch = TaskRunResumeIdentity::capture(&first);
        store.resume_task_run_expected(&status_epoch)?;
        store.request_pause("r1")?;
        let before_status_retry = store.list_events("r1", 0)?.len();
        assert!(store.resume_task_run_expected(&status_epoch).is_err());
        assert_eq!(store.list_events("r1", 0)?.len(), before_status_retry);

        let attachment_epoch = TaskRunResumeIdentity::capture(
            &store
                .get_run_state("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?,
        );
        store.set_run_attachments(
            "r1",
            &[crate::attachments::AttachmentRef {
                path: std::path::PathBuf::from("/tmp/resume-epoch.txt"),
                name: "resume-epoch.txt".to_string(),
                mime_type: "text/plain".to_string(),
                source: crate::types::AttachmentSource::default(),
            }],
        )?;
        let before_attachment_retry = store.list_events("r1", 0)?.len();
        assert!(store.resume_task_run_expected(&attachment_epoch).is_err());
        assert_eq!(store.list_events("r1", 0)?.len(), before_attachment_retry);

        let continuation_epoch = TaskRunResumeIdentity::capture(
            &store
                .get_run_state("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?,
        );
        store.configure_run_continuation("r1", true, false, Some(100), None)?;
        let before_continuation_retry = store.list_events("r1", 0)?.len();
        assert!(store.resume_task_run_expected(&continuation_epoch).is_err());
        assert_eq!(store.list_events("r1", 0)?.len(), before_continuation_retry);
        Ok(())
    }

    #[test]
    fn stale_expected_resume_cannot_mutate_recreated_run() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        store.request_pause("r1")?;
        let stale = TaskRunResumeIdentity::capture(
            &store
                .get_run_state("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?,
        );

        store.shadow.remove_runs(&["r1".to_string()])?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        store.request_pause("r1")?;
        let before_events = store.list_events("r1", 0)?.len();
        let before = store
            .get_run_state("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;

        let error = store
            .resume_and_claim_run_turn_expected(
                &stale,
                "stale-resume-turn",
                RunTurnOrigin::Resume,
                TurnVisibility::Visible,
            )
            .err()
            .ok_or_else(|| StoreError::InvalidPlan("stale resume unexpectedly won".to_string()))?;
        assert!(error.to_string().contains("identity changed"));
        assert_eq!(store.list_events("r1", 0)?.len(), before_events);
        let after = store
            .get_run_state("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        assert_eq!(after.run.status, TaskRunStatus::Paused);
        assert!(before.run.attachments.is_empty());
        assert!(after.run.attachments.is_empty());
        assert_eq!(after.continuation, before.continuation);
        assert!(
            after
                .continuation
                .as_ref()
                .is_none_or(|continuation| continuation.active_turn.is_none())
        );
        Ok(())
    }

    #[test]
    fn inactive_cancel_terminalizes_todos_and_run_in_one_frame() -> Result<(), String> {
        let store = fresh().map_err(|error| error.to_string())?;
        seed_plan(&store).map_err(|error| error.to_string())?;
        store
            .set_task_status(
                "r1",
                "t1",
                echo_agent::tasks::TaskStatus::Running,
                Some("subagent"),
                None,
            )
            .map_err(|error| error.to_string())?;
        assert!(
            store
                .request_cancel("r1")
                .map_err(|error| error.to_string())?
        );
        assert_eq!(
            last_frame_event_types(&store, "r1")?,
            ["task_cancelled", "run_status_changed", "run_cancelled"]
        );
        let todo = store
            .list_todos("r1")
            .map_err(|error| error.to_string())?
            .into_iter()
            .find(|todo| todo.task_id == "t1")
            .ok_or_else(|| "cancelled Todo missing".to_string())?;
        assert_eq!(todo.status, TodoStatus::Cancelled);
        assert_eq!(todo.owner_agent.as_deref(), Some("code_reviewer"));
        assert_eq!(
            store
                .get_run("r1")
                .map_err(|error| error.to_string())?
                .ok_or_else(|| "cancelled TaskRun missing".to_string())?
                .status,
            TaskRunStatus::Cancelled
        );
        Ok(())
    }

    #[test]
    fn idle_long_horizon_run_accepts_pause_resume_and_cancel() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        for ordinal in 1..=3 {
            let turn_id = format!("turn-{ordinal}");
            assert!(matches!(
                store.claim_run_turn(
                    "r1",
                    &turn_id,
                    RunTurnOrigin::Continuation,
                    TurnVisibility::Internal,
                )?,
                RunTurnClaimOutcome::Started(_)
            ));
            store.finish_run_turn(
                "r1",
                RunTurnCompletion {
                    turn_id: &turn_id,
                    status: RunTurnStatus::Ended,
                    elapsed_seconds: 1,
                    final_message_id: None,
                    error_fingerprint: None,
                },
            )?;
        }
        assert_eq!(
            store
                .get_run_state("r1")?
                .and_then(|state| state.continuation)
                .and_then(|state| state.blocker_audit)
                .map(|audit| audit.consecutive_turns),
            Some(3)
        );

        assert!(store.request_pause("r1")?);
        let paused = store
            .get_run_state("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        assert_eq!(paused.run.status, TaskRunStatus::Paused);
        assert_eq!(
            paused
                .continuation
                .as_ref()
                .and_then(|state| state.pause.as_ref())
                .map(|pause| pause.reason),
            Some(RunPauseReason::User)
        );

        assert_eq!(store.resume_task_run("r1")?.status, TaskRunStatus::Running);
        assert!(
            store
                .get_run_state("r1")?
                .and_then(|state| state.continuation)
                .and_then(|state| state.blocker_audit)
                .is_none()
        );
        assert!(store.request_cancel("r1")?);
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Cancelled
        );
        Ok(())
    }

    #[test]
    fn physical_owner_metadata_preserves_business_progress_fingerprint() -> Result<(), StoreError> {
        // Classification-only event stream, not physical-execution proof. The
        // real shared-driver three-turn regression exercises actual ownership.
        let event = |sequence, kind, payload| {
            RuntimeJournalEvent::for_append("progress-run", None, None, kind, payload)
                .project(sequence)
                .map_err(|sequence| {
                    StoreError::InvalidPlan(format!("fixture sequence overflow: {sequence}"))
                })
        };
        let mut events = vec![
            event(
                1,
                RuntimeEventKind::TaskStarted,
                serde_json::json!({"task_id":"task"}),
            )?,
            event(
                2,
                RuntimeEventKind::RunTurnStarted,
                serde_json::json!({"turn_id":"turn"}),
            )?,
        ];
        let original_progress = run_progress_fingerprint(&events);
        let intent = PhysicalOwnerIntent {
            run_id: "progress-run".to_string(),
            owner_id: "original-owner".to_string(),
            execution_id: None,
            workspace_id: "workspace".to_string(),
            process_epoch: None,
            physical_terminal_observed: false,
        };
        let completed = PhysicalOwnerIntent {
            physical_terminal_observed: true,
            ..intent.clone()
        };
        for (sequence, kind, owner) in [
            (3, RuntimeEventKind::RecoveryBlocked, &intent),
            (4, RuntimeEventKind::RecoveryBlocked, &completed),
            (5, RuntimeEventKind::RecoveryResolved, &completed),
        ] {
            events.push(event(
                sequence,
                kind,
                serde_json::json!({"physical_owner_intent":owner}),
            )?);
            assert_eq!(run_progress_fingerprint(&events), original_progress);
            assert!(!run_turn_made_progress(&events, "turn"));
        }
        // Both real recovery event kinds still count; the marker exclusion is
        // specific to those kinds, not every event with an owner field.
        for (kind, payload) in [
            (
                RuntimeEventKind::RecoveryBlocked,
                serde_json::json!({"task_id":"task","reason":"tool outcome requires recovery"}),
            ),
            (
                RuntimeEventKind::RecoveryResolved,
                serde_json::json!({"task_id":"task","decision":"retry"}),
            ),
            (
                RuntimeEventKind::TaskCompleted,
                serde_json::json!({"task_id":"task","physical_owner_intent":completed}),
            ),
        ] {
            let mut progressed = events.clone();
            progressed.push(event(6, kind, payload)?);
            assert_ne!(run_progress_fingerprint(&progressed), original_progress);
            assert!(run_turn_made_progress(&progressed, "turn"));
        }
        Ok(())
    }

    #[test]
    fn blocker_audit_resets_on_progress_and_distinguishes_error_fingerprints()
    -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;

        assert!(matches!(
            store.claim_run_turn(
                "r1",
                "stalled-before-progress",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            )?,
            RunTurnClaimOutcome::Started(_)
        ));
        let stalled = store.finish_run_turn(
            "r1",
            RunTurnCompletion {
                turn_id: "stalled-before-progress",
                status: RunTurnStatus::Ended,
                elapsed_seconds: 1,
                final_message_id: None,
                error_fingerprint: None,
            },
        )?;
        assert_eq!(
            stalled
                .blocker_audit
                .as_ref()
                .map(|audit| audit.consecutive_turns),
            Some(1)
        );

        assert!(matches!(
            store.claim_run_turn(
                "r1",
                "progress-turn",
                RunTurnOrigin::Continuation,
                TurnVisibility::Internal,
            )?,
            RunTurnClaimOutcome::Started(_)
        ));
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("code_reviewer"),
            Some("started review"),
        )?;
        let progressed = store.finish_run_turn(
            "r1",
            RunTurnCompletion {
                turn_id: "progress-turn",
                status: RunTurnStatus::Ended,
                elapsed_seconds: 1,
                final_message_id: None,
                error_fingerprint: None,
            },
        )?;
        assert!(progressed.blocker_audit.is_none());
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Completed,
            Some("code_reviewer"),
            Some("review completed"),
        )?;

        for (turn_id, fingerprint, expected) in [
            ("provider-a", "provider_a", 1_u32),
            ("provider-b-1", "provider_b", 1_u32),
            ("provider-b-2", "provider_b", 2_u32),
            ("provider-b-3", "provider_b", 3_u32),
        ] {
            assert!(matches!(
                store.claim_run_turn(
                    "r1",
                    turn_id,
                    RunTurnOrigin::Continuation,
                    TurnVisibility::Internal,
                )?,
                RunTurnClaimOutcome::Started(_)
            ));
            let state = store.finish_run_turn(
                "r1",
                RunTurnCompletion {
                    turn_id,
                    status: RunTurnStatus::Failed,
                    elapsed_seconds: 1,
                    final_message_id: None,
                    error_fingerprint: Some(fingerprint),
                },
            )?;
            let audit = state.blocker_audit.ok_or_else(|| {
                StoreError::InvalidPlan(format!("blocker audit missing for {turn_id}"))
            })?;
            assert_eq!(audit.fingerprint, format!("error:{fingerprint}"));
            assert_eq!(audit.consecutive_turns, expected);
        }
        Ok(())
    }

    #[test]
    fn canonical_runtime_store_retry_keeps_dependency_blockers_derived() -> Result<(), StoreError> {
        let store = fresh()?;
        store.create_run(
            "retry-run",
            "ws",
            "c1",
            "m1",
            DomainProfile::General,
            "retry a failed dependency chain",
            "",
            AttendedMode::Attended,
        )?;
        store.attach_plan_for_test(&TaskPlan {
            domain_binding: None,

            plan_id: "retry-plan".to_string(),
            run_id: "retry-run".to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("retry a failed dependency chain"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![
                PlanTask {
                    id: "upstream".to_string(),
                    agent_role: "implementer".to_string(),
                    max_retries: 2,
                    ..sample_task_body("upstream")
                },
                PlanTask {
                    id: "child".to_string(),
                    agent_role: "reviewer".to_string(),
                    depends_on: vec!["upstream".to_string()],
                    ..sample_task_body("child")
                },
                PlanTask {
                    id: "acceptance-blocked".to_string(),
                    agent_role: "reviewer".to_string(),
                    ..sample_task_body("acceptance-blocked")
                },
            ],
        })?;
        store.transition_run("retry-run", TaskRunStatus::Running)?;
        store.set_task_status(
            "retry-run",
            "upstream",
            echo_agent::tasks::TaskStatus::Failed(String::new()),
            Some("implementer"),
            Some("execution failed"),
        )?;
        store.set_task_status(
            "retry-run",
            "acceptance-blocked",
            echo_agent::tasks::TaskStatus::Blocked(String::new()),
            Some("reviewer"),
            Some("review needs fix; awaiting explicit retry"),
        )?;
        store.transition_run("retry-run", TaskRunStatus::Failed)?;

        let before = store.load_runtime_plan_snapshot("retry-run")?;
        let expected_task = before
            .tasks
            .iter()
            .find(|task| task.spec.id == "upstream")
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("upstream".to_string()))?;
        let mut expected = before.clone();
        let expected_outcome =
            echo_agent::tasks::retry_runtime_task(&mut expected, &expected_task, before.revision)?;
        assert_eq!(
            expected_outcome,
            echo_agent::tasks::RuntimeTaskRetryOutcome::Retried { retry_count: 1 }
        );
        assert_eq!(store.retry_blocked_task("retry-run", "upstream")?, 1);
        let stored = store.load_runtime_plan_snapshot("retry-run")?;
        assert_eq!(stored.revision, expected.revision);
        assert_eq!(stored.tasks, expected.tasks);
        let child = store
            .list_todos("retry-run")?
            .into_iter()
            .find(|todo| todo.task_id == "child")
            .ok_or_else(|| StoreError::TaskNotFound("child".to_string()))?;
        assert_eq!(child.status, TodoStatus::Pending);
        let independent = store
            .list_todos("retry-run")?
            .into_iter()
            .find(|todo| todo.task_id == "acceptance-blocked")
            .ok_or_else(|| StoreError::TaskNotFound("acceptance-blocked".to_string()))?;
        assert_eq!(independent.status, TodoStatus::Blocked);
        let upstream = store
            .list_todos("retry-run")?
            .into_iter()
            .find(|todo| todo.task_id == "upstream")
            .ok_or_else(|| StoreError::TaskNotFound("upstream".to_string()))?;
        assert_eq!(upstream.owner_agent.as_deref(), Some("implementer"));
        assert_eq!(
            store
                .get_run("retry-run")?
                .ok_or_else(|| StoreError::RunNotFound("retry-run".to_string()))?
                .status,
            TaskRunStatus::Running
        );
        assert_eq!(
            last_frame_event_types(&store, "retry-run").map_err(StoreError::InvalidPlan)?,
            ["task_status_changed", "note", "run_status_changed"]
        );
        assert!(store.list_events("retry-run", 0)?.iter().all(|event| {
            event
                .payload
                .get("summary")
                .and_then(serde_json::Value::as_str)
                .is_none_or(|summary| !summary.contains("unblocked after retrying upstream"))
        }));
        Ok(())
    }

    #[test]
    fn boot_recovery_pauses_run_and_preserves_completed_tasks() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        s.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Completed,
            Some("explorer"),
            Some("verified"),
        )?;

        assert_eq!(s.recover_incomplete()?, 1);
        let run = s
            .get_run("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        assert_eq!(run.status, TaskRunStatus::Paused);
        let todos = s.list_todos("r1")?;
        let task = todos
            .iter()
            .find(|todo| todo.task_id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(task.status, TodoStatus::Completed);
        assert_eq!(task.summary.as_deref(), Some("verified"));
        Ok(())
    }

    #[test]
    fn boot_recovery_settles_planless_conversation_turn_without_deadlock() -> Result<(), String> {
        let store = std::sync::Arc::new(fresh().map_err(|error| error.to_string())?);
        store
            .create_run_with_profile(
                "taskrun:conversation-before-restart",
                "test",
                "conversation-before-restart",
                "conversation-before-restart",
                DomainProfile::General,
                "answer the user",
                "agent_task_plan",
                AttendedMode::Attended,
                TaskRunExecutionProfile::conversation_turn(),
            )
            .map_err(|error| error.to_string())?;
        store
            .configure_run_continuation(
                "taskrun:conversation-before-restart",
                true,
                false,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run(
                "taskrun:conversation-before-restart",
                TaskRunStatus::Running,
            )
            .map_err(|error| error.to_string())?;
        store
            .claim_run_turn(
                "taskrun:conversation-before-restart",
                "conversation-before-restart",
                RunTurnOrigin::User,
                TurnVisibility::Visible,
            )
            .map_err(|error| error.to_string())?;
        store
            .record_background_cell_started(
                "taskrun:conversation-before-restart",
                "conversation-cell",
                "long-running command",
                "command-hash",
                Some("conversation-before-restart"),
                None,
                Some("conversation-call"),
            )
            .map_err(|error| error.to_string())?;

        let recovery_store = store.clone();
        let (result_tx, result_rx) = std::sync::mpsc::sync_channel(1);
        let _recovery = std::thread::spawn(move || {
            let _sent = result_tx.send(recovery_store.recover_incomplete());
        });
        let recovered = result_rx
            .recv_timeout(std::time::Duration::from_secs(1))
            .map_err(|error| format!("planless conversation recovery did not settle: {error}"))?
            .map_err(|error| error.to_string())?;
        assert_eq!(recovered, 1);
        let snapshot = store
            .get_run_state("taskrun:conversation-before-restart")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "recovered conversation run disappeared".to_string())?;
        assert_eq!(snapshot.run.status, TaskRunStatus::Cancelled);
        assert!(
            snapshot
                .continuation
                .as_ref()
                .is_some_and(|continuation| continuation.active_turn.is_none())
        );
        let cell = snapshot
            .background_cells
            .first()
            .ok_or_else(|| "recovered conversation cell disappeared".to_string())?;
        assert_eq!(cell.phase, BackgroundCellPhase::Failed);
        assert_eq!(
            cell.terminal_cause,
            Some(BackgroundCellTerminalCause::Interrupted)
        );
        Ok(())
    }

    #[test]
    fn boot_recovery_preserves_planless_orchestrated_run() -> Result<(), String> {
        let store = fresh().map_err(|error| error.to_string())?;
        store
            .create_run_with_profile(
                "direct-run-before-restart",
                "test",
                "background:direct-before-restart",
                "",
                DomainProfile::General,
                "complete direct read-only work",
                "agent_autonomous",
                AttendedMode::Unattended,
                TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
            )
            .map_err(|error| error.to_string())?;
        store
            .configure_run_continuation("direct-run-before-restart", true, true, None, None)
            .map_err(|error| error.to_string())?;
        store
            .transition_run("direct-run-before-restart", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;

        let store = std::sync::Arc::new(store);
        let recovery_store = store.clone();
        let (result_tx, result_rx) = std::sync::mpsc::sync_channel(1);
        let _recovery = std::thread::spawn(move || {
            let _sent = result_tx.send(recovery_store.recover_incomplete());
        });
        let recovered = result_rx
            .recv_timeout(std::time::Duration::from_secs(1))
            .map_err(|error| format!("planless orchestrated recovery did not settle: {error}"))?
            .map_err(|error| error.to_string())?;
        assert_eq!(recovered, 1);
        let snapshot = store
            .get_run_state("direct-run-before-restart")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "recovered orchestrated run disappeared".to_string())?;
        assert_eq!(snapshot.run.status, TaskRunStatus::Paused);
        assert_eq!(
            snapshot
                .continuation
                .and_then(|continuation| continuation.pause)
                .map(|pause| pause.reason),
            Some(RunPauseReason::BootRecovery)
        );
        assert!(matches!(
            store
                .boot_auto_resume_decision("direct-run-before-restart", true, false)
                .map_err(|error| error.to_string())?,
            BootAutoResumeDecision::Ready { .. }
        ));
        Ok(())
    }

    #[test]
    fn boot_recovery_completes_finished_planless_conversation_settlement_debt() -> Result<(), String>
    {
        let store = fresh().map_err(|error| error.to_string())?;
        store
            .create_run_with_profile(
                "taskrun:finished-before-settlement",
                "test",
                "finished-before-settlement",
                "finished-before-settlement",
                DomainProfile::General,
                "answer the user",
                "agent_task_plan",
                AttendedMode::Attended,
                TaskRunExecutionProfile::conversation_turn(),
            )
            .map_err(|error| error.to_string())?;
        store
            .configure_run_continuation(
                "taskrun:finished-before-settlement",
                true,
                false,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("taskrun:finished-before-settlement", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .claim_run_turn(
                "taskrun:finished-before-settlement",
                "finished-before-settlement",
                RunTurnOrigin::User,
                TurnVisibility::Visible,
            )
            .map_err(|error| error.to_string())?;
        store
            .finish_run_turn(
                "taskrun:finished-before-settlement",
                RunTurnCompletion {
                    turn_id: "finished-before-settlement",
                    status: RunTurnStatus::Ended,
                    elapsed_seconds: 1,
                    final_message_id: Some("answer-1"),
                    error_fingerprint: None,
                },
            )
            .map_err(|error| error.to_string())?;

        assert_eq!(
            store
                .recover_incomplete()
                .map_err(|error| error.to_string())?,
            1
        );
        let snapshot = store
            .get_run_state("taskrun:finished-before-settlement")
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "settlement-debt run disappeared".to_string())?;
        assert_eq!(snapshot.run.status, TaskRunStatus::Completed);
        assert!(
            snapshot
                .continuation
                .is_some_and(|continuation| continuation.active_turn.is_none())
        );
        Ok(())
    }

    #[test]
    fn boot_recovery_failure_keeps_running_marker_and_is_retryable() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("subagent"),
            None,
        )?;
        let event_count_before = store.list_events("r1", 0)?.len();
        store.fail_next_recovery_commit_for_test();

        assert!(matches!(
            store.recover_incomplete(),
            Err(StoreError::InvalidPlan(message)) if message == "injected recovery commit failure"
        ));
        assert_eq!(store.list_events("r1", 0)?.len(), event_count_before);
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Running
        );
        assert_eq!(
            store
                .list_todos("r1")?
                .into_iter()
                .find(|todo| todo.task_id == "t1")
                .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?
                .status,
            TodoStatus::Running
        );

        assert_eq!(store.recover_incomplete()?, 1);
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Paused
        );
        Ok(())
    }

    #[test]
    fn boot_recovery_repairs_projection_after_atomic_event_commit() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("subagent"),
            None,
        )?;
        store.fail_next_recovery_projection_for_test();

        assert_eq!(store.recover_incomplete()?, 1);
        let stale_projection = store
            .shadow
            .read_run_state("r1")
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        assert_eq!(stale_projection.run.status, TaskRunStatus::Paused);
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Paused
        );
        let authoritative = store
            .get_run_state("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        assert_eq!(authoritative.run.status, TaskRunStatus::Paused);
        assert_eq!(
            authoritative
                .tasks
                .iter()
                .find(|task| task.task_id == "t1")
                .map(|task| TodoStatus::project_task_status(&task.status)),
            Some(TodoStatus::Pending)
        );
        assert_eq!(boot_recovery_event_count(&store)?, 1);

        assert_eq!(store.recover_incomplete()?, 0);
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Paused
        );
        let todo = store
            .list_todos("r1")?
            .into_iter()
            .find(|todo| todo.task_id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(todo.status, TodoStatus::Pending);
        assert_eq!(todo.summary.as_deref(), Some("interrupted; pending resume"));
        assert_eq!(boot_recovery_event_count(&store)?, 1);
        Ok(())
    }

    #[test]
    fn boot_recovery_closes_orphan_turn_and_records_pause_reason() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.configure_run_continuation("r1", true, false, None, None)?;
        assert!(matches!(
            store.claim_run_turn(
                "r1",
                "turn-before-restart",
                RunTurnOrigin::User,
                TurnVisibility::Visible,
            )?,
            RunTurnClaimOutcome::Started(_)
        ));
        store.account_run_turn_usage("r1", "turn-before-restart", "usage-1", 40, 2)?;

        assert_eq!(store.recover_incomplete()?, 1);
        let state = store
            .get_run_state("r1")?
            .and_then(|state| state.continuation)
            .ok_or_else(|| StoreError::InvalidPlan("continuation missing".to_string()))?;
        assert!(state.active_turn.is_none());
        assert_eq!(state.tokens_used, 42);
        assert_eq!(
            state.last_turn.as_ref().map(|turn| turn.status),
            Some(RunTurnStatus::Failed)
        );
        assert_eq!(
            state
                .last_turn
                .as_ref()
                .and_then(|turn| turn.error_fingerprint.as_deref()),
            Some("process_interrupted")
        );
        assert_eq!(
            state.pause.as_ref().map(|pause| pause.reason),
            Some(RunPauseReason::BootRecovery)
        );
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Paused
        );
        Ok(())
    }

    #[test]
    fn boot_recovery_closes_orphan_cell_without_replaying_it() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.record_background_cell_started(
            "r1",
            "orphan-cell",
            "cargo test --workspace",
            "command-hash",
            Some("turn-before-restart"),
            None,
            Some("call-before-restart"),
        )?;

        assert_eq!(store.recover_incomplete()?, 1);
        let cells = store.list_background_cells("r1")?;
        let cell = cells
            .iter()
            .find(|cell| cell.cell_id == "orphan-cell")
            .ok_or_else(|| StoreError::InvalidPlan("orphan cell was not rebuilt".to_string()))?;
        assert_eq!(cell.phase, BackgroundCellPhase::Failed);
        assert_eq!(
            cell.terminal_cause,
            Some(BackgroundCellTerminalCause::Interrupted)
        );
        assert!(!cell.is_active());
        let recovered_cell_count = store
            .list_events("r1", 0)?
            .iter()
            .filter(|event| {
                boot_recovery_payload(event)
                    .and_then(|recovery| recovery.get("cells"))
                    .and_then(serde_json::Value::as_array)
                    .is_some_and(|cells| {
                        cells.iter().any(|cell| {
                            json_string(cell, "cell_id").as_deref() == Some("orphan-cell")
                        })
                    })
            })
            .count();
        assert_eq!(recovered_cell_count, 1);
        assert_eq!(store.recover_incomplete()?, 0);
        Ok(())
    }

    #[test]
    fn boot_recovery_closes_active_cell_owned_by_already_paused_run_once() -> Result<(), StoreError>
    {
        let store = fresh()?;
        seed_plan(&store)?;
        store.record_background_cell_started(
            "r1",
            "paused-orphan-cell",
            "sleep 30",
            "hash",
            Some("turn-before-pause"),
            None,
            Some("call-before-pause"),
        )?;
        store.transition_run("r1", TaskRunStatus::Paused)?;

        assert_eq!(store.recover_incomplete()?, 1);
        let cells = store.list_background_cells("r1")?;
        let cell = cells
            .iter()
            .find(|cell| cell.cell_id == "paused-orphan-cell")
            .ok_or_else(|| StoreError::InvalidPlan("paused orphan cell missing".to_string()))?;
        assert_eq!(cell.phase, BackgroundCellPhase::Failed);
        assert_eq!(
            cell.terminal_cause,
            Some(BackgroundCellTerminalCause::Interrupted)
        );
        assert_eq!(store.recover_incomplete()?, 0);
        assert_eq!(
            store
                .list_events("r1", 0)?
                .into_iter()
                .filter(|event| {
                    event.event_type == RuntimeEventKind::BackgroundCellFinished
                        && json_string(&event.payload, "cell_id").as_deref()
                            == Some("paused-orphan-cell")
                })
                .count(),
            1
        );
        Ok(())
    }

    #[test]
    fn pause_request_stops_driver_and_keeps_run_resumable() -> Result<(), StoreError> {
        let store = std::sync::Arc::new(fresh()?);
        seed_plan(&store)?;
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("subagent"),
            None,
        )?;
        let token = echo_agent::agent::CancellationToken::new();
        let registration = store.register_run_cancellation("r1", token.clone())?;

        assert!(store.request_pause("r1")?);
        assert!(token.is_cancelled());
        drop(registration);
        let run = store
            .get_run("r1")?
            .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?;
        assert_eq!(run.status, TaskRunStatus::Paused);
        Ok(())
    }

    #[test]
    fn active_cancel_durably_overrides_a_prior_pause_intent() -> Result<(), StoreError> {
        let store = std::sync::Arc::new(fresh()?);
        seed_plan(&store)?;
        let snapshot = store.load_runtime_plan_snapshot("r1")?;
        let task = snapshot
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let claim = match store.claim_runtime_task("r1", &task, snapshot.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "claim unexpectedly reloaded".to_string(),
                ));
            }
        };
        let token = echo_agent::agent::CancellationToken::new();
        let registration = store.register_run_cancellation("r1", token.clone())?;

        assert!(store.request_pause("r1")?);
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Paused
        );
        assert!(store.request_cancel("r1")?);
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Paused
        );
        assert!(token.is_cancelled());
        assert!(store.is_run_active("r1"));
        let pending = store.load_runtime_plan_snapshot("r1")?;
        let owned = pending
            .tasks
            .iter()
            .find(|owned| owned.spec.id == task.spec.id)
            .ok_or_else(|| StoreError::TaskNotFound(task.spec.id.clone()))?;
        assert_eq!(owned.execution.claim.as_ref(), Some(&claim));
        assert_eq!(
            owned.execution.interruption_requested,
            Some(echo_agent::tasks::RuntimeInterruptionDisposition::Cancelled)
        );
        // Only the original claimed task acknowledges completion. The durable
        // cancellation request wins over its nominal Completed result.
        assert!(matches!(
            store.settle_runtime_task_claim(
                "r1",
                &task.spec.id,
                &claim,
                echo_agent::tasks::TaskStatus::Completed,
                None
            )?,
            echo_agent::tasks::RuntimeTaskSettlementOutcome::Settled {
                status: echo_agent::tasks::TaskStatus::Cancelled
            }
        ));
        store.finalize_run("r1", TaskRunStatus::Cancelled, None)?;
        assert_eq!(
            store
                .get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Cancelled
        );
        assert!(
            store
                .load_runtime_plan_snapshot("r1")?
                .tasks
                .iter()
                .all(|task| task.execution.status.is_terminal())
        );
        drop(registration);
        Ok(())
    }

    #[test]
    fn cancelled_registration_drop_only_releases_in_memory_ownership() -> Result<(), StoreError> {
        let store = std::sync::Arc::new(fresh()?);
        store.create_run(
            "cancelled-driver",
            "ws",
            "conversation",
            "message",
            DomainProfile::General,
            "cancel interrupted driver",
            "",
            AttendedMode::Unattended,
        )?;
        store.transition_run("cancelled-driver", TaskRunStatus::Running)?;
        let token = echo_agent::agent::CancellationToken::new();
        let registration = store.register_run_cancellation("cancelled-driver", token.clone())?;

        token.cancel();
        drop(registration);

        let run = store
            .get_run("cancelled-driver")?
            .ok_or_else(|| StoreError::RunNotFound("cancelled-driver".to_string()))?;
        assert_eq!(run.status, TaskRunStatus::Running);
        assert!(!store.is_run_active("cancelled-driver"));
        Ok(())
    }

    #[test]
    fn cancel_request_retains_driver_ownership_until_registration_drop() -> Result<(), StoreError> {
        let store = std::sync::Arc::new(fresh()?);
        store.create_run(
            "cancel-request-driver",
            "ws",
            "conversation",
            "message",
            DomainProfile::General,
            "cancel active driver without releasing its registry slot",
            "",
            AttendedMode::Unattended,
        )?;
        store.transition_run("cancel-request-driver", TaskRunStatus::Running)?;
        let token = echo_agent::agent::CancellationToken::new();
        let registration =
            store.register_run_cancellation("cancel-request-driver", token.clone())?;

        assert!(store.request_cancel("cancel-request-driver")?);
        assert!(token.is_cancelled());
        assert!(store.is_run_active("cancel-request-driver"));
        assert_eq!(
            store
                .get_run("cancel-request-driver")?
                .ok_or_else(|| StoreError::RunNotFound("cancel-request-driver".to_string()))?
                .status,
            TaskRunStatus::Running
        );

        // This manual owner now acknowledges its own completion, before
        // dropping the registry guard; the request alone was nonterminal.
        store.finalize_run("cancel-request-driver", TaskRunStatus::Cancelled, None)?;
        drop(registration);
        assert!(!store.is_run_active("cancel-request-driver"));
        assert_eq!(
            store
                .get_run("cancel-request-driver")?
                .ok_or_else(|| StoreError::RunNotFound("cancel-request-driver".to_string()))?
                .status,
            TaskRunStatus::Cancelled
        );
        Ok(())
    }

    #[test]
    fn cancelled_nested_registration_restores_outer_driver() -> Result<(), StoreError> {
        let store = std::sync::Arc::new(fresh()?);
        store.create_run(
            "nested-cancelled-driver",
            "ws",
            "conversation",
            "message",
            DomainProfile::General,
            "cancel nested driver",
            "",
            AttendedMode::Unattended,
        )?;
        store.transition_run("nested-cancelled-driver", TaskRunStatus::Running)?;
        let outer_token = echo_agent::agent::CancellationToken::new();
        let outer_registration =
            store.register_run_cancellation("nested-cancelled-driver", outer_token.clone())?;
        let inner_token = outer_token.child_token();
        let inner_registration =
            store.register_run_cancellation("nested-cancelled-driver", inner_token.clone())?;

        inner_token.cancel();
        drop(inner_registration);

        let run = store
            .get_run("nested-cancelled-driver")?
            .ok_or_else(|| StoreError::RunNotFound("nested-cancelled-driver".to_string()))?;
        assert_eq!(run.status, TaskRunStatus::Running);
        assert!(store.is_run_active("nested-cancelled-driver"));
        assert!(!outer_token.is_cancelled());

        drop(outer_registration);
        assert!(!store.is_run_active("nested-cancelled-driver"));
        Ok(())
    }

    #[test]
    fn boot_recovery_requeues_orphaned_running_task() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("subagent"),
            None,
        )?;

        assert_eq!(store.recover_incomplete()?, 1);
        let todo = store
            .list_todos("r1")?
            .into_iter()
            .find(|todo| todo.task_id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(todo.status, TodoStatus::Pending);
        assert_eq!(todo.summary.as_deref(), Some("interrupted; pending resume"));
        Ok(())
    }

    #[test]
    fn boot_recovery_terminalizes_replay_safe_orphan_subagent_without_blocker()
    -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let task = store
            .get_plan("r1")?
            .and_then(|plan| plan.tasks.into_iter().next())
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let runtime_task =
            echo_agent::tasks::Task::try_from(&task).map_err(StoreError::InvalidPlan)?;
        let claim = match store.claim_runtime_task("r1", &runtime_task, 1)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "fresh task claim unexpectedly required reload".to_string(),
                ));
            }
        };
        let execution_id = claim.execution_id("r1", "t1");
        store.record_subagent_assigned(
            "r1",
            "t1",
            &execution_id,
            "subagent",
            "Task 1",
            claim.revision,
            claim.attempt,
            true,
            true,
        )?;

        assert_eq!(store.recover_incomplete()?, 1);
        assert!(store.active_subagent_boundaries("r1")?.is_empty());
        assert!(store.list_recovery_blockers("r1")?.is_empty());
        let subagent = store
            .list_subagent_runs("r1")?
            .into_iter()
            .find(|run| run.subagent_run_id == execution_id)
            .ok_or_else(|| StoreError::InvalidPlan("orphan Subagent missing".to_string()))?;
        assert_eq!(subagent.status, SubagentStatus::Failed);
        let recovery = store
            .list_events("r1", 0)?
            .into_iter()
            .find_map(|event| boot_recovery_payload(&event).cloned())
            .ok_or_else(|| StoreError::InvalidPlan("recovery event missing".to_string()))?;
        assert_eq!(
            recovery
                .get("subagents")
                .and_then(serde_json::Value::as_array)
                .and_then(|subagents| {
                    subagents.iter().find(|subagent| {
                        json_string(subagent, "execution_id").as_deref()
                            == Some(execution_id.as_str())
                    })
                })
                .and_then(|subagent| subagent.get("terminal_cause"))
                .and_then(serde_json::Value::as_str),
            Some("process_interrupted")
        );
        Ok(())
    }

    #[test]
    fn boot_recovery_reuses_completed_subagent_without_redispatch() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let task = store
            .get_plan("r1")?
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let runtime_task =
            echo_agent::tasks::Task::try_from(&task).map_err(StoreError::InvalidPlan)?;
        let claim = match store.claim_runtime_task("r1", &runtime_task, 1)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "fresh task claim unexpectedly required reload".to_string(),
                ));
            }
        };
        let execution_id = claim.execution_id("r1", "t1");
        store.record_subagent_assigned(
            "r1",
            "t1",
            &execution_id,
            "subagent",
            "Task 1",
            claim.revision,
            claim.attempt,
            true,
            true,
        )?;
        let result =
            SubagentOutcome::terminal(SubagentStatus::Completed, "durable result", Vec::new());
        store.record_subagent_released(SubagentReleaseRecord {
            run_id: "r1",
            task_id: "t1",
            execution_id: &execution_id,
            agent_name: "subagent",
            task_subject: "Task 1",
            plan_revision: claim.revision,
            attempt: claim.attempt,
            status: "completed",
            outcome: Some(&result),
            full_output: Some("durable full output"),
            usage: None,
            dispatch_hook: true,
        })?;

        assert_eq!(store.recover_incomplete()?, 1);
        assert_eq!(
            store.recoverable_subagent_outcome_for_attempt(
                "r1",
                "t1",
                &execution_id,
                claim.revision,
                claim.attempt,
            )?,
            Some(RecoverableSubagentOutcome {
                outcome: result,
                full_output: "durable full output".to_string(),
            })
        );
        let todo = store
            .list_todos("r1")?
            .into_iter()
            .find(|todo| todo.task_id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(todo.status, TodoStatus::Pending);
        assert_eq!(
            todo.summary.as_deref(),
            Some("Subagent completed before interruption; pending review")
        );
        assert!(store.list_recovery_blockers("r1")?.is_empty());
        Ok(())
    }

    #[test]
    fn mutating_in_doubt_subagent_blocks_resume_until_user_decides() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "exercise mutating recovery".to_string(),
                operations: vec![TaskUpdateOperation::Update {
                    task_id: "t1".to_string(),
                    patch: Box::new(TaskPatch {
                        kind: Some(PlanTaskKind::Implementation),
                        ..Default::default()
                    }),
                }],
            },
        )?;
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("subagent"),
            None,
        )?;
        store.record_subagent_assigned(
            "r1", "t1", "t1:1", "subagent", "Task 1", 1, 1, false, true,
        )?;
        store.record_tool_started("r1", "t1", "t1:1", "call-write", "write_file", false)?;

        assert_eq!(store.recover_incomplete()?, 1);
        assert!(store.active_subagent_boundaries("r1")?.is_empty());
        let blockers = store.list_recovery_blockers("r1")?;
        assert_eq!(blockers.len(), 1);
        assert_eq!(
            blockers.first().and_then(|b| b.call_id.as_deref()),
            Some("call-write")
        );
        assert!(matches!(
            store.resume_task_run("r1"),
            Err(StoreError::RecoveryBlocked { .. })
        ));

        store.resolve_recovery_task("r1", "t1", RecoveryDecision::Retry)?;
        assert_eq!(
            last_frame_event_types(&store, "r1").map_err(StoreError::InvalidPlan)?,
            ["recovery_resolved", "task_status_changed"]
        );
        assert!(store.list_recovery_blockers("r1")?.is_empty());
        let todo = store
            .list_todos("r1")?
            .into_iter()
            .find(|todo| todo.task_id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(todo.status, TodoStatus::Pending);
        assert_eq!(store.resume_task_run("r1")?.status, TaskRunStatus::Running);
        Ok(())
    }

    #[test]
    fn canonical_recovery_skip_commits_revision_and_resolution_in_one_batch()
    -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "exercise canonical recovery skip".to_string(),
                operations: vec![TaskUpdateOperation::Update {
                    task_id: "t1".to_string(),
                    patch: Box::new(TaskPatch {
                        kind: Some(PlanTaskKind::Implementation),
                        ..Default::default()
                    }),
                }],
            },
        )?;
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("subagent"),
            None,
        )?;
        store.record_subagent_assigned(
            "r1", "t1", "t1:1", "subagent", "Task 1", 2, 1, false, true,
        )?;
        store.record_tool_started("r1", "t1", "t1:1", "call-write", "write_file", false)?;
        assert_eq!(store.recover_incomplete()?, 1);
        let before = store.load_runtime_plan_snapshot("r1")?;
        let expected_revision = before
            .revision
            .checked_add(1)
            .ok_or_else(|| StoreError::InvalidPlan("test plan revision overflow".to_string()))?;

        store.resolve_recovery_task("r1", "t1", RecoveryDecision::Skip)?;

        let after = store.load_runtime_plan_snapshot("r1")?;
        assert_eq!(after.revision, expected_revision);
        let skipped = after
            .tasks
            .iter()
            .find(|task| task.spec.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(
            skipped.execution.status,
            echo_agent::tasks::TaskStatus::Skipped
        );
        assert!(skipped.execution.claim.is_none());
        assert!(store.list_recovery_blockers("r1")?.is_empty());
        assert_eq!(
            last_frame_event_types(&store, "r1").map_err(StoreError::InvalidPlan)?,
            [
                "plan_revision_committed",
                "recovery_resolved",
                "task_skipped",
            ]
        );
        Ok(())
    }

    #[test]
    fn tool_failure_boundary_persists_recovery_contract() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let failure = echo_agent::tools::ToolFailure::new(
            echo_agent::tools::ToolFailureCategory::PartialSideEffect,
        )
        .with_postcondition("verify target hash");

        store.record_tool_started("r1", "t1", "t1:1", "call-1", "write_file", false)?;
        store.record_tool_finished(
            "r1",
            "t1",
            "t1:1",
            "call-1",
            "write_file",
            false,
            "write interrupted",
            Some(&failure),
        )?;

        let event = store
            .list_events("r1", 0)?
            .into_iter()
            .find(|event| event.event_type == RuntimeEventKind::ToolFailed)
            .ok_or_else(|| StoreError::TaskNotFound("tool failure event".to_string()))?;
        assert_eq!(
            event
                .payload
                .get("failure")
                .and_then(|failure| failure.get("category"))
                .and_then(serde_json::Value::as_str),
            Some("partial_side_effect")
        );
        assert_eq!(
            event
                .payload
                .get("failure")
                .and_then(|failure| failure.get("postcondition"))
                .and_then(serde_json::Value::as_str),
            Some("verify target hash")
        );
        Ok(())
    }

    #[test]
    fn find_in_progress_run_by_conversation_returns_running() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?; // run "r1" in conversation "c1" is now Running.
        let found = s
            .find_in_progress_run_by_conversation("c1")?
            .ok_or_else(|| StoreError::RunNotFound("in-progress run for c1".to_string()))?;
        assert_eq!(found.run_id, "r1");
        Ok(())
    }

    #[test]
    fn find_in_progress_run_by_conversation_returns_paused() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        s.transition_run("r1", TaskRunStatus::Paused)?;
        let found = s
            .find_in_progress_run_by_conversation("c1")?
            .ok_or_else(|| StoreError::RunNotFound("paused run for c1".to_string()))?;
        assert_eq!(found.run_id, "r1");
        Ok(())
    }

    #[test]
    fn find_in_progress_run_by_conversation_returns_none_for_completed() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        s.transition_run("r1", TaskRunStatus::Completed)?;
        let found = s.find_in_progress_run_by_conversation("c1")?;
        assert!(found.is_none());
        Ok(())
    }

    #[test]
    fn task_update_inserts_task_and_commits_one_revision() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        let t2 = PlanTask {
            id: "t2".into(),
            title: "Second task".into(),
            description: "implement the second task".into(),
            kind: PlanTaskKind::Implementation,
            agent_role: "implementer".into(),
            depends_on: vec!["t1".into()],
            ..Default::default()
        };
        let before = s.list_events("r1", 0)?.len();
        let plan = s.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "new implementation dependency".to_string(),
                operations: vec![TaskUpdateOperation::Insert {
                    after_task_id: Some("t1".to_string()),
                    task: Box::new(t2.spec()),
                }],
            },
        )?;

        assert_eq!(plan.revision, 2);
        assert_eq!(plan.tasks.len(), 2);
        assert_eq!(plan.tasks[0].id, "t1");
        assert_eq!(plan.tasks[1].id, "t2");
        let evs = s.list_events("r1", 0)?;
        assert_eq!(evs.len(), before + 1);
        assert_eq!(
            evs.last().map(|event| event.event_type),
            Some(RuntimeEventKind::PlanRevisionCommitted)
        );
        Ok(())
    }

    #[test]
    fn reorder_keeps_plan_todos_and_framework_graph_in_one_order() -> Result<(), StoreError> {
        let store = TaskRuntimeStore::new_in_memory()
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        store.create_run(
            "reorder-run",
            "ws",
            "c-reorder",
            "m-reorder",
            DomainProfile::General,
            "reorder",
            "",
            AttendedMode::Attended,
        )?;
        let plan = TaskPlan {
            domain_binding: None,

            plan_id: "reorder-plan".to_string(),
            run_id: "reorder-run".to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("reorder"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![
                PlanTask {
                    id: "first".to_string(),
                    title: "First".to_string(),
                    sort_order: 0,
                    ..PlanTask::default()
                },
                PlanTask {
                    id: "second".to_string(),
                    title: "Second".to_string(),
                    sort_order: 1,
                    ..PlanTask::default()
                },
            ],
        };
        store.attach_plan_for_test(&plan)?;
        store.transition_run("reorder-run", TaskRunStatus::Running)?;

        let reordered = store.apply_task_patch_for_test(
            "reorder-run",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "surface parity reorder".to_string(),
                operations: vec![TaskUpdateOperation::Reorder {
                    task_ids: vec!["second".to_string(), "first".to_string()],
                }],
            },
        )?;
        assert_eq!(
            reordered
                .tasks
                .iter()
                .map(|task| task.id.as_str())
                .collect::<Vec<_>>(),
            vec!["second", "first"]
        );
        assert_eq!(
            reordered
                .tasks
                .iter()
                .map(|task| task.sort_order)
                .collect::<Vec<_>>(),
            vec![0, 1]
        );

        let todos = store.list_todos("reorder-run")?;
        assert_eq!(
            todos
                .iter()
                .map(|todo| todo.task_id.as_str())
                .collect::<Vec<_>>(),
            vec!["second", "first"]
        );
        let graph = store
            .load_revisioned_task_graph("reorder-run")?
            .ok_or_else(|| StoreError::PlanNotFound("reorder-run".to_string()))?;
        assert_eq!(
            graph
                .snapshot
                .tasks
                .iter()
                .map(|task| task.spec.id.as_str())
                .collect::<Vec<_>>(),
            vec!["second", "first"]
        );
        Ok(())
    }

    #[test]
    fn task_update_rejects_missing_run() -> std::result::Result<(), String> {
        let s = TaskRuntimeStore::new_in_memory().map_err(|e| e.to_string())?;
        let err = s
            .apply_task_patch_for_test(
                "missing-run",
                &TaskUpdateRequest {
                    base_revision: 1,
                    reason: "invalid".to_string(),
                    operations: vec![TaskUpdateOperation::Reorder {
                        task_ids: Vec::new(),
                    }],
                },
            )
            .err()
            .ok_or_else(|| "task_update unexpectedly succeeded without a run".to_string())?;
        assert!(matches!(err, StoreError::RunNotFound(run_id) if run_id == "missing-run"));
        Ok(())
    }

    #[test]
    fn task_update_rejects_stale_revision_without_appending_event() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        let before = s.list_events("r1", 0)?.len();
        let error = s
            .apply_task_patch_for_test(
                "r1",
                &TaskUpdateRequest {
                    base_revision: 0,
                    reason: "stale edit".to_string(),
                    operations: vec![TaskUpdateOperation::Skip {
                        task_id: "t1".to_string(),
                    }],
                },
            )
            .err()
            .ok_or_else(|| {
                StoreError::InvalidPlan("stale update unexpectedly succeeded".to_string())
            })?;
        assert!(matches!(error, StoreError::PlanConflict { .. }));
        assert_eq!(s.list_events("r1", 0)?.len(), before);
        Ok(())
    }

    #[test]
    fn canonical_runtime_store_claim_and_settlement_match_framework_fields()
    -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let before = store.load_runtime_plan_snapshot("r1")?;
        let expected_task = before
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let mut framework_claimed = before.clone();
        let framework_claim = match echo_agent::tasks::claim_runtime_task(
            &mut framework_claimed,
            &expected_task,
            before.revision,
        )? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "framework unexpectedly rejected a fresh claim".to_string(),
                ));
            }
        };
        store.fail_next_runtime_mutation_projection_for_test();
        let stored_claim = match store.claim_runtime_task("r1", &expected_task, before.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "store unexpectedly rejected a fresh claim".to_string(),
                ));
            }
        };
        assert_eq!(stored_claim.revision, framework_claim.revision);
        assert_eq!(stored_claim.attempt, framework_claim.attempt);
        assert_eq!(stored_claim.spec_hash, framework_claim.spec_hash);
        let framework_task = framework_claimed
            .tasks
            .iter_mut()
            .find(|task| task.spec.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        framework_task.execution.claim = Some(stored_claim.clone());
        let stored_claimed = store.load_runtime_plan_snapshot("r1")?;
        assert_eq!(stored_claimed.revision, framework_claimed.revision);
        assert_eq!(stored_claimed.tasks, framework_claimed.tasks);

        let claim_event = store
            .list_events("r1", 0)?
            .into_iter()
            .last()
            .ok_or_else(|| StoreError::InvalidPlan("claim event missing".to_string()))?;
        for field in [
            "status",
            "status_detail",
            "claim",
            "retry_count",
            "failure_fingerprint",
            "owner_agent",
            "summary",
        ] {
            assert!(claim_event.payload.get(field).is_some(), "missing {field}");
        }

        let mut framework_settled = framework_claimed;
        assert_eq!(
            echo_agent::tasks::settle_runtime_claim(
                &mut framework_settled,
                "t1",
                &stored_claim,
                echo_agent::tasks::TaskStatus::Completed,
            )?,
            echo_agent::tasks::RuntimeTaskSettlementOutcome::Settled {
                status: echo_agent::tasks::TaskStatus::Completed
            }
        );
        store.fail_next_runtime_mutation_projection_for_test();
        assert_eq!(
            store.settle_runtime_task_claim(
                "r1",
                "t1",
                &stored_claim,
                echo_agent::tasks::TaskStatus::Completed,
                Some("reviewed completion".to_string()),
            )?,
            echo_agent::tasks::RuntimeTaskSettlementOutcome::Settled {
                status: echo_agent::tasks::TaskStatus::Completed
            }
        );
        let stored = store.load_runtime_plan_snapshot("r1")?;
        assert_eq!(stored.revision, framework_settled.revision);
        assert_eq!(stored.tasks, framework_settled.tasks);
        let terminal = stored
            .tasks
            .iter()
            .find(|task| task.spec.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert!(terminal.execution.claim.is_none());
        assert_eq!(
            terminal.execution.status,
            echo_agent::tasks::TaskStatus::Completed
        );
        Ok(())
    }

    #[test]
    fn canonical_runtime_store_requeue_matches_framework_and_rejects_aba_claim()
    -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let initial = store.load_runtime_plan_snapshot("r1")?;
        let expected_task = initial
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let first_claim = match store.claim_runtime_task("r1", &expected_task, initial.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "fresh requeue claim unexpectedly required reload".to_string(),
                ));
            }
        };
        let claimed = store.load_runtime_plan_snapshot("r1")?;
        let request = echo_agent::tasks::RuntimeTaskResolutionRequest::Requeue {
            failure_fingerprint: Some("compile-fingerprint".to_string()),
            error: "cargo check failed".to_string(),
            exhaustion: echo_agent::tasks::RuntimeRetryExhaustion::Failed,
        };
        let mut framework_requeued = claimed.clone();
        let framework_resolution = echo_agent::tasks::settle_runtime_resolution(
            &mut framework_requeued,
            "t1",
            &first_claim,
            request.clone(),
        )?;
        store.fail_next_runtime_mutation_projection_for_test();
        assert_eq!(
            store
                .settle_runtime_task_resolution(
                    "r1",
                    "t1",
                    &first_claim,
                    request,
                    RuntimeTaskProductSettlement {
                        summary: Some("retry after cargo check".to_string()),
                        ..RuntimeTaskProductSettlement::default()
                    },
                )?
                .resolution,
            framework_resolution
        );
        let stored_requeued = store.load_runtime_plan_snapshot("r1")?;
        assert_eq!(stored_requeued.revision, framework_requeued.revision);
        assert_eq!(stored_requeued.tasks, framework_requeued.tasks);
        let requeued = framework_requeued
            .tasks
            .iter()
            .find(|task| task.spec.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(
            requeued.execution.status,
            echo_agent::tasks::TaskStatus::Pending
        );
        assert_eq!(requeued.execution.retry_count, 1);
        assert_eq!(
            requeued.execution.failure_fingerprint.as_deref(),
            Some("compile-fingerprint")
        );
        assert!(requeued.execution.claim.is_none());

        let second_claim = match store.claim_runtime_task("r1", requeued, initial.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "requeued task unexpectedly required reload".to_string(),
                ));
            }
        };
        assert_ne!(first_claim.claim_id, second_claim.claim_id);
        let completed_summary = TaskExecutionSummary {
            run_id: "r1".to_string(),
            task_id: "t1".to_string(),
            subagent_name: "subagent".to_string(),
            outcome: SubagentOutcome::terminal(
                SubagentStatus::Completed,
                "new physical claim result",
                Vec::new(),
            ),
            decisions: Vec::new(),
            next_implications: Vec::new(),
            suggested_tasks: Vec::new(),
            created_at: Utc::now(),
        };
        let current_review = ReviewResult {
            id: "review-new-claim".to_string(),
            run_id: "r1".to_string(),
            task_id: "t1".to_string(),
            reviewer_agent: "reviewer".to_string(),
            outcome: ReviewOutcome::Pass,
            issues: Vec::new(),
            failure_fingerprint: None,
            created_fix_task_id: None,
            created_at: Utc::now(),
        };
        assert_eq!(
            store
                .settle_runtime_task_resolution(
                    "r1",
                    "t1",
                    &second_claim,
                    echo_agent::tasks::RuntimeTaskResolutionRequest::Completed,
                    RuntimeTaskProductSettlement {
                        summary: Some("new physical claim result".to_string()),
                        execution_summary: Some(completed_summary.clone()),
                        review: Some(current_review),
                        diagnostic_note: Some("accepted new claim review".to_string()),
                        typed_terminal: None,
                    },
                )?
                .resolution,
            echo_agent::tasks::RuntimeTaskResolution::Completed
        );
        let stale_summary = TaskExecutionSummary {
            outcome: SubagentOutcome::terminal(
                SubagentStatus::Completed,
                "stale physical claim result",
                Vec::new(),
            ),
            ..completed_summary
        };
        let stale_review = ReviewResult {
            id: "review-stale-claim".to_string(),
            run_id: "r1".to_string(),
            task_id: "t1".to_string(),
            reviewer_agent: "reviewer".to_string(),
            outcome: ReviewOutcome::NeedsFix,
            issues: Vec::new(),
            failure_fingerprint: Some("stale-fingerprint".to_string()),
            created_fix_task_id: None,
            created_at: Utc::now(),
        };
        assert_eq!(
            store
                .settle_runtime_task_resolution(
                    "r1",
                    "t1",
                    &first_claim,
                    echo_agent::tasks::RuntimeTaskResolutionRequest::Completed,
                    RuntimeTaskProductSettlement {
                        summary: Some("stale physical claim result".to_string()),
                        execution_summary: Some(stale_summary),
                        review: Some(stale_review),
                        diagnostic_note: Some("stale claim review note".to_string()),
                        typed_terminal: None,
                    },
                )?
                .resolution,
            echo_agent::tasks::RuntimeTaskResolution::Superseded
        );
        assert_eq!(
            store
                .get_summary("r1", "t1")?
                .ok_or_else(|| StoreError::TaskNotFound("t1 summary".to_string()))?
                .outcome
                .summary,
            "new physical claim result"
        );
        let reviews = store.list_reviews("r1", "t1")?;
        assert_eq!(reviews.len(), 1);
        assert_eq!(
            reviews.first().map(|review| review.id.as_str()),
            Some("review-new-claim")
        );
        let notes = store.list_events("r1", 0)?;
        assert!(notes.iter().any(|event| {
            event
                .payload
                .get("message")
                .and_then(serde_json::Value::as_str)
                == Some("accepted new claim review")
        }));
        assert!(!notes.iter().any(|event| {
            event
                .payload
                .get("message")
                .and_then(serde_json::Value::as_str)
                == Some("stale claim review note")
        }));
        Ok(())
    }

    #[test]
    fn canonical_runtime_store_pause_interruption_is_lossless() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let initial = store.load_runtime_plan_snapshot("r1")?;
        let expected_task = initial
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let claim = match store.claim_runtime_task("r1", &expected_task, initial.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "fresh interruption claim unexpectedly required reload".to_string(),
                ));
            }
        };
        let claimed = store.load_runtime_plan_snapshot("r1")?;
        let mut framework_paused = claimed.clone();
        let disposition = echo_agent::tasks::RuntimeInterruptionDisposition::Paused {
            reason: "user requested pause".to_string(),
        };
        let framework_outcome = echo_agent::tasks::settle_runtime_interruption(
            &mut framework_paused,
            claimed.revision,
            disposition.clone(),
        )?;
        store.fail_next_runtime_mutation_projection_for_test();
        assert_eq!(
            store.settle_runtime_task_interruption("r1", claimed.revision, disposition)?,
            framework_outcome
        );
        let stored_paused = store.load_runtime_plan_snapshot("r1")?;
        assert_eq!(stored_paused.revision, framework_paused.revision);
        assert!(!store.runtime_task_claim_is_current("r1", "t1", &claim)?);
        let paused = framework_paused
            .tasks
            .iter()
            .find(|task| task.spec.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(
            paused.execution.status,
            echo_agent::tasks::TaskStatus::Paused("user requested pause".to_string())
        );
        assert!(paused.execution.claim.is_none());
        let retry_count_before_resume = paused.execution.retry_count;
        let persisted = stored_paused
            .tasks
            .iter()
            .find(|task| task.spec.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(
            persisted.execution.status,
            echo_agent::tasks::TaskStatus::Paused("user requested pause".to_string())
        );
        assert_eq!(persisted.execution.retry_count, retry_count_before_resume);
        store.transition_run("r1", TaskRunStatus::Paused)?;
        store.resume_task_run("r1")?;
        let resumed = store
            .load_runtime_plan_snapshot("r1")?
            .tasks
            .into_iter()
            .find(|task| task.spec.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(
            resumed.execution.status,
            echo_agent::tasks::TaskStatus::Pending
        );
        assert_eq!(resumed.execution.retry_count, retry_count_before_resume);
        assert!(resumed.execution.claim.is_none());
        Ok(())
    }

    #[test]
    fn recovered_result_requires_exact_physical_claim_after_pause_resume() -> Result<(), StoreError>
    {
        let store = fresh()?;
        seed_plan(&store)?;
        let initial = store.load_runtime_plan_snapshot("r1")?;
        let expected = initial
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let old_claim = match store.claim_runtime_task("r1", &expected, initial.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "initial claim reloaded".to_string(),
                ));
            }
        };
        let old_execution_id = old_claim.execution_id("r1", "t1");
        store.record_subagent_assigned(
            "r1",
            "t1",
            &old_execution_id,
            "subagent",
            "Review runtime",
            old_claim.revision,
            old_claim.attempt,
            true,
            true,
        )?;
        store.settle_runtime_task_interruption(
            "r1",
            initial.revision,
            echo_agent::tasks::RuntimeInterruptionDisposition::Paused {
                reason: "pause for exact recovery test".to_string(),
            },
        )?;
        store.transition_run("r1", TaskRunStatus::Paused)?;
        store.resume_task_run("r1")?;
        let resumed = store.load_runtime_plan_snapshot("r1")?;
        let resumed_task = resumed
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let new_claim = match store.claim_runtime_task("r1", &resumed_task, resumed.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "resumed claim reloaded".to_string(),
                ));
            }
        };
        assert_eq!(new_claim.attempt, old_claim.attempt);
        let new_execution_id = new_claim.execution_id("r1", "t1");
        store.record_subagent_assigned(
            "r1",
            "t1",
            &new_execution_id,
            "subagent",
            "Review runtime",
            new_claim.revision,
            new_claim.attempt,
            true,
            true,
        )?;
        let stale_result = SubagentOutcome::terminal(
            SubagentStatus::Completed,
            "late result from old physical claim",
            Vec::new(),
        );
        store.record_subagent_released(SubagentReleaseRecord {
            run_id: "r1",
            task_id: "t1",
            execution_id: &old_execution_id,
            agent_name: "subagent",
            task_subject: "Review runtime",
            plan_revision: old_claim.revision,
            attempt: old_claim.attempt,
            status: "completed",
            outcome: Some(&stale_result),
            full_output: Some("late result from old physical claim"),
            usage: None,
            dispatch_hook: true,
        })?;

        assert!(
            store
                .recoverable_subagent_outcome_for_attempt(
                    "r1",
                    "t1",
                    &new_execution_id,
                    new_claim.revision,
                    new_claim.attempt,
                )?
                .is_none()
        );
        assert!(
            store
                .recoverable_subagent_outcome_for_attempt(
                    "r1",
                    "t1",
                    &old_execution_id,
                    old_claim.revision,
                    old_claim.attempt,
                )?
                .is_some()
        );
        Ok(())
    }

    #[test]
    fn canonical_runtime_store_revision_reload_wins_task_update_race() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let expected = store
            .get_plan("r1")?
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?
            .tasks
            .first()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?
            .try_into()
            .map_err(StoreError::InvalidPlan)?;
        store.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "skip before stale dispatch claims task".to_string(),
                operations: vec![TaskUpdateOperation::Skip {
                    task_id: "t1".to_string(),
                }],
            },
        )?;

        let outcome = store.claim_runtime_task("r1", &expected, 1)?;

        assert_eq!(
            outcome,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot
        );
        let task = store
            .get_plan("r1")?
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?
            .tasks
            .into_iter()
            .find(|task| task.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(task.status, echo_agent::tasks::TaskStatus::Skipped);
        assert!(task.claim.is_none());
        Ok(())
    }

    #[test]
    fn stale_claim_cannot_overwrite_cancelled_task() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let expected = store
            .get_plan("r1")?
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?
            .tasks
            .first()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?
            .try_into()
            .map_err(StoreError::InvalidPlan)?;
        let claim = match store.claim_runtime_task("r1", &expected, 1)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "fresh task claim unexpectedly required reload".to_string(),
                ));
            }
        };
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Skipped,
            None,
            Some("cancelled by user"),
        )?;

        let outcome = store.settle_runtime_task_claim(
            "r1",
            "t1",
            &claim,
            echo_agent::tasks::TaskStatus::Completed,
            Some("stale completion".to_string()),
        )?;

        assert_eq!(
            outcome,
            echo_agent::tasks::RuntimeTaskSettlementOutcome::Superseded
        );
        let task = store
            .get_plan("r1")?
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?
            .tasks
            .into_iter()
            .find(|task| task.id == "t1")
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(task.status, echo_agent::tasks::TaskStatus::Skipped);
        Ok(())
    }

    #[test]
    fn patched_spec_uses_new_execution_identity_without_retry_bump() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        let original = store
            .get_plan("r1")?
            .ok_or_else(|| StoreError::PlanNotFound("r1".to_string()))?
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let original_runtime =
            echo_agent::tasks::Task::try_from(&original).map_err(StoreError::InvalidPlan)?;
        let old_claim = echo_agent::tasks::TaskClaim::new(
            1,
            1,
            original_runtime
                .spec
                .stable_hash()
                .map_err(StoreError::InvalidPlan)?,
        );
        let old_execution_id = old_claim.execution_id("r1", &original.id);
        let durable_result =
            SubagentOutcome::terminal(SubagentStatus::Completed, "old spec result", Vec::new());
        store.record_subagent_assigned(
            "r1",
            "t1",
            &old_execution_id,
            "code_reviewer",
            &original.title,
            old_claim.revision,
            old_claim.attempt,
            true,
            true,
        )?;
        store.record_subagent_released(SubagentReleaseRecord {
            run_id: "r1",
            task_id: "t1",
            execution_id: &old_execution_id,
            agent_name: "code_reviewer",
            task_subject: &original.title,
            plan_revision: old_claim.revision,
            attempt: old_claim.attempt,
            status: "completed",
            outcome: Some(&durable_result),
            full_output: Some("old spec full output"),
            usage: None,
            dispatch_hook: true,
        })?;
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Blocked(String::new()),
            Some("code_reviewer"),
            Some("requires a revised contract"),
        )?;
        let patched = store.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "change blocked task contract".to_string(),
                operations: vec![TaskUpdateOperation::Update {
                    task_id: "t1".to_string(),
                    patch: Box::new(TaskPatch {
                        description: Some("review the revised runtime contract".to_string()),
                        ..Default::default()
                    }),
                }],
            },
        )?;
        let patched_task = patched
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        assert_eq!(patched_task.retry_count, 0);
        let patched_runtime =
            echo_agent::tasks::Task::try_from(&patched_task).map_err(StoreError::InvalidPlan)?;
        let new_claim = match store.claim_runtime_task("r1", &patched_runtime, patched.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan(
                    "patched task claim unexpectedly required reload".to_string(),
                ));
            }
        };
        let new_execution_id = new_claim.execution_id("r1", &patched_task.id);

        assert_ne!(old_execution_id, new_execution_id);
        assert_ne!(old_claim.spec_hash, new_claim.spec_hash);
        assert!(
            store
                .recoverable_subagent_outcome_for_attempt(
                    "r1",
                    "t1",
                    &old_execution_id,
                    old_claim.revision,
                    old_claim.attempt,
                )?
                .is_some()
        );
        assert!(
            store
                .recoverable_subagent_outcome_for_attempt(
                    "r1",
                    "t1",
                    &new_execution_id,
                    new_claim.revision,
                    new_claim.attempt,
                )?
                .is_none()
        );
        Ok(())
    }

    #[test]
    fn task_update_skip_preserves_spec_and_updates_execution() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        let plan = s.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "task no longer required".to_string(),
                operations: vec![TaskUpdateOperation::Skip {
                    task_id: "t1".to_string(),
                }],
            },
        )?;
        assert_eq!(plan.revision, 2);
        assert_eq!(plan.tasks.len(), 1);
        assert_eq!(plan.tasks[0].status, echo_agent::tasks::TaskStatus::Skipped);
        Ok(())
    }

    #[test]
    fn task_update_update_requeues_blocked_task() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        s.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Blocked(String::new()),
            Some("reviewer"),
            Some("needs a clearer brief"),
        )?;
        let plan = s.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "clarify the blocked task".to_string(),
                operations: vec![TaskUpdateOperation::Update {
                    task_id: "t1".to_string(),
                    patch: Box::new(TaskPatch {
                        description: Some("Review the clarified runtime boundary".to_string()),
                        ..Default::default()
                    }),
                }],
            },
        )?;
        assert_eq!(plan.revision, 2);
        assert_eq!(plan.tasks[0].status, echo_agent::tasks::TaskStatus::Pending);
        assert_eq!(
            plan.tasks[0].description,
            "Review the clarified runtime boundary"
        );
        Ok(())
    }

    #[test]
    fn completion_gate_rechecks_latest_plan_revision() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        let persist_summary = |task_id: &str| {
            s.put_summary(&TaskExecutionSummary {
                run_id: "r1".to_string(),
                task_id: task_id.to_string(),
                subagent_name: "explorer".to_string(),
                outcome: SubagentOutcome::terminal(
                    SubagentStatus::Completed,
                    "verified task result",
                    Vec::new(),
                ),
                decisions: Vec::new(),
                next_implications: Vec::new(),
                suggested_tasks: Vec::new(),
                created_at: Utc::now(),
            })
        };
        persist_summary("t1")?;
        s.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Completed,
            Some("explorer"),
            None,
        )?;
        let follow_up = PlanTask {
            id: "t2".to_string(),
            title: "Verify follow-up".to_string(),
            description: "Verify evidence discovered by t1".to_string(),
            kind: PlanTaskKind::Verification,
            agent_role: "explorer".to_string(),
            depends_on: vec!["t1".to_string()],
            ..Default::default()
        };
        s.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "new evidence requires verification".to_string(),
                operations: vec![TaskUpdateOperation::Insert {
                    after_task_id: Some("t1".to_string()),
                    task: Box::new(follow_up.spec()),
                }],
            },
        )?;
        assert!(!s.complete_run_if_quiescent("r1")?);
        persist_summary("t2")?;
        s.set_task_status(
            "r1",
            "t2",
            echo_agent::tasks::TaskStatus::Completed,
            Some("explorer"),
            None,
        )?;
        assert!(s.complete_run_if_quiescent("r1")?);
        assert_eq!(
            s.get_run("r1")?
                .ok_or_else(|| StoreError::RunNotFound("r1".to_string()))?
                .status,
            TaskRunStatus::Completed
        );
        Ok(())
    }

    #[test]
    fn task_update_rejects_running_task_contract_change() -> Result<(), StoreError> {
        let store = fresh()?;
        seed_plan(&store)?;
        store.set_task_status(
            "r1",
            "t1",
            echo_agent::tasks::TaskStatus::Running,
            Some("subagent"),
            None,
        )?;
        let result = store.apply_task_patch_for_test(
            "r1",
            &TaskUpdateRequest {
                base_revision: 1,
                reason: "change active ownership".to_string(),
                operations: vec![TaskUpdateOperation::Update {
                    task_id: "t1".to_string(),
                    patch: Box::new(TaskPatch {
                        files: Some(vec!["src/new-owner.rs".to_string()]),
                        ..Default::default()
                    }),
                }],
            },
        );
        assert!(matches!(result, Err(StoreError::InvalidPlan(_))));
        Ok(())
    }

    // ── review #4: intent-visible tests that validation fires on the FILE
    //    authority path (not just transitively). Each asserts the error is
    //    returned AND no event line was appended — proving the file-path
    //    validation branch rejected before writing. ──────────────────────

    /// `transition_run` rejects an illegal transition on the file path and
    /// appends no event. (Completed → Running is always illegal.)
    #[test]
    fn file_path_rejects_illegal_transition_and_appends_no_event() -> Result<(), StoreError> {
        let s = fresh()?;
        s.create_run(
            "r1",
            "ws",
            "c1",
            "m1",
            DomainProfile::General,
            "g",
            "",
            AttendedMode::Attended,
        )?;
        s.transition_run("r1", TaskRunStatus::Running)?;
        s.transition_run("r1", TaskRunStatus::Completed)?;
        let before = s.list_events("r1", 0)?.len();
        let err = s
            .transition_run("r1", TaskRunStatus::Running)
            .err()
            .ok_or_else(|| {
                StoreError::InvalidPlan(
                    "illegal file transition unexpectedly succeeded".to_string(),
                )
            })?;
        assert!(matches!(err, StoreError::IllegalTransition { .. }));
        // No new event appended — the file-path validation rejected before writing.
        assert_eq!(s.list_events("r1", 0)?.len(), before);
        Ok(())
    }

    /// `task_update` rejects a dependency cycle and appends no revision event.
    #[test]
    fn file_path_rejects_dependency_cycle_and_appends_no_event() -> Result<(), StoreError> {
        let s = fresh()?;
        s.create_run(
            "r1",
            "ws",
            "c1",
            "m1",
            DomainProfile::General,
            "g",
            "",
            AttendedMode::Attended,
        )?;
        s.attach_plan_for_test(&TaskPlan {
            domain_binding: None,

            plan_id: "p1".to_string(),
            run_id: "r1".to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("g"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Parallel,
            tasks: vec![
                PlanTask {
                    id: "t1".into(),
                    depends_on: Vec::new(),
                    ..sample_task_body("t1")
                },
                PlanTask {
                    id: "t2".into(),
                    depends_on: vec!["t1".into()],
                    ..sample_task_body("t2")
                },
            ],
        })?;
        let before = s.list_events("r1", 0)?.len();
        // Now make t1 depend on t2 → cycle.
        let err = s
            .apply_task_patch_for_test(
                "r1",
                &TaskUpdateRequest {
                    base_revision: 1,
                    reason: "introduce invalid cycle".to_string(),
                    operations: vec![TaskUpdateOperation::Update {
                        task_id: "t1".to_string(),
                        patch: Box::new(TaskPatch {
                            depends_on: Some(vec!["t2".into()]),
                            ..Default::default()
                        }),
                    }],
                },
            )
            .err()
            .ok_or_else(|| {
                StoreError::InvalidPlan("dependency cycle unexpectedly succeeded".to_string())
            })?;
        assert!(matches!(err, StoreError::InvalidPlan(_)));
        assert_eq!(s.list_events("r1", 0)?.len(), before);
        Ok(())
    }

    /// `set_task_status` rejects an unknown task on the file path and appends
    /// no event.
    #[test]
    fn file_path_rejects_unknown_task_and_appends_no_event() -> Result<(), StoreError> {
        let s = fresh()?;
        seed_plan(&s)?;
        let before = s.list_events("r1", 0)?.len();
        let err = s
            .set_task_status(
                "r1",
                "nope",
                echo_agent::tasks::TaskStatus::Running,
                None,
                None,
            )
            .err()
            .ok_or_else(|| {
                StoreError::InvalidPlan("unknown task unexpectedly succeeded".to_string())
            })?;
        assert!(matches!(err, StoreError::TaskNotFound(_)));
        assert_eq!(s.list_events("r1", 0)?.len(), before);
        Ok(())
    }

    #[tokio::test]
    async fn generation_rebind_rejects_active_operation_then_isolates_roots()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let first_root = temp.path().join("first");
        let second_root = temp.path().join("second");
        let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(
            &first_root,
        )?);
        let operation = store.lease_active_workspace_generation()?;
        assert!(
            matches!(
                store.rebind_shadow_root(&second_root, "workspace-b").await,
                Err(StoreError::WorkspaceTransitionBusy {
                    active_operations: 1
                })
            ),
            "workspace transition must fail fast while a generation lease is active"
        );
        drop(operation);
        store
            .rebind_shadow_root(&second_root, "workspace-b")
            .await?;

        store.create_run_for_active_workspace(
            "run-b",
            "conversation-b",
            "message-b",
            DomainProfile::General,
            "generation isolation",
            "task",
            AttendedMode::Attended,
        )?;
        assert!(!first_root.join("run-b").exists());
        assert!(temp.path().join("second/run-b/events.jsonl").is_file());
        assert_eq!(
            store.get_run("run-b")?.map(|run| run.workspace_id),
            Some("workspace-b".to_string())
        );
        Ok(())
    }

    #[tokio::test(flavor = "current_thread")]
    async fn workspace_transition_rejects_operations_without_blocking_single_thread_runtime()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let first_root = temp.path().join("first");
        let second_root = temp.path().join("second");
        let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(
            &first_root,
        )?);
        let transition = store.begin_workspace_transition().await?;

        assert!(matches!(
            store.create_run_for_active_workspace(
                "run-b",
                "conversation-b",
                "message-b",
                DomainProfile::General,
                "generation admission",
                "task",
                AttendedMode::Attended,
            ),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));
        assert!(matches!(
            store.transition_run("run-b", TaskRunStatus::Running),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));
        assert!(matches!(
            store.set_task_status(
                "run-b",
                "task-b",
                echo_agent::tasks::TaskStatus::Running,
                None,
                None
            ),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));
        assert!(matches!(
            store.note("run-b", None, "must not reach the old root"),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));
        assert!(matches!(
            store.record_subagent_assigned(
                "run-b",
                "task-b",
                "execution-b",
                "subagent-b",
                "Task B",
                1,
                1,
                true,
                true,
            ),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));
        assert!(matches!(
            store.record_tool_started(
                "run-b",
                "task-b",
                "execution-b",
                "call-b",
                "read_file",
                true,
            ),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));
        assert!(matches!(
            store.get_run("run-b"),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));
        assert!(matches!(
            store.lease_active_workspace_generation(),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));

        transition.rebind_shadow_root(&second_root, "workspace-b")?;
        assert!(matches!(
            store.note("run-b", None, "must wait for generation publication"),
            Err(StoreError::WorkspaceTransitionBusy { .. })
        ));
        drop(transition);

        store.create_run_for_active_workspace(
            "run-b",
            "conversation-b",
            "message-b",
            DomainProfile::General,
            "generation admission",
            "task",
            AttendedMode::Attended,
        )?;

        assert!(!first_root.join("run-b").exists());
        assert!(second_root.join("run-b/events.jsonl").is_file());
        assert_eq!(store.active_workspace_id(), "workspace-b");
        Ok(())
    }

    #[tokio::test]
    async fn failed_generation_rebind_keeps_previous_root_and_identity()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let first_root = temp.path().join("first");
        let invalid_root = temp.path().join("not-a-directory");
        std::fs::write(&invalid_root, "file")?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&first_root)?;

        assert!(
            store
                .rebind_shadow_root(&invalid_root, "workspace-b")
                .await
                .is_err()
        );
        assert_eq!(store.active_workspace_id(), "test");
        store.create_run_for_active_workspace(
            "run-a",
            "conversation-a",
            "message-a",
            DomainProfile::General,
            "failed rebind",
            "task",
            AttendedMode::Attended,
        )?;
        assert!(first_root.join("run-a/events.jsonl").is_file());
        assert_eq!(
            store.get_run("run-a")?.map(|run| run.workspace_id),
            Some("test".to_string())
        );
        Ok(())
    }

    #[test]
    fn conversation_removal_deletes_only_its_task_runs() -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))?;
        for (run_id, conversation_id) in [
            ("conversation-run-a", "conversation-delete"),
            ("conversation-run-b", "conversation-delete"),
            ("retained-run", "conversation-keep"),
        ] {
            store.create_run(
                run_id,
                "workspace",
                conversation_id,
                "message",
                DomainProfile::General,
                run_id,
                "chat",
                AttendedMode::Attended,
            )?;
        }

        store.remove_conversation("conversation-delete")?;

        assert!(store.get_run("conversation-run-a")?.is_none());
        assert!(store.get_run("conversation-run-b")?.is_none());
        assert!(store.get_run("retained-run")?.is_some());
        assert!(
            store
                .list_runs_for_conversation("conversation-delete")?
                .is_empty()
        );
        Ok(())
    }

    #[test]
    fn degraded_conversation_delete_clears_local_state_before_same_id_recreate()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))?;
        store.create_run(
            "degraded-delete",
            "workspace",
            "conversation-delete",
            "message",
            DomainProfile::General,
            "degraded delete",
            "chat",
            AttendedMode::Attended,
        )?;
        store
            .task_cancel_tokens
            .lock()
            .map_err(|_| "task token lock poisoned")?
            .insert(
                "degraded-delete::task".to_string(),
                echo_agent::agent::CancellationToken::new(),
            );
        assert!(store.plan_locks.contains_key("degraded-delete"));
        store.shadow.fail_root_sync_on_call_for_test(2);
        assert!(matches!(
            store.remove_conversation("conversation-delete"),
            Err(StoreError::Shadow(
                super::super::file_shadow::ShadowError::CommittedDeletionDegraded { .. }
            ))
        ));
        assert!(!store.plan_locks.contains_key("degraded-delete"));
        assert!(
            !store
                .task_cancel_tokens
                .lock()
                .map_err(|_| "task token lock poisoned")?
                .contains_key("degraded-delete::task")
        );
        assert!(store.get_run("degraded-delete")?.is_none());
        let recreated = store.create_run(
            "degraded-delete",
            "workspace",
            "conversation-new",
            "message-new",
            DomainProfile::General,
            "recreated",
            "chat",
            AttendedMode::Attended,
        )?;
        assert_eq!(recreated.conversation_id, "conversation-new");
        Ok(())
    }

    #[test]
    fn conversation_removal_fails_closed_while_a_driver_is_active()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let store = std::sync::Arc::new(TaskRuntimeStore::new_in_memory_with_shadow_root(
            temp.path().join("tasks"),
        )?);
        store.create_run(
            "active-delete-run",
            "workspace",
            "conversation-delete",
            "message",
            DomainProfile::General,
            "active run",
            "chat",
            AttendedMode::Attended,
        )?;
        let registration = store.register_run_cancellation(
            "active-delete-run",
            echo_agent::agent::CancellationToken::new(),
        )?;

        assert!(matches!(
            store.remove_conversation("conversation-delete"),
            Err(StoreError::ConversationHasActiveRuns { .. })
        ));
        assert!(store.get_run("active-delete-run")?.is_some());
        drop(registration);
        store.remove_conversation("conversation-delete")?;
        assert!(store.get_run("active-delete-run")?.is_none());
        Ok(())
    }

    #[test]
    fn checkpoint_state_is_canonical_byte_equivalent_to_full_replay_and_repairs_corruption()
    -> Result<(), String> {
        let (temp, store, run_id) = seed_public_state_fixture(256)?;
        let events = store
            .list_events(&run_id, 0)
            .map_err(|error| error.to_string())?;
        let journal_sequence = events
            .last()
            .and_then(|event| u64::try_from(event.seq).ok())
            .ok_or_else(|| "full replay sequence is unavailable".to_string())?;
        let full = super::super::event_rebuild::fold_fixture_for_test(&events)
            .map_err(|error| error.to_string())?
            .run_state_with_sequence(journal_sequence);
        let warm = store
            .get_run_state(&run_id)
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "checkpoint-backed state is missing".to_string())?;
        let full_bytes = echo_agent::utils::canonical_json::canonical_json_bytes(&full)
            .map_err(|error| error.to_string())?;
        let warm_bytes = echo_agent::utils::canonical_json::canonical_json_bytes(&warm)
            .map_err(|error| error.to_string())?;
        assert_eq!(warm_bytes, full_bytes);

        let checkpoint_path = temp
            .path()
            .join("tasks")
            .join(&run_id)
            .join("checkpoint.json");
        std::fs::write(&checkpoint_path, b"{corrupt checkpoint")
            .map_err(|error| error.to_string())?;
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        let repaired = reopened
            .get_run_state(&run_id)
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "repaired state is missing".to_string())?;
        let repaired_bytes = echo_agent::utils::canonical_json::canonical_json_bytes(&repaired)
            .map_err(|error| error.to_string())?;
        assert_eq!(repaired_bytes, full_bytes);
        use echo_agent::state::journal::{CheckpointStore, FileCheckpointStore};
        let decoded = FileCheckpointStore::<serde_json::Value>::open(&checkpoint_path)
            .load()
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "repaired checkpoint is missing".to_string())?;
        assert_eq!(decoded.sequence, 256);
        assert!(decoded.state.is_object());
        Ok(())
    }

    #[test]
    #[ignore = "LH5 release performance gate; run with --release --ignored --nocapture"]
    fn performance_public_get_run_state_10k_100k_release_gate() -> Result<(), String> {
        if cfg!(debug_assertions) {
            return Err("LH5 performance gate must run with --release".to_string());
        }
        let (_ten_temp, ten_store, ten_run) = seed_public_state_fixture(10_000)?;
        let (hundred_temp, hundred_store, hundred_run) = seed_public_state_fixture(100_000)?;

        let mut ten_samples = Vec::with_capacity(5);
        let mut hundred_samples = Vec::with_capacity(5);
        for _ in 0..5 {
            let started = std::time::Instant::now();
            assert!(
                ten_store
                    .get_run_state(&ten_run)
                    .map_err(|error| error.to_string())?
                    .is_some()
            );
            ten_samples.push(started.elapsed());

            let started = std::time::Instant::now();
            assert!(
                hundred_store
                    .get_run_state(&hundred_run)
                    .map_err(|error| error.to_string())?
                    .is_some()
            );
            hundred_samples.push(started.elapsed());
        }
        let ten_median = median_duration(&mut ten_samples)
            .ok_or_else(|| "10k sample set is empty".to_string())?;
        let hundred_median = median_duration(&mut hundred_samples)
            .ok_or_else(|| "100k sample set is empty".to_string())?;
        let ten_worst = ten_samples.iter().copied().max().unwrap_or_default();
        let hundred_worst = hundred_samples.iter().copied().max().unwrap_or_default();

        let append_started = std::time::Instant::now();
        hundred_store
            .note(&hundred_run, None, "one appended public state event")
            .map_err(|error| error.to_string())?;
        assert!(
            hundred_store
                .get_run_state(&hundred_run)
                .map_err(|error| error.to_string())?
                .is_some()
        );
        let append_read = append_started.elapsed();

        let checkpoint_path = hundred_temp
            .path()
            .join("tasks")
            .join(&hundred_run)
            .join("checkpoint.json");
        let events_path = hundred_temp
            .path()
            .join("tasks")
            .join(&hundred_run)
            .join("events.jsonl");
        drop(hundred_store);
        std::fs::write(&checkpoint_path, b"{corrupt checkpoint")
            .map_err(|error| error.to_string())?;
        let hundred_store =
            TaskRuntimeStore::new_in_memory_with_shadow_root(hundred_temp.path().join("tasks"))
                .map_err(|error| error.to_string())?;
        let rebuild_started = std::time::Instant::now();
        assert!(
            hundred_store
                .get_run_state(&hundred_run)
                .map_err(|error| error.to_string())?
                .is_some()
        );
        let corrupt_rebuild = rebuild_started.elapsed();
        let warm_started = std::time::Instant::now();
        assert!(
            hundred_store
                .get_run_state(&hundred_run)
                .map_err(|error| error.to_string())?
                .is_some()
        );
        let repaired_warm = warm_started.elapsed();
        let checkpoint_bytes = std::fs::metadata(&checkpoint_path)
            .map_err(|error| error.to_string())?
            .len();
        let event_bytes = std::fs::metadata(&events_path)
            .map_err(|error| error.to_string())?
            .len();

        println!(
            "{}",
            serde_json::json!({
                "ten_k_median_ms": ten_median.as_secs_f64() * 1_000.0,
                "ten_k_worst_ms": ten_worst.as_secs_f64() * 1_000.0,
                "hundred_k_median_ms": hundred_median.as_secs_f64() * 1_000.0,
                "hundred_k_worst_ms": hundred_worst.as_secs_f64() * 1_000.0,
                "append_read_ms": append_read.as_secs_f64() * 1_000.0,
                "corrupt_rebuild_ms": corrupt_rebuild.as_secs_f64() * 1_000.0,
                "repaired_warm_ms": repaired_warm.as_secs_f64() * 1_000.0,
                "checkpoint_bytes": checkpoint_bytes,
                "event_bytes": event_bytes,
            })
        );
        assert!(ten_median <= std::time::Duration::from_millis(2));
        assert!(hundred_median <= std::time::Duration::from_millis(2));
        assert!(hundred_median.as_nanos() <= ten_median.as_nanos().saturating_mul(2).max(1));
        assert!(append_read <= std::time::Duration::from_millis(50));
        assert!(corrupt_rebuild <= std::time::Duration::from_secs(5));
        assert!(repaired_warm <= std::time::Duration::from_millis(2));
        assert!(checkpoint_bytes <= 256 * 1024);
        assert!(checkpoint_bytes.saturating_mul(20) < event_bytes);
        Ok(())
    }

    #[test]
    #[ignore = "final 10k/100k scale gate; run explicitly after the refactor"]
    fn production_todo_artifact_review_summary_completion_queries_are_bounded_at_10k_and_100k()
    -> Result<(), String> {
        let (_ten_temp, ten_store, ten_run) = seed_public_query_fixture(10_000)?;
        let (_hundred_temp, hundred_store, hundred_run) = seed_public_query_fixture(100_000)?;
        let mut ten_samples = Vec::with_capacity(5);
        let mut hundred_samples = Vec::with_capacity(5);
        for _ in 0..5 {
            ten_samples.push(time_public_queries(&ten_store, &ten_run)?);
            hundred_samples.push(time_public_queries(&hundred_store, &hundred_run)?);
        }
        let ten_median = median_duration(&mut ten_samples)
            .ok_or_else(|| "10k query sample set is empty".to_string())?;
        let hundred_median = median_duration(&mut hundred_samples)
            .ok_or_else(|| "100k query sample set is empty".to_string())?;
        let ratio_budget = ten_median
            .saturating_mul(4)
            .max(std::time::Duration::from_millis(25));
        assert!(hundred_median <= std::time::Duration::from_millis(200));
        assert!(hundred_median <= ratio_budget);
        Ok(())
    }

    /// FINAL performance gate for artifact and per-task review history.
    ///
    /// Run explicitly with:
    /// `cargo test -p echo-agent-app-core artifact_and_per_task_review_history_scale_at_10k_and_100k --lib --release -- --ignored --nocapture`
    #[test]
    #[ignore = "final 10k/100k performance gate; run explicitly with --release --ignored --nocapture"]
    fn artifact_and_per_task_review_history_scale_at_10k_and_100k() -> Result<(), String> {
        let (_ten_temp, ten_store, ten_run, ten_first, ten_second) =
            seed_history_scale_fixture(10_000)?;
        let (hundred_temp, hundred_store, hundred_run, hundred_first, hundred_second) =
            seed_history_scale_fixture(100_000)?;
        let (
            _ten_artifact_temp,
            _ten_artifact_store,
            _ten_artifact_run,
            ten_artifact_first,
            ten_artifact_second,
            ten_artifact_scans,
            _,
        ) = seed_artifact_scale_fixture(10_000)?;
        let (
            hundred_artifact_temp,
            hundred_artifact_store,
            hundred_artifact_run,
            hundred_artifact_first,
            hundred_artifact_second,
            hundred_artifact_scans,
            hundred_artifact_appended_bytes,
        ) = seed_artifact_scale_fixture(100_000)?;

        let mut ten_queries = Vec::with_capacity(5);
        let mut hundred_queries = Vec::with_capacity(5);
        for _ in 0..5 {
            ten_queries.push(time_history_target_queries(&ten_store, &ten_run)?);
            hundred_queries.push(time_history_target_queries(&hundred_store, &hundred_run)?);
        }
        let ten_query = median_duration(&mut ten_queries)
            .ok_or_else(|| "10k history query samples are empty".to_string())?;
        let hundred_query = median_duration(&mut hundred_queries)
            .ok_or_else(|| "100k history query samples are empty".to_string())?;
        assert_eq!(
            hundred_store
                .list_reviews(&hundred_run, "other-task")
                .map_err(|error| error.to_string())?
                .len(),
            100_000
        );
        let artifact_query_started = std::time::Instant::now();
        assert_eq!(
            hundred_artifact_store
                .list_artifacts(&hundred_artifact_run)
                .map_err(|error| error.to_string())?
                .len(),
            100_000
        );
        let hundred_artifact_query = artifact_query_started.elapsed();

        let (artifact_path, target_review_path, _) = hundred_store
            .shadow
            .history_paths_for_test(&hundred_run, "target-task")
            .map_err(|error| error.to_string())?;
        let (_, other_review_path, _) = hundred_store
            .shadow
            .history_paths_for_test(&hundred_run, "other-task")
            .map_err(|error| error.to_string())?;
        let checkpoint_path = hundred_temp
            .path()
            .join("tasks")
            .join(&hundred_run)
            .join("checkpoint.json");
        let artifact_bytes = std::fs::metadata(&artifact_path)
            .map_err(|error| error.to_string())?
            .len();
        let target_review_bytes = std::fs::metadata(&target_review_path)
            .map_err(|error| error.to_string())?
            .len();
        let other_review_bytes = std::fs::metadata(&other_review_path)
            .map_err(|error| error.to_string())?
            .len();
        let checkpoint_bytes = std::fs::metadata(&checkpoint_path)
            .map_err(|error| error.to_string())?
            .len();
        let (hundred_artifact_path, _, _) = hundred_artifact_store
            .shadow
            .history_paths_for_test(&hundred_artifact_run, "target-task")
            .map_err(|error| error.to_string())?;
        let hundred_artifact_segment_bytes = std::fs::metadata(&hundred_artifact_path)
            .map_err(|error| error.to_string())?
            .len();
        println!(
            "{}",
            serde_json::json!({
                "ten_k_append_first_half_median_ms": ten_first.as_secs_f64() * 1_000.0,
                "ten_k_append_second_half_median_ms": ten_second.as_secs_f64() * 1_000.0,
                "hundred_k_append_first_half_median_ms": hundred_first.as_secs_f64() * 1_000.0,
                "hundred_k_append_second_half_median_ms": hundred_second.as_secs_f64() * 1_000.0,
                "ten_k_artifact_append_first_half_median_ms": ten_artifact_first.as_secs_f64() * 1_000.0,
                "ten_k_artifact_append_second_half_median_ms": ten_artifact_second.as_secs_f64() * 1_000.0,
                "hundred_k_artifact_append_first_half_median_ms": hundred_artifact_first.as_secs_f64() * 1_000.0,
                "hundred_k_artifact_append_second_half_median_ms": hundred_artifact_second.as_secs_f64() * 1_000.0,
                "ten_k_target_query_median_ms": ten_query.as_secs_f64() * 1_000.0,
                "hundred_k_target_query_median_ms": hundred_query.as_secs_f64() * 1_000.0,
                "hundred_k_artifact_query_ms": hundred_artifact_query.as_secs_f64() * 1_000.0,
                "ten_k_artifact_segment_scans": ten_artifact_scans,
                "hundred_k_artifact_segment_scans": hundred_artifact_scans,
                "artifact_segment_bytes": artifact_bytes,
                "hundred_k_artifact_segment_bytes": hundred_artifact_segment_bytes,
                "hundred_k_artifact_appended_bytes": hundred_artifact_appended_bytes,
                "target_review_segment_bytes": target_review_bytes,
                "other_review_segment_bytes": other_review_bytes,
                "hot_checkpoint_bytes": checkpoint_bytes,
            })
        );
        assert!(artifact_bytes <= 64 * 1024);
        assert!(target_review_bytes <= 64 * 1024);
        assert!(other_review_bytes > target_review_bytes);
        assert!(checkpoint_bytes <= 256 * 1024);
        assert!(ten_artifact_scans <= 1);
        assert!(hundred_artifact_scans <= 1);
        assert_eq!(
            hundred_artifact_segment_bytes,
            hundred_artifact_appended_bytes
        );
        assert!(
            ten_second
                <= ten_first
                    .saturating_mul(4)
                    .max(std::time::Duration::from_millis(250))
        );
        assert!(
            hundred_second
                <= hundred_first
                    .saturating_mul(4)
                    .max(std::time::Duration::from_millis(250))
        );
        assert!(hundred_second <= std::time::Duration::from_secs(2));
        assert!(
            hundred_second
                <= ten_second
                    .saturating_mul(4)
                    .max(std::time::Duration::from_millis(250))
        );
        assert!(
            hundred_artifact_second
                <= hundred_artifact_first
                    .saturating_mul(4)
                    .max(std::time::Duration::from_millis(250))
        );
        assert!(
            hundred_artifact_second
                <= ten_artifact_second
                    .saturating_mul(4)
                    .max(std::time::Duration::from_millis(250))
        );
        assert!(hundred_artifact_second <= std::time::Duration::from_secs(2));
        assert!(hundred_artifact_query <= std::time::Duration::from_secs(2));
        assert!(hundred_query <= std::time::Duration::from_millis(250));
        assert!(
            hundred_query
                <= ten_query
                    .saturating_mul(4)
                    .max(std::time::Duration::from_millis(50))
        );

        drop(hundred_store);
        let reopened =
            TaskRuntimeStore::new_in_memory_with_shadow_root(hundred_temp.path().join("tasks"))
                .map_err(|error| error.to_string())?;
        time_history_target_queries(&reopened, &hundred_run)?;
        assert_eq!(
            reopened
                .list_reviews(&hundred_run, "other-task")
                .map_err(|error| error.to_string())?
                .len(),
            100_000
        );
        drop(hundred_artifact_store);
        let reopened_artifacts = TaskRuntimeStore::new_in_memory_with_shadow_root(
            hundred_artifact_temp.path().join("tasks"),
        )
        .map_err(|error| error.to_string())?;
        assert_eq!(
            reopened_artifacts
                .list_artifacts(&hundred_artifact_run)
                .map_err(|error| error.to_string())?
                .len(),
            100_000
        );
        Ok(())
    }

    #[test]
    #[ignore = "final 2k/10k scale characterization; run explicitly after the refactor"]
    fn artifact_and_per_task_review_history_characterization_at_2k_and_10k() -> Result<(), String> {
        let (small_temp, small_store, small_run, _, _) = seed_history_scale_fixture(2_000)?;
        let (large_temp, large_store, large_run, _, _) = seed_history_scale_fixture(10_000)?;

        for (store, run_id, expected_reviews) in [
            (&small_store, &small_run, 2_000_usize),
            (&large_store, &large_run, 10_000_usize),
        ] {
            let target_query = time_history_target_queries(store, run_id)?;
            assert!(
                target_query <= std::time::Duration::from_millis(250),
                "targeted history query exceeded daily characterization budget: {target_query:?}"
            );
            assert_eq!(
                store
                    .list_reviews(run_id, "other-task")
                    .map_err(|error| error.to_string())?
                    .len(),
                expected_reviews
            );
            assert_eq!(
                store
                    .list_artifacts(run_id)
                    .map_err(|error| error.to_string())?
                    .len(),
                1
            );
            let (artifact_path, target_review_path, _) = store
                .shadow
                .history_paths_for_test(run_id, "target-task")
                .map_err(|error| error.to_string())?;
            assert!(
                std::fs::metadata(&artifact_path)
                    .map_err(|error| error.to_string())?
                    .len()
                    <= 64 * 1024
            );
            assert!(
                std::fs::metadata(&target_review_path)
                    .map_err(|error| error.to_string())?
                    .len()
                    <= 64 * 1024
            );
        }

        drop(large_store);
        let restarted =
            TaskRuntimeStore::new_in_memory_with_shadow_root(large_temp.path().join("tasks"))
                .map_err(|error| error.to_string())?;
        assert_eq!(
            restarted
                .list_reviews(&large_run, "other-task")
                .map_err(|error| error.to_string())?
                .len(),
            10_000
        );
        assert_eq!(
            restarted
                .list_reviews(&large_run, "target-task")
                .map_err(|error| error.to_string())?
                .len(),
            1
        );
        assert_eq!(
            restarted
                .list_artifacts(&large_run)
                .map_err(|error| error.to_string())?
                .len(),
            1
        );
        time_history_target_queries(&restarted, &large_run)?;
        drop(small_store);
        drop(small_temp);
        Ok(())
    }

    #[test]
    fn query_checkpoint_corruption_self_heals_and_restart_preserves_results() -> Result<(), String>
    {
        let (temp, store, run_id) = seed_public_query_fixture(10_000)?;
        time_public_queries(&store, &run_id)?;
        let checkpoint_path = temp
            .path()
            .join("tasks")
            .join(&run_id)
            .join("checkpoint.json");
        drop(store);
        std::fs::write(&checkpoint_path, b"{corrupt checkpoint")
            .map_err(|error| error.to_string())?;
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        time_public_queries(&reopened, &run_id)?;
        let repaired: serde_json::Value = serde_json::from_slice(
            &std::fs::read(&checkpoint_path).map_err(|error| error.to_string())?,
        )
        .map_err(|error| error.to_string())?;
        assert_eq!(
            repaired
                .get("state")
                .and_then(|state| state.get("query_projection_schema"))
                .and_then(serde_json::Value::as_u64),
            Some(5)
        );
        drop(reopened);
        let restarted = TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        time_public_queries(&restarted, &run_id)?;
        Ok(())
    }

    #[test]
    fn behind_checkpoint_is_repaired_once_on_query_only_restart() -> Result<(), String> {
        use echo_agent::state::journal::{CheckpointStore, FileCheckpointStore};

        let (temp, store, run_id) = seed_public_query_fixture(1_000)?;
        let checkpoint_path = temp
            .path()
            .join("tasks")
            .join(&run_id)
            .join("checkpoint.json");
        let receipt = store
            .shadow
            .append_event_batch(
                &run_id,
                vec![RuntimeJournalEvent::for_append(
                    &run_id,
                    None,
                    None,
                    RuntimeEventKind::Note,
                    serde_json::json!({"kind": "checkpoint_suffix"}),
                )],
            )
            .map_err(|error| error.to_string())?;
        let head = receipt.apply.last_sequence;
        let checkpoints = FileCheckpointStore::<super::super::event_rebuild::EventFoldState>::open(
            &checkpoint_path,
        );
        let before = checkpoints
            .load()
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "checkpoint before restart is missing".to_string())?;
        assert!(before.sequence < head);
        drop(store);

        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        time_public_queries(&reopened, &run_id)?;
        drop(reopened);
        let repaired = checkpoints
            .load()
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "repaired checkpoint is missing".to_string())?;
        assert_eq!(repaired.sequence, head);

        let restarted = TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        let stats = restarted
            .shadow
            .rewrite_plan_with_stats(&run_id)
            .map_err(|error| error.to_string())?;
        assert!(stats.used_checkpoint);
        assert_eq!(stats.folded_events, 0);
        Ok(())
    }

    #[test]
    fn full_history_rebuild_removes_stale_review_segments() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        seed_history_plan(&store, "stale-history")?;
        store
            .add_review(&history_review("stale-history", "target-task", "review-1"))
            .map_err(|error| error.to_string())?;
        let (_, review_path, cursor_path) = store
            .shadow
            .history_paths_for_test("stale-history", "target-task")
            .map_err(|error| error.to_string())?;
        let review_directory = review_path
            .parent()
            .ok_or_else(|| "review history has no directory".to_string())?
            .to_path_buf();
        drop(store);
        let stale_path = review_directory.join("stale-valid-segment.jsonl");
        std::fs::write(&stale_path, b"{}\n").map_err(|error| error.to_string())?;
        std::fs::remove_file(cursor_path).map_err(|error| error.to_string())?;

        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        assert_eq!(
            reopened
                .list_reviews("stale-history", "target-task")
                .map_err(|error| error.to_string())?
                .len(),
            1
        );
        assert!(!stale_path.exists());
        Ok(())
    }

    #[test]
    fn legacy_query_checkpoint_schema_rebuilds_before_production_read() -> Result<(), String> {
        use echo_agent::state::journal::{CheckpointStore, FileCheckpointStore};

        let (temp, store, run_id) = seed_public_query_fixture(1_000)?;
        let checkpoint_path = temp
            .path()
            .join("tasks")
            .join(&run_id)
            .join("checkpoint.json");
        drop(store);
        let checkpoints = FileCheckpointStore::<super::super::event_rebuild::EventFoldState>::open(
            &checkpoint_path,
        );
        let mut legacy = checkpoints
            .load()
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "query checkpoint is missing".to_string())?;
        legacy.state.clear_query_projection_schema_for_test();
        checkpoints
            .save(&legacy.journal_identity, &legacy.state, legacy.sequence)
            .map_err(|error| error.to_string())?;
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))
            .map_err(|error| error.to_string())?;
        time_public_queries(&reopened, &run_id)?;
        drop(reopened);
        let repaired = checkpoints
            .load()
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "repaired query checkpoint is missing".to_string())?;
        assert!(repaired.state.has_current_query_projection_schema());
        Ok(())
    }

    #[cfg(unix)]
    #[test]
    fn readonly_legacy_checkpoint_does_not_block_journal_derived_queries() -> Result<(), String> {
        use echo_agent::state::journal::{CheckpointStore, FileCheckpointStore};
        use std::os::unix::fs::PermissionsExt;

        let (temp, store, run_id) = seed_public_query_fixture(1_000)?;
        let run_directory = temp.path().join("tasks").join(&run_id);
        let checkpoint_path = run_directory.join("checkpoint.json");
        let (artifact_history, review_history, _) = store
            .shadow
            .history_paths_for_test(&run_id, "task-a")
            .map_err(|error| error.to_string())?;
        drop(store);
        let checkpoints = FileCheckpointStore::<super::super::event_rebuild::EventFoldState>::open(
            &checkpoint_path,
        );
        let mut legacy = checkpoints
            .load()
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "query checkpoint is missing".to_string())?;
        legacy.state.clear_query_projection_schema_for_test();
        checkpoints
            .save(&legacy.journal_identity, &legacy.state, legacy.sequence)
            .map_err(|error| error.to_string())?;
        std::fs::remove_file(artifact_history).map_err(|error| error.to_string())?;
        std::fs::remove_file(review_history).map_err(|error| error.to_string())?;
        let original_permissions = std::fs::metadata(&run_directory)
            .map_err(|error| error.to_string())?
            .permissions();
        let mut readonly = original_permissions.clone();
        readonly.set_mode(0o555);
        std::fs::set_permissions(&run_directory, readonly).map_err(|error| error.to_string())?;
        let query = (|| {
            let reopened =
                TaskRuntimeStore::new_in_memory_with_shadow_root(temp.path().join("tasks"))
                    .map_err(|error| error.to_string())?;
            time_public_queries(&reopened, &run_id)?;
            let first_replays = reopened
                .shadow
                .history_fallback_replay_count_for_test(&run_id)
                .map_err(|error| error.to_string())?;
            time_public_queries(&reopened, &run_id)?;
            let second_replays = reopened
                .shadow
                .history_fallback_replay_count_for_test(&run_id)
                .map_err(|error| error.to_string())?;
            if first_replays != second_replays {
                return Err("readonly history fallback was replayed on every query".to_string());
            }
            Ok(())
        })();
        std::fs::set_permissions(&run_directory, original_permissions)
            .map_err(|error| error.to_string())?;
        query?;
        Ok(())
    }

    #[cfg(unix)]
    #[test]
    fn readonly_review_fallback_lru_avoids_aba_full_replay() -> Result<(), String> {
        use std::os::unix::fs::PermissionsExt;

        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        seed_history_plan(&store, "readonly-lru")?;
        store
            .add_review(&history_review(
                "readonly-lru",
                "target-task",
                "target-review",
            ))
            .map_err(|error| error.to_string())?;
        store
            .add_review(&history_review(
                "readonly-lru",
                "other-task",
                "other-review",
            ))
            .map_err(|error| error.to_string())?;
        let (_, target_path, _) = store
            .shadow
            .history_paths_for_test("readonly-lru", "target-task")
            .map_err(|error| error.to_string())?;
        let (_, other_path, _) = store
            .shadow
            .history_paths_for_test("readonly-lru", "other-task")
            .map_err(|error| error.to_string())?;
        let review_directory = target_path
            .parent()
            .ok_or_else(|| "review segment has no directory".to_string())?
            .to_path_buf();
        drop(store);
        std::fs::remove_file(target_path).map_err(|error| error.to_string())?;
        std::fs::remove_file(other_path).map_err(|error| error.to_string())?;
        let original_permissions = std::fs::metadata(&review_directory)
            .map_err(|error| error.to_string())?
            .permissions();
        let mut readonly = original_permissions.clone();
        readonly.set_mode(0o555);
        std::fs::set_permissions(&review_directory, readonly).map_err(|error| error.to_string())?;
        let query = (|| {
            let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
                .map_err(|error| error.to_string())?;
            for task_id in ["target-task", "other-task", "target-task"] {
                if reopened
                    .list_reviews("readonly-lru", task_id)
                    .map_err(|error| error.to_string())?
                    .len()
                    != 1
                {
                    return Err(format!("readonly review fallback lost task {task_id}"));
                }
            }
            let replays = reopened
                .shadow
                .history_fallback_replay_count_for_test("readonly-lru")
                .map_err(|error| error.to_string())?;
            if replays != 2 {
                return Err(format!(
                    "readonly A/B/A review fallback replayed {replays} times"
                ));
            }
            Ok(())
        })();
        std::fs::set_permissions(&review_directory, original_permissions)
            .map_err(|error| error.to_string())?;
        query
    }

    #[test]
    fn todo_metadata_clears_across_revision_reset_running_and_restart() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        store
            .create_run(
                "reset-run",
                "test",
                "conversation",
                "root",
                DomainProfile::General,
                "reset metadata",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        let mut plan = TaskPlan {
            domain_binding: None,

            plan_id: "reset-plan".to_string(),
            run_id: "reset-run".to_string(),
            revision: 1,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("reset metadata"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: "reset-task".to_string(),
                title: "Reset task".to_string(),
                description: "Verify metadata reset".to_string(),
                kind: PlanTaskKind::Investigation,
                agent_role: "old-owner".to_string(),
                domain_profile: DomainProfile::General,
                ..Default::default()
            }],
        };
        store
            .attach_plan_for_test(&plan)
            .map_err(|error| error.to_string())?;
        store
            .set_task_status(
                "reset-run",
                "reset-task",
                echo_agent::tasks::TaskStatus::Completed,
                Some("old-owner"),
                Some("old-summary"),
            )
            .map_err(|error| error.to_string())?;
        plan.revision = 2;
        store
            .commit_runtime_event(RuntimeJournalEvent::for_append(
                "reset-run",
                None,
                None,
                RuntimeEventKind::PlanRevisionCommitted,
                serde_json::json!({
                    "base_revision": 1,
                    "reason": "reset completed task",
                    "reset_task_ids": ["reset-task"],
                    "plan": plan.specification(),
                }),
            ))
            .map_err(|error| error.to_string())?;
        let pending = store
            .list_todos("reset-run")
            .map_err(|error| error.to_string())?
            .into_iter()
            .next()
            .ok_or_else(|| "reset Todo is missing".to_string())?;
        assert_eq!(pending.status, TodoStatus::Pending);
        assert!(pending.owner_agent.is_none());
        assert!(pending.started_at.is_none());
        assert!(pending.completed_at.is_none());
        assert!(pending.summary.is_none());
        store
            .set_task_status(
                "reset-run",
                "reset-task",
                echo_agent::tasks::TaskStatus::Running,
                Some("new-owner"),
                None,
            )
            .map_err(|error| error.to_string())?;
        let running = store
            .list_todos("reset-run")
            .map_err(|error| error.to_string())?
            .into_iter()
            .next()
            .ok_or_else(|| "running Todo is missing".to_string())?;
        assert_eq!(running.status, TodoStatus::Running);
        assert_eq!(running.owner_agent.as_deref(), Some("new-owner"));
        assert!(running.started_at.is_some());
        assert!(running.completed_at.is_none());
        assert!(running.summary.is_none());
        drop(store);
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        let restarted = reopened
            .list_todos("reset-run")
            .map_err(|error| error.to_string())?
            .into_iter()
            .next()
            .ok_or_else(|| "restarted Todo is missing".to_string())?;
        assert_eq!(restarted.status, TodoStatus::Running);
        assert_eq!(restarted.owner_agent.as_deref(), Some("new-owner"));
        assert!(restarted.completed_at.is_none());
        assert!(restarted.summary.is_none());
        Ok(())
    }

    #[test]
    fn concurrent_public_queries_remain_coherent_with_incremental_appends() -> Result<(), String> {
        let (_temp, store, run_id) = seed_public_query_fixture(10_000)?;
        let store = std::sync::Arc::new(store);
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(5));
        let mut readers = Vec::new();
        for _ in 0..4 {
            let reader_store = std::sync::Arc::clone(&store);
            let reader_run = run_id.clone();
            let reader_barrier = std::sync::Arc::clone(&barrier);
            readers.push(std::thread::spawn(move || -> Result<(), String> {
                reader_barrier.wait();
                for _ in 0..25 {
                    time_public_queries(&reader_store, &reader_run)?;
                }
                Ok(())
            }));
        }
        barrier.wait();
        for ordinal in 0..25 {
            store
                .note(&run_id, None, &format!("concurrent append {ordinal}"))
                .map_err(|error| error.to_string())?;
        }
        for reader in readers {
            reader
                .join()
                .map_err(|_| "public query reader panicked".to_string())??;
        }
        time_public_queries(&store, &run_id)?;
        Ok(())
    }

    #[test]
    fn projection_receipt_distinguishes_uncommitted_and_committed_degradation() -> Result<(), String>
    {
        let store = fresh().map_err(|error| error.to_string())?;
        store
            .create_run(
                "receipt-run",
                "test",
                "conversation",
                "root",
                DomainProfile::General,
                "receipt",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        let before = store
            .list_events("receipt-run", 0)
            .map_err(|error| error.to_string())?
            .len();
        store.fail_next_cell_started_for_test();
        let uncommitted = store.record_background_cell_started(
            "receipt-run",
            "cell-uncommitted",
            "false",
            "hash-a",
            None,
            None,
            None,
        );
        assert!(uncommitted.is_err());
        assert_eq!(
            store
                .list_events("receipt-run", 0)
                .map_err(|error| error.to_string())?
                .len(),
            before
        );
        store.fail_next_cell_started_projection_for_test();
        let committed = store
            .record_background_cell_started(
                "receipt-run",
                "cell-committed",
                "true",
                "hash-b",
                None,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        let ProjectionCommitReceipt::CommittedProjectionDegraded { seq, .. } = committed else {
            return Err("committed projection degradation lost its typed receipt".to_string());
        };
        assert!(seq > 0);
        assert_eq!(
            store
                .list_events("receipt-run", 0)
                .map_err(|error| error.to_string())?
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::BackgroundCellStarted)
                .count(),
            1
        );
        Ok(())
    }

    #[test]
    fn durability_receipt_preserves_batch_cell_and_reconciled_degradation() -> Result<(), String> {
        let store = fresh().map_err(|error| error.to_string())?;
        store
            .create_run(
                "durability-run",
                "test",
                "conversation",
                "root",
                DomainProfile::General,
                "durability",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;

        store
            .shadow
            .fail_next_append_durability_for_test("durability-run")
            .map_err(|error| error.to_string())?;
        let degraded = store
            .commit_runtime_events_with_receipt(
                "durability-run",
                vec![RuntimeJournalEvent::for_append(
                    "durability-run",
                    None,
                    None,
                    RuntimeEventKind::Note,
                    serde_json::json!({"kind": "durability-batch"}),
                )],
            )
            .map_err(|error| error.to_string())?;
        let ProjectionCommitReceipt::CommittedProjectionDegraded { seq, detail } = degraded else {
            return Err("degraded journal batch was reported durable".to_string());
        };
        assert!(seq > 0);
        assert!(detail.contains("journal durability degraded"));

        store
            .shadow
            .reconcile_next_append_unconfirmed_for_test("durability-run")
            .map_err(|error| error.to_string())?;
        let reconciled = store
            .commit_runtime_events_with_receipt(
                "durability-run",
                vec![RuntimeJournalEvent::for_append(
                    "durability-run",
                    None,
                    None,
                    RuntimeEventKind::Note,
                    serde_json::json!({"kind": "reconciled-batch"}),
                )],
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            reconciled,
            ProjectionCommitReceipt::CommittedProjectionDegraded { detail, .. }
                if detail.contains("journal durability unconfirmed")
        ));

        store
            .shadow
            .fail_next_append_durability_for_test("durability-run")
            .map_err(|error| error.to_string())?;
        let first = store
            .record_background_cell_started(
                "durability-run",
                "cell-durable",
                "command",
                "hash",
                None,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            first,
            ProjectionCommitReceipt::CommittedProjectionDegraded { detail, .. }
                if detail.contains("journal durability degraded")
        ));
        store
            .shadow
            .fail_next_durability_probe_for_test("durability-run")
            .map_err(|error| error.to_string())?;
        let still_degraded = store
            .record_background_cell_started(
                "durability-run",
                "cell-durable",
                "command",
                "hash",
                None,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            still_degraded,
            ProjectionCommitReceipt::CommittedProjectionDegraded { detail, .. }
                if detail.contains("journal durability degraded")
        ));
        let settled = store
            .record_background_cell_started(
                "durability-run",
                "cell-durable",
                "command",
                "hash",
                None,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(settled, ProjectionCommitReceipt::Durable { .. }));

        store
            .shadow
            .fail_next_append_durability_for_test("durability-run")
            .map_err(|error| error.to_string())?;
        store
            .note("durability-run", None, "committed diagnostic boundary")
            .map_err(|error| error.to_string())?;
        assert_eq!(
            store
                .list_events("durability-run", 0)
                .map_err(|error| error.to_string())?
                .iter()
                .filter(|event| {
                    event.event_type == RuntimeEventKind::Note
                        && event
                            .payload
                            .get("message")
                            .and_then(serde_json::Value::as_str)
                            == Some("committed diagnostic boundary")
                })
                .count(),
            1
        );

        store
            .shadow
            .fail_history_cursor_writes_for_test("durability-run", 3)
            .map_err(|error| error.to_string())?;
        let history_degraded = store
            .record_background_cell_started(
                "durability-run",
                "cell-history",
                "command",
                "history-hash",
                None,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            history_degraded,
            ProjectionCommitReceipt::CommittedProjectionDegraded { detail, .. }
                if detail.contains("history projection degraded")
        ));
        let duplicate_degraded = store
            .record_background_cell_started(
                "durability-run",
                "cell-history",
                "command",
                "history-hash",
                None,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            duplicate_degraded,
            ProjectionCommitReceipt::CommittedProjectionDegraded { detail, .. }
                if detail.contains("history projection degraded")
        ));
        let duplicate_repaired = store
            .record_background_cell_started(
                "durability-run",
                "cell-history",
                "command",
                "history-hash",
                None,
                None,
                None,
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            duplicate_repaired,
            ProjectionCommitReceipt::Durable { .. }
        ));

        let checkpoint = TaskRuntimeStore::classify_committed_projection(
            42,
            JournalDurabilityStatus::Confirmed,
            CheckpointApplyStatus::Degraded {
                error: "checkpoint-write".to_string(),
            },
            HistoryProjectionApplyStatus::Current,
            ProjectionCommitReceipt::Durable { seq: 42 },
        );
        assert!(matches!(
            checkpoint,
            ProjectionCommitReceipt::CommittedProjectionDegraded { seq: 42, detail }
                if detail.contains("checkpoint durability degraded")
        ));
        Ok(())
    }

    #[test]
    fn partial_history_failure_replays_without_duplicates_before_advancing_cursor()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        seed_history_plan(&store, "partial-history")?;
        let (artifact_path, review_path, cursor_path) = store
            .shadow
            .history_paths_for_test("partial-history", "target-task")
            .map_err(|error| error.to_string())?;
        let cursor_before = std::fs::read(&cursor_path).map_err(|error| error.to_string())?;
        store
            .shadow
            .fail_next_review_history_append_for_test("partial-history")
            .map_err(|error| error.to_string())?;
        let receipt = store
            .commit_runtime_events_with_receipt(
                "partial-history",
                vec![
                    artifact_history_event("partial-history", "artifact-1"),
                    review_history_event("partial-history", "target-task", "review-1"),
                ],
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            receipt,
            ProjectionCommitReceipt::CommittedProjectionDegraded { detail, .. }
                if detail.contains("history projection degraded")
        ));
        assert_eq!(
            std::fs::read(&cursor_path).map_err(|error| error.to_string())?,
            cursor_before
        );
        assert_eq!(line_count(&artifact_path)?, 1);
        assert!(!review_path.exists());
        drop(store);

        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        assert_eq!(
            reopened
                .list_artifacts("partial-history")
                .map_err(|error| error.to_string())?
                .len(),
            1
        );
        assert_eq!(
            reopened
                .list_reviews("partial-history", "target-task")
                .map_err(|error| error.to_string())?
                .len(),
            1
        );
        assert_eq!(line_count(&artifact_path)?, 1);
        assert_eq!(line_count(&review_path)?, 1);
        Ok(())
    }

    #[test]
    fn missing_history_segments_recover_old_and_new_facts_from_journal() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        seed_history_plan(&store, "missing-history")?;
        store
            .add_artifact(&history_artifact("missing-history", "artifact-old"))
            .map_err(|error| error.to_string())?;
        store
            .add_review(&history_review(
                "missing-history",
                "target-task",
                "review-old",
            ))
            .map_err(|error| error.to_string())?;
        let (artifact_path, review_path, cursor_path) = store
            .shadow
            .history_paths_for_test("missing-history", "target-task")
            .map_err(|error| error.to_string())?;
        std::fs::remove_file(&artifact_path).map_err(|error| error.to_string())?;
        assert_eq!(
            store
                .list_artifacts("missing-history")
                .map_err(|error| error.to_string())?
                .len(),
            1
        );
        let repaired_artifact_cursor = history_cursor_sequence(&cursor_path)?;
        store
            .add_artifact(&history_artifact("missing-history", "artifact-new"))
            .map_err(|error| error.to_string())?;
        let artifacts = store
            .list_artifacts("missing-history")
            .map_err(|error| error.to_string())?;
        assert_eq!(artifacts.len(), 2);
        assert_eq!(line_count(&artifact_path)?, 2);
        assert!(history_cursor_sequence(&cursor_path)? > repaired_artifact_cursor);
        std::fs::remove_file(&artifact_path).map_err(|error| error.to_string())?;
        let append_repair = store
            .commit_runtime_events_with_receipt(
                "missing-history",
                vec![artifact_history_event(
                    "missing-history",
                    "artifact-after-unlink",
                )],
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            append_repair,
            ProjectionCommitReceipt::Durable { .. }
        ));
        assert_eq!(line_count(&artifact_path)?, 3);

        std::fs::remove_file(&review_path).map_err(|error| error.to_string())?;
        assert_eq!(
            store
                .list_reviews("missing-history", "target-task")
                .map_err(|error| error.to_string())?
                .len(),
            1
        );
        let repaired_review_cursor = history_cursor_sequence(&cursor_path)?;
        store
            .add_review(&history_review(
                "missing-history",
                "target-task",
                "review-new",
            ))
            .map_err(|error| error.to_string())?;
        let reviews = store
            .list_reviews("missing-history", "target-task")
            .map_err(|error| error.to_string())?;
        assert_eq!(reviews.len(), 2);
        assert_eq!(line_count(&review_path)?, 2);
        assert!(history_cursor_sequence(&cursor_path)? > repaired_review_cursor);
        std::fs::remove_file(&review_path).map_err(|error| error.to_string())?;
        let append_repair = store
            .commit_runtime_events_with_receipt(
                "missing-history",
                vec![review_history_event(
                    "missing-history",
                    "target-task",
                    "review-after-unlink",
                )],
            )
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            append_repair,
            ProjectionCommitReceipt::Durable { .. }
        ));
        assert_eq!(line_count(&review_path)?, 3);

        std::fs::write(&artifact_path, b"{corrupt artifact segment\n")
            .map_err(|error| error.to_string())?;
        assert_eq!(
            store
                .list_artifacts("missing-history")
                .map_err(|error| error.to_string())?
                .len(),
            3
        );
        assert_eq!(line_count(&artifact_path)?, 3);
        std::fs::write(&review_path, b"{corrupt review segment\n")
            .map_err(|error| error.to_string())?;
        assert_eq!(
            store
                .list_reviews("missing-history", "target-task")
                .map_err(|error| error.to_string())?
                .len(),
            3
        );
        assert_eq!(line_count(&review_path)?, 3);
        Ok(())
    }

    #[test]
    fn valid_jsonl_prefix_and_empty_segment_self_heal_after_restart() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("tasks");
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        seed_history_plan(&store, "truncated-history")?;
        for id in ["artifact-1", "artifact-2"] {
            store
                .add_artifact(&history_artifact("truncated-history", id))
                .map_err(|error| error.to_string())?;
        }
        for id in ["review-1", "review-2"] {
            store
                .add_review(&history_review("truncated-history", "target-task", id))
                .map_err(|error| error.to_string())?;
        }
        let (artifact_path, review_path, _) = store
            .shadow
            .history_paths_for_test("truncated-history", "target-task")
            .map_err(|error| error.to_string())?;
        drop(store);

        retain_first_jsonl_record(&artifact_path)?;
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        assert_eq!(
            reopened
                .list_artifacts("truncated-history")
                .map_err(|error| error.to_string())?
                .len(),
            2
        );
        assert_eq!(line_count(&artifact_path)?, 2);
        drop(reopened);

        std::fs::write(&review_path, b"").map_err(|error| error.to_string())?;
        let restarted = TaskRuntimeStore::new_in_memory_with_shadow_root(&root)
            .map_err(|error| error.to_string())?;
        assert_eq!(
            restarted
                .list_reviews("truncated-history", "target-task")
                .map_err(|error| error.to_string())?
                .len(),
            2
        );
        assert_eq!(line_count(&review_path)?, 2);
        Ok(())
    }

    #[test]
    fn committed_projection_degradation_preserves_all_mutation_outcomes() -> Result<(), String> {
        let store = fresh().map_err(|error| error.to_string())?;
        store
            .create_run(
                "transition-run",
                "test",
                "conversation",
                "root",
                DomainProfile::General,
                "transition",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store.fail_next_runtime_mutation_projection_for_test();
        assert_eq!(
            store
                .transition_run("transition-run", TaskRunStatus::Running)
                .map_err(|error| error.to_string())?
                .status,
            TaskRunStatus::Running
        );
        store.fail_next_runtime_mutation_projection_for_test();
        assert_eq!(
            store
                .finalize_run("transition-run", TaskRunStatus::Failed, Some("terminal"))
                .map_err(|error| error.to_string())?
                .status,
            TaskRunStatus::Failed
        );

        store
            .create_run(
                "pause-goal-run",
                "test",
                "conversation",
                "root-2",
                DomainProfile::General,
                "old goal",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("pause-goal-run", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store.fail_next_runtime_mutation_projection_for_test();
        assert!(
            store
                .request_pause("pause-goal-run")
                .map_err(|error| error.to_string())?
        );
        store.fail_next_runtime_mutation_projection_for_test();
        let updated = store
            .update_run_goal(
                "pause-goal-run",
                1,
                "new goal",
                "user revised goal",
                RunGoalActorSource::Gui,
            )
            .map_err(|error| error.to_string())?;
        assert_eq!(updated.goal, "new goal");
        assert_eq!(updated.goal_revision, 2);

        store
            .create_run(
                "plan-run",
                "test",
                "conversation",
                "root-3",
                DomainProfile::General,
                "plan",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store.fail_next_runtime_mutation_projection_for_test();
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,

                plan_id: "plan-id".to_string(),
                run_id: "plan-run".to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: task_goal_sha256("plan"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: "task-a".to_string(),
                    title: "Task A".to_string(),
                    description: "Do A".to_string(),
                    kind: PlanTaskKind::Investigation,
                    agent_role: "subagent".to_string(),
                    domain_profile: DomainProfile::General,
                    ..Default::default()
                }],
            })
            .map_err(|error| error.to_string())?;
        assert!(
            store
                .get_plan("plan-run")
                .map_err(|error| error.to_string())?
                .is_some()
        );

        store
            .create_run(
                "turn-run",
                "test",
                "conversation",
                "root-4",
                DomainProfile::General,
                "turn",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run("turn-run", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .configure_run_continuation("turn-run", true, false, None, None)
            .map_err(|error| error.to_string())?;
        store.fail_next_runtime_mutation_projection_for_test();
        assert!(matches!(
            store
                .claim_run_turn(
                    "turn-run",
                    "turn-1",
                    RunTurnOrigin::User,
                    TurnVisibility::Visible,
                )
                .map_err(|error| error.to_string())?,
            RunTurnClaimOutcome::Started(_)
        ));
        assert_eq!(
            store
                .list_events("turn-run", 0)
                .map_err(|error| error.to_string())?
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::RunTurnStarted)
                .count(),
            1
        );
        Ok(())
    }

    #[tokio::test]
    async fn direct_completion_survives_committed_projection_degradation() -> Result<(), String> {
        let store = std::sync::Arc::new(fresh().map_err(|error| error.to_string())?);
        let run_id = "direct-degraded";
        store
            .create_run(
                run_id,
                "test",
                "conversation",
                "root",
                DomainProfile::General,
                "direct answer",
                "agent_autonomous",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store
            .transition_run(run_id, TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .configure_run_continuation(run_id, true, false, None, None)
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            store
                .claim_run_turn(
                    run_id,
                    "turn-direct",
                    RunTurnOrigin::User,
                    TurnVisibility::Visible,
                )
                .map_err(|error| error.to_string())?,
            RunTurnClaimOutcome::Started(_)
        ));
        let task_id = "direct-answer";
        let plan = TaskPlan {
            domain_binding: None,

            plan_id: format!("plan:{run_id}"),
            run_id: run_id.to_string(),
            revision: 0,
            domain_profile: DomainProfile::General,
            goal_revision: 1,
            goal_sha256: task_goal_sha256("direct answer"),
            assumptions: Vec::new(),
            risks: Vec::new(),
            execution_mode: ExecutionMode::Sequential,
            tasks: vec![PlanTask {
                id: task_id.to_string(),
                title: "Direct answer".to_string(),
                description: "direct answer".to_string(),
                kind: PlanTaskKind::Summary,
                agent_role: "primary-agent".to_string(),
                domain_profile: DomainProfile::General,
                ..Default::default()
            }],
        };
        let summary = TaskExecutionSummary {
            run_id: run_id.to_string(),
            task_id: task_id.to_string(),
            subagent_name: "primary-agent".to_string(),
            outcome: SubagentOutcome::terminal(
                SubagentStatus::Completed,
                "complete answer",
                Vec::new(),
            ),
            decisions: Vec::new(),
            next_implications: Vec::new(),
            suggested_tasks: Vec::new(),
            created_at: Utc::now(),
        };
        store.fail_next_runtime_mutation_projection_for_test();
        super::super::revisioned_runtime::commit_direct_completion(
            store.clone(),
            plan,
            summary,
            "complete answer".to_string(),
        )
        .await
        .map_err(|error| error.to_string())?;
        let todos = store
            .list_todos(run_id)
            .map_err(|error| error.to_string())?;
        assert_eq!(todos.len(), 1);
        assert_eq!(
            todos.first().map(|todo| todo.status),
            Some(TodoStatus::Completed)
        );
        assert_eq!(
            store
                .list_events(run_id, 0)
                .map_err(|error| error.to_string())?
                .iter()
                .filter(|event| event.event_type == RuntimeEventKind::PlanRevisionCommitted)
                .count(),
            1
        );
        Ok(())
    }

    /// Helper: a minimal `PlanTask` body with the given id and sane defaults,
    /// for the cycle test above (avoids repeating the full struct literal).
    fn sample_task_body(id: &str) -> PlanTask {
        PlanTask {
            domain_binding: None,
            domain_role: None,

            id: id.to_string(),
            title: format!("task {id}"),
            description: format!("do {id}"),
            kind: PlanTaskKind::Investigation,
            agent_role: "explorer".to_string(),
            domain_profile: DomainProfile::General,
            depends_on: Vec::new(),
            parallel_group: None,
            execution_target: None,
            files: Vec::new(),
            allowed_tools: vec!["read_file".to_string()],
            required_artifacts: Vec::new(),
            execution_checks: Vec::new(),
            acceptance_criteria: Vec::new(),
            retry_count: 0,
            max_retries: 3,
            failure_fingerprint: None,
            status: echo_agent::tasks::TaskStatus::Pending,
            claim: None,
            result: None,
            interruption_requested: None,
            sort_order: 0,
        }
    }
    fn claimed_task_for(
        store: &TaskRuntimeStore,
        run_id: &str,
    ) -> Result<(echo_agent::tasks::TaskClaim, echo_agent::tasks::Task), StoreError> {
        let snapshot = store.load_runtime_plan_snapshot(run_id)?;
        let task = snapshot
            .tasks
            .first()
            .cloned()
            .ok_or_else(|| StoreError::TaskNotFound("t1".to_string()))?;
        let claim = match store.claim_runtime_task(run_id, &task, snapshot.revision)? {
            echo_agent::tasks::RuntimeTaskClaimOutcome::Claimed(claim) => claim,
            echo_agent::tasks::RuntimeTaskClaimOutcome::ReloadSnapshot => {
                return Err(StoreError::InvalidPlan("claim not admitted".to_string()));
            }
        };
        Ok((claim, task))
    }

    fn evidence_summary(text: &str) -> TaskExecutionSummary {
        TaskExecutionSummary {
            run_id: "r1".to_string(),
            task_id: "t1".to_string(),
            subagent_name: "subagent".to_string(),
            outcome: SubagentOutcome::terminal(SubagentStatus::Completed, text, Vec::new()),
            decisions: Vec::new(),
            next_implications: Vec::new(),
            suggested_tasks: Vec::new(),
            created_at: Utc::now(),
        }
    }

    fn evidence_product(text: &str) -> RuntimeTaskProductSettlement {
        RuntimeTaskProductSettlement {
            summary: Some(text.to_string()),
            execution_summary: Some(evidence_summary(text)),
            review: Some(ReviewResult {
                id: format!("review-{text}"),
                run_id: "r1".to_string(),
                task_id: "t1".to_string(),
                reviewer_agent: "reviewer".to_string(),
                outcome: ReviewOutcome::Pass,
                issues: Vec::new(),
                failure_fingerprint: None,
                created_fix_task_id: None,
                created_at: Utc::now(),
            }),
            diagnostic_note: None,
            typed_terminal: None,
        }
    }

    #[test]
    fn superseded_resolution_rejects_every_attempt_product()
    -> Result<(), Box<dyn std::error::Error>> {
        use echo_agent::tasks::{RuntimeTaskResolution, RuntimeTaskResolutionRequest as Request};

        let requests = [
            Request::Blocked {
                error: "foreign review".to_string(),
                disposition: echo_agent::tasks::RuntimeStopDisposition::Pause,
            },
            Request::Completed,
            Request::CompletedWithResult {
                result: serde_json::json!({ "value": "foreign result" }),
            },
            Request::Requeue {
                failure_fingerprint: None,
                error: "foreign retry".to_string(),
                exhaustion: echo_agent::tasks::RuntimeRetryExhaustion::Failed,
            },
            Request::Skipped,
            Request::Failed {
                error: "foreign failure".to_string(),
            },
            Request::TimedOut {
                error: "foreign timeout".to_string(),
            },
            Request::Cancelled,
        ];
        for identity in ["foreign", "stale"] {
            for request in &requests {
                let store = fresh()?;
                seed_plan(&store)?;
                let (mut refused_claim, _) = claimed_task_for(&store, "r1")?;
                if identity == "stale" {
                    store.settle_runtime_task_resolution(
                        "r1",
                        "t1",
                        &refused_claim,
                        Request::Requeue {
                            failure_fingerprint: None,
                            error: "retry current attempt".to_string(),
                            exhaustion: echo_agent::tasks::RuntimeRetryExhaustion::Failed,
                        },
                        RuntimeTaskProductSettlement::default(),
                    )?;
                    claimed_task_for(&store, "r1")?;
                } else {
                    refused_claim.claim_id = "foreign-claim".to_string();
                }
                let before = store.load_runtime_plan_snapshot("r1")?;
                let sequence = store
                    .get_run_state("r1")?
                    .map(|state| state.journal_sequence)
                    .ok_or("run state missing")?;
                let receipt = store.settle_runtime_task_resolution(
                    "r1",
                    "t1",
                    &refused_claim,
                    request.clone(),
                    evidence_product("unaccepted attempt evidence"),
                )?;
                assert_eq!(receipt.resolution, RuntimeTaskResolution::Superseded);
                assert!(
                    receipt.acceptance.is_rejected(),
                    "{identity}/{request:?}: superseded evidence must be rejected"
                );
                assert!(
                    receipt.committed_summary.is_none(),
                    "{identity}/{request:?}: a refused claim committed no summary"
                );
                let after = store.load_runtime_plan_snapshot("r1")?;
                assert_eq!(after.revision, before.revision);
                assert_eq!(after.tasks, before.tasks);
                assert_eq!(
                    store
                        .get_run_state("r1")?
                        .map(|state| state.journal_sequence),
                    Some(sequence),
                    "{identity}/{request:?}: a refused claim must append no journal facts"
                );
                assert!(store.get_summary("r1", "t1")?.is_none());
                assert!(store.list_reviews("r1", "t1")?.is_empty());
            }
        }
        Ok(())
    }

    #[test]
    fn interruption_wins_over_late_completion_and_abandon_matrix()
    -> Result<(), Box<dyn std::error::Error>> {
        // cancel/pause x completion/abandon: interruption always owns the
        // durable status and no success summary or review is published.
        for interrupt in ["cancel", "pause"] {
            for outcome in ["completion", "abandon"] {
                let store = fresh()?;
                seed_plan(&store)?;
                let (claim, _task) = claimed_task_for(&store, "r1")?;
                if interrupt == "cancel" {
                    assert!(store.request_cancel("r1")?);
                } else {
                    assert!(store.request_pause("r1")?);
                }
                let expected_run = if interrupt == "cancel" {
                    TaskRunStatus::Cancelled
                } else {
                    TaskRunStatus::Paused
                };
                assert_eq!(
                    store.get_run("r1")?.map(|run| run.status),
                    Some(expected_run),
                    "{interrupt} must settle the run before evidence"
                );

                if outcome == "completion" {
                    let receipt = store.settle_runtime_task_resolution(
                        "r1",
                        "t1",
                        &claim,
                        echo_agent::tasks::RuntimeTaskResolutionRequest::Completed,
                        evidence_product("late success"),
                    )?;
                    assert!(
                        receipt.settlement.is_late(),
                        "{interrupt}/{outcome}: late evidence must be classified as late, got {:?}",
                        receipt.settlement
                    );
                    assert_ne!(
                        receipt.committed_summary.as_deref(),
                        Some("late success"),
                        "{interrupt}/{outcome}: committed summary must never be the rejected text"
                    );
                    let committed = receipt
                        .committed_status
                        .as_ref()
                        .cloned()
                        .ok_or("committed status missing")?;
                    assert!(
                        matches!(
                            committed,
                            echo_agent::tasks::TaskStatus::Cancelled
                                | echo_agent::tasks::TaskStatus::Paused(_)
                        ),
                        "{interrupt}/{outcome}: committed task status was {committed:?}"
                    );
                } else {
                    let fallback = if interrupt == "cancel" {
                        echo_agent::tasks::TaskStatus::Cancelled
                    } else {
                        echo_agent::tasks::TaskStatus::Paused("paused by user".to_string())
                    };
                    store.settle_runtime_task_claim(
                        "r1",
                        "t1",
                        &claim,
                        fallback,
                        Some("abandoned attempt".to_string()),
                    )?;
                    let committed = store
                        .runtime_task_execution("r1", "t1")?
                        .map(|execution| execution.status)
                        .ok_or("task missing after abandon")?;
                    assert!(
                        matches!(
                            committed,
                            echo_agent::tasks::TaskStatus::Cancelled
                                | echo_agent::tasks::TaskStatus::Paused(_)
                        ),
                        "{interrupt}/{outcome}: abandoned task status was {committed:?}"
                    );
                }

                assert_eq!(
                    store.get_run("r1")?.map(|run| run.status),
                    Some(expected_run),
                    "{interrupt}/{outcome}: late evidence must not change the run"
                );
                assert!(
                    store.get_summary("r1", "t1")?.is_none(),
                    "{interrupt}/{outcome}: no success summary may land"
                );
                assert!(
                    store.list_reviews("r1", "t1")?.is_empty(),
                    "{interrupt}/{outcome}: no success review may land"
                );
            }
        }
        Ok(())
    }

    #[test]
    fn review_finishing_after_pause_never_persists_success_evidence()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_plan(&store)?;
        let (claim, _task) = claimed_task_for(&store, "r1")?;
        assert!(store.request_pause("r1")?);

        let receipt = store.settle_runtime_task_resolution(
            "r1",
            "t1",
            &claim,
            echo_agent::tasks::RuntimeTaskResolutionRequest::Completed,
            evidence_product("review completed after pause"),
        )?;
        assert!(receipt.settlement.is_late());
        assert_eq!(
            store.get_run("r1")?.map(|run| run.status),
            Some(TaskRunStatus::Paused)
        );
        assert!(store.get_summary("r1", "t1")?.is_none());
        assert!(store.list_reviews("r1", "t1")?.is_empty());
        let events = store.list_events("r1", 0)?;
        assert!(
            events.iter().any(|event| {
                event
                    .payload
                    .get("kind")
                    .and_then(serde_json::Value::as_str)
                    == Some("settlement_evidence_rejected")
            }),
            "late evidence must leave one durable rejection fact"
        );
        Ok(())
    }

    #[test]
    fn duplicate_success_redelivery_is_idempotent() -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_plan(&store)?;
        let (claim, _task) = claimed_task_for(&store, "r1")?;
        let first = store.settle_runtime_task_resolution(
            "r1",
            "t1",
            &claim,
            echo_agent::tasks::RuntimeTaskResolutionRequest::Completed,
            evidence_product("committed result"),
        )?;
        assert!(first.settlement.is_committed());
        let sequence = store
            .get_run_state("r1")?
            .map(|state| state.journal_sequence)
            .ok_or("run state missing")?;

        let repeat = store.settle_runtime_task_resolution(
            "r1",
            "t1",
            &claim,
            echo_agent::tasks::RuntimeTaskResolutionRequest::Completed,
            evidence_product("committed result"),
        )?;
        assert!(
            repeat.settlement.is_duplicate(),
            "re-delivery of the same attempt's success must be a duplicate, got {:?}",
            repeat.settlement
        );
        assert_eq!(
            store
                .get_run_state("r1")?
                .map(|state| state.journal_sequence),
            Some(sequence),
            "duplicate evidence must not append journal facts"
        );
        assert_eq!(
            store
                .get_summary("r1", "t1")?
                .map(|summary| summary.outcome.summary),
            Some("committed result".to_string())
        );
        Ok(())
    }

    #[test]
    fn late_success_after_cancel_does_not_rewrite_terminal()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = fresh()?;
        seed_plan(&store)?;
        let (claim, _task) = claimed_task_for(&store, "r1")?;
        assert!(store.request_cancel("r1")?);
        let receipt = store.settle_runtime_task_resolution(
            "r1",
            "t1",
            &claim,
            echo_agent::tasks::RuntimeTaskResolutionRequest::Completed,
            evidence_product("late success after cancel"),
        )?;
        assert!(receipt.settlement.is_late());
        assert_eq!(
            store.get_run("r1")?.map(|run| run.status),
            Some(TaskRunStatus::Cancelled)
        );
        assert_eq!(
            store
                .runtime_task_execution("r1", "t1")?
                .map(|execution| execution.status),
            Some(echo_agent::tasks::TaskStatus::Cancelled)
        );
        assert!(store.get_summary("r1", "t1")?.is_none());
        Ok(())
    }

    #[test]
    fn canonical_retry_restores_execution_fields_without_stale_summary()
    -> Result<(), Box<dyn std::error::Error>> {
        let directory = tempfile::tempdir()?;
        let store = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        seed_plan(&store)?;
        let (claim, _task) = claimed_task_for(&store, "r1")?;
        // Attempt one publishes a summary, then fails and becomes retryable.
        assert!(
            store
                .put_summary(&evidence_summary("attempt one summary"))?
                .is_committed()
        );
        let failed = store.settle_runtime_task_resolution(
            "r1",
            "t1",
            &claim,
            echo_agent::tasks::RuntimeTaskResolutionRequest::Failed {
                error: "attempt one failed".to_string(),
            },
            RuntimeTaskProductSettlement {
                summary: Some("attempt one failed".to_string()),
                ..RuntimeTaskProductSettlement::default()
            },
        )?;
        assert_eq!(
            failed.resolution,
            echo_agent::tasks::RuntimeTaskResolution::Failed {
                error: "attempt one failed".to_string()
            }
        );

        // Field-level authority: the framework retry defines the exact
        // canonical execution every projection must restore.
        let before = store.load_runtime_plan_snapshot("r1")?;
        let expected_task = before
            .tasks
            .first()
            .cloned()
            .ok_or("task missing before retry")?;
        let mut expected_snapshot = store
            .load_revisioned_task_graph("r1")?
            .ok_or("revisioned graph missing before retry")?
            .snapshot;
        assert_eq!(
            echo_agent::tasks::retry_runtime_task(
                &mut expected_snapshot,
                &expected_task,
                before.revision
            )?,
            echo_agent::tasks::RuntimeTaskRetryOutcome::Retried { retry_count: 1 }
        );
        let expected_execution = expected_snapshot
            .tasks
            .first()
            .map(|task| task.execution.clone())
            .ok_or("retried task missing")?;

        let retried = store.retry_runtime_task("r1", &expected_task, before.revision)?;
        assert_eq!(
            retried,
            echo_agent::tasks::RuntimeTaskRetryOutcome::Retried { retry_count: 1 }
        );
        let committed = store
            .runtime_task_execution("r1", "t1")?
            .ok_or("canonical execution missing after retry")?;
        assert_eq!(
            committed, expected_execution,
            "retried canonical execution must be restored field by field"
        );
        assert_eq!(committed.status, echo_agent::tasks::TaskStatus::Pending);
        assert_eq!(committed.retry_count, 1);
        assert!(committed.claim.is_none());
        assert!(committed.result.is_none());
        assert!(committed.interruption_requested.is_none());
        assert!(
            store.get_summary("r1", "t1")?.is_none(),
            "attempt-one summary must not survive the retry"
        );
        // The plan projection and the canonical execution agree.
        let plan = store.get_plan("r1")?.ok_or("plan missing")?;
        let plan_task = plan
            .tasks
            .iter()
            .find(|task| task.id == "t1")
            .ok_or("plan task missing")?;
        assert_eq!(plan_task.execution(), committed);

        drop(store);
        // Restart replay from the journal restores the same canonical fields.
        let reopened = TaskRuntimeStore::new_in_memory_with_shadow_root(directory.path())
            .map_err(|error| StoreError::InvalidPlan(error.to_string()))?;
        let replayed = reopened
            .runtime_task_execution("r1", "t1")?
            .ok_or("canonical execution missing after replay")?;
        assert_eq!(replayed, expected_execution);
        assert!(reopened.get_summary("r1", "t1")?.is_none());
        Ok(())
    }
}

#[cfg(test)]
mod domain_binding_tests {
    use super::*;

    fn bound_graph(
        run: &TaskRun,
        binding: &crate::domain_plugin::DomainBinding,
    ) -> Result<echo_agent::tasks::TaskGraphCommit, Box<dyn std::error::Error>> {
        let task = PlanTask {
            id: "evidence".to_string(),
            kind: PlanTaskKind::Verification,
            agent_role: "primary".to_string(),
            domain_binding: Some(binding.reference()),
            domain_role: Some(binding.role_for_kind(PlanTaskKind::Verification)?.clone()),
            required_artifacts: binding.snapshot.required_artifacts.clone(),
            execution_checks: binding.snapshot.execution_checks.clone(),
            acceptance_criteria: binding.review_criteria(),
            ..Default::default()
        };
        Ok(echo_agent::tasks::TaskGraphCommit {
            expected_revision: None,
            expected_executions: None,
            reason: "domain initial graph".to_string(),
            effects: Default::default(),
            next: echo_agent::tasks::RevisionedTaskGraph {
                snapshot: echo_agent::tasks::RuntimePlanSnapshot {
                    revision: 1,
                    tasks: vec![(&task).try_into()?],
                },
                context: echo_agent::tasks::TaskGraphContext {
                    goal: run.goal.clone(),
                    assumptions: Vec::new(),
                    risks: Vec::new(),
                    execution_mode: echo_agent::tasks::TaskGraphExecutionMode::Sequential,
                    metadata: serde_json::to_value(EkoPlanMetadata {
                        plan_id: "domain-plan".to_string(),
                        domain_profile: DomainProfile::General,
                        domain_binding: Some(binding.reference()),
                        goal_revision: run.goal_revision,
                        goal_sha256: run.goal_sha256.clone(),
                    })?,
                },
            },
        })
    }

    #[test]
    fn domain_binding_roundtrips_both_run_created_producers_and_rejects_rebinding()
    -> Result<(), Box<dyn std::error::Error>> {
        let project = super::super::project_environment_tests::EnvironmentFixture::new()?;
        let store = project.open("domain-target.invalid", 7)?;
        let project_binding = store
            .project_execution_binding()
            .ok_or("project binding missing")?;
        let binding = crate::domain_plugin::test_binding(true)?;
        let profile = TaskRunExecutionProfile::orchestrated(RunPlanPolicy::RequirePlan);
        let run = store.create_run_for_active_workspace_with_domain(
            "domain-run",
            "conversation",
            "root",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
            profile,
            Some(&binding),
        )?;
        let state = store
            .get_run_state("domain-run")?
            .ok_or("domain state missing")?;
        assert_eq!(run.domain_binding, Some(binding.reference()));
        assert_eq!(state.domain_binding, Some(binding.clone()));
        assert_eq!(state.project_binding, Some(project_binding.clone()));
        let replay = super::super::event_rebuild::fold_fixture_for_test(
            &store.list_events("domain-run", 0)?,
        )?;
        assert_eq!(replay.domain_binding, Some(binding.clone()));
        assert_eq!(replay.run.domain_binding, Some(binding.reference()));
        assert_eq!(replay.project_binding, Some(project_binding.clone()));
        // An old idempotent reader may omit a new selection but cannot fill or
        // replace the immutable original binding from current configuration.
        store.create_run_for_active_workspace_with_profile(
            "domain-run",
            "conversation",
            "root",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
            profile,
        )?;
        let mut changed = binding.snapshot.clone();
        changed.plugin.version = Some("new".to_string());
        changed.dependency_closure = vec![changed.plugin.clone()];
        let changed = crate::domain_plugin::DomainBinding::new(changed)?;
        assert!(
            store
                .create_run_for_active_workspace_with_domain(
                    "domain-run",
                    "conversation",
                    "root",
                    DomainProfile::General,
                    "goal",
                    "task",
                    AttendedMode::Attended,
                    profile,
                    Some(&changed)
                )
                .is_err()
        );
        let mut initial = store.prepare_run_for_active_workspace(
            "initial",
            "conversation",
            "initial-root",
            DomainProfile::General,
            "initial goal",
            "task",
            AttendedMode::Attended,
        )?;
        initial.domain_binding = Some(binding.reference());
        let trigger = InitialRunTriggerMetadata {
            source: "fixture".to_string(),
            kind: "domain".to_string(),
            prompt: initial.goal.clone(),
            priority: 5,
        };
        store.compare_and_publish_initial_revisioned_task_graph_with_domain(
            &initial,
            &trigger,
            None,
            Some(&binding),
            profile,
            bound_graph(&initial, &binding)?,
        )?;
        let state = store
            .get_run_state("initial")?
            .ok_or("initial state missing")?;
        assert_eq!(state.domain_binding, Some(binding.clone()));
        assert_eq!(state.project_binding, Some(project_binding.clone()));
        let initial_replay =
            super::super::event_rebuild::fold_fixture_for_test(&store.list_events("initial", 0)?)?;
        assert_eq!(initial_replay.domain_binding, Some(binding.clone()));
        assert_eq!(
            initial_replay.project_binding,
            Some(project_binding.clone())
        );
        assert_eq!(
            store
                .get_plan("initial")?
                .ok_or("initial plan missing")?
                .domain_binding,
            Some(binding.reference())
        );
        drop(store);
        let reopened = project.open("domain-target.invalid", 7)?;
        let reopened_state = reopened
            .get_run_state("domain-run")?
            .ok_or("reopened state missing")?;
        assert_eq!(reopened_state.domain_binding, Some(binding));
        assert_eq!(reopened_state.project_binding, Some(project_binding));
        drop(reopened);
        let wrong_host = project.open("another-domain-target.invalid", 7)?;
        assert!(
            wrong_host
                .validate_run_project_binding("domain-run")
                .is_err()
        );
        Ok(())
    }

    #[test]
    fn malformed_present_binding_does_not_recover_as_general()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = TaskRuntimeStore::new_in_memory()?;
        let binding = crate::domain_plugin::test_binding(false)?;
        store.create_run_for_active_workspace_with_domain(
            "bad",
            "conversation",
            "root",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
            TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
            Some(&binding),
        )?;
        let mut events = store.list_events("bad", 0)?;
        let event = events
            .iter_mut()
            .find(|event| event.event_type == RuntimeEventKind::RunCreated)
            .ok_or("RunCreated missing")?;
        event
            .payload
            .as_object_mut()
            .ok_or("RunCreated payload is not an object")?
            .insert(
                "domain_binding".to_string(),
                serde_json::json!({"binding_sha256":"invalid"}),
            );
        assert!(super::super::event_rebuild::fold_fixture_for_test(&events).is_err());
        Ok(())
    }

    #[test]
    fn domain_graph_cannot_drop_obligations_or_change_binding()
    -> Result<(), Box<dyn std::error::Error>> {
        let store = TaskRuntimeStore::new_in_memory()?;
        let binding = crate::domain_plugin::test_binding(true)?;
        let run = store.create_run_for_active_workspace_with_domain(
            "rules",
            "conversation",
            "root",
            DomainProfile::General,
            "goal",
            "task",
            AttendedMode::Attended,
            TaskRunExecutionProfile::orchestrated(RunPlanPolicy::RequirePlan),
            Some(&binding),
        )?;
        let original = bound_graph(&run, &binding)?;
        let mut missing = original.clone();
        let task = missing
            .next
            .snapshot
            .tasks
            .first_mut()
            .ok_or("task missing")?;
        let mut extension: EkoTaskExtension = task.spec.extension_as()?;
        extension.execution_checks.clear();
        task.spec = task.spec.clone().with_extension(extension)?;
        assert!(
            store
                .compare_and_commit_revisioned_task_graph("rules", missing)
                .is_err()
        );
        let mut changed = original.clone();
        changed
            .next
            .context
            .metadata
            .as_object_mut()
            .ok_or("metadata is not an object")?
            .insert("domain_binding".to_string(), serde_json::Value::Null);
        assert!(
            store
                .compare_and_commit_revisioned_task_graph("rules", changed)
                .is_err()
        );
        store.compare_and_commit_revisioned_task_graph("rules", original)?;
        assert_eq!(
            store
                .get_plan("rules")?
                .ok_or("plan missing")?
                .tasks
                .first()
                .ok_or("task missing")?
                .execution_checks,
            binding.snapshot.execution_checks
        );
        Ok(())
    }
}
