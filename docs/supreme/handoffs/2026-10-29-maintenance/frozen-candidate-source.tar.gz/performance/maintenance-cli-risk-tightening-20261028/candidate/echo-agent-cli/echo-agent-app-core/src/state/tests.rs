#[cfg(test)]
mod reliability_contracts;

#[cfg(test)]
mod model_mutation_tests {
    use super::*;
    use crate::config::{ConfiguredModel, ModelProviderConfig};
    use echo_agent::llm::LlmApiProtocol;

    const MODEL_A: &str = "model-a";
    const MODEL_B: &str = "model-b";
    const ENDPOINT_A: &str = "http://127.0.0.1:11434/v1/chat/completions";
    const ENDPOINT_B: &str = "http://127.0.0.1:11435/v1/chat/completions";
    const ENDPOINT_C: &str = "http://127.0.0.1:11436/v1/chat/completions";
    const RESPONSES_ENDPOINT: &str = "http://127.0.0.1:11435/v1/responses";
    const WINDOW_A: usize = 120_000;
    const WINDOW_B: usize = 240_000;

    #[test]
    fn first_configured_model_becomes_the_active_generation() -> Result<(), String> {
        let mut config = crate::config::EkoConfig::default();
        config.model_providers.insert(
            "local".to_string(),
            ModelProviderConfig {
                base_url: Some(ENDPOINT_A.to_string()),
                ..Default::default()
            },
        );
        let mutation = prepare_model_mutation(
            &config,
            "",
            ModelMutationRequest::UpsertModel(ConfiguredModelMutation {
                model: model(MODEL_A, "local", "runtime-a", WINDOW_A as u32),
                set_default: false,
            }),
        )
        .map_err(|error| error.to_string())?;

        assert!(mutation.activated);
        assert_eq!(mutation.model_id, MODEL_A);
        assert_eq!(
            mutation.config.model.default_model_id.as_deref(),
            Some(MODEL_A)
        );
        assert_eq!(
            mutation.runtime.as_ref().map(|runtime| runtime.id.as_str()),
            Some(MODEL_A)
        );
        assert!(mutation.prepared.is_some());
        Ok(())
    }

    struct ModelMutationFixture {
        _temp: tempfile::TempDir,
        config_path: std::path::PathBuf,
        state: Arc<AppState>,
        pool: Arc<crate::agent_pool::AgentPool>,
        existing: AgentHandle,
    }

    #[derive(Debug, PartialEq, Eq)]
    struct AgentModelProjection {
        model: String,
        client_model: String,
        base_url: String,
        api_protocol: LlmApiProtocol,
        token_limit: usize,
    }

    fn model(id: &str, provider: &str, model: &str, context_window: u32) -> ConfiguredModel {
        ConfiguredModel {
            id: id.to_string(),
            display_name: id.to_string(),
            provider: provider.to_string(),
            model: model.to_string(),
            api_protocol: LlmApiProtocol::ChatCompletions,
            enabled: true,
            context_window: Some(context_window),
            ..ConfiguredModel::default()
        }
    }

    fn provider_mutation(id: &str, base_url: &str) -> ModelProviderMutation {
        ModelProviderMutation {
            id: id.to_string(),
            provider: ModelProviderConfig {
                name: id.to_string(),
                base_url: Some(base_url.to_string()),
                default_api_protocol: Some(LlmApiProtocol::ChatCompletions),
                ..Default::default()
            },
            preserve_auth_token: false,
        }
    }

    fn valid_config() -> Result<crate::config::EkoConfig, String> {
        let mut config = crate::config::EkoConfig::default();
        config.model_providers.insert(
            "local-a".to_string(),
            ModelProviderConfig {
                auth_token: None,
                base_url: Some(ENDPOINT_A.to_string()),
                ..Default::default()
            },
        );
        config.model_providers.insert(
            "local-b".to_string(),
            ModelProviderConfig {
                auth_token: None,
                base_url: Some(ENDPOINT_B.to_string()),
                ..Default::default()
            },
        );
        config.configured_models = vec![
            model(MODEL_A, "local-a", "runtime-a", WINDOW_A as u32),
            model(MODEL_B, "local-b", "runtime-b", WINDOW_B as u32),
        ];
        crate::model_config::set_default_model(&mut config, MODEL_A)?;
        Ok(config)
    }

    fn invalid_successor_config() -> Result<crate::config::EkoConfig, String> {
        let mut config = valid_config()?;
        let invalid = config
            .configured_models
            .iter_mut()
            .find(|model| model.id == MODEL_B)
            .ok_or_else(|| "missing invalid successor candidate".to_string())?;
        invalid.provider = "openai".to_string();
        invalid.api_protocol = LlmApiProtocol::Responses;
        config.model_providers.insert(
            "openai".to_string(),
            ModelProviderConfig {
                auth_token: Some("invalid\nheader".to_string()),
                base_url: Some("https://api.openai.com/v1/responses".to_string()),
                ..Default::default()
            },
        );
        Ok(config)
    }

    fn shared_provider_config() -> Result<crate::config::EkoConfig, String> {
        let mut config = crate::config::EkoConfig::default();
        config.model_providers.insert(
            "local-shared".to_string(),
            ModelProviderConfig {
                auth_token: None,
                base_url: Some(ENDPOINT_A.to_string()),
                ..Default::default()
            },
        );
        config.configured_models = vec![
            model(MODEL_A, "local-shared", "runtime-a", WINDOW_A as u32),
            model(MODEL_B, "local-shared", "runtime-b", WINDOW_B as u32),
        ];
        crate::model_config::set_default_model(&mut config, MODEL_A)?;
        Ok(config)
    }

    async fn fixture(
        config: crate::config::EkoConfig,
        persistence_fails: bool,
    ) -> Result<ModelMutationFixture, String> {
        fixture_with_active(config, persistence_fails, MODEL_A).await
    }

    async fn fixture_with_active(
        config: crate::config::EkoConfig,
        persistence_fails: bool,
        active_model_id: &str,
    ) -> Result<ModelMutationFixture, String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let config_path = if persistence_fails {
            let path = temp.path().join("config-as-directory");
            std::fs::create_dir_all(&path).map_err(|error| error.to_string())?;
            path
        } else {
            let path = temp.path().join("eko.yaml");
            crate::config::save_config_file(&path, &config)?;
            path
        };
        let created = crate::infra::create_agent_with_diagnostics(
            &crate::infra::AgentCreateParams {
                model: Some(active_model_id.to_string()),
                system_prompt: Some("model mutation test".to_string()),
                ..Default::default()
            },
            &config,
        )
        .await?;
        let active_runtime = created
            .runtime_model
            .ok_or_else(|| "model mutation fixture did not resolve its active model".to_string())?;
        let primary_consumers = created.model_consumers;
        let primary = AgentHandle::new(created.agent);
        let session_config =
            crate::model_config::session_config_for_runtime(&config, &active_runtime)?;
        let pool = Arc::new(
            crate::agent_pool::AgentPool::for_model_mutation_test(&primary, session_config).await,
        );
        pool.set_primary_model_consumers_for_test(primary_consumers.clone())
            .await;
        let existing_lease = pool
            .acquire("existing")
            .await
            .map_err(|error| error.to_string())?;
        let existing = existing_lease.agent();
        drop(existing_lease);
        let mcp_runtime = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            temp.path().join("mcp.json"),
            Default::default(),
        ));
        let mut state = AppState::from_shared(
            primary,
            Some(primary_consumers),
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            config,
            mcp_runtime,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?
        .with_active_model_id(active_runtime.id)
        .with_config_path(config_path.clone());
        state.set_pool(pool.clone());
        Ok(ModelMutationFixture {
            _temp: temp,
            config_path,
            state: Arc::new(state),
            pool,
            existing,
        })
    }

    async fn agent_projection(handle: &AgentHandle) -> Result<AgentModelProjection, String> {
        handle
            .read(|agent| {
                let llm = agent
                    .llm_config()
                    .ok_or_else(|| "agent has no LLM config".to_string())?;
                Ok(AgentModelProjection {
                    model: llm.model.clone(),
                    client_model: agent
                        .llm_client()
                        .map(|client| client.model_name().to_string())
                        .ok_or_else(|| "agent has no prepared LLM client".to_string())?,
                    base_url: llm.base_url.clone(),
                    api_protocol: llm.api_protocol,
                    token_limit: agent.config().get_token_limit(),
                })
            })
            .await
    }

    async fn assert_live_generation(
        fixture: &ModelMutationFixture,
        model_id: &str,
        runtime_model: &str,
        endpoint: &str,
        context_window: usize,
    ) -> Result<(), String> {
        let snapshot = fixture.state.config.app_config.read().await;
        assert_eq!(snapshot.model.default_model_id.as_deref(), Some(model_id));
        drop(snapshot);
        let expected = AgentModelProjection {
            model: runtime_model.to_string(),
            client_model: runtime_model.to_string(),
            base_url: endpoint.to_string(),
            api_protocol: LlmApiProtocol::ChatCompletions,
            token_limit: context_window,
        };
        assert_eq!(
            agent_projection(&fixture.state.connection.agent).await?,
            expected
        );
        assert_eq!(agent_projection(&fixture.existing).await?, expected);
        let new_lease = fixture
            .pool
            .acquire("new-after-mutation")
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(agent_projection(&new_lease.agent()).await?, expected);
        drop(new_lease);
        Ok(())
    }

    async fn assert_no_live_generation(fixture: &ModelMutationFixture) -> Result<(), String> {
        let snapshot = fixture.state.config.app_config.read().await;
        assert!(snapshot.model.default_model_id.is_none());
        assert!(snapshot.configured_models.is_empty());
        drop(snapshot);
        assert!(fixture.state.config.active_model_id.read().await.is_empty());

        for handle in [
            fixture.state.connection.agent.clone(),
            fixture.existing.clone(),
            inherited_handle(fixture)?,
        ] {
            let projection = handle
                .read(|agent| {
                    (
                        agent.model_name().to_string(),
                        agent.llm_config().is_none(),
                        agent.llm_client().is_none(),
                    )
                })
                .await;
            assert!(projection.0.is_empty());
            assert!(projection.1);
            assert!(projection.2);
        }

        let new_lease = fixture
            .pool
            .acquire("new-after-model-deactivation")
            .await
            .map_err(|error| error.to_string())?;
        let new_projection = new_lease
            .agent()
            .read(|agent| {
                (
                    agent.model_name().to_string(),
                    agent.llm_config().is_none(),
                    agent.llm_client().is_none(),
                )
            })
            .await;
        assert!(new_projection.0.is_empty());
        assert!(new_projection.1);
        assert!(new_projection.2);
        drop(new_lease);
        Ok(())
    }

    async fn assert_session_generation(
        fixture: &ModelMutationFixture,
        durable_default_id: &str,
        active_model_id: &str,
        runtime_model: &str,
        endpoint: &str,
        context_window: usize,
    ) -> Result<(), String> {
        let snapshot = fixture.state.config.app_config.read().await;
        assert_eq!(
            snapshot.model.default_model_id.as_deref(),
            Some(durable_default_id)
        );
        drop(snapshot);
        assert_eq!(
            fixture.state.config.active_model_id.read().await.as_str(),
            active_model_id
        );
        let expected = AgentModelProjection {
            model: runtime_model.to_string(),
            client_model: runtime_model.to_string(),
            base_url: endpoint.to_string(),
            api_protocol: LlmApiProtocol::ChatCompletions,
            token_limit: context_window,
        };
        assert_eq!(
            agent_projection(&fixture.state.connection.agent).await?,
            expected
        );
        assert_eq!(agent_projection(&fixture.existing).await?, expected);
        let new_lease = fixture
            .pool
            .acquire("new-after-session-mutation")
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(agent_projection(&new_lease.agent()).await?, expected);
        drop(new_lease);
        Ok(())
    }

    async fn assert_full_generation(
        fixture: &ModelMutationFixture,
        model_id: &str,
        runtime_model: &str,
        endpoint: &str,
        context_window: usize,
    ) -> Result<(), String> {
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(persisted.model.default_model_id.as_deref(), Some(model_id));
        assert_live_generation(fixture, model_id, runtime_model, endpoint, context_window).await
    }

    async fn wait_for_pool_model_admission(
        pool: &crate::agent_pool::AgentPool,
    ) -> Result<(), String> {
        tokio::time::timeout(std::time::Duration::from_secs(5), async {
            loop {
                if pool.transition_admission_closed_for_test() {
                    return;
                }
                tokio::task::yield_now().await;
            }
        })
        .await
        .map_err(|_| "timed out waiting for pool model admission".to_string())?;
        Ok(())
    }

    async fn join_mutation(
        handle: tokio::task::JoinHandle<Result<ModelMutationReceipt, ModelMutationError>>,
    ) -> Result<ModelMutationReceipt, String> {
        let joined = tokio::time::timeout(std::time::Duration::from_secs(3), handle)
            .await
            .map_err(|_| "model mutation task timed out".to_string())?;
        let settled = joined.map_err(|error| error.to_string())?;
        settled.map_err(|error| error.to_string())
    }

    async fn invalidate_model_budget(handle: &AgentHandle) {
        let invalid_budget = echo_agent::budget::TokenBudgetConfig::enabled().with_total_window(0);
        handle
            .write(|agent| {
                let config = agent.config();
                let model = config.get_model_name().to_string();
                let name = config.get_agent_name().to_string();
                let prompt = config.get_system_prompt().to_string();
                let token_limit = config.get_token_limit();
                *agent.config_mut() = echo_agent::agent::AgentConfig::new(&model, &name, &prompt)
                    .token_limit(token_limit)
                    .token_budget(invalid_budget);
            })
            .await;
    }

    fn inherited_handle(fixture: &ModelMutationFixture) -> Result<AgentHandle, String> {
        fixture
            .state
            .connection
            .model_consumers
            .as_ref()
            .and_then(|consumers| consumers.inherited_handle_for_test("general-purpose"))
            .ok_or_else(|| "inherit-parent handle was not retained".to_string())
    }

    #[tokio::test]
    async fn production_pool_does_not_reenter_primary_model_lock() -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let receipt = tokio::time::timeout(
            std::time::Duration::from_secs(3),
            fixture.state.set_default_model_owned(MODEL_B),
        )
        .await
        .map_err(|_| {
            "production pool model publication deadlocked on the primary Agent".to_string()
        })?
        .map_err(|error| error.to_string())?;

        assert_eq!(receipt.model_id, MODEL_B);
        assert_full_generation(&fixture, MODEL_B, "runtime-b", ENDPOINT_B, WINDOW_B).await
    }

    #[tokio::test]
    async fn gui_and_tui_model_mutations_share_one_linearized_owner() -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let primary = fixture.state.connection.agent.inner().clone();
        let barrier = primary.write().await;
        let gui_state = fixture.state.clone();
        let gui = tokio::spawn(async move { gui_state.set_default_model_owned(MODEL_B).await });
        wait_for_pool_model_admission(&fixture.pool).await?;

        let tui_state = fixture.state.clone();
        let tui = tokio::spawn(async move { tui_state.set_default_model_owned(MODEL_A).await });
        assert_eq!(
            fixture
                .state
                .config
                .app_config
                .read()
                .await
                .model
                .default_model_id
                .as_deref(),
            Some(MODEL_A)
        );
        drop(barrier);

        let gui_receipt = join_mutation(gui).await?;
        let tui_receipt = join_mutation(tui).await?;
        assert_eq!(gui_receipt.model_id, MODEL_B);
        assert_eq!(tui_receipt.model_id, MODEL_A);
        assert_full_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await
    }

    #[tokio::test]
    async fn active_model_generation_publishes_to_three_loaded_workspace_hosts()
    -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let workspaces = tempfile::tempdir().map_err(|error| error.to_string())?;
        for position in 0..3 {
            let name = format!("model-workspace-{position}");
            let root = workspaces.path().join(&name);
            std::fs::create_dir_all(&root).map_err(|error| error.to_string())?;
            fixture
                .state
                .switch_workspace(Workspace {
                    id: crate::workspace::WorkspaceId::from_name(&name),
                    name,
                    root,
                    project_root: None,
                    kind: crate::workspace::WorkspaceKind::General,
                    metadata: crate::workspace::WorkspaceMetadata::default(),
                    product_data_generation: String::new(),
                    created_at: Utc::now(),
                    last_active: Utc::now(),
                })
                .await
                .map_err(|error| error.to_string())?;
        }
        let runtimes = fixture
            .state
            .workspace
            .runtimes
            .loaded_execution_runtimes()
            .await;
        assert_eq!(runtimes.len(), 3);

        fixture
            .state
            .set_default_model_owned(MODEL_B)
            .await
            .map_err(|error| error.to_string())?;
        let expected = AgentModelProjection {
            model: "runtime-b".to_string(),
            client_model: "runtime-b".to_string(),
            base_url: ENDPOINT_B.to_string(),
            api_protocol: LlmApiProtocol::ChatCompletions,
            token_limit: WINDOW_B,
        };
        for (workspace_id, runtime) in runtimes {
            assert_eq!(agent_projection(&runtime.primary_agent()).await?, expected);
            let lease = runtime
                .pool()
                .acquire(&format!("future-{workspace_id}"))
                .await
                .map_err(|error| error.to_string())?;
            assert_eq!(agent_projection(&lease.agent()).await?, expected);
        }
        assert_full_generation(&fixture, MODEL_B, "runtime-b", ENDPOINT_B, WINDOW_B).await
    }

    #[tokio::test]
    async fn tool_control_generation_reaches_loaded_and_future_workspace_agents()
    -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let primary = fixture.state.connection.primary_agent();
        let tool_name = primary
            .read(|agent| agent.tool_names().into_iter().next())
            .await
            .ok_or_else(|| "tool-control fixture has no registered tool".to_string())?;
        let workspaces = tempfile::tempdir().map_err(|error| error.to_string())?;
        for position in 0..2 {
            let name = format!("tool-workspace-{position}");
            let root = workspaces.path().join(&name);
            std::fs::create_dir_all(&root).map_err(|error| error.to_string())?;
            fixture
                .state
                .switch_workspace(Workspace {
                    id: crate::workspace::WorkspaceId::from_name(&name),
                    name,
                    root,
                    project_root: None,
                    kind: crate::workspace::WorkspaceKind::General,
                    metadata: crate::workspace::WorkspaceMetadata::default(),
                    product_data_generation: String::new(),
                    created_at: Utc::now(),
                    last_active: Utc::now(),
                })
                .await
                .map_err(|error| error.to_string())?;
        }

        let receipt = fixture
            .state
            .set_tool_enabled(&primary, &tool_name, false)
            .await
            .map_err(|error| error.to_string())?;
        assert!(receipt.changed);
        assert_eq!(receipt.revision, 1);
        assert!(!receipt.policy_enabled);
        assert!(!receipt.effective_enabled);
        let listed = fixture
            .state
            .get_tool_infos(&primary)
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            listed
                .iter()
                .any(|tool| tool.name == tool_name && !tool.enabled)
        );
        for handle in [primary.clone(), fixture.existing.clone()] {
            assert!(
                crate::tool_control::snapshot_disabled_tools(&handle)
                    .await
                    .contains(&tool_name)
            );
        }
        let future_global = fixture
            .pool
            .acquire("future-tool-global")
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            crate::tool_control::snapshot_disabled_tools(&future_global.agent())
                .await
                .contains(&tool_name)
        );

        let runtimes = fixture
            .state
            .workspace
            .runtimes
            .loaded_execution_runtimes()
            .await;
        assert_eq!(runtimes.len(), 2);
        for (workspace_id, runtime) in runtimes {
            assert!(
                crate::tool_control::snapshot_disabled_tools(&runtime.primary_agent())
                    .await
                    .contains(&tool_name)
            );
            let future = runtime
                .pool()
                .acquire(&format!("future-tool-{workspace_id}"))
                .await
                .map_err(|error| error.to_string())?;
            assert!(
                crate::tool_control::snapshot_disabled_tools(&future.agent())
                    .await
                    .contains(&tool_name)
            );
        }

        assert!(
            fixture
                .state
                .set_tool_enabled(&primary, "missing-tool", false)
                .await
                .is_err_and(|error| matches!(
                    error,
                    crate::tool_control::ToolControlError::NotRegistered { name }
                        if name == "missing-tool"
                ))
        );
        Ok(())
    }

    #[tokio::test]
    async fn aborted_model_mutation_waiter_does_not_cancel_accepted_settlement()
    -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let primary = fixture.state.connection.agent.inner().clone();
        let barrier = primary.write().await;
        let caller_state = fixture.state.clone();
        let caller =
            tokio::spawn(async move { caller_state.set_default_model_owned(MODEL_B).await });
        wait_for_pool_model_admission(&fixture.pool).await?;
        caller.abort();
        assert!(caller.await.is_err());
        drop(barrier);

        tokio::time::timeout(
            std::time::Duration::from_secs(3),
            fixture.state.shutdown_model_mutations(),
        )
        .await
        .map_err(|_| "model mutation shutdown timed out".to_string())?
        .map_err(|error| error.to_string())?;
        assert_full_generation(&fixture, MODEL_B, "runtime-b", ENDPOINT_B, WINDOW_B).await
    }

    #[tokio::test]
    async fn invalid_default_successor_delete_changes_no_layer() -> Result<(), String> {
        let fixture = fixture(invalid_successor_config()?, false).await?;

        let result = fixture.state.delete_configured_model_owned(MODEL_A).await;

        assert!(matches!(result, Err(ModelMutationError::Validation(_))));
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(persisted.configured_models.len(), 2);
        assert!(
            persisted
                .configured_models
                .iter()
                .any(|model| model.id == MODEL_A)
        );
        assert_live_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await
    }

    #[tokio::test]
    async fn valid_default_successor_delete_settles_all_layers() -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;

        let receipt = fixture
            .state
            .delete_configured_model_owned(MODEL_A)
            .await
            .map_err(|error| error.to_string())?;

        assert!(receipt.deleted);
        assert!(receipt.activated);
        assert!(
            receipt
                .config
                .configured_models
                .iter()
                .all(|model| model.id != MODEL_A)
        );
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert!(
            persisted
                .configured_models
                .iter()
                .all(|model| model.id != MODEL_A)
        );
        assert_full_generation(&fixture, MODEL_B, "runtime-b", ENDPOINT_B, WINDOW_B).await
    }

    #[tokio::test]
    async fn omitted_subagent_model_tracks_parent_while_explicit_model_stays_fixed()
    -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let registry = fixture
            .state
            .connection
            .agent
            .read(|agent| agent.subagent_registry().clone())
            .await;
        let inherited_before = registry
            .get_agent("general-purpose")
            .await
            .ok_or_else(|| "inherit-parent subagent was not registered".to_string())?;
        let fixed_before = registry
            .get_agent("explorer")
            .await
            .ok_or_else(|| "explicit-model subagent was not registered".to_string())?;
        let inherited_handle = fixture
            .state
            .connection
            .model_consumers
            .as_ref()
            .and_then(|consumers| consumers.inherited_handle_for_test("general-purpose"))
            .ok_or_else(|| "inherit-parent handle was not retained".to_string())?;
        let fixed_model = fixed_before.model_name().to_string();
        assert_eq!(inherited_before.model_name(), "runtime-a");

        fixture
            .state
            .set_default_model_owned(MODEL_B)
            .await
            .map_err(|error| error.to_string())?;

        let inherited_after = registry
            .get_agent("general-purpose")
            .await
            .ok_or_else(|| "inherit-parent subagent was not refreshed".to_string())?;
        let fixed_after = registry
            .get_agent("explorer")
            .await
            .ok_or_else(|| "explicit-model subagent disappeared".to_string())?;
        assert_eq!(inherited_after.model_name(), "runtime-b");
        assert_eq!(fixed_after.model_name(), fixed_model);
        assert_eq!(
            agent_projection(&inherited_handle).await?,
            AgentModelProjection {
                model: "runtime-b".to_string(),
                client_model: "runtime-b".to_string(),
                base_url: ENDPOINT_B.to_string(),
                api_protocol: LlmApiProtocol::ChatCompletions,
                token_limit: WINDOW_B,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn model_mutation_preserves_primary_custom_critic() -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let custom = Arc::new(echo_agent::agent::critic::StaticCritic::always_pass());
        fixture
            .state
            .connection
            .agent
            .write(|agent| agent.set_critic(custom.clone()))
            .await;

        fixture
            .state
            .set_default_model_owned(MODEL_B)
            .await
            .map_err(|error| error.to_string())?;

        assert_eq!(Arc::strong_count(&custom), 2);
        assert_eq!(
            fixture
                .state
                .connection
                .agent
                .read(|agent| agent.critic_owner().map(str::to_string))
                .await,
            None
        );
        Ok(())
    }

    #[tokio::test]
    async fn deleting_last_default_deactivates_every_model_consumer() -> Result<(), String> {
        let mut config = valid_config()?;
        config.configured_models.retain(|model| model.id == MODEL_A);
        let fixture = fixture(config, false).await?;

        let receipt = fixture
            .state
            .delete_configured_model_owned(MODEL_A)
            .await
            .map_err(|error| error.to_string())?;

        assert!(receipt.deleted);
        assert!(!receipt.activated);
        assert!(receipt.runtime.is_none());
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert!(persisted.configured_models.is_empty());
        assert!(persisted.model.default_model_id.is_none());
        assert_no_live_generation(&fixture).await
    }

    #[tokio::test]
    async fn deleting_provider_cascades_its_models_and_deactivates_every_consumer()
    -> Result<(), String> {
        let fixture = fixture(shared_provider_config()?, false).await?;

        let receipt = fixture
            .state
            .delete_model_provider_owned("local-shared")
            .await
            .map_err(|error| error.to_string())?;

        assert!(receipt.deleted);
        assert!(!receipt.activated);
        assert!(receipt.config.model_providers.is_empty());
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert!(persisted.model_providers.is_empty());
        assert_no_live_generation(&fixture).await
    }

    #[tokio::test]
    async fn depth_default_publishes_only_after_owned_config_persistence() -> Result<(), String> {
        let next = crate::subagent_policy::SubagentDepthLimit::new(3)?;
        for persistence_fails in [false, true] {
            let fixture = fixture(valid_config()?, persistence_fails).await?;
            let original_revision = fixture.state.config.configuration_snapshot().await.1;
            let original = fixture
                .state
                .config
                .app_config
                .read()
                .await
                .max_subagent_depth;
            let store = fixture
                .state
                .tasks
                .runtime
                .as_ref()
                .ok_or_else(|| "TaskRuntime fixture missing".to_string())?;
            assert_eq!(store.new_execution_subagent_depth(), original);
            let result = fixture
                .state
                .update_app_config_owned(false, move |config| {
                    config.max_subagent_depth = next;
                    Ok(())
                })
                .await;
            let expected = if persistence_fails {
                assert!(matches!(result, Err(ModelMutationError::Persistence(_))));
                original
            } else {
                result.map_err(|error| error.to_string())?;
                assert_eq!(
                    crate::config::load_config_file(&fixture.config_path)?.max_subagent_depth,
                    next
                );
                next
            };
            assert_eq!(
                fixture
                    .state
                    .config
                    .app_config
                    .read()
                    .await
                    .max_subagent_depth,
                expected
            );
            assert_eq!(store.new_execution_subagent_depth(), expected);
            let published_revision = fixture.state.config.configuration_snapshot().await.1;
            if persistence_fails {
                assert_eq!(published_revision, original_revision);
            } else {
                assert_ne!(published_revision, original_revision);
            }
        }
        Ok(())
    }

    #[tokio::test]
    async fn persistence_failure_rolls_back_snapshot_primary_and_pool() -> Result<(), String> {
        let fixture = fixture(valid_config()?, true).await?;

        let result = fixture.state.set_default_model_owned(MODEL_B).await;

        assert!(matches!(result, Err(ModelMutationError::Persistence(_))));
        assert!(fixture.config_path.is_dir());
        assert_live_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await
    }

    #[tokio::test]
    async fn failed_settlement_is_stable_for_later_mutations_and_repeated_shutdown()
    -> Result<(), String> {
        let fixture = fixture(valid_config()?, true).await?;
        let first = fixture
            .state
            .set_default_model_owned(MODEL_B)
            .await
            .err()
            .ok_or_else(|| "persistence unexpectedly succeeded".to_string())?
            .to_string();
        let second = fixture
            .state
            .set_default_model_owned(MODEL_A)
            .await
            .err()
            .ok_or_else(|| "later mutation ignored failed settlement".to_string())?
            .to_string();
        assert_eq!(second, first);

        let first_shutdown = fixture
            .state
            .shutdown_model_mutations()
            .await
            .err()
            .ok_or_else(|| "shutdown lost the settlement failure".to_string())?
            .to_string();
        let second_shutdown = fixture
            .state
            .shutdown_model_mutations()
            .await
            .err()
            .ok_or_else(|| "repeated shutdown lost the settlement failure".to_string())?
            .to_string();
        assert_eq!(first_shutdown, first);
        assert_eq!(second_shutdown, first);
        Ok(())
    }

    #[tokio::test]
    async fn join_error_is_stable_for_later_mutations_and_repeated_shutdown() -> Result<(), String>
    {
        let fixture = fixture(valid_config()?, false).await?;
        let first = fixture
            .state
            .run_owned_model_mutation(ModelMutationRequest::AbortSettlementForTest)
            .await
            .err()
            .ok_or_else(|| "aborted settlement unexpectedly succeeded".to_string())?;
        assert!(matches!(first, ModelMutationError::Settlement(_)));
        let first = first.to_string();

        let later = fixture
            .state
            .set_default_model_owned(MODEL_B)
            .await
            .err()
            .ok_or_else(|| "later mutation ignored JoinError".to_string())?
            .to_string();
        let shutdown = fixture
            .state
            .shutdown_model_mutations()
            .await
            .err()
            .ok_or_else(|| "shutdown lost JoinError".to_string())?
            .to_string();
        let repeated = fixture
            .state
            .shutdown_model_mutations()
            .await
            .err()
            .ok_or_else(|| "repeated shutdown lost JoinError".to_string())?
            .to_string();
        assert_eq!(later, first);
        assert_eq!(shutdown, first);
        assert_eq!(repeated, first);
        Ok(())
    }

    #[tokio::test]
    async fn later_pool_agent_prepare_failure_changes_no_layer() -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let failing_lease = fixture
            .pool
            .acquire("z-failing")
            .await
            .map_err(|error| error.to_string())?;
        let failing = failing_lease.agent();
        drop(failing_lease);
        invalidate_model_budget(&failing).await;

        let result = fixture.state.set_default_model_owned(MODEL_B).await;

        assert!(matches!(result, Err(ModelMutationError::Publication(_))));
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(persisted.model.default_model_id.as_deref(), Some(MODEL_A));
        assert_eq!(
            agent_projection(&failing).await?,
            AgentModelProjection {
                model: "runtime-a".to_string(),
                client_model: "runtime-a".to_string(),
                base_url: ENDPOINT_A.to_string(),
                api_protocol: LlmApiProtocol::ChatCompletions,
                token_limit: WINDOW_A,
            }
        );
        assert_live_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await
    }

    #[tokio::test]
    async fn inherited_subagent_prepare_failure_changes_no_layer() -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let inherited = fixture
            .state
            .connection
            .model_consumers
            .as_ref()
            .and_then(|consumers| consumers.inherited_handle_for_test("general-purpose"))
            .ok_or_else(|| "inherit-parent handle was not retained".to_string())?;
        invalidate_model_budget(&inherited).await;

        let result = fixture.state.set_default_model_owned(MODEL_B).await;

        assert!(matches!(result, Err(ModelMutationError::Publication(_))));
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(persisted.model.default_model_id.as_deref(), Some(MODEL_A));
        assert_eq!(
            agent_projection(&inherited).await?,
            AgentModelProjection {
                model: "runtime-a".to_string(),
                client_model: "runtime-a".to_string(),
                base_url: ENDPOINT_A.to_string(),
                api_protocol: LlmApiProtocol::ChatCompletions,
                token_limit: WINDOW_A,
            }
        );
        assert_live_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await
    }

    #[tokio::test]
    async fn zero_context_window_is_rejected_before_persistence_or_publication()
    -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let mutation = ConfiguredModelMutation {
            model: model(MODEL_A, "local-a", "runtime-a", 0),
            set_default: false,
        };

        let result = fixture.state.upsert_configured_model_owned(mutation).await;

        assert!(matches!(result, Err(ModelMutationError::Validation(_))));
        assert_full_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await
    }

    #[tokio::test]
    async fn provider_upsert_refreshes_active_generation_when_provider_is_shared()
    -> Result<(), String> {
        let fixture = fixture(shared_provider_config()?, false).await?;
        let inherited = inherited_handle(&fixture)?;
        let receipt = fixture
            .state
            .upsert_model_provider_owned(provider_mutation("local-shared", ENDPOINT_B))
            .await
            .map_err(|error| error.to_string())?;

        assert!(receipt.activated);
        assert_eq!(receipt.model_id, "local-shared");
        assert_eq!(
            receipt.runtime.as_ref().map(|runtime| runtime.id.as_str()),
            Some(MODEL_A)
        );
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(persisted.model.default_model_id.as_deref(), Some(MODEL_A));
        assert_eq!(
            persisted
                .model_providers
                .get("local-shared")
                .and_then(|provider| provider.base_url.as_deref()),
            Some(ENDPOINT_B)
        );
        assert_eq!(
            fixture
                .state
                .config
                .app_config
                .read()
                .await
                .model_providers
                .get("local-shared")
                .and_then(|provider| provider.base_url.as_deref()),
            Some(ENDPOINT_B)
        );
        assert_full_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_B, WINDOW_A).await?;
        assert_eq!(
            agent_projection(&inherited).await?,
            AgentModelProjection {
                model: "runtime-a".to_string(),
                client_model: "runtime-a".to_string(),
                base_url: ENDPOINT_B.to_string(),
                api_protocol: LlmApiProtocol::ChatCompletions,
                token_limit: WINDOW_A,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn session_override_stays_active_when_its_shared_provider_changes() -> Result<(), String>
    {
        let fixture = fixture_with_active(shared_provider_config()?, false, MODEL_B).await?;
        let receipt = fixture
            .state
            .upsert_model_provider_owned(provider_mutation("local-shared", ENDPOINT_C))
            .await
            .map_err(|error| error.to_string())?;

        assert!(receipt.activated);
        assert_eq!(receipt.model_id, "local-shared");
        assert_eq!(
            receipt.runtime.as_ref().map(|runtime| runtime.id.as_str()),
            Some(MODEL_B)
        );
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(persisted.model.default_model_id.as_deref(), Some(MODEL_A));
        assert_session_generation(
            &fixture,
            MODEL_A,
            MODEL_B,
            "runtime-b",
            ENDPOINT_C,
            WINDOW_B,
        )
        .await
    }

    #[tokio::test]
    async fn deleting_session_override_reactivates_the_durable_default() -> Result<(), String> {
        let fixture = fixture_with_active(valid_config()?, false, MODEL_B).await?;

        let receipt = fixture
            .state
            .delete_configured_model_owned(MODEL_B)
            .await
            .map_err(|error| error.to_string())?;

        assert!(receipt.activated);
        assert!(receipt.deleted);
        assert_eq!(
            receipt.runtime.as_ref().map(|runtime| runtime.id.as_str()),
            Some(MODEL_A)
        );
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(persisted.model.default_model_id.as_deref(), Some(MODEL_A));
        assert!(
            persisted
                .configured_models
                .iter()
                .all(|model| model.id != MODEL_B)
        );
        assert_session_generation(
            &fixture,
            MODEL_A,
            MODEL_A,
            "runtime-a",
            ENDPOINT_A,
            WINDOW_A,
        )
        .await
    }

    #[tokio::test]
    async fn invalid_shared_provider_upsert_rolls_back_every_layer() -> Result<(), String> {
        let fixture = fixture(shared_provider_config()?, false).await?;
        let inherited = inherited_handle(&fixture)?;
        let mut mutation = provider_mutation("local-shared", RESPONSES_ENDPOINT);
        mutation.provider.auth_token = Some("invalid\nheader".to_string());
        let result = fixture.state.upsert_model_provider_owned(mutation).await;

        assert!(matches!(result, Err(ModelMutationError::Validation(_))));
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(
            persisted
                .model_providers
                .get("local-shared")
                .and_then(|provider| provider.base_url.as_deref()),
            Some(ENDPOINT_A)
        );
        assert_eq!(
            fixture
                .state
                .config
                .app_config
                .read()
                .await
                .model_providers
                .get("local-shared")
                .and_then(|provider| provider.base_url.as_deref()),
            Some(ENDPOINT_A)
        );
        assert_full_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await?;
        assert_eq!(
            agent_projection(&inherited).await?,
            AgentModelProjection {
                model: "runtime-a".to_string(),
                client_model: "runtime-a".to_string(),
                base_url: ENDPOINT_A.to_string(),
                api_protocol: LlmApiProtocol::ChatCompletions,
                token_limit: WINDOW_A,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn unrelated_provider_upsert_remains_persistence_only() -> Result<(), String> {
        let fixture = fixture(valid_config()?, false).await?;
        let inherited = inherited_handle(&fixture)?;
        invalidate_model_budget(&fixture.state.connection.agent).await;
        let receipt = fixture
            .state
            .upsert_model_provider_owned(provider_mutation("local-b", ENDPOINT_C))
            .await
            .map_err(|error| error.to_string())?;

        assert!(!receipt.activated);
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert_eq!(persisted.model.default_model_id.as_deref(), Some(MODEL_A));
        assert_eq!(
            persisted
                .model_providers
                .get("local-b")
                .and_then(|provider| provider.base_url.as_deref()),
            Some(ENDPOINT_C)
        );
        assert_eq!(
            fixture
                .state
                .config
                .app_config
                .read()
                .await
                .model_providers
                .get("local-b")
                .and_then(|provider| provider.base_url.as_deref()),
            Some(ENDPOINT_C)
        );
        assert_live_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await?;
        assert_eq!(
            agent_projection(&inherited).await?,
            AgentModelProjection {
                model: "runtime-a".to_string(),
                client_model: "runtime-a".to_string(),
                base_url: ENDPOINT_A.to_string(),
                api_protocol: LlmApiProtocol::ChatCompletions,
                token_limit: WINDOW_A,
            }
        );
        Ok(())
    }

    #[tokio::test]
    async fn deleting_non_default_commits_without_reapplying_active_runtime() -> Result<(), String>
    {
        let fixture = fixture(valid_config()?, false).await?;

        let receipt = fixture
            .state
            .delete_configured_model_owned(MODEL_B)
            .await
            .map_err(|error| error.to_string())?;

        assert!(receipt.deleted);
        assert!(!receipt.activated);
        assert!(receipt.runtime.is_none());
        let persisted = crate::config::load_config_file(&fixture.config_path)?;
        assert!(
            persisted
                .configured_models
                .iter()
                .all(|model| model.id != MODEL_B)
        );
        assert_full_generation(&fixture, MODEL_A, "runtime-a", ENDPOINT_A, WINDOW_A).await
    }
}

#[cfg(test)]
mod side_conversation_lifecycle_tests {
    use super::*;
    use echo_agent::agent::ReactAgentBuilder;
    use echo_agent::memory::{ConversationStore, FileConversationStore, NewConversation};
    use echo_agent::testing::MockLlmClient;

    const WORKSPACE_ID: &str = "global";

    struct Fixture {
        _temp: tempfile::TempDir,
        state: Arc<AppState>,
        store: Arc<dyn ConversationStore>,
        deletions: Arc<crate::conversation_deletion::ConversationDeletionService>,
    }

    async fn fixture() -> Result<Fixture, String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let store: Arc<dyn ConversationStore> = Arc::new(
            FileConversationStore::new(temp.path().join("conversations"))
                .map_err(|error| error.to_string())?,
        );
        let runtime_state: Arc<dyn echo_agent::state::RuntimeStateStore> = Arc::new(
            echo_agent::state::FileRuntimeStateStore::new(temp.path().join("runtime-state"))
                .map_err(|error| error.to_string())?,
        );
        let primary = ReactAgentBuilder::new()
            .llm_client(Arc::new(
                MockLlmClient::new().with_responses(["side answer"]),
            ))
            .system_prompt("Side Conversation lifecycle test")
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())?;
        let pool = Arc::new(
            crate::agent_pool::AgentPool::new_for_test(primary.clone(), None, None, 4, false).await,
        );
        pool.apply_conversation_store(Arc::clone(&store)).await;
        pool.apply_state_store(Arc::clone(&runtime_state)).await;
        let mcp = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            temp.path().join("mcp.json"),
            Default::default(),
        ));
        let mut state = AppState::from_shared(
            primary,
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            Some(Arc::clone(&store)),
            Some(Arc::clone(&runtime_state)),
            Default::default(),
            mcp,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?
        .with_agent_router(Arc::new(crate::agent_router::AgentRouter::new(
            temp.path().join("agent-router"),
        )));
        let deletions = Arc::new(
            crate::conversation_deletion::ConversationDeletionService::new(
                temp.path().join("conversation-deletions"),
            ),
        );
        {
            let mut binding = state.storage.conversation.write().await;
            binding.deletions = Arc::clone(&deletions);
        }
        state.workspace.global_conversation.deletions = Arc::clone(&deletions);
        state.storage.conversation_archive = Arc::new(
            crate::conversation_archive::ConversationArchiveStore::open(
                temp.path().join("conversation-archive.json"),
            )
            .map_err(|error| error.to_string())?,
        );
        state.storage.tool_executions = Arc::new(
            crate::tool_execution::ToolExecutionRepository::open(temp.path().join("tools"))
                .map_err(|error| error.to_string())?,
        );
        state.storage.chat_events = Arc::new(
            crate::chat_event_log::ChatEventLog::open(
                temp.path().join("chat-events"),
                Default::default(),
            )
            .map_err(|error| error.to_string())?,
        );
        state.set_pool(pool);
        Ok(Fixture {
            _temp: temp,
            state: Arc::new(state),
            store,
            deletions,
        })
    }

    async fn create_primary(store: &dyn ConversationStore, id: &str) -> Result<(), String> {
        store
            .ensure_projection_epoch(echo_agent::memory::EnsureConversationProjectionRequest {
                conversation: NewConversation {
                    conversation_id: id.to_string(),
                    user_id: "eko".to_string(),
                    agent_type: None,
                    title: Some("Main".to_string()),
                },
                expected_tombstone_epoch: None,
            })
            .await
            .map(|_| ())
            .map_err(|error| error.to_string())
    }

    fn side_request(
        parent: &str,
        request_id: &str,
    ) -> crate::side_conversation::SideConversationCreateRequest {
        crate::side_conversation::SideConversationCreateRequest {
            workspace_id: WORKSPACE_ID.to_string(),
            parent_conversation_id: parent.to_string(),
            request_id: request_id.to_string(),
            prompt: "Investigate the alternative".to_string(),
            title: Some("Alternative".to_string()),
            model_id: None,
        }
    }

    fn settle_when_cancelled(
        lease: crate::foreground_turn::ForegroundTurnLease,
    ) -> tokio::task::JoinHandle<Result<(), String>> {
        tokio::spawn(async move {
            lease.cancellation_token().cancelled().await;
            lease
                .settle_after_observers(crate::chat_driver::TurnOutcome::Cancelled)
                .await
                .map(|_| ())
                .map_err(|error| error.to_string())
        })
    }

    #[tokio::test]
    async fn side_snapshot_rejects_unsettled_internal_turn() -> Result<(), String> {
        let fixture = fixture().await?;
        create_primary(fixture.store.as_ref(), "main").await?;
        let authority = fixture
            .store
            .get_projection_authority("main")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "parent authority missing".to_string())?;
        fixture
            .state
            .storage
            .conversation_archive
            .prepare_internal_turn(
                WORKSPACE_ID,
                "main",
                authority.epoch,
                "pending-side-delivery",
                0,
                "internal turn",
            )?;
        let result = fixture
            .state
            .create_side_conversation_owned(side_request("main", "unsettled-parent"))
            .await;
        assert!(result.is_err());
        assert!(
            fixture
                .store
                .get_conversation(
                    &crate::side_conversation::SideConversationService::child_id_for_request(
                        &side_request("main", "unsettled-parent"),
                    )
                    .map_err(|error| error.to_string())?
                )
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        Ok(())
    }

    #[tokio::test]
    async fn side_snapshot_retries_when_internal_turn_commits_between_reads() -> Result<(), String>
    {
        let fixture = fixture().await?;
        create_primary(fixture.store.as_ref(), "main").await?;
        let authority = fixture
            .store
            .get_projection_authority("main")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "parent authority missing".to_string())?;
        let (entered_tx, entered_rx) = tokio::sync::oneshot::channel();
        let (release_tx, release_rx) = tokio::sync::oneshot::channel();
        *fixture.state.side_snapshot_barrier.lock().await = Some((entered_tx, release_rx));
        let request = side_request("main", "commit-during-snapshot");
        let creating_state = Arc::clone(&fixture.state);
        let creation =
            tokio::spawn(
                async move { creating_state.create_side_conversation_owned(request).await },
            );
        entered_rx
            .await
            .map_err(|_| "snapshot did not reach barrier".to_string())?;
        fixture
            .state
            .storage
            .conversation_archive
            .prepare_internal_turn(
                WORKSPACE_ID,
                "main",
                authority.epoch,
                "racing-internal",
                0,
                "internal turn",
            )?;
        fixture
            .store
            .apply_transcript_projection(
                echo_agent::memory::TranscriptProjectionBatch::prepare(
                    "main",
                    authority.epoch,
                    "racing-internal",
                    0,
                    vec![echo_agent::memory::StoredMessage {
                        id: None,
                        conversation_id: "main".to_string(),
                        role: "user".to_string(),
                        content: Some("internal turn".to_string()),
                        attachments_json: None,
                        tool_calls_json: None,
                        tool_result_json: None,
                        created_at: chrono::Utc::now().to_rfc3339(),
                    }],
                )
                .map_err(|error| error.to_string())?,
            )
            .await
            .map_err(|error| error.to_string())?;
        let parent = fixture
            .store
            .get_messages("main")
            .await
            .map_err(|error| error.to_string())?;
        let hidden = parent.iter().filter_map(|row| row.id).collect();
        fixture
            .state
            .storage
            .conversation_archive
            .settle_internal_turn(WORKSPACE_ID, "main", "racing-internal", hidden)?;
        release_tx
            .send(())
            .map_err(|_| "snapshot barrier closed".to_string())?;
        let created = creation.await.map_err(|error| error.to_string())??;
        let child_rows = fixture
            .store
            .get_messages(&created.creation.entry.conversation_id)
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            child_rows.is_empty(),
            "internal turn entered the child snapshot"
        );
        Ok(())
    }

    #[tokio::test]
    async fn active_child_delete_and_parent_cascade_cancel_and_aggregate_cleanup()
    -> Result<(), String> {
        let fixture = fixture().await?;
        create_primary(fixture.store.as_ref(), "main").await?;
        let direct = fixture
            .state
            .create_side_conversation_owned(side_request("main", "direct-child"))
            .await?;
        let direct_child = direct.creation.entry.conversation_id.clone();
        drop(direct);
        fixture
            .state
            .storage
            .chat_events
            .append(
                WORKSPACE_ID,
                Some(&direct_child),
                "later-turn",
                crate::chat_driver::ChatDriverEvent::TurnStatus {
                    status: "failed".to_string(),
                },
            )
            .map_err(|error| error.to_string())?;
        assert_eq!(
            fixture
                .state
                .list_side_conversations_scoped(WORKSPACE_ID)
                .await?
                .first()
                .map(|entry| entry.status),
            Some(crate::side_conversation::SideConversationStatus::Failed)
        );
        let direct_lease = fixture
            .state
            .session
            .foreground_turns
            .begin_scoped(
                WORKSPACE_ID,
                crate::foreground_turn::ForegroundTurnSurface::Gui,
                &direct_child,
                "direct-turn",
            )
            .map_err(|error| error.to_string())?;
        let direct_settlement = settle_when_cancelled(direct_lease);
        fixture
            .state
            .delete_conversation_scoped(WORKSPACE_ID, &direct_child)
            .await
            .map_err(|error| error.to_string())?;
        direct_settlement
            .await
            .map_err(|error| error.to_string())??;
        assert!(
            fixture
                .store
                .get_conversation("main")
                .await
                .map_err(|error| error.to_string())?
                .is_some()
        );

        let cascading = fixture
            .state
            .create_side_conversation_owned(side_request("main", "cascade-child"))
            .await?;
        let cascading_child = cascading.creation.entry.conversation_id.clone();
        drop(cascading);
        let cascading_lease = fixture
            .state
            .session
            .foreground_turns
            .begin_scoped(
                WORKSPACE_ID,
                crate::foreground_turn::ForegroundTurnSurface::Gui,
                &cascading_child,
                "cascade-turn",
            )
            .map_err(|error| error.to_string())?;
        assert_eq!(
            fixture
                .state
                .list_side_conversations_scoped(WORKSPACE_ID)
                .await?
                .first()
                .map(|entry| entry.status),
            Some(crate::side_conversation::SideConversationStatus::Running)
        );
        let cascading_settlement = settle_when_cancelled(cascading_lease);
        fixture.deletions.fail_next_tombstone_retirement_for_test();
        let receipt = fixture
            .state
            .delete_conversation_scoped(WORKSPACE_ID, "main")
            .await
            .map_err(|error| error.to_string())?;
        cascading_settlement
            .await
            .map_err(|error| error.to_string())??;
        assert!(receipt.cleanup_pending);
        assert!(
            fixture
                .store
                .get_conversation("main")
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            fixture
                .store
                .get_conversation(&cascading_child)
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            fixture
                .state
                .list_side_conversations_scoped(WORKSPACE_ID)
                .await?
                .is_empty()
        );
        Ok(())
    }

    #[tokio::test]
    async fn parent_delete_serializes_with_side_creation_and_leaves_no_orphan() -> Result<(), String>
    {
        let fixture = fixture().await?;
        create_primary(fixture.store.as_ref(), "main").await?;
        let (entered_tx, entered_rx) = tokio::sync::oneshot::channel();
        let (release_tx, release_rx) = tokio::sync::oneshot::channel();
        fixture
            .deletions
            .install_before_lineage_barrier(entered_tx, release_rx);
        let deleting_state = Arc::clone(&fixture.state);
        let deleting = tokio::spawn(async move {
            deleting_state
                .delete_conversation_scoped(WORKSPACE_ID, "main")
                .await
        });
        entered_rx
            .await
            .map_err(|_| "parent deletion did not reach its identity barrier".to_string())?;

        let request = side_request("main", "racing-child");
        let child_id =
            crate::side_conversation::SideConversationService::child_id_for_request(&request)
                .map_err(|error| error.to_string())?;
        let creating_state = Arc::clone(&fixture.state);
        let mut creating =
            tokio::spawn(
                async move { creating_state.create_side_conversation_owned(request).await },
            );
        assert!(
            tokio::time::timeout(std::time::Duration::from_millis(50), &mut creating)
                .await
                .is_err(),
            "side creation passed the parent identity guard"
        );
        release_tx
            .send(())
            .map_err(|_| "parent deletion barrier closed early".to_string())?;
        deleting
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        let create_result = creating.await.map_err(|error| error.to_string())?;
        assert!(create_result.is_err());
        assert!(
            fixture
                .store
                .get_conversation(&child_id)
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            fixture
                .state
                .list_side_conversations_scoped(WORKSPACE_ID)
                .await?
                .is_empty()
        );
        Ok(())
    }

    #[tokio::test]
    async fn first_gui_turn_admission_closes_the_post_create_delete_window() -> Result<(), String> {
        let fixture = fixture().await?;
        create_primary(fixture.store.as_ref(), "main").await?;
        let preparation = fixture
            .state
            .create_side_conversation_owned(side_request("main", "first-turn-race"))
            .await?;
        let child_id = preparation.creation.entry.conversation_id.clone();

        let deleting_state = Arc::clone(&fixture.state);
        let child_for_delete = child_id.clone();
        let mut deleting = tokio::spawn(async move {
            deleting_state
                .delete_conversation_scoped(WORKSPACE_ID, &child_for_delete)
                .await
        });
        assert!(
            tokio::time::timeout(std::time::Duration::from_millis(50), &mut deleting)
                .await
                .is_err(),
            "child deletion passed the retained first-turn admission identity"
        );

        let lease = fixture
            .state
            .begin_side_conversation_gui_turn(preparation.admission, "side-start:first-turn-race")
            .await
            .map_err(|error| error.to_string())?;
        let settlement = settle_when_cancelled(lease);
        let receipt = deleting
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        settlement.await.map_err(|error| error.to_string())??;

        assert!(!receipt.cleanup_pending);
        assert!(
            fixture
                .store
                .get_conversation(&child_id)
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            fixture
                .state
                .list_side_conversations_scoped(WORKSPACE_ID)
                .await?
                .is_empty()
        );
        Ok(())
    }
}

#[cfg(test)]
mod workspace_transition_tests {
    use super::*;
    use echo_agent::agent::ReactAgentBuilder;
    use echo_agent::llm::{ChatChunk, ChatRequest, ChatResponse, LlmClient};
    use echo_agent::memory::{ConversationStore, FileConversationStore, StoredMessage};
    use echo_agent::testing::MockLlmClient;

    /// Keep the real streaming turn open until the live delivery owns a mailbox receipt.
    /// A fixed provider delay can expire before injection under full-suite load.
    struct ParkedReplyClient {
        inner: MockLlmClient,
        entered: tokio::sync::Notify,
        release: CancellationToken,
    }

    impl LlmClient for ParkedReplyClient {
        fn chat(
            &self,
            request: ChatRequest,
        ) -> futures::future::BoxFuture<'_, echo_agent::error::Result<ChatResponse>> {
            self.inner.chat(request)
        }

        fn chat_stream(
            &self,
            request: ChatRequest,
        ) -> futures::future::BoxFuture<
            '_,
            echo_agent::error::Result<
                futures::stream::BoxStream<'static, echo_agent::error::Result<ChatChunk>>,
            >,
        > {
            Box::pin(async move {
                self.entered.notify_one();
                self.release.cancelled().await;
                self.inner.chat_stream(request).await
            })
        }

        fn model_name(&self) -> &str {
            self.inner.model_name()
        }
    }

    struct ParkedWorkspaceDeleteHook {
        browser: Arc<crate::browser::BrowserRuntime>,
        entered: tokio::sync::Mutex<Option<tokio::sync::oneshot::Sender<()>>>,
        release: tokio::sync::Mutex<Option<tokio::sync::oneshot::Receiver<()>>>,
        calls: tokio::sync::Mutex<Vec<String>>,
    }

    impl ParkedWorkspaceDeleteHook {
        fn new(
            browser: Arc<crate::browser::BrowserRuntime>,
        ) -> (
            Arc<Self>,
            tokio::sync::oneshot::Receiver<()>,
            tokio::sync::oneshot::Sender<()>,
        ) {
            let (entered_tx, entered_rx) = tokio::sync::oneshot::channel();
            let (release_tx, release_rx) = tokio::sync::oneshot::channel();
            (
                Arc::new(Self {
                    browser,
                    entered: tokio::sync::Mutex::new(Some(entered_tx)),
                    release: tokio::sync::Mutex::new(Some(release_rx)),
                    calls: tokio::sync::Mutex::new(Vec::new()),
                }),
                entered_rx,
                release_tx,
            )
        }
    }

    #[async_trait::async_trait]
    impl WorkspaceDeleteHook for ParkedWorkspaceDeleteHook {
        async fn remove_workspace(&self, workspace_id: &str) -> anyhow::Result<()> {
            self.browser.remove_workspace(workspace_id).await;
            self.calls.lock().await.push(workspace_id.to_string());
            if let Some(entered) = self.entered.lock().await.take() {
                let _ = entered.send(());
            }
            let release = self.release.lock().await.take();
            if let Some(release) = release {
                release
                    .await
                    .map_err(|_| anyhow::anyhow!("workspace delete hook release was dropped"))?;
            }
            Ok(())
        }
    }

    #[tokio::test]
    async fn workspace_delete_hook_settles_before_same_id_recreation() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let old_root = temp.path().join("old-workspace");
        let new_root = temp.path().join("new-workspace");
        std::fs::create_dir_all(&old_root).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&new_root).map_err(|error| error.to_string())?;
        let primary = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("workspace delete hook test")
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())?;
        let mcp = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            temp.path().join("mcp.json"),
            Default::default(),
        ));
        let registry = Arc::new(
            WorkspaceRegistry::with_base_dir(temp.path().join("registry"))
                .map_err(|error| error.to_string())?,
        );
        let browser = crate::browser::BrowserRuntime::start(crate::browser::BrowserConfig {
            enabled: false,
            extension_enabled: false,
            session_dir: temp.path().join("browser-sessions"),
            ..Default::default()
        })
        .await;
        let (hook, hook_entered, hook_release) = ParkedWorkspaceDeleteHook::new(browser.clone());
        let mut state = AppState::from_shared(
            primary,
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            mcp,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?
        .with_workspace_delete_hook(hook.clone());
        state.workspace.registry = registry.clone();
        state.storage.chat_events = Arc::new(
            crate::chat_event_log::ChatEventLog::open(
                temp.path().join("chat-events"),
                crate::chat_event_log::ChatEventRetention::default(),
            )
            .map_err(|error| error.to_string())?,
        );
        state.storage.tool_executions = Arc::new(
            crate::tool_execution::ToolExecutionRepository::open(
                temp.path().join("tool-executions"),
            )
            .map_err(|error| error.to_string())?,
        );
        let state = Arc::new(state);
        let (old_workspace, created) = state
            .create_workspace_owned(
                "same-id",
                crate::workspace::WorkspaceKind::General,
                Some(old_root),
            )
            .await
            .map_err(|error| error.to_string())?;
        assert!(created);
        let old_address = crate::browser::BrowserApprovalAddress::new(
            old_workspace.id.as_str(),
            "old-conversation",
        );
        let provider: Arc<dyn echo_agent::human_loop::HumanLoopProvider> =
            Arc::new(crate::hitl::HitlDispatcher::new());
        let _old_registration = browser
            .register_approval_provider(
                old_address.clone(),
                old_workspace.root.clone(),
                provider.clone(),
            )
            .await;
        let _old_lease = browser
            .session_manager()
            .lease_tab(&old_address, crate::browser::MAIN_TAB_OWNER, None)
            .await;
        assert_eq!(
            browser
                .workspace_projection_counts_for_test(old_workspace.id.as_str())
                .await,
            (1, 1, 1)
        );

        let delete_state = Arc::clone(&state);
        let workspace_id = old_workspace.id.clone();
        let delete =
            tokio::spawn(async move { delete_state.delete_workspace_owned(&workspace_id).await });
        hook_entered
            .await
            .map_err(|_| "workspace delete hook was not reached".to_string())?;
        assert!(registry.open(&old_workspace.id).is_ok());
        assert_eq!(
            browser
                .workspace_projection_counts_for_test(old_workspace.id.as_str())
                .await,
            (0, 0, 0)
        );

        let create_state = Arc::clone(&state);
        let recreate = tokio::spawn(async move {
            create_state
                .create_workspace_owned(
                    "same-id",
                    crate::workspace::WorkspaceKind::General,
                    Some(new_root),
                )
                .await
        });
        tokio::task::yield_now().await;
        assert!(!recreate.is_finished());
        hook_release
            .send(())
            .map_err(|_| "workspace delete hook release receiver was dropped".to_string())?;
        delete
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        let (recreated, created) = recreate
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        assert!(created);
        assert_eq!(recreated.id, old_workspace.id);
        assert_eq!(
            registry
                .open(&recreated.id)
                .map_err(|error| error.to_string())?
                .root,
            recreated.root
        );
        state
            .switch_workspace_registered(recreated.id.clone())
            .await
            .map_err(|error| error.to_string())?;
        let new_address =
            crate::browser::BrowserApprovalAddress::new(recreated.id.as_str(), "new-conversation");
        let _new_registration = browser
            .register_approval_provider(new_address.clone(), recreated.root.clone(), provider)
            .await;
        let _new_lease = browser
            .session_manager()
            .lease_tab(&new_address, crate::browser::MAIN_TAB_OWNER, None)
            .await;
        assert_eq!(
            browser
                .workspace_projection_counts_for_test(recreated.id.as_str())
                .await,
            (1, 1, 1)
        );
        let current_root = state
            .current_workspace()
            .await
            .map(|workspace| workspace.root)
            .ok_or_else(|| "recreated workspace was not focused".to_string())?
            .canonicalize()
            .map_err(|error| error.to_string())?;
        let recreated_root = recreated
            .root
            .canonicalize()
            .map_err(|error| error.to_string())?;
        assert_eq!(current_root, recreated_root);
        assert_eq!(hook.calls.lock().await.as_slice(), &["same-id".to_string()]);
        Ok(())
    }

    #[tokio::test]
    async fn workspace_delete_drains_driver_before_taking_transition_write() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("workspace");
        std::fs::create_dir_all(&root).map_err(|error| error.to_string())?;
        let primary = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("workspace delete lock order")
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())?;
        let mcp = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            temp.path().join("mcp.json"),
            Default::default(),
        ));
        let registry = Arc::new(
            WorkspaceRegistry::with_base_dir(temp.path().join("registry"))
                .map_err(|error| error.to_string())?,
        );
        let mut state = AppState::from_shared(
            primary,
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            mcp,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?;
        state.workspace.registry = registry.clone();
        state.storage.chat_events = Arc::new(
            crate::chat_event_log::ChatEventLog::open(
                temp.path().join("chat-events"),
                crate::chat_event_log::ChatEventRetention::default(),
            )
            .map_err(|error| error.to_string())?,
        );
        state.storage.tool_executions = Arc::new(
            crate::tool_execution::ToolExecutionRepository::open(
                temp.path().join("tool-executions"),
            )
            .map_err(|error| error.to_string())?,
        );
        state.agent_router = Arc::new(crate::agent_router::AgentRouter::new(
            temp.path().join("agent-router"),
        ));
        let state = Arc::new(state);
        let (workspace, _) = state
            .create_workspace_owned(
                "lock-order",
                crate::workspace::WorkspaceKind::General,
                Some(root),
            )
            .await
            .map_err(|error| error.to_string())?;
        let transition_write = state.workspace.transition.write().await;
        let driver_entered = Arc::new(tokio::sync::Notify::new());
        let driver_read = Arc::new(tokio::sync::Notify::new());
        let entered = Arc::clone(&driver_entered);
        let read = Arc::clone(&driver_read);
        let driver_state = Arc::clone(&state);
        let target =
            crate::agent_router::AgentAddress::new(workspace.id.clone(), "delivery-conversation");
        state
            .agent_deliveries
            .supervise(target, Arc::new(|_| {}), move |cycle| async move {
                entered.notify_one();
                let _transition_read = driver_state.workspace.transition.read().await;
                read.notify_one();
                let _ = cycle.complete();
            })
            .map_err(|error| error.to_string())?;
        driver_entered.notified().await;
        let delete_state = Arc::clone(&state);
        let delete_workspace_id = workspace.id.clone();
        let deleting = tokio::spawn(async move {
            delete_state
                .delete_workspace_owned(&delete_workspace_id)
                .await
        });
        tokio::task::yield_now().await;
        assert!(!deleting.is_finished());
        drop(transition_write);
        tokio::time::timeout(std::time::Duration::from_secs(1), driver_read.notified())
            .await
            .map_err(|_| "delivery driver never acquired transition read".to_string())?;
        tokio::time::timeout(std::time::Duration::from_secs(2), deleting)
            .await
            .map_err(|_| "workspace deletion deadlocked behind delivery drain".to_string())?
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        assert!(registry.open(&workspace.id).is_err());
        Ok(())
    }

    #[tokio::test]
    async fn agent_group_target_resolver_acquires_remote_host_and_rejects_drift()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let registry = Arc::new(
            WorkspaceRegistry::with_base_dir(temp.path().join("workspaces"))
                .map_err(|error| error.to_string())?,
        );
        let source_workspace = registry
            .create_at(
                "source",
                crate::workspace::WorkspaceKind::General,
                temp.path().join("source"),
            )
            .map_err(|error| error.to_string())?;
        let target_workspace = registry
            .create_at(
                "target",
                crate::workspace::WorkspaceKind::General,
                temp.path().join("target"),
            )
            .map_err(|error| error.to_string())?;
        let primary = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("Agent group target resolver test")
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())?;
        let seed_pool = Arc::new(
            crate::agent_pool::AgentPool::new_for_test(primary, None, None, 4, false).await,
        );
        let runtimes = Arc::new(crate::workspace::runtime::WorkspaceRuntimeRegistry::new());
        let target_host = runtimes
            .get_or_open(target_workspace.clone())
            .await
            .map_err(|error| error.to_string())?;
        target_host
            .resources()
            .conversation_store()
            .ensure_conversation(NewConversation {
                conversation_id: "target-conversation".to_string(),
                user_id: "default".to_string(),
                agent_type: None,
                title: Some("Target".to_string()),
            })
            .await
            .map_err(|error| error.to_string())?;

        let router = Arc::new(crate::agent_router::AgentRouter::new(
            temp.path().join("router"),
        ));
        let leader = crate::agent_router::AgentAddress::new(
            source_workspace.id.clone(),
            "source-conversation",
        );
        let member_address = crate::agent_router::AgentAddress::new(
            target_workspace.id.clone(),
            "target-conversation",
        );
        let group = router
            .create_group(
                "Research group",
                leader.clone(),
                vec![crate::agent_router::AgentGroupMember {
                    address: member_address.clone(),
                    subagent_role: "explorer".to_string(),
                    label: None,
                }],
            )
            .await
            .map_err(|error| error.to_string())?;
        let resolver = WorkspaceTaskExecutionTargetResolver {
            workspace_registry: registry,
            runtimes: Arc::downgrade(&runtimes),
            seed_pool: Arc::downgrade(&seed_pool),
            agent_router: router,
        };
        let mut target = crate::tasks::task_runtime::TaskExecutionTarget {
            group_id: group.group_id,
            subagent_role: "explorer".to_string(),
            address: member_address,
            project_binding: None,
        };
        target.project_binding =
            crate::tasks::task_runtime::TaskExecutionTargetResolver::bind_project(
                &resolver, &target,
            )
            .await?;
        let lease = crate::tasks::task_runtime::TaskExecutionTargetResolver::acquire(
            &resolver, &leader, &target,
        )
        .await?;
        let working_dir = lease.agent().read(|agent| agent.working_dir()).await;
        let canonical_target_root = target_workspace
            .root
            .canonicalize()
            .map_err(|error| error.to_string())?;
        assert_eq!(
            working_dir.as_deref(),
            Some(canonical_target_root.as_path())
        );
        drop(lease);

        let wrong_leader =
            crate::agent_router::AgentAddress::new(source_workspace.id, "another-conversation");
        let leader_error = crate::tasks::task_runtime::TaskExecutionTargetResolver::acquire(
            &resolver,
            &wrong_leader,
            &target,
        )
        .await
        .err()
        .ok_or_else(|| "wrong leader unexpectedly acquired Agent group".to_string())?;
        assert!(leader_error.contains("does not own Agent group"));

        let mut stale_target = target;
        stale_target.address.conversation_id = "stale-conversation".to_string();
        let stale_error = crate::tasks::task_runtime::TaskExecutionTargetResolver::acquire(
            &resolver,
            &leader,
            &stale_target,
        )
        .await
        .err()
        .ok_or_else(|| "stale target unexpectedly acquired Agent group".to_string())?;
        assert!(stale_error.contains("no longer matches frozen target"));
        Ok(())
    }

    #[tokio::test]
    async fn agent_send_queues_for_an_unloaded_validated_workspace_conversation()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let registry = Arc::new(
            WorkspaceRegistry::with_base_dir(temp.path().join("workspaces"))
                .map_err(|error| error.to_string())?,
        );
        let source_workspace = registry
            .create_at(
                "source",
                crate::workspace::WorkspaceKind::General,
                temp.path().join("source"),
            )
            .map_err(|error| error.to_string())?;
        let target_workspace = registry
            .create_at(
                "target",
                crate::workspace::WorkspaceKind::General,
                temp.path().join("target"),
            )
            .map_err(|error| error.to_string())?;
        let primary = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("Agent router test")
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())?;
        let mcp = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            temp.path().join("mcp.json"),
            Default::default(),
        ));
        let mut state = AppState::from_shared(
            primary,
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            mcp,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?
        .with_agent_router(Arc::new(crate::agent_router::AgentRouter::new(
            temp.path().join("router"),
        )));
        state.workspace.registry = Arc::clone(&registry);
        let state = Arc::new(state);

        for (workspace, conversation_id) in [
            (source_workspace.clone(), "source-conversation"),
            (target_workspace.clone(), "target-conversation"),
        ] {
            let host = state
                .workspace
                .runtimes
                .get_or_open(workspace)
                .await
                .map_err(|error| error.to_string())?;
            host.resources()
                .conversation_store()
                .ensure_projection_epoch(echo_agent::memory::EnsureConversationProjectionRequest {
                    conversation: NewConversation {
                        conversation_id: conversation_id.to_string(),
                        user_id: "default".to_string(),
                        agent_type: None,
                        title: Some(conversation_id.to_string()),
                    },
                    expected_tombstone_epoch: None,
                })
                .await
                .map_err(|error| error.to_string())?;
        }

        state
            .switch_workspace(source_workspace.clone())
            .await
            .map_err(|error| error.to_string())?;

        let source = crate::agent_router::AgentAddress::new(
            source_workspace.id.clone(),
            "source-conversation",
        );
        let target = crate::agent_router::AgentAddress::new(
            target_workspace.id.clone(),
            "target-conversation",
        );
        let endpoints = state
            .discover_agent_endpoints()
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(endpoints.len(), 2);
        assert!(endpoints.iter().any(|endpoint| endpoint.address == target));
        assert_eq!(
            state
                .current_agent_address(Some("source-conversation"))
                .await
                .map_err(|error| error.to_string())?,
            Some(source.clone())
        );
        assert_eq!(
            state
                .current_agent_address(Some("not-persisted"))
                .await
                .map_err(|error| error.to_string())?,
            None
        );

        let (lookup_entered, lookup_release) =
            state.workspace.runtimes.park_next_control_acquire()?;
        let lookup_state = Arc::clone(&state);
        let lookup = tokio::spawn(async move {
            lookup_state
                .current_agent_address(Some("source-conversation"))
                .await
        });
        lookup_entered
            .await
            .map_err(|_| "current address lookup did not reach control pin barrier".to_string())?;
        let switch_state = Arc::clone(&state);
        let switch =
            tokio::spawn(async move { switch_state.switch_workspace(target_workspace).await });
        while !state.workspace_transition_in_progress() {
            tokio::task::yield_now().await;
        }
        lookup_release
            .send(())
            .map_err(|_| "current address control pin release was dropped".to_string())?;
        assert_eq!(
            lookup
                .await
                .map_err(|error| error.to_string())?
                .map_err(|error| error.to_string())?,
            Some(source.clone())
        );
        switch
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        assert_eq!(
            state
                .current_agent_address(Some("source-conversation"))
                .await
                .map_err(|error| error.to_string())?,
            None
        );
        assert_eq!(
            state
                .current_agent_address(Some("target-conversation"))
                .await
                .map_err(|error| error.to_string())?,
            Some(target.clone())
        );

        let mut message = crate::agent_router::AgentMessage::user_text(
            Some(source),
            target.clone(),
            "What did you learn?",
        );
        message.message_id = "source-to-target".to_string();
        let receipt = state
            .send_agent_message_owned(message.clone())
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            receipt.phase,
            crate::agent_router::AgentDeliveryPhase::Persisted
        );
        assert_eq!(
            state
                .agent_router
                .pending(&target)
                .await
                .map_err(|error| error.to_string())?,
            vec![message]
        );
        let records = state
            .agent_delivery_records(&target)
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(records.len(), 1);
        assert_eq!(
            records.first().map(|record| record.message_id.as_str()),
            Some("source-to-target")
        );
        let activity = state
            .workspace
            .runtimes
            .activity_snapshot()
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(activity.len(), 2);
        assert!(activity.iter().all(|host| !host.execution_loaded));
        Ok(())
    }

    #[tokio::test]
    async fn cold_delivery_original_cell_marks_only_its_exact_unknown_lease() -> anyhow::Result<()>
    {
        let client = Arc::new(MockLlmClient::new().with_model_name("test-model"));
        let agent = AgentHandle::new(
            ReactAgentBuilder::new()
                .model("test-model")
                .llm_client(client.clone())
                .build()?,
        );
        let pool =
            Arc::new(crate::agent_pool::AgentPool::new_for_test(agent, None, None, 2, false).await);
        pool.set_llm_client_override_for_test(client).await;
        let original = pool.acquire("same-cold-target").await?;
        let ordinary = pool.acquire("same-cold-target").await?;
        let control = crate::foreground_turn::ForegroundTurnControl::default();
        let lease = control.begin(
            crate::foreground_turn::ForegroundTurnSurface::Channel,
            "same-cold-target",
            "cold-original-turn",
        )?;
        // Invoke the exact private binding used by deliver_agent_message_cold.
        let cell = AppState::retain_cold_delivery_execution(&lease, original);
        let (release, held) = tokio::sync::oneshot::channel();
        let backend = tokio::spawn(held);
        lease.retain_observation(crate::chat_driver::ChatTurnError::Observation {
            run_id: "cold-original-run".into(),
            execution_id: Some("cold-original-execution".into()),
        });
        drop(lease);
        {
            let normal_drain = pool.join_known_executions();
            tokio::pin!(normal_drain);
            assert!(futures::poll!(normal_drain.as_mut()).is_pending());
        }
        assert_eq!(pool.active_execution_count(), 2);
        drop(ordinary);
        let unknown = tokio::time::timeout(
            std::time::Duration::from_secs(2),
            pool.join_known_executions(),
        )
        .await?;
        assert!(
            unknown
                .as_ref()
                .err()
                .is_some_and(|error| error.contains("cold-original-run"))
        );
        assert_eq!(pool.active_execution_count(), 1);
        assert!(
            cell.lock()
                .unwrap_or_else(|error| error.into_inner())
                .is_some()
        );
        assert!(!backend.is_finished());
        release
            .send(())
            .map_err(|_| anyhow::anyhow!("original cold backend vanished"))?;
        backend.await??;
        cell.lock()
            .unwrap_or_else(|error| error.into_inner())
            .take();
        assert_eq!(pool.active_execution_count(), 0);
        pool.shutdown().await.map_err(anyhow::Error::msg)?;
        Ok(())
    }

    #[tokio::test]
    async fn agent_delivery_cold_starts_target_and_routes_correlated_reply() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let registry = Arc::new(
            WorkspaceRegistry::with_base_dir(temp.path().join("workspaces"))
                .map_err(|error| error.to_string())?,
        );
        let source_workspace = registry
            .create_at(
                "source",
                crate::workspace::WorkspaceKind::General,
                temp.path().join("source"),
            )
            .map_err(|error| error.to_string())?;
        let target_workspace = registry
            .create_at(
                "target",
                crate::workspace::WorkspaceKind::General,
                temp.path().join("target"),
            )
            .map_err(|error| error.to_string())?;
        let primary = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new().with_responses([
                "target model preflight",
                "target answer",
                "source model preflight",
                "source incorporated reply",
            ])))
            .system_prompt("Agent delivery integration test")
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())?;
        let seed_pool = Arc::new(
            crate::agent_pool::AgentPool::new_for_test(primary.clone(), None, None, 4, false).await,
        );
        seed_pool
            .set_llm_client_override_for_test(Arc::new(MockLlmClient::new().with_responses([
                "target model preflight",
                "target answer",
                "source model preflight",
                "source incorporated reply",
            ])))
            .await;
        let mcp = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            temp.path().join("mcp.json"),
            Default::default(),
        ));
        let mut state = AppState::from_shared(
            primary,
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            mcp,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?
        .with_agent_router(Arc::new(crate::agent_router::AgentRouter::new(
            temp.path().join("router"),
        )));
        state.workspace.registry = Arc::clone(&registry);
        state.set_pool(seed_pool.clone());
        let state = Arc::new(state);
        let mut lifecycle = crate::runtime::ApplicationLifecycleOwner::new(
            tokio_util::sync::CancellationToken::new(),
        );
        lifecycle.bind_app_state(state.clone());
        lifecycle.bind_pool(seed_pool);

        for (workspace, conversation_id) in [
            (source_workspace.clone(), "source-conversation"),
            (target_workspace.clone(), "target-conversation"),
        ] {
            let host = state
                .workspace
                .runtimes
                .get_or_open(workspace)
                .await
                .map_err(|error| error.to_string())?;
            host.resources()
                .conversation_store()
                .ensure_projection_epoch(echo_agent::memory::EnsureConversationProjectionRequest {
                    conversation: NewConversation {
                        conversation_id: conversation_id.to_string(),
                        user_id: "default".to_string(),
                        agent_type: None,
                        title: Some(conversation_id.to_string()),
                    },
                    expected_tombstone_epoch: None,
                })
                .await
                .map_err(|error| error.to_string())?;
        }

        let source = crate::agent_router::AgentAddress::new(
            source_workspace.id.clone(),
            "source-conversation",
        );
        let target = crate::agent_router::AgentAddress::new(
            target_workspace.id.clone(),
            "target-conversation",
        );
        let mut message = crate::agent_router::AgentMessage::user_text(
            Some(source.clone()),
            target.clone(),
            "Ask the target",
        );
        message.message_id = "cold-delivery".to_string();
        state
            .send_agent_message_owned(message.clone())
            .await
            .map_err(|error| error.to_string())?;

        let deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(30);
        let target_record = loop {
            let record = state
                .agent_router
                .records(&target)
                .await
                .map_err(|error| error.to_string())?
                .into_iter()
                .find(|record| {
                    record.message_id == message.message_id
                        && record.phase == crate::agent_router::AgentDeliveryPhase::TurnSettled
                        && record.outcome
                            == Some(crate::agent_router::AgentDeliveryOutcome::Completed)
                });
            if let Some(record) = record {
                break record;
            }
            if tokio::time::Instant::now() >= deadline {
                let records = state
                    .agent_router
                    .records(&target)
                    .await
                    .map_err(|error| error.to_string())?;
                let activity = state
                    .workspace
                    .runtimes
                    .activity_snapshot()
                    .await
                    .map_err(|error| error.to_string())?;
                return Err(format!(
                    "target Agent delivery did not settle; records={records:?}; activity={activity:?}"
                ));
            }
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        };
        let reply_id = target_record
            .reply_message_id
            .clone()
            .ok_or_else(|| "correlated reply was not queued".to_string())?;
        let deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(30);
        let source_record = loop {
            let record = state
                .agent_router
                .records(&source)
                .await
                .map_err(|error| error.to_string())?
                .into_iter()
                .find(|record| {
                    record.message_id == reply_id
                        && record.phase == crate::agent_router::AgentDeliveryPhase::TurnSettled
                        && record.outcome
                            == Some(crate::agent_router::AgentDeliveryOutcome::Completed)
                });
            if let Some(record) = record {
                break record;
            }
            if tokio::time::Instant::now() >= deadline {
                let records = state
                    .agent_router
                    .records(&source)
                    .await
                    .map_err(|error| error.to_string())?;
                return Err(format!(
                    "source Agent did not consume correlated reply; records={records:?}"
                ));
            }
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        };
        assert_eq!(
            source_record.payload.correlation_id.as_deref(),
            Some("cold-delivery")
        );
        assert_eq!(
            source_record.payload.causation_id.as_deref(),
            Some("cold-delivery")
        );
        assert!(matches!(
            source_record.payload.payload,
            crate::agent_router::AgentMessagePayload::Reply { ref text }
                if text == "target answer"
        ));

        let target_host = state
            .workspace
            .runtimes
            .get_or_open(target_workspace)
            .await
            .map_err(|error| error.to_string())?;
        let target_store = target_host.resources().conversation_store();
        let mut transcript = target_store
            .get_messages("target-conversation")
            .await
            .map_err(|error| error.to_string())?;
        assert!(transcript.iter().any(|stored| {
            stored.role == "assistant" && stored.content.as_deref() == Some("target answer")
        }));

        let mut crash_message = crate::agent_router::AgentMessage::user_text(
            Some(source.clone()),
            target.clone(),
            "Recover without running the model twice",
        );
        crash_message.message_id = "transcript-crash-window".to_string();
        state
            .agent_router
            .enqueue(crash_message.clone())
            .await
            .map_err(|error| error.to_string())?;
        let abandoned_claim = state
            .agent_router
            .claim_next(&target)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "crash-window claim missing".to_string())?;
        assert_eq!(abandoned_claim.attempt, 1);
        let actual_turn_id = crash_message.delivery_turn_id();
        state
            .agent_router
            .begin_injection(&abandoned_claim, actual_turn_id.clone())
            .await
            .map_err(|error| error.to_string())?;
        let crash_instruction = render_agent_delivery_instruction(&crash_message);
        let created_at = Utc::now().to_rfc3339();
        transcript.push(StoredMessage {
            id: None,
            conversation_id: target.conversation_id.clone(),
            role: "user".to_string(),
            content: Some(crash_instruction),
            attachments_json: None,
            tool_calls_json: None,
            tool_result_json: None,
            created_at: created_at.clone(),
        });
        transcript.push(StoredMessage {
            id: None,
            conversation_id: target.conversation_id.clone(),
            role: "assistant".to_string(),
            content: Some("unowned adjacent assistant text".to_string()),
            attachments_json: None,
            tool_calls_json: None,
            tool_result_json: None,
            created_at,
        });
        let additions = transcript.split_off(transcript.len().saturating_sub(2));
        let authority = target_store
            .get_projection_authority(&target.conversation_id)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "target managed projection authority is missing".to_string())?;
        let batch = echo_agent::memory::TranscriptProjectionBatch::prepare(
            &target.conversation_id,
            authority.epoch,
            "fixture-transcript-crash-window",
            0,
            additions,
        )
        .map_err(|error| error.to_string())?;
        let projection = target_store
            .apply_transcript_projection(batch)
            .await
            .map_err(|error| error.to_string())?;
        assert!(matches!(
            projection.status,
            echo_agent::memory::TranscriptProjectionApplyStatus::Applied
        ));

        assert!(
            state
                .reconcile_agent_delivery_in_flight(&target, &[], &CancellationToken::new(),)
                .await
                .map_err(|error| error.to_string())?
        );
        let recovered_record = state
            .agent_router
            .records(&target)
            .await
            .map_err(|error| error.to_string())?
            .into_iter()
            .find(|record| record.message_id == crash_message.message_id)
            .ok_or_else(|| "crash-window delivery record missing".to_string())?;
        assert_eq!(
            recovered_record.phase,
            crate::agent_router::AgentDeliveryPhase::TurnSettled
        );
        assert_eq!(
            recovered_record.outcome,
            Some(crate::agent_router::AgentDeliveryOutcome::OutcomeUnknown)
        );
        assert_eq!(recovered_record.attempt, 1);
        assert_eq!(
            recovered_record.turn_id.as_deref(),
            Some(actual_turn_id.as_str())
        );
        assert!(recovered_record.reply_message_id.is_none());
        let recovered_transcript = target_store
            .get_messages(&target.conversation_id)
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            recovered_transcript
                .iter()
                .filter(|stored| {
                    stored.role == "assistant"
                        && stored.content.as_deref() == Some("unowned adjacent assistant text")
                })
                .count(),
            1
        );

        let runtime = state
            .chat_runtime_for_agent(&target)
            .await
            .map_err(|error| error.to_string())?;
        let lease = runtime
            .begin_turn(
                &state.session.foreground_turns,
                crate::foreground_turn::ForegroundTurnSurface::Gui,
                &target.conversation_id,
                "active-target-turn",
            )
            .await
            .map_err(|error| error.to_string())?;
        let execution = runtime
            .agent_for(&target.conversation_id)
            .await
            .map_err(|error| error.to_string())?;
        let active_agent = execution.agent();
        let active_model = Arc::new(ParkedReplyClient {
            inner: MockLlmClient::new()
                .with_responses(["active turn draft", "active turn after steer"]),
            entered: tokio::sync::Notify::new(),
            release: CancellationToken::new(),
        });
        active_agent
            .write(|agent| {
                agent.set_llm_client(active_model.clone());
            })
            .await;
        let spill_dir = crate::prepared_turn::resolve_user_input_spill_dir(Some(
            runtime.execution_scope().root(),
        ));
        let active_turn =
            crate::prepared_turn::PreparedUserTurn::build(crate::prepared_turn::UserTurnInput {
                text: "Start a delayed target turn",
                attachments: &[],
                spill_dir: &spill_dir,
                conversation_id: Some(&target.conversation_id),
                turn_id: Some("active-target-turn"),
            })
            .map_err(|error| error.to_string())?;
        let active_sink: Arc<dyn crate::chat_driver::ChatSink> =
            Arc::new(AgentDeliveryCaptureSink::default());
        let active_resources = Arc::new(crate::chat_resources::ChatResources {
            execution_scope: runtime.execution_scope().clone(),
            workspace_io_receipt: Some(runtime.workspace_io_receipt()),
            pool: runtime.pool(),
            store: runtime.task_runtime(),
            sink: active_sink,
            webhook_emitter: Some(state.webhook.emitter.clone()),
            conv_id: Some(target.conversation_id.clone()),
            root_message_id: "active-target-turn".to_string(),
            attachments: Vec::new(),
            cancel: lease.cancellation_token(),
            review_integration: runtime.review_integration(),
            memory_generation: None,
            human_loop_provider: Some(Arc::new(crate::hitl::HitlDispatcher::new())),
        });
        let active_task = tokio::spawn(async move {
            let _execution = execution;
            crate::foreground_turn::drive_foreground_chat(
                lease,
                &active_agent,
                &active_turn,
                active_resources,
            )
            .await
        });
        tokio::time::timeout(
            std::time::Duration::from_secs(30),
            active_model.entered.notified(),
        )
        .await
        .map_err(|_| "target turn never entered the streaming provider".to_string())?;
        let mut live_message = crate::agent_router::AgentMessage::user_text(
            None,
            target.clone(),
            "Steer the active target turn",
        );
        live_message.message_id = "live-steer".to_string();
        state
            .send_agent_message_owned(live_message)
            .await
            .map_err(|error| error.to_string())?;
        // Release the provider only after durable mailbox acceptance, so this
        // fixture proves live consumption rather than racing a wall-clock sleep.
        let accepted_deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(30);
        loop {
            let record = state
                .agent_router
                .records(&target)
                .await
                .map_err(|error| error.to_string())?
                .into_iter()
                .find(|record| record.message_id == "live-steer");
            if record.is_some_and(|record| record.mailbox_accepted_at.is_some()) {
                break;
            }
            if tokio::time::Instant::now() >= accepted_deadline {
                active_model.release.cancel();
                return Err("live Agent delivery never reached mailbox acceptance".to_string());
            }
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        }
        active_model.release.cancel();
        let live_deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(30);
        let live_record = loop {
            let record = state
                .agent_router
                .records(&target)
                .await
                .map_err(|error| error.to_string())?
                .into_iter()
                .find(|record| {
                    record.message_id == "live-steer"
                        && record.phase == crate::agent_router::AgentDeliveryPhase::TurnSettled
                        && record.outcome
                            == Some(crate::agent_router::AgentDeliveryOutcome::Completed)
                });
            if let Some(record) = record {
                break record;
            }
            if tokio::time::Instant::now() >= live_deadline {
                let records = state
                    .agent_router
                    .records(&target)
                    .await
                    .map_err(|error| error.to_string())?;
                return Err(format!(
                    "live Agent message was not steered; records={records:?}"
                ));
            }
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        };
        assert_eq!(live_record.turn_id.as_deref(), Some("active-target-turn"));
        let active_outcome = active_task
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        assert_eq!(active_outcome, crate::chat_driver::TurnOutcome::Completed);

        let busy_execution = runtime
            .agent_for(&target.conversation_id)
            .await
            .map_err(|error| error.to_string())?;
        busy_execution
            .agent()
            .write(|agent| {
                agent.set_llm_client(Arc::new(
                    MockLlmClient::new()
                        .with_responses(["busy turn preflight", "processed after busy turn"]),
                ));
            })
            .await;
        drop(busy_execution);
        let busy_lease = runtime
            .begin_turn(
                &state.session.foreground_turns,
                crate::foreground_turn::ForegroundTurnSurface::Gui,
                &target.conversation_id,
                "busy-target-turn",
            )
            .await
            .map_err(|error| error.to_string())?;
        let mut busy_message =
            crate::agent_router::AgentMessage::user_text(None, target.clone(), "Wait for FIFO");
        busy_message.message_id = "busy-fifo".to_string();
        state
            .send_agent_message_owned(busy_message)
            .await
            .map_err(|error| error.to_string())?;
        let defer_deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(30);
        loop {
            let deferred = state
                .agent_router
                .records(&target)
                .await
                .map_err(|error| error.to_string())?
                .into_iter()
                .any(|record| {
                    record.message_id == "busy-fifo"
                        && record.phase == crate::agent_router::AgentDeliveryPhase::Deferred
                        && record.attempt > 0
                });
            if deferred {
                break;
            }
            if tokio::time::Instant::now() >= defer_deadline {
                let records = state
                    .agent_router
                    .records(&target)
                    .await
                    .map_err(|error| error.to_string())?;
                return Err(format!(
                    "busy Agent delivery was not deferred; records={records:?}"
                ));
            }
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        }
        busy_lease.settle(crate::chat_driver::TurnOutcome::Completed);
        let resume_deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(30);
        let resumed_record = loop {
            let record = state
                .agent_router
                .records(&target)
                .await
                .map_err(|error| error.to_string())?
                .into_iter()
                .find(|record| {
                    record.message_id == "busy-fifo"
                        && record.phase == crate::agent_router::AgentDeliveryPhase::TurnSettled
                        && record.outcome
                            == Some(crate::agent_router::AgentDeliveryOutcome::Completed)
                });
            if let Some(record) = record {
                break record;
            }
            if tokio::time::Instant::now() >= resume_deadline {
                let records = state
                    .agent_router
                    .records(&target)
                    .await
                    .map_err(|error| error.to_string())?;
                return Err(format!(
                    "deferred Agent delivery did not resume; records={records:?}"
                ));
            }
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        };
        assert!(resumed_record.attempt >= 2);
        state
            .shutdown_agent_deliveries()
            .await
            .map_err(|error| error.to_string())?;
        state
            .session
            .foreground_turns
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    fn workspace(name: &str, root: std::path::PathBuf) -> Workspace {
        Workspace {
            id: crate::workspace::WorkspaceId::from_name(name),
            name: name.to_string(),
            root,
            project_root: None,
            kind: crate::workspace::WorkspaceKind::General,
            metadata: crate::workspace::WorkspaceMetadata::default(),
            product_data_generation: String::new(),
            created_at: Utc::now(),
            last_active: Utc::now(),
        }
    }

    async fn extension_control_state(
        root: &std::path::Path,
    ) -> Result<
        (
            Arc<AppState>,
            Arc<crate::agent_pool::AgentPool>,
            Arc<crate::plugin_runtime::PluginRuntimeService>,
        ),
        String,
    > {
        let global_root = root.join("global");
        std::fs::create_dir_all(&global_root).map_err(|error| error.to_string())?;
        let global_root = global_root
            .canonicalize()
            .map_err(|error| error.to_string())?;
        let agent = AgentHandle::new(
            ReactAgentBuilder::new()
                .llm_client(Arc::new(MockLlmClient::new()))
                .system_prompt("extension control runtime identity test")
                .working_dir(global_root.clone())
                .build()
                .map_err(|error| error.to_string())?,
        );
        let seed_pool = Arc::new(
            crate::agent_pool::AgentPool::new_for_test(agent.clone(), None, None, 4, false).await,
        );
        seed_pool
            .update_mcp_config_snapshot(Default::default())
            .await;
        let plugin_runtime = crate::plugin_runtime::PluginRuntimeService::new_for_test(
            agent.clone(),
            global_root.clone(),
            root.join("global-plugins.json"),
            root.join("global-plugin-data"),
        )
        .await
        .map_err(|error| error.to_string())?;
        let mcp_runtime = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            root.join("mcp.json"),
            Default::default(),
        ));
        let skill_root = root.join("skills");
        std::fs::create_dir_all(&skill_root).map_err(|error| error.to_string())?;
        let mut state = AppState::from_shared(
            agent,
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            mcp_runtime,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?
        .with_plugin_runtime(Some(Arc::clone(&plugin_runtime)));
        state.skills_hub = Arc::new(tokio::sync::RwLock::new(
            crate::skills_hub::SkillsHub::with_root(skill_root),
        ));
        state.extension_control = Arc::new(
            crate::extension_control::ExtensionControlService::with_enabled_config_path(
                root.join("enabled-skills.json"),
            ),
        );
        state.workspace.global_execution_root = global_root;
        state.workspace.registry = Arc::new(
            WorkspaceRegistry::with_base_dir(root.join("workspace-registry"))
                .map_err(|error| error.to_string())?,
        );
        state.tasks.runtime = Some(Arc::new(
            crate::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                .map_err(|error| error.to_string())?,
        ));
        state.storage.chat_events = Arc::new(
            crate::chat_event_log::ChatEventLog::open(
                root.join("chat-events"),
                crate::chat_event_log::ChatEventRetention::default(),
            )
            .map_err(|error| error.to_string())?,
        );
        state.storage.tool_executions = Arc::new(
            crate::tool_execution::ToolExecutionRepository::open(root.join("tool-executions"))
                .map_err(|error| error.to_string())?,
        );
        state.storage.conversation_archive =
            Arc::new(crate::conversation_archive::ConversationArchiveStore::open(
                root.join("conversation-visibility.json"),
            )?);
        state.agent_router = Arc::new(crate::agent_router::AgentRouter::new(root.join("router")));
        state.set_pool(Arc::clone(&seed_pool));
        Ok((Arc::new(state), seed_pool, plugin_runtime))
    }

    #[tokio::test]
    async fn reply_fork_native_switch_rejects_recreated_target_before_source_projection_changes()
    -> Result<(), String> {
        let temporary = tempfile::tempdir().map_err(|error| error.to_string())?;
        let (state, _pool, _plugins) = extension_control_state(temporary.path()).await?;
        let source = state
            .workspace
            .registry
            .create_at(
                "source",
                crate::workspace::WorkspaceKind::General,
                temporary.path().join("source"),
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace_registered(source.id.clone())
            .await
            .map_err(|error| error.to_string())?;
        let old = state
            .workspace
            .registry
            .create_at(
                "target",
                crate::workspace::WorkspaceKind::General,
                temporary.path().join("old-target"),
            )
            .map_err(|error| error.to_string())?;
        let expected = old.opaque_product_data_generation();
        let transition = state.workspace.transition.write().await;
        let pending_state = state.clone();
        let target_id = old.id.clone();
        let pending = tokio::spawn(async move {
            pending_state
                .switch_workspace_registered_with_connection(target_id, None, Some(expected))
                .await
        });
        tokio::task::yield_now().await;
        assert!(!pending.is_finished());
        state
            .workspace
            .registry
            .delete(&old.id)
            .map_err(|error| error.to_string())?;
        let current = state
            .workspace
            .registry
            .create_at(
                "target",
                crate::workspace::WorkspaceKind::General,
                temporary.path().join("new-target"),
            )
            .map_err(|error| error.to_string())?;
        assert_ne!(
            current.opaque_product_data_generation(),
            old.opaque_product_data_generation()
        );
        drop(transition);
        assert!(pending.await.map_err(|error| error.to_string())?.is_err());
        assert_eq!(
            state
                .current_workspace()
                .await
                .map(|workspace| workspace.id),
            Some(source.id)
        );
        state
            .switch_workspace_registered_with_connection(
                current.id.clone(),
                None,
                Some(current.opaque_product_data_generation()),
            )
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            state
                .current_workspace()
                .await
                .map(|workspace| workspace.id),
            Some(current.id)
        );
        Ok(())
    }

    #[tokio::test]
    async fn handoff_collision_preserves_both_workspace_conversations() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root_a = temp.path().join("workspace-a");
        let root_b = temp.path().join("workspace-b");
        std::fs::create_dir_all(&root_a).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&root_b).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;
        let workspace_a = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root_a,
            )
            .map_err(|error| error.to_string())?;
        let workspace_b = state
            .workspace
            .registry
            .create_at(
                "workspace-b",
                crate::workspace::WorkspaceKind::General,
                root_b,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_a)
            .await
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_b)
            .await
            .map_err(|error| error.to_string())?;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        for (runtime, title) in [(&destination, "Keep"), (&source, "Move")] {
            runtime
                .ensure_conversation(echo_agent::memory::NewConversation {
                    conversation_id: "same-id".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some(title.to_string()),
                })
                .await
                .map_err(|error| error.to_string())?;
        }
        let operation = AppStateAgentControlOps::new(&state);
        let result = crate::agent_control::AgentControlAppOps::handoff_conversation(
            &operation,
            crate::agent_control::AgentHandoffRequest {
                workspace_id: "workspace-b".to_string(),
                conversation_id: "same-id".to_string(),
                destination_workspace_id: "workspace-a".to_string(),
                follow_up: None,
            },
        )
        .await;
        assert!(result.is_err());
        for (runtime, title) in [(&destination, "Keep"), (&source, "Move")] {
            let stored = runtime
                .conversation_store()
                .ok_or_else(|| "conversation store missing".to_string())?
                .get_conversation("same-id")
                .await
                .map_err(|error| error.to_string())?
                .ok_or_else(|| "conversation was deleted by collision".to_string())?;
            assert_eq!(stored.title.as_deref(), Some(title));
        }
        Ok(())
    }

    #[tokio::test]
    async fn handoff_retired_destination_and_reappeared_source_fail_closed() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let state = handoff_recovery_fixture(temp.path()).await?;
        let source = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        source
            .ensure_conversation(echo_agent::memory::NewConversation {
                conversation_id: "round-trip".to_string(),
                user_id: "test".to_string(),
                agent_type: None,
                title: Some("Move".to_string()),
            })
            .await
            .map_err(|error| error.to_string())?;
        let operation = AppStateAgentControlOps::new(&state);
        let forward = crate::agent_control::AgentHandoffRequest {
            workspace_id: "workspace-a".to_string(),
            conversation_id: "round-trip".to_string(),
            destination_workspace_id: "workspace-b".to_string(),
            follow_up: None,
        };
        crate::agent_control::AgentControlAppOps::handoff_conversation(&operation, forward.clone())
            .await
            .map_err(|error| error.to_string())?;
        let reverse = crate::agent_control::AgentHandoffRequest {
            workspace_id: "workspace-b".to_string(),
            conversation_id: "round-trip".to_string(),
            destination_workspace_id: "workspace-a".to_string(),
            follow_up: None,
        };
        assert!(
            crate::agent_control::AgentControlAppOps::handoff_conversation(&operation, reverse)
                .await
                .is_err()
        );
        assert!(
            state
                .storage
                .conversation_archive
                .pending_handoffs()?
                .is_empty()
        );
        let source_store = source
            .conversation_store()
            .ok_or_else(|| "source store missing".to_string())?;
        let tombstone = source_store
            .get_projection_authority("round-trip")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "source tombstone missing".to_string())?;
        source_store
            .ensure_projection_epoch(echo_agent::memory::EnsureConversationProjectionRequest {
                conversation: echo_agent::memory::NewConversation {
                    conversation_id: "round-trip".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some("Move".to_string()),
                },
                expected_tombstone_epoch: Some(tombstone.epoch),
            })
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            crate::agent_control::AgentControlAppOps::handoff_conversation(&operation, forward)
                .await
                .is_err()
        );
        let destination = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let authority = destination
            .conversation_store()
            .ok_or_else(|| "destination store missing".to_string())?
            .get_projection_authority("round-trip")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "destination authority missing".to_string())?;
        assert_eq!(authority.epoch, 2);
        assert!(
            source_store
                .get_conversation("round-trip")
                .await
                .map_err(|error| error.to_string())?
                .is_some()
        );
        Ok(())
    }

    async fn handoff_recovery_fixture(root: &std::path::Path) -> Result<Arc<AppState>, String> {
        let root_a = root.join("workspace-a");
        let root_b = root.join("workspace-b");
        std::fs::create_dir_all(&root_a).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&root_b).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(root).await?;
        let workspace_a = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root_a,
            )
            .map_err(|error| error.to_string())?;
        let workspace_b = state
            .workspace
            .registry
            .create_at(
                "workspace-b",
                crate::workspace::WorkspaceKind::General,
                root_b,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_a)
            .await
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_b)
            .await
            .map_err(|error| error.to_string())?;
        Ok(state)
    }

    async fn prepare_handoff_recovery_intent(
        state: &Arc<AppState>,
        conversation_id: &str,
    ) -> Result<String, String> {
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let source_store = source
            .conversation_store()
            .ok_or_else(|| "source store missing".to_string())?;
        let conversation = source_store
            .get_conversation(conversation_id)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "source conversation missing".to_string())?;
        let rows = source_store
            .get_messages(conversation_id)
            .await
            .map_err(|error| error.to_string())?;
        let source_epoch = source_store
            .get_projection_authority(conversation_id)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "source authority missing".to_string())?
            .epoch;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        let target_base_epoch = destination
            .conversation_store()
            .ok_or_else(|| "destination store missing".to_string())?
            .get_projection_authority(conversation_id)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "destination authority missing".to_string())?
            .epoch;
        let operation_id =
            crate::conversation_archive::ConversationArchiveStore::handoff_operation_id(
                "workspace-b",
                "workspace-a",
                conversation_id,
            )?;
        state.storage.conversation_archive.prepare_handoff(
            crate::conversation_archive::ConversationHandoffIntent {
                operation_id: operation_id.clone(),
                source_workspace_id: "workspace-b".to_string(),
                destination_workspace_id: "workspace-a".to_string(),
                conversation_id: conversation_id.to_string(),
                source_epoch,
                target_base_epoch,
                source_fingerprint: AppStateAgentControlOps::handoff_source_fingerprint(
                    &conversation,
                    &rows,
                )
                .map_err(|error| error.to_string())?,
                follow_up: None,
                phase: crate::conversation_archive::ConversationHandoffPhase::Prepared,
            },
        )?;
        Ok(operation_id)
    }

    #[tokio::test]
    async fn handoff_recovers_prepared_target_before_import() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let state = handoff_recovery_fixture(temp.path()).await?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        for runtime in [&source, &destination] {
            runtime
                .ensure_conversation(echo_agent::memory::NewConversation {
                    conversation_id: "prepared-cut".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some("Moved".to_string()),
                })
                .await
                .map_err(|error| error.to_string())?;
        }
        let operation_id = prepare_handoff_recovery_intent(&state, "prepared-cut").await?;
        assert!(
            crate::conversation_archive::ConversationArchiveStore::open(
                temp.path().join("conversation-visibility.json")
            )?
            .handoff(&operation_id)?
            .is_some()
        );
        tokio::time::timeout(
            std::time::Duration::from_secs(20),
            state.recover_pending_conversation_handoffs(),
        )
        .await
        .map_err(|_| "prepared handoff recovery did not settle".to_string())??;
        let authority = destination
            .conversation_store()
            .ok_or_else(|| "destination store missing".to_string())?
            .get_projection_authority("prepared-cut")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "destination authority missing".to_string())?;
        assert_eq!(authority.epoch, 2);
        assert!(
            source
                .conversation_store()
                .ok_or_else(|| "source store missing".to_string())?
                .get_conversation("prepared-cut")
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            state
                .storage
                .conversation_archive
                .handoff(&operation_id)?
                .is_none()
        );
        assert!(
            state
                .storage
                .conversation_archive
                .completed_handoff(&operation_id)?
                .is_some()
        );
        Ok(())
    }

    #[tokio::test]
    async fn pending_handoff_fences_both_turn_admissions_after_persist_failure()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let state = handoff_recovery_fixture(temp.path()).await?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        for runtime in [&source, &destination] {
            runtime
                .ensure_conversation(echo_agent::memory::NewConversation {
                    conversation_id: "fenced-cut".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some("Move".to_string()),
                })
                .await
                .map_err(|error| error.to_string())?;
        }
        let operation_id = prepare_handoff_recovery_intent(&state, "fenced-cut").await?;
        state
            .storage
            .conversation_archive
            .fail_next_persist_for_test();
        assert!(
            state
                .storage
                .conversation_archive
                .advance_handoff(
                    &operation_id,
                    crate::conversation_archive::ConversationHandoffPhase::TargetImported,
                )
                .is_err()
        );
        for runtime in [&source, &destination] {
            let turn = runtime
                .begin_turn(
                    &state.session.foreground_turns,
                    crate::foreground_turn::ForegroundTurnSurface::Gui,
                    "fenced-cut",
                    "forbidden-turn",
                )
                .await;
            assert!(matches!(
                turn,
                Err(crate::conversation_deletion::ConversationDeletionError::HandoffPending(_))
            ));
            assert!(matches!(
                runtime
                    .begin_managed_replacement(&state.session.foreground_turns, "fenced-cut",)
                    .await,
                Err(crate::conversation_deletion::ConversationDeletionError::HandoffPending(_))
            ));
            assert!(matches!(
                runtime
                    .ensure_conversation(echo_agent::memory::NewConversation {
                        conversation_id: "fenced-cut".to_string(),
                        user_id: "test".to_string(),
                        agent_type: None,
                        title: Some("Move".to_string()),
                    },)
                    .await,
                Err(crate::conversation_deletion::ConversationDeletionError::HandoffPending(_))
            ));
            assert!(matches!(
                runtime
                    .create_conversation(echo_agent::memory::NewConversation {
                        conversation_id: "fenced-cut".to_string(),
                        user_id: "test".to_string(),
                        agent_type: None,
                        title: Some("Move".to_string()),
                    },)
                    .await,
                Err(crate::conversation_deletion::ConversationDeletionError::HandoffPending(_))
            ));
        }
        state.recover_pending_conversation_handoffs().await?;
        assert!(
            state
                .storage
                .conversation_archive
                .completed_handoff(&operation_id)?
                .is_some()
        );
        Ok(())
    }

    #[tokio::test]
    async fn handoff_boot_retires_abandoned_intent_after_target_rollback() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let state = handoff_recovery_fixture(temp.path()).await?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        for runtime in [&source, &destination] {
            runtime
                .ensure_conversation(echo_agent::memory::NewConversation {
                    conversation_id: "rolled-back-cut".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some("Move".to_string()),
                })
                .await
                .map_err(|error| error.to_string())?;
        }
        let operation_id = prepare_handoff_recovery_intent(&state, "rolled-back-cut").await?;
        let admission = destination
            .begin_handoff_recovery(&state.session.foreground_turns, "rolled-back-cut")
            .await
            .map_err(|error| error.to_string())?;
        state
            .delete_conversation_tree_with_runtime(&destination, "rolled-back-cut", Some(admission))
            .await
            .map_err(|error| error.to_string())?;
        state.recover_pending_conversation_handoffs().await?;
        assert!(
            state
                .storage
                .conversation_archive
                .handoff(&operation_id)?
                .is_none()
        );
        assert!(
            source
                .conversation_store()
                .ok_or_else(|| "source store missing".to_string())?
                .get_conversation("rolled-back-cut")
                .await
                .map_err(|error| error.to_string())?
                .is_some()
        );
        Ok(())
    }

    #[tokio::test]
    async fn handoff_recovers_imported_target_without_second_epoch() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let state = handoff_recovery_fixture(temp.path()).await?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        for runtime in [&source, &destination] {
            runtime
                .ensure_conversation(echo_agent::memory::NewConversation {
                    conversation_id: "imported-cut".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some("Moved".to_string()),
                })
                .await
                .map_err(|error| error.to_string())?;
        }
        let operation_id = prepare_handoff_recovery_intent(&state, "imported-cut").await?;
        state
            .storage
            .conversation_archive
            .prepare_visibility_transfer(
                "workspace-a",
                "imported-cut",
                crate::conversation_archive::VisibilityTransfer {
                    expected_epoch: 2,
                    hidden_rows: Vec::new(),
                },
            )?;
        let execution = destination
            .agent_for_handoff("imported-cut")
            .await
            .map_err(|error| error.to_string())?;
        crate::managed_conversation::replace_and_resume(
            destination
                .conversation_store()
                .ok_or_else(|| "destination store missing".to_string())?
                .as_ref(),
            destination
                .runtime_state_store()
                .ok_or_else(|| "destination runtime state missing".to_string())?
                .as_ref(),
            &execution.agent(),
            "imported-cut",
            &[],
        )
        .await
        .map_err(|error| error.to_string())?;
        drop(execution);
        state
            .internal_message_ids_scoped("workspace-a", "imported-cut")
            .await?;
        state.storage.conversation_archive.advance_handoff(
            &operation_id,
            crate::conversation_archive::ConversationHandoffPhase::TargetImported,
        )?;
        drop(source);
        drop(destination);
        drop(state);
        let (state, _, _) = extension_control_state(temp.path()).await?;
        for workspace in state
            .workspace
            .registry
            .list()
            .map_err(|error| error.to_string())?
        {
            state
                .switch_workspace(workspace)
                .await
                .map_err(|error| error.to_string())?;
        }
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        tokio::time::timeout(
            std::time::Duration::from_secs(20),
            state.recover_pending_conversation_handoffs(),
        )
        .await
        .map_err(|_| "imported handoff recovery did not settle".to_string())??;
        let authority = destination
            .conversation_store()
            .ok_or_else(|| "destination store missing".to_string())?
            .get_projection_authority("imported-cut")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "destination authority missing".to_string())?;
        assert_eq!(authority.epoch, 2);
        assert!(
            source
                .conversation_store()
                .ok_or_else(|| "source store missing".to_string())?
                .get_conversation("imported-cut")
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            state
                .storage
                .conversation_archive
                .handoff(&operation_id)?
                .is_none()
        );
        let request = crate::agent_control::AgentHandoffRequest {
            workspace_id: "workspace-b".to_string(),
            conversation_id: "imported-cut".to_string(),
            destination_workspace_id: "workspace-a".to_string(),
            follow_up: None,
        };
        let operation = AppStateAgentControlOps::new(&state);
        let active_destination = destination
            .begin_turn(
                &state.session.foreground_turns,
                crate::foreground_turn::ForegroundTurnSurface::Gui,
                "imported-cut",
                "active-after-handoff",
            )
            .await
            .map_err(|error| error.to_string())?;
        let repeated = tokio::time::timeout(
            std::time::Duration::from_secs(5),
            crate::agent_control::AgentControlAppOps::handoff_conversation(&operation, request),
        )
        .await
        .map_err(|_| "completed handoff retry waited for destination turn".to_string())?
        .map_err(|error| error.to_string())?;
        active_destination
            .settle_after_observers(crate::chat_driver::TurnOutcome::Completed)
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(repeated["messages_migrated"], 0);
        assert_eq!(repeated["follow_up_delivered"], false);
        assert!(
            state
                .storage
                .conversation_archive
                .completed_handoff(&operation_id)?
                .is_some()
        );
        Ok(())
    }

    #[tokio::test]
    async fn handoff_recovers_after_source_retirement_before_completion() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let state = handoff_recovery_fixture(temp.path()).await?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        for runtime in [&source, &destination] {
            runtime
                .ensure_conversation(echo_agent::memory::NewConversation {
                    conversation_id: "retired-cut".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some("Moved".to_string()),
                })
                .await
                .map_err(|error| error.to_string())?;
        }
        let operation_id = prepare_handoff_recovery_intent(&state, "retired-cut").await?;
        state
            .storage
            .conversation_archive
            .prepare_visibility_transfer(
                "workspace-a",
                "retired-cut",
                crate::conversation_archive::VisibilityTransfer {
                    expected_epoch: 2,
                    hidden_rows: Vec::new(),
                },
            )?;
        let execution = destination
            .agent_for_handoff("retired-cut")
            .await
            .map_err(|error| error.to_string())?;
        crate::managed_conversation::replace_and_resume(
            destination
                .conversation_store()
                .ok_or_else(|| "destination store missing".to_string())?
                .as_ref(),
            destination
                .runtime_state_store()
                .ok_or_else(|| "destination runtime state missing".to_string())?
                .as_ref(),
            &execution.agent(),
            "retired-cut",
            &[],
        )
        .await
        .map_err(|error| error.to_string())?;
        drop(execution);
        state
            .internal_message_ids_scoped("workspace-a", "retired-cut")
            .await?;
        state.storage.conversation_archive.advance_handoff(
            &operation_id,
            crate::conversation_archive::ConversationHandoffPhase::TargetImported,
        )?;
        let source_admission = source
            .begin_handoff_recovery(&state.session.foreground_turns, "retired-cut")
            .await
            .map_err(|error| error.to_string())?;
        state
            .delete_conversation_tree_with_runtime(&source, "retired-cut", Some(source_admission))
            .await
            .map_err(|error| error.to_string())?;
        state.storage.conversation_archive.advance_handoff(
            &operation_id,
            crate::conversation_archive::ConversationHandoffPhase::SourceRetired,
        )?;
        state.recover_pending_conversation_handoffs().await?;
        let receipt = state
            .storage
            .conversation_archive
            .completed_handoff(&operation_id)?
            .ok_or_else(|| "handoff completion receipt missing".to_string())?;
        assert_eq!(receipt.message_count, 0);
        assert!(
            state
                .storage
                .conversation_archive
                .handoff(&operation_id)?
                .is_none()
        );
        Ok(())
    }

    #[tokio::test]
    async fn handoff_preserves_hidden_internal_rows_under_new_destination_ids() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root_a = temp.path().join("workspace-a");
        let root_b = temp.path().join("workspace-b");
        std::fs::create_dir_all(&root_a).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&root_b).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;
        let workspace_a = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root_a,
            )
            .map_err(|error| error.to_string())?;
        let workspace_b = state
            .workspace
            .registry
            .create_at(
                "workspace-b",
                crate::workspace::WorkspaceKind::General,
                root_b,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_a)
            .await
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_b)
            .await
            .map_err(|error| error.to_string())?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let source_store = source
            .conversation_store()
            .ok_or_else(|| "source store missing".to_string())?;
        source_store
            .create_conversation(echo_agent::memory::NewConversation {
                conversation_id: "move-hidden".to_string(),
                user_id: "test".to_string(),
                agent_type: None,
                title: Some("Source".to_string()),
            })
            .await
            .map_err(|error| error.to_string())?;
        let rows = [
            ("user", "ordinary input"),
            ("user", "internal instruction"),
            ("assistant", "internal result"),
        ]
        .into_iter()
        .map(|(role, content)| echo_agent::memory::StoredMessage {
            id: None,
            conversation_id: "move-hidden".to_string(),
            role: role.to_string(),
            content: Some(content.to_string()),
            attachments_json: None,
            tool_calls_json: None,
            tool_result_json: None,
            created_at: Utc::now().to_rfc3339(),
        })
        .collect::<Vec<_>>();
        source_store
            .save_messages("move-hidden", &rows)
            .await
            .map_err(|error| error.to_string())?;
        let epoch = source_store
            .ensure_projection_epoch(echo_agent::memory::EnsureConversationProjectionRequest {
                conversation: echo_agent::memory::NewConversation {
                    conversation_id: "move-hidden".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some("Source".to_string()),
                },
                expected_tombstone_epoch: None,
            })
            .await
            .map_err(|error| error.to_string())?
            .authority
            .epoch;
        let source_rows = source_store
            .get_messages("move-hidden")
            .await
            .map_err(|error| error.to_string())?;
        let hidden_ids = source_rows
            .iter()
            .skip(1)
            .filter_map(|row| row.id)
            .collect::<std::collections::BTreeSet<_>>();
        assert_eq!(hidden_ids.len(), 2);
        state.storage.conversation_archive.prepare_internal_turn(
            "workspace-b",
            "move-hidden",
            epoch,
            "delivery-source",
            1,
            "internal instruction",
        )?;
        state.storage.conversation_archive.settle_internal_turn(
            "workspace-b",
            "move-hidden",
            "delivery-source",
            hidden_ids,
        )?;
        let (entered_tx, entered_rx) = tokio::sync::oneshot::channel();
        let (release_tx, release_rx) = tokio::sync::oneshot::channel();
        source
            .deletions
            .install_before_lineage_barrier(entered_tx, release_rx);
        let handoff_state = Arc::clone(&state);
        let handoff = tokio::spawn(async move {
            let operation = AppStateAgentControlOps::new(&handoff_state);
            crate::agent_control::AgentControlAppOps::handoff_conversation(
                &operation,
                crate::agent_control::AgentHandoffRequest {
                    workspace_id: "workspace-b".to_string(),
                    conversation_id: "move-hidden".to_string(),
                    destination_workspace_id: "workspace-a".to_string(),
                    follow_up: None,
                },
            )
            .await
        });
        tokio::time::timeout(std::time::Duration::from_secs(10), entered_rx)
            .await
            .map_err(|_| "source retirement did not reach its lineage barrier".to_string())?
            .map_err(|error| error.to_string())?;
        assert!(
            state
                .session
                .foreground_turns
                .begin_scoped(
                    "workspace-a",
                    crate::foreground_turn::ForegroundTurnSurface::Gui,
                    "move-hidden",
                    "racing-destination-turn",
                )
                .is_err()
        );
        release_tx
            .send(())
            .map_err(|_| "lineage barrier closed".to_string())?;
        tokio::time::timeout(std::time::Duration::from_secs(20), handoff)
            .await
            .map_err(|_| "handoff did not settle".to_string())?
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        let destination_rows = destination
            .conversation_store()
            .ok_or_else(|| "destination store missing".to_string())?
            .get_messages("move-hidden")
            .await
            .map_err(|error| error.to_string())?;
        let destination_hidden = state
            .internal_message_ids_scoped("workspace-a", "move-hidden")
            .await?;
        assert_eq!(destination_rows.len(), 3);
        assert_eq!(destination_hidden.len(), 2);
        assert!(
            destination_rows
                .iter()
                .skip(1)
                .all(|row| row.id.is_some_and(|id| destination_hidden.contains(&id)))
        );
        assert!(
            source_store
                .get_conversation("move-hidden")
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        Ok(())
    }

    #[tokio::test]
    async fn handoff_invalid_import_rolls_back_only_new_destination() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root_a = temp.path().join("workspace-a");
        let root_b = temp.path().join("workspace-b");
        std::fs::create_dir_all(&root_a).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&root_b).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;
        let workspace_a = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root_a,
            )
            .map_err(|error| error.to_string())?;
        let workspace_b = state
            .workspace
            .registry
            .create_at(
                "workspace-b",
                crate::workspace::WorkspaceKind::General,
                root_b,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_a)
            .await
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_b)
            .await
            .map_err(|error| error.to_string())?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        let source_store = source
            .conversation_store()
            .ok_or_else(|| "source store missing".to_string())?;
        source_store
            .create_conversation(echo_agent::memory::NewConversation {
                conversation_id: "busy-source".to_string(),
                user_id: "test".to_string(),
                agent_type: None,
                title: Some("Source".to_string()),
            })
            .await
            .map_err(|error| error.to_string())?;
        source_store
            .save_messages(
                "busy-source",
                &[echo_agent::memory::StoredMessage {
                    id: None,
                    conversation_id: "busy-source".to_string(),
                    role: "invalid-role".to_string(),
                    content: Some("cannot restore".to_string()),
                    attachments_json: None,
                    tool_calls_json: None,
                    tool_result_json: None,
                    created_at: Utc::now().to_rfc3339(),
                }],
            )
            .await
            .map_err(|error| error.to_string())?;
        let operation = AppStateAgentControlOps::new(&state);
        let request = crate::agent_control::AgentHandoffRequest {
            workspace_id: "workspace-b".to_string(),
            conversation_id: "busy-source".to_string(),
            destination_workspace_id: "workspace-a".to_string(),
            follow_up: None,
        };
        let active = state
            .begin_conversation_turn_owned(
                crate::foreground_turn::ForegroundTurnSurface::Gui,
                "busy-source",
                "active-turn",
            )
            .await
            .map_err(|error| error.to_string())?;
        let active_result = crate::agent_control::AgentControlAppOps::handoff_conversation(
            &operation,
            request.clone(),
        )
        .await;
        assert!(active_result.is_err());
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            destination
                .conversation_store()
                .ok_or_else(|| "destination store missing".to_string())?
                .get_conversation("busy-source")
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        drop(active);
        let result =
            crate::agent_control::AgentControlAppOps::handoff_conversation(&operation, request)
                .await;
        assert!(result.is_err());
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            destination
                .conversation_store()
                .ok_or_else(|| "destination store missing".to_string())?
                .get_conversation("busy-source")
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            source_store
                .get_conversation("busy-source")
                .await
                .map_err(|error| error.to_string())?
                .is_some()
        );
        Ok(())
    }

    #[tokio::test]
    async fn handoff_source_retirement_failure_rolls_back_new_destination() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root_a = temp.path().join("workspace-a");
        let root_b = temp.path().join("workspace-b");
        std::fs::create_dir_all(&root_a).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&root_b).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;
        let workspace_a = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root_a,
            )
            .map_err(|error| error.to_string())?;
        let workspace_b = state
            .workspace
            .registry
            .create_at(
                "workspace-b",
                crate::workspace::WorkspaceKind::General,
                root_b,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_a)
            .await
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace_b)
            .await
            .map_err(|error| error.to_string())?;
        let source = state
            .chat_runtime_for_scope("workspace-b")
            .await
            .map_err(|error| error.to_string())?;
        source
            .ensure_conversation(echo_agent::memory::NewConversation {
                conversation_id: "source-fault".to_string(),
                user_id: "test".to_string(),
                agent_type: None,
                title: Some("Source".to_string()),
            })
            .await
            .map_err(|error| error.to_string())?;
        source.deletions.fail_next_initial_tombstone_for_test();
        let operation = AppStateAgentControlOps::new(&state);
        let result = tokio::time::timeout(
            std::time::Duration::from_secs(20),
            crate::agent_control::AgentControlAppOps::handoff_conversation(
                &operation,
                crate::agent_control::AgentHandoffRequest {
                    workspace_id: "workspace-b".to_string(),
                    conversation_id: "source-fault".to_string(),
                    destination_workspace_id: "workspace-a".to_string(),
                    follow_up: None,
                },
            ),
        )
        .await
        .map_err(|_| "faulted handoff did not settle".to_string())?;
        assert!(result.is_err());
        let destination = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            destination
                .conversation_store()
                .ok_or_else(|| "destination store missing".to_string())?
                .get_conversation("source-fault")
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            source
                .conversation_store()
                .ok_or_else(|| "source store missing".to_string())?
                .get_conversation("source-fault")
                .await
                .map_err(|error| error.to_string())?
                .is_some()
        );
        Ok(())
    }

    #[tokio::test]
    async fn managed_replacement_guard_blocks_new_turn_until_hydration_finishes()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let workspace_root = temp.path().join("workspace-a");
        std::fs::create_dir_all(&workspace_root).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;
        let registered = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                workspace_root,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(registered)
            .await
            .map_err(|error| error.to_string())?;
        let runtime = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        runtime
            .ensure_conversation(echo_agent::memory::NewConversation {
                conversation_id: "replace-guard".to_string(),
                user_id: "test".to_string(),
                agent_type: None,
                title: None,
            })
            .await
            .map_err(|error| error.to_string())?;
        let admission = runtime
            .begin_managed_replacement(&state.session.foreground_turns, "replace-guard")
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            state
                .session
                .foreground_turns
                .begin_scoped(
                    "workspace-a",
                    crate::foreground_turn::ForegroundTurnSurface::Gui,
                    "replace-guard",
                    "blocked-turn",
                )
                .is_err()
        );
        drop(admission);
        let accepted = state
            .begin_conversation_turn_owned(
                crate::foreground_turn::ForegroundTurnSurface::Gui,
                "replace-guard",
                "accepted-turn",
            )
            .await
            .map_err(|error| error.to_string())?;
        drop(accepted);
        Ok(())
    }

    #[tokio::test]
    async fn branch_import_failure_releases_owners_before_aggregate_rollback() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("workspace-a");
        std::fs::create_dir_all(&root).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;
        let workspace = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace)
            .await
            .map_err(|error| error.to_string())?;
        let runtime = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        runtime
            .ensure_conversation(echo_agent::memory::NewConversation {
                conversation_id: "failed-branch".to_string(),
                user_id: "test".to_string(),
                agent_type: None,
                title: None,
            })
            .await
            .map_err(|error| error.to_string())?;
        let admission = runtime
            .begin_managed_replacement(&state.session.foreground_turns, "failed-branch")
            .await
            .map_err(|error| error.to_string())?;
        let execution = runtime
            .agent_for("failed-branch")
            .await
            .map_err(|error| error.to_string())?;
        let store = runtime
            .conversation_store()
            .ok_or_else(|| "conversation store missing".to_string())?;
        let runtime_state = runtime
            .runtime_state_store()
            .ok_or_else(|| "runtime state store missing".to_string())?;
        let failed = crate::managed_conversation::replace_and_resume(
            store.as_ref(),
            runtime_state.as_ref(),
            &execution.agent(),
            "failed-branch",
            &[echo_agent::memory::StoredMessage {
                id: None,
                conversation_id: "failed-branch".to_string(),
                role: "invalid-role".to_string(),
                content: Some("invalid".to_string()),
                attachments_json: None,
                tool_calls_json: None,
                tool_result_json: None,
                created_at: Utc::now().to_rfc3339(),
            }],
        )
        .await;
        assert!(failed.is_err());
        drop(execution);
        drop(admission);
        let receipt = tokio::time::timeout(
            std::time::Duration::from_secs(5),
            state.delete_conversation_scoped("workspace-a", "failed-branch"),
        )
        .await
        .map_err(|_| "branch rollback waited on its own admission".to_string())?
        .map_err(|error| error.to_string())?;
        assert_eq!(receipt.conversation_id, "failed-branch");
        Ok(())
    }

    #[tokio::test]
    async fn owner_loss_before_first_transcript_row_settles_empty_visibility() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("workspace-a");
        std::fs::create_dir_all(&root).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;
        let workspace = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace)
            .await
            .map_err(|error| error.to_string())?;
        let runtime = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        let conversation = echo_agent::memory::NewConversation {
            conversation_id: "empty-effect".to_string(),
            user_id: "test".to_string(),
            agent_type: None,
            title: None,
        };
        let store = runtime
            .conversation_store()
            .ok_or_else(|| "store missing".to_string())?;
        let authority = store
            .ensure_projection_epoch(echo_agent::memory::EnsureConversationProjectionRequest {
                conversation,
                expected_tombstone_epoch: None,
            })
            .await
            .map_err(|error| error.to_string())?
            .authority;
        let target = crate::agent_router::AgentAddress::new(
            crate::workspace::WorkspaceId::from_raw("workspace-a".to_string()),
            "empty-effect".to_string(),
        );
        let mut delivery =
            crate::agent_router::AgentMessage::agent_text(None, target.clone(), "inspect");
        delivery.message_id = "empty-effect-delivery".to_string();
        state.storage.conversation_archive.prepare_internal_turn(
            "workspace-a",
            "empty-effect",
            authority.epoch,
            &delivery.message_id,
            0,
            &render_agent_delivery_instruction(&delivery),
        )?;
        state
            .agent_router
            .enqueue(delivery)
            .await
            .map_err(|error| error.to_string())?;
        let claim = state
            .agent_router
            .claim_next(&target)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "claim missing".to_string())?;
        state
            .agent_router
            .begin_injection(&claim, "lost-before-row")
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            state
                .reconcile_agent_delivery_in_flight(
                    &target,
                    &[],
                    &tokio_util::sync::CancellationToken::new(),
                )
                .await
                .map_err(|error| error.to_string())?
        );
        let records = state
            .agent_router
            .records(&target)
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            records
                .iter()
                .any(|record| record.message_id == "empty-effect-delivery"
                    && record.terminal
                    && record.outcome
                        == Some(crate::agent_router::AgentDeliveryOutcome::OutcomeUnknown))
        );
        assert!(
            state
                .storage
                .conversation_archive
                .pending_internal_turns("workspace-a", "empty-effect")?
                .is_empty()
        );
        assert!(
            state
                .internal_message_ids_scoped("workspace-a", "empty-effect")
                .await?
                .is_empty()
        );
        Ok(())
    }

    #[tokio::test]
    async fn side_to_primary_visibility_recovers_after_terminal_before_projection()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root = temp.path().join("workspace-a");
        std::fs::create_dir_all(&root).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;
        let workspace = state
            .workspace
            .registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root,
            )
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace)
            .await
            .map_err(|error| error.to_string())?;
        let runtime = state
            .chat_runtime_for_scope("workspace-a")
            .await
            .map_err(|error| error.to_string())?;
        let store = runtime
            .conversation_store()
            .ok_or_else(|| "conversation store missing".to_string())?;
        store
            .create_conversation(echo_agent::memory::NewConversation {
                conversation_id: "primary".to_string(),
                user_id: "test".to_string(),
                agent_type: None,
                title: Some("Primary".to_string()),
            })
            .await
            .map_err(|error| error.to_string())?;
        let side =
            crate::side_conversation::SideConversationService::new(Arc::clone(&state.agent_router))
                .create(
                    Arc::clone(&store),
                    crate::side_conversation::SideConversationCreateRequest {
                        workspace_id: "workspace-a".to_string(),
                        parent_conversation_id: "primary".to_string(),
                        request_id: "side-recovery".to_string(),
                        prompt: "inspect".to_string(),
                        title: None,
                        model_id: None,
                    },
                )
                .await
                .map_err(|error| error.to_string())?;
        let source = crate::agent_router::AgentAddress::new(
            crate::workspace::WorkspaceId::from_raw("workspace-a".to_string()),
            side.entry.conversation_id,
        );
        let target = crate::agent_router::AgentAddress::new(
            crate::workspace::WorkspaceId::from_raw("workspace-a".to_string()),
            "primary".to_string(),
        );
        let mut delivery = crate::agent_router::AgentMessage::agent_text(
            Some(source),
            target.clone(),
            "side result",
        );
        delivery.message_id = "delivery-recovery".to_string();
        assert!(
            state
                .agent_delivery_involves_side_conversation(&delivery)
                .await
                .map_err(|error| error.to_string())?
        );
        let instruction = render_agent_delivery_instruction(&delivery);
        let epoch = store
            .ensure_projection_epoch(echo_agent::memory::EnsureConversationProjectionRequest {
                conversation: echo_agent::memory::NewConversation {
                    conversation_id: "primary".to_string(),
                    user_id: "test".to_string(),
                    agent_type: None,
                    title: Some("Primary".to_string()),
                },
                expected_tombstone_epoch: None,
            })
            .await
            .map_err(|error| error.to_string())?;
        state.storage.conversation_archive.prepare_internal_turn(
            "workspace-a",
            "primary",
            epoch.authority.epoch,
            &delivery.message_id,
            0,
            &instruction,
        )?;
        store
            .apply_transcript_projection(
                echo_agent::memory::TranscriptProjectionBatch::prepare(
                    "primary",
                    epoch.authority.epoch,
                    "primary",
                    0,
                    vec![
                        echo_agent::memory::StoredMessage {
                            id: None,
                            conversation_id: "primary".to_string(),
                            role: "user".to_string(),
                            content: Some(instruction),
                            attachments_json: None,
                            tool_calls_json: None,
                            tool_result_json: None,
                            created_at: Utc::now().to_rfc3339(),
                        },
                        echo_agent::memory::StoredMessage {
                            id: None,
                            conversation_id: "primary".to_string(),
                            role: "assistant".to_string(),
                            content: Some("acknowledged".to_string()),
                            attachments_json: None,
                            tool_calls_json: None,
                            tool_result_json: None,
                            created_at: Utc::now().to_rfc3339(),
                        },
                    ],
                )
                .map_err(|error| error.to_string())?,
            )
            .await
            .map_err(|error| error.to_string())?;
        state
            .agent_router
            .enqueue(delivery)
            .await
            .map_err(|error| error.to_string())?;
        let claim = state
            .agent_router
            .claim_next(&target)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "delivery claim missing".to_string())?;
        state
            .agent_router
            .begin_injection(&claim, "turn-recovery")
            .await
            .map_err(|error| error.to_string())?;
        state
            .agent_router
            .mailbox_accepted(&claim, "turn-recovery")
            .await
            .map_err(|error| error.to_string())?;
        state
            .agent_router
            .drained(&claim, "turn-recovery")
            .await
            .map_err(|error| error.to_string())?;
        let committed = store
            .get_messages("primary")
            .await
            .map_err(|error| error.to_string())?;
        let committed_ids = committed
            .iter()
            .filter_map(|row| row.id)
            .collect::<std::collections::BTreeSet<_>>();
        state
            .storage
            .conversation_archive
            .fail_next_persist_for_test();
        assert!(
            state
                .storage
                .conversation_archive
                .settle_internal_turn(
                    "workspace-a",
                    "primary",
                    "delivery-recovery",
                    committed_ids.clone(),
                )
                .is_err()
        );
        assert!(
            state
                .agent_router
                .records(&target)
                .await
                .map_err(|error| error.to_string())?
                .iter()
                .any(|record| record.message_id == "delivery-recovery" && !record.terminal)
        );
        assert!(
            state
                .reconcile_agent_delivery_in_flight(
                    &target,
                    &[],
                    &tokio_util::sync::CancellationToken::new(),
                )
                .await
                .map_err(|error| error.to_string())?
        );
        assert!(
            state
                .agent_router
                .records(&target)
                .await
                .map_err(|error| error.to_string())?
                .iter()
                .any(|record| record.message_id == "delivery-recovery" && record.terminal)
        );
        let ids = state
            .internal_message_ids_scoped("workspace-a", "primary")
            .await?;
        assert_eq!(ids, committed_ids);
        assert!(
            state
                .storage
                .conversation_archive
                .pending_internal_turns("workspace-a", "primary")?
                .is_empty()
        );
        let reopened = crate::conversation_archive::ConversationArchiveStore::open(
            temp.path().join("conversation-visibility.json"),
        )?;
        assert_eq!(
            reopened.internal_message_ids("workspace-a", "primary")?,
            ids
        );
        for index in 0..4 {
            let mut later = crate::agent_router::AgentMessage::agent_text(
                None,
                target.clone(),
                "x".repeat(90_000),
            );
            later.message_id = format!("evict-terminal-{index}");
            state
                .agent_router
                .enqueue(later)
                .await
                .map_err(|error| error.to_string())?;
            let claim = state
                .agent_router
                .claim_next(&target)
                .await
                .map_err(|error| error.to_string())?
                .ok_or_else(|| "later delivery claim missing".to_string())?;
            let turn_id = format!("eviction-turn-{index}");
            state
                .agent_router
                .begin_injection(&claim, turn_id.clone())
                .await
                .map_err(|error| error.to_string())?;
            state
                .agent_router
                .mailbox_accepted(&claim, turn_id.clone())
                .await
                .map_err(|error| error.to_string())?;
            state
                .agent_router
                .drained(&claim, turn_id.clone())
                .await
                .map_err(|error| error.to_string())?;
            state
                .agent_router
                .turn_settled(
                    &claim,
                    Some(turn_id),
                    crate::agent_router::AgentDeliveryOutcome::Completed,
                    true,
                    None,
                    false,
                    None,
                )
                .await
                .map_err(|error| error.to_string())?;
        }
        assert!(
            state
                .agent_router
                .records(&target)
                .await
                .map_err(|error| error.to_string())?
                .iter()
                .all(|record| record.message_id != "delivery-recovery")
        );
        assert_eq!(
            state
                .internal_message_ids_scoped("workspace-a", "primary")
                .await?,
            ids
        );
        Ok(())
    }

    #[tokio::test]
    async fn extension_control_for_runtime_keeps_captured_workspace_after_focus_change()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root_a = temp.path().join("workspace-a");
        let root_b = temp.path().join("workspace-b");
        std::fs::create_dir_all(&root_a).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&root_b).map_err(|error| error.to_string())?;
        let canonical_a = root_a.canonicalize().map_err(|error| error.to_string())?;
        let canonical_b = root_b.canonicalize().map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;

        state
            .switch_workspace(workspace("workspace-a", root_a))
            .await
            .map_err(|error| error.to_string())?;
        let runtime_a = state
            .current_control_runtime()
            .await
            .map_err(|error| error.to_string())?;
        state
            .switch_workspace(workspace("workspace-b", root_b))
            .await
            .map_err(|error| error.to_string())?;

        let control_a = state
            .extension_control_for_runtime(&runtime_a)
            .await
            .map_err(|error| error.to_string())?;
        let control_b = state
            .current_extension_control()
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            control_a.runtime().execution_scope().workspace_id(),
            "workspace-a"
        );
        assert_eq!(control_a.project_root(), canonical_a.as_path());
        assert_eq!(
            control_b.runtime().execution_scope().workspace_id(),
            "workspace-b"
        );
        assert_eq!(control_b.project_root(), canonical_b.as_path());
        assert!(!Arc::ptr_eq(
            &control_a.plugin_runtime(),
            &control_b.plugin_runtime()
        ));
        let enabled = crate::skills_hub::enabled_skills::EnabledSkillsConfig::load(
            &temp.path().join("enabled-skills.json"),
        )
        .map_err(|error| error.to_string())?;
        // ADR 0041:首次加载只创建空配置，不隐式启用任何产品内置 Skill。
        assert!(enabled.skills.is_empty());
        Ok(())
    }

    async fn relinked_task_control_fixture(
        root: &std::path::Path,
    ) -> Result<
        (Arc<AppState>, crate::workspace::WorkspaceId, String, String),
        Box<dyn std::error::Error>,
    > {
        let first_root = root.join("project-before");
        let next_root = root.join("project-after");
        std::fs::create_dir_all(&first_root)?;
        std::fs::create_dir_all(&next_root)?;
        let (state, _, _) = extension_control_state(root).await?;
        let workspace = state.workspace.registry.create_at(
            "generation-control",
            crate::workspace::WorkspaceKind::General,
            first_root,
        )?;
        let id = workspace.id.clone();
        state.switch_workspace(workspace).await?;
        let old_control = state.workspace_control_for_scope(id.as_str()).await?;
        let old_generation = old_control.generation();
        let old_store = old_control
            .runtime()
            .task_runtime()
            .ok_or("old task runtime missing")?;
        old_store.create_run(
            "same-run",
            id.as_str(),
            "conversation",
            "root",
            crate::tasks::task_runtime::DomainProfile::General,
            "preserve captured project",
            "agent_task_plan",
            crate::tasks::task_runtime::AttendedMode::Attended,
        )?;
        drop(old_store);
        drop(old_control);
        state.link_workspace_project_owned(&id, next_root).await?;
        let current = state.workspace_control_for_scope(id.as_str()).await?;
        let current_generation = current.generation();
        assert_ne!(old_generation, current_generation);
        let store = current
            .runtime()
            .task_runtime()
            .ok_or("new task runtime missing")?;
        store.transition_run(
            "same-run",
            crate::tasks::task_runtime::TaskRunStatus::Running,
        )?;
        drop(store);
        drop(current);
        Ok((state, id, old_generation, current_generation))
    }

    #[tokio::test]
    async fn task_control_generation_rejects_relinked_workspace_without_mutation()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let (state, id, old_generation, current_generation) =
            relinked_task_control_fixture(temp.path()).await?;
        let current = state
            .workspace_control_for_generation(id.as_str(), &current_generation)
            .await?;
        let store = current
            .runtime()
            .task_runtime()
            .ok_or("new task runtime missing")?;
        let before = store.get_run_state("same-run")?.ok_or("new run missing")?;
        // These commands all use this production helper before mutation or launch.
        for action in [
            "pause", "cancel", "resume", "retry", "goal", "budget", "graph", "recovery", "skip",
        ] {
            let rejected = state
                .workspace_control_for_generation(id.as_str(), &old_generation)
                .await;
            assert!(
                rejected.is_err(),
                "late {action} accepted a replacement generation"
            );
            let unchanged = store.get_run_state("same-run")?.ok_or("run disappeared")?;
            assert_eq!(unchanged.journal_sequence, before.journal_sequence);
            assert_eq!(unchanged.run.status, before.run.status);
        }
        Ok(())
    }

    #[tokio::test]
    async fn task_control_generation_current_token_mutates_the_captured_store()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let (state, id, _, generation) = relinked_task_control_fixture(temp.path()).await?;
        let checked = state
            .workspace_control_for_generation(id.as_str(), &generation)
            .await?;
        let store = checked
            .runtime()
            .task_runtime()
            .ok_or("checked runtime missing")?;
        let before = store
            .get_run_state("same-run")?
            .ok_or("running snapshot missing")?
            .journal_sequence;
        assert!(store.request_pause("same-run")?);
        assert_eq!(
            store
                .get_run("same-run")?
                .ok_or("paused run missing")?
                .status,
            crate::tasks::task_runtime::TaskRunStatus::Paused
        );
        assert!(
            store
                .get_run_state("same-run")?
                .ok_or("paused snapshot missing")?
                .journal_sequence
                > before
        );
        Ok(())
    }

    #[tokio::test]
    async fn task_control_generation_retains_its_original_control_lease()
    -> Result<(), Box<dyn std::error::Error>> {
        let temp = tempfile::tempdir()?;
        let (state, id, _, generation) = relinked_task_control_fixture(temp.path()).await?;
        let checked = state
            .workspace_control_for_generation(id.as_str(), &generation)
            .await?;
        let pinned_runtime = checked.runtime().clone();
        drop(checked);
        // The returned runtime clone still owns the original lease used by every command.
        assert!(
            state
                .evict_workspace_runtime_if_idle_for_test(&id)
                .await
                .is_err_and(|error| error.to_string().contains("controls: 1"))
        );
        let store = pinned_runtime
            .task_runtime()
            .ok_or("pinned runtime missing")?;
        assert!(store.request_pause("same-run")?);
        drop(store);
        drop(pinned_runtime);
        // Once the captured operation releases its runtime clone, the original
        // lifecycle may complete the same eviction path.
        assert!(state.evict_workspace_runtime_if_idle_for_test(&id).await?);
        Ok(())
    }

    #[tokio::test]
    async fn extension_control_for_runtime_rejects_replaced_workspace_generation()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root_a = temp.path().join("workspace-a");
        let root_b = temp.path().join("workspace-b");
        std::fs::create_dir_all(&root_a).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&root_b).map_err(|error| error.to_string())?;
        let (state, _, _) = extension_control_state(temp.path()).await?;

        state
            .switch_workspace(workspace("workspace-a", root_a.clone()))
            .await
            .map_err(|error| error.to_string())?;
        let runtime_a = state
            .current_control_runtime()
            .await
            .map_err(|error| error.to_string())?;
        // Preserve the captured identity without its control lease so the test
        // can model a delayed surface request after the old host is evicted.
        let stale_runtime = ScopedChatRuntime {
            _lifetime: ScopedRuntimeLifetime::Global,
            execution_scope: runtime_a.execution_scope.clone(),
            workspace_io_identity: runtime_a.workspace_io_identity.clone(),
            primary_agent: runtime_a.primary_agent.clone(),
            pool: runtime_a.pool.clone(),
            task_runtime: runtime_a.task_runtime.clone(),
            review_integration: runtime_a.review_integration.clone(),
            conversation_store: runtime_a.conversation_store.clone(),
            runtime_state_store: runtime_a.runtime_state_store.clone(),
            deletions: Arc::clone(&runtime_a.deletions),
            handoffs: Arc::clone(&runtime_a.handoffs),
        };
        drop(runtime_a);
        state
            .switch_workspace(workspace("workspace-b", root_b))
            .await
            .map_err(|error| error.to_string())?;
        let workspace_a_id = crate::workspace::WorkspaceId::from_name("workspace-a");
        assert!(
            state
                .evict_workspace_runtime_if_idle_for_test(&workspace_a_id)
                .await
                .map_err(|error| error.to_string())?
        );
        state
            .switch_workspace(workspace("workspace-a", root_a))
            .await
            .map_err(|error| error.to_string())?;

        let error = state
            .extension_control_for_runtime(&stale_runtime)
            .await
            .err()
            .ok_or_else(|| "replaced workspace generation was accepted".to_string())?;
        assert!(
            error
                .to_string()
                .contains("workspace 'workspace-a' extension runtime generation was replaced")
        );
        Ok(())
    }

    #[tokio::test]
    async fn extension_control_for_runtime_matches_global_pool_identity() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let (state, seed_pool, plugin_runtime) = extension_control_state(temp.path()).await?;
        let global_runtime = state
            .chat_runtime_for_scope("global")
            .await
            .map_err(|error| error.to_string())?;

        let control = state
            .extension_control_for_runtime(&global_runtime)
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(control.runtime().execution_scope().workspace_id(), "global");
        assert!(Arc::ptr_eq(
            &control
                .runtime()
                .pool()
                .ok_or_else(|| "global runtime pool missing".to_string())?,
            &seed_pool
        ));
        assert!(Arc::ptr_eq(&control.plugin_runtime(), &plugin_runtime));

        let other_agent = AgentHandle::new(
            ReactAgentBuilder::new()
                .llm_client(Arc::new(MockLlmClient::new()))
                .system_prompt("replacement global runtime")
                .build()
                .map_err(|error| error.to_string())?,
        );
        let mismatched_runtime = ScopedChatRuntime {
            pool: Some(Arc::new(
                crate::agent_pool::AgentPool::new_for_test(other_agent, None, None, 1, false).await,
            )),
            ..global_runtime.clone()
        };
        assert!(
            state
                .extension_control_for_runtime(&mismatched_runtime)
                .await
                .is_err_and(|error| error
                    .to_string()
                    .contains("global extension runtime generation was replaced"))
        );
        Ok(())
    }

    #[test]
    fn workspace_transition_receipt_serializes_generated_typescript_contract()
    -> std::result::Result<(), String> {
        let receipt = WorkspaceTransitionReceipt::committed(
            Some("workspace-a".to_string()),
            Some("workspace-b".to_string()),
            std::path::PathBuf::from("/workspace-b"),
            vec![WorkspaceSubsystemTransition {
                subsystem: "config_watcher".to_string(),
                target_root: std::path::PathBuf::from("/workspace-b"),
                stale_roots: Vec::new(),
                error: "watch settled with degraded cleanup".to_string(),
            }],
        );
        let serialized = serde_json::to_value(receipt).map_err(|error| error.to_string())?;

        assert_eq!(
            serialized.get("status").and_then(serde_json::Value::as_str),
            Some("degraded")
        );
        assert_eq!(
            serialized
                .get("target_root")
                .and_then(serde_json::Value::as_str),
            Some("/workspace-b")
        );
        assert_eq!(
            serialized
                .pointer("/degraded_subsystems/0/stale_roots")
                .and_then(serde_json::Value::as_array)
                .map(Vec::len),
            Some(0)
        );
        Ok(())
    }

    #[tokio::test]
    async fn linking_the_same_project_keeps_the_shared_review_owner_and_focus() -> anyhow::Result<()>
    {
        let temp = tempfile::tempdir()?;
        let registry = Arc::new(WorkspaceRegistry::with_base_dir(
            temp.path().join("registry"),
        )?);
        let workspace = registry.create_at(
            "same-link",
            crate::workspace::WorkspaceKind::General,
            temp.path().join("workspace"),
        )?;
        let project = temp.path().join("project");
        std::fs::create_dir_all(&project)?;
        let project = project.canonicalize()?;
        let workspace = registry.link_project(&workspace.id, project.clone())?;
        let store = Arc::new(echo_agent::memory::FileStore::new(
            crate::workspace::layout::WorkspaceLayout::memory_store(&workspace.root),
        )?) as Arc<dyn echo_agent::memory::Store>;
        let review = Arc::new(
            crate::evolution::ReviewIntegration::new_scoped_with_project_root(
                echo_agent::evolution::ReviewConfig::default(),
                crate::workspace::layout::WorkspaceLayout::state_dir(
                    &workspace.root.canonicalize()?,
                ),
                store.clone(),
                workspace.id.to_string(),
                workspace.opaque_product_data_generation(),
                workspace.project_root.clone(),
            ),
        );
        let primary = AgentHandle::new(
            ReactAgentBuilder::new()
                .llm_client(Arc::new(MockLlmClient::new()))
                .store(store.clone())
                .system_prompt("same-project link regression")
                .build()?,
        );
        let seed = Arc::new(
            crate::agent_pool::AgentPool::new_for_test(
                primary.clone(),
                Some(review.clone()),
                Some(store),
                2,
                false,
            )
            .await,
        );
        let mut state = AppState::from_shared(
            primary,
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
                temp.path().join("mcp.json"),
                Default::default(),
            )),
            crate::product_data_io::ProductDataIoService::new(),
        )?;
        state.workspace.registry = registry;
        state = state.with_review_integration(Some(review.clone()));
        state.set_pool(seed.clone());
        let state = Arc::new(state);
        state.switch_workspace(workspace.clone()).await?;
        let host = state
            .workspace
            .runtimes
            .loaded_host(&workspace.id)
            .await
            .ok_or_else(|| anyhow::anyhow!("focused Host is missing"))?;
        let execution = host.get_or_open_execution(&seed).await?;
        assert!(Arc::ptr_eq(&review, &execution.review_integration()));
        let original_generation = workspace.opaque_product_data_generation();

        let linked = state.link_current_workspace_project_owned(project).await?;
        assert_eq!(linked.opaque_product_data_generation(), original_generation);
        assert!(
            state
                .current_workspace()
                .await
                .is_some_and(|current| current.id == workspace.id)
        );
        let same_host = state
            .workspace
            .runtimes
            .loaded_host(&workspace.id)
            .await
            .ok_or_else(|| anyhow::anyhow!("idempotent link removed the focused Host"))?;
        assert!(Arc::ptr_eq(&host, &same_host));
        assert!(Arc::ptr_eq(
            &review,
            &same_host
                .get_or_open_execution(&seed)
                .await?
                .review_integration()
        ));
        let generation = review.lease_generation()?;
        assert!(
            generation
                .matches_workspace_binding(
                    crate::workspace::layout::WorkspaceLayout::state_dir(
                        &workspace.root.canonicalize()?
                    )
                    .as_path(),
                    workspace.id.as_str(),
                    &original_generation,
                )
                .map_err(anyhow::Error::msg)?
        );
        drop(generation);
        state.shutdown_workspace_runtimes().await?;
        seed.shutdown().await.map_err(anyhow::Error::msg)?;
        Ok(())
    }

    #[tokio::test]
    async fn focus_changes_preserve_independent_running_workspace_hosts()
    -> std::result::Result<(), String> {
        let process_cwd = std::env::current_dir().map_err(|error| error.to_string())?;
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let root_a = temp.path().join("workspace-a");
        let root_b = temp.path().join("workspace-b");
        std::fs::create_dir_all(&root_a).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&root_b).map_err(|error| error.to_string())?;
        let canonical_a = root_a.canonicalize().map_err(|error| error.to_string())?;
        let canonical_b = root_b.canonicalize().map_err(|error| error.to_string())?;

        let agent = AgentHandle::new(
            ReactAgentBuilder::new()
                .llm_client(Arc::new(MockLlmClient::new()))
                .system_prompt("workspace focus test")
                .build()
                .map_err(|error| error.to_string())?,
        );
        let seed_pool = Arc::new(
            crate::agent_pool::AgentPool::new_for_test(agent.clone(), None, None, 4, false).await,
        );
        let global_store: Arc<dyn ConversationStore> = Arc::new(
            FileConversationStore::new(temp.path().join("global-conversations"))
                .map_err(|error| error.to_string())?,
        );
        let mcp_runtime = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            temp.path().join("mcp.json"),
            Default::default(),
        ));
        let mut state = AppState::from_shared(
            agent.clone(),
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            Some(global_store.clone()),
            None,
            Default::default(),
            mcp_runtime,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?;
        state.tasks.runtime = Some(Arc::new(
            crate::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                .map_err(|error| error.to_string())?,
        ));
        state.storage.chat_events = Arc::new(
            crate::chat_event_log::ChatEventLog::open(
                temp.path().join("chat-events"),
                crate::chat_event_log::ChatEventRetention::default(),
            )
            .map_err(|error| error.to_string())?,
        );
        state.storage.tool_executions = Arc::new(
            crate::tool_execution::ToolExecutionRepository::open(
                temp.path().join("tool-executions"),
            )
            .map_err(|error| error.to_string())?,
        );
        let workspace_registry = Arc::new(
            WorkspaceRegistry::with_base_dir(temp.path().join("workspace-registry"))
                .map_err(|error| error.to_string())?,
        );
        workspace_registry
            .create_at(
                "workspace-a",
                crate::workspace::WorkspaceKind::General,
                root_a.clone(),
            )
            .map_err(|error| error.to_string())?;
        workspace_registry
            .create_at(
                "workspace-b",
                crate::workspace::WorkspaceKind::General,
                root_b.clone(),
            )
            .map_err(|error| error.to_string())?;
        state.workspace.registry = workspace_registry;
        state.set_pool(seed_pool);
        let state = Arc::new(state);

        state
            .workspace
            .transitioning
            .store(true, std::sync::atomic::Ordering::Release);
        assert!(matches!(
            state.current_control_runtime().await,
            Err(ScopedControlError::WorkspaceTransition)
        ));
        state
            .workspace
            .transitioning
            .store(false, std::sync::atomic::Ordering::Release);

        let missing_root = temp.path().join("missing-workspace");
        assert!(
            state
                .switch_workspace(workspace("missing", missing_root))
                .await
                .is_err()
        );
        assert_eq!(
            state
                .current_control_runtime()
                .await
                .map_err(|error| error.to_string())?
                .execution_scope()
                .workspace_id(),
            "global"
        );

        let (entered, release) = state.park_next_workspace_transition()?;
        let detached_state = Arc::clone(&state);
        let detached_workspace = workspace("workspace-a", root_a.clone());
        let waiter =
            tokio::spawn(async move { detached_state.switch_workspace(detached_workspace).await });
        entered
            .await
            .map_err(|_| "workspace transition did not reach test barrier".to_string())?;
        assert!(matches!(
            state.current_control_runtime().await,
            Err(ScopedControlError::WorkspaceTransition)
        ));
        waiter.abort();
        let _ = waiter.await;
        release
            .send(())
            .map_err(|_| "workspace transition release receiver was dropped".to_string())?;
        state
            .switch_workspace(workspace("workspace-a", root_a))
            .await
            .map_err(|error| error.to_string())?;
        let runtime_a = state
            .current_control_runtime()
            .await
            .map_err(|error| error.to_string())?;
        let explicit_global = state
            .chat_runtime_for_scope("global")
            .await
            .map_err(|error| error.to_string())?;
        let explicit_global_store = explicit_global
            .conversation_store()
            .ok_or_else(|| "explicit global conversation store missing".to_string())?;
        let workspace_a_store = runtime_a
            .conversation_store()
            .ok_or_else(|| "workspace A conversation store missing".to_string())?;
        assert!(Arc::ptr_eq(&explicit_global_store, &global_store));
        assert!(!Arc::ptr_eq(&explicit_global_store, &workspace_a_store));
        assert!(explicit_global.runtime_state_store().is_none());
        assert!(runtime_a.runtime_state_store().is_some());
        let foreground_a = state
            .begin_conversation_turn_owned(
                crate::foreground_turn::ForegroundTurnSurface::Gui,
                "same-conversation",
                "turn-a",
            )
            .await
            .map_err(|error| error.to_string())?;
        let execution_a = runtime_a
            .agent_for("same-conversation")
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            execution_a.agent().read(|agent| agent.working_dir()).await,
            Some(canonical_a.clone())
        );
        let task_store_a = runtime_a
            .task_runtime()
            .ok_or_else(|| "workspace A TaskRuntime missing".to_string())?;
        task_store_a
            .create_run(
                "shared-run",
                "workspace-a",
                "same-conversation",
                "root-a",
                crate::tasks::task_runtime::DomainProfile::General,
                "workspace A goal",
                "task",
                crate::tasks::task_runtime::AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        let memory_a = runtime_a
            .review_integration()
            .ok_or_else(|| "workspace A memory integration missing".to_string())?
            .lease_generation()
            .map_err(|error| error.to_string())?;
        let memory_manager_a = memory_a
            .layer_manager()
            .map_err(|error| error.to_string())?;
        memory_manager_a
            .write_memory(
                "shared-memory",
                "workspace A memory",
                echo_agent::memory::MemoryMeta::new(
                    echo_agent::memory::MemoryType::ProjectFact,
                    echo_agent::memory::MemorySource::ExplicitSave,
                    "explicit",
                ),
            )
            .await
            .map_err(|error| error.to_string())?;
        let projection_a = memory_a.settle_hot_memory_projection().await;
        if let Some(error) = projection_a.error {
            return Err(format!("workspace A projection did not settle: {error}"));
        }

        let receipt_b = state
            .switch_workspace(workspace("workspace-b", root_b))
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            receipt_b.status,
            WorkspaceTransitionStatus::Committed,
            "workspace switch degraded: {receipt_b:?}"
        );
        assert!(
            state
                .delete_workspace_owned(&crate::workspace::WorkspaceId::from_name("workspace-a"))
                .await
                .is_err_and(|error| error.to_string().contains("active foreground"))
        );
        let runtime_b = state
            .current_control_runtime()
            .await
            .map_err(|error| error.to_string())?;
        let prelink_product_b = state
            .current_product_data()
            .await
            .map_err(|error| error.to_string())?;
        let prelink_generation_b = prelink_product_b.generation();
        std::fs::write(canonical_b.join("same.txt"), "same bytes")
            .map_err(|error| error.to_string())?;
        drop(prelink_product_b);
        drop(runtime_b);
        let invalid_project = temp.path().join("invalid-project-file");
        std::fs::write(&invalid_project, "not a project directory")
            .map_err(|error| error.to_string())?;
        assert!(
            state
                .link_current_workspace_project_owned(invalid_project)
                .await
                .is_err()
        );
        assert_eq!(
            state
                .current_workspace()
                .await
                .ok_or_else(|| "current workspace disappeared after invalid relink".to_string())?
                .id
                .as_str(),
            "workspace-b"
        );
        let linked_project = temp.path().join("workspace-b-project");
        std::fs::create_dir_all(&linked_project).map_err(|error| error.to_string())?;
        std::fs::write(linked_project.join("same.txt"), "same bytes")
            .map_err(|error| error.to_string())?;
        let linked_skill = linked_project.join(".eko/skills/linked-review");
        std::fs::create_dir_all(&linked_skill).map_err(|error| error.to_string())?;
        std::fs::write(
            linked_project.join("AGENTS.md"),
            "LINKED_PROJECT_AGENT_RULE",
        )
        .map_err(|error| error.to_string())?;
        std::fs::write(
            linked_skill.join("SKILL.md"),
            "---\nname: linked-review\ndescription: Review linked project\n---\n# Review",
        )
        .map_err(|error| error.to_string())?;
        let canonical_linked_project = linked_project
            .canonicalize()
            .map_err(|error| error.to_string())?;
        let linked_workspace = state
            .link_current_workspace_project_owned(linked_project.clone())
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(linked_workspace.id.as_str(), "workspace-b");
        assert_eq!(
            linked_workspace.project_root,
            Some(canonical_linked_project.clone())
        );
        assert!(
            state
                .product_data_for_scope("workspace-b", &prelink_generation_b)
                .await
                .is_err()
        );
        let runtime_b = state
            .current_control_runtime()
            .await
            .map_err(|error| error.to_string())?;
        let execution_b = runtime_b
            .agent_for("same-conversation")
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            execution_b.agent().read(|agent| agent.working_dir()).await,
            Some(canonical_b.clone())
        );
        assert!(
            execution_b
                .agent()
                .read(|agent| agent.has_skill("linked-review"))
                .await
        );
        let linked_context = execution_b
            .agent()
            .read(|agent| agent.context().clone())
            .await;
        let linked_context_text = linked_context
            .lock()
            .await
            .messages()
            .iter()
            .filter_map(|message| message.content.as_text_ref())
            .collect::<Vec<_>>()
            .join("\n");
        assert!(linked_context_text.contains("LINKED_PROJECT_AGENT_RULE"));
        let task_store_b = runtime_b
            .task_runtime()
            .ok_or_else(|| "workspace B TaskRuntime missing".to_string())?;
        task_store_b
            .create_run(
                "shared-run",
                "workspace-b",
                "same-conversation",
                "root-b",
                crate::tasks::task_runtime::DomainProfile::General,
                "workspace B goal",
                "task",
                crate::tasks::task_runtime::AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        let memory_b = runtime_b
            .review_integration()
            .ok_or_else(|| "workspace B memory integration missing".to_string())?
            .lease_generation()
            .map_err(|error| error.to_string())?;
        let memory_manager_b = memory_b
            .layer_manager()
            .map_err(|error| error.to_string())?;
        memory_manager_b
            .write_memory(
                "shared-memory",
                "workspace B memory",
                echo_agent::memory::MemoryMeta::new(
                    echo_agent::memory::MemoryType::ProjectFact,
                    echo_agent::memory::MemorySource::ExplicitSave,
                    "explicit",
                ),
            )
            .await
            .map_err(|error| error.to_string())?;
        let projection_b = memory_b.settle_hot_memory_projection().await;
        if let Some(error) = projection_b.error {
            return Err(format!("workspace B projection did not settle: {error}"));
        }
        let profile_store_a = echo_agent::profiles::ProfileStore::new(memory_a.memory_store());
        let profile_store_b = echo_agent::profiles::ProfileStore::new(memory_b.memory_store());
        let mut profile_a = echo_agent::profiles::UserProfile::new();
        profile_a.set_preference("scope", "workspace A");
        profile_store_a
            .save_user_profile(&profile_a)
            .await
            .map_err(|error| error.to_string())?;
        let mut profile_b = echo_agent::profiles::UserProfile::new();
        profile_b.set_preference("scope", "workspace B");
        profile_store_b
            .save_user_profile(&profile_b)
            .await
            .map_err(|error| error.to_string())?;
        let evidence_a = memory_a.evidence_store();
        let evidence_b = memory_b.evidence_store();
        evidence_a
            .upsert(crate::evolution::EvidenceCandidateDraft {
                kind: crate::evolution::EvidenceKind::ProjectFact,
                scope: None,
                content: "workspace A evidence".to_string(),
                evidence: vec![crate::evolution::EvidenceRef {
                    source: crate::evolution::EvidenceSource::AutoMemory,
                    source_run_id: None,
                    source_role: Some("user".to_string()),
                    source_turn: Some(1),
                    source_memory_key: None,
                    quote: "A quote".to_string(),
                }],
                action: None,
                confidence: 0.9,
            })
            .map_err(|error| error.to_string())?;
        let evidence_projection_a = memory_a.settle_hot_memory_projection().await;
        if let Some(error) = evidence_projection_a.error {
            return Err(format!(
                "workspace A evidence projection did not settle: {error}"
            ));
        }
        evidence_b
            .upsert(crate::evolution::EvidenceCandidateDraft {
                kind: crate::evolution::EvidenceKind::ProjectFact,
                scope: None,
                content: "workspace B evidence".to_string(),
                evidence: vec![crate::evolution::EvidenceRef {
                    source: crate::evolution::EvidenceSource::AutoMemory,
                    source_run_id: None,
                    source_role: Some("user".to_string()),
                    source_turn: Some(1),
                    source_memory_key: None,
                    quote: "B quote".to_string(),
                }],
                action: None,
                confidence: 0.9,
            })
            .map_err(|error| error.to_string())?;
        let evidence_projection_b = memory_b.settle_hot_memory_projection().await;
        if let Some(error) = evidence_projection_b.error {
            return Err(format!(
                "workspace B evidence projection did not settle: {error}"
            ));
        }
        assert_eq!(
            task_store_a
                .get_run("shared-run")
                .map_err(|error| error.to_string())?
                .map(|run| run.goal),
            Some("workspace A goal".to_string())
        );
        assert_eq!(
            task_store_b
                .get_run("shared-run")
                .map_err(|error| error.to_string())?
                .map(|run| run.goal),
            Some("workspace B goal".to_string())
        );
        assert!(
            task_store_b
                .request_cancel("shared-run")
                .map_err(|error| error.to_string())?
        );
        assert_eq!(
            task_store_a
                .get_run("shared-run")
                .map_err(|error| error.to_string())?
                .map(|run| run.status),
            Some(crate::tasks::task_runtime::TaskRunStatus::Pending)
        );
        assert_eq!(
            task_store_b
                .get_run("shared-run")
                .map_err(|error| error.to_string())?
                .map(|run| run.status),
            Some(crate::tasks::task_runtime::TaskRunStatus::Cancelled)
        );
        let located_a = memory_manager_a
            .locate("shared-memory")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "workspace A memory missing".to_string())?;
        let located_b = memory_manager_b
            .locate("shared-memory")
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| "workspace B memory missing".to_string())?;
        assert_eq!(located_a.1.content, "workspace A memory");
        assert_eq!(located_b.1.content, "workspace B memory");
        assert_eq!(
            profile_store_a
                .load_user_profile()
                .await
                .map_err(|error| error.to_string())?
                .and_then(|profile| profile.preferences.get("scope").cloned()),
            Some("workspace A".to_string())
        );
        assert_eq!(
            profile_store_b
                .load_user_profile()
                .await
                .map_err(|error| error.to_string())?
                .and_then(|profile| profile.preferences.get("scope").cloned()),
            Some("workspace B".to_string())
        );
        assert!(
            evidence_a
                .review_items()
                .map_err(|error| error.to_string())?
                .iter()
                .all(|item| item.candidate.content.contains("workspace A"))
        );
        assert!(
            evidence_b
                .review_items()
                .map_err(|error| error.to_string())?
                .iter()
                .all(|item| item.candidate.content.contains("workspace B"))
        );
        let integration_a = runtime_a
            .review_integration()
            .ok_or_else(|| "workspace A review integration missing".to_string())?;
        let integration_b = runtime_b
            .review_integration()
            .ok_or_else(|| "workspace B review integration missing".to_string())?;
        assert_ne!(
            integration_a.echo_agent_dir(),
            integration_b.echo_agent_dir()
        );
        assert!(
            memory_manager_b
                .delete_memory("shared-memory")
                .await
                .map_err(|error| error.to_string())?
        );
        let projection_b = memory_b.settle_hot_memory_projection().await;
        if let Some(error) = projection_b.error {
            return Err(format!(
                "workspace B deletion projection did not settle: {error}"
            ));
        }
        assert!(
            memory_manager_b
                .locate("shared-memory")
                .await
                .map_err(|error| error.to_string())?
                .is_none()
        );
        assert!(
            memory_manager_a
                .locate("shared-memory")
                .await
                .map_err(|error| error.to_string())?
                .is_some()
        );
        let pool_a = runtime_a
            .pool()
            .ok_or_else(|| "workspace A pool missing".to_string())?;
        let pool_b = runtime_b
            .pool()
            .ok_or_else(|| "workspace B pool missing".to_string())?;
        assert!(!Arc::ptr_eq(&pool_a, &pool_b));
        assert_eq!(
            runtime_a
                .task_runtime()
                .ok_or_else(|| "workspace A TaskRuntime missing".to_string())?
                .active_workspace_id(),
            "workspace-a"
        );
        assert_eq!(
            runtime_b
                .task_runtime()
                .ok_or_else(|| "workspace B TaskRuntime missing".to_string())?
                .active_workspace_id(),
            "workspace-b"
        );
        assert!(
            state
                .session
                .foreground_turns
                .snapshot_scoped(
                    "workspace-a",
                    crate::foreground_turn::ForegroundTurnSurface::Gui,
                    "same-conversation"
                )
                .is_some()
        );

        foreground_a.settle(crate::chat_driver::TurnOutcome::Completed);
        drop(execution_a);
        drop(execution_b);
        let product_control_b = state
            .current_product_data()
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(product_control_b.data_root(), canonical_b.as_path());
        assert_eq!(product_control_b.project_root(), canonical_linked_project);
        let stale_b_generation = product_control_b.generation();
        let auto_ingest_identity = product_control_b.runtime().workspace_io_identity.clone();
        let auto_ingest_scope = product_control_b.runtime().workspace_io_invocation();
        let auto_ingest_context = echo_agent::tools::ToolContext {
            working_dir: Some(auto_ingest_scope.data_root().to_path_buf()),
            resource_guards: auto_ingest_scope.resource_guards(),
            ..echo_agent::tools::ToolContext::default()
        };
        drop(auto_ingest_scope);
        drop(product_control_b);
        drop(runtime_b);
        let (io_entered_tx, io_entered_rx) = tokio::sync::oneshot::channel();
        let (io_release_tx, io_release_rx) = tokio::sync::oneshot::channel();
        let product_io = tokio::spawn(crate::research_connectors::run_auto_ingest_barrier_fixture(
            auto_ingest_context,
            auto_ingest_identity,
            io_entered_tx,
            io_release_rx,
        ));
        io_entered_rx
            .await
            .map_err(|_| "AutoIngest blocking closure did not park".to_string())?;
        product_io.abort();
        let _ = product_io.await;
        state
            .switch_workspace(workspace("workspace-a", canonical_a.clone()))
            .await
            .map_err(|error| error.to_string())?;
        assert!(
            state
                .delete_workspace_owned(&crate::workspace::WorkspaceId::from_name("workspace-b"))
                .await
                .is_err_and(|error| error.to_string().contains("controls:"))
        );
        let workspace_b_id = crate::workspace::WorkspaceId::from_name("workspace-b");
        let before_failed_auto_ingest_relink = state
            .workspace
            .registry
            .open(&workspace_b_id)
            .map_err(|error| error.to_string())?;
        let auto_ingest_relink = temp.path().join("workspace-b-auto-ingest-relink");
        std::fs::create_dir_all(&auto_ingest_relink).map_err(|error| error.to_string())?;
        assert!(
            state
                .link_workspace_project_owned(&workspace_b_id, auto_ingest_relink)
                .await
                .is_err_and(|error| error.to_string().contains("controls:"))
        );
        let after_failed_auto_ingest_relink = state
            .workspace
            .registry
            .open(&workspace_b_id)
            .map_err(|error| error.to_string())?;
        assert_eq!(
            after_failed_auto_ingest_relink.project_root,
            before_failed_auto_ingest_relink.project_root
        );
        assert_eq!(
            after_failed_auto_ingest_relink
                .metadata
                .project_root_revision,
            before_failed_auto_ingest_relink
                .metadata
                .project_root_revision
        );
        io_release_tx
            .send(())
            .map_err(|_| "AutoIngest blocking barrier receiver was dropped".to_string())?;
        for _ in 0..100 {
            if crate::research::list_sources(&canonical_b, None, None)
                .is_ok_and(|sources| !sources.is_empty())
            {
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(5)).await;
        }
        assert_eq!(
            crate::research::list_sources(&canonical_b, None, None)
                .map_err(|error| error.to_string())?
                .first()
                .map(|source| source.title.as_str()),
            Some("Auto-ingest lifetime barrier")
        );
        for _ in 0..100 {
            if state
                .ensure_workspace_idle_for_delete(&workspace_b_id)
                .await
                .is_ok()
            {
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(5)).await;
        }
        state
            .ensure_workspace_idle_for_delete(&workspace_b_id)
            .await
            .map_err(|error| format!("AutoIngest retained workspace after settlement: {error}"))?;
        let analysis_product_b = state
            .product_data_for_scope("workspace-b", &stale_b_generation)
            .await
            .map_err(|error| error.to_string())?;
        let (analysis_entered_tx, analysis_entered_rx) = tokio::sync::oneshot::channel();
        let (analysis_release_tx, analysis_release_rx) = tokio::sync::oneshot::channel();
        let analysis_receipt = analysis_product_b
            .start_analysis_fixture("owned-fixture", analysis_entered_tx, analysis_release_rx)
            .map_err(|error| error.to_string())?;
        analysis_entered_rx
            .await
            .map_err(|_| "owned analysis fixture did not start".to_string())?;
        drop(analysis_product_b);
        let relinked_project = temp.path().join("workspace-b-relinked-project");
        std::fs::create_dir_all(&relinked_project).map_err(|error| error.to_string())?;
        let before_failed_relink = state
            .workspace
            .registry
            .open(&workspace_b_id)
            .map_err(|error| error.to_string())?;
        assert!(
            state
                .link_workspace_project_owned(&workspace_b_id, relinked_project.clone())
                .await
                .is_err_and(|error| error.to_string().contains("controls:"))
        );
        let after_failed_relink = state
            .workspace
            .registry
            .open(&workspace_b_id)
            .map_err(|error| error.to_string())?;
        assert_eq!(
            after_failed_relink.project_root,
            before_failed_relink.project_root
        );
        assert_eq!(
            after_failed_relink.metadata.project_root_revision,
            before_failed_relink.metadata.project_root_revision
        );
        assert!(
            state
                .delete_workspace_owned(&workspace_b_id)
                .await
                .is_err_and(|error| error.to_string().contains("controls:"))
        );
        analysis_release_tx
            .send(())
            .map_err(|_| "owned analysis fixture release was dropped".to_string())?;
        for _ in 0..100 {
            if state
                .ensure_workspace_idle_for_delete(&workspace_b_id)
                .await
                .is_ok()
            {
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(5)).await;
        }
        state
            .ensure_workspace_idle_for_delete(&workspace_b_id)
            .await
            .map_err(|error| format!("joined analysis retained active owner: {error}"))?;
        let analysis_product_b = state
            .product_data_for_scope("workspace-b", &stale_b_generation)
            .await
            .map_err(|error| error.to_string())?;
        for _ in 0..100 {
            match analysis_product_b.poll_analysis(&analysis_receipt) {
                Ok(crate::product_data_io::AnalysisWaitReceipt::Started { .. }) => {
                    tokio::time::sleep(std::time::Duration::from_millis(5)).await;
                }
                Ok(crate::product_data_io::AnalysisWaitReceipt::Joined {
                    execution_error: Some(_),
                    ..
                }) => break,
                Ok(other) => {
                    return Err(format!(
                        "owned analysis fixture returned unexpected status: {other:?}"
                    ));
                }
                Err(error) => return Err(error.to_string()),
            }
        }
        drop(analysis_product_b);
        let relinked = state
            .link_workspace_project_owned(&workspace_b_id, relinked_project)
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(
            relinked.metadata.project_root_revision,
            before_failed_relink
                .metadata
                .project_root_revision
                .checked_add(1)
                .ok_or_else(|| "project-root revision overflow in test".to_string())?
        );
        assert!(
            state
                .product_data_for_scope("workspace-b", &stale_b_generation)
                .await
                .is_err()
        );
        for _ in 0..100 {
            if state
                .ensure_workspace_idle_for_delete(&workspace_b_id)
                .await
                .is_ok()
            {
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(5)).await;
        }
        state
            .delete_workspace_owned(&workspace_b_id)
            .await
            .map_err(|error| error.to_string())?;
        let recreated_b_root = temp.path().join("workspace-b-recreated");
        let (recreated_b, created) = state
            .create_workspace_owned(
                "workspace-b",
                crate::workspace::WorkspaceKind::General,
                Some(recreated_b_root),
            )
            .await
            .map_err(|error| error.to_string())?;
        assert!(created);
        assert!(
            state
                .product_data_for_scope(recreated_b.id.as_str(), &stale_b_generation)
                .await
                .is_err()
        );
        let reopened_a = state
            .current_control_runtime()
            .await
            .map_err(|error| error.to_string())?;
        assert!(Arc::ptr_eq(
            &pool_a,
            &reopened_a
                .pool()
                .ok_or_else(|| "reopened workspace A pool missing".to_string())?
        ));

        let exited = state
            .exit_workspace()
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(exited.status, WorkspaceTransitionStatus::Committed);
        assert!(state.current_workspace().await.is_none());
        let restored = state
            .conversation_store()
            .await
            .ok_or_else(|| "global conversation store missing".to_string())?;
        assert!(Arc::ptr_eq(&restored, &global_store));
        assert_eq!(agent.read(|agent| agent.working_dir()).await, None);
        assert_eq!(
            std::env::current_dir().map_err(|error| error.to_string())?,
            process_cwd
        );
        drop(reopened_a);
        drop(runtime_a);
        state
            .delete_workspace_owned(&crate::workspace::WorkspaceId::from_name("workspace-a"))
            .await
            .map_err(|error| error.to_string())?;
        assert!(state.chat_runtime_for_scope("workspace-a").await.is_err());
        Ok(())
    }
}

#[cfg(test)]
mod service_bootstrap_tests {
    use super::*;
    use echo_agent::agent::ReactAgentBuilder;
    use echo_agent::memory::{Store, StoreItem};
    use echo_agent::testing::MockLlmClient;
    use futures::future::BoxFuture;

    fn seed_recoverable_attended_run(
        store: &crate::tasks::task_runtime::TaskRuntimeStore,
    ) -> Result<(), String> {
        use crate::tasks::task_runtime::{
            AttendedMode, DomainProfile, ExecutionMode, PlanTask, TaskPlan, TaskRunStatus,
        };
        let workspace_id = store.active_workspace_id();
        store
            .create_run(
                "healthy-global-run",
                &workspace_id,
                "ordinary-conversation",
                "root-message",
                DomainProfile::General,
                "healthy global goal",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,
                plan_id: "healthy-plan".to_string(),
                run_id: "healthy-global-run".to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: crate::tasks::task_runtime::task_goal_sha256("healthy global goal"),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: "healthy-task".to_string(),
                    title: "Wait for owner".to_string(),
                    ..Default::default()
                }],
            })
            .map_err(|error| error.to_string())?;
        store
            .transition_run("healthy-global-run", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .configure_run_continuation("healthy-global-run", true, true, None, None)
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    struct SchedulerInitFailureStore;

    fn scheduler_store_failure<T>() -> echo_agent::error::Result<T> {
        Err(echo_agent::error::ReactError::Other(
            "injected scheduler store failure".to_string(),
        ))
    }

    impl Store for SchedulerInitFailureStore {
        fn put<'a>(
            &'a self,
            _namespace: &'a [&'a str],
            _key: &'a str,
            _value: serde_json::Value,
        ) -> BoxFuture<'a, echo_agent::error::Result<()>> {
            Box::pin(async { scheduler_store_failure() })
        }

        fn get<'a>(
            &'a self,
            _namespace: &'a [&'a str],
            _key: &'a str,
        ) -> BoxFuture<'a, echo_agent::error::Result<Option<StoreItem>>> {
            Box::pin(async { scheduler_store_failure() })
        }

        fn search<'a>(
            &'a self,
            _namespace: &'a [&'a str],
            _query: &'a str,
            _limit: usize,
        ) -> BoxFuture<'a, echo_agent::error::Result<Vec<StoreItem>>> {
            Box::pin(async { scheduler_store_failure() })
        }

        fn delete<'a>(
            &'a self,
            _namespace: &'a [&'a str],
            _key: &'a str,
        ) -> BoxFuture<'a, echo_agent::error::Result<bool>> {
            Box::pin(async { scheduler_store_failure() })
        }

        fn list_namespaces<'a>(
            &'a self,
            _prefix: Option<&'a [&'a str]>,
        ) -> BoxFuture<'a, echo_agent::error::Result<Vec<Vec<String>>>> {
            Box::pin(async { scheduler_store_failure() })
        }

        fn list<'a>(
            &'a self,
            _namespace: &'a [&'a str],
        ) -> BoxFuture<'a, echo_agent::error::Result<Vec<StoreItem>>> {
            Box::pin(async { scheduler_store_failure() })
        }
    }

    #[tokio::test]
    async fn scheduler_init_failure_does_not_start_task_service_or_run_driver()
    -> std::result::Result<(), String> {
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("service bootstrap test")
            .build()
            .map_err(|error| error.to_string())?;
        let mcp_runtime = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            std::env::temp_dir().join(format!("eko-mcp-{}.json", uuid::Uuid::new_v4())),
            Default::default(),
        ));
        let mut state = AppState::from_shared(
            AgentHandle::new(agent),
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            mcp_runtime,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?;
        let runtime_store = Arc::new(
            crate::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                .map_err(|error| error.to_string())?,
        );
        state.tasks.runtime = Some(runtime_store.clone());

        let result = state
            .start_scheduler_and_task_service(Some(Arc::new(SchedulerInitFailureStore)))
            .await;

        assert!(result.is_err());
        assert!(state.scheduler.runner.is_none());
        assert!(state.tasks.service.is_none());
        assert_eq!(runtime_store.active_run_driver_count()?, 0);
        Ok(())
    }

    #[tokio::test]
    async fn corrupt_workspace_does_not_block_healthy_global_boot_recovery()
    -> std::result::Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("boot isolation test")
            .build()
            .map_err(|error| error.to_string())?;
        let mcp_runtime = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            temp.path().join("mcp.json"),
            Default::default(),
        ));
        let mut state = AppState::from_shared(
            AgentHandle::new(agent),
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            mcp_runtime,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?;
        let global = Arc::new(
            crate::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                .map_err(|error| error.to_string())?,
        );
        seed_recoverable_attended_run(&global)?;
        state.tasks.runtime = Some(global.clone());
        let registry_root = temp.path().join("registry");
        let registry = Arc::new(
            crate::workspace::registry::WorkspaceRegistry::with_base_dir(registry_root)
                .map_err(|error| error.to_string())?,
        );
        let corrupt_root = temp.path().join("corrupt-workspace");
        registry
            .create_at(
                "corrupt",
                crate::workspace::WorkspaceKind::General,
                corrupt_root.clone(),
            )
            .map_err(|error| error.to_string())?;
        let tasks_root = crate::workspace::layout::WorkspaceLayout::tasks(&corrupt_root);
        std::fs::remove_dir_all(&tasks_root).map_err(|error| error.to_string())?;
        std::fs::write(&tasks_root, "not a directory").map_err(|error| error.to_string())?;
        state.workspace.registry = registry;

        let report = state.reconcile_task_runs_at_boot().await;
        assert_eq!(report.recovered, 1);
        assert_eq!(report.blocked, 1);
        assert_eq!(report.resumed, 0);
        assert!(
            report
                .failed_scopes
                .iter()
                .any(|failure| failure.contains("corrupt"))
        );
        assert_eq!(
            global
                .get_run("healthy-global-run")
                .map_err(|error| error.to_string())?
                .map(|run| run.status),
            Some(crate::tasks::task_runtime::TaskRunStatus::Paused)
        );
        Ok(())
    }

    /// Boot-recovery AppState with an isolated workspace registry so the scan
    /// never touches the developer's real workspaces.
    fn boot_recovery_state(registry_root: &std::path::Path) -> Result<AppState, String> {
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("task run boot recovery test")
            .build()
            .map_err(|error| error.to_string())?;
        let mcp_runtime = Arc::new(crate::mcp_config_runtime::McpConfigRuntime::new(
            std::env::temp_dir().join(format!("eko-mcp-boot-{}.json", uuid::Uuid::new_v4())),
            Default::default(),
        ));
        let mut state = AppState::from_shared(
            AgentHandle::new(agent),
            None,
            Arc::new(crate::hitl::HitlDispatcher::new()),
            None,
            None,
            Default::default(),
            mcp_runtime,
            crate::product_data_io::ProductDataIoService::new(),
        )
        .map_err(|error| error.to_string())?;
        state.workspace.registry = Arc::new(
            crate::workspace::registry::WorkspaceRegistry::with_base_dir(
                registry_root.to_path_buf(),
            )
            .map_err(|error| error.to_string())?,
        );
        Ok(state)
    }

    /// Seed one `Running` run with a resumable continuation.
    fn seed_running_run(
        store: &crate::tasks::task_runtime::TaskRuntimeStore,
        run_id: &str,
        conversation_id: &str,
        attended_mode: crate::tasks::task_runtime::AttendedMode,
    ) -> Result<(), String> {
        use crate::tasks::task_runtime::{
            DomainProfile, ExecutionMode, PlanTask, TaskPlan, TaskRunStatus,
        };
        let workspace_id = store.active_workspace_id();
        let goal = "seeded boot recovery goal";
        store
            .create_run(
                run_id,
                &workspace_id,
                conversation_id,
                "",
                DomainProfile::General,
                goal,
                "task",
                attended_mode,
            )
            .map_err(|error| error.to_string())?;
        store
            .attach_plan_for_test(&TaskPlan {
                domain_binding: None,
                plan_id: format!("{run_id}-plan"),
                run_id: run_id.to_string(),
                revision: 1,
                domain_profile: DomainProfile::General,
                goal_revision: 1,
                goal_sha256: crate::tasks::task_runtime::task_goal_sha256(goal),
                assumptions: Vec::new(),
                risks: Vec::new(),
                execution_mode: ExecutionMode::Sequential,
                tasks: vec![PlanTask {
                    id: format!("{run_id}-task"),
                    title: "Seeded work".to_string(),
                    ..Default::default()
                }],
            })
            .map_err(|error| error.to_string())?;
        store
            .transition_run(run_id, TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        store
            .configure_run_continuation(run_id, true, true, None, None)
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    /// 普通启动恢复不得接管 cron 拥有的 run：scheduler 先于恢复启动，cron
    /// slot 的归属权在 occurrence 投递侧；普通恢复只能把它计入 blocked。
    #[tokio::test]
    async fn ordinary_boot_recovery_does_not_take_over_cron_owned_run() -> Result<(), String> {
        use crate::tasks::task_runtime::{AttendedMode, TaskRunStatus};

        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let mut state = boot_recovery_state(&temp.path().join("registry"))?;
        let store = Arc::new(
            crate::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                .map_err(|error| error.to_string())?,
        );
        seed_running_run(
            &store,
            "cron-owned-run",
            "cron:daily-summary:cron-scheduled:seed",
            AttendedMode::Unattended,
        )?;
        state.tasks.runtime = Some(store.clone());

        let report = state.reconcile_task_runs_at_boot().await;

        assert_eq!(
            report.recovered, 1,
            "the recovery scan still settles the run into its boot disposition"
        );
        assert_eq!(
            report.resumed, 0,
            "ordinary recovery must never resume a cron-owned run"
        );
        assert!(
            report.blocked >= 1,
            "the skipped cron run must be observable as blocked"
        );
        assert!(
            !report.is_settled(),
            "a boot that left a cron run for its owner is not settled"
        );
        assert_eq!(
            store
                .get_run("cron-owned-run")
                .map_err(|error| error.to_string())?
                .map(|run| run.status),
            Some(TaskRunStatus::Paused),
            "the cron-owned run must stay Paused until its cron delivery owns it"
        );
        Ok(())
    }

    /// 物理 owner fence 拒绝恢复的 run 必须计入 blocked / failed_scopes，
    /// 不能因为 `recover_incomplete() == Ok(0)` 就谎报启动已结算。
    #[tokio::test]
    async fn owner_fence_rejection_is_reported_as_blocked_not_settled() -> Result<(), String> {
        use crate::tasks::task_runtime::TaskRunStatus;
        use crate::tasks::task_runtime::store::RunDriverFailure;

        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let mut state = boot_recovery_state(&temp.path().join("registry"))?;
        let store = Arc::new(
            crate::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
                .map_err(|error| error.to_string())?,
        );
        // The driver admission below requires the store's lifecycle owner.
        let _resource_scope = store.test_resource_scope();
        seed_running_run(
            &store,
            "fenced-run",
            "ordinary-conversation",
            crate::tasks::task_runtime::AttendedMode::Unattended,
        )?;
        // Leave the exact R1 state through the canonical driver path: the
        // driver reports an unknown physical settlement, so the supervisor
        // retains the owner intent with observed=false.
        let cancel = CancellationToken::new();
        let admission = store
            .reserve_run_driver_admission("fenced-run".to_string(), cancel)
            .map_err(|error| error.to_string())?;
        let registration = store
            .register_observed_run_driver::<()>(
                admission,
                store
                    .lease_active_workspace_generation()
                    .map_err(|error| error.to_string())?,
            )
            .map_err(|error| error.to_string())?;
        let waiter = registration.start(|_resources| async move {
            Err::<(), RunDriverFailure>(RunDriverFailure::Observation {
                run_id: "fenced-run".to_string(),
                execution_id: None,
            })
        });
        let observed = waiter
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string());
        assert!(
            observed.is_err(),
            "the driver must report the unsettled owner"
        );
        assert!(store.has_unsettled_driver_resources());
        // R1: the fence leaves the run Running and recovery settles nothing.
        assert_eq!(
            store
                .recover_incomplete()
                .map_err(|error| error.to_string())?,
            0
        );
        assert_eq!(
            store
                .get_run("fenced-run")
                .map_err(|error| error.to_string())?
                .map(|run| run.status),
            Some(TaskRunStatus::Running)
        );
        state.tasks.runtime = Some(store.clone());

        let report = state.reconcile_task_runs_at_boot().await;

        assert_eq!(report.recovered, 0, "the fence settles nothing");
        assert_eq!(report.resumed, 0);
        assert!(
            report.blocked >= 1,
            "the fenced run must be counted as blocked, not silently settled"
        );
        assert!(
            !report.is_settled(),
            "Ok(0) from recover_incomplete must not be treated as a settled boot"
        );
        assert!(
            report
                .failed_scopes
                .iter()
                .any(|scope| scope.contains("remain unsettled")),
            "the unsettled scope must be observable in the boot report: {:?}",
            report.failed_scopes
        );
        // Fence semantics are preserved: T3 never rewrites the run.
        assert_eq!(
            store
                .get_run("fenced-run")
                .map_err(|error| error.to_string())?
                .map(|run| run.status),
            Some(TaskRunStatus::Running)
        );
        Ok(())
    }
}

async fn await_workspace_settlement(
    handle: &mut WorkspaceSettlementHandle,
) -> anyhow::Result<WorkspaceSettlementOutcome> {
    handle
        .await
        .map_err(|error| anyhow::anyhow!("workspace settlement task failed: {error}"))?
}

#[cfg(test)]
fn ensure_no_running_task_runs(
    transition: Option<&crate::tasks::task_runtime::store::TaskRuntimeWorkspaceTransition<'_>>,
) -> anyhow::Result<()> {
    let Some(transition) = transition else {
        return Ok(());
    };
    let running = transition
        .list_runs_in(&[crate::tasks::task_runtime::TaskRunStatus::Running])
        .map_err(|error| anyhow::anyhow!("Failed to inspect active task runs: {error}"))?;
    if running.is_empty() {
        return Ok(());
    }
    let run_ids = running
        .iter()
        .take(5)
        .map(|run| run.run_id.as_str())
        .collect::<Vec<_>>()
        .join(", ");
    anyhow::bail!("Cannot change workspace while TaskRun is running: {run_ids}")
}

#[cfg(test)]
mod permission_rule_tests {
    use super::*;
    use echo_agent::tools::permission::{RuleBehavior, RuleMatcher, RuleSource, ToolPermission};

    #[tokio::test]
    async fn scheduler_shutdown_joins_owned_handle_and_is_idempotent()
    -> std::result::Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let store = crate::scheduler::CronTaskStore::new()
            .with_path(temp.path().join("scheduler-tasks.json"));
        let cancel_token = echo_agent::agent::CancellationToken::new();
        let fire_fn: echo_agent::scheduler::FireFn =
            Arc::new(|_task| Box::pin(async { Ok("done".to_string()) }));
        let runner = Arc::new(
            crate::scheduler::SchedulerRunner::new(store, cancel_token.clone(), fire_fn)
                .await
                .map_err(|error| error.to_string())?,
        );
        let handle = runner.clone().spawn();
        let scheduler = SchedulerState {
            #[cfg(feature = "channels")]
            weixin_notifications: Arc::new(crate::weixin_cron::WeixinCronBinding::default()),
            runner: Some(runner),
            cancel_token,
            handle: Mutex::new(Some(handle)),
        };

        scheduler
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        scheduler
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;

        assert!(scheduler.handle.lock().await.is_none());
        Ok(())
    }

    #[test]
    fn framework_permission_rule_parsing_preserves_semantics() -> std::result::Result<(), String> {
        let rule = echo_agent::tools::permission::PermissionRule {
            matcher: "permission:write".parse().map_err(|error: String| error)?,
            behavior: "deny".parse().map_err(|error: String| error)?,
            source: "projectSettings".parse().map_err(|error: String| error)?,
            description: Some("EKO application permission rule".to_string()),
        };
        assert!(matches!(
            rule.matcher,
            RuleMatcher::Permission {
                permission: ToolPermission::Write
            }
        ));
        assert!(matches!(rule.behavior, RuleBehavior::Deny { .. }));
        assert_eq!(rule.source, RuleSource::ProjectSettings);
        Ok(())
    }

    #[tokio::test]
    async fn workspace_preflight_rejects_running_task_runs() -> std::result::Result<(), String> {
        use crate::tasks::task_runtime::{AttendedMode, DomainProfile, TaskRunStatus};

        let runtime = crate::tasks::task_runtime::TaskRuntimeStore::new_in_memory()
            .map_err(|error| error.to_string())?;
        runtime
            .create_run(
                "workspace-transition-run",
                "workspace-a",
                "conversation-a",
                "message-a",
                DomainProfile::General,
                "verify workspace transition",
                "task",
                AttendedMode::Attended,
            )
            .map_err(|error| error.to_string())?;
        {
            let transition = runtime
                .begin_workspace_transition()
                .await
                .map_err(|error| error.to_string())?;
            assert!(ensure_no_running_task_runs(Some(&transition)).is_ok());
        }

        runtime
            .transition_run("workspace-transition-run", TaskRunStatus::Running)
            .map_err(|error| error.to_string())?;
        let transition = runtime
            .begin_workspace_transition()
            .await
            .map_err(|error| error.to_string())?;
        let error = match ensure_no_running_task_runs(Some(&transition)) {
            Ok(()) => return Err("a running TaskRun did not block workspace change".to_string()),
            Err(error) => error,
        };
        assert!(error.to_string().contains("workspace-transition-run"));
        Ok(())
    }
}
