//! 唯一的 hook 配置加载器 (audit P0-1)。
//!
//! ## 背景
//!
//! 用户 hook 配置有三个来源,历史上加载逻辑分散在多处,且每个来源都
//! 调用 `HookRegistry::clear_user_hooks()` + `register_user_hooks()`,
//! 而框架的 `HookSource::UserConfig` 只有一个槽位 —— 后装的 clear 会
//! 把先装的清掉,导致:
//! 1. `eko.yaml` 内嵌 hooks 在 bootstrap 第 6 步被 hooks.yaml
//!    文件加载覆盖丢失;
//! 2. `/hooks reload` 只重读文件 hooks、不重读 eko.yaml,reload
//!    后内嵌 hooks 永久丢失。
//!
//! ## 修复
//!
//! 本 loader 把三个来源按固定顺序合并成**单个** `HooksDefinition`,
//! 然后**一次性** `clear_user_hooks()` + `register_user_hooks(merged)`。
//! 无论哪个来源变,都重建完整的 user hook 集,不再互相清空。
//!
//! 三个来源在框架语义里都属于"用户配置"(`HookSource::UserConfig`),
//! 所以共用 UserConfig 槽位是正确的 —— 关键是合并后再 register,而不是
//! 各自 register。
//!
//! ## 合并顺序(后者覆盖前者同名 event 的 rules,additive merge)
//!
//! 1. `eko.yaml` 内嵌 `hooks:` 字段(最低优先级)
//! 2. `~/.eko/hooks.yaml`(全局用户 hooks)
//! 3. `.eko/hooks.yaml`(项目级 hooks,最高优先级)

use crate::config::EkoConfig;
use echo_agent::skills::hooks::HooksDefinition;
use std::path::{Path, PathBuf};

/// hook 配置加载结果。
///
/// `definition` 是按固定顺序合并后的单一 user hook 集合;
/// `loaded_from` 记录实际成功加载的文件路径(用于 `/hooks` 命令展示)。
#[derive(Debug, Clone, Default)]
pub struct HooksLoadResult {
    /// 合并后的 hooks 定义(空表示无任何 user hook)。
    pub definition: HooksDefinition,
    /// Ordered inputs to that same merged definition. Origins are transient
    /// registration facts, not independent hook stores or configuration.
    pub(crate) origins: Vec<HookConfigOrigin>,
    /// 实际加载成功的文件路径列表(内嵌 eko.yaml 不算文件,
    /// 不进入此列表;只含 `~/.eko/hooks.yaml` 与 `.eko/hooks.yaml`)。
    pub loaded_from: Vec<PathBuf>,
    /// Read/parse errors. Reload callers must keep the existing live hook set
    /// when this is non-empty rather than replacing it with partial data.
    pub errors: Vec<String>,
}

#[derive(Debug, Clone)]
pub(crate) struct HookConfigOrigin {
    pub definition: HooksDefinition,
    pub directory: PathBuf,
    pub project: bool,
}

/// hook 配置来源标识(仅用于日志/审计,不影响框架 `HookSource`)。
///
/// 注意:这三个来源最终都 register 进框架的 `HookSource::UserConfig`
/// 单一槽位 —— 本 enum 只在 loader 内部用于追踪合并顺序和日志。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HookConfigSource {
    /// `eko.yaml` 内嵌 `hooks:` 字段(最低优先级)。
    InlineConfig,
    /// `~/.eko/hooks.yaml`(全局)。
    GlobalFile,
    /// `.eko/hooks.yaml`(项目级,最高优先级)。
    ProjectFile,
}

impl HookConfigSource {
    /// 可读名称(日志用)。
    fn label(self) -> &'static str {
        match self {
            HookConfigSource::InlineConfig => "eko.yaml (inline)",
            HookConfigSource::GlobalFile => "~/.eko/hooks.yaml (global)",
            HookConfigSource::ProjectFile => ".eko/hooks.yaml (project)",
        }
    }
}

/// 唯一的 hook 配置加载器。
///
/// 无状态:所有方法都是关联函数,直接从磁盘/`EkoConfig` 读取并合并。
/// 提供 `load_merged`(已知 `EkoConfig`)与 `load_merged_from_disk`
/// (`/hooks reload` 无法访问 `EkoConfig` 时从磁盘重读)两个统一入口。
/// 默认入口只加载 inline/global 来源；项目级来源必须通过显式 workspace
/// 入口提供 root，不能从进程 cwd 推断。
pub struct HookConfigLoader;

impl HookConfigLoader {
    /// 加载并合并非 workspace user hook 来源(内嵌 + 全局文件)。
    ///
    /// 这是 bootstrap 路径应使用的入口:它接收已加载的 `EkoConfig`,
    /// 取其 `hooks` 字段,再叠加全局 hooks.yaml,合并返回单个
    /// `HooksDefinition`。调用方拿到结果后应**一次性**
    /// `clear_user_hooks()` + `register_user_hooks(merged)`,不要
    /// 再单独 register 内嵌或文件 hooks(那是旧 bug 的根源)。
    pub fn load_merged(app_config: &EkoConfig) -> HooksLoadResult {
        Self::load_merged_for_workspace(app_config, None)
    }

    /// Load all user hook sources for an explicit workspace generation.
    ///
    /// Passing the workspace root explicitly avoids consulting process cwd
    /// while a workspace switch is in flight.
    pub fn load_merged_for_workspace(
        app_config: &EkoConfig,
        project_root: Option<&Path>,
    ) -> HooksLoadResult {
        Self::load_merged_with_file_system(
            app_config,
            project_root,
            &echo_agent::tools::files::LocalFileSystem,
        )
    }

    /// Preserve the original merge order while reading only the project
    /// source through its admitted provider. Application/global config stays
    /// on the machine that owns the GUI and configuration.
    pub(crate) fn load_merged_with_file_system(
        app_config: &EkoConfig,
        project_root: Option<&Path>,
        files: &dyn echo_agent::tools::filesystem::FileSystem,
    ) -> HooksLoadResult {
        let mut definition = HooksDefinition::default();
        let mut origins = Vec::new();
        let mut loaded_from = Vec::new();
        let mut errors = Vec::new();

        // 1. eko.yaml 内嵌(最低优先级)
        let inline = app_config.hooks.clone();
        let inline_rule_count: usize = inline.rules.values().map(Vec::len).sum();
        if inline_rule_count > 0 {
            origins.push(HookConfigOrigin {
                definition: inline.clone(),
                directory: std::env::current_dir()
                    .unwrap_or_else(|_| crate::data_root::user_data_dir()),
                project: false,
            });
            definition.merge(inline);
            tracing::info!(
                source = HookConfigSource::InlineConfig.label(),
                count = inline_rule_count,
                "Loaded inline user hooks from eko.yaml"
            );
        }

        // 2 & 3. 两个 hooks.yaml 文件(全局 + 项目级)
        Self::merge_file_sources(
            &mut definition,
            &mut origins,
            &mut loaded_from,
            &mut errors,
            project_root,
            files,
        );

        HooksLoadResult {
            definition,
            origins,
            loaded_from,
            errors,
        }
    }

    /// 从磁盘重新加载并合并所有 user hook 来源。
    ///
    /// 用于 `/hooks reload`:无法访问 `EkoConfig` 时,用框架的
    /// `load_config(None)` 重新从标准路径读取 `eko.yaml`,
    /// 再叠加全局 hooks.yaml。语义与 `load_merged` 完全一致,
    /// 只是内嵌来源从磁盘重读而非从内存取。
    pub fn load_merged_from_disk() -> HooksLoadResult {
        Self::load_merged_from_disk_at(None)
    }

    /// Reload from an explicitly selected app config plus the global hooks file.
    pub fn load_merged_from_disk_at(config_path: Option<&Path>) -> HooksLoadResult {
        Self::load_merged_from_disk_for_workspace(config_path, None)
    }

    /// Reload from disk for an explicit workspace generation.
    pub fn load_merged_from_disk_for_workspace(
        config_path: Option<&Path>,
        project_root: Option<&Path>,
    ) -> HooksLoadResult {
        Self::load_merged_from_disk_with_file_system(
            config_path,
            project_root,
            &echo_agent::tools::files::LocalFileSystem,
        )
    }

    pub(crate) fn load_merged_from_disk_with_file_system(
        config_path: Option<&Path>,
        project_root: Option<&Path>,
        files: &dyn echo_agent::tools::filesystem::FileSystem,
    ) -> HooksLoadResult {
        let mut config_errors = Vec::new();
        let mut app_config = EkoConfig::default();
        let mut loaded_config_directory = None;
        let search_paths = config_path
            .map(|path| vec![path.to_path_buf()])
            .unwrap_or_else(crate::config::config_search_paths);
        for path in search_paths {
            if !path.exists() {
                continue;
            }
            match crate::config::load_config_file(&path) {
                Ok(config) => {
                    app_config = config;
                    let absolute = if path.is_absolute() {
                        path.clone()
                    } else {
                        std::env::current_dir()
                            .map(|directory| directory.join(&path))
                            .unwrap_or_else(|_| crate::data_root::user_data_dir().join(&path))
                    };
                    loaded_config_directory = absolute.parent().map(Path::to_path_buf);
                    break;
                }
                Err(error) => config_errors.push(format!(
                    "Failed to load app config {}: {error}",
                    path.display()
                )),
            }
        }

        let mut result = Self::load_merged_with_file_system(&app_config, project_root, files);
        if let Some(directory) = loaded_config_directory
            && !app_config.hooks.is_empty()
            && let Some(inline) = result.origins.first_mut()
        {
            inline.directory = directory;
        }
        result.errors.splice(0..0, config_errors);
        result
    }

    // ── 内部 helpers ──────────────────────────────────────────────

    /// 把全局 hooks.yaml + 项目级 hooks.yaml 合并进 `definition`,
    /// 并把成功加载的路径加入 `loaded_from`。
    ///
    /// 文件来源合并的唯一实现。
    fn merge_file_sources(
        definition: &mut HooksDefinition,
        origins: &mut Vec<HookConfigOrigin>,
        loaded_from: &mut Vec<PathBuf>,
        errors: &mut Vec<String>,
        project_root: Option<&Path>,
        files: &dyn echo_agent::tools::filesystem::FileSystem,
    ) {
        // 2. 全局 hooks: ~/.eko/hooks.yaml
        let global_path = crate::data_root::user_data_path("hooks.yaml");
        match try_load_yaml(&global_path) {
            Ok(Some(def)) => {
                let count: usize = def.rules.values().map(Vec::len).sum();
                origins.push(HookConfigOrigin {
                    definition: def.clone(),
                    directory: global_path
                        .parent()
                        .map(Path::to_path_buf)
                        .unwrap_or_else(crate::data_root::user_data_dir),
                    project: false,
                });
                definition.merge(def);
                loaded_from.push(global_path);
                tracing::info!(
                    source = HookConfigSource::GlobalFile.label(),
                    count,
                    "Loaded user hooks from global file"
                );
            }
            Ok(None) => {}
            Err(error) => errors.push(error),
        }

        // 3. 项目级 hooks: <workspace>/.eko/hooks.yaml
        if let Some(project_root) = project_root {
            let project_path = project_root.join(".eko").join("hooks.yaml");
            match try_load_yaml_with_file_system(&project_path, files) {
                Ok(Some(def)) => {
                    let count: usize = def.rules.values().map(Vec::len).sum();
                    origins.push(HookConfigOrigin {
                        definition: def.clone(),
                        directory: project_root.to_path_buf(),
                        project: true,
                    });
                    definition.merge(def);
                    loaded_from.push(project_path);
                    tracing::info!(
                        source = HookConfigSource::ProjectFile.label(),
                        count,
                        "Loaded user hooks from project file"
                    );
                }
                Ok(None) => {}
                Err(error) => errors.push(error),
            }
        }
    }
}

/// 尝试从 YAML 文件加载 `HooksDefinition`。
///
/// 文件不存在 → `Ok(None)`;读取或解析失败 → `Err`, so a live reload can
/// preserve the last known-good hook set.
fn try_load_yaml(path: &Path) -> Result<Option<HooksDefinition>, String> {
    try_load_yaml_with_file_system(path, &echo_agent::tools::files::LocalFileSystem)
}

fn try_load_yaml_with_file_system(
    path: &Path,
    files: &dyn echo_agent::tools::filesystem::FileSystem,
) -> Result<Option<HooksDefinition>, String> {
    if !files
        .exists(path)
        .map_err(|error| format!("Failed to inspect hooks file {}: {error}", path.display()))?
    {
        return Ok(None);
    }
    let content = files
        .read_to_string(path)
        .map_err(|error| format!("Failed to read hooks file {}: {error}", path.display()))?;
    serde_yaml::from_str::<HooksDefinition>(&content)
        .map(Some)
        .map_err(|error| format!("Failed to parse hooks file {}: {error}", path.display()))
}

#[cfg(test)]
mod tests {
    use super::*;
    use echo_agent::skills::hooks::{HookAction, HookEvent, HookRule};
    use std::collections::HashMap;

    /// 构造一条合法的 Prompt hook rule(非空 prompt 通过 validate)。
    fn prompt_rule(matcher: &str, prompt: &str) -> HookRule {
        HookRule {
            matcher: matcher.to_string(),
            hooks: vec![HookAction::Prompt {
                prompt: prompt.to_string(),
            }],
        }
    }

    /// 构造只含一条 rule 的 HooksDefinition。
    fn single_def(event: HookEvent, matcher: &str, prompt: &str) -> HooksDefinition {
        let mut rules = HashMap::new();
        rules.insert(event, vec![prompt_rule(matcher, prompt)]);
        HooksDefinition { rules }
    }

    /// 空的 EkoConfig(无内嵌 hooks)。
    fn empty_app_config() -> EkoConfig {
        EkoConfig::default()
    }

    /// 把 inline hooks 塞进 EkoConfig 的 `hooks` 字段。
    fn app_config_with_inline(def: HooksDefinition) -> EkoConfig {
        EkoConfig {
            hooks: def,
            ..EkoConfig::default()
        }
    }

    struct ProjectHookFiles {
        path: PathBuf,
        bytes: Vec<u8>,
        offline: bool,
    }

    fn unsupported<T>() -> echo_agent::error::Result<T> {
        Err(std::io::Error::new(std::io::ErrorKind::Unsupported, "unused test operation").into())
    }

    impl echo_agent::tools::filesystem::FileSystem for ProjectHookFiles {
        fn current_dir(&self) -> echo_agent::error::Result<PathBuf> {
            unsupported()
        }
        fn canonicalize(&self, _: &Path) -> echo_agent::error::Result<PathBuf> {
            unsupported()
        }
        fn metadata(
            &self,
            path: &Path,
        ) -> echo_agent::error::Result<echo_agent::tools::filesystem::FileMetadata> {
            if self.offline {
                return Err(std::io::Error::new(
                    std::io::ErrorKind::ConnectionReset,
                    "project hooks disconnected",
                )
                .into());
            }
            if path != self.path {
                return Err(
                    std::io::Error::new(std::io::ErrorKind::NotFound, "no target file").into(),
                );
            }
            Ok(echo_agent::tools::filesystem::FileMetadata {
                file_type: echo_agent::tools::filesystem::FileType::File,
                len: u64::try_from(self.bytes.len()).unwrap_or(u64::MAX),
                mode: None,
            })
        }
        fn symlink_metadata(
            &self,
            path: &Path,
        ) -> echo_agent::error::Result<echo_agent::tools::filesystem::FileMetadata> {
            self.metadata(path)
        }
        fn read(&self, path: &Path) -> echo_agent::error::Result<Vec<u8>> {
            self.metadata(path)?;
            Ok(self.bytes.clone())
        }
        fn read_dir(
            &self,
            _: &Path,
        ) -> echo_agent::error::Result<Vec<echo_agent::tools::filesystem::FileEntry>> {
            unsupported()
        }
        fn create_dir_all(&self, _: &Path) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn create_file(&self, _: &Path) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn write(&self, _: &Path, _: &[u8]) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn append(&self, _: &Path, _: &[u8]) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn rename(&self, _: &Path, _: &Path) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn remove_file(&self, _: &Path) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn remove_dir(&self, _: &Path) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn remove_dir_all(&self, _: &Path) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn set_mode(&self, _: &Path, _: u32) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn atomic_write(&self, _: &Path, _: &[u8]) -> echo_agent::error::Result<()> {
            unsupported()
        }
        fn checkpoint(&self, _: &Path) -> echo_agent::error::Result<Option<String>> {
            unsupported()
        }
    }

    #[test]
    fn project_hook_origins_use_provider_and_keep_local_config_order()
    -> Result<(), Box<dyn std::error::Error>> {
        let host = tempfile::tempdir()?;
        let project_root = host.path().join("same-name-project");
        std::fs::create_dir_all(project_root.join(".eko"))?;
        let path = project_root.join(".eko/hooks.yaml");
        std::fs::write(
            &path,
            serde_yaml::to_string(&single_def(HookEvent::Stop, "host-only", "wrong host"))?,
        )?;
        let config = app_config_with_inline(single_def(
            HookEvent::Stop,
            "inline-first",
            "local app config",
        ));
        let files = ProjectHookFiles {
            path: path.clone(),
            bytes: serde_yaml::to_string(&single_def(
                HookEvent::Stop,
                "project-last",
                "target config",
            ))?
            .into_bytes(),
            offline: false,
        };
        let loaded =
            HookConfigLoader::load_merged_with_file_system(&config, Some(&project_root), &files);
        assert!(loaded.errors.is_empty());
        let stop = loaded.definition.rules_for(HookEvent::Stop);
        assert_eq!(
            stop.first().map(|rule| rule.matcher.as_str()),
            Some("inline-first")
        );
        assert_eq!(
            stop.last().map(|rule| rule.matcher.as_str()),
            Some("project-last")
        );
        assert!(!stop.iter().any(|rule| rule.matcher == "host-only"));
        assert!(
            loaded
                .origins
                .first()
                .is_some_and(|origin| !origin.project && origin.directory.is_absolute())
        );
        assert!(
            loaded
                .origins
                .last()
                .is_some_and(|origin| origin.project && origin.directory == project_root)
        );
        let offline = ProjectHookFiles {
            offline: true,
            ..files
        };
        let failed =
            HookConfigLoader::load_merged_with_file_system(&config, Some(&project_root), &offline);
        assert!(
            failed
                .errors
                .iter()
                .any(|error| error.contains("project hooks disconnected"))
        );
        assert!(
            !failed
                .definition
                .rules_for(HookEvent::Stop)
                .iter()
                .any(|rule| rule.matcher == "host-only" || rule.matcher == "project-last")
        );
        Ok(())
    }

    // ── 合并顺序测试 ─────────────────────────────────────────────

    #[test]
    fn test_inline_hooks_loaded_from_app_config() -> Result<(), String> {
        let workspace = tempfile::tempdir().map_err(|error| error.to_string())?;
        let inline = single_def(HookEvent::SessionStart, "*", "inline-only");
        let cfg = app_config_with_inline(inline);
        let result = HookConfigLoader::load_merged_for_workspace(&cfg, Some(workspace.path()));
        assert!(
            result
                .definition
                .rules_for(HookEvent::SessionStart)
                .iter()
                .any(|rule| rule.matcher == "*"),
            "inline hooks should be present in merged result"
        );
        Ok(())
    }

    #[test]
    fn test_merge_order_inline_then_files() {
        // 三源都存在(用真实磁盘文件模拟)时,项目级应叠加在内嵌和全局之上。
        // 这里只验证"合并逻辑"——实际文件加载由 try_load_yaml 处理,
        // 已在 test_load_yaml_parses_valid_file 覆盖。本测试用 merge 直接验证顺序。
        let mut merged = HooksDefinition::default();
        let inline = single_def(HookEvent::Stop, "*", "inline");
        let global = single_def(HookEvent::Stop, "*", "global");
        let project = single_def(HookEvent::Stop, "*", "project");

        // 按文档顺序 merge(additive):内嵌 < 全局 < 项目
        merged.merge(inline);
        merged.merge(global);
        merged.merge(project);

        // additive 语义:三条都应在
        let rules = merged.rules_for(HookEvent::Stop);
        assert_eq!(rules.len(), 3, "additive merge should keep all 3 rules");
    }

    #[test]
    fn test_load_merged_empty_app_config_no_workspace_hooks() -> Result<(), String> {
        let workspace = tempfile::tempdir().map_err(|error| error.to_string())?;
        let cfg = empty_app_config();
        let result = HookConfigLoader::load_merged_for_workspace(&cfg, Some(workspace.path()));
        let workspace_hook = workspace.path().join(".eko").join("hooks.yaml");
        assert!(!result.loaded_from.contains(&workspace_hook));
        assert!(
            result
                .loaded_from
                .iter()
                .all(|path| path == &crate::data_root::user_data_path("hooks.yaml"))
        );
        Ok(())
    }

    #[test]
    fn default_load_does_not_infer_a_workspace_root() -> Result<(), String> {
        let workspace = tempfile::tempdir().map_err(|error| error.to_string())?;
        let hooks_dir = workspace.path().join(".eko");
        std::fs::create_dir_all(&hooks_dir).map_err(|error| error.to_string())?;
        let hooks_path = hooks_dir.join("hooks.yaml");
        std::fs::write(
            &hooks_path,
            "SessionStart:\n  - matcher: \"must-stay-explicit\"\n    hooks:\n      - type: prompt\n        prompt: \"workspace hook\"\n",
        )
        .map_err(|error| error.to_string())?;

        let result = HookConfigLoader::load_merged(&EkoConfig::default());
        assert!(!result.loaded_from.contains(&hooks_path));
        assert!(
            result
                .definition
                .rules_for(HookEvent::SessionStart)
                .iter()
                .all(|rule| rule.matcher != "must-stay-explicit")
        );
        Ok(())
    }

    #[test]
    fn explicit_workspace_root_selects_project_hooks() -> Result<(), String> {
        let workspace = tempfile::tempdir().map_err(|error| error.to_string())?;
        let hooks_dir = workspace.path().join(".eko");
        std::fs::create_dir_all(&hooks_dir).map_err(|error| error.to_string())?;
        let hooks_path = hooks_dir.join("hooks.yaml");
        std::fs::write(
            &hooks_path,
            "SessionStart:\n  - matcher: \"explicit-workspace-marker\"\n    hooks:\n      - type: prompt\n        prompt: \"workspace hook\"\n",
        )
        .map_err(|error| error.to_string())?;

        let result = HookConfigLoader::load_merged_for_workspace(
            &EkoConfig::default(),
            Some(workspace.path()),
        );
        assert!(result.errors.is_empty());
        assert!(result.loaded_from.contains(&hooks_path));
        assert!(
            result
                .definition
                .rules_for(HookEvent::SessionStart)
                .iter()
                .any(|rule| rule.matcher == "explicit-workspace-marker")
        );
        Ok(())
    }

    // ── 文件加载测试 ─────────────────────────────────────────────

    #[test]
    fn test_try_load_yaml_returns_none_for_missing_file() {
        let p = PathBuf::from("/tmp/__definitely_not_existing_hooks__.yaml");
        assert!(matches!(try_load_yaml(&p), Ok(None)));
    }

    #[test]
    fn test_try_load_yaml_parses_valid_file() -> Result<(), String> {
        // 写一个临时 YAML 文件,验证能解析出 HooksDefinition。
        let dir = std::env::temp_dir();
        let fname = format!("eko_hook_loader_test_{}.yaml", std::process::id());
        let path = dir.join(fname);
        // 用 hooks.yaml 实际格式:顶层是 event 名 → rule 列表。
        // HooksDefinition 用 serde(flatten) 所以是 event 名直接铺平。
        let yaml = r#"
SessionStart:
  - matcher: "*"
    hooks:
      - type: prompt
        prompt: "hello from file"
"#;
        std::fs::write(&path, yaml).map_err(|error| error.to_string())?;

        let def = try_load_yaml(&path);
        // 清理临时文件
        let _ = std::fs::remove_file(&path);

        let def = def.ok().flatten().unwrap_or_default();
        let rules = def.rules_for(HookEvent::SessionStart);
        assert_eq!(rules.len(), 1, "one SessionStart rule expected");
        // 不再访问 matcher/hook 内部细节,只验证数量足够(避免耦合字段)。
        Ok(())
    }

    #[test]
    fn test_try_load_yaml_reports_parse_error() {
        let path = std::env::temp_dir().join(format!(
            "eko_hook_loader_invalid_{}.yaml",
            std::process::id()
        ));
        let write_result = std::fs::write(&path, "SessionStart: [");
        assert!(write_result.is_ok(), "failed to write invalid hook fixture");
        if write_result.is_err() {
            return;
        }
        let result = try_load_yaml(&path);
        let _ = std::fs::remove_file(&path);
        assert!(result.is_err());
    }

    // ── 来源标识 ────────────────────────────────────────────────

    #[test]
    fn test_hook_config_source_labels_distinct() {
        let labels = [
            HookConfigSource::InlineConfig.label(),
            HookConfigSource::GlobalFile.label(),
            HookConfigSource::ProjectFile.label(),
        ];
        // 三个 label 应互不相同且非空。
        for l in labels.iter() {
            assert!(!l.is_empty());
        }
        assert_eq!(labels.len(), 3);
        let unique: std::collections::HashSet<_> = labels.iter().collect();
        assert_eq!(unique.len(), 3, "labels should be distinct");
    }
}
