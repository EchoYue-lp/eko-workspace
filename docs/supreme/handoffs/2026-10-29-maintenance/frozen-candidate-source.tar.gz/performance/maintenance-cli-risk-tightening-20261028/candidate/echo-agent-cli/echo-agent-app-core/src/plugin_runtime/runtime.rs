impl PluginRuntimeService {
    /// Construct a plugin runtime that hands every unsettled cleanup receipt
    /// (including exact MCP ownership tokens) back to the caller when the initial
    /// generation cannot be committed.
    pub(crate) async fn new_owned(
        agent_handle: AgentHandle,
        project_root: PathBuf,
        mcp_ownership: Arc<McpNameOwnershipRegistry>,
    ) -> Result<Arc<Self>, PluginBootstrapFailure> {
        Self::new_owned_with_source(
            agent_handle,
            project_root,
            mcp_ownership,
            RegistrySource::Default,
            "global".to_string(),
            None,
            true,
        )
        .await
    }

    /// Construct a scoped plugin runtime after the caller has already
    /// retired the seed Agent generation. This avoids a second name-based
    /// descriptor cleanup after project-local Skills have been loaded.
    pub(crate) async fn new_owned_for_scope_after_agent_reset(
        agent_handle: AgentHandle,
        project_root: PathBuf,
        mcp_ownership: Arc<McpNameOwnershipRegistry>,
        target_scope: String,
        authority_generation: Option<AgentPluginGeneration>,
    ) -> Result<Arc<Self>, PluginBootstrapFailure> {
        Self::new_owned_with_source(
            agent_handle,
            project_root,
            mcp_ownership,
            RegistrySource::Default,
            target_scope,
            authority_generation,
            false,
        )
        .await
    }

    async fn new_owned_with_source(
        agent_handle: AgentHandle,
        project_root: PathBuf,
        mcp_ownership: Arc<McpNameOwnershipRegistry>,
        registry_source: RegistrySource,
        target_scope: String,
        authority_generation: Option<AgentPluginGeneration>,
        remove_authority_descriptors: bool,
    ) -> Result<Arc<Self>, PluginBootstrapFailure> {
        let framework_generation = authority_generation
            .as_ref()
            .and_then(AgentPluginGeneration::framework_generation);
        let authority_revision = authority_generation
            .as_ref()
            .map_or(0, AgentPluginGeneration::revision);
        let preferences_file = match &registry_source {
            RegistrySource::Default => crate::data_root::user_data_dir()
                .join("plugins")
                .join("preferences.json"),
            #[cfg(test)]
            RegistrySource::Custom { state_file, .. } => {
                state_file.with_file_name("preferences.json")
            }
        };
        let preferences = load_preferences(&preferences_file);
        let registry = match &registry_source {
            RegistrySource::Default => PluginRegistry::new(crate::data_root::user_data_dir(), None),
            #[cfg(test)]
            RegistrySource::Custom {
                state_file,
                data_dir,
                ..
            } => PluginRegistry::with_paths(state_file.clone(), data_dir.clone(), None),
        };
        for diagnostic in crate::config_discovery::retired_lsp_config_diagnostics(
            Some(&project_root),
            &crate::data_root::user_data_dir(),
        ) {
            tracing::warn!(%diagnostic);
        }
        let service = Arc::new(Self {
            agent_handle,
            project_root: RwLock::new(project_root),
            scheduler: RwLock::new(None),
            mcp_ownership,
            integrator: PluginIntegrator::default(),
            target_scope,
            registry_source,
            preferences_file,
            state: Mutex::new(PluginRuntimeState {
                registry,
                framework_components: HashMap::new(),
                framework_generation,
                framework_receipt: None,
                mcp_ownership: HashMap::new(),
                prepared: PreparedApplicationComponents::default(),
                lifecycle: PluginLifecycleManager::new(),
                cleanup_receipts: Vec::new(),
                active_theme: preferences.active_theme,
                active_output_style: preferences.active_output_style,
                generation: authority_revision,
                shut_down: false,
            }),
            agent_pool: RwLock::new(None),
            mutation_supervisor: Mutex::new(PluginMutationSupervisor::default()),
        });
        // Root lookup does not transfer resource authority. Withdraw the earlier
        // target using its exact retained authorities before mutating this target,
        // and export the unchanged debt if it cannot settle.
        if let Err(error) = service.adopt_parked_cleanup_receipts().await {
            return Err(service.into_bootstrap_failure(error).await);
        }
        if remove_authority_descriptors && let Some(authority_generation) = authority_generation {
            // A cold workspace primary is created from the global pool's exact
            // committed projection. Retire it before applying the workspace's
            // full User + Project + Local prepared set so global project-only
            // descriptors cannot survive in the new target.
            service
                .agent_handle
                .write_async(|agent| {
                    Box::pin(async move {
                        crate::agent_pool::remove_agent_plugin_generation(
                            agent,
                            &authority_generation,
                        )
                        .await;
                    })
                })
                .await;
        }
        if let Err(error) = service.reload().await {
            return Err(service.into_bootstrap_failure(error).await);
        }
        Ok(service)
    }

    /// Take over cleanup debt parked by an earlier failed bootstrap and retry it.
    ///
    /// The root selects debt to retry; the exported receipt retains its issuing
    /// Agent, registry, scheduler and lifecycle authority. Residual debt prevents
    /// this constructor from publishing a replacement generation.
    async fn adopt_parked_cleanup_receipts(&self) -> anyhow::Result<()> {
        let root = self.project_root.read().await.clone();
        let parked = take_parked_cleanup_receipts(&root);
        if parked.is_empty() {
            return Ok(());
        }
        let adopted = parked.len();
        let mut state = self.state.lock().await;
        state.cleanup_receipts.extend(parked);
        self.settle_pending_receipts(&mut state, "plugin bootstrap cleanup adoption")
            .await?;
        tracing::warn!(
            adopted,
            "settled original-target cleanup receipts before plugin bootstrap publication"
        );
        Ok(())
    }

    async fn cleanup_authority(&self) -> Arc<CleanupAuthority> {
        Arc::new(CleanupAuthority {
            agent_handle: self.agent_handle.clone(),
            mcp_ownership: Arc::clone(&self.mcp_ownership),
            scheduler: self.scheduler.read().await.clone(),
            registry_source: self.registry_source.clone(),
        })
    }

    /// Convert runtime-local obligations into self-contained original-target
    /// receipts. No service Arc is retained, so exported debt cannot form a
    /// service/ledger cycle. Already-exported receipts keep their old authority.
    fn export_cleanup_receipts(
        state: &mut PluginRuntimeState,
        authority: &Arc<CleanupAuthority>,
    ) -> Vec<CleanupReceipt> {
        let mut receipts = std::mem::take(&mut state.cleanup_receipts);
        let needs_lifecycle = receipts.iter().any(|receipt| {
            matches!(
                &receipt.settlement,
                CleanupSettlement::LiveLifecycle { .. } | CleanupSettlement::LifecycleShutdown
            )
        });
        let lifecycle = needs_lifecycle.then(|| {
            Arc::new(Mutex::new(std::mem::replace(
                &mut state.lifecycle,
                PluginLifecycleManager::new(),
            )))
        });
        for receipt in &mut receipts {
            if matches!(
                &receipt.settlement,
                CleanupSettlement::LiveLifecycle { .. } | CleanupSettlement::LifecycleShutdown
            ) && let Some(manager) = lifecycle.as_ref()
            {
                receipt.settlement = CleanupSettlement::OwnedLifecycle {
                    manager: Arc::clone(manager),
                };
            }
        }
        receipts
            .into_iter()
            .map(|receipt| receipt.bind_authority(authority))
            .collect()
    }

    /// Convert a failed initial generation into a value that keeps every
    /// unsettled cleanup obligation.
    ///
    /// The service is about to be dropped, so external withdrawal that only it
    /// could perform must travel with the error. Ownership tokens still held by
    /// this instance are handed over as receipts rather than silently released:
    /// their wire-level components may still be attached to an Agent the caller
    /// continues to hold.
    async fn into_bootstrap_failure(
        self: &Arc<Self>,
        error: anyhow::Error,
    ) -> PluginBootstrapFailure {
        let authority = self.cleanup_authority().await;
        let mut state = self.state.lock().await;
        let root = self.project_root.read().await.clone();
        let claims = claims_from_ownership(&std::mem::take(&mut state.mcp_ownership));
        let cause = "bootstrap failed after candidate components were wired".to_string();
        if let Some(wiring) = state.framework_receipt.take() {
            state
                .cleanup_receipts
                .push(CleanupReceipt::framework(root, cause, wiring, claims));
        } else if !claims.is_empty() {
            state
                .cleanup_receipts
                .push(CleanupReceipt::mcp_names(root, cause, claims));
        }
        let receipts = Self::export_cleanup_receipts(&mut state, &authority);
        for receipt in &receipts {
            tracing::error!(
                receipt = %receipt.describe(),
                "Plugin runtime bootstrap retained a cleanup receipt"
            );
        }
        drop(state);
        // `PluginBootstrapFailure` hands these to the caller as a collection that
        // can only leave scope parked in the process-level retry ledger.
        PluginBootstrapFailure::new(error, receipts)
    }

    #[cfg(test)]
    pub(crate) async fn new_for_test(
        agent_handle: AgentHandle,
        project_root: PathBuf,
        state_file: PathBuf,
        data_dir: PathBuf,
    ) -> anyhow::Result<Arc<Self>> {
        Self::new_for_test_with_ownership(
            agent_handle,
            project_root,
            state_file,
            data_dir,
            McpNameOwnershipRegistry::new(Vec::<String>::new()),
        )
        .await
    }

    #[cfg(test)]
    pub(crate) async fn new_for_test_with_ownership(
        agent_handle: AgentHandle,
        project_root: PathBuf,
        state_file: PathBuf,
        data_dir: PathBuf,
        mcp_ownership: Arc<McpNameOwnershipRegistry>,
    ) -> anyhow::Result<Arc<Self>> {
        Self::new_for_test_owned(
            agent_handle,
            project_root,
            state_file,
            data_dir,
            mcp_ownership,
        )
        .await
        .map_err(PluginBootstrapFailure::into_error)
    }

    #[cfg(test)]
    pub(crate) async fn new_for_test_owned(
        agent_handle: AgentHandle,
        project_root: PathBuf,
        state_file: PathBuf,
        data_dir: PathBuf,
        mcp_ownership: Arc<McpNameOwnershipRegistry>,
    ) -> Result<Arc<Self>, PluginBootstrapFailure> {
        let target_scope = format!("test:{}", project_root.display());
        Self::new_owned_with_source(
            agent_handle,
            project_root,
            mcp_ownership,
            RegistrySource::Custom {
                state_file,
                data_dir,
                scopes: vec![PluginScope::Project, PluginScope::Local],
            },
            target_scope,
            None,
            true,
        )
        .await
    }

    async fn run_owned_mutation<T, F, Fut>(self: &Arc<Self>, operation: F) -> anyhow::Result<T>
    where
        T: Send + 'static,
        F: FnOnce(Arc<Self>) -> Fut + Send + 'static,
        Fut: std::future::Future<Output = anyhow::Result<T>> + Send + 'static,
    {
        let (result_sender, result_receiver) = tokio::sync::oneshot::channel();
        let mut supervisor = self.mutation_supervisor.lock().await;
        if !supervisor.accepting {
            return Err(anyhow::anyhow!("plugin runtime is shutting down"));
        }
        let sequence_permit = Arc::clone(&supervisor.sequence)
            .acquire_owned()
            .await
            .map_err(|error| anyhow::anyhow!("plugin mutation sequence is closed: {error}"))?;
        while let Some(result) = supervisor.settlements.try_join_next() {
            if let Err(error) = result {
                tracing::warn!(%error, "completed plugin mutation owner failed");
            }
        }
        let service = Arc::clone(self);
        supervisor.settlements.spawn(async move {
            let _sequence_permit = sequence_permit;
            let result = match tokio::spawn(operation(service)).await {
                Ok(result) => result,
                Err(error) => Err(anyhow::anyhow!(
                    "plugin mutation task failed before settlement: {error}"
                )),
            };
            let _ = result_sender.send(result);
        });
        drop(supervisor);
        result_receiver
            .await
            .map_err(|_| anyhow::anyhow!("plugin mutation settlement task stopped unexpectedly"))?
    }

    /// Bind the process pool to the currently committed plugin generation.
    pub async fn bind_agent_pool(self: &Arc<Self>, pool: Weak<AgentPool>) -> anyhow::Result<()> {
        self.run_owned_mutation(
            move |service| async move { service.bind_agent_pool_inner(pool).await },
        )
        .await
    }

    async fn bind_agent_pool_inner(&self, pool: Weak<AgentPool>) -> anyhow::Result<()> {
        let pool_owner = pool
            .upgrade()
            .ok_or_else(|| anyhow::anyhow!("AgentPool was released before plugin binding"))?;
        if let Some(existing) = self
            .agent_pool
            .read()
            .await
            .as_ref()
            .and_then(Weak::upgrade)
            && !Arc::ptr_eq(&existing, &pool_owner)
        {
            return Err(anyhow::anyhow!(
                "plugin runtime is already bound to another live AgentPool"
            ));
        }
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin AgentPool binding")
            .await?;
        if state.shut_down {
            return Err(anyhow::anyhow!("plugin runtime is shut down"));
        }
        let generation = self
            .capture_agent_generation(
                state.generation,
                &state.prepared,
                state.active_output_style.as_deref(),
            )
            .await
            .with_framework_generation(state.framework_generation.clone());
        let mut publication = pool_owner
            .begin_plugin_publication()
            .await
            .map_err(anyhow::Error::msg)?;
        publication
            .prepare(generation)
            .await
            .map_err(anyhow::Error::msg)?;
        publication.commit().await.map_err(anyhow::Error::msg)?;
        pool_owner
            .install_domain_registration_admission(&self.agent_handle)
            .await;
        *self.agent_pool.write().await = Some(pool);
        Ok(())
    }

    async fn capture_agent_generation(
        &self,
        revision: u64,
        prepared: &PreparedApplicationComponents,
        active_output_style: Option<&str>,
    ) -> AgentPluginGeneration {
        let descriptors = self
            .agent_handle
            .read(|agent| agent.skill_descriptors())
            .await;
        let output_style = active_output_style_instructions_for(active_output_style, prepared);
        AgentPluginGeneration::new(revision, descriptors, prepared.agents.clone(), output_style)
            .with_domain_components(
                prepared.domains.clone(),
                active_output_style.map(str::to_string),
            )
    }

    /// Atomically load one EKO-owned skill into the primary and pool catalog.
    /// The registry edit happens inside the same mutation owner as plugin
    /// reload/rebind, preventing a plugin generation from overwriting it.
    pub(crate) async fn enable_application_skill(
        self: &Arc<Self>,
        name: String,
        load_root: PathBuf,
        source: String,
    ) -> anyhow::Result<Vec<String>> {
        self.run_owned_mutation(move |service| async move {
            service
                .enable_application_skill_inner(&name, load_root, &source)
                .await
        })
        .await
    }

    async fn enable_application_skill_inner(
        &self,
        name: &str,
        load_root: PathBuf,
        source: &str,
    ) -> anyhow::Result<Vec<String>> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "application Skill enable")
            .await?;
        if state.shut_down {
            anyhow::bail!("plugin runtime is shut down");
        }
        let revision = state
            .generation
            .checked_add(1)
            .ok_or_else(|| anyhow::anyhow!("plugin generation revision exhausted"))?;
        let primary_execution = self
            .agent_handle
            .read(|agent| Arc::clone(agent.execution_mutex()))
            .await;
        let _primary_execution_guard = primary_execution.lock_owned().await;
        let primary_owner = Arc::clone(self.agent_handle.inner());
        let mut primary = primary_owner.write_owned().await;
        let primary_had_skill = primary.skill_descriptors().iter().any(|descriptor| {
            descriptor.name == name && descriptor.source.as_deref() == Some(source)
        });
        let pool = self
            .agent_pool
            .read()
            .await
            .as_ref()
            .and_then(Weak::upgrade);
        if primary_had_skill && pool.is_none() {
            return Ok(vec![name.to_string()]);
        }
        let mut pool_publication = if let Some(pool) = pool.as_ref() {
            Some(
                pool.begin_plugin_publication()
                    .await
                    .map_err(anyhow::Error::msg)?,
            )
        } else {
            None
        };
        let loaded = if primary_had_skill {
            vec![name.to_string()]
        } else {
            load_exact_application_skill(&mut primary, name, load_root, source).await?
        };
        if !loaded.iter().any(|loaded_name| loaded_name == name) {
            anyhow::bail!("Skill '{name}' was not discovered");
        }
        crate::runtime::configure_intent_router(&mut primary);
        let generation = AgentPluginGeneration::new(
            revision,
            primary.skill_descriptors(),
            state.prepared.agents.clone(),
            active_output_style_instructions(&state),
        )
        .with_domain_components(
            state.prepared.domains.clone(),
            state.active_output_style.clone(),
        )
        .with_framework_generation(state.framework_generation.clone());
        if let Some(publication) = pool_publication.as_mut()
            && let Err(error) = publication
                .prepare_application_skill(generation, name, source)
                .await
        {
            if !primary_had_skill {
                primary.unregister_skills_by_source(source).await;
                crate::runtime::configure_intent_router(&mut primary);
            }
            return Err(anyhow::Error::msg(error));
        }
        if let Some(publication) = pool_publication.as_mut()
            && let Err(error) = publication.commit().await
        {
            if !primary_had_skill {
                primary.unregister_skills_by_source(source).await;
                crate::runtime::configure_intent_router(&mut primary);
            }
            let rollback = publication.rollback().await.err();
            return Err(match rollback {
                Some(rollback) => anyhow::anyhow!(
                    "Skill pool commit failed: {error}; rollback failed: {rollback}"
                ),
                None => anyhow::Error::msg(error),
            });
        }
        state.generation = revision;
        Ok(loaded)
    }

    /// Atomically remove one EKO-owned skill from primary and pool catalogs.
    pub(crate) async fn disable_application_skill(
        self: &Arc<Self>,
        name: String,
        load_root: PathBuf,
        source: String,
    ) -> anyhow::Result<Vec<String>> {
        self.run_owned_mutation(move |service| async move {
            service
                .disable_application_skill_inner(&name, load_root, &source)
                .await
        })
        .await
    }

    async fn disable_application_skill_inner(
        &self,
        name: &str,
        load_root: PathBuf,
        source: &str,
    ) -> anyhow::Result<Vec<String>> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "application Skill disable")
            .await?;
        if state.shut_down {
            anyhow::bail!("plugin runtime is shut down");
        }
        let revision = state
            .generation
            .checked_add(1)
            .ok_or_else(|| anyhow::anyhow!("plugin generation revision exhausted"))?;
        let primary_execution = self
            .agent_handle
            .read(|agent| Arc::clone(agent.execution_mutex()))
            .await;
        let _primary_execution_guard = primary_execution.lock_owned().await;
        let primary_owner = Arc::clone(self.agent_handle.inner());
        let mut primary = primary_owner.write_owned().await;
        let primary_had_skill = primary.skill_descriptors().iter().any(|descriptor| {
            descriptor.name == name && descriptor.source.as_deref() == Some(source)
        });
        let pool = self
            .agent_pool
            .read()
            .await
            .as_ref()
            .and_then(Weak::upgrade);
        if !primary_had_skill && pool.is_none() {
            return Ok(Vec::new());
        }
        let mut pool_publication = if let Some(pool) = pool.as_ref() {
            Some(
                pool.begin_plugin_publication()
                    .await
                    .map_err(anyhow::Error::msg)?,
            )
        } else {
            None
        };
        let removed = if primary_had_skill {
            primary.unregister_skills_by_source(source).await
        } else {
            Vec::new()
        };
        crate::runtime::configure_intent_router(&mut primary);
        let generation = AgentPluginGeneration::new(
            revision,
            primary.skill_descriptors(),
            state.prepared.agents.clone(),
            active_output_style_instructions(&state),
        )
        .with_domain_components(
            state.prepared.domains.clone(),
            state.active_output_style.clone(),
        )
        .with_framework_generation(state.framework_generation.clone());
        if let Some(publication) = pool_publication.as_mut()
            && let Err(error) = publication
                .prepare_application_skill(generation, name, source)
                .await
        {
            let restore_error = if primary_had_skill {
                let restore =
                    load_exact_application_skill(&mut primary, name, load_root.clone(), source)
                        .await
                        .err();
                crate::runtime::configure_intent_router(&mut primary);
                restore
            } else {
                None
            };
            return Err(match restore_error {
                Some(restore) => anyhow::anyhow!(
                    "Skill pool preparation failed: {error}; primary restore failed: {restore}"
                ),
                None => anyhow::Error::msg(error),
            });
        }
        if let Some(publication) = pool_publication.as_mut()
            && let Err(error) = publication.commit().await
        {
            let restore = if primary_had_skill {
                let restore =
                    load_exact_application_skill(&mut primary, name, load_root, source).await;
                crate::runtime::configure_intent_router(&mut primary);
                Some(restore)
            } else {
                None
            };
            let rollback = publication.rollback().await.err();
            let mut errors = vec![format!("Skill pool commit failed: {error}")];
            if let Some(Err(error)) = restore {
                errors.push(format!("primary restore failed: {error}"));
            }
            errors.extend(rollback.map(|error| format!("pool rollback failed: {error}")));
            return Err(anyhow::anyhow!(errors.join("; ")));
        }
        state.generation = revision;
        Ok(removed)
    }

    async fn drain_owned_mutations(
        mut settlements: tokio::task::JoinSet<()>,
    ) -> anyhow::Result<()> {
        let mut errors = Vec::new();
        while let Some(settlement) = settlements.join_next().await {
            if let Err(error) = settlement {
                errors.push(error.to_string());
            }
        }
        if errors.is_empty() {
            Ok(())
        } else {
            Err(anyhow::anyhow!(
                "plugin mutation settlement failed: {}",
                errors.join("; ")
            ))
        }
    }

    pub(crate) async fn reload(self: &Arc<Self>) -> anyhow::Result<ReloadSummary> {
        self.run_owned_mutation(|service| async move { service.reload_inner().await })
            .await
    }

    async fn reload_inner(&self) -> anyhow::Result<ReloadSummary> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin reload")
            .await?;
        let binding = self.project_root.read().await.clone();
        let mut candidate = self.registry_for(binding.to_path_buf());
        self.scan_registry(&mut candidate)?;
        self.apply_candidate(&mut state, candidate, &binding).await
    }

    /// Validate a target generation without replacing live plugin resources.
    pub async fn preflight_workspace(&self, project_root: PathBuf) -> anyhow::Result<()> {
        let binding = project_root;
        let mut candidate = self.registry_for(binding.to_path_buf());
        self.scan_registry(&mut candidate)?;
        let framework_generation =
            require_applicable_generation(self.integrator.prepare(&mut candidate).await)?;
        let prepared =
            prepare_application_components(&framework_generation, &self.target_scope, &candidate)
                .map_err(|errors| anyhow::anyhow!(errors.join("; ")))?;
        let declarations = plugin_mcp_declarations(&framework_generation)?;
        let state = self.state.lock().await;
        if state.shut_down {
            return Err(anyhow::anyhow!("plugin runtime is shut down"));
        }
        self.validate_agent_collisions(&state, &prepared).await?;
        let ownership_guard = self.mcp_ownership.lock().await;
        validate_plugin_mcp_claims(&ownership_guard, &declarations, &state.mcp_ownership)
            .map_err(anyhow::Error::msg)?;
        drop(ownership_guard);
        Ok(())
    }

    /// Replace project/local plugin components for a committed workspace.
    /// A target failure converges to the target's User-only generation instead
    /// of clearing user-scoped plugins or retaining old workspace plugins.
    pub(crate) async fn rebind_workspace(
        self: &Arc<Self>,
        project_root: PathBuf,
    ) -> anyhow::Result<ReloadSummary> {
        self.run_owned_mutation(move |service| async move {
            service.rebind_workspace_inner(project_root).await
        })
        .await
    }

    async fn rebind_workspace_inner(&self, project_root: PathBuf) -> anyhow::Result<ReloadSummary> {
        for diagnostic in crate::config_discovery::retired_lsp_config_diagnostics(
            Some(&project_root),
            &crate::data_root::user_data_dir(),
        ) {
            tracing::warn!(%diagnostic);
        }

        let previous_binding = self.project_root.read().await.clone();
        let binding = project_root;
        let mut candidate = self.registry_for(binding.to_path_buf());
        let scan = self.scan_registry(&mut candidate);
        let mut state = self.state.lock().await;
        if state.shut_down {
            return Err(anyhow::anyhow!("plugin runtime is shut down"));
        }
        let retry_errors = self.retry_cleanup_receipts(&mut state).await;
        let previous_workspace_plugins = workspace_scope_plugin_ids(&state.registry);
        let result = match scan {
            Ok(()) => self.apply_candidate(&mut state, candidate, &binding).await,
            Err(error) => Err(error),
        };
        match result {
            Ok(summary) => {
                let mut retirement_errors = retry_errors;
                let (errors, failed_plugin_ids) =
                    retire_plugin_lifecycles(&mut state.lifecycle, &previous_workspace_plugins);
                retirement_errors.extend(errors);
                if !failed_plugin_ids.is_empty() {
                    state.cleanup_receipts.push(CleanupReceipt::live_lifecycle(
                        previous_binding.to_path_buf(),
                        "previous workspace lifecycle retirement failed".to_string(),
                        failed_plugin_ids,
                    ));
                }
                if let Some(error) =
                    Self::outstanding_receipt_error(&state, "workspace plugin rebind")
                {
                    retirement_errors.push(error.to_string());
                }
                if retirement_errors.is_empty() {
                    Ok(summary)
                } else {
                    Err(anyhow::anyhow!(
                        "Target plugin generation committed, but previous workspace lifecycle retirement failed: {}",
                        retirement_errors.join("; ")
                    ))
                }
            }
            Err(error) => {
                let primary = error.to_string();
                let mut user_candidate = self.registry_for(binding.to_path_buf());
                let fallback =
                    match self.scan_registry_scopes(&mut user_candidate, &[PluginScope::User]) {
                        Ok(()) => self
                            .apply_candidate(&mut state, user_candidate, &binding)
                            .await
                            .map(|_| ()),
                        Err(error) => Err(error),
                    };
                match fallback {
                    Ok(()) => {
                        let mut retirement_errors = retry_errors;
                        let (errors, failed_plugin_ids) = retire_plugin_lifecycles(
                            &mut state.lifecycle,
                            &previous_workspace_plugins,
                        );
                        retirement_errors.extend(errors);
                        if !failed_plugin_ids.is_empty() {
                            state.cleanup_receipts.push(CleanupReceipt::live_lifecycle(
                                previous_binding.to_path_buf(),
                                "previous workspace lifecycle retirement failed".to_string(),
                                failed_plugin_ids,
                            ));
                        }
                        Err(anyhow::anyhow!(append_errors(
                            format!(
                                "Target workspace plugins were rejected; committed User-scope plugin generation instead: {primary}"
                            ),
                            retirement_errors,
                        )))
                    }
                    Err(fallback_error) => {
                        let retirement_errors = self
                            .retire_generation_fail_closed(
                                &mut state,
                                &binding,
                                previous_binding.to_path_buf(),
                            )
                            .await;
                        let mut all_errors = retry_errors;
                        all_errors.extend(retirement_errors);
                        Err(anyhow::anyhow!(append_errors(
                            format!(
                                "{primary}; failed to converge target User-scope plugin generation: {fallback_error}; retired all plugin-owned components fail-closed, including degraded User-scope plugins"
                            ),
                            all_errors,
                        )))
                    }
                }
            }
        }
    }

    async fn retire_generation_fail_closed(
        &self,
        state: &mut PluginRuntimeState,
        binding: &Path,
        previous_root: PathBuf,
    ) -> Vec<String> {
        let mut errors = Vec::new();
        let primary_execution = self
            .agent_handle
            .read(|agent| Arc::clone(agent.execution_mutex()))
            .await;
        let _primary_execution_guard = primary_execution.lock_owned().await;
        let primary_owner = Arc::clone(self.agent_handle.inner());
        let mut primary = primary_owner.write_owned().await;
        let pool = self
            .agent_pool
            .read()
            .await
            .as_ref()
            .and_then(Weak::upgrade);
        let mut pool_publication = if let Some(pool) = pool.as_ref() {
            match pool.begin_plugin_publication().await {
                Ok(publication) => Some(publication),
                Err(error) => {
                    errors.push(format!(
                        "Failed to close AgentPool admission for fail-closed plugin retirement: {error}"
                    ));
                    return errors;
                }
            }
        } else {
            None
        };
        let previous_prepared = std::mem::take(&mut state.prepared);
        let mut failed_monitors = Vec::new();
        if let Some(scheduler) = self.scheduler.read().await.clone() {
            let monitor_errors =
                remove_plugin_monitors_best_effort(&scheduler, &previous_prepared.monitors).await;
            if !monitor_errors.is_empty() {
                failed_monitors = previous_prepared.monitors.clone();
                errors.extend(monitor_errors);
            }
        }
        if !failed_monitors.is_empty() {
            state.cleanup_receipts.push(CleanupReceipt::monitors(
                previous_root.clone(),
                "fail-closed plugin retirement could not remove plugin monitors".to_string(),
                failed_monitors,
            ));
        }

        let mut previous_lifecycle =
            std::mem::replace(&mut state.lifecycle, PluginLifecycleManager::new());
        let lifecycle_errors = previous_lifecycle.shutdown();
        if lifecycle_errors.is_empty() {
            drop(previous_lifecycle);
        } else {
            errors.extend(lifecycle_errors);
            state.cleanup_receipts.push(CleanupReceipt::owned_lifecycle(
                previous_root.clone(),
                "fail-closed plugin retirement could not shut down plugin lifecycles".to_string(),
                previous_lifecycle,
            ));
        }

        state.framework_components.clear();
        state.framework_generation.take();
        let previous_framework_receipt = state.framework_receipt.take();
        let previous_mcp_ownership = std::mem::take(&mut state.mcp_ownership);
        let previous_claims = claims_from_ownership(&previous_mcp_ownership);
        let mut ownership_guard = self.mcp_ownership.lock().await;
        let mut owned_claims = previous_claims.clone();
        if let Some(receipt) = previous_framework_receipt.as_ref() {
            match self.integrator.rollback(&mut primary, receipt).await {
                Ok(()) => {}
                Err(error) => {
                    errors.push(format!("framework plugin rollback failed: {error}"));
                    // The failed withdrawal still owns its MCP clients: keep the
                    // exact tokens in one receipt and only release them after a
                    // successful retry of this wiring receipt. Prefer the receipt
                    // the framework reported as canonical for this failed attempt.
                    let retained_withdrawal = error
                        .cleanup_receipt()
                        .cloned()
                        .unwrap_or_else(|| receipt.clone());
                    state.cleanup_receipts.push(CleanupReceipt::framework(
                        previous_root.clone(),
                        "fail-closed plugin retirement could not withdraw plugin components"
                            .to_string(),
                        retained_withdrawal,
                        std::mem::take(&mut owned_claims),
                    ));
                }
            }
        }
        unload_application_components(&mut primary, &previous_prepared).await;
        primary
            .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, None)
            .await;
        primary
            .replace_system_context_projection(DOMAIN_CATALOG_PROJECTION, None)
            .await;
        crate::runtime::configure_intent_router(&mut primary);
        release_plugin_mcp_name_claims(&mut ownership_guard, &owned_claims);
        drop(ownership_guard);

        *self.project_root.write().await = binding.to_path_buf();

        state.registry = self.registry_for(binding.to_path_buf());
        state.active_theme = None;
        state.active_output_style = None;
        match state.generation.checked_add(1) {
            Some(revision) => {
                let generation = AgentPluginGeneration::new(
                    revision,
                    primary.skill_descriptors(),
                    state.prepared.agents.clone(),
                    None,
                );
                if let Some(publication) = pool_publication.as_mut() {
                    match publication.prepare(generation).await {
                        Ok(()) => match publication.commit().await {
                            Ok(()) => state.generation = revision,
                            Err(error) => errors.push(format!(
                                "Failed to commit fail-closed AgentPool generation: {error}"
                            )),
                        },
                        Err(error) => errors.push(format!(
                            "Failed to prepare fail-closed AgentPool generation: {error}"
                        )),
                    }
                } else {
                    state.generation = revision;
                }
            }
            None => errors.push("plugin generation revision exhausted".to_string()),
        }
        if let Err(error) = persist_preferences(
            &self.preferences_file,
            &PluginPreferences {
                active_theme: None,
                active_output_style: None,
            },
        ) {
            errors.push(format!(
                "Failed to persist fail-closed plugin preferences: {error}"
            ));
        }
        drop(pool_publication);
        drop(primary);
        errors
    }

    /// Retry every outstanding cleanup receipt exactly once.
    ///
    /// Settlement runs against the ledger in place and a receipt is removed only
    /// after its exact obligation settled. Nothing is moved out of the ledger
    /// before an await, so cancelling the caller mid-retry (a dropped mutation
    /// future, an aborted waiter) cannot drop debt on the stack: the ledger still
    /// holds the receipt and the next retry finds it.
    async fn retry_cleanup_receipts(&self, state: &mut PluginRuntimeState) -> Vec<String> {
        let mut retry_errors = Vec::new();
        // Split the state borrow so settlement can use the lifecycle authority
        // while the receipt stays in the ledger.
        let PluginRuntimeState {
            lifecycle,
            cleanup_receipts,
            ..
        } = state;
        let mut index = 0;
        while let Some(receipt) = cleanup_receipts.get_mut(index) {
            let errors = self.settle_cleanup_receipt(lifecycle, receipt).await;
            receipt.attempts = receipt.attempts.saturating_add(1);
            if errors.is_empty() {
                // The preceding get_mut proves this index exists, and no Vec
                // mutation occurs across the awaited settlement. Only confirmed
                // settlement removes it from the ledger.
                cleanup_receipts.remove(index);
                continue;
            }
            receipt.last_errors = errors
                .iter()
                .map(|error| format!("{}: {error}", receipt.root.display()))
                .collect();
            retry_errors.extend(receipt.last_errors.clone());
            index = index.saturating_add(1);
        }
        retry_errors
    }

    async fn settle_cleanup_receipt(
        &self,
        lifecycle: &mut PluginLifecycleManager,
        receipt: &mut CleanupReceipt,
    ) -> Vec<String> {
        let (authority, settlement) = match &mut receipt.settlement {
            CleanupSettlement::OwnedAuthority { authority, receipt } => {
                (Some(Arc::clone(authority)), &mut receipt.settlement)
            }
            settlement => (None, settlement),
        };
        let mcp_ownership = authority
            .as_ref()
            .map_or(&self.mcp_ownership, |authority| &authority.mcp_ownership);
        match settlement {
            CleanupSettlement::OwnedAuthority { .. } => {
                // Exports are idempotent: a bound receipt may never be rebound
                // or wrapped in a new runtime's authorities.
                vec!["nested plugin cleanup authority receipt is invalid".to_string()]
            }
            CleanupSettlement::McpNames { claims } => {
                let mut guard = mcp_ownership.lock().await;
                release_plugin_mcp_name_claims(&mut guard, claims);
                Vec::new()
            }
            CleanupSettlement::Framework { wiring, claims } => {
                let agent_handle = authority
                    .as_ref()
                    .map_or(&self.agent_handle, |authority| &authority.agent_handle);
                match self
                    .rollback_framework_wiring(agent_handle, wiring.as_ref())
                    .await
                {
                    Some(error) => vec![format!("framework plugin withdrawal failed: {error}")],
                    None => {
                        // Only after the wiring is gone may the exact tokens be
                        // released; otherwise a new owner could claim a name whose
                        // old client is still connected.
                        let mut guard = mcp_ownership.lock().await;
                        release_plugin_mcp_name_claims(&mut guard, claims);
                        Vec::new()
                    }
                }
            }
            CleanupSettlement::LiveLifecycle { plugin_ids } => {
                if authority.is_some() {
                    return vec![
                        "exported plugin cleanup lost its original lifecycle manager".to_string(),
                    ];
                }
                let mut errors = Vec::new();
                let mut remaining = Vec::new();
                for plugin_id in plugin_ids.drain(..) {
                    if let Err(error) = lifecycle.unregister(&plugin_id) {
                        errors.push(error);
                        remaining.push(plugin_id);
                    }
                }
                *plugin_ids = remaining;
                errors
            }
            CleanupSettlement::OwnedLifecycle { manager } => {
                let mut manager = Arc::clone(manager).lock_owned().await;
                manager.shutdown()
            }
            CleanupSettlement::LifecycleShutdown => {
                if authority.is_some() {
                    return vec![
                        "exported plugin cleanup lost its original lifecycle manager".to_string(),
                    ];
                }
                lifecycle.shutdown()
            }
            CleanupSettlement::Monitors { tasks } => {
                let scheduler = match authority.as_ref() {
                    Some(authority) => authority.scheduler.clone(),
                    None => self.scheduler.read().await.clone(),
                };
                let Some(scheduler) = scheduler else {
                    return vec![format!(
                        "Scheduler unavailable while retrying {} plugin monitor cleanup receipt(s)",
                        tasks.len()
                    )];
                };
                // Withdraw against a snapshot and narrow the receipt only after the
                // whole loop finished. Cancelling mid-loop therefore leaves the
                // receipt listing every monitor, and a retry re-attempts them (the
                // removal is exact and idempotent).
                let snapshot = tasks.clone();
                let mut errors = Vec::new();
                let mut remaining = Vec::new();
                for task in snapshot {
                    if let Err(error) = scheduler.remove_task_exact(&task.id).await {
                        errors.push(format!(
                            "Failed to remove plugin monitor '{}': {error}",
                            task.name
                        ));
                        remaining.push(task);
                    }
                }
                *tasks = remaining;
                errors
            }
            CleanupSettlement::PluginUninstall {
                plugin_id,
                keep_data,
            } => {
                let source = authority
                    .as_ref()
                    .map_or(&self.registry_source, |authority| {
                        &authority.registry_source
                    });
                let mut registry = Self::registry_for_source(source, receipt.root.clone());
                if let Err(error) = Self::scan_registry_source(source, &mut registry) {
                    return vec![error.to_string()];
                }
                if registry.get(plugin_id).is_none() {
                    // Already removed, or removed by another owner: nothing left.
                    return Vec::new();
                }
                match registry.uninstall(plugin_id, *keep_data) {
                    Ok(()) => Vec::new(),
                    Err(error) => vec![format!("Uninstall plugin '{plugin_id}' failed: {error}")],
                }
            }
        }
    }

    /// Withdraw exactly one framework wiring receipt from the primary Agent.
    async fn rollback_framework_wiring(
        &self,
        agent_handle: &AgentHandle,
        wiring: &PluginWiringResult,
    ) -> Option<String> {
        let integrator = self.integrator.clone();
        let wiring = wiring.clone();
        agent_handle
            .write_async(|agent| {
                Box::pin(async move {
                    integrator
                        .rollback(agent, &wiring)
                        .await
                        .err()
                        .map(|error| error.to_string())
                })
            })
            .await
    }

    /// Refuse to report success while a receipt is still outstanding.
    async fn settle_pending_receipts(
        &self,
        state: &mut PluginRuntimeState,
        operation: &str,
    ) -> anyhow::Result<()> {
        let errors = self.retry_cleanup_receipts(state).await;
        if errors.is_empty() {
            Ok(())
        } else {
            Err(anyhow::anyhow!(
                "{operation} cannot report success while plugin cleanup receipts remain unsettled: {}",
                errors.join("; ")
            ))
        }
    }

    fn outstanding_receipt_error(
        state: &PluginRuntimeState,
        operation: &str,
    ) -> Option<anyhow::Error> {
        if state.cleanup_receipts.is_empty() {
            return None;
        }
        let receipts = state
            .cleanup_receipts
            .iter()
            .map(CleanupReceipt::describe)
            .collect::<Vec<_>>();
        Some(anyhow::anyhow!(
            "{operation} cannot report success while plugin cleanup receipts remain unsettled: {}",
            receipts.join("; ")
        ))
    }

    /// Snapshot of the cleanup receipts that still block a success report.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) async fn cleanup_receipts(&self) -> Vec<CleanupReceipt> {
        self.state.lock().await.cleanup_receipts.clone()
    }

    /// Adopt receipts exported by a failed bootstrap (or an earlier runtime) and
    /// retry them against this runtime. Outstanding receipts stay in the ledger
    /// so the next mutation retries them again; the error reports what remains.
    ///
    /// This is the S2 seam the application bootstrap switch (T3) uses; until
    /// that call site lands it has no production caller.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) async fn adopt_cleanup_receipts(
        self: &Arc<Self>,
        receipts: Vec<CleanupReceipt>,
    ) -> anyhow::Result<()> {
        self.run_owned_mutation(move |service| async move {
            let mut state = service.state.lock().await;
            state.cleanup_receipts.extend(receipts);
            service
                .settle_pending_receipts(&mut state, "adopting plugin cleanup receipts")
                .await
        })
        .await
    }

    /// Roots with plugin-owned external cleanup that has not yet settled.
    pub async fn cleanup_debt_roots(&self) -> Vec<PathBuf> {
        let mut roots = self
            .state
            .lock()
            .await
            .cleanup_receipts
            .iter()
            .map(|receipt| receipt.root().to_path_buf())
            .collect::<Vec<_>>();
        roots.sort();
        roots.dedup();
        roots
    }

    pub async fn workspace_root(&self) -> PathBuf {
        self.project_root.read().await.clone()
    }

    /// Opaque identity of the prepared framework generation currently exposed
    /// by this target.
    pub(crate) async fn prepared_generation_identity(&self) -> String {
        let state = self.state.lock().await;
        state
            .framework_generation
            .as_ref()
            .map(|generation| generation.identity().to_string())
            .unwrap_or_else(|| format!("unprepared:{}", state.generation))
    }

    pub(crate) async fn mcp_reconcile_target(
        &self,
    ) -> crate::mcp_config_runtime::McpReconcileTarget {
        let pool = self
            .agent_pool
            .read()
            .await
            .as_ref()
            .and_then(Weak::upgrade);
        crate::mcp_config_runtime::McpReconcileTarget::new(
            self.agent_handle.clone(),
            Arc::clone(&self.mcp_ownership),
            pool,
        )
    }

    pub async fn bind_scheduler(
        self: &Arc<Self>,
        scheduler: Arc<SchedulerRunner>,
    ) -> anyhow::Result<usize> {
        self.run_owned_mutation(move |service| async move {
            service.bind_scheduler_inner(scheduler).await
        })
        .await
    }

    async fn bind_scheduler_inner(&self, scheduler: Arc<SchedulerRunner>) -> anyhow::Result<usize> {
        let mut state = self.state.lock().await;
        if state.shut_down {
            return Err(anyhow::anyhow!("plugin runtime is shut down"));
        }
        let monitors = state.prepared.monitors.clone();
        {
            let mut slot = self.scheduler.write().await;
            if slot.is_none() {
                replace_plugin_monitors(&scheduler, &[], &monitors).await?;
                *slot = Some(scheduler);
            }
        }
        // Monitor receipts can only settle once the scheduler is bound, so the
        // retry runs after binding.
        self.settle_pending_receipts(&mut state, "plugin scheduler binding")
            .await?;
        Ok(monitors.len())
    }

    /// Release all plugin-owned resources. Repeated calls are harmless.
    pub async fn shutdown(self: &Arc<Self>) -> anyhow::Result<()> {
        let (result_sender, result_receiver) = tokio::sync::oneshot::channel();
        let mut supervisor = self.mutation_supervisor.lock().await;
        // Admission closes and ownership transfers without an intervening
        // await. Cancelling this observer cannot drop either pending mutations
        // or resources taken from state during withdrawal. A subsequent shutdown
        // drains this owner before attempting another cleanup pass.
        supervisor.accepting = false;
        let pending = std::mem::take(&mut supervisor.settlements);
        let service = Arc::clone(self);
        supervisor.settlements.spawn(async move {
            let result = tokio::spawn(async move {
                let settlement_error = Self::drain_owned_mutations(pending).await.err();
                service.shutdown_inner(settlement_error).await
            })
            .await
            .map_err(|error| anyhow::anyhow!("plugin shutdown settlement task failed: {error}"))
            .and_then(std::convert::identity);
            let _ = result_sender.send(result);
        });
        drop(supervisor);
        result_receiver
            .await
            .map_err(|_| anyhow::anyhow!("plugin shutdown settlement owner stopped unexpectedly"))?
    }

    async fn shutdown_inner(&self, settlement_error: Option<anyhow::Error>) -> anyhow::Result<()> {
        let mut state = self.state.lock().await;
        let mut errors = self.retry_cleanup_receipts(&mut state).await;
        if state.shut_down {
            errors.extend(state.lifecycle.shutdown());
            errors.extend(settlement_error.map(|error| error.to_string()));
            if let Some(error) = Self::outstanding_receipt_error(&state, "plugin runtime shutdown")
            {
                errors.push(error.to_string());
            }
            return if errors.is_empty() {
                Ok(())
            } else {
                Err(anyhow::anyhow!(
                    "Plugin runtime shutdown retry failed: {}",
                    errors.join("; ")
                ))
            };
        }

        let lifecycle_errors = state.lifecycle.shutdown();
        if !lifecycle_errors.is_empty() {
            errors.extend(lifecycle_errors);
            state
                .cleanup_receipts
                .push(CleanupReceipt::lifecycle_shutdown(
                    self.project_root.read().await.clone(),
                    "plugin runtime shutdown could not settle lifecycle callbacks".to_string(),
                ));
        }
        errors.extend(settlement_error.map(|error| error.to_string()));
        state.framework_components.clear();
        state.framework_generation.take();
        let previous_framework_receipt = state.framework_receipt.take();
        let previous_mcp_ownership = std::mem::take(&mut state.mcp_ownership);
        let mut owned_claims = claims_from_ownership(&previous_mcp_ownership);
        let previous_prepared = std::mem::take(&mut state.prepared);
        if !previous_prepared.monitors.is_empty()
            && let Some(scheduler) = self.scheduler.read().await.clone()
        {
            let monitor_errors =
                remove_plugin_monitors_best_effort(&scheduler, &previous_prepared.monitors).await;
            if !monitor_errors.is_empty() {
                let root = self.project_root.read().await.clone();
                state.cleanup_receipts.push(CleanupReceipt::monitors(
                    root,
                    "plugin runtime shutdown could not remove plugin monitors".to_string(),
                    previous_prepared.monitors.clone(),
                ));
                errors.extend(monitor_errors);
            }
        }

        let mut ownership_guard = self.mcp_ownership.lock().await;
        let integrator = self.integrator.clone();
        let rollback_receipt = previous_framework_receipt.clone();
        let rollback_error = self
            .agent_handle
            .write_async(|agent| {
                Box::pin(async move {
                    let rollback_error = match rollback_receipt.as_ref() {
                        Some(receipt) => integrator
                            .rollback(agent, receipt)
                            .await
                            .err()
                            .map(|error| error.to_string()),
                        None => None,
                    };
                    unload_application_components(agent, &previous_prepared).await;
                    agent
                        .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, None)
                        .await;
                    rollback_error
                })
            })
            .await;
        match (rollback_error, previous_framework_receipt) {
            (Some(error), Some(receipt)) => {
                errors.push(format!(
                    "framework plugin rollback failed during unload: {error}"
                ));
                // Keep the exact wiring receipt and its ownership tokens: a
                // retry must withdraw the components before releasing the names.
                let root = self.project_root.read().await.clone();
                state.cleanup_receipts.push(CleanupReceipt::framework(
                    root,
                    "plugin runtime shutdown could not withdraw plugin components".to_string(),
                    receipt,
                    std::mem::take(&mut owned_claims),
                ));
            }
            _ => release_plugin_mcp_name_claims(&mut ownership_guard, &owned_claims),
        }
        drop(ownership_guard);

        let project_root = self.project_root.read().await.clone();
        state.registry = self.registry_for(project_root);
        state.active_theme = None;
        state.active_output_style = None;

        if let Some(error) = Self::outstanding_receipt_error(&state, "plugin runtime shutdown") {
            errors.push(error.to_string());
        }
        if errors.is_empty() {
            state.shut_down = true;
            Ok(())
        } else {
            // Mutation admission is already closed by drain_owned_mutations,
            // but keep the runtime unsettled so a later shutdown retries the
            // retained lifecycle/monitor/ownership cleanup receipts.
            state.shut_down = false;
            Err(anyhow::anyhow!(
                "Plugin runtime shutdown failed: {}",
                errors.join("; ")
            ))
        }
    }

    pub(crate) async fn enable(self: &Arc<Self>, name: &str) -> anyhow::Result<ReloadSummary> {
        let name = name.to_string();
        self.run_owned_mutation(move |service| async move { service.enable_inner(&name).await })
            .await
    }

    async fn enable_inner(&self, name: &str) -> anyhow::Result<ReloadSummary> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin enable")
            .await?;
        let binding = self.project_root.read().await.clone();
        let mut candidate = self.registry_for(binding.to_path_buf());
        self.scan_registry(&mut candidate)?;
        let previously_enabled = candidate
            .get(name)
            .ok_or_else(|| anyhow::anyhow!("Plugin '{name}' not found"))?
            .enabled;
        candidate
            .enable(name)
            .map_err(|error| anyhow::anyhow!("Enable plugin '{name}' failed: {error}"))?;
        match self.apply_candidate(&mut state, candidate, &binding).await {
            Ok(summary) => Ok(summary),
            Err(error) => {
                self.restore_enabled_state(name, previously_enabled).await;
                Err(error)
            }
        }
    }

    pub(crate) async fn disable(self: &Arc<Self>, name: &str) -> anyhow::Result<ReloadSummary> {
        let name = name.to_string();
        self.run_owned_mutation(move |service| async move { service.disable_inner(&name).await })
            .await
    }

    async fn disable_inner(&self, name: &str) -> anyhow::Result<ReloadSummary> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin disable")
            .await?;
        let binding = self.project_root.read().await.clone();
        let mut candidate = self.registry_for(binding.to_path_buf());
        self.scan_registry(&mut candidate)?;
        let previously_enabled = candidate
            .get(name)
            .ok_or_else(|| anyhow::anyhow!("Plugin '{name}' not found"))?
            .enabled;
        candidate
            .disable(name)
            .map_err(|error| anyhow::anyhow!("Disable plugin '{name}' failed: {error}"))?;
        match self.apply_candidate(&mut state, candidate, &binding).await {
            Ok(summary) => {
                self.fire_plugin_disabled(name).await;
                Ok(summary)
            }
            Err(error) => {
                self.restore_enabled_state(name, previously_enabled).await;
                Err(error)
            }
        }
    }

    pub(crate) async fn install(
        self: &Arc<Self>,
        source: &InstallSource,
        scope: PluginScope,
    ) -> anyhow::Result<(String, ReloadSummary)> {
        let source = source.clone();
        self.run_owned_mutation(move |service| async move {
            service.install_inner(&source, scope).await
        })
        .await
    }

    async fn install_inner(
        &self,
        source: &InstallSource,
        scope: PluginScope,
    ) -> anyhow::Result<(String, ReloadSummary)> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin install")
            .await?;
        let binding = self.project_root.read().await.clone();
        let mut candidate = self.registry_for(binding.to_path_buf());
        self.scan_registry(&mut candidate)?;
        let plugin_id = candidate
            .install(source, scope)
            .map_err(|error| anyhow::anyhow!("Install plugin failed: {error}"))?;
        match self.apply_candidate(&mut state, candidate, &binding).await {
            Ok(summary) => Ok((plugin_id, summary)),
            Err(error) => {
                if let Some(rollback_error) = self.rollback_install(&plugin_id).await {
                    // A partially installed entry is itself a retryable cleanup
                    // obligation: a failed install must not leave an untracked
                    // plugin directory or registry entry behind.
                    state
                        .cleanup_receipts
                        .push(CleanupReceipt::plugin_uninstall(
                            binding.to_path_buf(),
                            format!("install rollback failed: {rollback_error}"),
                            plugin_id.clone(),
                            false,
                        ));
                    return Err(anyhow::anyhow!(append_errors(
                        error.to_string(),
                        vec![format!(
                            "plugin install rollback failed and was retained as a cleanup receipt: {rollback_error}"
                        )],
                    )));
                }
                Err(error)
            }
        }
    }

    pub(crate) async fn uninstall(
        self: &Arc<Self>,
        name: &str,
        keep_data: bool,
    ) -> anyhow::Result<ReloadSummary> {
        let name = name.to_string();
        self.run_owned_mutation(move |service| async move {
            service.uninstall_inner(&name, keep_data).await
        })
        .await
    }

    async fn uninstall_inner(&self, name: &str, keep_data: bool) -> anyhow::Result<ReloadSummary> {
        let root = self.project_root().await;
        {
            let mut state = self.state.lock().await;
            self.settle_pending_receipts(&mut state, "plugin uninstall")
                .await?;
        }
        let was_enabled = self
            .get(name)
            .await
            .ok_or_else(|| anyhow::anyhow!("Plugin '{name}' not found"))?
            .enabled;
        let mut summary = if was_enabled {
            self.disable_inner(name).await?
        } else {
            let state = self.state.lock().await;
            ReloadSummary {
                total: state.registry.count(),
                enabled: state.registry.list_enabled().len(),
                skills_loaded: state
                    .framework_components
                    .values()
                    .map(|components| components.skills.len())
                    .sum(),
                hooks_registered: state
                    .framework_components
                    .values()
                    .filter(|components| components.hooks_registered)
                    .count(),
                mcp_connected: state
                    .framework_components
                    .values()
                    .map(|components| components.mcp_servers.len())
                    .sum(),
                agents_loaded: state.prepared.agents.len(),
                monitors_loaded: state.prepared.monitors.len(),
                themes_loaded: state.prepared.themes.len(),
                output_styles_loaded: state.prepared.output_styles.len(),
                errors: Vec::new(),
            }
        };
        let mut state = self.state.lock().await;
        if let Err(error) = state.registry.uninstall(name, keep_data) {
            // The entry (or its staged directory) may still exist: retain a
            // retryable uninstall receipt instead of dropping the obligation.
            state
                .cleanup_receipts
                .push(CleanupReceipt::plugin_uninstall(
                    root,
                    format!("plugin uninstall failed: {error}"),
                    name.to_string(),
                    keep_data,
                ));
            return Err(anyhow::anyhow!(
                "Uninstall plugin '{name}' failed and was retained as a cleanup receipt: {error}"
            ));
        }
        let lifecycle_error = state.lifecycle.unregister(name).err();
        if let Some(error) = lifecycle_error.as_ref() {
            state.cleanup_receipts.push(CleanupReceipt::live_lifecycle(
                root,
                format!("plugin uninstall could not release lifecycle callbacks: {error}"),
                vec![name.to_string()],
            ));
        }
        summary.total = state.registry.count();
        summary.enabled = state.registry.list_enabled().len();
        if !was_enabled {
            self.fire_plugin_disabled(name).await;
        }
        match lifecycle_error {
            Some(error) => Err(anyhow::anyhow!(error)),
            None => match Self::outstanding_receipt_error(&state, "plugin uninstall") {
                Some(error) => Err(error),
                None => Ok(summary),
            },
        }
    }

    pub async fn list(&self) -> Vec<PluginEntry> {
        self.state
            .lock()
            .await
            .registry
            .list()
            .into_iter()
            .cloned()
            .collect()
    }

    #[cfg(test)]
    pub(crate) async fn generation_for_test(&self) -> u64 {
        self.state.lock().await.generation
    }

    pub async fn get(&self, name: &str) -> Option<PluginEntry> {
        self.state.lock().await.registry.get(name).cloned()
    }

    pub(crate) async fn configure(
        self: &Arc<Self>,
        name: &str,
        values: HashMap<String, serde_json::Value>,
    ) -> anyhow::Result<ReloadSummary> {
        let name = name.to_string();
        self.run_owned_mutation(move |service| async move {
            service.configure_inner(&name, values).await
        })
        .await
    }

    async fn configure_inner(
        &self,
        name: &str,
        values: HashMap<String, serde_json::Value>,
    ) -> anyhow::Result<ReloadSummary> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin configure")
            .await?;
        let binding = self.project_root.read().await.clone();
        let mut candidate = self.registry_for(binding.to_path_buf());
        self.scan_registry(&mut candidate)?;
        let previous = candidate
            .get(name)
            .ok_or_else(|| anyhow::anyhow!("Plugin '{name}' not found"))?
            .user_config
            .clone();
        candidate
            .configure(name, values)
            .map_err(|error| anyhow::anyhow!("Configure plugin '{name}' failed: {error}"))?;
        match self.apply_candidate(&mut state, candidate, &binding).await {
            Ok(summary) => Ok(summary),
            Err(error) => {
                self.restore_plugin_config(name, previous).await;
                Err(error)
            }
        }
    }

    /// Register native lifecycle callbacks and synchronize them immediately.
    pub async fn register_lifecycle(
        self: &Arc<Self>,
        name: &str,
        callbacks: Arc<dyn PluginLifecycle>,
    ) -> anyhow::Result<()> {
        let name = name.to_string();
        self.run_owned_mutation(move |service| async move {
            service.register_lifecycle_inner(&name, callbacks).await
        })
        .await
    }

    async fn register_lifecycle_inner(
        &self,
        name: &str,
        callbacks: Arc<dyn PluginLifecycle>,
    ) -> anyhow::Result<()> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin lifecycle registration")
            .await?;
        let enabled = state
            .registry
            .get(name)
            .ok_or_else(|| anyhow::anyhow!("Plugin '{name}' not found"))?
            .enabled;
        state
            .lifecycle
            .register(name, callbacks)
            .map_err(anyhow::Error::msg)?;
        if enabled && let Err(error) = state.lifecycle.activate(name) {
            match state.lifecycle.unregister(name) {
                Ok(_) => return Err(anyhow::anyhow!(error)),
                Err(cleanup_error) => {
                    // The callback may still own external resources, so keep a
                    // retryable receipt for its exact registration.
                    state.cleanup_receipts.push(CleanupReceipt::live_lifecycle(
                        self.project_root().await,
                        format!("lifecycle registration rollback failed: {cleanup_error}"),
                        vec![name.to_string()],
                    ));
                    return Err(anyhow::anyhow!(append_errors(error, vec![cleanup_error],)));
                }
            }
        }
        Ok(())
    }

    pub async fn themes(&self) -> Vec<PluginThemeDefinition> {
        self.state.lock().await.prepared.themes.clone()
    }

    pub async fn active_theme(&self) -> Option<String> {
        self.state.lock().await.active_theme.clone()
    }

    pub(crate) async fn activate_theme(
        self: &Arc<Self>,
        name: Option<&str>,
    ) -> anyhow::Result<Option<PluginThemeDefinition>> {
        let name = name.map(str::to_string);
        self.run_owned_mutation(move |service| async move {
            service.activate_theme_inner(name.as_deref()).await
        })
        .await
    }

    async fn activate_theme_inner(
        &self,
        name: Option<&str>,
    ) -> anyhow::Result<Option<PluginThemeDefinition>> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin theme activation")
            .await?;
        let theme = match name {
            Some(name) => Some(
                state
                    .prepared
                    .themes
                    .iter()
                    .find(|theme| theme.name == name)
                    .ok_or_else(|| anyhow::anyhow!("Theme '{name}' not found"))?
                    .clone(),
            ),
            None => None,
        };
        let selected = name.map(str::to_string);
        persist_preferences(
            &self.preferences_file,
            &PluginPreferences {
                active_theme: selected.clone(),
                active_output_style: state.active_output_style.clone(),
            },
        )?;
        state.active_theme = selected;
        Ok(theme)
    }

    pub async fn output_styles(&self) -> Vec<PluginOutputStyle> {
        self.state.lock().await.prepared.output_styles.clone()
    }

    pub async fn active_output_style(&self) -> Option<String> {
        self.state.lock().await.active_output_style.clone()
    }

    pub(crate) async fn activate_output_style(
        self: &Arc<Self>,
        name: Option<&str>,
    ) -> anyhow::Result<()> {
        let name = name.map(str::to_string);
        self.run_owned_mutation(move |service| async move {
            service.activate_output_style_inner(name.as_deref()).await
        })
        .await
    }

    async fn activate_output_style_inner(&self, name: Option<&str>) -> anyhow::Result<()> {
        let mut state = self.state.lock().await;
        self.settle_pending_receipts(&mut state, "plugin output-style activation")
            .await?;
        let instructions = match name {
            Some(name) => Some(
                state
                    .prepared
                    .output_styles
                    .iter()
                    .find(|style| style.name == name)
                    .ok_or_else(|| anyhow::anyhow!("Output style '{name}' not found"))?
                    .instructions
                    .clone(),
            ),
            None => None,
        };
        let selected = name.map(str::to_string);
        let previous_selected = state.active_output_style.clone();
        let previous = active_output_style_instructions(&state);
        let revision = state
            .generation
            .checked_add(1)
            .ok_or_else(|| anyhow::anyhow!("plugin generation revision exhausted"))?;
        let primary_execution = self
            .agent_handle
            .read(|agent| Arc::clone(agent.execution_mutex()))
            .await;
        let _primary_execution_guard = primary_execution.lock_owned().await;
        let primary_owner = Arc::clone(self.agent_handle.inner());
        let primary = primary_owner.write_owned().await;
        let pool = self
            .agent_pool
            .read()
            .await
            .as_ref()
            .and_then(Weak::upgrade);
        let mut pool_publication = if let Some(pool) = pool.as_ref() {
            Some(
                pool.begin_plugin_publication()
                    .await
                    .map_err(anyhow::Error::msg)?,
            )
        } else {
            None
        };
        primary
            .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, instructions.clone())
            .await;
        let generation = AgentPluginGeneration::new(
            revision,
            primary.skill_descriptors(),
            state.prepared.agents.clone(),
            instructions,
        )
        .with_domain_components(state.prepared.domains.clone(), selected.clone())
        .with_framework_generation(state.framework_generation.clone());
        if let Some(publication) = pool_publication.as_mut()
            && let Err(error) = publication.prepare(generation).await
        {
            primary
                .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, previous.clone())
                .await;
            return Err(anyhow::Error::msg(error));
        }
        if let Err(error) = persist_preferences(
            &self.preferences_file,
            &PluginPreferences {
                active_theme: state.active_theme.clone(),
                active_output_style: selected.clone(),
            },
        ) {
            primary
                .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, previous.clone())
                .await;
            let rollback = match pool_publication.as_mut() {
                Some(publication) => publication.rollback().await.err(),
                None => None,
            };
            return Err(match rollback {
                Some(rollback) => anyhow::anyhow!(
                    "Output-style persistence failed: {error}; pool rollback failed: {rollback}"
                ),
                None => error,
            });
        }
        if let Some(publication) = pool_publication.as_mut()
            && let Err(error) = publication.commit().await
        {
            primary
                .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, previous)
                .await;
            let rollback = publication.rollback().await.err();
            let preference_rollback = persist_preferences(
                &self.preferences_file,
                &PluginPreferences {
                    active_theme: state.active_theme.clone(),
                    active_output_style: previous_selected,
                },
            )
            .err();
            let mut errors = vec![format!("Output-style pool commit failed: {error}")];
            errors.extend(rollback.map(|error| format!("pool rollback failed: {error}")));
            errors.extend(
                preference_rollback.map(|error| format!("preference rollback failed: {error}")),
            );
            return Err(anyhow::anyhow!(errors.join("; ")));
        }
        state.generation = revision;
        state.active_output_style = selected;
        Ok(())
    }

    pub fn scaffold(
        directory: impl AsRef<Path>,
        name: &str,
    ) -> anyhow::Result<PluginScaffoldResult> {
        let directory = directory.as_ref();
        let name = name.trim();
        validate_plugin_name(name)?;
        if directory.exists() {
            return Err(anyhow::anyhow!(
                "Plugin scaffold target already exists: {}",
                directory.display()
            ));
        }

        std::fs::create_dir_all(directory).map_err(|error| {
            anyhow::anyhow!(
                "Failed to create plugin directory '{}': {error}",
                directory.display()
            )
        })?;
        let result = write_scaffold(directory, name);
        if let Err(error) = result {
            let cleanup = std::fs::remove_dir_all(directory).err();
            return Err(match cleanup {
                Some(cleanup) => anyhow::anyhow!(
                    "{error}; failed to roll back scaffold '{}': {cleanup}",
                    directory.display()
                ),
                None => error,
            });
        }
        Ok(PluginScaffoldResult {
            path: directory.to_path_buf(),
            name: name.to_string(),
        })
    }

    pub fn validate(directory: impl AsRef<Path>) -> PluginValidationReport {
        let directory = directory.as_ref();
        match PluginRegistry::validate_plugin_dir(directory) {
            Ok((manifest, resolved)) => {
                let defaults = manifest
                    .config
                    .iter()
                    .filter_map(|(name, entry)| {
                        entry.default.clone().map(|value| (name.clone(), value))
                    })
                    .collect::<HashMap<_, _>>();
                let project_dir =
                    std::env::current_dir().unwrap_or_else(|_| directory.to_path_buf());
                let variables = echo_agent::plugin::PluginVariables::new(
                    directory.to_path_buf(),
                    std::env::temp_dir(),
                    project_dir,
                )
                .with_json_user_config(&defaults);
                let mut errors = validate_application_component_files(
                    &manifest.name,
                    directory,
                    &resolved,
                    &variables,
                );
                let components = component_names(directory, &resolved);
                let valid = errors.is_empty();
                if std::fs::symlink_metadata(directory.join("lsp.yaml")).is_ok() {
                    errors.push("LSP component has been retired from EKO; no language server will be loaded; retained components were validated independently".to_string());
                }
                PluginValidationReport {
                    valid,
                    name: Some(manifest.name),
                    components,
                    errors,
                }
            }
            Err(errors) => PluginValidationReport {
                valid: false,
                name: None,
                components: Vec::new(),
                errors,
            },
        }
    }

    async fn apply_candidate(
        &self,
        state: &mut PluginRuntimeState,
        mut candidate: PluginRegistry,
        binding: &Path,
    ) -> anyhow::Result<ReloadSummary> {
        if state.shut_down {
            return Err(anyhow::anyhow!("plugin runtime is shut down"));
        }
        let candidate_revision = state
            .generation
            .checked_add(1)
            .ok_or_else(|| anyhow::anyhow!("plugin generation revision exhausted"))?;
        let framework_generation =
            require_applicable_generation(self.integrator.prepare(&mut candidate).await)?;
        let candidate_plugins = candidate
            .list_enabled()
            .into_iter()
            .map(|entry| entry.manifest.name.clone())
            .collect::<Vec<_>>();
        let previous_plugins = state
            .registry
            .list_enabled()
            .into_iter()
            .map(|entry| entry.manifest.name.clone())
            .collect::<Vec<_>>();
        let prepared =
            prepare_application_components(&framework_generation, &self.target_scope, &candidate)
                .map_err(|errors| anyhow::anyhow!(errors.join("; ")))?;
        let candidate_mcp_declarations = plugin_mcp_declarations(&framework_generation)?;
        self.validate_agent_collisions(state, &prepared).await?;

        // Publication lock order: primary execution, primary agent write,
        // then pool transition/agents. No primary or pooled turn can observe
        // a half-published skill/Subagent/router catalog.
        let primary_execution = self
            .agent_handle
            .read(|agent| Arc::clone(agent.execution_mutex()))
            .await;
        let _primary_execution_guard = primary_execution.lock_owned().await;
        let primary_owner = Arc::clone(self.agent_handle.inner());
        let mut primary = primary_owner.write_owned().await;
        let pool = self
            .agent_pool
            .read()
            .await
            .as_ref()
            .and_then(Weak::upgrade);
        let mut pool_publication = if let Some(pool) = pool.as_ref() {
            match pool.begin_plugin_publication().await {
                Ok(publication) => Some(publication),
                Err(error) => {
                    return Err(anyhow::anyhow!(
                        "Failed to close AgentPool plugin publication admission: {error}"
                    ));
                }
            }
        } else {
            None
        };

        let deactivate_errors = state.lifecycle.deactivate_all();
        if !deactivate_errors.is_empty() {
            let mut errors = deactivate_errors;
            errors.extend(
                state
                    .lifecycle
                    .activate_enabled(previous_plugins.iter().map(String::as_str)),
            );

            return Err(anyhow::anyhow!(
                "Plugin lifecycle deactivation failed: {}",
                errors.join("; ")
            ));
        }

        let scheduler = self.scheduler.read().await.clone();
        if let Some(scheduler) = scheduler.as_ref()
            && let Err(error) =
                replace_plugin_monitors(scheduler, &state.prepared.monitors, &prepared.monitors)
                    .await
        {
            let mut errors = vec![error.to_string()];
            errors.extend(
                state
                    .lifecycle
                    .activate_enabled(previous_plugins.iter().map(String::as_str)),
            );
            return Err(anyhow::anyhow!(errors.join("; ")));
        }

        let previous_registry = std::mem::replace(
            &mut state.registry,
            self.registry_for(binding.to_path_buf()),
        );
        let previous_framework = std::mem::take(&mut state.framework_components);
        let previous_framework_generation = state.framework_generation.take();
        let previous_framework_receipt = state.framework_receipt.take();
        let previous_mcp_ownership = std::mem::take(&mut state.mcp_ownership);
        let previous_prepared = std::mem::take(&mut state.prepared);
        let apply = self
            .replace_agent_components(
                &mut primary,
                previous_registry,
                previous_framework,
                previous_framework_generation,
                previous_framework_receipt,
                previous_mcp_ownership,
                previous_prepared,
                candidate,
                Some(framework_generation),
                candidate_mcp_declarations,
                prepared,
            )
            .await;

        let applied = match apply {
            Ok(applied) => applied,
            Err(mut failed) => {
                let restored_live_generation = failed.framework_generation.is_some();
                state.registry = failed.registry;
                state.framework_components = failed.framework_components;
                state.framework_generation = failed.framework_generation;
                state.framework_receipt = failed.framework_receipt;
                state.mcp_ownership = failed.mcp_ownership;
                state.prepared = failed.prepared;
                if let Some(scheduler) = scheduler.as_ref()
                    && let Err(error) = replace_plugin_monitors(
                        scheduler,
                        &failed.candidate_monitors,
                        &state.prepared.monitors,
                    )
                    .await
                {
                    failed.error =
                        format!("{}; rollback plugin monitors failed: {error}", failed.error);
                }

                if let Some((wiring, claims)) = failed.retained_withdrawal.take() {
                    // A withdrawal did not settle, so no generation can be
                    // described as live any more. The exact wiring receipt and its
                    // tokens move to the ledger, which retries the withdrawal
                    // before it may release a single name, and the rest of the
                    // retired generation is withdrawn fail-closed.
                    state.cleanup_receipts.push(CleanupReceipt::framework(
                        binding.to_path_buf(),
                        format!("plugin generation replacement aborted: {}", failed.error),
                        wiring,
                        claims,
                    ));
                }
                if !restored_live_generation {
                    failed.error =
                        append_errors(failed.error, Self::retire_failed_lifecycles(state, binding));
                    primary
                        .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, None)
                        .await;
                    crate::runtime::configure_intent_router(&mut primary);
                } else {
                    failed.error = append_errors(
                        failed.error,
                        state
                            .lifecycle
                            .activate_enabled(previous_plugins.iter().map(String::as_str)),
                    );
                }
                if !failed.orphaned_claims.is_empty() {
                    // Candidate names that were claimed and then unwound travel as
                    // a receipt; dropping them here would leak the exact tokens.
                    state.cleanup_receipts.push(CleanupReceipt::mcp_names(
                        binding.to_path_buf(),
                        format!("failed plugin generation: {}", failed.error),
                        failed.orphaned_claims,
                    ));
                }
                return Err(anyhow::anyhow!(failed.error));
            }
        };

        let candidate_generation = AgentPluginGeneration::new(
            candidate_revision,
            primary.skill_descriptors(),
            applied.prepared.agents.clone(),
            active_output_style_instructions_for(
                state.active_output_style.as_deref(),
                &applied.prepared,
            ),
        )
        .with_domain_components(
            applied.prepared.domains.clone(),
            state.active_output_style.clone(),
        )
        .with_framework_generation(applied.framework_generation.clone());
        if let Some(publication) = pool_publication.as_mut()
            && let Err(pool_error) = publication.prepare(candidate_generation).await
        {
            let candidate_monitors = applied.prepared.monitors.clone();
            let previous_monitors = applied.previous_prepared.monitors.clone();
            let candidate_framework = applied
                .wiring
                .as_ref()
                .map(|receipt| receipt.components_by_plugin.clone())
                .unwrap_or_default();
            let rollback = self
                .replace_agent_components(
                    &mut primary,
                    applied.registry,
                    candidate_framework,
                    applied.framework_generation,
                    applied.wiring,
                    applied.mcp_ownership,
                    applied.prepared,
                    applied.previous_registry,
                    applied.previous_framework_generation,
                    applied.previous_mcp_declarations,
                    applied.previous_prepared,
                )
                .await;
            let mut errors = vec![format!(
                "AgentPool plugin generation publication failed: {pool_error}"
            )];
            match rollback {
                Ok(restored) => {
                    if let Some(scheduler) = scheduler.as_ref()
                        && let Err(error) = replace_plugin_monitors(
                            scheduler,
                            &candidate_monitors,
                            &previous_monitors,
                        )
                        .await
                    {
                        errors.push(format!("rollback plugin monitors failed: {error}"));
                    }
                    state.registry = restored.registry;
                    state.framework_components = restored
                        .wiring
                        .as_ref()
                        .map(|receipt| receipt.components_by_plugin.clone())
                        .unwrap_or_default();
                    state.framework_generation = restored.framework_generation;
                    state.framework_receipt = restored.wiring;
                    state.mcp_ownership = restored.mcp_ownership;
                    state.prepared = restored.prepared;
                    errors.extend(
                        state
                            .lifecycle
                            .activate_enabled(previous_plugins.iter().map(String::as_str)),
                    );
                }
                Err(mut failed) => {
                    let restored_live_generation = failed.framework_generation.is_some();
                    errors.push(format!(
                        "rollback agent components failed: {}",
                        failed.error
                    ));
                    if let Some((wiring, claims)) = failed.retained_withdrawal.take() {
                        state.cleanup_receipts.push(CleanupReceipt::framework(
                            binding.to_path_buf(),
                            format!(
                                "AgentPool rollback retained plugin withdrawal: {}",
                                failed.error
                            ),
                            wiring,
                            claims,
                        ));
                    }
                    if !failed.orphaned_claims.is_empty() {
                        state.cleanup_receipts.push(CleanupReceipt::mcp_names(
                            binding.to_path_buf(),
                            format!(
                                "AgentPool rollback retained plugin name claims: {}",
                                failed.error
                            ),
                            failed.orphaned_claims,
                        ));
                    }
                    state.registry = failed.registry;
                    state.framework_components = failed.framework_components;
                    state.framework_generation = failed.framework_generation;
                    state.framework_receipt = failed.framework_receipt;
                    state.mcp_ownership = failed.mcp_ownership;
                    state.prepared = failed.prepared;
                    if restored_live_generation {
                        errors.extend(
                            state
                                .lifecycle
                                .activate_enabled(candidate_plugins.iter().map(String::as_str)),
                        );
                    } else {
                        errors.extend(Self::retire_failed_lifecycles(state, binding));
                        primary
                            .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, None)
                            .await;
                        crate::runtime::configure_intent_router(&mut primary);
                    }
                }
            }

            return Err(anyhow::anyhow!(errors.join("; ")));
        }

        let activation_errors = state
            .lifecycle
            .activate_enabled(candidate_plugins.iter().map(String::as_str));
        if !activation_errors.is_empty() {
            let mut errors = vec![format!(
                "Plugin lifecycle activation failed: {}",
                activation_errors.join("; ")
            )];
            errors.extend(state.lifecycle.deactivate_all());
            let shutdown_errors = state.lifecycle.shutdown();
            if !shutdown_errors.is_empty() {
                state
                    .cleanup_receipts
                    .push(CleanupReceipt::lifecycle_shutdown(
                        binding.to_path_buf(),
                        "candidate Plugin generation failed activation".to_string(),
                    ));
                errors.extend(shutdown_errors);
            }
            if let Some(scheduler) = scheduler.as_ref() {
                let monitor_errors =
                    remove_plugin_monitors_best_effort(scheduler, &applied.prepared.monitors).await;
                if !monitor_errors.is_empty() {
                    state.cleanup_receipts.push(CleanupReceipt::monitors(
                        binding.to_path_buf(),
                        "candidate Plugin generation failed activation".to_string(),
                        applied.prepared.monitors.clone(),
                    ));
                    errors.extend(monitor_errors);
                }
            }
            let candidate_claims = claims_from_ownership(&applied.mcp_ownership);
            let mut retained_claims = false;
            if let Some(receipt) = applied.wiring.as_ref() {
                match self.integrator.rollback(&mut primary, receipt).await {
                    Ok(()) => {}
                    Err(error) => {
                        errors.push(format!(
                            "failed to withdraw candidate framework components: {error}"
                        ));
                        // The failed withdrawal still owns its MCP clients: keep
                        // the exact wiring receipt and tokens so a retry can
                        // withdraw before releasing the names.
                        state.cleanup_receipts.push(CleanupReceipt::framework(
                            binding.to_path_buf(),
                            "candidate Plugin generation failed activation".to_string(),
                            receipt.clone(),
                            candidate_claims.clone(),
                        ));
                        retained_claims = true;
                    }
                }
            }
            unload_application_components(&mut primary, &applied.prepared).await;
            primary
                .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, None)
                .await;
            crate::runtime::configure_intent_router(&mut primary);
            if !retained_claims && !candidate_claims.is_empty() {
                state.cleanup_receipts.push(CleanupReceipt::mcp_names(
                    binding.to_path_buf(),
                    "candidate Plugin generation failed activation".to_string(),
                    candidate_claims,
                ));
            }
            let retirement_revision = candidate_revision.checked_add(1).ok_or_else(|| {
                anyhow::anyhow!("Plugin generation revision exhausted during failed activation")
            })?;
            if let Some(publication) = pool_publication.as_mut() {
                let retired = AgentPluginGeneration::new(
                    retirement_revision,
                    primary.skill_descriptors(),
                    Vec::new(),
                    None,
                );
                if let Err(error) = publication.retire_failed_candidate(retired).await {
                    errors.push(error);
                }
            }

            state.registry = self.registry_for(binding.to_path_buf());
            state.framework_components.clear();
            state.framework_generation = None;
            state.framework_receipt = None;
            state.mcp_ownership.clear();
            state.prepared = PreparedApplicationComponents::default();
            state.active_theme = None;
            state.active_output_style = None;
            state.generation = retirement_revision;
            if let Err(error) = persist_preferences(
                &self.preferences_file,
                &PluginPreferences {
                    active_theme: None,
                    active_output_style: None,
                },
            ) {
                errors.push(format!(
                    "failed to persist retired Plugin preferences: {error}"
                ));
            }
            return Err(anyhow::anyhow!(
                "candidate Plugin generation failed activation and was retired: {}",
                errors.join("; ")
            ));
        }

        if let Some(publication) = pool_publication.as_mut()
            && let Err(pool_error) = publication.commit().await
        {
            // Commit is the final publication step. If it fails, the candidate
            // components are still wired on the primary and prepared in pooled
            // Agents, so their exact ownership tokens must survive as a receipt.
            let claims = claims_from_ownership(&applied.mcp_ownership);
            let mut errors = vec![format!(
                "AgentPool plugin generation commit failed: {pool_error}"
            )];
            if let Err(error) = publication.rollback().await {
                errors.push(format!(
                    "AgentPool plugin generation rollback failed: {error}"
                ));
            }
            let cause = "AgentPool plugin generation commit failed".to_string();
            match applied.wiring {
                Some(receipt) => state.cleanup_receipts.push(CleanupReceipt::framework(
                    binding.to_path_buf(),
                    cause,
                    receipt,
                    claims,
                )),
                None => state.cleanup_receipts.push(CleanupReceipt::mcp_names(
                    binding.to_path_buf(),
                    cause,
                    claims,
                )),
            }

            return Err(anyhow::anyhow!(errors.join("; ")));
        }

        *self.project_root.write().await = binding.to_path_buf();

        let active_style = state.active_output_style.clone();
        let active_theme = state.active_theme.clone();
        state.registry = applied.registry;
        state.framework_components = applied
            .wiring
            .as_ref()
            .map(|receipt| receipt.components_by_plugin.clone())
            .unwrap_or_default();
        state.framework_generation = applied.framework_generation;
        state.framework_receipt = applied.wiring;
        state.mcp_ownership = applied.mcp_ownership;
        state.prepared = applied.prepared;
        state.generation = candidate_revision;
        primary
            .replace_system_context_projection(
                DOMAIN_CATALOG_PROJECTION,
                state.prepared.domains.catalog_prompt(),
            )
            .await;
        if let Some(style) = active_style {
            if state
                .prepared
                .output_styles
                .iter()
                .any(|candidate| candidate.name == style)
            {
                let instructions = state
                    .prepared
                    .output_styles
                    .iter()
                    .find(|candidate| candidate.name == style)
                    .map(|candidate| candidate.instructions.clone());
                primary
                    .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, instructions)
                    .await;
            } else {
                state.active_output_style = None;
                primary
                    .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, None)
                    .await;
            }
        }

        if let Some(theme) = active_theme
            && !state
                .prepared
                .themes
                .iter()
                .any(|candidate| candidate.name == theme)
        {
            state.active_theme = None;
        }

        let total = state.registry.count();
        let enabled = state.registry.list_enabled().len();
        let mut summary = ReloadSummary::from_components(
            total,
            enabled,
            state.framework_receipt.as_ref(),
            state.framework_generation.as_deref(),
            &state.prepared,
        );
        if let Err(error) = persist_preferences(
            &self.preferences_file,
            &PluginPreferences {
                active_theme: state.active_theme.clone(),
                active_output_style: state.active_output_style.clone(),
            },
        ) {
            summary.errors.push(error.to_string());
        }
        drop(pool_publication);
        drop(primary);
        self.fire_loaded_events(&candidate_plugins).await;
        tracing::info!(
            total,
            enabled,
            agents = summary.agents_loaded,
            monitors = summary.monitors_loaded,
            themes = summary.themes_loaded,
            output_styles = summary.output_styles_loaded,
            "plugin runtime replaced atomically"
        );
        Ok(summary)
    }

    fn retire_failed_lifecycles(state: &mut PluginRuntimeState, root: &Path) -> Vec<String> {
        let mut lifecycle = std::mem::replace(&mut state.lifecycle, PluginLifecycleManager::new());
        let errors = lifecycle.shutdown();
        if !errors.is_empty() {
            state.cleanup_receipts.push(CleanupReceipt::owned_lifecycle(
                root.to_path_buf(),
                "aborted plugin generation could not shut down plugin lifecycles".to_string(),
                lifecycle,
            ));
        }
        state.active_theme = None;
        state.active_output_style = None;
        errors
    }

    /// A rejected restore is not a live generation. Preserve the framework's
    /// partial withdrawal receipt before formatting the error; if no wiring
    /// survived, the claimed names still need an exact ownership-only retry.
    fn failed_framework_restore(
        context: String,
        error: echo_agent::plugin::PluginWiringError,
        registry: PluginRegistry,
        ownership: PluginMcpOwnership,
        candidate_monitors: Vec<CronTask>,
        mut orphaned_claims: Vec<PluginMcpNameClaim>,
    ) -> FailedAgentComponents {
        let claims = claims_from_ownership(&ownership);
        let retained_withdrawal = match error.cleanup_receipt().cloned() {
            Some(wiring) => Some((wiring, claims)),
            None => {
                orphaned_claims.extend(claims);
                None
            }
        };
        FailedAgentComponents {
            error: format!("{context}; rollback framework wiring failed: {error}"),
            registry,
            framework_components: HashMap::new(),
            framework_generation: None,
            framework_receipt: None,
            mcp_ownership: HashMap::new(),
            prepared: PreparedApplicationComponents::default(),
            candidate_monitors,
            orphaned_claims,
            retained_withdrawal,
        }
    }

    #[allow(clippy::too_many_arguments)]
    #[allow(clippy::result_large_err)]
    async fn replace_agent_components(
        &self,
        agent: &mut echo_agent::agent::ReactAgent,
        previous_registry: PluginRegistry,
        previous_framework: HashMap<String, WiredPluginComponents>,
        previous_framework_generation: Option<Arc<PreparedPluginSet>>,
        previous_framework_receipt: Option<PluginWiringResult>,
        previous_mcp_ownership: PluginMcpOwnership,
        previous_prepared: PreparedApplicationComponents,
        candidate: PluginRegistry,
        candidate_framework_generation: Option<Arc<PreparedPluginSet>>,
        candidate_mcp_declarations: PluginMcpDeclarations,
        candidate_prepared: PreparedApplicationComponents,
    ) -> Result<AppliedAgentComponents, FailedAgentComponents> {
        // This service root is EKO's local workspace data, not the project's
        // remote code cwd. Project I/O comes from the parent Agent resources.
        let local_state_dir = Some(crate::workspace::layout::WorkspaceLayout::state_dir(
            &self.project_root.read().await,
        ));
        let candidate_monitors = candidate_prepared.monitors.clone();
        let previous_mcp_declarations = match previous_framework_generation
            .as_deref()
            .map(plugin_mcp_declarations)
            .transpose()
        {
            Ok(declarations) => declarations.unwrap_or_default(),
            Err(error) => {
                return Err(FailedAgentComponents {
                    error: format!("Failed to inspect prepared plugin MCP receipts: {error}"),
                    registry: previous_registry,
                    framework_components: previous_framework,
                    framework_generation: previous_framework_generation,
                    framework_receipt: previous_framework_receipt,
                    mcp_ownership: previous_mcp_ownership,
                    prepared: previous_prepared,
                    candidate_monitors,
                    orphaned_claims: Vec::new(),
                    retained_withdrawal: None,
                });
            }
        };
        let mut ownership_guard = self.mcp_ownership.lock().await;
        if let Err(error) = validate_plugin_mcp_claims(
            &ownership_guard,
            &candidate_mcp_declarations,
            &previous_mcp_ownership,
        ) {
            return Err(FailedAgentComponents {
                error,
                registry: previous_registry,
                framework_components: previous_framework,
                framework_generation: previous_framework_generation,
                framework_receipt: previous_framework_receipt,
                mcp_ownership: previous_mcp_ownership,
                prepared: previous_prepared,
                candidate_monitors,
                orphaned_claims: Vec::new(),
                retained_withdrawal: None,
            });
        }

        // Withdraw the previous framework generation before releasing anything of
        // it. A failed withdrawal leaves its Skills/Hooks/MCP clients attached to
        // the Agent, so releasing the exact name tokens now would let a new owner
        // take a name whose old client is still connected. The replacement stops,
        // and the exact wiring receipt plus tokens become retryable debt.
        if let Some(receipt) = previous_framework_receipt.as_ref()
            && let Err(error) = self.integrator.rollback(agent, receipt).await
        {
            let retained_withdrawal = error
                .cleanup_receipt()
                .cloned()
                .unwrap_or_else(|| receipt.clone());
            let retained_claims = claims_from_ownership(&previous_mcp_ownership);
            unload_application_components(agent, &previous_prepared).await;
            agent
                .replace_system_context_projection(OUTPUT_STYLE_PROJECTION, None)
                .await;
            crate::runtime::configure_intent_router(agent);
            return Err(FailedAgentComponents {
                error: format!(
                    "framework plugin rollback failed before replacement: {error}; the previous plugin generation could not be withdrawn, so its exact wiring receipt stays retryable and no MCP name was released"
                ),
                registry: previous_registry,
                framework_components: HashMap::new(),
                framework_generation: None,
                framework_receipt: None,
                mcp_ownership: HashMap::new(),
                prepared: PreparedApplicationComponents::default(),
                candidate_monitors,
                orphaned_claims: Vec::new(),
                retained_withdrawal: Some((retained_withdrawal, retained_claims)),
            });
        }
        unload_application_components(agent, &previous_prepared).await;
        release_plugin_mcp_claims(&mut ownership_guard, &previous_mcp_ownership);
        let candidate_mcp_ownership =
            match claim_plugin_mcp_names(&mut ownership_guard, &candidate_mcp_declarations) {
                Ok(ownership) => ownership,
                Err(error) => {
                    let restored_mcp_ownership = match claim_plugin_mcp_names(
                        &mut ownership_guard,
                        &previous_mcp_declarations,
                    ) {
                        Ok(ownership) => ownership,
                        Err(restore_error) => {
                            return Err(FailedAgentComponents {
                                error: format!(
                                    "{error}; rollback MCP ownership failed: {restore_error}"
                                ),
                                registry: previous_registry,
                                framework_components: HashMap::new(),
                                framework_generation: None,
                                framework_receipt: None,
                                mcp_ownership: HashMap::new(),
                                prepared: PreparedApplicationComponents::default(),
                                candidate_monitors,
                                orphaned_claims: Vec::new(),
                                retained_withdrawal: None,
                            });
                        }
                    };
                    let restored = match previous_framework_generation.as_deref() {
                        Some(generation) => {
                            match self.integrator.wire_prepared(agent, generation).await {
                                Ok(receipt) => Some(receipt),
                                Err(restore_error) => {
                                    return Err(Self::failed_framework_restore(
                                        error,
                                        restore_error,
                                        previous_registry,
                                        restored_mcp_ownership,
                                        candidate_monitors,
                                        Vec::new(),
                                    ));
                                }
                            }
                        }
                        None => None,
                    };
                    let restore_agent_error = register_plugin_agents(
                        agent,
                        &previous_prepared.agents,
                        local_state_dir.clone(),
                    )
                    .await
                    .err();
                    crate::runtime::configure_intent_router(agent);
                    let mut errors = vec![error];
                    if let Some(error) = restore_agent_error {
                        errors.push(format!("rollback Subagent wiring failed: {error}"));
                    }
                    return Err(FailedAgentComponents {
                        error: errors.join("; "),
                        registry: previous_registry,
                        framework_components: restored
                            .as_ref()
                            .map(|receipt| receipt.components_by_plugin.clone())
                            .unwrap_or_default(),
                        framework_generation: previous_framework_generation,
                        framework_receipt: restored,
                        mcp_ownership: restored_mcp_ownership,
                        prepared: previous_prepared,
                        candidate_monitors,
                        orphaned_claims: Vec::new(),
                        retained_withdrawal: None,
                    });
                }
            };

        let wiring = match candidate_framework_generation.as_deref() {
            Some(generation) => self
                .integrator
                .wire_prepared(agent, generation)
                .await
                .map(Some),
            None => Ok(None),
        };
        // A failed apply may still hold framework cleanup debt: `wire_prepared`
        // returns the exact partial receipt when its own unwiring failed, and that
        // receipt's clients stay connected until a retry withdraws them. Keep the
        // typed error until the receipt and the candidate tokens are in hand.
        let candidate_outcome: Result<AppliedCandidate, RejectedCandidate> = match wiring {
            Ok(wiring) => match register_plugin_agents(
                agent,
                &candidate_prepared.agents,
                local_state_dir.clone(),
            )
            .await
            {
                Ok(_) => {
                    crate::runtime::configure_intent_router(agent);
                    Ok((candidate, wiring))
                }
                Err(error) => {
                    let mut retained_withdrawal = None;
                    if let Some(receipt) = wiring.as_ref()
                        && let Err(rollback_error) = self.integrator.rollback(agent, receipt).await
                    {
                        let retained = rollback_error
                            .cleanup_receipt()
                            .cloned()
                            .unwrap_or_else(|| receipt.clone());
                        retained_withdrawal =
                            Some((retained, claims_from_ownership(&candidate_mcp_ownership)));
                    }
                    unload_application_components(agent, &candidate_prepared).await;
                    Err((
                        format!("Plugin Subagent registration failed: {error}"),
                        retained_withdrawal,
                    ))
                }
            },
            Err(error) => {
                let retained_withdrawal = error
                    .cleanup_receipt()
                    .cloned()
                    .map(|receipt| (receipt, claims_from_ownership(&candidate_mcp_ownership)));
                Err((
                    format!("Plugin wiring failed: {error}"),
                    retained_withdrawal,
                ))
            }
        };

        match candidate_outcome {
            Ok((registry, wiring)) => Ok(AppliedAgentComponents {
                registry,
                wiring,
                framework_generation: candidate_framework_generation,
                mcp_ownership: candidate_mcp_ownership,
                prepared: candidate_prepared,
                previous_registry,
                previous_framework_generation,
                previous_mcp_declarations,
                previous_prepared,
            }),
            Err((error, Some((wiring, claims)))) => {
                // The candidate wiring could not be withdrawn, so its clients (and
                // the names they hold) are still live. Nothing is released and the
                // previous generation is not restored: the framework still owes its
                // own cleanup debt, which blocks a replacement wiring. The exact
                // receipt and tokens travel to the ledger, which now owns the
                // withdrawal-before-release ordering.
                Err(FailedAgentComponents {
                    error: format!(
                        "{error}; the partially wired plugin generation could not be withdrawn, so its exact wiring receipt stays retryable and no MCP name was released"
                    ),
                    registry: previous_registry,
                    framework_components: HashMap::new(),
                    framework_generation: None,
                    framework_receipt: None,
                    mcp_ownership: HashMap::new(),
                    prepared: PreparedApplicationComponents::default(),
                    candidate_monitors,
                    orphaned_claims: Vec::new(),
                    retained_withdrawal: Some((wiring, claims)),
                })
            }
            Err((error, None)) => {
                // The candidate wiring was fully withdrawn, so the exact ownership
                // tokens are the only surviving obligation. Release them exactly
                // once now so the previous generation can restore its own claims;
                // the orphaned receipt retry is an idempotent no-op.
                let orphaned_claims = claims_from_ownership(&candidate_mcp_ownership);
                release_plugin_mcp_claims(&mut ownership_guard, &candidate_mcp_ownership);
                let restored_mcp_ownership = match claim_plugin_mcp_names(
                    &mut ownership_guard,
                    &previous_mcp_declarations,
                ) {
                    Ok(ownership) => ownership,
                    Err(restore_error) => {
                        return Err(FailedAgentComponents {
                            error: format!(
                                "{error}; rollback MCP ownership failed: {restore_error}"
                            ),
                            registry: previous_registry,
                            framework_components: HashMap::new(),
                            framework_generation: None,
                            framework_receipt: None,
                            mcp_ownership: HashMap::new(),
                            prepared: PreparedApplicationComponents::default(),
                            candidate_monitors,
                            orphaned_claims: Vec::new(),
                            retained_withdrawal: None,
                        });
                    }
                };
                let restored = match previous_framework_generation.as_deref() {
                    Some(generation) => self
                        .integrator
                        .wire_prepared(agent, generation)
                        .await
                        .map(Some),
                    None => Ok(None),
                };
                let restored = match restored {
                    Ok(restored) => restored,
                    Err(restore_error) => {
                        crate::runtime::configure_intent_router(agent);
                        return Err(Self::failed_framework_restore(
                            error,
                            restore_error,
                            previous_registry,
                            restored_mcp_ownership,
                            candidate_monitors,
                            orphaned_claims,
                        ));
                    }
                };
                let restore_agent_error = register_plugin_agents(
                    agent,
                    &previous_prepared.agents,
                    local_state_dir.clone(),
                )
                .await
                .err();
                crate::runtime::configure_intent_router(agent);
                let registry = previous_registry;
                let mut errors = vec![error];
                if let Some(error) = restore_agent_error {
                    errors.push(format!("rollback Subagent wiring failed: {error}"));
                }
                Err(FailedAgentComponents {
                    error: errors.join("; "),
                    registry,
                    framework_components: restored
                        .as_ref()
                        .map(|receipt| receipt.components_by_plugin.clone())
                        .unwrap_or_default(),
                    framework_generation: previous_framework_generation,
                    framework_receipt: restored,
                    mcp_ownership: restored_mcp_ownership,
                    prepared: previous_prepared,
                    candidate_monitors,
                    orphaned_claims,
                    retained_withdrawal: None,
                })
            }
        }
    }

    async fn validate_agent_collisions(
        &self,
        state: &PluginRuntimeState,
        prepared: &PreparedApplicationComponents,
    ) -> anyhow::Result<()> {
        let existing = self
            .agent_handle
            .read(|agent| agent.subagent_registry().clone())
            .await
            .agent_names()
            .await
            .into_iter()
            .collect::<HashSet<_>>();
        let previous = state
            .prepared
            .agents
            .iter()
            .map(agent_name)
            .collect::<HashSet<_>>();
        let collisions = prepared
            .agents
            .iter()
            .map(agent_name)
            .filter(|name| existing.contains(name) && !previous.contains(name))
            .collect::<Vec<_>>();
        if collisions.is_empty() {
            Ok(())
        } else {
            Err(anyhow::anyhow!(
                "Plugin Subagent names collide with existing runtime roles: {}",
                collisions.join(", ")
            ))
        }
    }

    pub(crate) async fn project_root(&self) -> PathBuf {
        self.project_root.read().await.clone()
    }

    fn registry_for(&self, project_root: PathBuf) -> PluginRegistry {
        Self::registry_for_source(&self.registry_source, project_root)
    }

    fn registry_for_source(source: &RegistrySource, project_root: PathBuf) -> PluginRegistry {
        match source {
            RegistrySource::Default => {
                PluginRegistry::new(crate::data_root::user_data_dir(), Some(project_root))
            }
            #[cfg(test)]
            RegistrySource::Custom {
                state_file,
                data_dir,
                ..
            } => {
                PluginRegistry::with_paths(state_file.clone(), data_dir.clone(), Some(project_root))
            }
        }
    }

    fn scan_registry(&self, registry: &mut PluginRegistry) -> anyhow::Result<()> {
        Self::scan_registry_source(&self.registry_source, registry)
    }

    fn scan_registry_source(
        source: &RegistrySource,
        registry: &mut PluginRegistry,
    ) -> anyhow::Result<()> {
        match source {
            RegistrySource::Default => registry.scan_all().map(|_| ()),
            #[cfg(test)]
            RegistrySource::Custom { scopes, .. } => registry.scan_scopes(scopes).map(|_| ()),
        }
        .map_err(|error| anyhow::anyhow!("Plugin scan failed: {error}"))
    }

    fn scan_registry_scopes(
        &self,
        registry: &mut PluginRegistry,
        requested: &[PluginScope],
    ) -> anyhow::Result<()> {
        let scopes = match &self.registry_source {
            RegistrySource::Default => requested.to_vec(),
            #[cfg(test)]
            RegistrySource::Custom { scopes, .. } => requested
                .iter()
                .filter(|scope| scopes.contains(scope))
                .copied()
                .collect(),
        };
        registry
            .scan_scopes(&scopes)
            .map(|_| ())
            .map_err(|error| anyhow::anyhow!("Plugin scan failed: {error}"))
    }

    async fn restore_enabled_state(&self, name: &str, enabled: bool) {
        let mut registry = self.registry_for(self.project_root().await);
        if self.scan_registry(&mut registry).is_ok() {
            let result = if enabled {
                registry.enable(name)
            } else {
                registry.disable(name)
            };
            if let Err(error) = result {
                tracing::error!(plugin = %name, %error, "failed to roll back plugin enabled state");
            }
        }
    }

    async fn restore_plugin_config(&self, name: &str, values: HashMap<String, serde_json::Value>) {
        let mut registry = self.registry_for(self.project_root().await);
        if self.scan_registry(&mut registry).is_ok()
            && let Err(error) = registry.configure(name, values)
        {
            tracing::error!(plugin = %name, %error, "failed to roll back plugin configuration");
        }
    }

    /// Best-effort install rollback. Returns the error that must be retained as a
    /// cleanup receipt when the entry could not be fully removed.
    async fn rollback_install(&self, name: &str) -> Option<String> {
        let mut registry = self.registry_for(self.project_root().await);
        match self.scan_registry(&mut registry) {
            Ok(()) => match registry.uninstall(name, false) {
                Ok(()) => None,
                Err(error) => {
                    tracing::error!(plugin = %name, %error, "failed to roll back plugin install");
                    Some(error)
                }
            },
            Err(error) => Some(error.to_string()),
        }
    }

    async fn fire_loaded_events(&self, names: &[String]) {
        let (hook_registry, session_id, agent_name) = self
            .agent_handle
            .read(|agent| {
                (
                    agent.hook_registry().clone(),
                    agent
                        .config()
                        .get_session_id()
                        .unwrap_or_default()
                        .to_string(),
                    agent.config().get_agent_name().to_string(),
                )
            })
            .await;
        fire_plugin_events(
            &hook_registry,
            echo_agent::skills::hooks::HookEvent::PluginLoaded,
            names,
            &session_id,
            &agent_name,
        )
        .await;
    }

    async fn fire_plugin_disabled(&self, name: &str) {
        let (hook_registry, session_id, agent_name) = self
            .agent_handle
            .read(|agent| {
                (
                    agent.hook_registry().clone(),
                    agent
                        .config()
                        .get_session_id()
                        .unwrap_or_default()
                        .to_string(),
                    agent.config().get_agent_name().to_string(),
                )
            })
            .await;
        fire_plugin_events(
            &hook_registry,
            echo_agent::skills::hooks::HookEvent::PluginDisabled,
            &[name.to_string()],
            &session_id,
            &agent_name,
        )
        .await;
    }
}

impl Drop for PluginRuntimeService {
    /// Last line of defence for the receipt invariant: an owner may only let a
    /// receipt out of scope by settling it or by handing it to a live retry
    /// owner. A runtime dropped while still unsettled therefore parks its ledger
    /// in the process-level owner instead of dropping the obligations with it.
    fn drop(&mut self) {
        // Exclusive access during Drop gives access to both locks without
        // awaiting. Preserve exact authorities before any resource field drops.
        let authority = Arc::new(CleanupAuthority {
            agent_handle: self.agent_handle.clone(),
            mcp_ownership: Arc::clone(&self.mcp_ownership),
            scheduler: self.scheduler.get_mut().clone(),
            registry_source: self.registry_source.clone(),
        });
        let state = self.state.get_mut();
        if state.cleanup_receipts.is_empty() {
            return;
        }
        let receipts = Self::export_cleanup_receipts(state, &authority);
        let descriptions = retain_cleanup_receipts(receipts);
        tracing::error!(
            receipts = descriptions.len(),
            "plugin runtime dropped with unsettled cleanup receipts; parked them in the process retry ledger"
        );
    }
}
