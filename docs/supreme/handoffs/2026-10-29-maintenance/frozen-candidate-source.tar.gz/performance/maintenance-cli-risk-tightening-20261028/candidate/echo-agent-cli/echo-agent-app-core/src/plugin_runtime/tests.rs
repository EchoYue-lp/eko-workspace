#[cfg(test)]
mod tests {
    use super::*;
    use echo_agent::agent::ReactAgentBuilder;
    use echo_agent::testing::MockLlmClient;
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

    #[derive(Default)]
    struct LifecycleCounts {
        init: AtomicUsize,
        activate: AtomicUsize,
        deactivate: AtomicUsize,
        shutdown: AtomicUsize,
        fail_next_activation: AtomicBool,
        shutdown_failures_remaining: AtomicUsize,
    }

    struct TestLifecycle(Arc<LifecycleCounts>);

    impl PluginLifecycle for TestLifecycle {
        fn init(&self) -> Result<(), String> {
            self.0.init.fetch_add(1, Ordering::SeqCst);
            Ok(())
        }

        fn activate(&self) -> Result<(), String> {
            self.0.activate.fetch_add(1, Ordering::SeqCst);
            if self.0.fail_next_activation.swap(false, Ordering::SeqCst) {
                Err("injected activation failure".to_string())
            } else {
                Ok(())
            }
        }

        fn deactivate(&self) -> Result<(), String> {
            self.0.deactivate.fetch_add(1, Ordering::SeqCst);
            Ok(())
        }

        fn shutdown(&self) -> Result<(), String> {
            self.0.shutdown.fetch_add(1, Ordering::SeqCst);
            if self
                .0
                .shutdown_failures_remaining
                .try_update(Ordering::SeqCst, Ordering::SeqCst, |remaining| {
                    remaining.checked_sub(1)
                })
                .is_ok()
            {
                Err("injected shutdown failure".to_string())
            } else {
                Ok(())
            }
        }
    }

    fn write_fixture(root: &Path) -> Result<PathBuf, String> {
        write_fixture_at(
            root.join(".echo-agent/plugins/runtime-fixture"),
            "runtime-fixture",
        )
    }

    fn write_fixture_at(plugin: PathBuf, name: &str) -> Result<PathBuf, String> {
        PluginRuntimeService::scaffold(&plugin, name).map_err(|error| error.to_string())?;
        let skill_name = format!("{name}-example");
        std::fs::write(
            plugin.join("skills").join(&skill_name).join("SKILL.md"),
            format!(
                "---\nname: {skill_name}\ndescription: Example skill for route {name} work and related tasks.\n---\nUse this skill for {name} tasks.\n"
            ),
        )
        .map_err(|error| error.to_string())?;
        std::fs::write(
            plugin.join("monitors.yaml"),
            "monitors:\n  - name: daily-review\n    cron: \"0 0 * * * *\"\n    prompt: Review pending work\n",
        )
        .map_err(|error| error.to_string())?;
        Ok(plugin)
    }

    async fn service(root: &Path) -> Result<Arc<PluginRuntimeService>, String> {
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("plugin runtime integration test")
            .enable_tools()
            .enable_subagent()
            .register_agent_dispatch_tool()
            .working_dir(root)
            .build()
            .map_err(|error| error.to_string())?;
        PluginRuntimeService::new_for_test(
            AgentHandle::new(agent),
            root.to_path_buf(),
            root.join("registry.json"),
            root.join("plugin-data"),
        )
        .await
        .map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn constructor_rejects_an_invalid_initial_generation() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        std::fs::write(plugin.join("agents/example.md"), "not valid frontmatter")
            .map_err(|error| error.to_string())?;
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("constructor rejection test")
            .working_dir(temp.path())
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())?;

        let result = PluginRuntimeService::new_for_test(
            agent,
            temp.path().to_path_buf(),
            temp.path().join("registry.json"),
            temp.path().join("plugin-data"),
        )
        .await;

        assert!(result.is_err());
        Ok(())
    }

    async fn bind_test_pool(runtime: &Arc<PluginRuntimeService>) -> Result<Arc<AgentPool>, String> {
        let pool = Arc::new(
            AgentPool::new_for_test(runtime.agent_handle.clone(), None, None, 8, false).await,
        );
        runtime
            .bind_agent_pool(Arc::downgrade(&pool))
            .await
            .map_err(|error| error.to_string())?;
        Ok(pool)
    }

    fn write_application_skill(root: &Path, name: &str) -> Result<PathBuf, String> {
        let skill_root = root.join(name);
        std::fs::create_dir_all(&skill_root).map_err(|error| error.to_string())?;
        std::fs::write(
            skill_root.join("SKILL.md"),
            format!(
                "---\nname: {name}\ndescription: Application skill replay fixture for use {name}.\n---\nUse this skill for replay tests.\n"
            ),
        )
        .map_err(|error| error.to_string())?;
        Ok(root.to_path_buf())
    }

    async fn agent_has_application_skill(
        handle: &AgentHandle,
        name: &str,
        source: &str,
        expected: bool,
    ) -> Result<(), String> {
        let matches = handle
            .read(|agent| {
                agent
                    .skill_descriptors()
                    .into_iter()
                    .filter(|descriptor| {
                        descriptor.name == name && descriptor.source.as_deref() == Some(source)
                    })
                    .count()
            })
            .await;
        let exact = if expected { matches == 1 } else { matches == 0 };
        if exact {
            Ok(())
        } else {
            Err(format!(
                "application skill projection mismatch for '{name}' from '{source}': count={matches}, expected_present={expected}"
            ))
        }
    }

    async fn agent_has_plugin_generation(
        handle: &AgentHandle,
        plugin: &str,
        expected: bool,
    ) -> Result<(), String> {
        let skill = format!("{plugin}-example");
        let subagent = format!("{plugin}-specialist");
        let has_skill = handle
            .read(|agent| {
                agent
                    .skill_descriptors()
                    .iter()
                    .any(|descriptor| descriptor.name == skill)
            })
            .await;
        let registry = handle.read(|agent| agent.subagent_registry().clone()).await;
        let has_subagent = registry.contains(&subagent).await;
        if has_skill != expected || has_subagent != expected {
            return Err(format!(
                "agent plugin generation mismatch for {plugin}: skill={has_skill}, subagent={has_subagent}, expected={expected}"
            ));
        }
        Ok(())
    }

    async fn agent_has_output_style(handle: &AgentHandle, expected: bool) -> Result<(), String> {
        let messages = handle
            .read_async(|agent| Box::pin(async move { agent.get_messages().await }))
            .await;
        let present = messages.iter().any(|message| {
            message
                .content
                .as_text_ref()
                .is_some_and(|content| content.contains("Answer directly"))
        });
        if present == expected {
            Ok(())
        } else {
            Err(format!(
                "output style projection expected={expected}, actual={present}"
            ))
        }
    }

    async fn default_service(root: &Path) -> Result<Arc<PluginRuntimeService>, String> {
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("default plugin runtime integration test")
            .enable_tools()
            .enable_subagent()
            .register_agent_dispatch_tool()
            .working_dir(root)
            .build()
            .map_err(|error| error.to_string())?;
        PluginRuntimeService::new_owned(
            AgentHandle::new(agent),
            root.to_path_buf(),
            McpNameOwnershipRegistry::new(Vec::<String>::new()),
        )
        .await
        .map_err(|failure| failure.into_error().to_string())
    }

    async fn wait_until_mutation_holds_state(runtime: &PluginRuntimeService) -> Result<(), String> {
        tokio::time::timeout(std::time::Duration::from_secs(2), async {
            loop {
                if runtime.state.try_lock().is_err() {
                    break;
                }
                tokio::task::yield_now().await;
            }
        })
        .await
        .map_err(|_| "plugin mutation did not acquire runtime state".to_string())
    }

    #[tokio::test]
    async fn user_first_plugin_claim_is_rejected_without_a_receipt() -> Result<(), String> {
        let ownership = McpNameOwnershipRegistry::new(["shared".to_string()]);
        let mut guard = ownership.lock().await;

        let error = guard
            .claim_plugin("fixture", "shared")
            .err()
            .ok_or_else(|| "plugin unexpectedly claimed a user MCP name".to_string())?;

        assert!(error.contains("user configuration"));
        Ok(())
    }

    #[tokio::test]
    async fn plugin_first_user_takeover_invalidates_plugin_shutdown_receipt() -> Result<(), String>
    {
        let ownership = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let token = {
            let mut guard = ownership.lock().await;
            guard.claim_plugin("fixture", "shared")?
        };
        let plugin_receipts = HashMap::from([(
            "fixture".to_string(),
            WiredPluginComponents {
                mcp_servers: vec!["shared".to_string()],
                ..Default::default()
            },
        )]);
        let plugin_ownership = HashMap::from([(
            "fixture".to_string(),
            HashMap::from([("shared".to_string(), token)]),
        )]);

        ownership.claim_user_names(["shared".to_string()]).await;
        let guard = ownership.lock().await;
        let shutdown_receipts =
            exact_plugin_framework_receipts(&plugin_receipts, &plugin_ownership, &guard);

        assert!(
            shutdown_receipts
                .get("fixture")
                .is_some_and(|receipt| receipt.mcp_servers.is_empty())
        );
        assert!(!guard.owns_plugin("fixture", "shared", token));
        Ok(())
    }

    #[tokio::test]
    async fn reload_summary_preserves_complete_frozen_diagnostics() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        std::fs::write(plugin.join("lsp.yaml"), "languages: {}\n")
            .map_err(|error| error.to_string())?;
        std::fs::remove_file(plugin.join("mcp.json")).map_err(|error| error.to_string())?;
        std::fs::create_dir(plugin.join("mcp.json")).map_err(|error| error.to_string())?;
        let runtime = service(temp.path()).await?;
        let mut registry = runtime.registry_for(temp.path().to_path_buf());
        runtime
            .scan_registry(&mut registry)
            .map_err(|error| error.to_string())?;
        let prepared = runtime.integrator.prepare(&mut registry).await;
        assert!(
            prepared.diagnostics().iter().any(|diagnostic| {
                diagnostic.component() == "lsp"
                    && diagnostic.severity()
                        == echo_agent::plugin::PluginDiagnosticSeverity::Warning
            }),
            "fixture must include the frozen build-boundary warning"
        );
        assert!(
            prepared.diagnostics().iter().any(|diagnostic| {
                diagnostic.component() != "lsp"
                    && diagnostic.severity()
                        == echo_agent::plugin::PluginDiagnosticSeverity::Warning
            }),
            "fixture must include a retained generic warning"
        );
        let components =
            prepare_application_components(&prepared, "diagnostic-contract", &registry)
                .map_err(|errors| errors.join("; "))?;
        let summary = ReloadSummary::from_components(1, 1, None, Some(&prepared), &components);
        assert_eq!(summary.errors.len(), prepared.diagnostics().len());
        for diagnostic in prepared.diagnostics() {
            let severity_prefix = format!("{:?}:", diagnostic.severity());
            assert!(summary.errors.iter().any(|message| {
                message.starts_with(&severity_prefix) && message.contains(&diagnostic.to_string())
            }));
        }
        runtime
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn retired_lsp_diagnostics_preserve_mixed_plugin_components_and_files()
    -> Result<(), String> {
        for bytes in [
            b"languages: {}\n".as_slice(),
            b"invalid: [\n".as_slice(),
            &[0xff, 0xfe],
        ] {
            let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
            let plugin = write_fixture(temp.path())?;
            let legacy = plugin.join("lsp.yaml");
            std::fs::write(&legacy, bytes).map_err(|error| error.to_string())?;
            let runtime = service(temp.path()).await?;
            let summary = runtime.reload().await.map_err(|error| error.to_string())?;
            assert_eq!(summary.agents_loaded, 1);
            assert_eq!(summary.monitors_loaded, 1);
            assert_eq!(summary.themes_loaded, 1);
            assert!(summary.skills_loaded > 0);
            assert!(
                summary
                    .errors
                    .iter()
                    .any(|message| message.contains("LSP component has been retired"))
            );
            assert_eq!(
                std::fs::read(&legacy).map_err(|error| error.to_string())?,
                bytes
            );
            let entry = runtime
                .get("runtime-fixture")
                .await
                .ok_or_else(|| "mixed plugin missing".to_string())?;
            assert!(
                !plugin_capabilities(&entry)
                    .iter()
                    .any(|capability| capability.display_name().contains("LSP"))
            );
            runtime
                .shutdown()
                .await
                .map_err(|error| error.to_string())?;
        }
        Ok(())
    }

    #[tokio::test]
    async fn retirement_diagnostics_follow_prepared_generation_not_live_files() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        let legacy = plugin.join("lsp.yaml");
        std::fs::write(&legacy, "languages: {}\n").map_err(|error| error.to_string())?;
        let runtime = service(temp.path()).await?;
        let mut registry = runtime.registry_for(temp.path().to_path_buf());
        runtime
            .scan_registry(&mut registry)
            .map_err(|error| error.to_string())?;
        let prepared = runtime.integrator.prepare(&mut registry).await;
        let diagnostic = prepared
            .diagnostics()
            .iter()
            .find(|diagnostic| diagnostic.component() == "lsp")
            .ok_or_else(|| "frozen build diagnostic missing".to_string())?;
        assert_eq!(diagnostic.path(), Some(legacy.as_path()));
        assert_eq!(diagnostic.plugin_id(), Some("runtime-fixture"));
        assert_eq!(
            diagnostic.severity(),
            echo_agent::plugin::PluginDiagnosticSeverity::Warning
        );
        std::fs::rename(&legacy, plugin.join("legacy.saved")).map_err(|error| error.to_string())?;
        let cached = runtime.integrator.prepare(&mut registry).await;
        assert!(Arc::ptr_eq(&prepared, &cached));
        assert_eq!(cached.generation(), prepared.generation());
        assert_eq!(cached.identity(), prepared.identity());
        assert_eq!(cached.diagnostics(), prepared.diagnostics());
        let components = prepare_application_components(&prepared, "snapshot-test", &registry)
            .map_err(|errors| errors.join("; "))?;
        let observed = ReloadSummary::from_components(1, 1, None, Some(&prepared), &components);
        assert!(
            observed
                .errors
                .iter()
                .any(|message| message.contains("LSP component has been retired"))
        );
        let mut clean_registry = runtime.registry_for(temp.path().to_path_buf());
        runtime
            .scan_registry(&mut clean_registry)
            .map_err(|error| error.to_string())?;
        let clean = runtime.integrator.prepare(&mut clean_registry).await;
        assert!(
            clean
                .diagnostics()
                .iter()
                .all(|diagnostic| diagnostic.component() != "lsp")
        );
        std::fs::write(&legacy, "late legacy file").map_err(|error| error.to_string())?;
        let clean_components =
            prepare_application_components(&clean, "snapshot-test", &clean_registry)
                .map_err(|errors| errors.join("; "))?;
        let observed = ReloadSummary::from_components(1, 1, None, Some(&clean), &clean_components);
        assert!(
            !observed
                .errors
                .iter()
                .any(|message| message.contains("LSP component has been retired"))
        );
        let cached_clean = runtime.integrator.prepare(&mut clean_registry).await;
        assert!(Arc::ptr_eq(&clean, &cached_clean));
        assert_eq!(cached_clean.diagnostics(), clean.diagnostics());
        runtime.integrator.invalidate(&clean_registry);
        let late = runtime.integrator.prepare(&mut clean_registry).await;
        assert!(late.generation() > clean.generation());
        assert_ne!(late.identity(), clean.identity());
        assert_eq!(
            late.diagnostics()
                .iter()
                .filter(|diagnostic| diagnostic.component() == "lsp")
                .count(),
            1
        );
        std::fs::write(&legacy, [0xff]).map_err(|error| error.to_string())?;
        let cached_late = runtime.integrator.prepare(&mut clean_registry).await;
        assert!(Arc::ptr_eq(&late, &cached_late));
        assert_eq!(cached_late.diagnostics(), late.diagnostics());
        runtime.integrator.invalidate(&clean_registry);
        let invalid = runtime.integrator.prepare(&mut clean_registry).await;
        assert!(invalid.generation() > late.generation());
        let diagnostic = invalid
            .diagnostics()
            .iter()
            .find(|diagnostic| diagnostic.component() == "lsp")
            .ok_or_else(|| "invalid text diagnostic missing".to_string())?;
        assert_eq!(
            diagnostic.severity(),
            echo_agent::plugin::PluginDiagnosticSeverity::Error
        );
        let components = prepare_application_components(&invalid, "snapshot-test", &clean_registry)
            .map_err(|errors| errors.join("; "))?;
        let summary = ReloadSummary::from_components(1, 1, None, Some(&invalid), &components);
        assert!(
            summary
                .errors
                .iter()
                .any(|message| message.starts_with("Error:")
                    && message.contains("LSP component has been retired"))
        );
        runtime
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn retired_lsp_io_errors_keep_legal_components_and_source_identity() -> Result<(), String>
    {
        use std::os::unix::fs::{PermissionsExt, symlink};
        for kind in [
            "directory",
            "broken-link",
            "metadata-loop",
            "read-permission",
            "metadata-permission",
        ] {
            let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
            let plugin = write_fixture(temp.path())?;
            let runtime = service(temp.path()).await?;
            let legacy = plugin.join("lsp.yaml");
            let mut restore_permissions = None;
            match kind {
                "directory" => std::fs::create_dir(&legacy).map_err(|error| error.to_string())?,
                "broken-link" => {
                    symlink("missing-language-input", &legacy).map_err(|error| error.to_string())?
                }
                "metadata-loop" => {
                    symlink("lsp.yaml", &legacy).map_err(|error| error.to_string())?
                }
                "read-permission" => {
                    std::fs::write(&legacy, "languages: {}\n")
                        .map_err(|error| error.to_string())?;
                    let permissions = std::fs::metadata(&legacy)
                        .map_err(|error| error.to_string())?
                        .permissions();
                    std::fs::set_permissions(&legacy, std::fs::Permissions::from_mode(0o0))
                        .map_err(|error| error.to_string())?;
                    restore_permissions = Some((legacy.clone(), permissions));
                }
                "metadata-permission" => {
                    let locked = plugin.join("locked");
                    std::fs::create_dir(&locked).map_err(|error| error.to_string())?;
                    std::fs::write(locked.join("source.yaml"), "languages: {}\n")
                        .map_err(|error| error.to_string())?;
                    symlink("locked/source.yaml", &legacy).map_err(|error| error.to_string())?;
                    let permissions = std::fs::metadata(&locked)
                        .map_err(|error| error.to_string())?
                        .permissions();
                    std::fs::set_permissions(&locked, std::fs::Permissions::from_mode(0o0))
                        .map_err(|error| error.to_string())?;
                    restore_permissions = Some((locked, permissions));
                }
                _ => return Err(format!("unknown input fixture: {kind}")),
            }
            // Privileged test processes may bypass Unix mode bits. The deterministic
            // directory/link/loop cases still exercise actual I/O errors there.
            let permission_error_observable = match kind {
                "read-permission" => std::fs::read(&legacy).is_err(),
                "metadata-permission" => std::fs::metadata(&legacy).is_err(),
                _ => true,
            };
            if !permission_error_observable {
                if let Some((path, permissions)) = restore_permissions {
                    std::fs::set_permissions(path, permissions)
                        .map_err(|error| error.to_string())?;
                }
                runtime
                    .shutdown()
                    .await
                    .map_err(|error| error.to_string())?;
                eprintln!("Unix permission fixture not applicable with bypass privileges: {kind}");
                continue;
            }
            let result = runtime.reload().await;
            // Restore access before inspecting any result, including a failed reload.
            if let Some((path, permissions)) = restore_permissions {
                std::fs::set_permissions(path, permissions).map_err(|error| error.to_string())?;
            }
            let summary = result.map_err(|error| error.to_string())?;
            let prepared = runtime
                .state
                .lock()
                .await
                .framework_generation
                .clone()
                .ok_or_else(|| "published generation missing".to_string())?;
            let diagnostic = prepared
                .diagnostics()
                .iter()
                .find(|diagnostic| diagnostic.component() == "lsp")
                .ok_or_else(|| format!("structured diagnostic missing for {kind}"))?;
            assert_eq!(diagnostic.path(), Some(legacy.as_path()));
            assert_eq!(diagnostic.plugin_id(), Some("runtime-fixture"));
            assert_eq!(
                diagnostic.severity(),
                echo_agent::plugin::PluginDiagnosticSeverity::Error
            );
            assert!(
                summary
                    .errors
                    .iter()
                    .any(|message| message.starts_with("Error:")
                        && message.contains(&diagnostic.to_string())
                        && message.contains("LSP component has been retired"))
            );
            assert_eq!(summary.errors.len(), prepared.diagnostics().len());
            assert_eq!(summary.agents_loaded, 1);
            assert_eq!(summary.monitors_loaded, 1);
            assert_eq!(summary.themes_loaded, 1);
            assert!(summary.skills_loaded > 0);
            let metadata = std::fs::symlink_metadata(&legacy).map_err(|error| error.to_string())?;
            match kind {
                "directory" => assert!(metadata.is_dir()),
                "read-permission" => assert_eq!(
                    std::fs::read_to_string(&legacy).map_err(|error| error.to_string())?,
                    "languages: {}\n"
                ),
                _ => assert!(metadata.file_type().is_symlink()),
            }
            eprintln!("Retired input fixture exercised with original Error: {kind}");
            runtime
                .shutdown()
                .await
                .map_err(|error| error.to_string())?;
        }
        Ok(())
    }

    #[tokio::test]
    async fn retired_lsp_only_plugin_reports_no_activated_language_component() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = temp.path().join(".echo-agent/plugins/legacy-only");
        std::fs::create_dir_all(&plugin).map_err(|error| error.to_string())?;
        std::fs::write(plugin.join("plugin.json"), serde_json::json!({"$schema": AGENT_PLUGIN_SCHEMA_V1, "name":"legacy-only", "version":"1.0.0", "description":"legacy language service"}).to_string()).map_err(|error| error.to_string())?;
        std::fs::write(plugin.join("lsp.yaml"), "languages: {}\n")
            .map_err(|error| error.to_string())?;
        let runtime = service(temp.path()).await?;
        let summary = runtime.reload().await.map_err(|error| error.to_string())?;
        assert_eq!(summary.agents_loaded, 0);
        assert_eq!(summary.skills_loaded, 0);
        assert!(
            summary
                .errors
                .iter()
                .any(|message| message.contains("no language server was loaded"))
        );
        runtime
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn real_plugin_load_disable_and_unload_are_live() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let summary = runtime.reload().await.map_err(|error| error.to_string())?;
        assert_eq!(summary.total, 1);
        assert_eq!(summary.agents_loaded, 1);

        assert_eq!(summary.monitors_loaded, 1);
        assert_eq!(summary.themes_loaded, 1);
        assert_eq!(summary.output_styles_loaded, 1);
        let registry = runtime
            .agent_handle
            .read(|agent| agent.subagent_registry().clone())
            .await;
        assert!(registry.contains("runtime-fixture-specialist").await);
        assert_eq!(runtime.themes().await.len(), 1);
        assert_eq!(runtime.output_styles().await.len(), 1);

        let cron_store =
            crate::scheduler::CronTaskStore::new().with_path(temp.path().join("cron-tasks.json"));
        let fire_fn: echo_agent::scheduler::FireFn =
            Arc::new(|_| Box::pin(async { Ok("fixture monitor fired".to_string()) }));
        let scheduler = Arc::new(
            SchedulerRunner::new(
                cron_store,
                echo_agent::agent::CancellationToken::new(),
                fire_fn,
            )
            .await
            .map_err(|error| error.to_string())?,
        );
        assert_eq!(
            runtime
                .bind_scheduler(scheduler.clone())
                .await
                .map_err(|error| error.to_string())?,
            1
        );
        assert_eq!(scheduler.list_tasks().await.len(), 1);

        runtime
            .activate_output_style(Some("runtime-fixture-concise"))
            .await
            .map_err(|error| error.to_string())?;
        let projected = runtime
            .agent_handle
            .read_async(|agent| Box::pin(async move { agent.get_messages().await }))
            .await;
        assert!(projected.iter().any(|message| {
            message
                .content
                .as_text_ref()
                .is_some_and(|content| content.contains("Answer directly"))
        }));

        runtime
            .disable("runtime-fixture")
            .await
            .map_err(|error| error.to_string())?;
        assert!(!registry.contains("runtime-fixture-specialist").await);
        assert!(runtime.themes().await.is_empty());
        assert!(runtime.output_styles().await.is_empty());
        assert!(scheduler.list_tasks().await.is_empty());

        let projected = runtime
            .agent_handle
            .read_async(|agent| Box::pin(async move { agent.get_messages().await }))
            .await;
        assert!(projected.iter().all(|message| {
            message
                .content
                .as_text_ref()
                .is_none_or(|content| !content.contains("Answer directly"))
        }));

        runtime
            .enable("runtime-fixture")
            .await
            .map_err(|error| error.to_string())?;
        assert!(registry.contains("runtime-fixture-specialist").await);
        assert_eq!(scheduler.list_tasks().await.len(), 1);
        runtime
            .uninstall("runtime-fixture", false)
            .await
            .map_err(|error| error.to_string())?;
        assert!(!plugin.exists());
        assert!(runtime.list().await.is_empty());
        assert!(!registry.contains("runtime-fixture-specialist").await);
        assert!(scheduler.list_tasks().await.is_empty());
        Ok(())
    }

    #[tokio::test]
    async fn plugin_generation_reaches_primary_existing_and_future_pool_agents()
    -> Result<(), String> {
        let temporary = tempfile::tempdir().map_err(|error| error.to_string())?;
        let runtime = service(temporary.path()).await?;
        let pool = bind_test_pool(&runtime).await?;
        let existing_lease = pool
            .acquire("existing-plugin-consumer")
            .await
            .map_err(|error| error.to_string())?;
        let existing = existing_lease.agent();
        drop(existing_lease);
        agent_has_plugin_generation(&runtime.agent_handle, "runtime-fixture", false).await?;
        agent_has_plugin_generation(&existing, "runtime-fixture", false).await?;

        let _plugin = write_fixture(temporary.path())?;
        runtime.reload().await.map_err(|error| error.to_string())?;
        agent_has_plugin_generation(&runtime.agent_handle, "runtime-fixture", true).await?;
        agent_has_plugin_generation(&existing, "runtime-fixture", true).await?;
        runtime
            .activate_output_style(Some("runtime-fixture-concise"))
            .await
            .map_err(|error| error.to_string())?;
        agent_has_output_style(&runtime.agent_handle, true).await?;
        agent_has_output_style(&existing, true).await?;

        let future_lease = pool
            .acquire("future-plugin-consumer")
            .await
            .map_err(|error| error.to_string())?;
        let future = future_lease.agent();
        drop(future_lease);
        agent_has_plugin_generation(&future, "runtime-fixture", true).await?;
        agent_has_output_style(&future, true).await?;
        let committed_revision = pool.plugin_generation_revision_for_test().await;

        runtime
            .disable("runtime-fixture")
            .await
            .map_err(|error| error.to_string())?;
        agent_has_plugin_generation(&runtime.agent_handle, "runtime-fixture", false).await?;
        agent_has_plugin_generation(&existing, "runtime-fixture", false).await?;
        agent_has_plugin_generation(&future, "runtime-fixture", false).await?;
        let after_remove_lease = pool
            .acquire("after-plugin-remove")
            .await
            .map_err(|error| error.to_string())?;
        let after_remove = after_remove_lease.agent();
        drop(after_remove_lease);
        agent_has_plugin_generation(&after_remove, "runtime-fixture", false).await?;
        assert!(pool.plugin_generation_revision_for_test().await > committed_revision);
        Ok(())
    }

    #[tokio::test]
    async fn application_skill_replay_repairs_pool_split_and_future_generation()
    -> Result<(), String> {
        let temporary = tempfile::tempdir().map_err(|error| error.to_string())?;
        let runtime = service(temporary.path()).await?;
        let pool = bind_test_pool(&runtime).await?;
        let existing_lease = pool
            .acquire("application-skill-existing")
            .await
            .map_err(|error| error.to_string())?;
        let existing = existing_lease.agent();
        drop(existing_lease);
        let name = "replay-skill";
        let source = "eko:user-skill:replay-skill";
        let skill_root = write_application_skill(temporary.path(), name)?;

        runtime
            .enable_application_skill(name.to_string(), skill_root.clone(), source.to_string())
            .await
            .map_err(|error| error.to_string())?;
        agent_has_application_skill(&runtime.agent_handle, name, source, true).await?;
        agent_has_application_skill(&existing, name, source, true).await?;

        let tampered_source = source.to_string();
        existing
            .write_async(|agent| {
                Box::pin(async move {
                    agent.unregister_skills_by_source(&tampered_source).await;
                    crate::runtime::configure_intent_router(agent);
                })
            })
            .await;
        agent_has_application_skill(&runtime.agent_handle, name, source, true).await?;
        agent_has_application_skill(&existing, name, source, false).await?;

        let before_enable_repair = pool.plugin_generation_revision_for_test().await;
        runtime
            .enable_application_skill(name.to_string(), skill_root.clone(), source.to_string())
            .await
            .map_err(|error| error.to_string())?;
        agent_has_application_skill(&existing, name, source, true).await?;
        assert!(pool.plugin_generation_revision_for_test().await > before_enable_repair);
        let future_enabled_lease = pool
            .acquire("application-skill-future-enabled")
            .await
            .map_err(|error| error.to_string())?;
        let future_enabled = future_enabled_lease.agent();
        drop(future_enabled_lease);
        agent_has_application_skill(&future_enabled, name, source, true).await?;

        let descriptor = runtime
            .agent_handle
            .read(|agent| {
                agent.skill_descriptors().into_iter().find(|descriptor| {
                    descriptor.name == name && descriptor.source.as_deref() == Some(source)
                })
            })
            .await
            .ok_or_else(|| "primary application skill descriptor is missing".to_string())?;
        runtime
            .disable_application_skill(name.to_string(), skill_root.clone(), source.to_string())
            .await
            .map_err(|error| error.to_string())?;
        agent_has_application_skill(&runtime.agent_handle, name, source, false).await?;
        agent_has_application_skill(&existing, name, source, false).await?;
        agent_has_application_skill(&future_enabled, name, source, false).await?;

        existing
            .write_async(|agent| {
                Box::pin(async move {
                    agent
                        .register_skill_descriptor(descriptor)
                        .await
                        .map_err(|error| error.to_string())?;
                    crate::runtime::configure_intent_router(agent);
                    Ok::<(), String>(())
                })
            })
            .await?;
        agent_has_application_skill(&runtime.agent_handle, name, source, false).await?;
        agent_has_application_skill(&existing, name, source, true).await?;

        let before_disable_repair = pool.plugin_generation_revision_for_test().await;
        runtime
            .disable_application_skill(name.to_string(), skill_root, source.to_string())
            .await
            .map_err(|error| error.to_string())?;
        agent_has_application_skill(&existing, name, source, false).await?;
        assert!(pool.plugin_generation_revision_for_test().await > before_disable_repair);
        let future_disabled_lease = pool
            .acquire("application-skill-future-disabled")
            .await
            .map_err(|error| error.to_string())?;
        let future_disabled = future_disabled_lease.agent();
        drop(future_disabled_lease);
        agent_has_application_skill(&future_disabled, name, source, false).await?;
        Ok(())
    }

    #[tokio::test]
    async fn failed_plugin_activation_retires_primary_and_pool_generation() -> Result<(), String> {
        let temporary = tempfile::tempdir().map_err(|error| error.to_string())?;
        let _first = write_fixture(temporary.path())?;
        let runtime = service(temporary.path()).await?;
        let pool = bind_test_pool(&runtime).await?;
        let existing_lease = pool
            .acquire("rollback-existing")
            .await
            .map_err(|error| error.to_string())?;
        let existing = existing_lease.agent();
        drop(existing_lease);
        let previous_revision = pool.plugin_generation_revision_for_test().await;
        let lifecycle = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        let _second = write_fixture_at(
            temporary
                .path()
                .join(".echo-agent/plugins/rollback-candidate"),
            "rollback-candidate",
        )?;
        lifecycle.fail_next_activation.store(true, Ordering::SeqCst);

        let error = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "injected activation failure unexpectedly committed".to_string())?;
        if !error.to_string().contains("injected activation failure") {
            return Err(format!(
                "plugin activation failed for an unexpected reason: {error}"
            ));
        }
        agent_has_plugin_generation(&runtime.agent_handle, "runtime-fixture", false).await?;
        agent_has_plugin_generation(&existing, "runtime-fixture", false).await?;
        agent_has_plugin_generation(&runtime.agent_handle, "rollback-candidate", false).await?;
        agent_has_plugin_generation(&existing, "rollback-candidate", false).await?;
        assert!(pool.plugin_generation_revision_for_test().await > previous_revision);

        let future_lease = pool
            .acquire("rollback-future")
            .await
            .map_err(|error| error.to_string())?;
        let future = future_lease.agent();
        drop(future_lease);
        agent_has_plugin_generation(&future, "runtime-fixture", false).await?;
        agent_has_plugin_generation(&future, "rollback-candidate", false).await?;
        Ok(())
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn active_primary_execution_blocks_plugin_generation_publication() -> Result<(), String> {
        let temporary = tempfile::tempdir().map_err(|error| error.to_string())?;
        let runtime = service(temporary.path()).await?;
        let pool = bind_test_pool(&runtime).await?;
        let previous_revision = pool.plugin_generation_revision_for_test().await;
        let primary_execution = runtime
            .agent_handle
            .read(|agent| Arc::clone(agent.execution_mutex()))
            .await;
        let active_execution = primary_execution.lock_owned().await;
        let _plugin = write_fixture(temporary.path())?;

        let reload_runtime = Arc::clone(&runtime);
        let mut reload = tokio::spawn(async move { reload_runtime.reload().await });
        tokio::task::yield_now().await;
        assert!(
            tokio::time::timeout(std::time::Duration::from_millis(50), &mut reload)
                .await
                .is_err(),
            "plugin publication escaped an already-active primary execution"
        );
        assert_eq!(
            pool.plugin_generation_revision_for_test().await,
            previous_revision
        );
        agent_has_plugin_generation(&runtime.agent_handle, "runtime-fixture", false).await?;

        drop(active_execution);
        reload
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        agent_has_plugin_generation(&runtime.agent_handle, "runtime-fixture", true).await?;
        assert!(pool.plugin_generation_revision_for_test().await > previous_revision);
        Ok(())
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn component_readers_wait_for_plugin_generation_settlement() -> Result<(), String> {
        let temporary = tempfile::tempdir().map_err(|error| error.to_string())?;
        let runtime = service(temporary.path()).await?;
        let _plugin = write_fixture(temporary.path())?;
        let ownership = runtime.mcp_ownership.lock().await;

        let reload_runtime = Arc::clone(&runtime);
        let reload = tokio::spawn(async move { reload_runtime.reload().await });
        wait_until_mutation_holds_state(&runtime).await?;

        let reader_runtime = Arc::clone(&runtime);
        let mut reader = tokio::spawn(async move { reader_runtime.themes().await });
        assert!(
            tokio::time::timeout(std::time::Duration::from_millis(50), &mut reader)
                .await
                .is_err(),
            "Component reader observed a plugin generation before settlement"
        );

        drop(ownership);
        reload
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        let themes = reader.await.map_err(|error| error.to_string())?;
        assert!(!themes.is_empty());
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn aborted_reload_waiter_does_not_cancel_owned_component_settlement() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        std::fs::write(
            plugin.join("themes/second.json"),
            "{\n  \"name\": \"runtime-fixture-second\",\n  \"dark\": false,\n  \"colors\": {}\n}\n",
        )
        .map_err(|error| error.to_string())?;

        let ownership = runtime.mcp_ownership.lock().await;
        let runtime_for_waiter = Arc::clone(&runtime);
        let waiter = tokio::spawn(async move { runtime_for_waiter.reload().await });
        wait_until_mutation_holds_state(&runtime).await?;
        waiter.abort();
        let waiter_error = waiter
            .await
            .err()
            .ok_or_else(|| "aborted plugin reload waiter unexpectedly completed".to_string())?;
        assert!(waiter_error.is_cancelled());
        drop(ownership);

        let themes = runtime.themes().await;
        assert!(
            themes
                .iter()
                .any(|theme| theme.name == "runtime-fixture-second")
        );
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn owned_plugin_mutations_execute_in_admission_order() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let runtime = service(temp.path()).await?;
        let order = Arc::new(Mutex::new(Vec::new()));
        let (first_started_tx, first_started_rx) = tokio::sync::oneshot::channel();
        let (release_first_tx, release_first_rx) = tokio::sync::oneshot::channel();

        let first_runtime = Arc::clone(&runtime);
        let first_order = Arc::clone(&order);
        let first = tokio::spawn(async move {
            first_runtime
                .run_owned_mutation(move |_| async move {
                    first_order.lock().await.push(1_u8);
                    first_started_tx
                        .send(())
                        .map_err(|_| anyhow::anyhow!("first mutation start waiter closed"))?;
                    release_first_rx
                        .await
                        .map_err(|error| anyhow::anyhow!(error.to_string()))?;
                    Ok(())
                })
                .await
        });
        first_started_rx.await.map_err(|error| error.to_string())?;

        let second_runtime = Arc::clone(&runtime);
        let second_order = Arc::clone(&order);
        let second = tokio::spawn(async move {
            second_runtime
                .run_owned_mutation(move |_| async move {
                    second_order.lock().await.push(2_u8);
                    Ok(())
                })
                .await
        });
        release_first_tx
            .send(())
            .map_err(|_| "first plugin mutation stopped before release".to_string())?;
        first
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        second
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        assert_eq!(*order.lock().await, vec![1, 2]);
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn aborted_rebind_waiter_does_not_cancel_owned_workspace_settlement() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let first = temp.path().join("first");
        let second = temp.path().join("second");
        std::fs::create_dir_all(&first).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&second).map_err(|error| error.to_string())?;
        write_fixture(&first)?;
        write_fixture_at(
            second.join(".echo-agent/plugins/second-fixture"),
            "second-fixture",
        )?;
        let runtime = service(&first).await?;

        let ownership = runtime.mcp_ownership.lock().await;
        let runtime_for_waiter = Arc::clone(&runtime);
        let second_for_waiter = second.clone();
        let waiter =
            tokio::spawn(
                async move { runtime_for_waiter.rebind_workspace(second_for_waiter).await },
            );
        wait_until_mutation_holds_state(&runtime).await?;
        waiter.abort();
        let waiter_error = waiter
            .await
            .err()
            .ok_or_else(|| "aborted plugin rebind waiter unexpectedly completed".to_string())?;
        assert!(waiter_error.is_cancelled());
        drop(ownership);

        let entries = runtime.list().await;
        assert_eq!(runtime.workspace_root().await, second);
        assert!(
            entries
                .iter()
                .any(|entry| entry.manifest.name == "second-fixture")
        );
        assert!(
            entries
                .iter()
                .all(|entry| entry.manifest.name != "runtime-fixture")
        );
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn workspace_rebind_replaces_project_plugins_and_preserves_root_authority()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let first = temp.path().join("first");
        let second = temp.path().join("second");
        std::fs::create_dir_all(&first).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&second).map_err(|error| error.to_string())?;
        write_fixture(&first)?;
        let runtime = service(&first).await?;
        let lifecycle = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        let registry = runtime
            .agent_handle
            .read(|agent| agent.subagent_registry().clone())
            .await;
        assert!(registry.contains("runtime-fixture-specialist").await);

        let summary = runtime
            .rebind_workspace(second.clone())
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(summary.total, 0);
        assert_eq!(runtime.workspace_root().await, second);
        assert!(!registry.contains("runtime-fixture-specialist").await);
        assert_eq!(lifecycle.deactivate.load(Ordering::SeqCst), 1);
        assert_eq!(lifecycle.shutdown.load(Ordering::SeqCst), 1);

        Ok(())
    }

    #[tokio::test]
    async fn failed_project_lifecycle_cleanup_is_quarantined_and_retried() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let first = temp.path().join("first");
        let second = temp.path().join("second");
        std::fs::create_dir_all(&first).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&second).map_err(|error| error.to_string())?;
        write_fixture(&first)?;
        let runtime = service(&first).await?;
        let lifecycle = Arc::new(LifecycleCounts::default());
        lifecycle
            .shutdown_failures_remaining
            .store(1, Ordering::SeqCst);
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;

        let first_error = runtime
            .rebind_workspace(second.clone())
            .await
            .err()
            .ok_or_else(|| "lifecycle cleanup failure was not reported".to_string())?;
        assert!(
            first_error
                .to_string()
                .contains("lifecycle retirement failed")
        );
        assert_eq!(runtime.workspace_root().await, second);
        assert_eq!(runtime.cleanup_debt_roots().await, vec![first.clone()]);

        runtime
            .rebind_workspace(first.clone())
            .await
            .map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_debt_roots().await.is_empty());
        assert_eq!(lifecycle.shutdown.load(Ordering::SeqCst), 2);
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn shutdown_unwires_plugin_receipts_and_is_idempotent() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let lifecycle = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        let registry = runtime
            .agent_handle
            .read(|agent| agent.subagent_registry().clone())
            .await;
        assert!(registry.contains("runtime-fixture-specialist").await);

        runtime
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        runtime
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        assert!(!registry.contains("runtime-fixture-specialist").await);
        assert_eq!(lifecycle.deactivate.load(Ordering::SeqCst), 1);
        assert_eq!(lifecycle.shutdown.load(Ordering::SeqCst), 1);

        assert!(runtime.reload().await.is_err());
        Ok(())
    }

    #[tokio::test]
    async fn malformed_target_preserves_user_scope_receipt_and_agent() -> Result<(), String> {
        const CHILD_BASE: &str = "EKO_PLUGIN_USER_SCOPE_TEST_BASE";
        let child_base = std::env::var_os(CHILD_BASE).map(PathBuf::from);
        if child_base.is_none() {
            let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
            let output = std::process::Command::new(
                std::env::current_exe().map_err(|error| error.to_string())?,
            )
            .arg("malformed_target_preserves_user_scope_receipt_and_agent")
            .arg("--test-threads=1")
            .env(CHILD_BASE, temp.path().join("plugin-base"))
            .output()
            .map_err(|error| error.to_string())?;
            if output.status.success() {
                return Ok(());
            }
            return Err(format!(
                "isolated User-scope plugin test failed\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            ));
        }
        let child_base = child_base.ok_or_else(|| "missing child plugin base".to_string())?;
        crate::data_root::configure(child_base.clone()).map_err(|current| {
            format!(
                "plugin base was initialized before isolated test: {}",
                current.display()
            )
        })?;

        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let first = temp.path().join("first");
        let second = temp.path().join("second");
        std::fs::create_dir_all(&first).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&second).map_err(|error| error.to_string())?;
        write_fixture_at(child_base.join("plugins/user-fixture"), "user-fixture")?;
        let malformed = write_fixture(&second)?;
        std::fs::write(
            malformed.join("hooks/hooks.yaml"),
            "PreToolUse: [unterminated\n",
        )
        .map_err(|error| error.to_string())?;
        let runtime = default_service(&first).await?;
        let registry = runtime
            .agent_handle
            .read(|agent| agent.subagent_registry().clone())
            .await;
        assert!(registry.contains("user-fixture-specialist").await);
        {
            let state = runtime.state.lock().await;
            assert!(state.framework_components.contains_key("user-fixture"));
            assert!(
                state
                    .prepared
                    .agents
                    .iter()
                    .any(|agent| agent.name() == "user-fixture-specialist")
            );
        }

        let error = runtime
            .rebind_workspace(second.clone())
            .await
            .err()
            .ok_or_else(|| "malformed target plugin unexpectedly committed".to_string())?;
        assert!(error.to_string().contains("User-scope plugin generation"));
        assert_eq!(runtime.workspace_root().await, second);
        assert!(!registry.contains("runtime-fixture-specialist").await);
        assert!(registry.contains("user-fixture-specialist").await);
        let entries = runtime.list().await;
        assert_eq!(entries.len(), 1);
        assert_eq!(
            entries.first().map(|entry| entry.scope),
            Some(PluginScope::User)
        );
        {
            let state = runtime.state.lock().await;
            assert!(state.framework_components.contains_key("user-fixture"));
            assert!(
                state
                    .prepared
                    .agents
                    .iter()
                    .any(|agent| agent.name() == "user-fixture-specialist")
            );
        }
        runtime
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn double_rebind_failure_retires_old_generation_at_target_root() -> Result<(), String> {
        const CHILD_BASE: &str = "EKO_PLUGIN_FAIL_CLOSED_TEST_BASE";
        let child_base = std::env::var_os(CHILD_BASE).map(PathBuf::from);
        if child_base.is_none() {
            let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
            let output = std::process::Command::new(
                std::env::current_exe().map_err(|error| error.to_string())?,
            )
            .arg("double_rebind_failure_retires_old_generation_at_target_root")
            .arg("--test-threads=1")
            .env(CHILD_BASE, temp.path().join("plugin-base"))
            .output()
            .map_err(|error| error.to_string())?;
            if output.status.success() {
                return Ok(());
            }
            return Err(format!(
                "isolated fail-closed plugin test failed\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            ));
        }
        let child_base = child_base.ok_or_else(|| "missing child plugin base".to_string())?;
        crate::data_root::configure(child_base.clone()).map_err(|current| {
            format!(
                "plugin base was initialized before isolated test: {}",
                current.display()
            )
        })?;

        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let first = temp.path().join("first");
        let second = temp.path().join("second");
        std::fs::create_dir_all(&first).map_err(|error| error.to_string())?;
        std::fs::create_dir_all(&second).map_err(|error| error.to_string())?;
        write_fixture(&first)?;
        let target_plugin = write_fixture_at(
            second.join(".echo-agent/plugins/target-fixture"),
            "target-fixture",
        )?;
        let user_plugin = child_base.join("plugins/user-fixture");
        PluginRuntimeService::scaffold(&user_plugin, "user-fixture")
            .map_err(|error| error.to_string())?;

        let runtime = default_service(&first).await?;
        let registry = runtime
            .agent_handle
            .read(|agent| agent.subagent_registry().clone())
            .await;
        assert!(registry.contains("runtime-fixture-specialist").await);
        assert!(registry.contains("user-fixture-specialist").await);
        let lifecycle = Arc::new(LifecycleCounts::default());
        lifecycle
            .shutdown_failures_remaining
            .store(1, Ordering::SeqCst);
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        let cron_store =
            crate::scheduler::CronTaskStore::new().with_path(temp.path().join("cron-tasks.json"));
        let fire_fn: echo_agent::scheduler::FireFn =
            Arc::new(|_| Box::pin(async { Ok("fixture monitor fired".to_string()) }));
        let scheduler = Arc::new(
            SchedulerRunner::new(
                cron_store,
                echo_agent::agent::CancellationToken::new(),
                fire_fn,
            )
            .await
            .map_err(|error| error.to_string())?,
        );
        runtime
            .bind_scheduler(scheduler.clone())
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(scheduler.list_tasks().await.len(), 1);

        std::fs::write(
            target_plugin.join("monitors.yaml"),
            "monitors: [not-a-monitor-definition]\n",
        )
        .map_err(|error| error.to_string())?;
        std::fs::write(
            user_plugin.join("hooks/hooks.yaml"),
            "PreToolUse: [not-a-hook-rule]\n",
        )
        .map_err(|error| error.to_string())?;

        let error = runtime
            .rebind_workspace(second.clone())
            .await
            .err()
            .ok_or_else(|| "double-failure rebind unexpectedly succeeded".to_string())?;
        assert!(
            error
                .to_string()
                .contains("retired all plugin-owned components")
        );
        assert!(error.to_string().contains("degraded User-scope plugins"));
        assert_eq!(runtime.workspace_root().await, second);
        assert!(!registry.contains("runtime-fixture-specialist").await);
        assert!(!registry.contains("target-fixture-specialist").await);
        assert!(!registry.contains("user-fixture-specialist").await);
        assert!(scheduler.list_tasks().await.is_empty());

        assert!(runtime.list().await.is_empty());
        assert_eq!(lifecycle.shutdown.load(Ordering::SeqCst), 1);
        assert_eq!(runtime.cleanup_debt_roots().await, vec![first.clone()]);
        {
            let state = runtime.state.lock().await;
            assert!(state.framework_components.is_empty());
            assert!(state.mcp_ownership.is_empty());
            assert!(state.prepared.agents.is_empty());
            assert!(state.prepared.monitors.is_empty());
        }
        runtime
            .shutdown()
            .await
            .map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_debt_roots().await.is_empty());
        assert_eq!(lifecycle.shutdown.load(Ordering::SeqCst), 2);
        Ok(())
    }

    #[tokio::test]
    async fn failed_real_reload_restores_previous_live_components() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        runtime.reload().await.map_err(|error| error.to_string())?;
        let registry = runtime
            .agent_handle
            .read(|agent| agent.subagent_registry().clone())
            .await;
        assert!(registry.contains("runtime-fixture-specialist").await);
        let cron_store =
            crate::scheduler::CronTaskStore::new().with_path(temp.path().join("cron-tasks.json"));
        let fire_fn: echo_agent::scheduler::FireFn =
            Arc::new(|_| Box::pin(async { Ok("fixture monitor fired".to_string()) }));
        let scheduler = Arc::new(
            SchedulerRunner::new(
                cron_store,
                echo_agent::agent::CancellationToken::new(),
                fire_fn,
            )
            .await
            .map_err(|error| error.to_string())?,
        );
        runtime
            .bind_scheduler(scheduler.clone())
            .await
            .map_err(|error| error.to_string())?;
        runtime
            .activate_output_style(Some("runtime-fixture-concise"))
            .await
            .map_err(|error| error.to_string())?;

        std::fs::write(
            plugin.join("hooks/hooks.yaml"),
            "PreToolUse: [unterminated\n",
        )
        .map_err(|error| error.to_string())?;
        let error = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "malformed hook reload unexpectedly succeeded".to_string())?;
        let rejection = error
            .downcast_ref::<PluginPreparationRejected>()
            .ok_or_else(|| format!("reload did not preserve prepared diagnostics: {error}"))?;
        assert!(rejection.diagnostics.iter().any(|diagnostic| {
            diagnostic.plugin_id() == Some("runtime-fixture")
                && diagnostic.component() == "hooks"
                && diagnostic.severity() == echo_agent::plugin::PluginDiagnosticSeverity::Error
                && diagnostic
                    .path()
                    .is_some_and(|path| path.ends_with("hooks/hooks.yaml"))
        }));
        assert!(
            registry.contains("runtime-fixture-specialist").await,
            "reload rollback did not restore the previous Subagent: {error}"
        );
        assert_eq!(runtime.themes().await.len(), 1);
        assert_eq!(runtime.output_styles().await.len(), 1);
        assert_eq!(
            runtime.active_output_style().await.as_deref(),
            Some("runtime-fixture-concise")
        );
        assert_eq!(scheduler.list_tasks().await.len(), 1);

        Ok(())
    }

    #[tokio::test]
    async fn native_lifecycle_brackets_reload_configure_and_unregisters_on_uninstall()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        let manifest_path = plugin.join("plugin.json");
        let manifest_text =
            std::fs::read_to_string(&manifest_path).map_err(|error| error.to_string())?;
        let mut manifest: serde_json::Value =
            serde_json::from_str(&manifest_text).map_err(|error| error.to_string())?;
        let manifest_object = manifest
            .as_object_mut()
            .ok_or_else(|| "fixture plugin manifest is not an object".to_string())?;
        manifest_object.insert(
            "config".to_string(),
            serde_json::json!({
                "label": {
                    "type": "string",
                    "title": "Label",
                    "default": "initial"
                }
            }),
        );
        std::fs::write(
            &manifest_path,
            serde_json::to_string_pretty(&manifest).map_err(|error| error.to_string())?,
        )
        .map_err(|error| error.to_string())?;
        let runtime = service(temp.path()).await?;
        let counts = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&counts))),
            )
            .await
            .map_err(|error| error.to_string())?;

        runtime.reload().await.map_err(|error| error.to_string())?;
        runtime
            .configure(
                "runtime-fixture",
                HashMap::from([("label".to_string(), serde_json::json!("updated"))]),
            )
            .await
            .map_err(|error| error.to_string())?;

        assert_eq!(counts.init.load(Ordering::SeqCst), 1);
        assert_eq!(counts.activate.load(Ordering::SeqCst), 3);
        assert_eq!(counts.deactivate.load(Ordering::SeqCst), 2);

        runtime
            .uninstall("runtime-fixture", false)
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(counts.deactivate.load(Ordering::SeqCst), 3);
        assert_eq!(counts.shutdown.load(Ordering::SeqCst), 1);

        write_fixture(temp.path())?;
        runtime.reload().await.map_err(|error| error.to_string())?;
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::new(LifecycleCounts::default()))),
            )
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn failed_native_lifecycle_registration_shuts_down_and_can_retry() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let counts = Arc::new(LifecycleCounts::default());
        counts.fail_next_activation.store(true, Ordering::SeqCst);

        let error = runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&counts))),
            )
            .await
            .err()
            .ok_or_else(|| "failing lifecycle registration unexpectedly succeeded".to_string())?;
        assert!(error.to_string().contains("injected activation failure"));
        assert_eq!(counts.init.load(Ordering::SeqCst), 1);
        assert_eq!(counts.activate.load(Ordering::SeqCst), 1);
        assert_eq!(counts.shutdown.load(Ordering::SeqCst), 1);

        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::new(LifecycleCounts::default()))),
            )
            .await
            .map_err(|error| error.to_string())?;
        Ok(())
    }

    #[tokio::test]
    async fn activation_failure_retires_previous_components_and_lifecycle() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let counts = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&counts))),
            )
            .await
            .map_err(|error| error.to_string())?;

        std::fs::write(
            plugin.join("themes/example.json"),
            "{\n  \"name\": \"runtime-fixture-dark\",\n  \"dark\": true,\n  \"colors\": {\"accent\": \"#000000\"}\n}\n",
        )
        .map_err(|error| error.to_string())?;
        counts.fail_next_activation.store(true, Ordering::SeqCst);

        let error = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "lifecycle activation failure unexpectedly succeeded".to_string())?;
        assert!(error.to_string().contains("injected activation failure"));
        let themes = runtime.themes().await;
        let accent = themes
            .first()
            .and_then(|theme| theme.colors.get("accent"))
            .map(String::as_str);
        assert_eq!(accent, None);
        assert_eq!(counts.init.load(Ordering::SeqCst), 1);
        assert_eq!(counts.activate.load(Ordering::SeqCst), 2);
        assert_eq!(counts.deactivate.load(Ordering::SeqCst), 2);

        Ok(())
    }

    #[tokio::test]
    async fn canonical_compose_binds_cold_workspace_owner_before_boot_dispatch()
    -> anyhow::Result<()> {
        const NAME: &str = "plugin_runtime::tests::canonical_compose_binds_cold_workspace_owner_before_boot_dispatch";
        if std::env::var_os("EKO_BOOTSTRAP_ISOLATED").is_none() {
            let directory = tempfile::tempdir()?;
            let output = std::process::Command::new(std::env::current_exe()?)
                .args(["--exact", NAME, "--nocapture"])
                .env("EKO_BOOTSTRAP_ISOLATED", "1")
                .env("EKO_DATA_DIR", directory.path().join("user-data"))
                .output()?;
            assert!(
                output.status.success(),
                "isolated compose failed: {}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            return Ok(());
        }
        let _ = tracing_subscriber::fmt()
            .with_max_level(tracing::Level::INFO)
            .with_test_writer()
            .try_init();
        use crate::runtime::{AgentRuntime, ApplicationLifecycleReason, ApplicationServices};
        use crate::tasks::task_runtime::{
            AttendedMode, DomainProfile, RunPlanPolicy, TaskRunExecutionProfile, TaskRunStatus,
            TaskRuntimeStore,
        };
        use crate::workspace::{
            WorkspaceKind, layout::WorkspaceLayout, registry::WorkspaceRegistry,
        };

        let directory = tempfile::tempdir()?;
        let registry = WorkspaceRegistry::new()?;
        let workspace = registry.create_at(
            "cold-compose",
            WorkspaceKind::General,
            directory.path().join("cold"),
        )?;
        let task_root = WorkspaceLayout::tasks(&workspace.root);
        let store = TaskRuntimeStore::open_for_workspace(&task_root, workspace.id.to_string())?;
        store.create_run_with_profile(
            "cold-original",
            &workspace.id.to_string(),
            "cold-conversation",
            "cold-message",
            DomainProfile::General,
            "Reply once with the requested result",
            "agent_autonomous",
            AttendedMode::Unattended,
            TaskRunExecutionProfile::orchestrated(RunPlanPolicy::AllowDirect),
        )?;
        store.configure_run_continuation("cold-original", true, true, None, None)?;
        store.transition_run("cold-original", TaskRunStatus::Running)?;
        drop(store);

        let entered = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Semaphore::new(0));
        let calls = Arc::new(AtomicUsize::new(0));
        let handler_entered = entered.clone();
        let handler_release = release.clone();
        let handler_calls = calls.clone();
        let router = axum::Router::new().route("/v1/chat/completions", axum::routing::post(move || {
            let entered = handler_entered.clone();
            let release = handler_release.clone();
            let calls = handler_calls.clone();
            async move {
                calls.fetch_add(1, Ordering::SeqCst);
                entered.notify_one();
                if let Ok(permit) = release.acquire().await { permit.forget(); }
                ([(axum::http::header::CONTENT_TYPE, "text/event-stream")], "data: {\"id\":\"cold-original-response\",\"object\":\"chat.completion.chunk\",\"created\":0,\"model\":\"test-model\",\"choices\":[{\"index\":0,\"delta\":{\"content\":\"original completed\"},\"finish_reason\":null}]}\n\ndata: {\"id\":\"cold-original-response\",\"object\":\"chat.completion.chunk\",\"created\":0,\"model\":\"test-model\",\"choices\":[{\"index\":0,\"delta\":{},\"finish_reason\":\"stop\"}]}\n\ndata: [DONE]\n\n")
            }
        }));
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let (server_stop, server_stopped) = tokio::sync::oneshot::channel();
        let server = tokio::spawn(async move {
            axum::serve(listener, router)
                .with_graceful_shutdown(async {
                    let _ = server_stopped.await;
                })
                .await
        });
        let mut config = crate::config::EkoConfig::default();
        config.model.default_model_id = Some("fixture:test-model".to_string());
        config.model_providers.insert(
            "fixture".to_string(),
            crate::config::ModelProviderConfig {
                base_url: Some(format!("http://{address}/v1")),
                requires_api_key: false,
                ..Default::default()
            },
        );
        config
            .configured_models
            .push(crate::config::ConfiguredModel {
                id: "fixture:test-model".to_string(),
                provider: "fixture".to_string(),
                model: "test-model".to_string(),
                ..Default::default()
            });
        let project = directory.path().join("project");
        std::fs::create_dir_all(&project)?;
        let browser = crate::browser::BrowserRuntime::start(crate::browser::BrowserConfig {
            enabled: false,
            extension_enabled: false,
            session_dir: directory.path().join("browser"),
            ..Default::default()
        })
        .await;
        let runtime = Arc::new(
            AgentRuntime::bootstrap(
                &config,
                crate::infra::AgentCreateParams {
                    working_dir: Some(project),
                    browser_runtime: Some(browser),
                    ..Default::default()
                },
                directory.path().join("missing-mcp.json"),
            )
            .await?,
        );
        // The real plugin scheduler read guard lets pool initialization and
        // boot admission proceed, but holds compose before its late state bind.
        let plugin = runtime.plugin_runtime.clone();
        let scheduler_guard = plugin.scheduler.read().await;
        let runtime_for_compose = runtime.clone();
        let compose = tokio::spawn(async move {
            ApplicationServices::compose(
                &runtime_for_compose,
                None,
                None,
                echo_agent::tools::permission::PermissionMode::Default,
            )
            .await
        });
        let reached_boot_resume = AtomicBool::new(false);
        let reached_late_bind = AtomicBool::new(false);
        let observation = tokio::time::timeout(std::time::Duration::from_secs(10), async {
            loop {
                let cold =
                    TaskRuntimeStore::open_for_workspace(&task_root, workspace.id.to_string())?;
                let resumed = cold.list_events("cold-original", 0)?.iter().any(|event| {
                    event.event_type
                        == crate::tasks::task_runtime::RuntimeEventKind::RunContinuationResumed
                });
                if resumed {
                    reached_boot_resume.store(true, Ordering::SeqCst);
                }
                if resumed && plugin.state.try_lock().is_err() {
                    reached_late_bind.store(true, Ordering::SeqCst);
                    break;
                }
                tokio::task::yield_now().await;
            }
            entered.notified().await;
            Ok::<_, anyhow::Error>(())
        })
        .await;
        let compose_was_held = !compose.is_finished();
        // Always release the actual provider and plugin locks, and join the
        // real compose/shutdown/server before reporting a failed observation.
        release.add_permits(16);
        drop(scheduler_guard);
        let services = compose.await??;
        let shutdown = services
            .settle(ApplicationLifecycleReason::Shutdown, None)
            .await;
        let _ = server_stop.send(());
        server.await??;
        shutdown.into_result()?;
        assert!(
            compose_was_held,
            "compose bypassed its original scheduler bind barrier"
        );
        if observation.is_err() {
            let cold = TaskRuntimeStore::open_for_workspace(&task_root, workspace.id.to_string())?;
            eprintln!(
                "compose observation phases: boot_resumed={} late_bind={} provider_calls={} run={:?} journal={}",
                reached_boot_resume.load(Ordering::SeqCst),
                reached_late_bind.load(Ordering::SeqCst),
                calls.load(Ordering::SeqCst),
                cold.get_run("cold-original")?,
                serde_json::to_string(&cold.list_events("cold-original", 0)?)?
            );
        }
        observation??;
        assert_eq!(
            calls.load(Ordering::SeqCst),
            1,
            "cold boot must dispatch the original run exactly once"
        );
        Ok(())
    }

    #[tokio::test]
    async fn scheduler_binding_uses_the_same_lock_order_as_reload() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let runtime = service(temp.path()).await?;
        let cron_store =
            crate::scheduler::CronTaskStore::new().with_path(temp.path().join("cron-tasks.json"));
        let fire_fn: echo_agent::scheduler::FireFn =
            Arc::new(|_| Box::pin(async { Ok("fixture monitor fired".to_string()) }));
        let scheduler = Arc::new(
            SchedulerRunner::new(
                cron_store,
                echo_agent::agent::CancellationToken::new(),
                fire_fn,
            )
            .await
            .map_err(|error| error.to_string())?,
        );

        let state_guard = runtime.state.lock().await;
        let (started, bind_started) = tokio::sync::oneshot::channel();
        let runtime_for_bind = runtime.clone();
        let bind = tokio::spawn(async move {
            let _ = started.send(());
            runtime_for_bind
                .bind_scheduler(scheduler)
                .await
                .map_err(|error| error.to_string())
        });
        bind_started
            .await
            .map_err(|_| "scheduler bind task stopped before starting".to_string())?;
        tokio::task::yield_now().await;

        let scheduler_guard = tokio::time::timeout(
            std::time::Duration::from_millis(250),
            runtime.scheduler.read(),
        )
        .await
        .map_err(|_| "scheduler lock was acquired before plugin state lock".to_string())?;
        drop(scheduler_guard);
        drop(state_guard);

        let monitor_count = tokio::time::timeout(std::time::Duration::from_secs(2), bind)
            .await
            .map_err(|_| "scheduler binding deadlocked".to_string())?
            .map_err(|error| error.to_string())??;
        assert_eq!(monitor_count, 0);
        Ok(())
    }

    #[tokio::test]
    async fn theme_and_output_style_preferences_survive_runtime_restart() -> Result<(), String> {
        let temporary = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temporary.path())?;
        let runtime = service(temporary.path()).await?;
        runtime
            .activate_theme(Some("runtime-fixture-dark"))
            .await
            .map_err(|error| error.to_string())?;
        runtime
            .activate_output_style(Some("runtime-fixture-concise"))
            .await
            .map_err(|error| error.to_string())?;
        drop(runtime);

        let restored = service(temporary.path()).await?;

        assert_eq!(
            restored.active_theme().await.as_deref(),
            Some("runtime-fixture-dark")
        );
        assert_eq!(
            restored.active_output_style().await.as_deref(),
            Some("runtime-fixture-concise")
        );
        let messages = restored
            .agent_handle
            .read_async(|agent| Box::pin(async move { agent.get_messages().await }))
            .await;
        assert!(messages.iter().any(|message| {
            message
                .content
                .as_text_ref()
                .is_some_and(|content| content.contains("Answer directly"))
        }));
        Ok(())
    }

    async fn service_with_ownership(
        root: &Path,
        ownership: Arc<McpNameOwnershipRegistry>,
    ) -> Result<Arc<PluginRuntimeService>, String> {
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("plugin runtime ownership integration test")
            .enable_tools()
            .enable_subagent()
            .register_agent_dispatch_tool()
            .working_dir(root)
            .build()
            .map_err(|error| error.to_string())?;
        PluginRuntimeService::new_for_test_with_ownership(
            AgentHandle::new(agent),
            root.to_path_buf(),
            root.join("registry.json"),
            root.join("plugin-data"),
            ownership,
        )
        .await
        .map_err(|error| error.to_string())
    }

    /// Declare one MCP server whose transport is unreachable. Connection failure
    /// is a warning in the framework, so the plugin still claims its name.
    fn write_mcp_fixture(plugin: &Path, server_name: &str) -> Result<(), String> {
        let config = serde_json::json!({
            "$schema": "https://agent-plugins.org/schemas/1.0.0/mcp.schema.json",
            "mcpServers": {
                server_name: {"type": "streamable-http", "url": "http://127.0.0.1:9/mcp"}
            }
        });
        std::fs::write(
            plugin.join("mcp.json"),
            serde_json::to_string_pretty(&config).map_err(|error| error.to_string())?,
        )
        .map_err(|error| error.to_string())
    }

    async fn claim_token(
        runtime: &PluginRuntimeService,
        plugin_id: &str,
        name: &str,
    ) -> Result<PluginMcpOwnershipToken, String> {
        runtime
            .state
            .lock()
            .await
            .mcp_ownership
            .get(plugin_id)
            .and_then(|tokens| tokens.get(name))
            .copied()
            .ok_or_else(|| format!("missing MCP ownership token for '{plugin_id}:{name}'"))
    }

    async fn test_scheduler(root: &Path) -> Result<Arc<SchedulerRunner>, String> {
        let cron_store =
            crate::scheduler::CronTaskStore::new().with_path(root.join("cron-tasks.json"));
        let fire_fn: echo_agent::scheduler::FireFn =
            Arc::new(|_| Box::pin(async { Ok("fixture monitor fired".to_string()) }));
        SchedulerRunner::new(
            cron_store,
            echo_agent::agent::CancellationToken::new(),
            fire_fn,
        )
        .await
        .map(Arc::new)
        .map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn failed_install_retains_cleanup_receipt_with_exact_mcp_token_and_retries()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let ownership = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let alpha = write_fixture_at(
            temp.path().join(".echo-agent/plugins/alpha-fixture"),
            "alpha-fixture",
        )?;
        write_mcp_fixture(&alpha, "alpha")?;
        let runtime = service_with_ownership(temp.path(), Arc::clone(&ownership)).await?;
        let alpha_token = claim_token(&runtime, "alpha-fixture", "alpha").await?;

        // The install itself succeeds up to activation; the failure happens after
        // the candidate generation already claimed its MCP names.
        let lifecycle = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "alpha-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        lifecycle.fail_next_activation.store(true, Ordering::SeqCst);

        let beta_source = write_fixture_at(temp.path().join("beta-source"), "beta-fixture")?;
        write_mcp_fixture(&beta_source, "beta")?;
        let error = runtime
            .install(&InstallSource::Local(beta_source), PluginScope::Project)
            .await
            .err()
            .ok_or_else(|| "failing install unexpectedly succeeded".to_string())?;
        assert!(error.to_string().contains("injected activation failure"));
        assert!(runtime.get("beta-fixture").await.is_none());
        assert!(
            !temp
                .path()
                .join(".echo-agent/plugins/beta-fixture")
                .exists()
        );

        let receipts = runtime.cleanup_receipts().await;
        assert_eq!(receipts.len(), 1, "retained receipts: {receipts:?}");
        let retained = receipts
            .first()
            .ok_or_else(|| "failed install retained no cleanup receipt".to_string())?;
        let claims = retained.mcp_claims();
        let alpha_claim = claims
            .iter()
            .find(|claim| claim.plugin_id() == "alpha-fixture" && claim.name() == "alpha")
            .ok_or_else(|| "receipt lost the exact alpha ownership token".to_string())?;
        let retained_alpha_token = alpha_claim.token();
        assert!(
            claims
                .iter()
                .any(|claim| claim.plugin_id() == "beta-fixture" && claim.name() == "beta"),
            "receipt lost the partially installed beta token: {claims:?}"
        );
        assert_eq!(
            runtime.cleanup_debt_roots().await,
            vec![temp.path().to_path_buf()]
        );
        {
            let guard = ownership.lock().await;
            // The candidate rewire reclaimed the name before the failure, so the
            // receipt must carry that exact live token, not the older one.
            assert!(guard.owns_plugin("alpha-fixture", "alpha", retained_alpha_token));
            assert!(!guard.owns_plugin("alpha-fixture", "alpha", alpha_token));
        }

        // Every owned mutation retries receipts before it may report success.
        runtime.reload().await.map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_receipts().await.is_empty());
        assert!(runtime.cleanup_debt_roots().await.is_empty());
        let refreshed = claim_token(&runtime, "alpha-fixture", "alpha").await?;
        assert_ne!(refreshed, retained_alpha_token);
        {
            let guard = ownership.lock().await;
            assert!(!guard.owns_plugin("alpha-fixture", "alpha", retained_alpha_token));
            assert!(guard.owns_plugin("alpha-fixture", "alpha", refreshed));
        }
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn failed_uninstall_retains_lifecycle_cleanup_receipt_and_retries() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let lifecycle = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        lifecycle
            .shutdown_failures_remaining
            .store(1, Ordering::SeqCst);

        let error = runtime
            .uninstall("runtime-fixture", false)
            .await
            .err()
            .ok_or_else(|| "failing uninstall unexpectedly succeeded".to_string())?;
        assert!(error.to_string().contains("injected shutdown failure"));
        assert!(!plugin.exists());
        assert!(runtime.get("runtime-fixture").await.is_none());
        let receipts = runtime.cleanup_receipts().await;
        assert_eq!(receipts.len(), 1, "retained receipts: {receipts:?}");
        assert!(
            receipts
                .iter()
                .any(|receipt| receipt.plugin_id() == Some("runtime-fixture")
                    && receipt.describe().contains("lifecycle")),
            "uninstall did not retain its lifecycle cleanup receipt: {receipts:?}"
        );
        assert_eq!(
            runtime.cleanup_debt_roots().await,
            vec![temp.path().to_path_buf()]
        );

        runtime.reload().await.map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_receipts().await.is_empty());
        assert!(runtime.cleanup_debt_roots().await.is_empty());
        assert_eq!(lifecycle.shutdown.load(Ordering::SeqCst), 2);
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn cancelled_uninstall_waiter_still_retains_cleanup_receipt() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let lifecycle = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        lifecycle
            .shutdown_failures_remaining
            .store(1, Ordering::SeqCst);

        // Hold the state lock so the admitted settlement parks in the real
        // uninstall path; aborting the caller must not cancel or drop the receipt.
        let state_guard = runtime.state.lock().await;
        let (started, started_rx) = tokio::sync::oneshot::channel();
        let waiter_runtime = Arc::clone(&runtime);
        let waiter = tokio::spawn(async move {
            waiter_runtime
                .run_owned_mutation(move |service| async move {
                    let _ = started.send(());
                    service.uninstall_inner("runtime-fixture", false).await
                })
                .await
        });
        started_rx
            .await
            .map_err(|_| "owned plugin uninstall never started".to_string())?;
        waiter.abort();
        let _ = waiter.await;
        drop(state_guard);

        let settled = tokio::time::timeout(std::time::Duration::from_secs(10), async {
            loop {
                if runtime.get("runtime-fixture").await.is_none()
                    && !runtime.cleanup_receipts().await.is_empty()
                {
                    break;
                }
                tokio::task::yield_now().await;
            }
        })
        .await;
        if settled.is_err() {
            let receipts = runtime.cleanup_receipts().await;
            let present = runtime.get("runtime-fixture").await.is_some();
            let settlements = runtime.mutation_supervisor.lock().await.settlements.len();
            return Err(format!(
                "cancelled plugin uninstall lost its cleanup receipt: plugin_present={present}, receipts={}, shutdowns={}, settlements={settlements}",
                receipts.len(),
                lifecycle.shutdown.load(Ordering::SeqCst),
            ));
        }

        let receipts = runtime.cleanup_receipts().await;
        assert!(
            receipts
                .iter()
                .any(|receipt| receipt.plugin_id() == Some("runtime-fixture")),
            "cancelled uninstall did not retain its receipt: {receipts:?}"
        );
        runtime.reload().await.map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_receipts().await.is_empty());
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn same_name_takeover_is_rejected_without_releasing_the_owner_token() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let ownership = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let alpha = write_fixture_at(
            temp.path().join(".echo-agent/plugins/alpha-fixture"),
            "alpha-fixture",
        )?;
        write_mcp_fixture(&alpha, "shared")?;
        ownership
            .claim_user_names(["user-shared".to_string()])
            .await;
        let runtime = service_with_ownership(temp.path(), Arc::clone(&ownership)).await?;
        let alpha_token = claim_token(&runtime, "alpha-fixture", "shared").await?;

        // A second enabled plugin declaring the incumbent name is rejected before
        // any ownership token is taken.
        let beta_source = write_fixture_at(temp.path().join("beta-source"), "beta-fixture")?;
        write_mcp_fixture(&beta_source, "shared")?;
        let error = runtime
            .install(&InstallSource::Local(beta_source), PluginScope::Project)
            .await
            .err()
            .ok_or_else(|| "same-name plugin takeover unexpectedly succeeded".to_string())?;
        assert!(
            error
                .to_string()
                .contains("is declared by both 'alpha-fixture' and 'beta-fixture'"),
            "install error: {error}"
        );
        assert!(
            !temp
                .path()
                .join(".echo-agent/plugins/beta-fixture")
                .exists()
        );
        assert!(
            runtime.cleanup_receipts().await.is_empty(),
            "a rejected takeover must not fabricate a cleanup receipt"
        );

        // A user-configured name is also rejected by the ownership authority.
        let gamma_source = write_fixture_at(temp.path().join("gamma-source"), "gamma-fixture")?;
        write_mcp_fixture(&gamma_source, "user-shared")?;
        let error = runtime
            .install(&InstallSource::Local(gamma_source), PluginScope::Project)
            .await
            .err()
            .ok_or_else(|| "user-owned MCP name takeover unexpectedly succeeded".to_string())?;
        assert!(
            error.to_string().contains("owned by user configuration"),
            "install error: {error}"
        );
        assert!(runtime.cleanup_receipts().await.is_empty());
        {
            let guard = ownership.lock().await;
            assert!(
                guard.owns_plugin("alpha-fixture", "shared", alpha_token),
                "rejected takeover released the incumbent plugin token"
            );
            assert!(
                guard
                    .validate_plugin_claim("gamma-fixture", "user-shared", None)
                    .err()
                    .is_some_and(|error| error.contains("user configuration"))
            );
        }

        // A stale receipt carrying another plugin's token settles as a no-op and
        // can never release a name it does not own.
        let stale = CleanupReceipt::mcp_names(
            temp.path().to_path_buf(),
            "stale receipt from a partial install".to_string(),
            vec![PluginMcpNameClaim::new(
                "beta-fixture".to_string(),
                "shared".to_string(),
                alpha_token,
            )],
        );
        runtime
            .adopt_cleanup_receipts(vec![stale.clone()])
            .await
            .map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_receipts().await.is_empty());
        {
            let guard = ownership.lock().await;
            assert!(
                guard.owns_plugin("alpha-fixture", "shared", alpha_token),
                "a receipt carrying a foreign plugin id released the owner token"
            );
        }

        // Retrying the same receipt is an idempotent no-op, never a double release.
        runtime
            .adopt_cleanup_receipts(vec![stale])
            .await
            .map_err(|error| error.to_string())?;
        {
            let guard = ownership.lock().await;
            assert!(guard.owns_plugin("alpha-fixture", "shared", alpha_token));
        }

        // An explicit user takeover is a hand-over, not a plugin release.
        ownership.claim_user_names(["shared".to_string()]).await;
        let handed_over = CleanupReceipt::mcp_names(
            temp.path().to_path_buf(),
            "hand-over receipt".to_string(),
            vec![PluginMcpNameClaim::new(
                "alpha-fixture".to_string(),
                "shared".to_string(),
                alpha_token,
            )],
        );
        runtime
            .adopt_cleanup_receipts(vec![handed_over])
            .await
            .map_err(|error| error.to_string())?;
        {
            let guard = ownership.lock().await;
            assert!(!guard.owns_plugin("alpha-fixture", "shared", alpha_token));
            assert!(
                guard
                    .validate_plugin_claim("alpha-fixture", "shared", Some(alpha_token))
                    .err()
                    .is_some_and(|error| error.contains("user configuration")),
                "user takeover was not preserved"
            );
        }
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn partial_receipt_settlement_is_not_success_until_every_obligation_settles()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let ownership = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let orphan_token = {
            let mut guard = ownership.lock().await;
            guard
                .claim_plugin("stale-plugin", "stale-name")
                .map_err(|error| error.to_string())?
        };
        let alpha = write_fixture_at(
            temp.path().join(".echo-agent/plugins/alpha-fixture"),
            "alpha-fixture",
        )?;
        write_mcp_fixture(&alpha, "alpha")?;
        let runtime = service_with_ownership(temp.path(), Arc::clone(&ownership)).await?;
        let alpha_token = claim_token(&runtime, "alpha-fixture", "alpha").await?;

        let claim_receipt = CleanupReceipt::mcp_names(
            temp.path().to_path_buf(),
            "partial install".to_string(),
            vec![PluginMcpNameClaim::new(
                "stale-plugin".to_string(),
                "stale-name".to_string(),
                orphan_token,
            )],
        );
        let monitor_receipt = CleanupReceipt::monitors(
            temp.path().to_path_buf(),
            "stale plugin monitor".to_string(),
            vec![CronTask::new(
                "stale-plugin-monitor",
                "0 0 * * * *",
                "stale plugin monitor",
            )],
        );
        let error = runtime
            .adopt_cleanup_receipts(vec![claim_receipt, monitor_receipt])
            .await
            .err()
            .ok_or_else(|| "unsettleable monitor receipt was reported as settled".to_string())?;
        assert!(
            error
                .to_string()
                .contains("cleanup receipts remain unsettled")
        );
        {
            let guard = ownership.lock().await;
            assert!(
                !guard.owns_plugin("stale-plugin", "stale-name", orphan_token),
                "the settleable half of the partial recovery was not settled"
            );
            assert!(
                guard.owns_plugin("alpha-fixture", "alpha", alpha_token),
                "partial recovery released a live plugin token"
            );
        }
        assert_eq!(runtime.cleanup_receipts().await.len(), 1);

        let reload_error = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "reload reported success with an unsettled receipt".to_string())?;
        assert!(
            reload_error
                .to_string()
                .contains("cleanup receipts remain unsettled")
        );
        assert_eq!(runtime.cleanup_receipts().await.len(), 1);

        let scheduler = test_scheduler(temp.path()).await?;
        runtime
            .bind_scheduler(Arc::clone(&scheduler))
            .await
            .map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_receipts().await.is_empty());
        assert!(runtime.cleanup_debt_roots().await.is_empty());
        assert_eq!(scheduler.list_tasks().await.len(), 1);
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn bootstrap_failure_exports_retained_cleanup_receipts_with_exact_tokens()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture_at(
            temp.path().join(".echo-agent/plugins/alpha-fixture"),
            "alpha-fixture",
        )?;
        write_mcp_fixture(&plugin, "alpha")?;
        let runtime = service(temp.path()).await?;
        let lifecycle = Arc::new(LifecycleCounts::default());
        runtime
            .register_lifecycle(
                "alpha-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        lifecycle.fail_next_activation.store(true, Ordering::SeqCst);
        let reload_error = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "failing reload unexpectedly succeeded".to_string())?;

        // This is exactly the conversion `new_owned` uses when the initial
        // generation fails: the failed service hands its receipts to the caller.
        let failure = runtime.into_bootstrap_failure(reload_error).await;
        assert!(
            failure
                .error()
                .to_string()
                .contains("injected activation failure")
        );
        let receipts = failure.receipts();
        assert_eq!(receipts.len(), 1, "retained receipts: {receipts:?}");
        let claims = receipts
            .iter()
            .next()
            .ok_or_else(|| "bootstrap failure retained no receipt".to_string())?
            .mcp_claims();
        assert!(
            claims
                .iter()
                .any(|claim| claim.plugin_id() == "alpha-fixture" && claim.name() == "alpha"),
            "bootstrap failure lost its exact ownership tokens: {claims:?}"
        );
        let (error, receipts) = failure.into_parts();
        assert!(error.to_string().contains("injected activation failure"));
        assert_eq!(receipts.len(), 1);
        // Dropping these would park them in the process ledger; this test owns
        // them explicitly instead so the ledger stays clean for other tests.
        assert_eq!(receipts.park().len(), 1);
        Ok(())
    }

    #[tokio::test]
    async fn owned_constructor_maps_rejected_generation_into_bootstrap_failure()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        std::fs::write(plugin.join("agents/example.md"), "not valid frontmatter")
            .map_err(|error| error.to_string())?;
        let agent = ReactAgentBuilder::new()
            .llm_client(Arc::new(MockLlmClient::new()))
            .system_prompt("owned constructor rejection test")
            .working_dir(temp.path())
            .build()
            .map(AgentHandle::new)
            .map_err(|error| error.to_string())?;

        let failure = PluginRuntimeService::new_for_test_owned(
            agent,
            temp.path().to_path_buf(),
            temp.path().join("registry.json"),
            temp.path().join("plugin-data"),
            McpNameOwnershipRegistry::new(Vec::<String>::new()),
        )
        .await
        .err()
        .ok_or_else(|| "invalid initial generation unexpectedly bootstrapped".to_string())?;

        assert!(
            failure.error().to_string().contains("frontmatter"),
            "bootstrap error: {}",
            failure.error()
        );
        assert!(failure.receipts().is_empty());
        assert!(failure.to_string().contains("cleanup receipt(s) retained"));
        Ok(())
    }

    #[test]
    fn scaffold_and_validate_cover_application_components() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = temp.path().join("scaffolded");
        PluginRuntimeService::scaffold(&plugin, "scaffolded").map_err(|error| error.to_string())?;
        for expected_file in [
            "plugin.json",
            "skills/scaffolded-example/SKILL.md",
            "agents/example.md",
            "hooks/hooks.yaml",
            "mcp.json",
            "monitors.yaml",
            "themes/example.json",
            "output-styles/scaffolded-concise.md",
            "README.md",
        ] {
            assert!(
                plugin.join(expected_file).is_file(),
                "missing scaffold file {expected_file}"
            );
        }
        assert!(plugin.join("scripts").is_dir());
        assert!(!plugin.join("lsp.yaml").exists());
        assert!(!plugin.join(".echo-plugin").exists());
        assert!(!plugin.join(".mcp.json").exists());
        let report = PluginRuntimeService::validate(&plugin);
        assert!(report.valid, "{}", report.errors.join("; "));
        for expected in [
            "skills",
            "agents",
            "hooks",
            "mcp_servers",
            "monitors",
            "themes",
            "output_styles",
        ] {
            assert!(
                report
                    .components
                    .iter()
                    .any(|component| component == expected)
            );
        }
        Ok(())
    }

    #[test]
    fn validate_rejects_malformed_runtime_components() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = temp.path().join("invalid-components");
        PluginRuntimeService::scaffold(&plugin, "invalid-components")
            .map_err(|error| error.to_string())?;
        std::fs::write(
            plugin.join("hooks/hooks.yaml"),
            "PreToolUse:\n  - matcher: '*'\n    hooks:\n      - type: command\n        command: ''\n",
        )
        .map_err(|error| error.to_string())?;
        std::fs::write(
            plugin.join("mcp.json"),
            r#"{"$schema":"invalid","mcpServers":{}}"#,
        )
        .map_err(|error| error.to_string())?;
        std::fs::write(
            plugin.join("skills/invalid-components-example/SKILL.md"),
            "This file has no frontmatter.\n",
        )
        .map_err(|error| error.to_string())?;

        let report = PluginRuntimeService::validate(&plugin);

        assert!(!report.valid);
        assert!(
            report
                .errors
                .iter()
                .any(|error| error.contains("empty command"))
        );
        assert!(
            report
                .errors
                .iter()
                .any(|error| error.contains("MCP config"))
        );
        assert!(
            report
                .errors
                .iter()
                .any(|error| error.contains("must begin with YAML frontmatter"))
        );
        Ok(())
    }

    // ── Receipt ownership regressions (R-T2) ──
    //
    // Three defects are covered here:
    //   A. A production bootstrap failure must not downcast its cleanup
    //      receipts to log text.
    //   B. A replacement whose previous framework withdrawal fails must keep the
    //      exact wiring receipt and MCP tokens, stop the replacement, and never
    //      release a name whose client is still connected.
    //   C. Cancelling a retry mid-await must leave the receipt in the ledger.

    /// Re-run one test in a child process with an isolated product data root.
    ///
    /// `RegistrySource::Default` scans the process-wide EKO data root, so a real
    /// `AgentRuntime` bootstrap must not see (or write to) the developer's
    /// `~/.eko`. The child owns a throwaway root and a private parked-receipt
    /// ledger for the whole process lifetime.
    fn isolated_bootstrap_child(name: &str) -> Result<bool, String> {
        if std::env::var_os("EKO_BOOTSTRAP_ISOLATED").is_some() {
            return Ok(false);
        }
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let output =
            std::process::Command::new(std::env::current_exe().map_err(|error| error.to_string())?)
                .args(["--exact", name, "--nocapture"])
                .env("EKO_BOOTSTRAP_ISOLATED", "1")
                .env("EKO_DATA_DIR", temp.path().join("user-data"))
                .output()
                .map_err(|error| error.to_string())?;
        if !output.status.success() {
            return Err(format!(
                "isolated bootstrap test failed: {}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            ));
        }
        Ok(true)
    }

    fn bootstrap_test_config() -> crate::config::EkoConfig {
        let mut config = crate::config::EkoConfig::default();
        config.model.default_model_id = Some("fixture:test-model".to_string());
        config.model_providers.insert(
            "fixture".to_string(),
            crate::config::ModelProviderConfig {
                base_url: Some("http://127.0.0.1:9/v1".to_string()),
                requires_api_key: false,
                ..Default::default()
            },
        );
        config
            .configured_models
            .push(crate::config::ConfiguredModel {
                id: "fixture:test-model".to_string(),
                provider: "fixture".to_string(),
                model: "test-model".to_string(),
                ..Default::default()
            });
        config
    }

    /// Defect A: the real `AgentRuntime` bootstrap consumer must hand a failed
    /// generation's receipts to a live owner instead of dropping them.
    #[test]
    fn bootstrap_failure_parks_receipts_owned_by_the_next_bootstrap() -> Result<(), String> {
        const NAME: &str =
            "plugin_runtime::tests::bootstrap_failure_parks_receipts_owned_by_the_next_bootstrap";
        if isolated_bootstrap_child(NAME)? {
            return Ok(());
        }
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|error| error.to_string())?;
        runtime.block_on(async move {
            let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
            let project = temp.path().join("project");
            std::fs::create_dir_all(&project).map_err(|error| error.to_string())?;
            let project = std::fs::canonicalize(&project).map_err(|error| error.to_string())?;
            let plugin = project.join(".echo-agent/plugins/bootstrap-fixture");
            PluginRuntimeService::scaffold(&plugin, "bootstrap-fixture")
                .map_err(|error| error.to_string())?;
            // The candidate generation claims its MCP name while wiring, then
            // fails while registering its Subagent (`max_turns: 0` is rejected by
            // the builder). That is the production bootstrap shape that leaves an
            // exact cleanup claim behind.
            std::fs::write(
                plugin.join("mcp.json"),
                serde_json::json!({
                    "$schema": "https://agent-plugins.org/schemas/1.0.0/mcp.schema.json",
                    "mcpServers": {"bootstrap": {"type": "streamable-http", "url": "http://127.0.0.1:9/mcp"}}
                })
                .to_string(),
            )
            .map_err(|error| error.to_string())?;
            std::fs::write(
                plugin.join("agents/example.md"),
                "---\nname: bootstrap-fixture-specialist\ndescription: Bootstrap fixture Subagent\nreadonly: true\nmax_turns: 0\n---\nReturn the requested result.\n",
            )
            .map_err(|error| error.to_string())?;

            let error = bootstrap_runtime(temp.path(), &project)
                .await
                .err()
                .ok_or_else(|| {
                    "plugin bootstrap with an unwireable MCP server unexpectedly succeeded"
                        .to_string()
                })?;
            let rendered = error.to_string();
            assert!(
                rendered.contains("Plugin Subagent registration failed"),
                "fixture did not reach the post-claim bootstrap failure: {rendered}"
            );
            assert!(
                rendered.contains("process retry ledger"),
                "bootstrap error must report the parked receipts: {rendered}"
            );

            // The receipt object survived: a live owner still knows the exact
            // plugin:name claim, not merely a formatted log line.
            let parked = parked_cleanup_receipts_for_root(&project);
            assert!(
                !parked.is_empty(),
                "bootstrap failure dropped every cleanup receipt"
            );
            assert!(
                parked
                    .iter()
                    .flat_map(|receipt| receipt.mcp_claims())
                    .any(|claim| claim.plugin_id() == "bootstrap-fixture"
                        && claim.name() == "bootstrap"),
                "parked receipt lost the exact ownership claim: {parked:?}"
            );
            assert!(
                parked_cleanup_debt_roots().contains(&project),
                "parked debt roots must report the failed project"
            );

            // The next real bootstrap for this root adopts and settles the debt.
            std::fs::write(
                plugin.join("agents/example.md"),
                "---\nname: bootstrap-fixture-specialist\ndescription: Bootstrap fixture Subagent\nreadonly: true\nmax_turns: 4\n---\nReturn the requested result.\n",
            )
            .map_err(|error| error.to_string())?;
            let restarted = bootstrap_runtime(temp.path(), &project)
                .await
                .map_err(|error| format!("second plugin bootstrap failed: {error}"))?;
            assert!(
                restarted.plugin_runtime.cleanup_receipts().await.is_empty(),
                "the adopting runtime kept parked receipts in its own ledger"
            );
            assert!(
                parked_cleanup_receipts_for_root(&project).is_empty(),
                "the parked receipt was not taken over by the next bootstrap"
            );
            restarted
                .plugin_runtime
                .shutdown()
                .await
                .map_err(|error| error.to_string())?;
            Ok(())
        })
    }

    async fn bootstrap_runtime(
        temp_root: &Path,
        project: &Path,
    ) -> anyhow::Result<crate::runtime::AgentRuntime> {
        let browser = crate::browser::BrowserRuntime::start(crate::browser::BrowserConfig {
            enabled: false,
            extension_enabled: false,
            session_dir: temp_root.join("browser"),
            ..Default::default()
        })
        .await;
        crate::runtime::AgentRuntime::bootstrap(
            &bootstrap_test_config(),
            crate::infra::AgentCreateParams {
                working_dir: Some(project.to_path_buf()),
                browser_runtime: Some(browser),
                ..Default::default()
            },
            temp_root.join("missing-mcp.json"),
        )
        .await
    }

    /// Publish a newer framework generation behind the runtime's back.
    ///
    /// The runtime still holds the earlier receipt, so the real
    /// `PluginIntegrator` now refuses to roll it back (`StaleReceipt`). That is a
    /// genuine withdrawal failure produced by the framework, not a test seam.
    async fn supersede_framework_generation(
        runtime: &Arc<PluginRuntimeService>,
    ) -> Result<u64, String> {
        let root = runtime.project_root().await;
        let receipt = runtime
            .state
            .lock()
            .await
            .framework_receipt
            .clone()
            .ok_or_else(|| "runtime has no framework wiring receipt".to_string())?;
        runtime
            .agent_handle
            .write_async(|agent| {
                let integrator = runtime.integrator.clone();
                Box::pin(async move {
                    integrator
                        .rollback(agent, &receipt)
                        .await
                        .map_err(|error| error.to_string())
                })
            })
            .await?;
        let mut registry = runtime.registry_for(root);
        runtime
            .scan_registry(&mut registry)
            .map_err(|error| error.to_string())?;
        let superseding = runtime.integrator.prepare(&mut registry).await;
        let wired = runtime
            .agent_handle
            .write_async(|agent| {
                let integrator = runtime.integrator.clone();
                Box::pin(async move {
                    integrator
                        .wire_prepared(agent, superseding.as_ref())
                        .await
                        .map_err(|error| error.to_string())
                })
            })
            .await?;
        Ok(wired.generation())
    }

    /// Defect B: replacement must stop and keep the exact wiring receipt and
    /// tokens when the previous generation cannot be withdrawn.
    #[tokio::test]
    async fn replacement_with_unwithdrawable_generation_keeps_claims_and_receipt()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let ownership = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let alpha = write_fixture_at(
            temp.path().join(".echo-agent/plugins/alpha-fixture"),
            "alpha-fixture",
        )?;
        write_mcp_fixture(&alpha, "shared")?;
        let runtime = service_with_ownership(temp.path(), Arc::clone(&ownership)).await?;
        let owner_token = claim_token(&runtime, "alpha-fixture", "shared").await?;

        let superseding_generation = supersede_framework_generation(&runtime).await?;
        assert!(
            superseding_generation > 0,
            "framework generation was not superseded"
        );

        // A candidate that re-declares the same name for the same owner.
        let beta = write_fixture_at(
            temp.path().join(".echo-agent/plugins/beta-fixture"),
            "beta-fixture",
        )?;
        write_mcp_fixture(&beta, "beta")?;

        let error = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "replacement unexpectedly reported success".to_string())?;
        assert!(
            error
                .to_string()
                .contains("framework plugin rollback failed before replacement"),
            "replacement did not stop at the failed withdrawal: {error}"
        );

        // The exact old token still owns the name: nothing was released while the
        // old MCP client is still attached to the Agent, and no fresh owner may
        // take the name over.
        {
            let mut guard = ownership.lock().await;
            assert!(
                guard.owns_plugin("alpha-fixture", "shared", owner_token),
                "failed withdrawal released the live MCP name token"
            );
            assert!(
                guard.claim_plugin("intruder-fixture", "shared").is_err(),
                "a new owner took a name whose client was never withdrawn"
            );
            assert!(
                guard
                    .validate_plugin_claim("beta-fixture", "shared", None)
                    .is_err(),
                "beta could claim a name the aborted replacement never released"
            );
        }

        // The obligation is a real receipt in the ledger, carrying the wiring and
        // the exact token, and the runtime refuses to describe a live generation.
        {
            let state = runtime.state.lock().await;
            assert!(
                state.framework_receipt.is_none(),
                "the aborted generation is still reported as live"
            );
            assert!(
                state.prepared.agents.is_empty(),
                "the aborted generation still exposes application components"
            );
        }
        let receipts = runtime.cleanup_receipts().await;
        assert_eq!(receipts.len(), 1, "retained receipts: {receipts:?}");
        let retained = receipts
            .first()
            .ok_or_else(|| "aborted replacement retained no receipt".to_string())?;
        assert!(
            matches!(&retained.settlement, CleanupSettlement::Framework { .. }),
            "the receipt lost the framework wiring: {retained:?}"
        );
        assert!(
            retained
                .mcp_claims()
                .iter()
                .any(|claim| claim.plugin_id() == "alpha-fixture"
                    && claim.name() == "shared"
                    && claim.token() == owner_token),
            "the receipt lost the exact ownership token: {retained:?}"
        );
        assert_eq!(retained.attempts, 0);

        // The next retry really attempts the withdrawal again and still refuses to
        // report success while it cannot settle.
        let retry_error = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "a retry reported success with unsettled receipts".to_string())?;
        assert!(
            retry_error
                .to_string()
                .contains("cannot report success while plugin cleanup receipts remain unsettled"),
            "retry error: {retry_error}"
        );
        let receipts = runtime.cleanup_receipts().await;
        assert_eq!(receipts.len(), 1, "retry dropped the receipt: {receipts:?}");
        assert_eq!(
            receipts.first().map(|receipt| receipt.attempts),
            Some(1),
            "the retry never attempted the withdrawal"
        );

        drop(runtime);
        // The aborted generation's debt is permanent in this fixture; do not leak
        // it into the process-level ledger of the surrounding test binary.
        take_parked_cleanup_receipts(temp.path());
        Ok(())
    }

    /// Defect C: cancelling a caller while a receipt is being settled must leave
    /// the receipt in the ledger, and the next retry must attempt it again.
    #[tokio::test]
    async fn cancelled_receipt_retry_keeps_the_receipt_for_the_next_attempt() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let lifecycle = Arc::new(LifecycleCounts::default());
        let mut manager = PluginLifecycleManager::new();
        manager
            .register(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .map_err(|error| error.to_string())?;
        manager
            .activate("runtime-fixture")
            .map_err(|error| error.to_string())?;
        let receipt = CleanupReceipt::owned_lifecycle(
            temp.path().to_path_buf(),
            "cancelled retry fixture".to_string(),
            manager,
        );

        // Deterministic cancellation hook: the test itself holds the manager lock
        // that settlement must acquire, so the retry parks exactly on its await.
        let handle = receipt.clone();
        let manager_guard = match &handle.settlement {
            CleanupSettlement::OwnedLifecycle { manager } => Arc::clone(manager).lock_owned().await,
            _ => return Err("fixture receipt is not an owned lifecycle".to_string()),
        };
        runtime.state.lock().await.cleanup_receipts.push(receipt);

        let retry = {
            let runtime = Arc::clone(&runtime);
            tokio::spawn(async move {
                let mut state = runtime.state.lock().await;
                runtime.retry_cleanup_receipts(&mut state).await
            })
        };
        let mut parked = false;
        for _ in 0..10_000 {
            if runtime.state.try_lock().is_err() {
                parked = true;
                break;
            }
            tokio::task::yield_now().await;
        }
        assert!(parked, "the retry never entered its settlement await");
        retry.abort();
        let _ = retry.await;
        drop(manager_guard);

        let receipts = runtime.cleanup_receipts().await;
        assert_eq!(
            receipts.len(),
            1,
            "cancelled retry dropped the cleanup receipt: {receipts:?}"
        );
        assert!(
            matches!(
                receipts.first().map(|receipt| &receipt.settlement),
                Some(CleanupSettlement::OwnedLifecycle { .. })
            ),
            "the surviving receipt is not the cancelled one: {receipts:?}"
        );

        // The next retry still attempts settlement: the injected shutdown failure
        // is observed, then the following retry settles the receipt.
        lifecycle
            .shutdown_failures_remaining
            .store(1, Ordering::SeqCst);
        let failing = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "retry after cancellation reported success".to_string())?;
        assert!(
            failing.to_string().contains("injected shutdown failure"),
            "retry error: {failing}"
        );
        assert_eq!(lifecycle.shutdown.load(Ordering::SeqCst), 1);
        assert_eq!(runtime.cleanup_receipts().await.len(), 1);

        runtime.reload().await.map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_receipts().await.is_empty());
        assert_eq!(lifecycle.shutdown.load(Ordering::SeqCst), 2);
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn parked_framework_receipt_uses_original_agent_and_registry() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture_at(
            temp.path().join(".echo-agent/plugins/alpha-fixture"),
            "alpha-fixture",
        )?;
        write_mcp_fixture(&plugin, "shared")?;
        let original_registry = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let original = service_with_ownership(temp.path(), Arc::clone(&original_registry)).await?;
        let original_agent = original.agent_handle.clone();
        let original_token = claim_token(&original, "alpha-fixture", "shared").await?;
        {
            let mut state = original.state.lock().await;
            let wiring = state
                .framework_receipt
                .take()
                .ok_or_else(|| "original runtime has no wiring receipt".to_string())?;
            let claims = claims_from_ownership(&std::mem::take(&mut state.mcp_ownership));
            state.cleanup_receipts.push(CleanupReceipt::framework(
                temp.path().to_path_buf(),
                "park original target".to_string(),
                wiring,
                claims,
            ));
        }
        drop(original);
        assert!(
            original_agent
                .read(|agent| agent
                    .skill_descriptors()
                    .iter()
                    .any(|skill| skill.name == "alpha-fixture-example"))
                .await
        );
        let replacement_registry = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let replacement =
            service_with_ownership(temp.path(), Arc::clone(&replacement_registry)).await?;
        let replacement_token = claim_token(&replacement, "alpha-fixture", "shared").await?;
        // Independent registries issue the same first token. Token equality is
        // insufficient authority to release a lease in another registry.
        assert_eq!(original_token, replacement_token);
        assert!(
            replacement_registry.lock().await.owns_plugin(
                "alpha-fixture",
                "shared",
                replacement_token,
            ),
            "adopting old debt released the new runtime's lease"
        );
        assert!(
            !original_registry
                .lock()
                .await
                .owns_plugin("alpha-fixture", "shared", original_token,),
            "original registry never settled its exact lease"
        );
        assert!(
            !original_agent
                .read(|agent| agent
                    .skill_descriptors()
                    .iter()
                    .any(|skill| skill.name == "alpha-fixture-example"))
                .await,
            "the externally retained original Agent kept its framework wiring"
        );
        assert!(parked_cleanup_receipts_for_root(temp.path()).is_empty());
        replacement
            .shutdown()
            .await
            .map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn constructor_rejects_unsettled_parked_monitor_before_publication() -> Result<(), String>
    {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temp.path())?;
        let original = service(temp.path()).await?;
        {
            let mut state = original.state.lock().await;
            let monitors = state.prepared.monitors.clone();
            state.cleanup_receipts.push(CleanupReceipt::monitors(
                temp.path().to_path_buf(),
                "original scheduler unavailable".to_string(),
                monitors,
            ));
        }
        drop(original);
        let result = service(temp.path()).await;
        let rejected = result.is_err();
        if let Ok(runtime) = result {
            let _ = runtime.shutdown().await;
        }
        // This fixture intentionally has no scheduler capable of settlement.
        // Remove the test-owned permanent debt from the process ledger.
        let retained = take_parked_cleanup_receipts(temp.path());
        assert!(
            rejected,
            "constructor published a generation with old monitor cleanup unsettled"
        );
        assert!(
            !retained.is_empty(),
            "constructor lost its unsettled monitor receipt"
        );
        Ok(())
    }

    #[tokio::test]
    async fn aborted_shutdown_waiter_does_not_drop_framework_withdrawal() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let agent = runtime.agent_handle.clone();
        let (locked_sender, locked_receiver) = tokio::sync::oneshot::channel();
        let (release_sender, release_receiver) = tokio::sync::oneshot::channel();
        let blocker = tokio::spawn(async move {
            agent
                .write_async(|_| {
                    Box::pin(async move {
                        let _ = locked_sender.send(());
                        let _ = release_receiver.await;
                    })
                })
                .await;
        });
        locked_receiver.await.map_err(|error| error.to_string())?;
        let waiter = {
            let runtime = Arc::clone(&runtime);
            tokio::spawn(async move { runtime.shutdown().await })
        };
        wait_until_mutation_holds_state(&runtime).await?;
        waiter.abort();
        let _ = waiter.await;
        release_sender
            .send(())
            .map_err(|_| "Agent lock owner stopped".to_string())?;
        blocker.await.map_err(|error| error.to_string())?;
        tokio::time::timeout(std::time::Duration::from_secs(5), runtime.shutdown())
            .await
            .map_err(|error| error.to_string())?
            .map_err(|error| error.to_string())?;
        assert!(
            !runtime
                .agent_handle
                .read(|agent| agent
                    .skill_descriptors()
                    .iter()
                    .any(|skill| skill.name == "runtime-fixture-example"))
                .await,
            "cancelled shutdown forgot the wiring it removed from the live ledger"
        );
        assert!(runtime.cleanup_receipts().await.is_empty());
        Ok(())
    }

    #[tokio::test]
    async fn parked_cleanup_retries_original_scheduler_and_lifecycle() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temp.path())?;
        let original = service(temp.path()).await?;
        let lifecycle = Arc::new(LifecycleCounts::default());
        original
            .register_lifecycle(
                "runtime-fixture",
                Arc::new(TestLifecycle(Arc::clone(&lifecycle))),
            )
            .await
            .map_err(|error| error.to_string())?;
        let scheduler = test_scheduler(temp.path()).await?;
        original
            .bind_scheduler(Arc::clone(&scheduler))
            .await
            .map_err(|error| error.to_string())?;
        assert_eq!(scheduler.list_tasks().await.len(), 1);
        {
            let mut state = original.state.lock().await;
            let monitors = state.prepared.monitors.clone();
            state.cleanup_receipts.push(CleanupReceipt::live_lifecycle(
                temp.path().to_path_buf(),
                "original lifecycle cleanup".to_string(),
                vec!["runtime-fixture".to_string()],
            ));
            state.cleanup_receipts.push(CleanupReceipt::monitors(
                temp.path().to_path_buf(),
                "original scheduler cleanup".to_string(),
                monitors,
            ));
        }
        drop(original);
        let replacement = service(temp.path()).await?;
        assert_eq!(
            lifecycle.shutdown.load(Ordering::SeqCst),
            1,
            "cleanup called the replacement's empty lifecycle manager"
        );
        assert!(
            scheduler.list_tasks().await.is_empty(),
            "cleanup used the replacement's unbound scheduler"
        );
        assert!(replacement.cleanup_receipts().await.is_empty());
        replacement
            .shutdown()
            .await
            .map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn rejected_restore_retains_claims_without_reporting_a_live_generation()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        write_mcp_fixture(&plugin, "shared")?;
        let ownership = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let runtime = service_with_ownership(temp.path(), Arc::clone(&ownership)).await?;
        // The candidate reaches real framework wiring and then fails application
        // Subagent construction. Replaying the old frozen framework generation
        // is rejected by the canonical publication authority as AlreadyPublished.
        std::fs::write(plugin.join("agents/example.md"),
            "---\nname: runtime-fixture-specialist\ndescription: Restore rejection fixture\nreadonly: true\nmax_turns: 0\n---\nReturn the requested result.\n")
            .map_err(|error| error.to_string())?;
        let failure = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "invalid candidate unexpectedly published".to_string())?;
        assert!(
            failure
                .to_string()
                .contains("rollback framework wiring failed"),
            "{failure}"
        );
        {
            let state = runtime.state.lock().await;
            assert!(
                state.framework_generation.is_none(),
                "rejected restore was reported live"
            );
            assert!(state.framework_receipt.is_none());
            assert!(
                state.mcp_ownership.is_empty(),
                "cleanup names remained presented as live ownership"
            );
            assert!(state.prepared.agents.is_empty());
        }
        let receipts = runtime.cleanup_receipts().await;
        let retained = receipts
            .iter()
            .flat_map(CleanupReceipt::mcp_claims)
            .filter(|claim| claim.plugin_id() == "runtime-fixture" && claim.name() == "shared")
            .collect::<Vec<_>>();
        assert!(
            !retained.is_empty(),
            "restore rejected after claims were taken, but lost their receipts"
        );
        let guard = ownership.lock().await;
        assert!(
            retained.iter().any(|claim| guard.owns_plugin(
                "runtime-fixture",
                "shared",
                claim.token()
            )),
            "the issuing registry no longer holds any retained restore claim"
        );
        drop(guard);
        std::fs::write(plugin.join("agents/example.md"),
            "---\nname: runtime-fixture-specialist\ndescription: Restore rejection fixture\nreadonly: true\nmax_turns: 4\n---\nReturn the requested result.\n")
            .map_err(|error| error.to_string())?;
        runtime.reload().await.map_err(|error| error.to_string())?;
        assert!(runtime.cleanup_receipts().await.is_empty());
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn partial_restore_failure_retains_issued_withdrawal_authority() -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        write_mcp_fixture(&plugin, "shared")?;
        let ownership = McpNameOwnershipRegistry::new(Vec::<String>::new());
        let runtime = service_with_ownership(temp.path(), Arc::clone(&ownership)).await?;
        let token = claim_token(&runtime, "runtime-fixture", "shared").await?;
        let (issued, claims) = {
            let mut state = runtime.state.lock().await;
            (
                state
                    .framework_receipt
                    .take()
                    .ok_or_else(|| "issued wiring missing".to_string())?,
                std::mem::take(&mut state.mcp_ownership),
            )
        };
        // Exercise the typed framework-error adapter using a genuinely issued
        // receipt. Its publication token must survive conversion and still be
        // accepted by the real issuing Agent's rollback path.
        let partial_error = echo_agent::plugin::PluginWiringError::RollbackFailed {
            generation: issued.generation(),
            diagnostics: "restore transport has not settled".to_string(),
            receipt: Box::new(issued.clone()),
        };
        let mut failed = PluginRuntimeService::failed_framework_restore(
            "candidate rejected".to_string(),
            partial_error,
            runtime.registry_for(temp.path().to_path_buf()),
            claims,
            Vec::new(),
            Vec::new(),
        );
        assert!(failed.framework_generation.is_none());
        assert!(failed.framework_receipt.is_none());
        assert!(failed.prepared.agents.is_empty());
        let (retained, claims) = failed
            .retained_withdrawal
            .take()
            .ok_or_else(|| "partial restore error was reduced to text".to_string())?;
        assert_eq!(retained, issued, "framework publication identity was lost");
        assert!(
            claims
                .iter()
                .any(|claim| claim.token() == token && claim.name() == "shared")
        );
        {
            let mut state = runtime.state.lock().await;
            state.cleanup_receipts.push(CleanupReceipt::framework(
                temp.path().to_path_buf(),
                failed.error,
                retained,
                claims,
            ));
            let errors = runtime.retry_cleanup_receipts(&mut state).await;
            assert!(
                errors.is_empty(),
                "issued withdrawal authority was not preserved: {errors:?}"
            );
            assert!(state.cleanup_receipts.is_empty());
        }
        assert!(
            !ownership
                .lock()
                .await
                .owns_plugin("runtime-fixture", "shared", token)
        );
        assert!(
            !runtime
                .agent_handle
                .read(|agent| agent
                    .skill_descriptors()
                    .iter()
                    .any(|skill| skill.name == "runtime-fixture-example"))
                .await
        );
        runtime.shutdown().await.map_err(|error| error.to_string())
    }

    #[tokio::test]
    async fn failed_withdrawal_blocks_skill_and_pool_publication_until_settlement()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let skill_root = write_application_skill(temp.path(), "preserved-skill")?;
        let source = "eko:user-skill:preserved-skill";
        runtime
            .enable_application_skill(
                "preserved-skill".to_string(),
                skill_root.clone(),
                source.to_string(),
            )
            .await
            .map_err(|error| error.to_string())?;
        supersede_framework_generation(&runtime).await?;
        let rejected_reload = runtime
            .reload()
            .await
            .err()
            .ok_or_else(|| "stale framework receipt unexpectedly withdrew".to_string())?;
        assert!(
            rejected_reload
                .to_string()
                .contains("framework plugin rollback failed")
        );
        let generation = runtime.state.lock().await.generation;
        let preferences =
            std::fs::read(&runtime.preferences_file).map_err(|error| error.to_string())?;
        let enable = runtime
            .enable_application_skill(
                "preserved-skill".to_string(),
                skill_root.clone(),
                source.to_string(),
            )
            .await;
        let disable = runtime
            .disable_application_skill(
                "preserved-skill".to_string(),
                skill_root,
                source.to_string(),
            )
            .await;
        let pool = Arc::new(
            AgentPool::new_for_test(runtime.agent_handle.clone(), None, None, 8, false).await,
        );
        let bind = runtime.bind_agent_pool(Arc::downgrade(&pool)).await;
        let output_style = runtime.activate_output_style(None).await;
        let theme = runtime.activate_theme(None).await;
        for result in [
            enable.map(|_| ()),
            disable.map(|_| ()),
            bind,
            output_style,
            theme.map(|_| ()),
        ] {
            let error = result.err().ok_or_else(|| {
                "publication reported success while original withdrawal was unsettled".to_string()
            })?;
            assert!(
                error
                    .to_string()
                    .contains("cleanup receipts remain unsettled"),
                "{error}"
            );
        }
        agent_has_application_skill(&runtime.agent_handle, "preserved-skill", source, true).await?;
        assert_eq!(
            std::fs::read(&runtime.preferences_file).map_err(|error| error.to_string())?,
            preferences
        );
        let state = runtime.state.lock().await;
        assert_eq!(
            state.generation, generation,
            "blocked publication advanced the generation"
        );
        assert_eq!(state.cleanup_receipts.len(), 1);
        assert_eq!(
            state
                .cleanup_receipts
                .first()
                .map(|receipt| receipt.attempts),
            Some(5),
            "every rejected entry point must retry the actual obligation"
        );
        drop(state);
        drop(pool);
        drop(runtime);
        // The externally superseded receipt is intentionally permanent in this
        // fixture; the test owns and removes that debt after proving admission.
        let retained = take_parked_cleanup_receipts(temp.path());
        assert_eq!(retained.len(), 1);
        Ok(())
    }

    #[tokio::test]
    async fn domain_identity_uses_published_eko_definitions_not_runtime_timestamps_or_theme()
    -> Result<(), String> {
        let temp = tempfile::tempdir().map_err(|error| error.to_string())?;
        let plugin = write_fixture(temp.path())?;
        let runtime = service(temp.path()).await?;
        let mut registry = runtime.registry_for(temp.path().to_path_buf());
        runtime
            .scan_registry(&mut registry)
            .map_err(|error| error.to_string())?;
        let generation = runtime.integrator.prepare(&mut registry).await;
        let prepare = || {
            prepare_application_components(&generation, "identity-fixture", &registry)
                .map_err(|errors| errors.join("; "))
        };
        let first = prepare()?;
        let identity = first
            .domains
            .plugins
            .get("runtime-fixture")
            .ok_or("domain package missing")?
            .identity
            .clone();
        assert_eq!(identity.version.as_deref(), Some("0.1.0"));
        assert_eq!(
            prepare()?
                .domains
                .plugins
                .get("runtime-fixture")
                .ok_or("domain package missing")?
                .identity,
            identity
        );
        std::fs::create_dir_all(plugin.join("themes")).map_err(|error| error.to_string())?;
        std::fs::write(
            plugin.join("themes/example.json"),
            r##"{"name":"example","colors":{"background":"#222"}}"##,
        )
        .map_err(|error| error.to_string())?;
        assert_eq!(
            prepare()?
                .domains
                .plugins
                .get("runtime-fixture")
                .ok_or("domain package missing")?
                .identity,
            identity
        );
        std::fs::write(plugin.join("monitors.yaml"), "monitors:\n  - name: daily-review\n    cron: \"0 0 * * * *\"\n    prompt: A different automated instruction\n").map_err(|error| error.to_string())?;
        let changed_monitor = prepare()?
            .domains
            .plugins
            .get("runtime-fixture")
            .ok_or("domain package missing")?
            .identity
            .clone();
        assert_ne!(changed_monitor, identity);
        std::fs::create_dir_all(plugin.join("output-styles")).map_err(|error| error.to_string())?;
        std::fs::write(
            plugin.join("output-styles/evidence.md"),
            "---\nname: evidence\n---\nCite exact evidence.\n",
        )
        .map_err(|error| error.to_string())?;
        let changed_style = prepare()?
            .domains
            .plugins
            .get("runtime-fixture")
            .ok_or("domain package missing")?
            .identity
            .clone();
        assert_ne!(changed_style, changed_monitor);
        assert_eq!(
            generation.identity(),
            runtime.integrator.prepare(&mut registry).await.identity()
        );
        Ok(())
    }

    #[tokio::test]
    async fn domain_prepare_blocks_persisting_decoded_sensitive_values_with_escapes()
    -> Result<(), String> {
        for secret in ["fixture\nprivate", "fixture\"private", "fixture\\private"] {
            let temp = tempfile::tempdir().map_err(|_| "fixture directory unavailable")?;
            let plugin = write_fixture(temp.path())?;
            let path = plugin.join("plugin.json");
            let mut manifest: serde_json::Value = serde_json::from_slice(
                &std::fs::read(&path).map_err(|_| "fixture manifest read failed")?,
            )
            .map_err(|_| "fixture manifest parse failed")?;
            manifest.as_object_mut().ok_or("fixture manifest must be an object")?.insert("config".to_string(), serde_json::json!({
                "credential": { "type": "string", "title": "Fixture credential", "sensitive": true, "default": secret }
            }));
            std::fs::write(
                &path,
                serde_json::to_vec(&manifest).map_err(|_| "fixture manifest encoding failed")?,
            )
            .map_err(|_| "fixture manifest write failed")?;
            let mut declaration = crate::domain_plugin::DomainDeclaration {
                schema_version: 1,
                method: format!("Private method: {secret}"),
                default_subagent_roles: Default::default(),
                allowed_tools: Vec::new(),
                required_artifacts: Vec::new(),
                execution_checks: Vec::new(),
                acceptance_criteria: Vec::new(),
                review_checklist: Vec::new(),
                inputs: Vec::new(),
            };
            for private_rules in [false, true] {
                if private_rules {
                    declaration.method = "Safe method".to_string();
                    declaration.review_checklist = vec![secret.to_string()];
                }
                std::fs::write(
                    plugin.join("domain.yaml"),
                    serde_yaml::to_string(&declaration)
                        .map_err(|_| "fixture declaration encoding failed")?,
                )
                .map_err(|_| "fixture declaration write failed")?;
                let runtime = service(temp.path()).await?;
                let mut registry = runtime.registry_for(temp.path().to_path_buf());
                runtime
                    .scan_registry(&mut registry)
                    .map_err(|_| "fixture registry scan failed")?;
                let generation = runtime.integrator.prepare(&mut registry).await;
                let prepared = prepare_application_components(
                    &generation,
                    "private-domain-fixture",
                    &registry,
                )
                .map_err(|_| "fixture prepare failed")?;
                assert!(
                    prepared
                        .domains
                        .bind("runtime-fixture", None, &[])
                        .is_err_and(
                            |error| error.contains("contains sensitive configuration content")
                        ),
                    "sensitive declaration must not reach a persistable binding"
                );
                assert!(
                    !prepared
                        .domains
                        .catalog_prompt()
                        .unwrap_or_default()
                        .contains(secret),
                    "domain catalog must not expose a configured credential"
                );
            }
        }
        Ok(())
    }
}
