# 旧控制历史与专用恢复兼容退役：ignored源码候选

## 准确入口与资格

唯一候选为revision02-owner-and-current-controls/manifest.json，SHA
`c329b40345c3c691d5c22ab139c5c4218b1ebd803a02c524d078a4db3d2718ae`；
完整patch SHA `e9e98889141b8e31a39f156c3c9062d53714e833360910605a2b61d3c7580d75`。
base为Framework `e0cda8f95e6695a99c04ded2285057b5fa68d9f3`，原pause原件保持。
本线仅ignored副本写入，没有正式源/docs/HEAD/index、Cargo、validator、target、
用户数据、既有恢复材料或SDK/CLI写入。

14路径：11修改、1新增当前测试文件、2删除旧module。三个patch在全新ignored
base副本串行check/apply6项实际自然0，删除路径缺失、其余candidate逐bytes回读完全
相同。rustfmt check及审后check均自然0，仅语法/格式。独立有限源码复审C0/I0/M0，
行动0；没有编译、类型检查、运行、RED/GREEN、完整门禁或native资格。

## 实际源码删除与替代

删除src/state/legacy_control_history.rs及pending_recovery.rs；没有来源hash/旧工厂
revision/旧think/final参数→模型副本或最终候选的运行时转换。删除Core RecoveredToolKind/
RecoveredToolOrigin、recovered_tool_origins trait扩点及再导出；think不再调用旧历史
投影，正常必要projector的is_required/project/validate_model_request保留。

删除React normalize_pending_control_checkpoint/prepare_pending_control_checkpoint及
stream/Resume两个真实入口调用；删除RuntimeCheckpointRecoveryRequest、Store专用
inspection/commit adapters、File recovery Option与宽松deferred-pairing读模式。
普通CAS仍同一个原内核：严格checkpoint/owner load、scope/runtime锁、reconcile、
expected状态/epoch/revision fencing、AlreadyCurrent重放、pending transition校验、
owner/scope提交及索引修复保持。只移出旧来源专用读/特殊CAS/新建_recovery_sources
归档分支；已经保存的目录、日志、恢复包不读写/迁移/删除。

当前runtime-only保存仍调用的派生函数没有删除：旧误名derive_control_recovery_checkpoint
改为derive_context_view_checkpoint，使用严格当前payload恢复，保context-only lineage、
transcript frontier/generation/cursor，不把派生上下文当新transcript事实。

同一个原ReactStreamTurnOwner现在覆盖全部普通准备await，包含Load/reconcile/hydrate、
InputGuard、context准备及intent阶段。active steering仍放在原owner；成功直接move
该对象到同一producer，不重构资源束、不创建第二owner。普通失败settle该owner，
typedunknown保其原身份并retain；caller drop不释放仍active的mutex/resource guards。

## 当前测试迁移与退役区分

新增current_native_recovery_tests.rs八个测试定义：严格未配对真实tool拒绝且不改历史；
当前context-view派生保cursor/source；当前managed cursor损坏拒绝；正常CAS精确
replay与stale hydrate/epoch；绝对deadline三个原普通阶段（scope load/runtime load/
normal CAS，保250ms/500ms/5s期限）；normal typedunknown精确原owner资源保有；
当前自定义同名think/final_answer普通工具；丢弃已准入normal Load时mutex/resources
保留到未知物理观察。

用户自定义同名普通工具是当前合理扩展，不是旧兼容；原正控完整移入，保两次模型请求、
真实结果与唯一runtime Final通知。其它38个旧兼容专用成功义务按最新人类Goal retire，
不是matched/pass，未新增ignore/skip。acceptance-migration.json逐项记录旧名与混合
当前不变量的新场景，不以“删了tests”冒新行为验证通过。

首版revision01独审I2原件保持：它曾错误去掉当前准备RAII与误退当前自定义工具正控；
本修订两项静态关闭。任何首版结果不能冒本修订，任何静态票不能冒Cargo GREEN。

## 串行整合顺序

1. 01-current-native-controls.patch：先把当前控制定义放到原API版本，所用派生函数名
仍为旧的现有名字；未调用旧迁移adapter，不修改生产。这可在Root安排的同target窗口
实际运行当前控制/观察已准入Load丢弃缺口，不把编译错误当行为RED。
2. 02-retire-old-control-adapters.patch：实际切断旧主路径，删除适配机制，派生函数
同步重命名到当前语义并迁其调用，保同owner准备与current能力。
3. 03-owned-ADR.patch：同步既有ADR0101、中文guide43与zh41旧控制恢复段；
不新建英文副本。仍须在采用后按适用范围实际验证。

## 与其他owner的接缝

EKO须同一源码切点由owner删除legacy_eko_history及infra/factory、turn_context、
TaskRuntime compact_context三处旧getter override；不能先删Framework方法却宣
EKO/SDK全编译通过。SDK owner独立核public inventory移除这些compat-only API，
不保shim、不跨写SDK。本线未修改任何SDK或CLI文件。

父代理另准备当前writer/decoder格式收敛：本包不改current_plan/schema1/2/3、
File owner version域/raw writer、scope/index当前version1或SQLite能力。state/mod.rs
与file.rs须顺序合流/精确重拍，不平行formal写；zh41本包只改旧控制恢复小节，
版本/模式章节由格式owner整合。

现有examples没有Recovered*/recovery API调用，无示例API需要改名；后继原all-target
链路仍须编译它们。官网相关文档镜像随正式源码采用由官网owner从ADR0101/guide43/
zh41更新，本包未跨写网站。

runtime FinalAnswer、on_final_answer、Guard/Critic/Stop和真实收尾能力保持；String
便利、结构化API、多Store、当前cold/history/reload/Fork、幂等、不重放真实副作用、
provider签名/redacted/opaque协议回传均不退。本切片不是完整NoCompat目标交付，
未实现其他wrapper/配置alias/版本writer清理，也未改变风险baseline、tools/source排除
或任何用户数据/历史tag/恢复原件。
