from pathlib import Path
root=Path('candidate')

def replace(p,a,b):
 text=(root/p).read_text();assert text.count(a)==1,(p,'count',text.count(a),a[:100]);(root/p).write_text(text.replace(a,b,1))

def skip_quoted(text,i):
 if text.startswith('//',i):
  n=text.find('\n',i);return len(text) if n<0 else n+1
 if text.startswith('/*',i):
  depth=1;i+=2
  while depth:
   if text.startswith('/*',i):depth+=1;i+=2
   elif text.startswith('*/',i):depth-=1;i+=2
   else:i+=1
  return i
 import re
 m=re.match(r'(?:br|r)(#*)"',text[i:])
 if m:
  end='"'+m[1];j=text.find(end,i+len(m[0]));assert j>=0;return j+len(end)
 if text[i]=='"':
  i+=1
  while i<len(text):
   if text[i]=='\\':i+=2
   elif text[i]=='"':return i+1
   else:i+=1
  raise ValueError('unclosed string')
 m=re.match(r"'(?:\\(?:u\{[^}]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\n])'",text[i:])
 if m:return i+len(m[0])
 return i

def item_bounds(text,marker):
 start=text.index(marker);i=start;depth=0;found=False
 while i<len(text):
  j=skip_quoted(text,i)
  if j!=i:i=j;continue
  if text[i]=='{':depth+=1;found=True
  elif text[i]=='}':
   depth-=1
   if found and depth==0:return start,i+1
  i+=1
 raise ValueError(marker)

def remove_item(p,marker,doc_marker=None):
 text=(root/p).read_text();a,b=item_bounds(text,marker)
 if doc_marker:
  begin=text.rfind(doc_marker,0,a);assert begin>=0;a=begin
 line_end=text.find('\n',b);b=len(text) if line_end<0 else line_end+1
 (root/p).write_text(text[:a]+text[b:])

# No historical builtin contract, parser or origin getter remains on runtime model requests.
p='echo-core/src/compression.rs';text=(root/p).read_text();a=text.index('/// 原恢复owner为只读模型历史声明');b=text.index('/// Produces replaceable context',a);(root/p).write_text(text[:a]+text[b:]);remove_item(p,'    fn recovered_tool_origins<','    /// 原恢复/产品owner可从已知旧工厂')
replace('echo-state/src/compression/mod.rs','    RecoveredToolKind, RecoveredToolOrigin, StructuredSummary, ToolPairFix, ToolPairFixType,','    StructuredSummary, ToolPairFix, ToolPairFixType,')
p='src/agent/react/run/phases/think.rs';text=(root/p).read_text();a=text.index('    // 原restore/reconcile及compact已完成');b=text.index('    let agent = &snap.config.agent_name;',a);(root/p).write_text(text[:a]+text[b:])

# Remove compatibility recovery API and only its call sites, keeping normal admission/hydration.
p='src/agent/react/mod.rs';text=(root/p).read_text();a=text.index('    /// caller已持有原execution mutex');b=text.index('    ///\n    /// Loads the most recent',a) if False else text.index('    /// Restore context from the state store',a) if '    /// Restore context from the state store' in text[a:] else -1
# The two adjacent legacy methods end immediately before resume_from_state_store docs.
a=text.index('    /// caller已持有原execution mutex');b=text.index('    /// Resume agent state from the configured state store.',a) if '    /// Resume agent state from the configured state store.' in text[a:] else text.index('    /// Restore agent context',a) if '    /// Restore agent context' in text[a:] else -1
# Use exact end of prepare method to retain original following docs without guessing heading.
_,end=item_bounds(text,'    pub async fn prepare_pending_control_checkpoint(');assert end>a;(root/p).write_text(text[:a]+text[end+1:])
p='src/agent/react/mod.rs';text=(root/p).read_text();a=text.index('            if let Some(runtime_id) = self.config.conversation_id.as_deref() {',text.index('    pub async fn resume_from_state_store('));_,b=item_bounds(text,'            if let Some(runtime_id) = self.config.conversation_id.as_deref() {');assert a==text.index('            if let Some(runtime_id) = self.config.conversation_id.as_deref() {');(root/p).write_text(text[:a]+text[b+1:])
p='src/agent/react/run/stream_channel.rs';text=(root/p).read_text();a=text.index('        let mut recovery_owner =\n');b=text.index('        let pending_settlement = match admission_snapshot',a);text=text[:a]+text[b:];text=text.replace('    ReactStreamTurnOwner::preparation', '    ReactStreamTurnOwner::preparation') # current owner type kept elsewhere.
(root/p).write_text(text)

# Strict current payload is the only read mode. No deferred pairing inspection accessor.
replace('src/state/mod.rs','pub(crate) mod legacy_control_history;\npub use legacy_control_history::pending_recovery::PreparedPendingControlRecovery;\n','#[cfg(test)]\nmod current_native_recovery_tests;\n')
p='src/state/mod.rs';text=(root/p).read_text();a=text.index('        self.restore_managed_payload_for_read(false)');b=text.index('        self.validate_transcript_projection(',a);text=text[:a]+'''        let payload = self.restore_payload()?;
        validate_tool_message_pairing(&payload.messages)?;
'''+text[b:];(root/p).write_text(text)
remove_item('src/state/mod.rs','pub struct RuntimeCheckpointRecoveryRequest {','/// 原恢复owner提交派生context的输入')
remove_item('src/state/mod.rs','    fn inspect_runtime_state_for_recovery_with_context<','    /// 只读检查原恢复记录')
remove_item('src/state/mod.rs','    fn commit_checkpoint_recovery_with_context<','    /// 保存不可变旧来源后')

# Preserve current context-only view lineage, rename it to its real generic purpose and read strictly.
replace('src/agent/snapshot.rs','pub(crate) fn derive_control_recovery_checkpoint(','pub(crate) fn derive_context_view_checkpoint(')
replace('src/agent/snapshot.rs','    let payload = source.inspect_payload_for_recovery()?;','    let payload = source.restore_managed_runtime_payload()?;')
replace('src/agent/snapshot.rs','                    derive_control_recovery_checkpoint(current, messages)?.messages_json;','                    derive_context_view_checkpoint(current, messages)?.messages_json;')
replace('src/agent/snapshot.rs','            // 已经通过原恢复CAS进入revisioned owner，不能退回无版本save覆盖。','            // 当前revisioned owner的保存仍须沿原CAS，不能退回无版本save覆盖。')

# Remove dedicated recovery-only CAS adapter, retaining the same normal CAS kernel with strict owner load.
p='src/state/file.rs';remove_item(p,'struct CheckpointRecoverySourceArchive {','/// 完整raw owner的不可变读回凭据')
replace(p,'        request: RuntimeCheckpointCasRequest,\n        recovery: Option<super::RuntimeCheckpointRecoveryRequest>,','        request: RuntimeCheckpointCasRequest,')
text=(root/p).read_text();a=text.index('        if let Some(source) = recovery.as_ref()');b=text.index('        if let Err(error) = Self::validate_checkpoint_cas_request',a);text=text[:a]+text[b:];(root/p).write_text(text)
replace(p,'''            let mut scope_record = if recovery.is_some() {
                store.read_scope_owner_sync(&request.scope_id)?
            } else {
                store.reconcile_scope_owner_sync(&request.scope_id)?
            };
            let owner = if recovery.is_some() {
                store.read_runtime_owner_for_read(&runtime_state_id, true)?
            } else {
                store.read_live_runtime_owner_sync(&runtime_state_id)?
            };''','''            let mut scope_record = store.reconcile_scope_owner_sync(&request.scope_id)?;
            let owner = store.read_live_runtime_owner_sync(&runtime_state_id)?;''')
p='src/state/file.rs';text=(root/p).read_text();a=text.index('            // owner-first写入后崩溃可能尚未更新scope。');b=text.index('            let owners = owner.iter()',a);text=text[:a]+text[b:];(root/p).write_text(text)
replace(p,'''                if let Some(recovery) = recovery.as_ref() {
                    store.verify_checkpoint_recovery_source(&recovery.original)?;
                }
''','')
p='src/state/file.rs';text=(root/p).read_text();a=text.index('            if let Some(recovery) = recovery.as_ref() {');b=text.index('            let current_state_revision =',a);text=text[:a]+'''            Self::validate_pending_transition(owner.as_ref(), &request.checkpoint)?;
'''+text[b:];(root/p).write_text(text)
text=(root/p).read_text();a=text.index('    /// 旧原件是不可变恢复材料');b=text.index('    fn scope_index_path(',a);text=text[:a]+text[b:];(root/p).write_text(text)
# Collapse both helper read layers to one strict payload/owner read function.
p='src/state/file.rs';text=(root/p).read_text();a=text.index('    fn validate_runtime_owner_payload(');b=text.index('        match owner.state_version.as_ref() {',a);text=text[:a]+'''    fn validate_runtime_owner_payload(owner: &RuntimeStateOwner) -> crate::error::Result<()> {
'''+text[b:];text=text.replace('Self::checked_payload_for_owner_read(checkpoint, recovery_inspection)?','checkpoint.restore_managed_runtime_payload()?');a=text.index('    fn read_runtime_owner_sync(');b=text.index('        let path = self.runtime_owner_path(runtime_state_id)?;',a);text=text[:a]+'''    fn read_runtime_owner_sync(
        &self,
        runtime_state_id: &str,
    ) -> crate::error::Result<Option<RuntimeStateOwner>> {
'''+text[b:];text=text.replace('Self::validate_runtime_owner_payload_for_read(&owner, recovery_inspection)?','Self::validate_runtime_owner_payload(&owner)?');(root/p).write_text(text)
remove_item(p,'    fn inspect_runtime_state_for_recovery_with_context<')
remove_item(p,'    fn commit_checkpoint_recovery_with_context<')
replace(p,'        self.commit_checkpoint_cas(request, None)','        self.commit_checkpoint_cas(request)')

for p in ['src/state/legacy_control_history.rs','src/state/legacy_control_history/pending_recovery.rs']:(root/p).unlink()
