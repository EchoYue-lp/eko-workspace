from pathlib import Path
import re
p=Path('candidate/src/agent/react/run/stream_channel.rs');s=p.read_text();a=s.index('    pub(crate) async fn run_stream_channel(');b=s.index('\n}\n\nfn message_with_replaced_text',a);head=s[:a];body=s[a:b];tail=s[b:]
needle='''        let pending_settlement = match admission_snapshot''';insert='''        // 当前准备期的同一物理owner持有lease/mutex/资源，直到交给原producer。
        // 去掉旧控制历史归一不代表正常Store已准入工作可因caller drop提前释放。
        let mut preparation_owner =
            ReactStreamTurnOwner::preparation(&admission_snapshot, turn_lease, execution_guard);
        let pending_settlement = match admission_snapshot''';assert body.count(needle)==1;body=body.replace(needle,insert,1)
pattern=re.compile(r'ReactStreamTurnOwner::retain_pre_spawn\(\s*&[A-Za-z_]+,\s*turn_lease,\s*execution_guard,\s*(?:None|Some\(active_turn_lease\)),\s*(run_id(?:\.clone\(\))?),\s*(execution_id(?:\.clone\(\))?),\s*\);')
def retained(m):return f'preparation_owner.run_id = Some({m[1]});\n                    preparation_owner.execution_id = {m[2]};\n                    preparation_owner.retain_unknown();'
body,count=pattern.subn(retained,body);assert count==7,count
# Once steering exists, the same preparation owner must retain it if preparation is dropped.
needle='''        active_turn_lease.set_steerable(true);''';insert=needle+'''
        let turn_steer_incarnation = active_turn_lease.incarnation();
        preparation_owner.steering = Some(active_turn_lease);''';assert body.count(needle)==1;body=body.replace(needle,insert,1)
# Success/failure exits settle the same owner; release is not reconstructed from snapshots.
pattern=re.compile(r'active_turn_lease\.settle\(([^;]+)\);\s*turn_lease\.settle\(\);(?:\s*drop\(execution_guard\);)?')
body,count=pattern.subn(lambda m:f'preparation_owner.settle({m[1]});',body);assert count==3,count
body=body.replace('turn_lease.settle();','preparation_owner.settle(crate::agent::AgentSteerTurnOutcome::Failed);').replace('                    drop(execution_guard);\n','')
body=body.replace('snap.turn_steer_incarnation = Some(active_turn_lease.incarnation());','snap.turn_steer_incarnation = Some(turn_steer_incarnation);')
needle='''        let mut physical_owner = ReactStreamTurnOwner {
            lease: Some(turn_lease),
            steering: Some(active_turn_lease),
            execution: Some(execution_guard),
            resource_guards: snap.resource_guards.clone(),
            run_id: Some(observation_run_id.clone()),
            execution_id: observation_execution_id.clone(),
        };''';replace='''        preparation_owner.run_id = Some(observation_run_id.clone());
        preparation_owner.execution_id = observation_execution_id.clone();
        preparation_owner.resource_guards = snap.resource_guards.clone();
        let mut physical_owner = preparation_owner;''';assert body.count(needle)==1;body=body.replace(needle,replace,1)
# The old static builder is no longer needed: the already existing owner is transferred once.
s=head+body+tail
script=Path('edit-candidate.py').read_text();ns={};exec(script[:script.index('# No historical')],ns);start,end=ns['item_bounds'](s,'    fn retain_pre_spawn(');s=s[:start]+s[end+1:]
p.write_text(s)
