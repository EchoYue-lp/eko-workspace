#!/usr/bin/env python3
"""仅在自身 ignored 目录内核对补丁；不运行 Rust compiler 或测试。"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
FILES = ["src/state/mod.rs", "src/state/file.rs", "src/state/sqlite.rs"]
ADR = "docs/adr/0103-current-storage-records.md"
CHECK = ROOT / "apply-check"
CHECK.mkdir(exist_ok=True)
for path in FILES:
    target = CHECK / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / "base" / path, target)
adr_target = CHECK / ADR
if adr_target.exists():
    adr_target.unlink()
env = dict(os.environ, GIT_CEILING_DIRECTORIES=str(ROOT))
steps = []
for patch in ["storage-mod.patch", "storage-file.patch", "storage-sqlite.patch", "storage-adr.patch"]:
    for check in [True, False]:
        argv = ["git", "apply", "--whitespace=error"]
        if check:
            argv.append("--check")
        argv.append(str(ROOT / patch))
        result = subprocess.run(argv, cwd=CHECK, env=env, capture_output=True, text=True)
        step = {"argv": argv, "cwd": str(CHECK), "natural_exit": result.returncode,
                "stdout": result.stdout, "stderr": result.stderr}
        steps.append(step)
        if result.returncode:
            (ROOT / "apply-check-result.json").write_text(json.dumps({"steps": steps}, ensure_ascii=False, indent=2) + "\n")
            raise SystemExit(result.returncode)
matches = []
for path in FILES + [ADR]:
    applied = (CHECK / path).read_bytes()
    candidate = (ROOT / "candidate" / path).read_bytes()
    matches.append({"path": path, "equal": applied == candidate,
                    "sha256": hashlib.sha256(applied).hexdigest()})
report = {"steps": steps, "applied_matches_candidate": matches,
          "not_compilation_or_behavior_validation": True}
(ROOT / "apply-check-result.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"natural_exits": [s["natural_exit"] for s in steps],
                  "all_bytes_exact": all(m["equal"] for m in matches)}, ensure_ascii=False))
raise SystemExit(0 if all(m["equal"] for m in matches) else 1)
