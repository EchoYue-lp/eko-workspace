# 当前存储格式隔离候选交接

仅 ignored 候选，未正式接纳。基线 `e0cda8f95e6695a99c04ded2285057b5fa68d9f3`，无新公开字段/API/authority。

- `src/state/mod.rs`：唯一显式 schema3 writer/decoder，保无 cursor runtime-only/raw、unbound cursor 和 context-only lineage；旧裸数组/缺版本/1/2拒绝。
- `src/state/file.rs`：私有 owner 唯一version2、现有state_version枚举必填；raw明确Unmanaged digest，可原CAS采用为Managed1；rawDeleting崩溃切点和scope/index1保。
- `src/state/sqlite.rs`：只删除旧ALTER和duplicate-column兼容，当前CREATE/Store/事务/CAS保。
- 新中文ADR `docs/adr/0103-current-storage-records.md`。正式编号由上级串合时决定。

| 路径 | base SHA256 | candidate SHA256 |
|---|---|---|
| src/state/mod.rs | 60572e12314d33106b7c15cb4bfb2bc40dc1f2b1ba002b34750179e977221b5f | 25ffc36f73bbffb66277de92bde8268c7207d1e22def17e3ee3780e57b0bcc0b |
| src/state/file.rs | c3a83363f15f230ed0c9364bf8bb32ac886cfafcb48e5272f28567a991f244ea | f82f0c26ba870280f5db4d730ffebca28ed44b34a856e2bc679eeedaffa09b0d |
| src/state/sqlite.rs | 5462e7aa0271cbf5b0bc2ee02c3742211608ca28701c096bd982f086e956c5ff | 15a595d5928d6602847c2a55da73e4aabab03a31d77ec1e89aa56027371d816f |
| docs/adr/0103-current-storage-records.md | 新增 | 9a5218f6307610257469efefcd31c6e5fd07bc958ffac1ec46edcb8377a8f787 |

恢复和串合入口为 `manifest.json`、三个 `storage-{mod,file,sqlite}.patch`、`storage-formats.patch`（仅3源码）、`storage-adr.patch` 和 `storage-complete.patch`（含ADR）。这些补丁绑定共同base；上级与control候选顺序合流时处理重叠hunk，不覆盖其候选。`prepare-*.py`是制作草稿，不作为精确恢复入口。

有限独立源码复审pass：C0/I0/M0；绑定manifest `d4bcec8f9c95c893edc61181cbd5b8d43776470ee781a357530cef7484593c23`。首轮Minor负控遮蔽已修正并复审。三文件内当前测试定义63→66，无skip/ignore；旧接纳/迁移义务在source-qualification.md明确retired_by_goal，不计通过。`kernel-source-comparison.json`列保留测试和精确未改函数，三个production.diff列所有生产hunk；不把File完整CAS函数宣为原字节未变。

隔离补丁8次check/apply自然0、四份结果逐字节等于候选；审后standalone rustfmt check自然0，正式三源码和ADR不存在状态均无漂移。证据只到源码/补丁/格式；未Cargo、typecheck、测试、validator、App/用户数据或外部操作，无新target/worktree，不借Core13/old3959/主批GREEN。

正式采用前：与control专用退役包合流（当前context派生helper由其保留更名），迁`cross-file-fixture-dependencies.json`中的当前cold/history/skill-resource/trace/runtime-identity夹具，按该包取消清单处理旧专用义务；同步框架/官网中文owner示意。current_plan/SDK wire继续独立后继。由上级获准窗口执行真实类型和行为验证，本包不单独宣可跑全suite。
