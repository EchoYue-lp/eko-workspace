from pathlib import Path
import re
p=Path('candidate/src/state/file.rs');s=p.read_text()
def once(a,b,label):
 global s
 if s.count(a)!=1:raise ValueError(f'{label} expected1 got{s.count(a)}')
 s=s.replace(a,b,1)
def span(text,name):
 a=text.index(name);start=text.index('{',a);i=start+1;depth=1
 while depth:
  depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return a,i
s=s.replace('const LEGACY_RUNTIME_STATE_RECORD_VERSION: u8 = 1;\n','',1)
once('''    #[serde(default, skip_serializing_if = "Option::is_none")]
    state_version: Option<RuntimeStateVersion>,''','''    /// 当前模式必须显式持久化；Unmanaged/Managed/Retired复用同一版本枚举。
    state_version: RuntimeStateVersion,''','required state_version')
# Private owner field references are non-optional; request/version Option values elsewhere stay untouched.
s=s.replace('owner.state_version.as_ref()','&owner.state_version').replace('runtime.state_version.as_ref()','&runtime.state_version')
# Match arms are within this exact owner validation function.
a,b=span(s,'    fn validate_runtime_owner_payload_for_read(');body=s[a:b];body=body.replace('match &owner.state_version {','match &owner.state_version {',1).replace('None | Some(RuntimeStateVersion::Unmanaged { .. }) =>','RuntimeStateVersion::Unmanaged { digest } =>',1).replace('Some(RuntimeStateVersion::Managed { revision }) =>','RuntimeStateVersion::Managed { revision } =>',1).replace('Some(RuntimeStateVersion::Retired { .. }) =>','RuntimeStateVersion::Retired { .. } =>',1).replace('Some(RuntimeStateVersion::Absent) =>','RuntimeStateVersion::Absent =>',1).replace('Some(RuntimeStateVersion::Managed { .. })','RuntimeStateVersion::Managed { .. }')
needle='''        match &owner.state_version {''';body=body.replace(needle,'''        if owner.version != RUNTIME_STATE_RECORD_VERSION {
            return Err(Self::invalid_state("unsupported current runtime owner record version"));
        }
        match &owner.state_version {''',1)
needle='''            RuntimeStateVersion::Unmanaged { digest } => {
                if let Some(checkpoint) = owner.checkpoint.as_ref() {''';replacement='''            RuntimeStateVersion::Unmanaged { digest } => {
                if owner.scope_revision != 0 || owner.conversation_epoch.is_some()
                    || owner.scope_lifecycle != RuntimeScopeLifecycle::Active
                    || owner.cas_expected_state_version.is_some()
                    || owner.cas_expected_scope_revision != 0
                    || owner.transcript_ack_proof.is_some()
                    || digest.len()!=64 || !digest.bytes().all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
                {
                    return Err(Self::invalid_state("unmanaged runtime state has invalid explicit metadata"));
                }
                if let Some(checkpoint) = owner.checkpoint.as_ref() {
                    if Self::checkpoint_digest(checkpoint)? != *digest {
                        return Err(Self::invalid_state("unmanaged runtime checkpoint digest mismatch"));
                    }''';assert body.count(needle)==1;body=body.replace(needle,replacement,1)
needle='''            RuntimeStateVersion::Managed { revision } => {
                let checkpoint''';replacement='''            RuntimeStateVersion::Managed { revision } => {
                if *revision==0 || owner.scope_revision==0 {
                    return Err(Self::invalid_state("managed runtime state lacks current revision metadata"));
                }
                let checkpoint''';assert body.count(needle)==1;body=body.replace(needle,replacement,1)
needle='''            RuntimeStateVersion::Retired { .. } => {
                if owner.checkpoint''';replacement='''            RuntimeStateVersion::Retired { revision, .. } => {
                if *revision==0 || owner.scope_revision==0 {
                    return Err(Self::invalid_state("retired runtime state lacks current revision metadata"));
                }
                if owner.checkpoint''';assert body.count(needle)==1;body=body.replace(needle,replacement,1);s=s[:a]+body+s[b:]
a,b=span(s,'    fn owner_state_version(');s=s[:a]+'''    fn owner_state_version(owner: &RuntimeStateOwner) -> crate::error::Result<RuntimeStateVersion> {
        Ok(owner.state_version.clone())
    }'''+s[b:]
# All explicit current owner constructors retain the same existing version enum.
s=s.replace('state_version: Some(version.clone()),','state_version: version.clone(),')
s=s.replace('owner.state_version = Some(RuntimeStateVersion::Managed { revision: 2 });','owner.state_version = RuntimeStateVersion::Managed { revision: 2 };')
s=s.replace('''unmanaged_proof.state_version = Some(RuntimeStateVersion::Unmanaged {
            digest: "legacy".to_string(),
        });''','''unmanaged_proof.state_version = RuntimeStateVersion::Unmanaged {
            digest: "current-invalid-proof".to_string(),
        };''')
s=s.replace('''state_version: Some(RuntimeStateVersion::Retired {''','''state_version: RuntimeStateVersion::Retired {''')
# The retired constructor terminates this one private enum field with `}),`.
once('''                                operation_id: delete_operation_id.clone(),
                            }),
                            conversation_epoch:''','''                                operation_id: delete_operation_id.clone(),
                            },
                            conversation_epoch:''','retired constructor')
# Owner-version matching is no longer Option matching. Touch only owner-related patterns.
s=re.sub(r'(owner\.state_version,\s*)Some\((RuntimeStateVersion::(?:Managed|Retired) \{[^}]*\})\)',r'\1\2',s)
s=re.sub(r'(&owner\.state_version,\s*)Some\((RuntimeStateVersion::(?:Managed|Retired) \{[^}]*\})\)',r'\1\2',s)
s=re.sub(r'(&runtime\.state_version,\s*)Some\((RuntimeStateVersion::(?:Managed|Retired) \{[^}]*\})\)',r'\1\2',s)
# Optional owner is still optional, but the version inside a present owner is explicit.
s=s.replace('''.and_then(|owner| &owner.state_version)
            .map(Self::state_revision)''','''.map(|owner| Self::state_revision(&owner.state_version))''')
s=re.sub(r'owner\s*\.state_version\s*\.as_ref\(\)\s*\.map\(Self::state_revision\)\s*\.unwrap_or\(0\)',r'Self::state_revision(&owner.state_version)',s)
# Current raw writers stamp explicit Unmanaged at version2; no legacy reader path remains.
s=s.replace('version: LEGACY_RUNTIME_STATE_RECORD_VERSION,','version: RUNTIME_STATE_RECORD_VERSION,')
a,b=span(s,'    fn save_checkpoint_sync(');body=s[a:b].replace('state_version: None,','state_version: RuntimeStateVersion::Unmanaged { digest: Self::checkpoint_digest(checkpoint)? },',1);s=s[:a]+body+s[b:]
a,b=span(s,'    fn save_checkpoint_for_scope');body=s[a:b].replace('record.state_version.is_some()','!matches!(record.state_version, RuntimeStateVersion::Unmanaged { .. })',1);body=body.replace('''checkpoint: Some(checkpoint),
                state_version: None,''','''state_version: RuntimeStateVersion::Unmanaged { digest: Self::checkpoint_digest(&checkpoint)? },
                checkpoint: Some(checkpoint),''',1);s=s[:a]+body+s[b:]
s=s.replace('.is_some_and(|owner| owner.state_version.is_some())','.is_some_and(|owner| !matches!(owner.state_version, RuntimeStateVersion::Unmanaged { .. }))')
# Read metadata no longer treats v1 as a second layout or infers absent state version.
a=s.index('        if !matches!(\n            owner.version,');b=s.index('        if !Self::epoch_is_valid(owner.conversation_epoch)',a);s=s[:a]+'''        if owner.version != RUNTIME_STATE_RECORD_VERSION || owner.runtime_state_id != runtime_state_id {
            return Err(Self::invalid_state(format!("runtime state owner identity mismatch at {}",path.display())));
        }
        let _safe = safe_segment(&owner.scope_id)?;
'''+s[b:]
s=s.replace('''if owner.version == RUNTIME_STATE_RECORD_VERSION
                    && !matches!(
                        owner.state_version,
                        RuntimeStateVersion::Retired { .. }
                    )''','''if !matches!(owner.state_version, RuntimeStateVersion::Retired { .. } | RuntimeStateVersion::Unmanaged { .. })''',1)
s=s.replace('''    /// Normalize a legacy clear crash-cut while the caller holds this runtime's shard.''','''    /// 当前Unmanaged清除崩溃切点；模式显式存在，不从旧version推断删除许可。''',1)
s=s.replace('''owner.version == LEGACY_RUNTIME_STATE_RECORD_VERSION
                && owner.phase == RuntimeStatePhase::Deleting''','''matches!(owner.state_version, RuntimeStateVersion::Unmanaged { .. })
                && owner.phase == RuntimeStatePhase::Deleting''')
s=s.replace('''validated.version == LEGACY_RUNTIME_STATE_RECORD_VERSION
                && validated.phase == RuntimeStatePhase::Deleting''','''matches!(validated.state_version, RuntimeStateVersion::Unmanaged { .. })
                && validated.phase == RuntimeStatePhase::Deleting''')
s=s.replace('''record.version == LEGACY_RUNTIME_STATE_RECORD_VERSION''','''matches!(record.state_version, RuntimeStateVersion::Unmanaged { .. })''')
# Current phase-cut fixture starts from current explicit owner, preserving the crash sequence.
s=s.replace('''checkpoint: Some(active),
            state_version: None,''','''state_version: RuntimeStateVersion::Unmanaged { digest: FileRuntimeStateStore::checkpoint_digest(&active)? },
            checkpoint: Some(active),''',1)
p.write_text(s)
