from pathlib import Path
import re
base=Path('candidate')
def replace_once(s,a,b,label):
 if s.count(a)!=1:raise ValueError(f'{label}: expected1 got{s.count(a)}')
 return s.replace(a,b,1)
def span(s,name):
 a=s.index(name);start=s.index('{',a);i=start+1;depth=1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return a,i
p=base/'src/state/mod.rs';s=p.read_text()
s=replace_once(s,'    #[serde(default = "default_agent_checkpoint_payload_version")]\n    schema_version: u16,','    schema_version: u16,','required schema version')
a=s.index('fn default_agent_checkpoint_payload_version()');b=s.index('impl AgentCheckpoint {',a);s=s[:a]+s[b:]
a=s.index('        let bound = transcript_projection',s.index('pub fn serialize_managed_payload'));b=s.index('        serde_json::to_string(&AgentCheckpointPayload {',a);s=s[:a]+s[b:];s=s.replace('schema_version: if bound { 3 } else { 2 },','schema_version: 3,',1)
a,b=span(s,'    fn restore_payload(')
s=s[:a]+'''    fn restore_payload(&self) -> crate::error::Result<ManagedAgentCheckpointPayload> {
        // 当前payload只有一种明确版本。raw/runtime-only可不带cursor；缺版本、裸数组
        // 与旧版本均不是当前记录，不能通过缺字段猜出恢复许可。
        let payload: AgentCheckpointPayload = serde_json::from_str(&self.messages_json)
            .map_err(|error| invalid_checkpoint(format!("Failed to deserialize current checkpoint payload: {error}")))?;
        if payload.schema_version != 3 {
            return Err(invalid_checkpoint(format!(
                "unsupported checkpoint payload version {}", payload.schema_version
            )));
        }
        Ok(ManagedAgentCheckpointPayload {
            messages: payload.messages,
            transcript_projection: payload.transcript_projection,
            pending_transcript_projection: payload.pending_transcript_projection,
        })
    }'''+s[b:]
s=replace_once(s,'    /// `None` denotes a legacy cursor without transformation provenance.','    /// `None`表示本次视图未声明context-only派生；当前格式仍可表示无派生的模式。','cursor comment')
s=replace_once(s,'''        checkpoint.messages_json = serde_json::to_string(&messages)
            .map_err(|error| crate::error::ReactError::Other(error.to_string()))?;''','''        checkpoint.messages_json = AgentCheckpoint::serialize_payload(messages, None)?;''','tests constructor')
s=s.replace('fn context_binding_schema3_roundtrip_legacy_and_corruption()','fn current_schema3_roundtrip_bound_unbound_and_corruption()',1)
a=s.index('        let mut legacy = cursor;',s.index('fn current_schema3_roundtrip_bound_unbound_and_corruption'));b=s.index('        Ok(())',a)
s=s[:a]+'''        let mut unbound = cursor;
        unbound.context_only = None;
        checkpoint.messages_json =
            AgentCheckpoint::serialize_payload(messages, Some(unbound.clone()))?;
        let encoded: serde_json::Value = serde_json::from_str(&checkpoint.messages_json)?;
        assert_eq!(encoded.get("schema_version").and_then(serde_json::Value::as_u64), Some(3));
        assert_eq!(checkpoint.restore_managed_runtime_payload()?.transcript_projection, Some(unbound));
        // 无cursor仍是当前raw/runtime-only能力，不把统一schema误绑managed cursor。
        checkpoint.messages_json=AgentCheckpoint::serialize_payload(vec![Message::user("当前裸Store内容".into())],None)?;
        assert!(checkpoint.restore_managed_runtime_payload()?.transcript_projection.is_none());
'''+s[b:]
# Explicit former compatibility obligations are replaced with current-format negative controls.
pos=s.index('    #[test]\n    fn current_schema3_roundtrip_bound_unbound_and_corruption')
s=s[:pos]+'''    #[test]
    fn current_payload_rejects_missing_version_old_versions_and_bare_arrays() -> crate::error::Result<()> {
        let mut checkpoint=AgentCheckpoint::new("current-payload");
        for payload in ["[]", r#"{"messages":[]}"#, r#"{"schema_version":1,"messages":[]}"#, r#"{"schema_version":2,"messages":[]}"#] {
            checkpoint.messages_json=payload.into();
            assert!(checkpoint.restore_managed_runtime_payload().is_err());
        }
        checkpoint.messages_json=AgentCheckpoint::serialize_payload(Vec::new(),None)?;
        assert!(checkpoint.restore_managed_runtime_payload()?.messages.is_empty());
        Ok(())
    }

'''+s[pos:]
p.write_text(s)
# SQL compatibility-only changes: current schema already contains every column.
p=base/'src/state/sqlite.rs';s=p.read_text();a=s.index('        // Databases created before working-directory restoration lack this');b=s.index('        Ok(())',a);s=s[:a]+'''        // 当前建库声明已含全部字段；不对旧库执行ALTER或把补列失败当兼容成功。
'''+s[b:]
a,b=span(s,'    async fn revisioned_tables_migrate_legacy_checkpoint_database()');start=s.rfind('    #[tokio::test]',0,a);old=s[start:b]
# Keep current raw->managed/CAS and retirement semantics in a current freshly created DB.
new=old.replace('revisioned_tables_migrate_legacy_checkpoint_database','current_tables_preserve_raw_adoption_and_generation_retirement')
a=new.index('        let connection =');b=new.index('        let delete =',a)
new=new[:a]+'''        let store = SqliteRuntimeStateStore::new(&path)?;
        store.save_checkpoint(&checkpoint("current-raw", "raw")?).await?;
        store.save_checkpoint(&checkpoint("current-delete", "delete")?).await?;
'''+new[b:]
new=new.replace('legacy-migration','current-layout').replace('legacy-delete','current-delete').replace('"legacy"','"current-raw"').replace('legacy checkpoint','current raw checkpoint')
s=s[:start]+new+s[b:];p.write_text(s)
