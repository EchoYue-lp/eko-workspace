    #[tokio::test]
    async fn current_raw_owner_is_explicit_and_can_be_cas_adopted_after_reopen() -> crate::error::Result<()> {
        let tmp=tmp_base();let store=FileRuntimeStateStore::new(&tmp)?;
        let checkpoint=checkpoint("current-owner","中文记录");
        store.save_checkpoint_for_scope("current-scope",&checkpoint).await?;
        let raw=std::fs::read(store.runtime_owner_path("current-owner")?).map_err(FileRuntimeStateStore::to_react_err)?;
        let value:serde_json::Value=serde_json::from_slice(&raw).map_err(|error|FileRuntimeStateStore::invalid_state(error.to_string()))?;
        assert_eq!(value.get("version"),Some(&serde_json::json!(2)));
        assert!(value.get("state_version").and_then(|value|value.get("unmanaged")).is_some());
        let index:serde_json::Value=serde_json::from_slice(&std::fs::read(store.scope_index_path("current-scope")?).map_err(FileRuntimeStateStore::to_react_err)?).map_err(|error|FileRuntimeStateStore::invalid_state(error.to_string()))?;
        assert_eq!(index.get("version"),Some(&serde_json::json!(1)),"scope index当前版本不随owner格式退役");
        drop(store);let reopened=FileRuntimeStateStore::new(&tmp)?;
        let observed=reopened.load_runtime_state("current-scope","current-owner").await?.ok_or_else(||ReactError::Other("current raw owner missing".into()))?;
        let RuntimeStateVersion::Unmanaged {digest}=observed.version else {return Err(ReactError::Other("current raw mode changed".into()));};
        let adopted=reopened.compare_and_save_checkpoint(RuntimeCheckpointCasRequest {scope_id:"current-scope".into(),runtime_state_id:"current-owner".into(),conversation_epoch:Some(1),expected_scope_revision:0,expected_state_version:RuntimeStateExpectedVersion::Unmanaged {digest},checkpoint:managed_checkpoint("current-owner","new typed state")?,managed_import:None}).await?;
        assert_eq!(adopted.status,RuntimeCheckpointCasStatus::Applied);assert_eq!(adopted.version,RuntimeStateVersion::Managed {revision:1});
        let _=std::fs::remove_dir_all(&tmp);Ok(())
    }

    #[tokio::test]
    async fn current_owner_decoder_rejects_implicit_mode_and_old_version_without_mutation() -> crate::error::Result<()> {
        let tmp=tmp_base();let store=FileRuntimeStateStore::new(&tmp)?;
        store.save_checkpoint_for_scope("current-scope",&checkpoint("strict-owner","record")).await?;
        let path=store.runtime_owner_path("strict-owner")?;let original=std::fs::read(&path).map_err(FileRuntimeStateStore::to_react_err)?;
        let value:serde_json::Value=serde_json::from_slice(&original).map_err(|error|FileRuntimeStateStore::invalid_state(error.to_string()))?;
        for corruption in 0..3 {
            let mut invalid=value.clone();let object=invalid.as_object_mut().ok_or_else(||ReactError::Other("fixture owner not object".into()))?;
            match corruption {0=>{object.remove("state_version");},1=>{object.insert("version".into(),serde_json::json!(1));},_=>{object.insert("state_version".into(),serde_json::Value::Null);}}
            let bad=serde_json::to_vec(&invalid).map_err(|error|FileRuntimeStateStore::invalid_state(error.to_string()))?;
            echo_core::utils::fs::atomic_write(&path,&bad).map_err(FileRuntimeStateStore::to_react_err)?;
            assert!(store.get_checkpoint("strict-owner").await.is_err());
            assert_eq!(std::fs::read(&path).map_err(FileRuntimeStateStore::to_react_err)?,bad,"拒绝不自动迁移或修补原记录");
            echo_core::utils::fs::atomic_write(&path,&original).map_err(FileRuntimeStateStore::to_react_err)?;
        }
        assert!(store.get_checkpoint("strict-owner").await?.is_some());let _=std::fs::remove_dir_all(&tmp);Ok(())
    }
