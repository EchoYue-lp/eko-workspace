# ADR 0103：运行时检查点只写读当前格式

状态：已确认退役目标的隔离实现候选，尚未合入或运行验证。

## 背景

运行时检查点由框架管理，适用于文件、SQLite 和内存 Store，不依赖 EKO 的产品入口。旧实现同时接纳裸 `Vec<Message>`、缺失 schema 的 payload、payload 版本 1/2，以及缺失模式的文件 owner 版本 1。读取时猜测旧模式，与当前运行时自身需要的 raw Store、无 cursor 检查点和带 cursor 检查点混在同一条路径。

开发阶段已批准取消旧格式兼容和旧数据库补列义务。取消的是旧记录接纳义务；通用 Store 实现、当前 raw 保存能力、严格恢复校验和普通 CAS 仍是框架能力。

## 候选方案

1. 保留多版本 decoder，继续在缺字段时推断旧模式。这会继续承担已取消的兼容义务。
2. 为 raw、managed 和 retired 增加新 mode 字段及不同 decoder。现有 `RuntimeStateVersion` 已表达这些语义，新增字段会形成重复权威。
3. 使用唯一当前 payload 和 owner 格式，复用现有版本枚举表达模式，保留当前能力的可选字段。

## 决策

采用方案 3，沿既有 writer、decoder、原子写和 CAS 路径实现，不新增公共字段或执行 owner。

- `AgentCheckpoint::serialize_payload` 和 `serialize_managed_payload` 始终写 `schema_version: 3`；读取要求显式版本 3。裸消息数组、缺版本、版本 1/2 不再被接纳。
- `transcript_projection`、`pending_transcript_projection` 和 cursor 的 `context_only` 仍按当前语义可选。无 cursor 的 runtime-only/raw Store 以及无 context-only 派生的 cursor 均可使用版本 3；版本号本身不代表已有 transcript receipt。
- 私有文件 owner 只接受 `version: 2`，必填现有 `state_version`，复用 `Unmanaged { digest }`、`Managed { revision }`、`Retired { revision, operation_id }`。不存在新的 mode 字段或第二套 decoder。
- raw 保存写明确的 `Unmanaged` 和完整 checkpoint digest；raw 更新/清除只允许 `Unmanaged`。匹配原 digest 的 `expected_state_version: Unmanaged` 仍可经原 CAS 成为 `Managed { revision: 1 }`。
- 当前 raw 清除的 `Deleting + checkpoint: None + Unmanaged { digest }` 是合法崩溃切点。读取/扫描仍按原锁和原 owner 处理，不再从旧版本号推断清除许可。
- scope owner 和 scope index 的版本 1 是当前格式，继续保留。
- SQLite 的当前 `CREATE TABLE` 已声明 `working_dir`、CAS expected-version/revision 和 transcript ack proof 列；移除旧 `ALTER TABLE` 补列及忽略 duplicate-column 错误的分支。框架 SQLite backend 和当前事务不退役；EKO 应用仍不启用 SQLite。

文件 owner 的当前约束继续在既有校验函数内检查。`Unmanaged` 的 digest 必须为完整小写 SHA-256，并与仍存在的 checkpoint 一致；不带 managed revision、epoch 或 ack 元数据。managed/retired 保留非零 revision、pending base revision 与 acknowledgement proof 约束。scope retirement 的临时结构仍在写入前赋予本次 scope revision，写 owner 后再写 scope 的崩溃恢复次序保持原状。

## 取舍和影响

旧记录不会在读取时自动升级、修补或重放副作用；本 ADR 不提供兼容 shim。当前 writer 产生的格式由新增负控和原当前行为测试共同约束。旧数据库缺列的操作不再承诺迁移成功。

保留普通 CAS 的 expected epoch/version、stale 拒绝、幂等 replay、pending effect/ack、scope retirement journal、scope/runtime 锁、deadline、typed unknown 和资源 owner。文件模式字段的机械访问调整不构成新增运行权威。旧控制历史模块及其专用恢复 adapter 由另一个隔离切片删除；本切片不重复删除或重命名当前 context-view 派生函数。

`AgentCheckpoint.current_plan` 及 SDK wire 清理是后继独立合同切片，本次保留字段和调用关系。正式接纳前还需串合旧控制历史退役候选，迁移该切片外剩余的裸数组测试夹具，同步框架和官网中文持久化示意，并在获准资源窗口运行实际编译和行为验证。

## 验证边界

本文件与三份 Rust 候选仅存于 ignored 目录。独立 rustfmt 和隔离补丁应用只证明语法格式、补丁可应用及结果字节一致，不证明类型正确或测试通过。当前 lineage、冷开、raw adoption、CAS stale/replay、腐坏拒绝、pending effect 非重放和 owner-first crash cuts 的测试定义需保留并在最终串合快照执行；历史主批或其它候选的结果不能替代本切片证据。
