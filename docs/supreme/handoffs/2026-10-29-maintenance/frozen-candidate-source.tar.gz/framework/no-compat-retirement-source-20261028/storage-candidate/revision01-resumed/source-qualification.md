# 当前存储格式候选交接说明

范围：`e0cda8f95e6695a99c04ded2285057b5fa68d9f3` 的 `src/state/{mod,file,sqlite}.rs` 三文件及新增中文 ADR。所有产物只在本 ignored 目录内，正式采用由 `/root` 唯一写入。不是编译、行为或正式 Source 验收。

## 当前能力与源码边界

payload writer/decoder 只写读显式 schema3；无 cursor 和无 context-only 派生仍合法。文件 owner 以显式现有枚举表达 raw/managed/retired，raw writer 写当前版本2及 checkpoint digest。scope/index 版本1保持当前格式。SQLite 删除旧补列分支，当前建库及多 backend 保留。

`kernel-source-comparison.json` 提供原件与候选函数块的字节比较、测试名称映射。它是源码比较，不是 Rust 解析或行为证明。File 的模式访问和 owner 构造必然改变；不把整个 CAS 函数宣称为“原字节未改”。生产 diff 另存于 `file.rs.production.diff`、`mod.rs.production.diff` 和 `sqlite.rs.production.diff`，可逐 hunk 核验。

保留的精确源码包括 File 的 scope/runtime/shard 锁、原 keyed blocking、deadline、checked revision、`state_matches_expected`、epoch/CAS request 校验、pending attempt 分类、scope index 原子写与原 scope owner 校验；SQLite 除 `init_tables` 兼容分支外的生产函数不改变。File 的 CAS、pending/ack、retirement replay 仅随私有 `Option<RuntimeStateVersion>` 归一作枚举访问/构造调整；expected revision/epoch、pending proof、owner 先写与 scope 后写次序、日志和 typed error 的条件仍保留。

## 当前测试定义保留与迁移

三文件内测试定义由 63 个变为 66 个，新增 schema 拒绝负控和两项当前 File owner 控制。没有添加 `ignore`、skip 或 matched-pass。

- payload：原工具调用配对、重复结果拒绝、cursor digest/位置腐坏、pending effect、context-only after-view/original lineage 保留。schema3 测试改为有 binding、无 binding 和无 cursor 三种当前模式；旧 schema 下标拒绝继续保留。
- File：原并发 CAS/stale/replay、pending/ack、管理态 raw mutator 阻断、sender/scope 隔离、deadline 无副作用、owner-first crash cut、清除/重建/回收切点保留。原 raw 夹具改为当前 schema3 + 显式 Unmanaged owner，不再借旧 owner1 接纳行为维持这些测试。新增冷开后 Unmanaged digest 精确 CAS adoption；新增缺模式/null模式/owner1/合法64hex但内容不匹配的digest拒绝且不改原字节。原raw ack负控先由当前writer建立合法owner，再只附proof，排除无效digest和其它metadata遮蔽。
- SQLite：当前新库生命周期、scope index 冷开、CAS 并发、stale/replay、pending/ack、deadline 与 scope retirement 保留。原“旧数据库补列成功”测试替换成当前新库 raw adoption 和 generation retirement，原当前核心断言继续存在。

完整测试名称和新旧名称映射在 `kernel-source-comparison.json`，只是定义清单，均未执行。

## 明确取消的旧义务

以下义务标记为 `retired_by_goal`，不计为测试通过：裸 `Vec<Message>` payload 接纳；缺版本默认1；schema1/2 接纳；无 binding writer 写schema2；文件 owner1 接纳/新 raw owner 写1；缺 state_version 推断模式及 digest；读取旧模式时补默认必填元数据；SQLite working_dir/CAS/ack 旧补列；duplicate-column 忽略；旧数据库迁移成功。当前可选 cursor、context-only、epoch、expected-state 和 ack 字段的合法 optional 语义不退役。

## 串合依赖和文档核对

本包保留旧控制历史/Store recovery 专用 adapter，由 sibling control 候选删除；保留当前 `derive_control_recovery_checkpoint`，由该切片在保持当前调用后更名。上级应以共同原件顺序合流，不把本包覆盖到 sibling 候选。`current_plan` 与 SDK wire 仍属后继合同切片。

`cross-file-fixture-dependencies.json` 列出三文件外剩余直接 JSON 数组夹具的确切路径/原行号/函数。其中 cold chat、warm history、技能资源权威、trace 与 invocation/runtime identity 含当前能力，需先迁当前 serializer；兼容专用部分与 sibling 取消清单对账，不能整条删或 skip。因此本三文件包不能作为可独立运行全套测试的完整变更。

正式文档归框架，ADR 候选放在 `candidate/docs/adr/`。`docs/zh/03-memory.md` 与 `echo-website/src/docs/content/echo-agent/zh/03-memory.md` 的 owner 示意缺显式 version/mode，需要各所属 writer 在正式接纳同批同步；它们未在本包跨权修改。实际 examples 在 `echo-agent-learning/examples`；未发现直接 `messages_json` 构造，公开 builder/Store 调用不变，本切片不新增或修改示例。`demo17_chat.rs` 的 current_plan 注释随独立字段退役切片核对。

## 已运行与未运行

`apply-check-result.json` 记录在非 Git 仓库的本地副本顺序应用三个源码补丁和 ADR，每个 `git apply --check` 与实际 apply 的自然退出码及结果 SHA；正式源未写。`check-logs/rustfmt-check.log` 对应独立 `rustfmt --edition 2024 --check --config skip_children=true`，不递归外部模块。

未运行 Cargo、rustc、测试、全量格式门禁、依赖扫描、外部语义 validator、应用或真实用户数据操作；未创建 target/worktree。未使用主批或历史 Core/Framework 测试结果替代本候选验证。`prepare-*.py` 是制作过程辅助草稿，不是恢复或验收入口；精确恢复以 base/candidate 哈希、分段补丁及完整补丁为准。
