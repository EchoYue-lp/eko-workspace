# 2026-10-28 Framework未合流候选保全包

人类最新维护优先级：暂停新功能，先保存已实现代码和中间成果。此包由ignored原件
逐bytes复制，准备给Root在Framework所属仓库独立跟踪；目前尚未复制到正式docs、
未stage/commit、未采用为产品实现，不含raw日志、二进制、账户或用户资料。

canonical-v04 source review C0/I0/M0；只有隔离patch apply、字节一致与rustfmt，
没有Cargo/typecheck/RED/GREEN。Weixin同样只有有限source review和静态资格。旧
v01/v02/v03静态block原件保为prior-static-reviews，不用后继pass覆盖。

恢复：先取得Root将当前Framework2805正式快照保存的精确提交；逐manifest.base_sha256
核全部base文件一致，才能按01→02→03或complete.patch（两者二选一）应用。当前
HEAD0e404185是父提交，含未提交变化，不能把它直接当候选完整base。base可由本机
保存的0e598稳定source索引/对应source tar精确恢复；原件路径和哈希保于清单。
不符合base时停止重新核对，不无条件强行apply，不恢复用户名/密钥/旧账号材料。

未开工：旧control-history/pending归一/CAS专用adapter实际删除，以及当前writer/
decoder格式收敛，在维护暂停前尚未第一次写candidate；只有18组inventory与只读
事实，绝不能标删除完成、matched/pass或补skip。所有runtimeFinal事件/回调、当前
String/非流式、冷恢复/Fork/CAS/幂等、多Store及provider签名/opaque能力继续保留。

重新迭代由Root唯一维护清单恢复；本包本身不解除EKO整批source冻结，也不授业务
操作、Source#10/旧402/新pin/native/MainCI/Goal完成。
