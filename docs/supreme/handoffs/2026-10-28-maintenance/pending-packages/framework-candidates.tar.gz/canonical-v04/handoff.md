# Framework当前canonical消费者与旧兼容退役候选

唯一候选入口v04/manifest.json，SHAa0f02920328366e0a3fdab6b65ac5a11ed7aa893c5de100520902fcf3121c26a；
仅ignored源包，正式2805稳定源/HEAD/index继续整批EKO租约冻结。原0fcf/3959仅原输入票，
不授此候选编译或运行资格。

已形成五路径source/test/ADR候选：Core共享纯输出归并helper、原Subagent executor、原
Workflow node及所属ADR0102。它不执行、取消、持久化或拥有资源；不新wire/event shape
或finalowner。新增Rust公共helper供两个独立crate共用，SDK inventory由其owner另核。

两个当前能力漏洞已在候选中处理：Subagent不再按content为Text而丢role/name/metadata，
完整Message+history+invocation直达原typed执行；Subagent/Workflow使用AssistantMessage/
真实ExecutionStatus/LlmUsage消费原source，Reasoning独立、原request/item/block/seq去重。
原流一直到EOF，block.complete和FinalAnswer不提前返回；typedunknown只由合法新native
同owner终态解除，重复/合成/foreign终态无解除资格，attachment drain保同规则与首因。

运行时FinalAnswer/on_final_answer是用户明确保留的当前能力，不是compat-only删除项；
退役的是FinalAnswerTool和旧Final-only source合成成功。两consumer在真实EOF成功后，
利用既有terminal.request_id补原runtimeFinal安全正文：原批准块已显示的部分不双拼，
Guard transform无raw块也能完整呈现；不改producer、callback、Guard/Critic/Stop/结算。

13个纯helper定义及3个consumer测试方法（Subagent9场景、Workflow11场景、attachment
drain3场景）已提供。首版I3、v02 I3、v03 I1的完整block原件保留；v04独立只读静态
复审PASS C0/I0/M0/行动0。三patch在ignored freshbase串行check/apply6命令自然0、
逐文件bytes匹配、rustfmt check0仅语法格式；没有Cargo/typecheck/RED/GREEN/完整矩阵
或native资格。必须等Root真实EKO reader返回后走正常formal scope与相邻验证窗口。

18组精确清单分别记录compat-only退役、当前writer活模式须先收敛、合理跨产品API与
多Store保留。不按LEGACY/version号或wrapper名称盲删；scope/index当前1、当前payload
2/3真实模式、contextOnly lineage、Fork/编辑generation replacement、CAS/幂等/不重放
副作用和provider signed/encrypted回放继续保留。所有旧日志、失败、恢复包、tag和用户
数据保原，不为旧缺字段新增解析/来源猜测，不新增skip或matched/pass。

当前非流式源码路径及GUI Fork证据边界另见nonstream-current-producer.md；合法
model_streaming(false)/String便利已有同ReAct canonical路径，无需新owner。Store内
Candidate不是App已公开Settled，GUI Fork需原generation的Sink/ChatEventLog实际事实；
无native的空events/Ok旁路可以retire，但保当前native nonstream组合验收。

SDK rich override源码另由真实owner维护；本线不跨写SDK。EKO/SDK/ACP/其它合理
consumer列表是后继退旧Token/Think前的真实联动范围；其中FinalAnswer合法引用不退。
工具分类仍待用户方案裁决，风险baseline/工具/Source排除无变化。
