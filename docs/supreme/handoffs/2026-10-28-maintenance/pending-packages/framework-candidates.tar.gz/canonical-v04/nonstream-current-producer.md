# 当前非流式与GUI Fork：源码核对

Framework execute/chat：react/mod.rs3718/3748→run/direct.rs9/29→react_loop.rs23，完整读取
同一Managed流到EOF、保首个错误，仅runtime Settled返回String。execute_typed在extract.rs
263..275沿同execute后parse；model_streaming(false)只在think.rs853..898选择chat而非
chat_stream，把完整工具/来源/reasoning/blocks/finish/usage投到同Chunk与ReAct。

因此合法String便利、非流式模型传输和当前typed接口保留，不需要第二owner或App补终态。
现有HTTP回归定义native_message_contract_tests.rs255覆盖传输及execute fresh/chat history，
本轮没有重跑，且该测试不含Store/GUI Fork，不能冒组合验收。assistant任意非文本Parts
输出也不能因as_text路径而声称全形状完整，当前可核的是文本final及canonical字段。

finalize.rs398..418把safe content、raw/approved及同execution/request/sequence持久成
Candidate；431持久化协调后，448/457/472公开原status、批准块和runtime FinalAnswer。
Message/store不落公开Settled是有意区分持久候选与已发布事实；不能为了Fork把Candidate
升级成功、回填历史，不能由App拿String或TaskRunCompleted造terminal。

GUI chat_driver.rs2290/2300/2306使用原Sink+TurnRequest.from_message+AgentTurnDriver，
chat.rs2418的ChatSurface::Gui属于原ChatEventLog generation；model_streaming(false)
依然走同路径，因此无native空events/Ok旧旁路并非保它的必要条件。Fork投影
conversation_projection.rs259..475还核同workspace/conversation/execution、批准事件逐字段、
同request/seq唯一Settled、唯一最终通知及后续产品TurnStatus completed。

IM handle在channel_runtime.rs5832完整consume handle_stream，后者沿同foreground/chat
driver；该当前能力保留。cron scheduler/runner.rs149/158/205持Run admission、workspace
generation和occurrence Run/TaskRuntime journal，不能当GUI reply publication证据。

剩余真实组合：当前GUI driver + model_streaming(false) + 原Store cold + 同一ChatEventLog
已确认事件 + Fork复制/冷开/再Fork（及typed结构化返回组合）。旧兼容旁路验收retired，
这些新版本功能继续必验。此报告纯源码，未新增producer、调用模型或写入用户资料。
