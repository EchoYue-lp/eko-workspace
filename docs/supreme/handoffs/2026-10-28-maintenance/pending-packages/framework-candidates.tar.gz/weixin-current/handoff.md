# 微信当前getupdates合同与一次脱敏诊断候选

本包只在ignored准备；正式Framework2805及当前EKO B2整批租约仍冻结。没有真实业务
请求、第二poller、手工getupdates、账号操作或Cargo；原扫码授权与原GUIStop不变。

作者parser-v02原manifest SHA30fb2a734817a3c15769c428835f4156d1d80487e6d6b813103c9d3ab7b4c028、
tests-first be1b468f15889df583603809230d13485897b600393c9e45ebaff061d8daa285
原样纳入第一patch（5方法/19case）。第二patch仅private UpdatesResponse object-only
typed解码与当前业务谓词：presence明确分Missing/Null/Value，不把OptionNone误说成
原键缺失；字段类型/重复字段仍由原Serde拒绝，非0/-14先行，显式null业务码Unknown。
必须明确business0或当前typed msgs数组/cursor字符串才Accepted，{}、无关object、
仅timeout hint、array/nullroot及坏类型不因HTTP2xx转Ready。不接deprecated sync_buf。

第三patch把薄观测带在原client execute_json，同原POST getupdates响应；clone共享
一次额度，不新store/owner/协议/模式或poller。只记真实HTTPstatus、受限完整bytes
长度/SHA、固定allowlist字段presence/type、i64code、msgs count与未知key count。
不遍历消息、不回显未知键名、errmsg/text/cursor/headers/token/rawbody。非2xx仍
原早退且明确body未捕获，不以伪空body冒原形状。新增4个Rust诊断测试定义，未运行。

原channel poll/send/handler、cursor receipt frontier/CAS/去重、Stop/backoff全部不改；
sender的业务接受谓词未扩展，Accepted仍不等手机实际收到。现场仅知typed decode
未Some0且未判非0；原presence/type和数字HTTPcode未捕获，不能断言现场一定缺ret。
官方固定Tencent874637a0与npm2.4.10逐bytes同合同差异是确定源码依据，不是现场
RootCause已证；已有官方原件复用，不重复下载或新请求取证。

manifest SHA6ccbc59cdec6e5bc825c716694c5454de84072259490f4fa5b04998a6dbc627b，
complete.patch SHA98fc6263cccee75448e494c9df9da48fae59fd1171ce9aeed030fd893ea6213b。
三个patch在ignored fresh base串行check/apply6项自然0，逐文件候选bytes匹配，rustfmt
check0仅语法格式。独立有限source review C0/I0/M0/行动0，不授编译、RED/GREEN
或现场修复资格；原helper准备脚本第一次断言漏考虑api.rs测试literal第三constructor
的失败已纠正，所有三个literal都显式加入同一次观测额度，无编译票被伪造。

既定下一步由Root真实释放B2整批reader并登记F唯一source/资源窗后：原author tests
先实跑RED，再同target当前谓词GREEN；补原HTTP/channel未知/拒绝/-14/停止/游标与
幂等回归及诊断隐私反控。原focused入口为
cargo test -p echo_integration --lib --features channels --locked tencent_current_poll_contract -- --test-threads=1 --nocapture。
随后仅Root安排新版App同已保存授权原实例恢复观察一轮安全shape，手机/HITL收件
另作实际验收；不重复要求同次扫码、不手动消费inbox、不回填旧source票。
