"""原官方raw的受控缺项反例；不是新scanner，也不签发最终gate资格。"""
import copy
import hashlib
import json
from pathlib import Path
import unittest

import check_cli_dependency_risks as gate

BASE = Path(__file__).resolve().parent
INPUTS = json.loads((BASE / "before.json").read_text())
RAW = Path(INPUTS["official_raw_source"]).read_bytes()
if hashlib.sha256(RAW).hexdigest() != INPUTS["official_raw_sha256"]:
    raise ValueError("official raw evidence changed")
REPORT = json.loads(RAW)
POLICY = json.loads(gate.POLICY_PATH.read_text())


class CapturedWarningCoverage(unittest.TestCase):
    def test_original_current_capture_matches_exact_five(self):
        self.assertEqual(len(gate.verify_report(REPORT, 1, POLICY, 768)), 5)

    def test_every_single_omission_from_actual_warning_capture_is_rejected(self):
        for category, entries in REPORT["warnings"].items():
            for index, entry in enumerate(entries):
                with self.subTest(advisory=entry["advisory"]["id"]):
                    altered = copy.deepcopy(REPORT)
                    altered["warnings"][category].pop(index)
                    with self.assertRaises(ValueError):
                        gate.verify_report(altered, 1, POLICY, 768)

    def test_empty_capture_does_not_masquerade_as_current_exact_baseline(self):
        altered = copy.deepcopy(REPORT)
        altered["warnings"] = {}
        with self.assertRaises(ValueError):
            gate.verify_report(altered, 0, POLICY, 768)

    def test_each_captured_setting_change_is_rejected(self):
        changed = {
            "target_arch": ["aarch64"],
            "target_os": ["macos"],
            "severity": "high",
            "ignore": [POLICY["accepted"][0]["advisory"]],
            "informational_warnings": ["unmaintained", "unsound"],
            "unexpected_setting": True,
        }
        for field, value in changed.items():
            altered = copy.deepcopy(REPORT)
            altered["settings"][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                gate.verify_report(altered, 1, POLICY, 768)
        for field in REPORT["settings"]:
            altered = copy.deepcopy(REPORT)
            del altered["settings"][field]
            with self.subTest(missing=field), self.assertRaises(ValueError):
                gate.verify_report(altered, 1, POLICY, 768)


if __name__ == "__main__":
    unittest.main(verbosity=2)
