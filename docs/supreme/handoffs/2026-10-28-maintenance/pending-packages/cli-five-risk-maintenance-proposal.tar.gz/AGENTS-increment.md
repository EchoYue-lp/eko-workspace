
## 2026-10-28 本轮CLI具名退役后的五项严格子集合同

本节覆盖上文CLI旧3fb/856与d38f/321绑定的当前时态，历史原文、六项用户授权与所有失败保留。原用户仍是“继续保留原六个依赖，完成本次修复和验证”；Root在本轮既有授权内审原完整身份并批准技术复评收紧，不表述为用户新批准五项。仅因具名入口退役移除bincode1.3.3闭包，剩余glib0.18.5、proc-macro-error1.0.4、zvariant5.13.1、zbus_names4.3.4、zvariant_derive5.14.0五项完整身份均与原六项相同；不接受新增风险或以后自动续期。

当前候选精确绑定CLI锁SHA256`399509eeb951c87d407ffd949c60ac4c5b7dcc460a189e078a25f8287f4e2a4f`（768包）、原collector consumer`7659b93fc04512b307f62a6402fa5a8e9ac0cf4fa24d1e63c6de0622a35aa9a1`（274输入）；唯一机器身份仍为CLI `.cargo/accepted-dependency-risks.json`，人类来源和本轮技术复评看原`dependency-risk-decision.md`的本日后继。任何新包/边/风险或name/version/source/checksum/advisory/kind变化都阻断；不增ignore、不改scanner/filters、不继承Framework/SDK例外。

checker要求恰当前五项完整warning集合；少一项、加一项、重复、字段、settings、漏洞、yanked或扫描错误均阻断，不因空报告或数量变化自动接受。原六方法全部保留并更新当前768/五项基线，另有缺组与settings负控。候选测试通过不代表正式风险门禁通过；Root须在必要Rust验证结束且source稳定后安排原actual-lock/canonical-origin两gate实际执行，官方scanner自然1与独立精确gate0分别保留。当前锁/consumer漂移须准确复核，不自动重绑；所有其它编译/测试/fmt、文档、mainCI和原生门禁不变。
