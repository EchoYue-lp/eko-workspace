
## 2026-10-28 本轮具名入口退役后的精确子集技术复评

原人类本轮授权原话仍是“继续保留原六个依赖，完成本次修复和验证（推荐）”。原六项policy、中文原文、先前原gate失败和本轮3失败/7错误的测试原件完整保留。本次不是用户新批准五项，也不接受新的advisory、包、版本、source、checksum、kind、ignore或后续迭代风险。

Root已审实际官方报告与原checker，并明确授权在本轮既有六项授权内作收紧：具名终端入口退役使bincode1.3.3及其syntect依赖闭包退出实际锁，剩余五项是原六项的严格子集。两侧锁fresh比较为856→768包，新增0、移除88，共同包version/source/checksum变化0；共同包resolved依赖边新增0、移除24。这里只说明退役消除该消费图暴露，不声称bincode的原advisory被修复或合理Framework公开存储API应删除。

本次候选只绑定锁`399509eeb951c87d407ffd949c60ac4c5b7dcc460a189e078a25f8287f4e2a4f`（768包）及原collector当前consumer `7659b93fc04512b307f62a6402fa5a8e9ac0cf4fa24d1e63c6de0622a35aa9a1`（274输入）。accepted仅删除bincode，其余glib0.18.5、proc-macro-error1.0.4、zvariant5.13.1、zbus_names4.3.4、zvariant_derive5.14.0的name/version/source/checksum/advisory/kind逐字段不变。唯一机器身份仍是`.cargo/accepted-dependency-risks.json`，不从数量推断接受，不向Framework/SDK或未来锁扩展。

本轮只读提交核验的actual-lock/canonical-origin官方fresh scanner均自然1、0漏洞、4项unmaintained＋1项unsound，完整五身份均匹配原六子集，原raw不改。原policy绑定旧3fb/d38f，因此两次正式原gate均自然1且scannerExit=null；这些失败保留，不回写为通过。

原checker还有独立缺口：只逐条拒新增/重复，未要求全部accepted原件都出现。用上述官方真实raw逐一移去一条warning作受控负例，原checker对五种少一条均未拒绝；清空warnings/退出0亦未拒绝，真实RED自然1原件保留。候选保持所有scanner/settings/schema/漏洞/来源拒绝条件，明确要求当前五项完整集合恰好匹配；以后5→4/6、重复、withdrawn、字段或settings漂移均阻断，不能用任意数量或clean空报告自动续期。

原六Python方法全部保留（首个名称按five改正），人口常量按当前768/767负控更新，原clean空报告从接受改为缺完整集合拒绝；另补缺组/重复/四或六基线、所有原settings及withdrawn负控。隔离候选中原六方法、新增两方法及同一真实raw三个控制均自然0；这些是候选工具测试，非当前正式actual/canonical gate、Rust消费者或原生安全资格。

本次不改scanner命令、URL、settings、fetch/yanked、全局Git/SSH或ignore；只在Root批准的维护范围准备候选，正式源仍由EKO唯一writer按正常预检处理。最终actual-lock/canonical-origin原gate必须在必要Rust验证完成且source稳定后，由Root另排真实执行。其间source/lock/consumer变化须停在准确差异，不自动改摘要续期。候选票与历史scanner自然1不冒最终gate0，完整Rust/前端/native/mainCI和整体Goal均继续独立验收。
