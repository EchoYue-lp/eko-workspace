# 精确五项子集合同候选交接

这是Root明确安排的提交必要维护，不恢复产品feature或性能迭代。**所有修改只在本目录ignored候选中；正式policy/checker/测试/文档/AGENTS未写入，未stage/commit。** 最终actual/canonical gate必须等EKO必要Rust验证结束、source稳定后由Root另排，本候选票不冒该门禁通过。

## 当前唯一可审输入

- CLI五文件patch：`cli-exact-subset.patch`，SHA **`df691ea1cfd7f7cdbc44bbe5dbf96b7de62f9b09cbda6efffe57c43a978709bf`**。
- Root AGENTS同步hunk：`root-AGENTS.patch`，SHA **`713a9ac11df29c8e688ed8ee1416fbc0d61ba006d9f86daf2188f2740f4184b6`**。
- 六文件精确base/after：`candidate-manifest.json`。policy候选SHA **`67464eadb66da30aa44208a70e0eda60862474717e833a80c9b304e8d777af32`**。
- 原六项人类原话/旧policy完整原件：`preserved/`；逐项严格子集证明：`subset-proof.json`。
- 独审：`review.json`，候选工具/合同 **pass C0/I0/M0**，仅绑定上述候选，不是最终官方扫描门禁。

policy仅删随具名入口退役移出实际锁的bincode，并绑定当前3995锁/768包与7659 consumer/274输入；其余五项name/version/source/checksum/advisory/kind逐字段与原接受六项相同。原人类授权仍是“继续保留原六个依赖，完成本次修复和验证（推荐）”；文档准确描述Root本轮既有授权内的技术复评和退役消除暴露，未写“用户新批准五项”。任何新身份/新风险不在此候选范围内。

checker只把硬编码six改为当前固定five，并补“accepted全部必须在原warning集合出现”。原settings/schema/vulnerability/yanked/ignore/来源/重复/scanner-exit规则、官方URL/命令和global Git/SSH均不放宽；不会接受任意数量或未来自动续期。原六方法保留，更新768基线，空报告现在明确拒绝；新增缺组/重复/4或6基数及settings/withdrawn负控。

## 真实RED与候选GREEN

在修checker前，对刚保全的官方五项raw逐一移走一项：原checker五种情况均未抛错；清空warnings/退出0也未抛错。`red-run.json`和`logs/captured-warning-red.log`保留自然1、六个失败的原RED；不是scanner新扫描，更没有把原raw改写。

修后隔离候选实际执行：原六方法6/0、新增严格控制2/0、同官方raw控制4/0，分别自然退出0。最后一组同时覆盖每个实际warning缺项、空报告及各settings变异/缺字段。adapter单元控制里的tiny scanner仅验证原进程输出/失败处理，不冒官方扫描。CLI/Root两patch的准确scratch applycheck0，Python AST/JSON0；六文件base/after哈希、正式274输入和Root AGENTS前后未漂移。

上一次正式原gate actual/canonical仍各自然1/scannerExit=null，原六方法3失败7错误和官方两次scanner自然1/0漏洞/5warning原件都在相邻 `maintenance-cli-risk-readonly-20261028/` 保留。没有重标历史失败，候选没有运行正式actual/canonical gate。原scanner raw和Root已审的88包/24边减少、0新增及五项完整身份事实继续原样引用。

## 合流与最终资格

EKO唯一writer按准确base在正常预检范围接CLI五文件；Root自行接Root AGENTS同步hunk。若实际lock/consumer/base变化，先停在具体差异，不自动改摘要、承认新风险或扩大policy。正式policy和consumer可在所属source冻结后由Root安排原六方法与新控制、原actual-lock/canonical-origin gate；必要Rust验证结束前不抢运行scanner，也不为此开新编译。

本任务Rust编译0、Host/模型/UI/产品数据/性能0、新官方scanner0；没有外部echo-semantic修改、无新ignore、无清理他人target。独立审查末次进程快照出现其他Cargo/rustc，原件只作事实，不归本线、不kill、不清cache。任务完成即返回人类维护冻结；完整Goal、原24/59及新12/17性能、native/mainCI/发布等均未因此完成。
