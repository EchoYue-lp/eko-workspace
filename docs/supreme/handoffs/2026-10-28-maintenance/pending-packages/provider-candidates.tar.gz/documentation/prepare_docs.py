"""只准备EKO正式中文文档/ADR及Delivery提案，绝不写正式或自动镜像清单。"""
from pathlib import Path
import json,hashlib,difflib,subprocess,re
p=Path(__file__).resolve().parent;root=p.parents[5]
manifest={'status':'ignored_docs_candidate_only','files':{},'patches':{}}
groups={'eko-native-docs.patch':[],'delivery-website-zh-review-only.patch':[]}

def replace(s,a,b):
 if s.count(a)!=1:raise ValueError('doc anchor missing/ambiguous '+a[:80])
 return s.replace(a,b,1)

def save(rel,source,s,group):
 for name,data in [('base',source),('candidate',s)]:
  target=p/name/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(data)
 manifest['files'][rel]={'base_sha256':hashlib.sha256(source.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest()}
 groups[group].append(''.join(difflib.unified_diff(source.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))

rel='echo-agent-cli/docs/zh/adr/0057-native-messages-and-progress-policy.md'
source=(root/rel).read_text();s=source
s=replace(s,'2026-10-27 用户已确认方向。本仓正在实现；源码、定向验证、Framework 合同和新版原生验收分别记录。本 ADR 不表示跨仓切换或产品验收已经完成。',
'''2026-10-27 用户已确认方向。本仓正在实现；源码、定向验证、Framework 合同和新版原生验收分别记录。本 ADR 不表示跨仓切换或产品验收已经完成。

2026-10-28 用户亲自追加开发期不考虑旧版本兼容的裁决。此前旧 schema、消息 wrapper 和
旧内置控制调用来源判定的运行时兼容义务已取消，记为退役，不记为 matched／pass。
本 ADR 保留相关历史讨论供追溯；它们不再是当前实现要求。新版本新产生的数据仍须完整
支持冷加载、重载、Fork／恢复及幂等，不能重放已完成副作用；第三方协议要求的签名、
加密 Reasoning 与原 history 回传继续保留。代码物理删除与验证资格由各 owner 安全批次另行记录。''')
s=replace(s,'- 旧日志保原件，只读归一历史；无法判断的旧控制文字显示为历史执行说明，不重新注册旧工具或补成功。',
'''- 旧日志、失败、用户数据、受保护 tag 和恢复包保留原件；不为旧格式新增运行时归一、
  控制来源猜测或补成功。取消兼容义务不取消新 typed 数据自身的历史／恢复能力。''')
s=replace(s,'## 2026-10-28：旧控制调用的来源边界与真实getter接线\n',
'''## 2026-10-28：旧控制调用的来源边界与真实getter接线（兼容义务已取消）

本节是此前调研记录。用户后继裁决已取消其中针对旧控制日志的运行时兼容恢复要求；
保留原记录不表示继续维护该适配，也不构成 matched／pass 或代码已物理删除的证明。
退役内置 `FinalAnswerTool` 不退役 runtime 触发的最终回答事件与回调。
''')
s+='''

## 2026-10-28：当前前端投影收敛与旧格式退役

候选取舍：继续双写 round／字符串思考会保留两套来源；只删旧 consumer 会丢掉尚在副写
的当前工具记录。因此同步停止 `currentRound/executionRounds` 副写，复用原真实工具
summary `started → recordToolStart → executionSteps`，再移除 OlderRounds 和旧思考回退。
不增加新 store、执行器或结束 validator。

当前 native 消息以 `assistantBlocks` 保留原 block／request、phase、序号和 Reasoning；
`executionSteps` 只记录 assistant 索引和工具引用的实际顺序。Reasoning 继续由原
`NativeMessageTimeline`／`ThinkingSegment` 独立折叠，空 delta 可读取原签名块公开文字和
opaque summary，私有签名／加密字段仍只作原件。`thinkingContent/thinkingSegments`、
`thinking_segments/execution_rounds` 及相应无序、旧 round fallback 不再作为前端来源。
Rust DTO／旧数组 parser 由所属 owner 同步收敛，本切片不另建兼容转换。

模型起止、工具批次与运行 notice 继续沿原事件入口观测，不制造空思考块、round 副本或
完成资格。批次观测不得调用会重开全局 streaming 的状态副写；completed、failed 或
cancelled 后的迟到 batch 不得复活输入框／队列忙碌状态。工具状态和步骤仍来自实际
summary，终态仍来自原运行时。运行时 `FinalAnswer` 事件及其回调明确保留；Bubble 不再
以缺少 `finalAnswerConfirmed` 的普通正文授予 Fork，仍须遵守原执行与流式门槛。

b529 的实际 Settled／选定批准块／publication 身份及双序号域规则继续生效。前端分支
重新发送后续轮时保留原前缀的 native 块和 canonical 步骤；spinner 与 Timeline 共用公开
native 文字提取，不从已退役字符串思考推断等待或阶段。只改变呈现，不改 TaskRun／Goal。

本切片已保存候选快照的 12 项新契约／负控、下列 13 个消费者文件共 211 项及完整前端
类型、lint、格式回执。纯旧格式回退验收已由用户取消并标为退役，无新增 skip，也不把
取消项改记通过。这些是 JS／DTO 消费证据；正式源合流、真实 Rust get 投影原件桥、
完整执行链和新版 native 窗口仍须分别取得当前证据，不能由同源旧票或文档晋级。

内部 UI 不提供可独立编译的 MessageBubble API example；不新增无调用方示例或长 soak。
在所属 `web-frontend` 中，直接消费者验证入口为：

```sh
npx vitest run \\
  src/components/chat/ChatPanel.controls.test.tsx \\
  src/components/chat/MessageBubble.completed.test.tsx \\
  src/components/chat/MessageBubble.fork.test.tsx \\
  src/components/chat/MessageBubble.rendering.test.tsx \\
  src/components/chat/MessageBubble.test.ts \\
  src/components/chat/NativeMessageTimeline.test.tsx \\
  src/components/task/TaskRuntimeList.test.tsx \\
  src/hooks/chatEventHandler.contract.test.ts \\
  src/hooks/chatEventHandler.hitlReplay.test.ts \\
  src/hooks/chatEventHandler.test.ts \\
  src/stores/chatStore.toolExecution.test.ts \\
  src/stores/conversationStore.test.ts \\
  src/types/api.contract.test.ts
```

原 domain-plugin／产品 soak examples 不消费这些 UI DTO，Framework／SDK API 未因本件
变化，故不修改其示例。官网用户能力介绍仅需同步旧格式承诺取消与 runtime 最终事件保留
的边界；由 Delivery 在真实 EKO 来源固定并审阅后处理中文提案，不手改自动镜像或同步
manifest，不提前宣告实际后端桥、新版 native 或网站部署通过。
'''
save(rel,source,s,'eko-native-docs.patch')

rel='echo-agent-cli/docs/zh/guides/gui-task-runtime-panel.md';source=(root/rel).read_text();s=source
s=replace(s,'## 阅读任务状态\n', '''## 助手消息与完整回复（本轮变更，待新版原生验收）

助手进度、部分回答、独立思考、工具和运行状态按其真实来源呈现。进度与最终回答即使
正文相同，也可能是两条独立消息；只有能证明属于同一个最终候选时才合并显示。思考可
单独展开，签名和加密原件不会转成聊天正文，工具保留实际先后顺序。

运行时确认最终回答的事件与回调继续保留。出现文字、一段生成结束或保存成功都不能
单独代表完整回复或整个任务完成；分叉入口仍受原执行和完整回复资格约束。迟到的工具
批次观测不能把已完成、失败或取消的运行重新变成等待中。重新生成后续回复时，之前
消息的工具顺序继续保留。

开发期不再承诺旧消息格式的运行时兼容，新格式自身的冷加载、重载、Fork 和恢复仍须
工作，旧原件／失败与恢复材料仍保留。本节不把已保存的前端测试当作真实后端 DTO 桥
或新版桌面验收。数据与验证边界见 [ADR 0057](../adr/0057-native-messages-and-progress-policy.md)。

## 阅读任务状态
''')
save(rel,source,s,'eko-native-docs.patch')

rel='echo-website/src/docs/content/eko/zh/capabilities.md';source=(root/rel).read_text();s=source
s=replace(s,'内置 Think/FinalAnswer 控制工具的具名退役须随 provider、流式与非流式路径、Subagent、GUI、IM、cron 和 SDK 消费者一起验收。本页不宣称已完成全链路切换、60 秒进度策略或新版原生窗口验收。',
'''退役对象是模型可调用的内置 Think/FinalAnswer 控制工具及旧消息格式兼容表面；由运行时触发的最终回答事件与回调继续保留。开发期取消旧格式运行时兼容承诺，新版本自身的冷加载、重载、Fork／恢复和已完成副作用不重放仍须成立，第三方协议要求的签名与加密 history 回传也继续保留。

这些边界仍须随 provider、流式与非流式路径、Subagent、GUI、IM、cron 和 SDK 消费者分别验收。本页不把前端测试或旧夹具晋升为真实后端 DTO 桥、新版原生窗口或网站已部署的证明，也不宣称全链路切换或 60 秒进度策略已验收。''')
save(rel,source,s,'delivery-website-zh-review-only.patch')

for name,parts in groups.items():
 content=''.join(parts);(p/name).write_text(content)
 repo='echo-website' if name.startswith('delivery-') else 'echo-agent-cli'
 result=subprocess.run(['git','-C',repo,'apply','--check','-p2','-'],cwd=root,input=content,text=True,capture_output=True)
 (p/(name+'.check.log')).write_text(result.stdout+result.stderr)
 manifest['patches'][name]={'sha256':hashlib.sha256(content.encode()).hexdigest(),'apply_check_exit':result.returncode,'owner':'Delivery review only; do not update mirror/manifest here' if repo=='echo-website' else 'EKO single writer'}
 print(name,result.returncode,len(content.splitlines()),'lines')

# 只校验本次新增引用和既有13个真实入口；不重跑JS、网站生成或同步。
cli=Path('echo-agent-cli')
tests=re.findall(r'  (src/[^\s]+\.test\.tsx?)', (p/'candidate/echo-agent-cli/docs/zh/adr/0057-native-messages-and-progress-policy.md').read_text())
missing=[path for path in tests if not(root/cli/'web-frontend'/path).is_file()]
assert len(tests)==13 and not missing,('consumer test paths invalid',tests,missing)
assert (root/cli/'docs/zh/adr/0057-native-messages-and-progress-policy.md').is_file()
manifest['doc_checks']={'consumer_test_paths':len(tests),'missing_paths':missing,'js_tests_rerun':False,'mirror_or_manifest_written':False,'official_docs_written':False}
manifest['source_candidates']={'implementation_manifest_sha256':hashlib.sha256((p.parent/'manifest.json').read_bytes()).hexdigest(),'implementation_evidence_sha256':hashlib.sha256((p.parent/'final-evidence.json').read_bytes()).hexdigest()}
manifest['unchanged_formal']={rel:hashlib.sha256((root/rel).read_bytes()).hexdigest()==facts['base_sha256'] for rel,facts in manifest['files'].items()}
(p/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
