# Provider 候选工程保全包

仅供维护期受跟踪保存，**不是正式采用、产品源码合流或验收完成**。这些文件位于
`docs/engineering/pending/2026-10-28-provider-candidates/` 时也不会自动编译或运行。
主 Goal 保持暂停；只由 Root 统一复制、按仓预检和提交，不触发任何恢复脚本或业务测试。

## 保存内容与资格

- `nocompat/`：已审的 6 个生产文件、9 个迁移测试所对应的 5 份函数补丁，原
  manifest（formal base／after SHA）、中文说明、review、final-evidence、原 RED 及最终
  必要小日志和独立测试／生成脚本。12 项新契约与 13 文件 211 项、full TS/lint/fmt
  只绑定原 exact ignored 快照；未合流源码不得继承这些资格。
- `documentation/`：EKO ADR0057／GUI guide 小补丁及单列的 Delivery 中文官网提案。
  仅做过 apply-check 和 13 个实际消费者路径检查；维护暂停到达时**尚未独立文档审查**。
  官网提案不授权修改自动镜像、manifest 或部署。
- `actual-backend-bridge/`：合法 single/multi producer 捕获模块、生成及回放脚本、基底身份、
  准备期 source bindings 和真实未运行限定。Rust 源审／语法不等于实际编译和执行，
  missing-input 负控制退出 1，不是后端通过。实际 capture／桥尚无通过资格；
  原 29/89 fixture 消费证据保原、不升级，参见 `context/b529/`。
- `recovery/`：保留固定 Git HEAD 到准确 WIP 基底的 delta，不复制完整 base/after 源。
  唯一完整 base 是固定 HEAD 中不存在的独立 capture 测试 helper；独立新增测试／捕获
  模块和生成脚本按自身文件保留。修前 late-batch RED 源也以 delta 恢复。

旧版本兼容义务由人类取消，标退役而不是 matched/pass；runtime FinalAnswer 事件／回调、
新版本 cold/history/reload/Fork/幂等、第三方签名／加密 history 的义务继续。
不改风险基线、排除范围或最终成功标准。

## 恢复方式

`recovery-plan.json` 列出准确仓库、固定 commit／blob、源 SHA 和补丁顺序。维护准备已经
在主根 scratch 中实际执行所有补丁，逐个核对 15 个 NoCompat、3 个文档、2 个 capture
after SHA，另恢复 late-batch RED 源；结果见 `restoration-receipt.json`。
这是**资料可恢复性验证**，没有运行新业务测试、没有合并当前源码。

恢复时先从仍保留的固定 Git 对象导出各 seed；先应用对应 `baseline-from-fixed-head.patch`
并逐项核 base SHA，再按 candidate_patches 顺序应用，逐项核 after SHA。独立新文件基底
从 recovery-plan 指定的 `new-file-base` 复制。只在新的主根 scratch 中做这些操作；
不能整文件覆盖 EKO／Gov／Workspace 已有新改动。固定 Git 对象缺失时停止并保留原件，
不得用当前 HEAD 或同名文件冒充旧基底。

各原始脚本仍含原 ignored 路径和依赖，是精确原件，不会因移动到受跟踪目录变成可自动
执行入口。将来恢复必须先按新作用域明确接线；不能直接运行 finalize 等脚本改写历史。

## 证据和隐私边界

初期一轮中间 NoCompat 回归日志曾同名覆盖：原 exit1 仍在 run.json，第一次完整 stdout
不可独立恢复。该缺口继续明确保留，不重建、伪造原票。最终资格只用独立命名的最终日志。
原候选、原日志／失败、用户数据与恢复包都没有删除。

本包未选择 node_modules、.vite-cache、二进制、原生运行时目录、真实 auth/config 或私人
消息。所选小日志来自本地合成测试；敏感模式检查没有命中，见 sensitivity-assessment。
这只针对明确选择的文件，不冒称全仓凭据审计。原本路径／hash 在 preservation-manifest
保留供 Root 复核；原真实数据必须继续留在受保护位置，不能为“保全”顺手复制。

本包归属 echo-agent-cli 工程交接；其中 website 提案仅附属审阅资料，不改变其所属仓库。
恢复候选的唯一入口仍为 Root 维护保存切点清单；整体 Goal 未完成。
