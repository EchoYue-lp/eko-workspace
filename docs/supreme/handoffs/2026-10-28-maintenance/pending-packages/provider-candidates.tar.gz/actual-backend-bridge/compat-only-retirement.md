# 新用户裁决下的本边界退役清单

已读取用户亲自更新的完整 Goal，SHA-256：`cd30e66fd0135d754a42c07169a5d49692c2e779f8975b6934c1ab3da498a5bb`。这里只列当前消息呈现/历史 DTO 边界能由源码证实的兼容表面；正式源码由 EKO writer 在 reader 安全切点处理，本补件不热删。

| 源码/测试/说明 | 处理 | 新版本路径 |
|---|---|---|
| `conversation_projection.rs::AttachmentsPayload::parse` 接受旧 JSON 字符串数组并当作 thinking_segments 的分支；`attachments_payload_accepts_legacy_thinking_array` | retire 旧数组格式解析及其兼容验收；原旧 JSON/日志只归档保留，不转换为批准消息 | 新对象格式与明确 typed 字段；新版本自身 FileStore 重开/Fork/import 必测 |
| `MessageBubble.tsx` 分叉资格中的 `finalAnswerConfirmed == null && !hasNativeTimeline` | retire 依旧消息缺标记授予完整回复资格的后门；旧 fixture 不能据此冒称新资格 | 原 runtime FinalAnswer、actual terminal/publication 和产品完成事实；现 final source 只用于呈现去重，不替代完成判定 |
| `MessageBubble.flattenSteps` 中明确为 Older persisted conversations 提供的 `executionRounds` 回退及 deprecated `message.thinkingContent` 历史正文回退 | 在当前生产者统一到新 timeline 后 retire 旧记录回退，不猜 Reasoning/phase | canonical assistant blocks + 当前 executionSteps 工具引用。注意 `executionRounds` 仍有本版本 producer，不能直接整字段当死代码删除；由 writer 同步迁移现 producer 后移除重复投影 |
| `types/api.ts` 把 `executionSteps` 注释成 backward compat/deprecated、建议改用 rounds | retire 过时说明，不能连带删除新 native 时间线正在使用的顺序字段 | 明确 `executionSteps` 当前为 assistant/tool 的实际呈现顺序，与块序号域分开 |

以下不属于旧版本兼容，不因裁决删除：

- 新版本新产生的 single/multi Unknown、Guard transform、原 FileStore/journal 的冷恢复、reload、Fork/import、幂等与原副作用不重放。
- 第三方协议要求的签名、加密 Reasoning、原 provider history/source identity。
- 普通进度尚无最终 publication、真实投影加载失败或丢失时保留已经安全发布的消息/最终文本。这是本版本的异常路径，不是为旧资料缺字段推导新 phase 或成功资格。
- DOM clipboard fallback 属于当前浏览器能力处理，不是旧 Agent/schema 兼容。
- `produce_and_reopen(transform)` 的内部测试默认参数 wrapper 只复用现测试 factory，不解析旧协议；single/multi 新参数直接生产真实响应。

本次 actual backend bridge 只接受新捕获 schema、指定 Rust 原标记和外部固定 SHA；不会解析旧 wrapper，不从多块 JSON 剪出单块，也不把原 29/89 fixture 消费票升级成实际后端通过。上述 compat-only 行应标记 `retired_by_user_decision`，不能标成 matched/pass；原失败、原件、tag 与恢复材料继续保留。
