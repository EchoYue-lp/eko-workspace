import { defineConfig } from 'vitest/config';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import {
  loadCapturedBackend,
  loadFrontendSources,
  mainRoot,
  artifact,
  hash,
} from './capture-inputs.mjs';

// 缺真实原件在收集测试前即失败，禁止skip/旧fixture回退。
loadCapturedBackend();
const sources = loadFrontendSources();
const loaded: Record<string, { sha256: string; source: string }> = {};
export default defineConfig({
  root: artifact,
  cacheDir: resolve(artifact, '.vite-cache'),
  esbuild: { jsx: 'automatic' },
  plugins: [
    {
      name: 'exact-latest-eko-source-binding',
      enforce: 'pre',
      load(id) {
        const original = id.split('?')[0];
        const binding = sources.files.get(original);
        if (!binding) return;
        const bytes = readFileSync(binding.path);
        if (hash(bytes) !== binding.sha256)
          throw new Error(`运行中前端binding漂移：${binding.path}`);
        return bytes.toString('utf8');
      },
      transform(code, id) {
        const original = id.split('?')[0];
        if (!original.startsWith(mainRoot + '/echo-agent-cli/web-frontend/src/')) return;
        loaded[original.slice(mainRoot.length + 1)] = {
          sha256: hash(Buffer.from(code)),
          source: sources.files.has(original)
            ? 'exact_source_binding'
            : 'formal_readonly_dependency',
        };
        writeFileSync(
          resolve(artifact, 'actual-bridge-loaded-inputs.json'),
          JSON.stringify(loaded, null, 2) + '\n'
        );
      },
    },
  ],
  server: { fs: { allow: [mainRoot] } },
  test: {
    include: ['actual-backend-replay.test.tsx'],
    environment: 'jsdom',
    reporters: ['verbose'],
  },
});
