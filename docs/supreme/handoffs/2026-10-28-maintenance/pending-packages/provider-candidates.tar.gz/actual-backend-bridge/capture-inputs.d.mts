import type {
  AssistantMessageBlock,
  ChatEventEnvelope,
  NativeExecutionStatus,
  SavedMessage,
} from '../../../../../../../echo-agent-cli/web-frontend/src/types/api';

export interface OriginalReceipt {
  path: string;
  sha256: string;
  buffer?: Buffer;
}
export interface CapturedCase {
  case_id: string;
  requested_unknown_blocks: 1 | 2;
  guard_transform: boolean;
  workspace_id: string;
  conversation_id: string;
  root_turn_id: string;
  target_workspace_id: string;
  target_conversation_id: string;
  data: {
    source_get_message: SavedMessage;
    target_get_message: SavedMessage;
    envelopes: ChatEventEnvelope[];
    actual_terminal: NativeExecutionStatus;
    canonical_message: {
      assistant_blocks: AssistantMessageBlock[];
      approved_assistant_blocks: AssistantMessageBlock[];
      execution_status: NativeExecutionStatus;
    };
  };
}
export const artifact: string;
export const mainRoot: string;
export function hash(bytes: Uint8Array): string;
export function loadCapturedBackend(env?: NodeJS.ProcessEnv): {
  index: { compiled_source_sha256: Record<string, string> };
  cases: CapturedCase[];
  originals: OriginalReceipt[];
  backendReceipt: OriginalReceipt;
  indexReceipt: OriginalReceipt;
  logReceipt: OriginalReceipt;
};
export function loadFrontendSources(env?: NodeJS.ProcessEnv): {
  receipt: OriginalReceipt;
  files: Map<string, OriginalReceipt>;
};
