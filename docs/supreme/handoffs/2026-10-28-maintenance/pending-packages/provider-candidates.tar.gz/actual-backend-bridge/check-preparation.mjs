import ts from 'typescript';
import { ESLint } from 'eslint';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { mainRoot, artifact } from './capture-inputs.mjs';

const frontend = resolve(mainRoot, 'echo-agent-cli/web-frontend');
const config = ts.readConfigFile(resolve(frontend, 'tsconfig.app.json'), ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, frontend);
const options = {
  ...parsed.options,
  types: [resolve(frontend, 'node_modules/vite/client')],
  noEmit: true,
  incremental: false,
  tsBuildInfoFile: undefined,
};
const host = ts.createCompilerHost(options);
host.getCurrentDirectory = () => frontend;
const program = ts.createProgram(
  [
    resolve(artifact, 'actual-backend-replay.test.tsx'),
    resolve(artifact, 'bridge.vitest.config.mts'),
  ],
  options,
  host
);
const diagnostics = ts.getPreEmitDiagnostics(program);
const output = ts.formatDiagnosticsWithColorAndContext(diagnostics, {
  getCurrentDirectory: () => mainRoot,
  getCanonicalFileName: (file) => file,
  getNewLine: () => '\n',
});
writeFileSync(
  resolve(artifact, 'typescript-bridge.log'),
  output || 'TypeScript bridge preparation: zero diagnostics; actual capture replay not run\n'
);
const eslint = new ESLint({ cwd: frontend });
const results = await eslint.lintText(
  readFileSync(resolve(artifact, 'actual-backend-replay.test.tsx'), 'utf8'),
  { filePath: resolve(frontend, 'src/components/chat/ActualBackendReplay.test.tsx') }
);
const formatted = (await eslint.loadFormatter('stylish')).format(results);
writeFileSync(
  resolve(artifact, 'eslint-bridge.log'),
  formatted || 'ESLint bridge preparation: zero errors/warnings\n'
);
console.log(output || 'TypeScript bridge preparation: zero diagnostics');
console.log(formatted || 'ESLint bridge preparation: zero errors/warnings');
process.exitCode =
  diagnostics.length || results.some((item) => item.errorCount || item.warningCount) ? 1 : 0;
