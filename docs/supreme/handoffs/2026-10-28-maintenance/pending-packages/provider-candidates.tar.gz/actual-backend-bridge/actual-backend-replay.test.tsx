import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type {
  ChatEventEnvelope,
  ChatMessage,
  ConversationRecord,
  SavedMessage,
} from '../../../../../../../echo-agent-cli/web-frontend/src/types/api';
import { MessageBubble } from '../../../../../../../echo-agent-cli/web-frontend/src/components/chat/MessageBubble';
import { handleChatEventEnvelope } from '../../../../../../../echo-agent-cli/web-frontend/src/hooks/chatEventHandler';
import { useChatStore } from '../../../../../../../echo-agent-cli/web-frontend/src/stores/chatStore';
import { useConversationStore } from '../../../../../../../echo-agent-cli/web-frontend/src/stores/conversationStore';
import { useWorkspaceStore } from '../../../../../../../echo-agent-cli/web-frontend/src/stores/workspaceStore';
import { useTaskRuntimeStore } from '../../../../../../../echo-agent-cli/web-frontend/src/stores/taskRuntimeStore';
import { useToolExecutionStore } from '../../../../../../../echo-agent-cli/web-frontend/src/stores/toolExecutionStore';
import { useSubagentRunStore } from '../../../../../../../echo-agent-cli/web-frontend/src/stores/subagentRunStore';
import { loadCapturedBackend, type CapturedCase } from './capture-inputs.mjs';

const captured = loadCapturedBackend();
const mocks = vi.hoisted(() => ({ get: vi.fn(), restore: vi.fn(), tools: vi.fn() }));
vi.mock('../../../../../../../echo-agent-cli/web-frontend/src/api/endpoints', () => ({
  conversationApi: { get: mocks.get, restore: mocks.restore },
  toolExecutionApi: { list: mocks.tools },
  sessionApi: {},
}));

function selectPage(workspaceId: string, conversationId: string) {
  // 仅建立消费者的page容器。模型/执行/消息/批准集合/坐标全部读取Rust原件，不在这里补造。
  useWorkspaceStore.setState({
    current: {
      id: workspaceId,
      name: 'actual capture replay page',
      root: '/unused-capture-page',
      kind: { type: 'local' },
      metadata: { tags: [] },
      product_data_generation: 'test-page-only-no-native-generation-claim',
      created_at: '2026-10-28T00:00:00Z',
      last_active: '2026-10-28T00:00:00Z',
    },
    isLoading: false,
  });
  useConversationStore.setState({ workspaceId, activeId: conversationId });
}

function originalRecord(
  caseData: Pick<CapturedCase, 'conversation_id' | 'target_conversation_id'>,
  message: SavedMessage,
  target = false
): ConversationRecord {
  const conversationId = String(
    target ? caseData.target_conversation_id : caseData.conversation_id
  );
  // get_record的无关外壳仅满足原load入口；messages[0]是未经修改的Rust get投影原件。
  return {
    id: conversationId,
    conversation_id: conversationId,
    title: 'captured get projection',
    messages: [message],
    created_at: '',
    updated_at: '',
  };
}

function current(): ChatMessage {
  const message = useChatStore.getState().messages.at(-1);
  if (!message) throw new Error('真实DTO未经过现conversationStore投影为消息');
  return message;
}

function expectSingleFinal(
  original: SavedMessage,
  rawBlocks: { delta: string }[],
  transformed: boolean
) {
  const text = original.content;
  expect(typeof text).toBe('string');
  if (typeof text !== 'string' || !text.trim()) throw new Error('实际get原件没有安全最终正文');
  expect(screen.getAllByText(text, { selector: 'p' })).toHaveLength(1);
  for (const raw of rawBlocks) {
    if (transformed || raw.delta !== text)
      expect(screen.queryAllByText(raw.delta, { selector: 'p' })).toHaveLength(0);
  }
}

beforeEach(() => {
  cleanup();
  useChatStore.getState().clearMessages();
  useTaskRuntimeStore.getState().reset();
  useToolExecutionStore.getState().clear();
  useSubagentRunStore.getState().clear();
  mocks.get.mockReset();
  mocks.restore.mockReset().mockResolvedValue({});
  mocks.tools.mockReset().mockResolvedValue([]);
});
afterEach(cleanup);

describe.each(captured.cases)('实际Rust原件回放 $case_id', (caseData) => {
  const dto = caseData.data.source_get_message as SavedMessage;
  const importedDto = caseData.data.target_get_message as SavedMessage;
  const raw = caseData.data.canonical_message.assistant_blocks as { delta: string }[];

  it('single/multi来自独立真实producer，原raw/approved和checksum不被桥改写', () => {
    expect(raw).toHaveLength(caseData.requested_unknown_blocks);
    expect(caseData.data.canonical_message.approved_assistant_blocks).toHaveLength(
      caseData.guard_transform ? 0 : caseData.requested_unknown_blocks
    );
    expect(caseData.data.canonical_message.execution_status.status).toBe('candidate');
    expect(caseData.data.actual_terminal.status).toBe('settled');
    expect(dto.final_answer_confirmed).toBe(true);
    expect(dto.final_answer_source?.blocks).toHaveLength(
      caseData.guard_transform ? 0 : caseData.requested_unknown_blocks
    );
  });

  it('真实原envelopes驱动handler/store/WholeBubble并消费实际get原件', async () => {
    selectPage(caseData.workspace_id, caseData.conversation_id);
    useChatStore.getState().startAssistantMessage(caseData.root_turn_id);
    const ctx = {
      assistantIdRef: { current: caseData.root_turn_id as string | null },
      currentMessageKeyRef: { current: caseData.root_turn_id as string | null },
      currentMessageIdRef: { current: caseData.root_turn_id as string | null },
      isCancelledRef: { current: false },
      currentThinkingIdRef: { current: null as string | null },
    };
    mocks.get.mockResolvedValue(originalRecord(caseData, dto));
    const originalBytes = JSON.stringify(caseData.data);
    await act(async () => {
      for (const original of caseData.data.envelopes as ChatEventEnvelope[])
        handleChatEventEnvelope(original, ctx);
      await Promise.resolve();
    });
    render(<MessageBubble message={current()} />);
    expectSingleFinal(dto, raw, caseData.guard_transform);
    expect(mocks.get).toHaveBeenCalledTimes(1);
    expect(mocks.get).toHaveBeenCalledWith(caseData.workspace_id, caseData.conversation_id);
    expect(JSON.stringify(caseData.data)).toBe(originalBytes);
  });

  it('真实source cold get原件经过现conversationStore/WholeBubble仅一份最终正文', async () => {
    selectPage(caseData.workspace_id, caseData.conversation_id);
    mocks.get.mockResolvedValue(originalRecord(caseData, dto));
    await useConversationStore.getState().loadConversation(caseData.conversation_id);
    render(<MessageBubble message={current()} />);
    expectSingleFinal(dto, raw, caseData.guard_transform);
  });

  it('真实import target重开get原件沿相同cold路径保原identity且仅一份正文', async () => {
    selectPage(caseData.target_workspace_id, caseData.target_conversation_id);
    mocks.get.mockResolvedValue(originalRecord(caseData, importedDto, true));
    await useConversationStore.getState().loadConversation(caseData.target_conversation_id);
    render(<MessageBubble message={current()} />);
    expectSingleFinal(importedDto, raw, caseData.guard_transform);
  });
});
