import { parseArgs } from 'node:util';
import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import {
  artifact,
  mainRoot,
  hash,
  loadCapturedBackend,
  loadFrontendSources,
} from './capture-inputs.mjs';

const receiptPath = resolve(artifact, 'actual-backend-bridge-status.json');
try {
  const { values } = parseArgs({
    options: {
      'rust-log': { type: 'string' },
      'rust-log-sha256': { type: 'string' },
      'index-sha256': { type: 'string' },
      'frontend-sources': { type: 'string' },
      'frontend-sources-sha256': { type: 'string' },
      'backend-sources': { type: 'string' },
      'backend-sources-sha256': { type: 'string' },
    },
  });
  const env = {
    ...process.env,
    EKO_NATIVE_TIMELINE_CAPTURE_LOG: values['rust-log'],
    EKO_NATIVE_TIMELINE_CAPTURE_LOG_SHA256: values['rust-log-sha256'],
    EKO_NATIVE_TIMELINE_CAPTURE_INDEX_SHA256: values['index-sha256'],
    EKO_NATIVE_TIMELINE_FRONTEND_SOURCES: values['frontend-sources'],
    EKO_NATIVE_TIMELINE_FRONTEND_SOURCES_SHA256: values['frontend-sources-sha256'],
    EKO_NATIVE_TIMELINE_BACKEND_SOURCES: values['backend-sources'],
    EKO_NATIVE_TIMELINE_BACKEND_SOURCES_SHA256: values['backend-sources-sha256'],
  };
  const captured = loadCapturedBackend(env);
  const sources = loadFrontendSources(env);
  const run = spawnSync(
    resolve(mainRoot, 'echo-agent-cli/web-frontend/node_modules/.bin/vitest'),
    ['run', '--config', resolve(artifact, 'bridge.vitest.config.mts')],
    { cwd: mainRoot, env, encoding: 'utf8' }
  );
  const output = (run.stdout ?? '') + (run.stderr ?? '');
  writeFileSync(resolve(artifact, 'actual-backend-whole-bubble.log'), output);
  if (run.error) throw run.error;
  const allOriginals = [...captured.originals, sources.receipt, ...sources.files.values()];
  for (const input of allOriginals)
    if (hash(readFileSync(input.path)) !== input.sha256)
      throw new Error(`回放期间原件/源码漂移：${input.path}`);
  const passed =
    run.status === 0 &&
    !output.includes('Unhandled Errors') &&
    /Tests\s+16 passed \(16\)/.test(output);
  const receipt = {
    status: passed ? 'actual_captured_backend_dto_replay_pass' : 'actual_backend_replay_failed',
    actual_backend_pass: passed,
    exit_code: run.status,
    test_count_expected: 16,
    original_index: captured.indexReceipt,
    original_rust_log: captured.logReceipt,
    expected_backend_sources: captured.backendReceipt,
    compiled_rust_source_sha256: captured.index.compiled_source_sha256,
    frontend_sources: sources.receipt,
    replay_log_sha256: hash(Buffer.from(output)),
    originals_unchanged: true,
    evidence_boundary:
      'Rust原ReAct/Guard/FileStore/journal/import/get投影原件 + 原handler/conversationStore/WholeBubble；非真实外部模型API或native UI验收；page容器generation仅为测试环境',
  };
  writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt, null, 2));
  process.exitCode = passed ? 0 : 1;
} catch (error) {
  const receipt = {
    status: 'blocked_missing_or_invalid_actual_inputs',
    exit_code: 1,
    actual_backend_pass: false,
    error: error instanceof Error ? error.message : String(error),
    fixture_fallback: false,
    cargo_run_by_bridge: false,
  };
  writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');
  console.error(JSON.stringify(receipt, null, 2));
  process.exitCode = 1;
}
