import { readFileSync, realpathSync } from 'node:fs';
import { dirname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

export const artifact = dirname(fileURLToPath(import.meta.url));
export const mainRoot = resolve(artifact, '../../../../../../..');
const artifactRoot = resolve(mainRoot, '.echo-semantic/local') + sep;
export const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');

function required(env, name) {
  const value = env[name];
  if (!value) throw new Error(`缺少 ${name}：真实后端桥待执行，不允许 fixture fallback`);
  return value;
}

function original(path, expectedSha, bytes, artifactsOnly = true) {
  const real = realpathSync(path);
  if (!real.startsWith(artifactsOnly ? artifactRoot : mainRoot + sep))
    throw new Error(`输入必须是主根${artifactsOnly ? 'ignored原件' : '源码'}：${real}`);
  if (!/^[a-f0-9]{64}$/.test(expectedSha)) throw new Error(`缺少精确SHA-256：${real}`);
  const buffer = readFileSync(real);
  assert.equal(hash(buffer), expectedSha, `原件hash不匹配：${real}`);
  if (bytes !== undefined) assert.equal(buffer.length, bytes, `原件bytes不匹配：${real}`);
  return { path: real, sha256: expectedSha, buffer };
}

export function loadFrontendSources(env = process.env) {
  const file = required(env, 'EKO_NATIVE_TIMELINE_FRONTEND_SOURCES');
  const sha = required(env, 'EKO_NATIVE_TIMELINE_FRONTEND_SOURCES_SHA256');
  const sourceReceipt = original(file, sha);
  const document = JSON.parse(sourceReceipt.buffer.toString('utf8'));
  assert.equal(document.schema_version, 1, 'frontend binding schema不匹配');
  const requiredFiles = [
    'types/api.ts',
    'stores/chatStore.ts',
    'stores/conversationStore.ts',
    'hooks/chatEventHandler.ts',
    'components/chat/NativeMessageTimeline.tsx',
    'components/chat/MessageBubble.tsx',
  ].map((file) => 'echo-agent-cli/web-frontend/src/' + file);
  const files = new Map();
  for (const path of requiredFiles) {
    const binding = document.files?.[path];
    assert.ok(binding, `latest frontend source binding缺项：${path}`);
    const item = original(binding.path, binding.sha256, undefined, false);
    files.set(resolve(mainRoot, path), item);
  }
  return { receipt: { path: sourceReceipt.path, sha256: sourceReceipt.sha256 }, files };
}

export function loadCapturedBackend(env = process.env) {
  const log = original(
    required(env, 'EKO_NATIVE_TIMELINE_CAPTURE_LOG'),
    required(env, 'EKO_NATIVE_TIMELINE_CAPTURE_LOG_SHA256')
  );
  const text = log.buffer.toString('utf8');
  assert.match(text, /native_unknown_actual_backend_replay_capture/, '日志缺指定实际Rust测试入口');
  assert.match(
    text,
    /test result: ok\. 1 passed; 0 failed;/,
    'Rust捕获测试缺真实成功总结，不能只凭中间JSON标记通过'
  );
  assert.equal(
    (text.match(/test result:/g) ?? []).length,
    1,
    '必须提供本次单一capture命令的原始日志，不能混用多批成功/失败总结'
  );
  function markers(name) {
    return text
      .split(/\r?\n/)
      .filter((line) => line.includes(name))
      .map((line) => JSON.parse(line.slice(line.indexOf(name) + name.length)));
  }
  const indices = markers('EKO_NATIVE_TIMELINE_CAPTURE_INDEX:');
  assert.equal(indices.length, 1, 'nocapture必须恰有一条真实capture index标记');
  const descriptor = indices.at(0);
  assert.equal(
    descriptor.sha256,
    required(env, 'EKO_NATIVE_TIMELINE_CAPTURE_INDEX_SHA256'),
    '外部固定index SHA与Rust标记不符'
  );
  const indexFile = original(descriptor.path, descriptor.sha256, descriptor.bytes);
  const index = JSON.parse(indexFile.buffer.toString('utf8'));
  assert.equal(index.schema_version, 1);
  assert.equal(index.producer_test, 'native_unknown_actual_backend_replay_capture');
  const backendReceipt = original(
    required(env, 'EKO_NATIVE_TIMELINE_BACKEND_SOURCES'),
    required(env, 'EKO_NATIVE_TIMELINE_BACKEND_SOURCES_SHA256')
  );
  const expectedBackend = JSON.parse(backendReceipt.buffer.toString('utf8'));
  assert.equal(expectedBackend.schema_version, 1);
  const backendSources = [];
  for (const field of [
    'helper',
    'capture_module',
    'get_projection',
    'native_publication_projection',
  ]) {
    assert.match(
      index.compiled_source_sha256?.[field] ?? '',
      /^[a-f0-9]{64}$/,
      `缺编译源输入hash：${field}`
    );
    const binding = expectedBackend.sources?.[field];
    assert.ok(binding, `缺显式expected Rust输入：${field}`);
    const source = original(binding.path, binding.sha256, undefined, false);
    assert.equal(
      index.compiled_source_sha256[field],
      source.sha256,
      `捕获来自不同Rust源码快照：${field}；保留为异快照资料，不得冒称same-source通过`
    );
    backendSources.push({ path: source.path, sha256: source.sha256 });
  }
  const files = markers('EKO_NATIVE_TIMELINE_CAPTURE_FILE:');
  const expectedCases = [
    'normal-unknown-1',
    'normal-unknown-2',
    'guard-unknown-1',
    'guard-unknown-2',
  ];
  assert.deepEqual(
    index.cases?.map((item) => item.case_id).sort(),
    expectedCases.sort(),
    '真实single/multi及Guard捕获不完整，不能用一份multi JSON补造case'
  );
  const originals = [
    { path: log.path, sha256: log.sha256 },
    { path: indexFile.path, sha256: indexFile.sha256 },
    { path: backendReceipt.path, sha256: backendReceipt.sha256 },
    ...backendSources,
  ];
  const cases = index.cases.map((item) => {
    const data = {};
    for (const field of [
      'source_stored',
      'canonical_message',
      'envelopes',
      'source_get_message',
      'native_history_import',
      'actual_terminal',
      'target_stored',
      'target_get_message',
    ]) {
      const receipt = item[field];
      assert.ok(receipt, `缺独立原件：${item.case_id}/${field}`);
      assert.equal(
        files.filter(
          (entry) =>
            entry.path === receipt.path &&
            entry.sha256 === receipt.sha256 &&
            entry.bytes === receipt.bytes
        ).length,
        1,
        `原件必须匹配本次Rust原始文件标记：${field}`
      );
      const source = original(receipt.path, receipt.sha256, receipt.bytes);
      data[field] = JSON.parse(source.buffer.toString('utf8'));
      originals.push({ path: source.path, sha256: source.sha256 });
    }
    // 证据链只做原件绑定：不重演最终校验、phase选择或任何生产validator。
    assert.equal(
      item.source_message_sha256,
      item.canonical_message.sha256,
      '原canonical字节hash不一致'
    );
    assert.equal(
      data.native_history_import.message_content_sha256,
      item.source_message_sha256,
      'import原source checksum不一致'
    );
    assert.deepEqual(data.native_history_import.events, data.envelopes, 'import未保原始envelopes');
    return { ...item, data };
  });
  return {
    index,
    cases,
    originals,
    backendReceipt: { path: backendReceipt.path, sha256: backendReceipt.sha256 },
    indexReceipt: { path: indexFile.path, sha256: indexFile.sha256 },
    logReceipt: { path: log.path, sha256: log.sha256 },
  };
}
