import { parseArgs } from 'node:util';
import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { resolve, sep } from 'node:path';
import { hash, mainRoot } from './capture-inputs.mjs';

const { values } = parseArgs({
  options: {
    'eko-root': { type: 'string' },
    'overlay-root': { type: 'string' },
    output: { type: 'string' },
  },
});
if (!values['eko-root'] || !values.output)
  throw new Error(
    '必须显式给 --eko-root 和新的 --output；可选 --overlay-root 必须是EKO最新after-base'
  );
const eko = realpathSync(values['eko-root']);
const overlay = values['overlay-root'] ? realpathSync(values['overlay-root']) : null;
const output = resolve(values.output);
if (!output.startsWith(resolve(mainRoot, '.echo-semantic/local') + sep))
  throw new Error('binding必须写主根ignored工程目录');
const files = {};
for (const rel of [
  'types/api.ts',
  'stores/chatStore.ts',
  'stores/conversationStore.ts',
  'hooks/chatEventHandler.ts',
  'components/chat/NativeMessageTimeline.tsx',
  'components/chat/MessageBubble.tsx',
]) {
  // 显式overlay只承载已改的五文件；原MessageBubble始终从显式eko-root读取并绑定。
  const useOverlay = overlay && rel !== 'components/chat/MessageBubble.tsx';
  const source = realpathSync(resolve(useOverlay ? overlay : eko, 'web-frontend/src', rel));
  if (!source.startsWith(mainRoot + sep)) throw new Error(`源码必须位于主根：${source}`);
  files['echo-agent-cli/web-frontend/src/' + rel] = {
    path: source,
    sha256: hash(readFileSync(source)),
    source: useOverlay ? 'explicit_latest_eko_overlay' : 'explicit_eko_source_root',
  };
}
const bytes = Buffer.from(JSON.stringify({ schema_version: 1, files }, null, 2) + '\n');
writeFileSync(output, bytes, { flag: 'wx' });
console.log(JSON.stringify({ path: output, sha256: hash(bytes) }));
