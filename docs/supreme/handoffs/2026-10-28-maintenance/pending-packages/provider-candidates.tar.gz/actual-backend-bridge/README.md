# 实际 Rust DTO → Whole Bubble 桥补件

本目录是 b529 完整候选的增量，不修改或升级上级目录原 29/89 fixture 票。正式 EKO 仍由唯一 writer 在 B 安全点合入；本会话没有运行 Cargo、改正式源或触碰 liveUI/用户数据。

## Rust 原件生产

`rust-producer-capture.patch` 仅改当前 `conversations_native_history_tests.rs` 的原 factory 函数，并挂载 test-only `native_timeline_actual_backend_capture.rs`：

- `produce_and_reopen(transform)` 保留其现测试默认两块；新增参数 helper 接受 1/2，分别直接生成完整单块 `SECRET-DRAFT` 或原两块 `SECRET-`/`DRAFT`，各自调用原 ReAct，自然形成 raw/approved/publications。
- 新显式捕获测试依次运行 normal/Guard × single/multi 四个真实 producer。原 Guard 校验、FileStore 与 ChatEventLog 关闭/重开、实际 get 消息投影、原 NativeHistoryImport/checksum 与 target FileStore 冷重开保持原路径。
- 每个 case 保存 8 份独立、不可覆盖的原件：source StoredMessage、restore 后 canonical Message、原 envelopes、source get-message DTO、原 import、实际 terminal、target StoredMessage、target get-message DTO。
- 输出 `EKO_NATIVE_TIMELINE_CAPTURE_FILE:` 和唯一 `EKO_NATIVE_TIMELINE_CAPTURE_INDEX:` 标记，附原字节 SHA-256/长度。index 还包含编译时 `include_bytes!` 的 helper/capture/getter/publication 四项源码 SHA。
- 这是显式 opt-in 捕获测试，**没有运行就保持待执行**。`#[ignore]` 不代表兼容测试被跳过后通过；指定 `--ignored` 运行时缺捕获目录会报错，没有 fallback。

owner 合入补丁后在原受控 manifest/target/jobs 窗执行，不另起重型窗；示意命令：

```sh
# cwd: echo-agent-cli；捕获目录和 TMPDIR 均使用主根ignored中的新目录。
EKO_NATIVE_TIMELINE_CAPTURE_DIR=/主根/.echo-semantic/local/本轮新捕获目录 \
cargo test --locked -p echo-agent-cli --bin echo-agent-tauri \
  native_unknown_actual_backend_replay_capture -- --ignored --nocapture --test-threads=1
```

保存完整原 stdout/stderr、自然退出码、精确编译输入与监督回执。index 文件输出到指定目录，不能覆盖前次原件；不要从 multi JSON 删除块制造 single。

## 固定前后端输入

在实际 Rust source 冻结后生成 expected backend receipt；源码 hash 必须和 index 的编译时 hash 一致：

```sh
node /本目录/bind-backend.mjs --eko-root /主根/echo-agent-cli \
  --output /主根/.echo-semantic/local/新backend-sources.json
node /本目录/bind-frontend.mjs --eko-root /主根/echo-agent-cli \
  --output /主根/.echo-semantic/local/新frontend-sources.json
```

两工具都只新建 receipt，打印其 path/SHA。若 owner 在 ignored 三方合源上编译，`bind-backend --capture-root` 显式指定真正 helper/capture 源目录，`bind-frontend --overlay-root` 显式指定五个已改前端文件的最新 after-base；文件缺失直接失败，不回读旧候选补齐。

本目录的 `frontend-sources-current-144.json` 是当时正式前端已接 b529 的读回绑定。`backend-sources-prepared-144.json` 只绑定准备中的 capture 源，不证明它已编译；EKO 合入并格式化后必须按最终实际源码重生 binding，不靠文件名宣称 current。

## 只读回放

```sh
node /本目录/run-actual-bridge.mjs \
  --rust-log /主根/.echo-semantic/local/原nocapture.log \
  --rust-log-sha256 原日志SHA \
  --index-sha256 Rust标记里的原indexSHA \
  --backend-sources /主根/.echo-semantic/local/冻结backend-sources.json \
  --backend-sources-sha256 该receiptSHA \
  --frontend-sources /主根/.echo-semantic/local/冻结frontend-sources.json \
  --frontend-sources-sha256 该receiptSHA
```

桥强制核对：指定 Rust 测试真实成功总结；唯一 index 标记与外部固定 SHA；四个独立 case；每份原件与本次 FILE 标记、长度、hash 一致；原 canonical/import checksum 与完整原 envelopes；四项编译源码 hash 与显式 expected receipt 相等；前端六个明确绑定源文件不漂移。旧 Rust 捕获与新前端输入不能混成 same-source pass。

16 个前端测试直接读取原件：每 case 检查真实 producer 输出，并运行原 envelopes→handler→store→完整 MessageBubble、source cold get→conversationStore→Whole Bubble、import target cold get→相同 consumer。get 的 messages[0] 是未修改的实际 Rust DTO；只提供测试页面外壳，不补造执行/模型/块/批准坐标。UI page generation 是测试容器，不冒充 native registry/generation 验收。

Vite loader 只加载显式固定的当前正式/after-base 源码；不使用上级 29 项中的 DTO fixture。必须恰好 16 项通过、无 skip/Unhandled Errors 才能写桥 pass；原件/源码在回放结束后再次核 hash。

缺日志、字段、hash、receipt 或发生快照漂移直接退出 1，`actual-backend-bridge-status.json` 保持 `actual_backend_pass:false`。当前没有真实捕获输入，因此实际桥尚未运行/通过；静态 TS/ESLint/语法通过不升级此资格。

## 新用户裁决

本桥只消费本版本新生产的 typed 原件，不解析旧 wrapper/旧 schema、不维护旧日志运行时回退。新版本自身 cold/Fork/import 恢复仍是必备功能。确实 compat-only 的退役清单见 `compat-only-retirement.md`；旧原件和失败证据保留，取消的兼容验收标 retire 而不标 pass。
