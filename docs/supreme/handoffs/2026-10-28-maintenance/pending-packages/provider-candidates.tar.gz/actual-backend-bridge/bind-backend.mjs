import { parseArgs } from 'node:util';
import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { resolve, sep } from 'node:path';
import { hash, mainRoot } from './capture-inputs.mjs';

const { values } = parseArgs({
  options: {
    'eko-root': { type: 'string' },
    'capture-root': { type: 'string' },
    output: { type: 'string' },
  },
});
if (!values['eko-root'] || !values.output)
  throw new Error(
    '必须显式给 --eko-root 和新 --output；可选 --capture-root 指定已冻结的真实编译capture源码'
  );
const eko = realpathSync(values['eko-root']);
const captureRoot = values['capture-root'] ? realpathSync(values['capture-root']) : eko;
const output = resolve(values.output);
if (!output.startsWith(resolve(mainRoot, '.echo-semantic/local') + sep))
  throw new Error('backend binding必须写主根ignored目录');
const sources = {};
for (const [key, base, rel] of [
  ['helper', captureRoot, 'src/tauri/commands/conversations_native_history_tests.rs'],
  ['capture_module', captureRoot, 'src/tauri/commands/native_timeline_actual_backend_capture.rs'],
  ['get_projection', eko, 'src/tauri/commands/conversations.rs'],
  ['native_publication_projection', eko, 'echo-agent-app-core/src/conversation_projection.rs'],
]) {
  const path = realpathSync(resolve(base, rel));
  if (!path.startsWith(mainRoot + sep)) throw new Error(`backend输入必须位于主根：${path}`);
  sources[key] = { path, sha256: hash(readFileSync(path)) };
}
const bytes = Buffer.from(JSON.stringify({ schema_version: 1, sources }, null, 2) + '\n');
writeFileSync(output, bytes, { flag: 'wx' });
console.log(JSON.stringify({ path: output, sha256: hash(bytes) }));
