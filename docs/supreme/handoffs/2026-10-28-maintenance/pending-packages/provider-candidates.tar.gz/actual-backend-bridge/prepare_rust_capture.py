"""只对当前tests670函数生成补件，不覆盖EKO的V5/perf/b529其它hunk。"""
from pathlib import Path
import difflib
import hashlib
import json

p=Path(__file__).resolve().parent
root=p.parents[6]
rel='echo-agent-cli/src/tauri/commands/conversations_native_history_tests.rs'
source=(root/rel).read_text()
anchor='''async fn produce_and_reopen(transform: bool) -> anyhow::Result<ColdNativeFixture> {
    let root = tempfile::tempdir()?;
    let raw: Vec<_> = ["SECRET-", "DRAFT"]'''
replacement='''async fn produce_and_reopen(transform: bool) -> anyhow::Result<ColdNativeFixture> {
    produce_and_reopen_with_unknown_blocks(transform, 2).await
}

// 分别构造合法single/multi响应，均由原ReAct形成raw/approved/publications；不能剪multi JSON。
async fn produce_and_reopen_with_unknown_blocks(transform: bool, block_count: usize) -> anyhow::Result<ColdNativeFixture> {
    let root = tempfile::tempdir()?;
    let parts = match block_count {
        1 => vec!["SECRET-DRAFT"],
        2 => vec!["SECRET-", "DRAFT"],
        _ => anyhow::bail!("native Unknown捕获factory只接受1或2块"),
    };
    let raw: Vec<_> = parts'''
if source.count(anchor)!=1: raise ValueError('current helper source drift, require function hunk rebase')
candidate=source.replace(anchor,replacement,1)
anchor='''struct ColdNativeFixture {'''
replacement='''#[path = "native_timeline_actual_backend_capture.rs"]
mod native_timeline_actual_backend_capture;

struct ColdNativeFixture {'''
if candidate.count(anchor)!=1: raise ValueError('current capture module insertion anchor drift')
candidate=candidate.replace(anchor,replacement,1)
target=p/'candidate'/rel
target.parent.mkdir(parents=True,exist_ok=True)
target.write_text(candidate)
module_rel='echo-agent-cli/src/tauri/commands/native_timeline_actual_backend_capture.rs'
module=(p/'native_timeline_actual_backend_capture.rs').read_text()
module_target=p/'candidate'/module_rel
module_target.write_text(module)
base=p/'base'/rel
base.parent.mkdir(parents=True,exist_ok=True)
base.write_text(source)
patch=''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
patch+=''.join(difflib.unified_diff([],module.splitlines(True),fromfile='/dev/null',tofile='b/'+module_rel))
(p/'rust-producer-capture.patch').write_text(patch)
manifest={'status':'prepared_not_compiled_no_Cargo','base':{'path':rel,'sha256':hashlib.sha256(source.encode()).hexdigest()},'files':{rel:hashlib.sha256(candidate.encode()).hexdigest(),module_rel:hashlib.sha256(module.encode()).hexdigest()},'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'official_source_write':False,'expected_cases':['normal-unknown-1','normal-unknown-2','guard-unknown-1','guard-unknown-2']}
(p/'rust-capture-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
