from pathlib import Path
import difflib,json,hashlib,subprocess
p=Path(__file__).resolve().parent;root=p.parents[4]
m=json.loads((p/'manifest.json').read_text())
groups={
 '01-bubble-functions.patch':['components/chat/MessageBubble.tsx'],
 '02-canonical-store-handler.patch':['stores/chatStore.ts','hooks/chatEventHandler.ts'],
 '03-conversation-dto.patch':['stores/conversationStore.ts','types/api.ts'],
 '04-chatpanel-functions.patch':['components/chat/ChatPanel.tsx'],
 '05-current-native-tests.patch':[],
}
parts={key:[] for key in groups}
for path,facts in m['files'].items():
 original=(p/'base'/path).read_bytes();candidate=(p/'candidate'/path).read_bytes()
 if hashlib.sha256(original).hexdigest()!=facts['base_sha256']:raise ValueError('base artifact drift '+path)
 facts['candidate_sha256']=hashlib.sha256(candidate).hexdigest()
 key=next((key for key,ends in groups.items() if any(path.endswith('/'+end) for end in ends)), '05-current-native-tests.patch')
 parts[key].append(''.join(difflib.unified_diff(original.decode().splitlines(True),candidate.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
m['patches']={}
for name,diffs in parts.items():
 text=''.join(diffs);(p/name).write_text(text)
 result=subprocess.run(['git','-C','echo-agent-cli','apply','--check','-p2','-'],cwd=root,input=text,text=True,capture_output=True)
 (p/(name+'.check.log')).write_text(result.stdout+result.stderr)
 m['patches'][name]={'sha256':hashlib.sha256(text.encode()).hexdigest(),'apply_check_exit':result.returncode}
 print(name,len(text.splitlines()),'lines','apply-check',result.returncode)
m['current_formal_matches_base']={path:hashlib.sha256((root/path).read_bytes()).hexdigest()==facts['base_sha256'] for path,facts in m['files'].items()}
(p/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
