import { defineConfig } from 'vitest/config';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const artifact = fileURLToPath(new URL('.', import.meta.url));
const root = resolve(artifact, '../../../../..');
const green = process.env.NOCOMPAT_MODE === 'green';
const regress = process.env.NOCOMPAT_REGRESS === 'true';
const loaded: Record<string, string> = {};
export default defineConfig({
  root: artifact,
  cacheDir: resolve(artifact, '.vite-cache'),
  esbuild: { jsx: 'automatic' },
  plugins: [
    {
      name: 'ignored-nocompat-frontend',
      enforce: 'pre',
      load(id) {
        const original = id.split('?')[0];
        if (!original.startsWith(root + '/echo-agent-cli/web-frontend/src/')) return;
        const rel = original.slice(root.length + 1);
        const file = resolve(artifact, green ? 'candidate' : 'base', rel);
        if (existsSync(file)) return readFileSync(file, 'utf8');
      },
      transform(code, id) {
        if (!id.startsWith(root + '/echo-agent-cli/web-frontend/src/')) return;
        loaded[id] = createHash('sha256').update(code).digest('hex');
        writeFileSync(
          resolve(artifact, (green ? 'green' : 'baseline') + '-loaded-inputs.json'),
          JSON.stringify(loaded, null, 2) + '\n'
        );
      },
    },
  ],
  server: { fs: { allow: [root] } },
  test: {
    dir: regress ? root : artifact,
    include: regress
      ? [
          'echo-agent-cli/web-frontend/src/components/chat/MessageBubble*.test.*',
          'echo-agent-cli/web-frontend/src/components/chat/NativeMessageTimeline.test.tsx',
          'echo-agent-cli/web-frontend/src/components/chat/ChatPanel.controls.test.tsx',
          'echo-agent-cli/web-frontend/src/components/task/TaskRuntimeList.test.tsx',
          'echo-agent-cli/web-frontend/src/stores/chatStore*.test.ts',
          'echo-agent-cli/web-frontend/src/hooks/chatEventHandler*.test.ts',
          'echo-agent-cli/web-frontend/src/stores/conversationStore.test.ts',
          'echo-agent-cli/web-frontend/src/types/api.contract.test.ts',
        ]
      : ['native-only-projection.test.tsx'],
    environment: 'jsdom',
    reporters: ['verbose'],
  },
});
