import ts from 'typescript';
import { ESLint } from 'eslint';
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const artifact = dirname(fileURLToPath(import.meta.url));
const root = resolve(artifact, '../../../../..');
const frontend = resolve(root, 'echo-agent-cli/web-frontend');
const manifest = JSON.parse(readFileSync(resolve(artifact, 'manifest.json'), 'utf8'));
const files = Object.keys(manifest.files);
const config = ts.readConfigFile(resolve(frontend, 'tsconfig.app.json'), ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, frontend);
const options = {
  ...parsed.options,
  types: [resolve(frontend, 'node_modules/vite/client')],
  noEmit: true,
  incremental: false,
  tsBuildInfoFile: undefined,
};
const host = ts.createCompilerHost(options);
host.getCurrentDirectory = () => frontend;
const originalRead = host.readFile.bind(host);
host.readFile = (file) => {
  const rel = file.startsWith(root + '/') ? file.slice(root.length + 1) : '';
  return files.includes(rel)
    ? readFileSync(resolve(artifact, 'candidate', rel), 'utf8')
    : originalRead(file);
};
const program = ts.createProgram(
  [...parsed.fileNames, resolve(artifact, 'native-only-projection.test.tsx')],
  options,
  host
);
const diagnostics = ts.getPreEmitDiagnostics(program);
const typeOutput = ts.formatDiagnosticsWithColorAndContext(diagnostics, {
  getCurrentDirectory: () => root,
  getCanonicalFileName: (f) => f,
  getNewLine: () => '\n',
});
writeFileSync(
  resolve(artifact, 'typecheck.log'),
  typeOutput || 'Frontend source overlay: zero TypeScript diagnostics\n'
);
console.log(typeOutput || 'Frontend source overlay: zero TypeScript diagnostics');
const eslint = new ESLint({ cwd: frontend });
const results = [];
for (const file of files)
  results.push(
    ...(await eslint.lintText(readFileSync(resolve(artifact, 'candidate', file), 'utf8'), {
      filePath: resolve(root, file),
    }))
  );
results.push(
  ...(await eslint.lintText(
    readFileSync(resolve(artifact, 'native-only-projection.test.tsx'), 'utf8'),
    { filePath: resolve(frontend, 'src/components/chat/NativeOnlyProjection.test.tsx') }
  ))
);
const lintOutput = (await eslint.loadFormatter('stylish')).format(results);
writeFileSync(
  resolve(artifact, 'lint.log'),
  lintOutput || 'Candidate source/tests: zero ESLint errors/warnings\n'
);
console.log(lintOutput || 'Candidate source/tests: zero ESLint errors/warnings');
process.exitCode =
  diagnostics.length || results.some((r) => r.errorCount || r.warningCount) ? 1 : 0;
