"""NoCompat前端函数级候选；只写ignored，正式文件由EKO/Gov合流。"""
from pathlib import Path
import difflib
import hashlib
import json

ARTIFACT=Path(__file__).resolve().parent
ROOT=ARTIFACT.parents[4]
PREFIX='echo-agent-cli/web-frontend/src/'
manifest={'status':'prepared_ignored_only','files':{}}


def read(rel):
    return (ROOT/PREFIX/rel).read_text()


def replace(s,a,b):
    if s.count(a)!=1: raise ValueError('source anchor missing or ambiguous: '+a[:100])
    return s.replace(a,b,1)


def cut(s,a,b,new=''):
    if s.count(a)!=1 or s.count(b)!=1: raise ValueError('section source anchor drift: '+a)
    start=s.index(a);end=s.index(b,start)
    return s[:start]+new+s[end:]


def save(rel,source,candidate):
    full=PREFIX+rel
    base=ARTIFACT/'base'/full
    output=ARTIFACT/'candidate'/full
    base.parent.mkdir(parents=True,exist_ok=True);output.parent.mkdir(parents=True,exist_ok=True)
    base.write_text(source);output.write_text(candidate)
    manifest['files'][full]={'base_sha256':hashlib.sha256(source.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest()}


rel='types/api.ts';source=read(rel);s=source
s=replace(s,'//   - ExecutionRound (frontend-specific aggregation)\n','')
s=cut(s,'// Execution round: one ReAct loop iteration (think → tools)\n','export type ExecutionStep =')
s=replace(s,"  | { type: 'thinking'; index: number }\n",'')
s=replace(s,'  thinkingContent?: string; // deprecated, kept for history display\n','')
s=replace(s,"  thinkingSegments?: { content: string; kind?: 'reasoning' | 'historical_execution' }[];\n",'')
s=replace(s,'  /** @deprecated Use executionRounds instead. Flat execution order tracking for backward compat. */','  /** assistant块与工具引用的实际呈现顺序；Reasoning使用原生assistant块。 */')
s=replace(s,'  /** Execution rounds: each round = one ReAct iteration (thinking + tool batch) */\n  executionRounds?: ExecutionRound[];\n','')
s=replace(s,'  thinking_segments?: string[];\n','')
s=cut(s,'  execution_rounds?: {\n','  tool_result?: string | null;')
save(rel,source,s)

rel='stores/chatStore.ts';source=read(rel);s=source
s=replace(s,'  ExecutionRound,\n','')
s=cut(s,'/** In-progress round being built during streaming */\n','export interface ChatActivity {')
s=replace(s,'  /** Current round being built during streaming */\n  currentRound: CurrentRound | null;\n','')
for line in ['  appendThinking: (id: string, token: string) => void;\n','  startThinkingSegment: (id: string) => void;\n','  startToolBatch: (toolCount: number) => void;\n','  endToolBatch: () => void;\n']:
    s=replace(s,line,'')
s=s.replace('  currentRound: null,\n','').replace('          thinkingSegments: [],\n','').replace('          executionRounds: [],\n','')
s=replace(s,'message.content || message.thinkingSegments?.length || message.executionSteps?.length','message.content || message.assistantBlocks?.length || message.executionSteps?.length')
s=cut(s,'  appendThinking: (id, token) => {\n','  setThinking: (v) =>')
s=cut(s,'      const currentRound = s.currentRound\n','    });\n    scheduleAutoSave();\n  },\n\n  /** Start a new tool batch',"      return { messages, runStatus: 'using_tool' };\n")
s=cut(s,'  /** Start a new tool batch','  // 原生终态仅提供消息来源坐标')
save(rel,source,s)

rel='hooks/chatEventHandler.ts';source=read(rel);s=source
s=replace(s,'        store.startThinkingSegment(id);','        // 起止仅是运行观测；公开Reasoning正文只消费原assistant_message块。')
s=replace(s,'      store.startToolBatch(event.tool_count ?? 0);','      // 批次仅观测；真实summary→recordToolStart维护工具状态和顺序，不重开已结算stream。')
s=replace(s,'      store.endToolBatch();','      // 工具顺序由真实summary started→recordToolStart维护；batch结束不制造完成事实。')
save(rel,source,s)

rel='stores/conversationStore.ts';source=read(rel);s=source
s=cut(s,'    // Save thinking segments\n','    // Save execution steps')
s=replace(s,"s.type === 'thinking' || s.type === 'assistant'","s.type === 'assistant'")
s=cut(s,'    // Save execution rounds','    // Save user-uploaded attachments')
s=replace(s,'      ...(message.executionRounds?.flatMap((round) => round.toolCallIds) ?? []),\n','')
s=cut(s,'    if (message.executionSteps?.length) {\n','  });\n  return saved.flatMap', '''    message.executionSteps = [
      ...(message.executionSteps ?? []),
      ...missing.map((record) => ({ type: 'tool' as const, callId: record.id })),
    ];
''')
s=cut(s,'          // Restore thinking segments\n','          // Restore chronological order')
s=cut(s,"              if (step.type === 'thinking' && step.index != null) {\n","              if (step.type === 'assistant'")
save(rel,source,s)

rel='components/chat/MessageBubble.tsx';source=read(rel);s=source
s=replace(s,"import { ThinkingSegment } from './ThinkingSegment';\n",'')
s=cut(s,'/** Project the persisted execution timeline into renderable steps. */\n','export function isExecutionProcessCompleted(','''/** 原生Reasoning由NativeMessageTimeline呈现；此投影只处理当前工具引用。 */
interface FlatStep {
  type: 'tool';
  toolId: string;
  toolIndex: number;
}

interface ToolDisplayItem {
  type: 'tools';
  toolIds: string[];
}

type ExecutionDisplayItem = ToolDisplayItem;

''')
s=cut(s,'export function flattenSteps(', '/** Read only the tool facts', '''export function flattenSteps(message: ChatMessage): { steps: FlatStep[] } {
  const steps: FlatStep[] = [];
  for (const step of message.executionSteps ?? []) {
    if (step.type === 'tool')
      steps.push({ type: 'tool', toolId: step.callId, toolIndex: steps.length });
  }
  return { steps };
}

/** 无native块的工具视图仍沿canonical步骤顺序呈现。 */
export function groupExecutionSteps(steps: FlatStep[]): ExecutionDisplayItem[] {
  return steps.length ? [{ type: 'tools', toolIds: steps.map((step) => step.toolId) }] : [];
}

''')
s=replace(s,'  const { steps, thinkingTotal } = flattenSteps(message);','  const { steps } = flattenSteps(message);')
s=replace(s,"      (!hasNativeTimeline &&\n        executionItems.some((item) => item.type === 'thinking' && item.kind !== 'reasoning')) ||\n",'')
s=replace(s,'  let thinkingIndex = 0;\n','')
s=cut(s,"                    if (item.type === 'thinking') {\n",'                    return (\n                      <ToolExecutionGroup')
s=replace(s,'                {/* Thinking + tools */}','                {/* canonical工具引用 */}')
s=replace(s,"                      (message.finalAnswerConfirmed === true ||\n                        (message.finalAnswerConfirmed == null && !hasNativeTimeline)) && (",'                      message.finalAnswerConfirmed === true && (')
save(rel,source,s)

rel='components/chat/ChatPanel.tsx';source=read(rel);s=source
s=replace(s,"import { MessageBubble } from './MessageBubble';","import { MessageBubble } from './MessageBubble';\nimport { nativeAssistantBlockText } from './NativeMessageTimeline';")
s=replace(s,'        executionSteps: undefined,\n        executionRounds: undefined,\n','')
s=replace(s,"(view) => view.content.trim() && view.block.phase !== 'final_answer'\n                      ) ||\n                      m.thinkingSegments?.some((segment) => segment.content.trim())", "(view) => view.block.phase !== 'final_answer' && nativeAssistantBlockText(view).trim()\n                      )")
save(rel,source,s)

(ARTIFACT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('prepared frontend-only NoCompat function candidates',len(manifest['files']))
