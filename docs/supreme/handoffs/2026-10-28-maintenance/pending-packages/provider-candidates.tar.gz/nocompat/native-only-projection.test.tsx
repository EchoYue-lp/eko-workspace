import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type {
  AssistantMessageBlock,
  ChatMessage,
  SavedMessage,
} from '../../../../../echo-agent-cli/web-frontend/src/types/api';
import {
  MessageBubble,
  flattenSteps,
} from '../../../../../echo-agent-cli/web-frontend/src/components/chat/MessageBubble';
import { useChatStore } from '../../../../../echo-agent-cli/web-frontend/src/stores/chatStore';
import {
  useConversationStore,
  chatMessagesToSaved,
} from '../../../../../echo-agent-cli/web-frontend/src/stores/conversationStore';
import { useTaskRuntimeStore } from '../../../../../echo-agent-cli/web-frontend/src/stores/taskRuntimeStore';
import { useSubagentRunStore } from '../../../../../echo-agent-cli/web-frontend/src/stores/subagentRunStore';
import { useToolExecutionStore } from '../../../../../echo-agent-cli/web-frontend/src/stores/toolExecutionStore';
import { handleChatEvent } from '../../../../../echo-agent-cli/web-frontend/src/hooks/chatEventHandler';

const mocks = vi.hoisted(() => ({ get: vi.fn(), restore: vi.fn(), tools: vi.fn() }));
vi.mock('../../../../../echo-agent-cli/web-frontend/src/api/endpoints', () => ({
  conversationApi: { get: mocks.get, restore: mocks.restore },
  toolExecutionApi: { list: mocks.tools },
  sessionApi: {},
}));
const base: ChatMessage = {
  id: 'native',
  role: 'assistant',
  content: '普通正文',
  timestamp: 0,
  isStreaming: false,
};
const ctx = {
  assistantIdRef: { current: 'native' as string | null },
  currentMessageKeyRef: { current: 'native' as string | null },
  currentMessageIdRef: { current: 'native' as string | null },
  isCancelledRef: { current: false },
  currentThinkingIdRef: { current: null as string | null },
};
function raw(fields: Record<string, unknown>): ChatMessage {
  return JSON.parse(JSON.stringify({ ...base, ...fields })) as ChatMessage;
}
function block(
  id: string,
  phase: AssistantMessageBlock['phase'],
  delta: string,
  sequence = 0
): AssistantMessageBlock {
  return {
    block_id: id,
    request_id: 'native-request',
    sequence,
    phase,
    delta,
    complete: true,
    provider: 'fixture',
    reasoning: null,
  };
}
beforeEach(() => {
  useChatStore.getState().clearMessages();
  useTaskRuntimeStore.getState().reset();
  useSubagentRunStore.getState().clear();
  useToolExecutionStore.getState().clear();
  ctx.assistantIdRef.current = 'native';
  ctx.isCancelledRef.current = false;
  useConversationStore.setState({ workspaceId: 'global', activeId: 'native-conversation' });
  mocks.get.mockReset();
  mocks.restore.mockReset().mockResolvedValue({});
  mocks.tools.mockReset().mockResolvedValue([]);
});
afterEach(cleanup);
describe('新唯一native消息呈现', () => {
  it('缺runtime final确认的普通正文不获得Fork资格', () => {
    render(<MessageBubble message={base} onFork={vi.fn()} />);
    expect(screen.getByText('普通正文')).toBeTruthy();
    expect(screen.queryByRole('button', { name: '分叉会话' })).toBeNull();
  });
  it('runtime FinalAnswer事件继续发布最终正文并在原turn结算后开放Fork', () => {
    useChatStore.getState().startAssistantMessage('native');
    handleChatEvent({ type: 'final_answer', data: '运行时最终回答' }, ctx);
    handleChatEvent({ type: 'run_status', status: 'completed' }, ctx);
    const message = useChatStore.getState().messages.at(-1);
    if (!message) throw new Error('missing original message');
    const fork = vi.fn();
    render(<MessageBubble message={message} onFork={fork} />);
    fireEvent.click(screen.getByRole('button', { name: '分叉会话' }));
    expect(fork).toHaveBeenCalledWith('native');
    expect(message.finalAnswerConfirmed).toBe(true);
  });
  it('退役thinkingContent不再被渲染为Reasoning或执行历史', () => {
    render(<MessageBubble message={raw({ thinkingContent: '已退役的旧思考' })} />);
    expect(screen.queryByText('已退役的旧思考')).toBeNull();
    expect(screen.queryByRole('button', { name: '展开执行过程' })).toBeNull();
  });
  it('退役rounds不能回退生成工具步骤', () => {
    const message = raw({
      executionRounds: [{ thinking: { content: '旧round' }, toolCallIds: ['old-tool'] }],
    });
    expect(flattenSteps(message).steps).toEqual([]);
  });
  it('模型thinking起止只保运行观测，不再制造空thinking步骤', () => {
    useChatStore.getState().startAssistantMessage('native');
    handleChatEvent({ type: 'thinking_start' }, ctx);
    handleChatEvent({ type: 'thinking_end', prompt_tokens: 1, completion_tokens: 1 }, ctx);
    expect(useChatStore.getState().messages.at(-1)?.executionSteps).toEqual([]);
  });
  it('当前tool batch沿现recordToolStart记录唯一顺序，不再并写rounds', () => {
    const store = useChatStore.getState();
    store.startAssistantMessage('native');
    handleChatEvent({ type: 'tool_batch_start', tool_count: 2 }, ctx);
    store.recordToolStart('native', 'tool-a');
    store.recordToolStart('native', 'tool-a');
    store.recordToolStart('native', 'tool-b');
    handleChatEvent({ type: 'tool_batch_end' }, ctx);
    const message = useChatStore.getState().messages.at(-1);
    expect(message?.executionSteps).toEqual([
      { type: 'tool', callId: 'tool-a' },
      { type: 'tool', callId: 'tool-b' },
    ]);
    expect(message).not.toHaveProperty('executionRounds');
  });

  it.each(['completed', 'failed', 'cancelled'] as const)(
    '%s后迟到batch_start不能复活stream或改变原终态',
    (terminal) => {
      useChatStore.getState().startAssistantMessage('native');
      handleChatEvent({ type: 'run_status', status: terminal }, ctx);
      expect(useChatStore.getState().isStreaming).toBe(false);
      handleChatEvent({ type: 'tool_batch_start', tool_count: 1 }, ctx);
      expect(useChatStore.getState().isStreaming).toBe(false);
      expect(useChatStore.getState().runStatus).toBe(terminal);
    }
  );
  it('typed signed Reasoning空delta仍由native块独立折叠且不公开signature', () => {
    const reasoning = {
      ...block('reason', 'reasoning', ''),
      reasoning: { type: 'signed', thinking: '原生思考', signature: 'private-signature' },
    };
    render(
      <MessageBubble
        message={{
          ...base,
          assistantBlocks: [{ block: reasoning, content: '' }],
          executionSteps: [{ type: 'assistant', index: 0 }],
        }}
      />
    );
    expect(screen.queryByText('原生思考')).toBeNull();
    fireEvent.click(screen.getByRole('button', { name: '展开思考' }));
    expect(screen.getByText('原生思考')).toBeTruthy();
    expect(screen.queryByText('private-signature')).toBeNull();
  });
  it('新消息native正文/工具/后续正文顺序及typed Reasoning DTO均保留', async () => {
    const store = useChatStore.getState();
    store.startAssistantMessage('native');
    const reasoning = {
      ...block('reason-cold', 'reasoning', ''),
      reasoning: {
        type: 'signed',
        thinking: '冷恢复原生推理',
        signature: 'cold-private-signature',
      },
    };
    store.appendAssistantBlock('native', reasoning, 'execution', 'event-reason');
    store.appendAssistantBlock(
      'native',
      block('before', 'commentary', '工具之前', 1),
      'execution',
      'event-before'
    );
    store.recordToolStart('native', 'actual-tool');
    store.appendAssistantBlock(
      'native',
      block('after', 'partial_answer', '工具之后', 2),
      'execution',
      'event-after'
    );
    store.settleAssistantMessage('native');
    const message = useChatStore.getState().messages.at(-1);
    if (!message) throw new Error('missing native');
    const saved = chatMessagesToSaved([message]);
    mocks.get.mockResolvedValue({ messages: saved });
    await useConversationStore.getState().loadConversation('native-conversation');
    const restored = useChatStore.getState().messages.at(-1);
    if (!restored) throw new Error('missing restored');
    expect(restored.executionSteps).toEqual([
      { type: 'assistant', index: 0 },
      { type: 'assistant', index: 1 },
      { type: 'tool', callId: 'actual-tool' },
      { type: 'assistant', index: 2 },
    ]);
    expect(restored.assistantBlocks).toEqual(message.assistantBlocks);
    const { container } = render(<MessageBubble message={restored} />);
    const text = container.textContent ?? '';
    expect(text.indexOf('工具之前')).toBeLessThan(text.indexOf('状态未恢复'));
    expect(text.indexOf('状态未恢复')).toBeLessThan(text.indexOf('工具之后'));
    fireEvent.click(screen.getByRole('button', { name: '展开思考' }));
    expect(screen.getByText('冷恢复原生推理')).toBeTruthy();
    expect(screen.queryByText('cold-private-signature')).toBeNull();
  });
  it('新DTO不读取旧thinking_segments/rounds来补消息身份或执行正文', async () => {
    const unsupported = JSON.parse(
      JSON.stringify({
        message_id: 'old-fields',
        role: 'assistant',
        content: '普通记录',
        thinking_segments: ['旧字段正文'],
        execution_rounds: [{ tool_call_ids: ['old-tool'] }],
      })
    ) as SavedMessage;
    mocks.get.mockResolvedValue({ messages: [unsupported] });
    await useConversationStore.getState().loadConversation('native-conversation');
    const message = useChatStore.getState().messages.at(-1);
    if (!message) throw new Error('missing ordinary');
    expect(message).not.toHaveProperty('thinkingSegments');
    expect(message).not.toHaveProperty('executionRounds');
    render(<MessageBubble message={message} />);
    expect(screen.getByText('普通记录')).toBeTruthy();
    expect(screen.queryByRole('button', { name: '展开执行过程' })).toBeNull();
  });
});
