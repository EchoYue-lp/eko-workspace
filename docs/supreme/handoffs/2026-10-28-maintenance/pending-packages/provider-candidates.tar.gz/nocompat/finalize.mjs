import { runCommand } from '/Users/ls/.codex/plugins/cache/supreme/supreme/0.4.12/skills/build/scripts/run-command.mjs';
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const artifact=dirname(fileURLToPath(import.meta.url));const root=resolve(artifact,'../../../../..');
const frontend=resolve(root,'echo-agent-cli/web-frontend');
const original=JSON.parse(readFileSync(resolve(artifact,'manifest.json'),'utf8'));
const files=Object.keys(original.files).map(path=>resolve(artifact,'candidate',path));
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
const receipts=[];
async function run(label,command,expected=0,env={}) {
 const old={};for(const [key,value]of Object.entries(env)){old[key]=process.env[key];process.env[key]=value;}
 const receipt=await runCommand({cwd:root,command,label,logPath:resolve(artifact,label+'.log'),runPath:resolve(artifact,'run.json')});
 for(const [key,value]of Object.entries(old)){if(value===undefined)delete process.env[key];else process.env[key]=value;}
 receipts.push({...receipt,sha256:hash(receipt.logPath)});
 const log=readFileSync(receipt.logPath,'utf8');
 console.log(label,receipt.exitCode,log.split('\n').filter(line=>line.includes('Test Files')||line.includes('Tests  ')).join(';'));
 if(receipt.exitCode!==expected||receipt.truncated||log.includes('Unhandled Errors'))throw new Error('unexpected final check: '+label);
}
const prettier=resolve(frontend,'node_modules/.bin/prettier');
const extras=[resolve(artifact,'native-only-projection.test.tsx'),resolve(artifact,'vitest.config.mts'),resolve(artifact,'check.mjs')];
await run('final-format-write',[prettier,'--config',resolve(frontend,'.prettierrc'),'--write',...files,...extras]);
await run('final-format-check',[prettier,'--config',resolve(frontend,'.prettierrc'),'--check',...files,...extras]);
await run('final-patch-check',['python3',resolve(artifact,'make_patches.py')]);
const vitest=[resolve(frontend,'node_modules/.bin/vitest'),'run','--config',resolve(artifact,'vitest.config.mts')];
await run('final-baseline-red',vitest,1,{NOCOMPAT_MODE:'baseline',NOCOMPAT_REGRESS:'false'});
await run('final-focused-green',vitest,0,{NOCOMPAT_MODE:'green',NOCOMPAT_REGRESS:'false'});
await run('final-regression-green',vitest,0,{NOCOMPAT_MODE:'green',NOCOMPAT_REGRESS:'true'});
await run('final-type-lint',['node',resolve(artifact,'check.mjs')]);
const manifest=JSON.parse(readFileSync(resolve(artifact,'manifest.json'),'utf8'));
const evidence={status:'ignored_candidate_ready_for_eko_single_writer',commands:receipts,
 candidate_sha256:Object.fromEntries(Object.entries(manifest.files).map(([path,facts])=>[path,facts.candidate_sha256])),
 formal_base_unchanged:Object.fromEntries(Object.entries(manifest.files).map(([path,facts])=>[path,hash(resolve(root,path))===facts.base_sha256])),
 patch_apply_checks:manifest.patches,
 actual_backend_native_api_qualification:'not_run_not_upgraded',old_fixture_29_89:'preserved_not_upgraded',
 official_source_writes:[],cargo_run:false,
 review_fix_red:{log:'late-batch-red.log',natural_exit:1,failed:3,before_source_sha256:hash(resolve(artifact,'before-late-batch-fix.chatEventHandler.ts'))},
 retired_acceptance:'old-round/old-thinking fallback and missing-final flag eligibility retired by user decision; no skip or matched/pass claim',
 history_note:'initial intermediate regression log reused once; its exit1 retained in run.json but full first output unavailable; all final qualification uses uniquely named current logs',
};
writeFileSync(resolve(artifact,'final-evidence.json'),JSON.stringify(evidence,null,2)+'\n');
console.log('saved final-evidence.json');
