"""把已退旧投影的验收迁为本版本canonical路径，不新增skip。"""
from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;root=p.parents[4];prefix='echo-agent-cli/web-frontend/src/'
m=json.loads((p/'manifest.json').read_text())

def write(rel,source,s):
 full=prefix+rel
 for directory,data in [('base',source),('candidate',s)]:
  target=p/directory/full;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(data)
 m['files'][full]={'base_sha256':hashlib.sha256(source.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest()}
def replace(s,a,b):
 if s.count(a)!=1:raise ValueError('test anchor drift '+a[:100])
 return s.replace(a,b,1)
def read(rel):return(root/prefix/rel).read_text()

rel='components/chat/MessageBubble.fork.test.tsx';source=read(rel)
s=replace(source,"  isStreaming: false,\n};","  isStreaming: false,\n  finalAnswerConfirmed: true,\n};")
write(rel,source,s)

rel='components/chat/MessageBubble.rendering.test.tsx';source=read(rel);s=source
s=replace(s,"    rerender(\n      <MessageBubble\n        message={{ ...emptyReply, content: ' \\n\\t ', thinkingSegments: [{ content: ' ' }] }}\n      />\n    );", "    rerender(<MessageBubble message={{ ...emptyReply, content: ' \\n\\t ' }} />);")
s=replace(s,"    rerender(<MessageBubble message={{ ...emptyReply, thinkingContent: ' \\n\\t ' }} />);\n    expect(container.childElementCount).toBe(0);\n",'')
s=replace(s,"{ ...emptyReply, id: 'final', content: '真实结果 中文 🧭' },","{ ...emptyReply, id: 'final', content: '真实结果 中文 🧭', finalAnswerConfirmed: true },")
start=s.index("  it('旧思考没有原生来源证明时显示历史执行说明并保留折叠详情'")
end=s.index("  it('只有关联 Subagent 时",start)
s=s[:start]+'''  it('原生Reasoning始终从typed块显示，不需要旧字符串思考投影', () => {
    render(<MessageBubble message={{...emptyReply,
      assistantBlocks: [{block: {block_id:'reasoning',request_id:'request-native',sequence:0,
        phase:'reasoning',delta:'原生推理摘要',complete:true,provider:'fixture',reasoning:null},content:'原生推理摘要'}],
      executionSteps:[{type:'assistant',index:0}],
    }} />);
    expect(screen.queryByRole('button',{name:'展开历史执行说明'})).toBeNull();
    fireEvent.click(screen.getByRole('button',{name:'展开思考'}));
    expect(screen.getByText('原生推理摘要')).toBeDefined();
  });

'''+s[end:]
write(rel,source,s)

rel='components/chat/MessageBubble.completed.test.tsx';source=read(rel);s=source
s=replace(s,"  it('shows only the collapsed process summary before the final result', () => {", "  it('keeps native Reasoning collapsed before the confirmed final result', () => {")
s=replace(s,"      thinkingSegments: [{ content: '不应默认展开的思考' }],",'''      assistantBlocks: [{block: {block_id:'reason',request_id:'native-request',sequence:0,
        phase:'reasoning',delta:'不应默认展开的思考',complete:true,provider:null,reasoning:null},content:'不应默认展开的思考'}],''')
s=replace(s,"        { type: 'thinking', index: 0 },","        { type: 'assistant', index: 0 },")
s=replace(s,"expect(markup).toContain('aria-label=\"展开执行过程\"');","expect(markup).toContain('aria-label=\"展开思考\"');")
write(rel,source,s)

rel='components/chat/MessageBubble.test.ts';source=read(rel);s=source
start=s.index("  it('uses the chronological")
end=s.index("  it('does not collapse reloaded",start)
s=s[:start]+'''  it('keeps canonical tool reference order without round history', () => {
    const message: ChatMessage = {id:'assistant-1',role:'assistant',content:'',timestamp:1,
      executionSteps:[{type:'tool',callId:'call-list'},{type:'tool',callId:'call-read'}]};
    const projection=flattenSteps(message);
    expect(projection.steps.map((step)=>step.toolId)).toEqual(['call-list','call-read']);
    expect(groupExecutionSteps(projection.steps)).toEqual([{type:'tools',toolIds:['call-list','call-read']}]);
  });

  it('does not fabricate process steps without native/tool facts', () => {
    const message: ChatMessage={id:'empty',role:'assistant',content:'ordinary',timestamp:1};
    expect(flattenSteps(message).steps).toEqual([]);
    expect(groupExecutionSteps([])).toEqual([]);
  });

'''+s[end:]
write(rel,source,s)

rel='stores/chatStore.toolExecution.test.ts';source=read(rel);s=source
s=replace(s,"    useChatStore.setState({ currentRound: null, runStatus: 'idle' });","    useChatStore.setState({ runStatus: 'idle' });")
s=s.replace('    store.startToolBatch(2);\n','').replace('    store.startToolBatch(1);\n','').replace('    store.endToolBatch();\n','')
s=s.replace("    expect(message?.executionRounds).toEqual([{ toolCallIds: ['detail-a', 'detail-b'] }]);\n",'').replace("    expect(message?.executionRounds).toEqual([{ toolCallIds: ['detail-1'] }]);\n",'')
s=replace(s,"it('stores execution order and rounds as stable execution IDs'","it('stores canonical execution order as stable execution IDs'")
write(rel,source,s)

rel='hooks/chatEventHandler.test.ts';source=read(rel);s=source
s=replace(s,"    expect(message?.thinkingSegments?.some((segment) => segment.content.trim())).toBe(false);","    expect(message?.executionSteps).toEqual([]);\n    expect(message?.assistantBlocks).toBeUndefined();")
write(rel,source,s)

rel='components/task/TaskRuntimeList.test.tsx';source=read(rel);s=source
s=replace(s,"      thinkingSegments: [{ content: '当前执行分析' }],","      finalAnswerConfirmed: true,")
write(rel,source,s)

rel='components/chat/ChatPanel.controls.test.tsx';source=read(rel);s=source
s=replace(s,'    renderRealBubble: false,','    renderRealBubble: false,\n    send: vi.fn(),')
s=replace(s,'    sendMessage: vi.fn(),','    sendMessage: mocks.send,')
start=s.index("  it('从空思考段、空白增量")
end=s.index("  it('offers one fork only",start)
s=s[:start]+'''  it('从空native Reasoning、空白delta到可见内容只保留一处等待状态', () => {
    mocks.renderRealBubble=true;
    useChatStore.setState({messages:[{id:'stream-user',role:'user',content:'用户问题',timestamp:1}]});
    const id=useChatStore.getState().startAssistantMessage('stream-thinking');
    const {container}=render(<ChatPanel/>);
    const append=(block_id:string,delta:string,sequence:number,phase:'reasoning'|'commentary'='reasoning')=>
      act(()=>useChatStore.getState().appendAssistantBlock(id,{block_id,request_id:'request',sequence,
        phase,delta,complete:false,provider:'fixture',reasoning:null}));
    expect(container.querySelectorAll('.spinner')).toHaveLength(1);
    append('reason','',0);append('reason',' \\n\\t ',1);
    expect(container.querySelectorAll('.spinner')).toHaveLength(1);
    append('reason','正在分析 中文 🧭',2);
    expect(container.querySelectorAll('.spinner')).toHaveLength(0);
    fireEvent.click(screen.getByRole('button',{name:'展开思考'}));
    expect(screen.getByText('正在分析 中文 🧭')).toBeTruthy();
    append('reason-next','',3);expect(container.querySelectorAll('.spinner')).toHaveLength(0);
    append('body','正文首段 中文',4,'commentary');
    expect(screen.getByText('正文首段 中文')).toBeTruthy();
    act(()=>useChatStore.getState().applyFinalAnswer(id,'完整回复 中文'));
    act(()=>useChatStore.getState().settleAssistantMessage(id));
    expect(screen.getByText('完整回复 中文')).toBeTruthy();
    expect(screen.getByRole('button',{name:'分叉会话'})).toBeTruthy();
    expect(container.querySelectorAll('.spinner')).toHaveLength(0);
  });

'''+s[end:]
s=replace(s,"    act(() => useChatStore.getState().startThinkingSegment(id));",'''    act(() => useChatStore.getState().appendAssistantBlock(id,{
      block_id:'empty-reason',request_id:'request',sequence:0,phase:'reasoning',delta:'',complete:false,provider:null,reasoning:null,
    }));''')
s+='''
describe('canonical branch prefix',()=>{
  it('重新生成后续回复时保留前缀native与工具顺序，不把新steps随旧round一起清空',async()=>{
    mocks.renderRealBubble=true;useTaskRuntimeStore.setState({activeRun:null});
    const original=useConversationStore.getState().branchCurrent;
    const branch=vi.fn().mockResolvedValue({id:'branch-canonical',targetContent:'第二轮问题'});
    useConversationStore.setState({branchCurrent:branch});
    useChatStore.setState({isStreaming:false,messages:[
      {id:'u1',role:'user',content:'第一轮问题',timestamp:1},
      {id:'a1',role:'assistant',content:'第一轮已确认回答',timestamp:2,finalAnswerConfirmed:true,
       assistantBlocks:[{block:{block_id:'before',request_id:'request-one',sequence:0,phase:'commentary',delta:'原生进度',complete:true,provider:null,reasoning:null},content:'原生进度'}],
       executionSteps:[{type:'assistant',index:0},{type:'tool',callId:'original-tool'}]},
      {id:'u2',role:'user',content:'第二轮问题',timestamp:3},
      {id:'a2',role:'assistant',content:'第二轮已确认回答',timestamp:4,finalAnswerConfirmed:true},
    ]});
    try{
      render(<ChatPanel/>);const buttons=screen.getAllByRole('button',{name:'重新生成'});
      const last=buttons.at(-1);if(!last)throw new Error('missing regenerate');fireEvent.click(last);
      await waitFor(()=>expect(mocks.send).toHaveBeenCalled());
      const prefix=useChatStore.getState().messages.find((message)=>message.role==='assistant');
      expect(prefix?.assistantBlocks?.at(0)?.block.block_id).toBe('before');
      expect(prefix?.executionSteps).toEqual([{type:'assistant',index:0},{type:'tool',callId:'original-tool'}]);
    }finally{useConversationStore.setState({branchCurrent:original});}
  });
});
'''
write(rel,source,s)

rel='stores/conversationStore.test.ts';source=read(rel);s=source
s=replace(s,"        { message_id: 'assistant-after', role: 'assistant', content: '后一条真实回复' },", "        { message_id: 'assistant-after', role: 'assistant', content: '后一条真实回复', final_answer_confirmed: true },")
write(rel,source,s)
(p/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print('prepared canonical tests without legacy compatibility skips',len(m['files']))
