# 前端 NoCompat 当前生产消费收敛

按用户亲自更新的完整 Goal（SHA `cd30e66fd0135d754a42c07169a5d49692c2e779f8975b6934c1ab3da498a5bb`）与 Root 后续精确分权实施。仅在 ignored 目录准备 TS/TSX 函数级候选，正式源由 EKO 唯一 writer 与 Gov 合流。Rust `AttachmentsPayload`、旧数组 parser 和 Rust DTO/测试属于 Workspace；`legacy_eko_history` 属于 EKO，本件均未改。

## 分层与当前路径

运行时最终回答事件/回调属于保留能力；这里不改 `FinalAnswer` 协议、完成判定或 Framework。此改动只收敛 EKO 前端投影。

当前代码已经具备唯一主路径：

- `assistant_message → appendAssistantBlock → assistantBlocks/executionSteps → NativeMessageTimeline` 保留原身份、phase、顺序、Reasoning payload；`ThinkingSegment` 共享组件保留。
- 真实工具 summary 的 `started → useTauriChat.recordToolStart → executionSteps` 已覆盖工具顺序与重复 start 去重。原 `tool_batch_start/end → currentRound/executionRounds` 是同时存在的副投影；此件同步退掉该生产写入后才删其消费。
- `thinkingContent` 没有当前生产写入，`appendThinking` 仅测试调用；模型起止只会制造空段。此件取消空段副写，保留运行观测，不把文本或起止事件转换成 Reasoning。
- 真正 transcript writer 仍在后端。`chatMessagesToSaved` 的现调用只有测试，真实 `saveCurrent` 只创建会话身份/改标题；本件不新增前端 transcript writer。

## 退役与保留

| 原表面 | 本件处理 | 新版本保留路径 |
|---|---|---|
| 缺少 final 确认仍开放 Fork 的 Bubble 分支 | 删除 `finalAnswerConfirmed == null && !hasNativeTimeline` 旧放行 | 只接受 runtime `FinalAnswer` 写入的确认标记，并继续使用原执行/流式门槛 |
| thinkingContent、字符串 thinkingSegments、无顺序思考 fallback | 删除字段/空段 producer/旧消费 | 原 typed signed/redacted/opaque Reasoning 块与公开摘要 |
| OlderRounds fallback | 同步删除 currentRound/rounds 副写及前端 DTO 读写 | 原工具 summary/assistant 的 canonical executionSteps |
| executionSteps 的 backward/deprecated 旧注释 | 更新说明 | 原 assistant/tool 顺序，不再添加 thinking 索引 |
| ChatPanel 分支同时清 steps/rounds | 删除清空 canonical steps 的代码 | 重新生成后续轮时保留前缀原 native/工具顺序，实时工具与 TaskRun store 仍按原流程清理 |
| spinner 读取旧 thinkingSegments | 使用现 `nativeAssistantBlockText` | 空 delta 的原签名/opaque 公开 Reasoning 文本也能正确承接等待状态 |

不变的权威边界：b529 的 execution/request/model-sequence/publication identity、actual terminal/source、运行时最终正文发布、工具 owner gate、HITL、Subagent、附件、复制、取消和原序均保留。批次观测不更新全局 stream；真实工具 summary 负责工具状态和步骤，避免迟到 batch 复活已结算运行。

## 小 hunk 交付

- `01-bubble-functions.patch`：类型/flatten/group、旧思考 JSX、Fork gate；与 Gov 的角色/样式 hunk 分函数合流。
- `02-canonical-store-handler.patch`：退空思考/round 副写；保 native 和 runtime FinalAnswer 的原方法。
- `03-conversation-dto.patch`：只移除 thinking/round DTO 与回退，保 canonical blocks/steps/tool calls/source。
- `04-chatpanel-functions.patch`：仅分支前缀和 spinner。
- `05-current-native-tests.patch`：迁移相关当前行为测试，无 skip/todo。

纯旧版本验收（round-only 历史回退、旧字符串思考解释、缺确认标记的旧 Fork 放行）标为 `retired_by_user_decision`，不标 matched/pass。对应原测试源码仍在 `base/`，当前工具顺序/Reasoning/Fork/等待功能迁到 native 新测试，不把原兼容要求改名伪称通过。

当前 Rust DTO 接缝已通知 Workspace/EKO：前端不再声明/消费 `thinking_segments/execution_rounds`，后端需按其 W-C1 同步；本件不重复 Rust hunk或增加兼容回退。未修改 Workspace location 具体字段，与 W-C4 分工独立。

## 直接验证与范围

`vitest.config.mts` 只在内存加载 `base/` 或 `candidate/`，全部缓存/日志在本目录；不会把临时测试写入正式 frontend。

- `baseline-red.log`：新退役验收 9 项中 6 项失败，自然退出 1；原 runtime FinalAnswer/native Reasoning/原序正控通过。
- `late-batch-red.log`：独审发现的迟到 batch 三态复活问题，3 项真实 handler 负控失败；修前源码单独保留。
- `focused-after-review.log`：修后新契约与负控共 12 项通过。
- 最终回归、类型、格式及源哈希以 `final-evidence.json`、`manifest.json`、`run.json` 和最终独立日志为准。初期一轮中间回归日志被同名重跑覆盖，退出码仍在 `run.json`；不将该中间步骤作为可独立重放原件，后续每轮使用独立路径。原 29/89 和 actual-backend bridge 原件未动。

测试证明前端生产消费行为与类型闭合，不等同于 Rust backend、真实 API、native UI、完整矩阵或整个 Goal 已通过。实际 backend capture 仍使用独立原件桥及其明确资格，不因本件 JS 通过升级。

本件是内部 EKO 呈现/投影退役，不新增 Framework/SDK API 或用户操作；examples、官网无需新增示例或营销能力。正式 EKO writer 合流时需同步其消息架构说明，并将取消的兼容义务标退役；用户数据、旧原件、受保护 tag 与恢复包均不迁移、不删除。
