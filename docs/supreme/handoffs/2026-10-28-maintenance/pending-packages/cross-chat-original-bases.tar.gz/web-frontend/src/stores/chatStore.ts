import { create } from 'zustand';
import { isHitlRequestIdentity, sameHitlIdentity } from '../types/api';
import type { HitlRequestIdentity } from '../types/api';
import type {
  AssistantMessageBlock,
  ChatMessage,
  ApprovalRequest,
  ExecutionRound,
  ChatRunStatus,
} from '../types/api';
import { useConversationStore } from './conversationStore';

/** In-progress round being built during streaming */
interface CurrentRound {
  thinking?: { content: string };
  toolCallIds: string[];
}

export interface ChatActivity {
  key: string;
  label: string;
  startedAt: number;
  lastEventAt: number;
  scope?: string;
}

/** 当前上下文窗口占用快照（对齐 Claude Code statusline 语义）。 */
export interface ContextWindowUsage {
  /** 本次请求的实际输入 token（= 当前上下文主体），已含 cache 部分。 */
  inputTokens: number;
  /** 其中命中缓存的部分。 */
  cachedTokens: number;
  /** 写入缓存的部分。 */
  cacheCreationTokens: number;
  /** 本次生成 token（不计入占用，仅参考）。 */
  outputTokens: number;
  /** provider 是否上报了 usage；false 时不应写入 store。 */
  usageReported: boolean;
}

/** 会话级 LLM 用量累计（缓存命中率）；压缩不清，会话重置时清零。 */
export interface ContextUsageAccumulator {
  totalInput: number;
  totalCached: number;
}

export type PendingHitlRequest = { identity: HitlRequestIdentity } & (
  | ({ kind: 'approval' } & ApprovalRequest)
  | { kind: 'input'; requestId: string; prompt?: string }
  | {
      kind: 'selection';
      requestId: string;
      prompt: string;
      options: string[];
      taskId?: string;
      context?: unknown;
      phase?: string;
    }
);

function waitingStatus(request: PendingHitlRequest): ChatRunStatus {
  return request.kind === 'approval' ? 'waiting_approval' : 'waiting_input';
}

export function cacheHitRate(acc: ContextUsageAccumulator): number | null {
  if (acc.totalInput <= 0) return null;
  return acc.totalCached / acc.totalInput;
}

interface ChatState {
  messages: ChatMessage[];
  isStreaming: boolean;
  isCancelled: boolean;
  isThinking: boolean;
  runStatus: ChatRunStatus;
  /** 仅来自实际运行事件；计时刷新不产生新事件或发现。 */
  activity: ChatActivity | null;
  observeActivity: (key: string, label: string, at?: number, scope?: string) => void;
  noteActivityEvent: (at?: number) => void;
  pendingHitlRequests: PendingHitlRequest[];
  /** True when viewing a loaded historical conversation (agent has no context) */
  isHistoryView: boolean;
  /** Current round being built during streaming */
  currentRound: CurrentRound | null;
  /** 当前上下文窗口占用（来自最近一次 llm_usage 事件的真实 prompt_tokens）。null = 首次响应前 / 刚压缩后。 */
  contextWindow: ContextWindowUsage | null;
  /** 会话级缓存命中率累加器（压缩保留，clear/replace 清零）。 */
  usageAccumulator: ContextUsageAccumulator;

  addUserMessage: (content: string, attachments?: ChatMessage['attachments']) => string;
  removeMessages: (ids: string[]) => void;
  startAssistantMessage: (idOverride?: string) => string;
  continueAfterSteer: (
    assistantId: string | null,
    content: string,
    attachments?: ChatMessage['attachments']
  ) => string;
  appendToken: (id: string, token: string) => void;
  appendAssistantBlock: (id: string, block: AssistantMessageBlock) => void;
  appendThinking: (id: string, token: string) => void;
  startThinkingSegment: (id: string) => void;
  recordToolStart: (messageId: string, toolExecutionId: string) => void;
  startToolBatch: (toolCount: number) => void;
  endToolBatch: () => void;
  applyFinalAnswer: (id: string, content: string) => void;
  settleAssistantMessage: (id: string) => void;
  projectAssistantError: (id: string, error: string) => void;
  handoffToTaskRuntime: (id: string, content: string, isRunning: boolean) => void;
  /** Insert a non-streaming assistant note (e.g. background subagent finished). */
  appendLocalAssistantNote: (content: string) => void;
  setStreaming: (v: boolean) => void;
  setThinking: (v: boolean) => void;
  setRunStatus: (status: ChatRunStatus) => void;
  clearInactiveTurnProjection: () => void;
  enqueueHitlRequest: (request: PendingHitlRequest) => void;
  removeHitlRequest: (identity: HitlRequestIdentity) => void;
  clearHitlRequests: () => void;
  addChartMessage: (spec: unknown) => void;
  clearMessages: () => void;
  replaceMessages: (messages: ChatMessage[]) => void;
  setHistoryView: (v: boolean) => void;
  /** 更新上下文窗口占用快照（由 llm_usage 事件驱动，仅 usageReported=true）。 */
  setContextWindow: (usage: ContextWindowUsage) => void;
  /** 压缩边界：只清 Snapshot，保留 Accumulator。 */
  clearContextWindow: () => void;
  /** 累加一次 usage（仅 usageReported=true 时由 handler 调用）。 */
  recordUsage: (input: number, cached: number) => void;
}

/// Maximum number of messages retained in-memory. Beyond this, oldest messages
/// are evicted to prevent OOM on very long conversations (P0-4).
const MAX_MESSAGES = 500;

/// Trim oldest messages when an array exceeds MAX_MESSAGES. Applied to every
/// path that grows or replaces the message list (addUserMessage,
/// startAssistantMessage, replaceMessages) so the cap cannot be bypassed via
/// the streaming path or a loaded historical conversation (P0-4).
function trimToMax(msgs: ChatMessage[]): ChatMessage[] {
  return msgs.length > MAX_MESSAGES ? msgs.slice(-MAX_MESSAGES) : msgs;
}

let msgCounter = 0;
const nextId = () => `msg-${++msgCounter}-${Date.now()}`;

/** Auto-save to conversationStore after state changes that add messages. */
function autoSave() {
  const state = useChatStore.getState();
  if (state.isStreaming) return;
  const msgs = state.messages;
  if (msgs.length > 0) {
    void useConversationStore.getState().saveCurrent(msgs);
  }
}

/// Debounced wrapper that replaces synchronous `autoSave()` calls inside
/// set() closures. Prevents N writes per streaming token and decouples the
/// chatStore→conversationStore dependency from the hot path.
let autoSaveTimer: ReturnType<typeof setTimeout> | undefined;
function scheduleAutoSave() {
  clearTimeout(autoSaveTimer);
  autoSaveTimer = setTimeout(autoSave, 300);
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  isStreaming: false,
  isCancelled: false,
  isThinking: false,
  runStatus: 'idle',
  activity: null,
  pendingHitlRequests: [],
  isHistoryView: false,
  currentRound: null,
  contextWindow: null,
  usageAccumulator: { totalInput: 0, totalCached: 0 },

  observeActivity: (key, label, at = Date.now(), scope) =>
    set((state) => {
      if (!state.isStreaming || !Number.isFinite(at)) return state;
      const previous = state.activity;
      if (previous && at < previous.lastEventAt) return state;
      return {
        activity: {
          key,
          label,
          startedAt: previous?.key === key ? previous.startedAt : at,
          lastEventAt: Math.max(previous?.lastEventAt ?? at, at),
          scope,
        },
      };
    }),
  noteActivityEvent: (at = Date.now()) =>
    set((state) => ({
      activity:
        state.isStreaming && state.activity && Number.isFinite(at)
          ? { ...state.activity, lastEventAt: Math.max(state.activity.lastEventAt, at) }
          : state.activity,
    })),

  addUserMessage: (content, attachments) => {
    const id = nextId();
    set((s) => {
      const newMsg: ChatMessage = {
        id,
        role: 'user',
        content,
        attachments,
        timestamp: Date.now(),
      };
      const msgs = trimToMax([...s.messages, newMsg]);
      return { isCancelled: false, runStatus: 'running', messages: msgs };
    });
    scheduleAutoSave();
    return id;
  },

  removeMessages: (ids) => {
    const removed = new Set(ids);
    set((state) => ({
      messages: state.messages.filter((message) => !removed.has(message.id)),
      isStreaming: false,
      isThinking: false,
      activity: null,
    }));
    scheduleAutoSave();
  },

  startAssistantMessage: (idOverride) => {
    const id = idOverride || nextId();
    set((s) => ({
      messages: trimToMax([
        ...s.messages,
        {
          id,
          role: 'assistant',
          content: '',
          finalAnswerConfirmed: false,
          thinkingSegments: [],
          executionSteps: [],
          executionRounds: [],
          isStreaming: true,
          timestamp: Date.now(),
        },
      ]),
      isStreaming: true,
      isCancelled: false,
      runStatus: 'running',
      activity: null,
    }));
    return id;
  },

  continueAfterSteer: (assistantId, content, attachments) => {
    const nextAssistantId = nextId();
    set((s) => {
      const finalized = s.messages
        .map((message) =>
          message.id === assistantId ? { ...message, isStreaming: false } : message
        )
        .filter((message) => {
          if (message.id !== assistantId || message.role !== 'assistant') return true;
          return Boolean(
            message.content || message.thinkingSegments?.length || message.executionSteps?.length
          );
        });
      return {
        messages: trimToMax([
          ...finalized,
          {
            id: nextId(),
            role: 'user' as const,
            content,
            attachments,
            timestamp: Date.now(),
          },
          {
            id: nextAssistantId,
            role: 'assistant' as const,
            content: '',
            finalAnswerConfirmed: false,
            thinkingSegments: [],
            executionSteps: [],
            executionRounds: [],
            isStreaming: true,
            timestamp: Date.now(),
          },
        ]),
        isStreaming: true,
        isCancelled: false,
        runStatus: 'running' as const,
        activity: null,
      };
    });
    scheduleAutoSave();
    return nextAssistantId;
  },

  appendToken: (id, token) => {
    set((s) => {
      const idx = s.messages.findIndex((m) => m.id === id);
      if (idx === -1) return { messages: s.messages };
      const updated = [...s.messages];
      updated[idx] = { ...updated[idx], content: updated[idx].content + token };
      return { messages: updated };
    });
  },

  appendAssistantBlock: (id, block) => {
    set((state) => ({
      messages: state.messages.map((message) => {
        if (message.id !== id || !message.isStreaming) return message;
        const blocks = [...(message.assistantBlocks ?? [])];
        const index = blocks.findIndex(
          (entry) =>
            entry.block.request_id === block.request_id && entry.block.block_id === block.block_id
        );
        if (index >= 0) {
          const previous = blocks[index];
          if (!previous || previous.block.complete || block.sequence < previous.block.sequence)
            return message;
          if (previous.block.phase !== 'unknown' && previous.block.phase !== block.phase)
            return message;
          blocks[index] = { block, content: previous.content + block.delta };
          return { ...message, assistantBlocks: blocks };
        }
        blocks.push({ block, content: block.delta });
        return {
          ...message,
          assistantBlocks: blocks,
          executionSteps: [
            ...(message.executionSteps ?? []),
            { type: 'assistant' as const, index: blocks.length - 1 },
          ],
        };
      }),
    }));
  },

  appendThinking: (id, token) => {
    set((s) => {
      const idx = s.messages.findIndex((m) => m.id === id);
      if (idx === -1) return { messages: s.messages };
      const m = s.messages[idx];
      const segments = [...(m.thinkingSegments || [])];
      if (segments.length === 0) {
        segments.push({ content: token });
      } else {
        const last = { ...segments[segments.length - 1] };
        segments[segments.length - 1] = { ...last, content: last.content + token };
      }
      const updated = [...s.messages];
      updated[idx] = { ...m, thinkingSegments: segments };
      return { messages: updated };
    });
  },

  startThinkingSegment: (id) => {
    set((s) => {
      const messages = s.messages.map((m) => {
        if (m.id !== id) return m;
        const thinkingSegments = [...(m.thinkingSegments || []), { content: '' }];
        const executionSteps = [
          ...(m.executionSteps || []),
          { type: 'thinking' as const, index: thinkingSegments.length - 1 },
        ];
        return { ...m, thinkingSegments, executionSteps };
      });
      // If there's an in-progress round, it's now complete (thinking→tools→done),
      // so start a fresh round for this new thinking phase.
      return { messages };
    });
  },

  setThinking: (v) => set({ isThinking: v, runStatus: v ? 'thinking' : get().runStatus }),

  recordToolStart: (messageId, toolExecutionId) => {
    set((s) => {
      const messages = s.messages.map((m) => {
        if (m.id !== messageId) return m;
        if (
          m.executionSteps?.some((step) => step.type === 'tool' && step.callId === toolExecutionId)
        ) {
          return m;
        }
        const executionSteps = [
          ...(m.executionSteps || []),
          { type: 'tool' as const, callId: toolExecutionId },
        ];
        return { ...m, executionSteps };
      });
      const currentRound = s.currentRound
        ? {
            ...s.currentRound,
            toolCallIds: s.currentRound.toolCallIds.includes(toolExecutionId)
              ? s.currentRound.toolCallIds
              : [...s.currentRound.toolCallIds, toolExecutionId],
          }
        : { toolCallIds: [toolExecutionId] };
      return { messages, currentRound, runStatus: 'using_tool' };
    });
    scheduleAutoSave();
  },

  /** Start a new tool batch (received tool_batch_start event from backend) */
  startToolBatch: () => {
    const state = get();
    // Capture the last thinking segment from the streaming message.
    // During streaming, thinking content is accumulated on message.thinkingSegments,
    // not on currentRound. When a tool batch starts, we must explicitly associate
    // the preceding thinking with the upcoming tools to form a complete ExecutionRound.
    const streamingMsg = state.messages.find((m) => m.isStreaming);
    const segments = streamingMsg?.thinkingSegments;
    const lastSegment = segments && segments.length > 0 ? segments[segments.length - 1] : null;
    set({
      currentRound: {
        thinking: lastSegment?.content ? { content: lastSegment.content } : undefined,
        toolCallIds: [],
      },
    });
  },

  /** End current tool batch (received tool_batch_end event from backend).
   *  Push the current round into the streaming message's executionRounds. */
  endToolBatch: () => {
    const { currentRound } = get();
    if (!currentRound) return;
    const round: ExecutionRound = {
      thinking: currentRound.thinking,
      toolCallIds: [...currentRound.toolCallIds],
    };
    set((s) => ({
      currentRound: null,
      messages: s.messages.map((m) => {
        if (!m.isStreaming) return m;
        const executionRounds = [...(m.executionRounds || []), round];
        return { ...m, executionRounds };
      }),
    }));
    scheduleAutoSave();
  },

  applyFinalAnswer: (id, content) => {
    if (!content.trim()) return;
    set((state) => ({
      messages: state.messages.map((message) =>
        message.id === id && !message.finalAnswerConfirmed
          ? { ...message, content, finalAnswerConfirmed: true }
          : message
      ),
    }));
    scheduleAutoSave();
  },

  settleAssistantMessage: (id) => {
    set((state) => ({
      isStreaming: false,
      isThinking: false,
      pendingHitlRequests: [],
      activity: null,
      messages: state.messages.map((message) =>
        message.id === id ? { ...message, isStreaming: false } : message
      ),
    }));
    scheduleAutoSave();
  },

  projectAssistantError: (id, error) => {
    set((s) => ({
      messages: s.messages.map((message) => {
        if (message.id !== id) return message;
        const errorNote = `[Error] ${error}`;
        return {
          ...message,
          content: message.content ? `${message.content}\n\n${errorNote}` : errorNote,
        };
      }),
    }));
    scheduleAutoSave();
  },

  handoffToTaskRuntime: (id, content, isRunning) => {
    set((s) => ({
      isStreaming: false,
      isThinking: false,
      runStatus: isRunning ? 'running' : 'waiting_approval',
      activity: null,
      messages: s.messages.map((m) => (m.id === id ? { ...m, content, isStreaming: false } : m)),
    }));
    scheduleAutoSave();
  },

  appendLocalAssistantNote: (content) => {
    set((s) => ({
      messages: trimToMax([
        ...s.messages,
        {
          id: nextId(),
          role: 'assistant',
          content,
          finalAnswerConfirmed: false,
          isStreaming: false,
          timestamp: Date.now(),
        },
      ]),
    }));
    scheduleAutoSave();
  },

  setStreaming: (v) => set((state) => ({ isStreaming: v, activity: v ? state.activity : null })),
  setRunStatus: (status) =>
    set((state) => ({
      runStatus: status,
      activity: ['idle', 'completed', 'failed', 'cancelled'].includes(status)
        ? null
        : state.activity,
      isStreaming: !['idle', 'completed', 'failed', 'cancelled'].includes(status),
      isCancelled: status === 'cancelled',
      isThinking: status === 'thinking',
      pendingHitlRequests: ['completed', 'failed', 'cancelled'].includes(status)
        ? []
        : state.pendingHitlRequests,
    })),

  clearInactiveTurnProjection: () => {
    set((state) => ({
      isStreaming: false,
      isThinking: false,
      isCancelled: false,
      runStatus: 'idle',
      activity: null,
      pendingHitlRequests: [],
      messages: state.messages.map((message) =>
        message.isStreaming ? { ...message, isStreaming: false } : message
      ),
    }));
    scheduleAutoSave();
  },

  enqueueHitlRequest: (request) =>
    set((state) => {
      if (
        !isHitlRequestIdentity(request.identity) ||
        request.identity.request_id !== request.requestId ||
        request.identity.kind !== request.kind
      )
        return state;
      if (
        state.pendingHitlRequests.some((pending) =>
          sameHitlIdentity(pending.identity, request.identity)
        )
      ) {
        return state;
      }
      const pendingHitlRequests = [...state.pendingHitlRequests, request];
      const front = pendingHitlRequests.at(0);
      return {
        pendingHitlRequests,
        runStatus: front ? waitingStatus(front) : state.runStatus,
      };
    }),
  removeHitlRequest: (identity) =>
    set((state) => {
      if (!isHitlRequestIdentity(identity)) return state;
      const pendingHitlRequests = state.pendingHitlRequests.filter(
        (request) => !sameHitlIdentity(request.identity, identity)
      );
      if (pendingHitlRequests.length === state.pendingHitlRequests.length) {
        return state;
      }
      const front = pendingHitlRequests.at(0);
      return {
        pendingHitlRequests,
        runStatus: front ? waitingStatus(front) : 'running',
      };
    }),
  clearHitlRequests: () => set({ pendingHitlRequests: [] }),

  addChartMessage: (spec) => {
    set((s) => ({
      messages: s.messages.map((m) =>
        m.isStreaming ? { ...m, chartSpecs: [...(m.chartSpecs || []), spec] } : m
      ),
    }));
  },

  clearMessages: () =>
    set({
      messages: [],
      isStreaming: false,
      isCancelled: false,
      isThinking: false,
      isHistoryView: false,
      pendingHitlRequests: [],
      currentRound: null,
      contextWindow: null,
      usageAccumulator: { totalInput: 0, totalCached: 0 },
      runStatus: 'idle',
      activity: null,
    }),

  replaceMessages: (messages) =>
    set({
      messages: trimToMax(messages),
      isStreaming: false,
      isCancelled: false,
      isHistoryView: true,
      pendingHitlRequests: [],
      // 加载历史会话时清空实时上下文占用（历史视图无 live llm_usage，显示旧值会误导）。
      contextWindow: null,
      usageAccumulator: { totalInput: 0, totalCached: 0 },
      runStatus: 'idle',
      activity: null,
    }),

  setHistoryView: (v) => set({ isHistoryView: v }),

  setContextWindow: (usage) => set({ contextWindow: usage }),

  clearContextWindow: () => set({ contextWindow: null }),

  recordUsage: (input, cached) =>
    set((s) => ({
      usageAccumulator: {
        totalInput: s.usageAccumulator.totalInput + input,
        totalCached: s.usageAccumulator.totalCached + cached,
      },
    })),
}));
