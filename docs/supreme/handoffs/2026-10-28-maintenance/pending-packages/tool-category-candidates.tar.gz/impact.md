# 合流与影响

修改EKO产品DTO/原单项工具开关/设置页，不改Framework；source与policy_enabled/required_reason/category一次闭合，生成TS候选已手工精确对齐Rust derive形状，尚未运行ts-rs导出或Cargo。正式writer按patches中的逐文件精确hunk采用，不整文件覆盖公共endpoints/AppState/response。

唯一设计 spec/design.md；普通中文轻Plan spec/plans/plan_01_六类工具控制.md。原Supreme路径校验失败保留，用户ignored范围优先，不为满足路径把正式docs变成第二writer。

ADR候选 docs/zh/adr/0061-tool-categories-and-required-tools.md。其它文档/示例/官网已检查本次工具设置接口表面；不存在ToolInfo构造或分类名单使用示例，故不新增虚假例子、不扩SDK或网站发布。独立GUI完整门禁与Rust/原生由owner完成。

工具选择原来就是进程内存，不新增落盘语义；MCP/Plugin来源来自真实server identity，非MCP未提供来源保持Unknown，不把canonical名当来源证明。类别映射只用于产品展示，未分类动态工具照常显示可切换。
