# 六类工具候选冻结保全（维护切点）

状态：仅静态保全，未正式合流、未新增 Review、未启动测试或构建。人类当前优先级是先保存代码和中间产物，再提交/清理；原 Goal 仍暂停且未完成。

- 正式 EKO 基线：`080e0b698c664105f789f522779a985f93b4f71b`，当前 WIP 由 Root 维护提交 `c128fa1a` 另行保存。
- 完整候选补丁：`tool-categories.patch`，15 个文件，SHA `a148057536f48fb37d27909c82a5b9346a52939f57e0a2f8903931adac7d1d22`。
- HEAD→当前 WIP base 恢复补丁：`recovery/head-080e0b6-to-current-wip-base.patch`；逐文件 base/after 身份见 `recovery/base-after-sha.json`。
- 现有 Review 仍为 pass/0 未解决；已有 JS、全 src TypeScript、ESLint、rustfmt、apply-check/scratch apply 回执原样保存。Rust 编译、原生 UI 和正式 EKO 合流仍未完成。

恢复顺序：先恢复 `080e0b6`，按 `base-after-sha.json` 应用 HEAD→WIP base 补丁并逐项核对，再由 EKO owner 完成 preflight 后决定是否应用完整候选补丁。不要直接把候选强行并入当前正式 source freeze。

本目录没有复制 node_modules、Vite 缓存、二进制、Cargo target、用户数据或 live fixture；完整 15 文件以补丁恢复。Root 统一决定是否把该 staging 迁入受跟踪工程交接并提交，本线不 stage/commit/push/merge。
