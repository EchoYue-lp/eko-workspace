# 首次验证原件与处理

focused-first：自然1，6 passed / 2 failed。两处 openCommands 测试定位器要求可访问名中一定有空格，而嵌套span文本连接没有该空格；改为唯一类别按钮文本定位，不改产品断言/实现。原完整DOM和失败输出保留。

types-first：自然2，缺 ../components/compress/subagentUsage。候选只挂了工具组件目录，原store依赖的其它组件尚未在只读overlay解析；补完整缺项只读symlink，不改原source、不缩小类型范围。原失败输出保留。
