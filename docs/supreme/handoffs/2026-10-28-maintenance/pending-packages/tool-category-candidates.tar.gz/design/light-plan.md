# 六类工具控制轻量计划

执行来源：人类 call_10819250b7b04a8094e546317f60ff36 已批准六组，Root明确授权候选实现。唯一设计：`../design.md`。这是普通Markdown轻量计划，不是Supreme机读Plan；当前所有产物限定ignored，正式写入仍由EKO owner负责。

交付结果：形成六组折叠和快捷开关、后端系统必需拒绝、真实来源及scope保护的可审候选；附JS真实验证、Rust待运行反控和精确hunks。

- [x] EKO目录投影category/policy_enabled/required_reason/source，保留原ToolManager及ToolControlService；后端拒绝关闭真实产品依赖，捕获并校验scope。
- [x] GUI按六组/未分类折叠、搜索筛选和可选项mixed操作，沿原逐项回执保错误与动态注销，scope改变阻止迟到继续。
- [x] 定向JS/类型/格式检查，Rust反控候选；独审后完整hunks读回及base/afterSHA；附ADR与examples/官网影响。

范围外：Framework代码、原生页面/用户数据、额外持久化、新store、Gov/Provider其它业务、Cargo与Git提交/推送/合并。

验收：系统必需不可点且直调后端不可关；optional shell仍可关；批量只影响可选且部分失败可见；A→B→A与卸载不继续旧批次；当前run snapshot及readonly/正上界原语义保留；候选与正式字节分离，不将静态检查当Rust/native通过。

工具记录：Supreme create原始退出1：`design_ref must identify docs/supreme/specs/<topic>/design.md`。未生成虚假通过；用户明确ignored路径优先，故使用本普通Markdown执行来源，不修改正式docs或技能来绕路径。原失败保存于同目录工具回执。

本轻Plan候选交付已完成：独审pass/0遗留、JS17、全src类型和focused格式/ESLint0、patch实际应用15文件读回一致。Rust/ts-rs/native/全量门禁仍由EKO正式合流后验收，整体Goal不标完成。
