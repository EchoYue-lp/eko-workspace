---
title: 六类工具展示与系统必需工具保护
artifact: design
carrier: markdown
---

## 目标与确认来源

人类已在 Root 明确采用六组：任务与协作、文件与代码、命令与运行、搜索与浏览、数据与文档、记忆与技能（call_10819250b7b04a8094e546317f60ff36）。实现折叠、搜索、筛选、分类快捷开关；系统必需工具按钮不可点，后端同样拒绝关闭。未分类动态工具不丢失。本设计由既有 brainstorm 方案评估与当前8文件固定base派生，不需要再问分类。

## 权威与数据流

注册仍是 ToolManager，用户选择仍是 ToolControlService(revision,disabled_names)，发布仍是既有 pool generation。EKO 当前 ToolInfo 一次补齐 category、policy_enabled、required_reason；source 使用 owner-qualified MCP 的实际客户端目录，未知实现明确 Unknown，不用工具名称推断来源。分类是产品展示，可用当前已登记canonical工具名作明确显示归类，不能由分类决定权限或来源。无通用Framework产品枚举、第二store/validator/executor。

必需策略唯一位于 EKO tool_control：tool_search 为延迟能力发现入口；task_create/update/list/execute 为唯一revisioned TaskRun graph API；read_artifact 是长Goal/原文恢复的已实现读取合同。每项注释绑定真实源，不将全部Builtin、首轮22个候选或所有只读工具锁定。profile正上界与必要依赖继续原 capability admission 检查，不能为系统必需跨越只读/allowed_tools授予工具。

GUI列表与变更请求带原工作空间id＋product_data_generation；AppState 在原transition读锁下校验当前focus与generation，捕获原runtime并完成操作；陈旧页面不能改新workspace目录中的同名工具。原单项内部AppState API继续供IM/原消费者使用同一required拒绝策略。

## 交互与异常

六个主类只在有工具时显示，动态没有分类元数据进未分类；来源badge与主类正交。类别折叠，搜索命中自动展开但不丢原折叠选择；全部/已关闭/系统必需筛选只改显示。

组头统计可选已启用x/y、必需z，复选框mixed/on/off只由可选项决定；全必需组disabled。单工具显示policy选择，实际enabled不同另说明。锁定理由可读、可聚焦；原详情继续按需展开。

批量先重新取目录，仅处理点击时该类别的可选身份，随后逐项调用原enable/disable回执；动作期间防重复提交。注销/策略变化/拒绝/部分失败逐项显示，不伪造全有全无。scope变化或组件卸载后停止排新操作且拒绝迟到UI回写；后端再次验证scope。已开始原run持有snapshot不热改，用户GUI终端/MCP连接不受Agent工具开关误卡。

## 边界与复用

当前内存选择语义不增加跨重启保存，不复用mcp.json冒充工具开关配置；不加SQLite、新store、新permission gate，不修改Framework、不改Gov/Provider其它业务。未知来源不冒Builtin；MCP名只用原McpServerId.parse_selector解码正式selector，不拆工具前缀猜owner。生成TS同步当前合同，不保旧DTO兼容分支。

## 验收

必需项单点/批量/直接后端均不可关闭；内置可选shell仍可关闭。混合计数与锁定、键盘原生控件、搜索、部分失败、动态注销和A→B→A迟到回执均有定向反控。Rust新增拒绝/投影/作用域候选测试，低盘不Cargo，不冒运行GREEN。JS在ignored隔离候选下真实focused测试、tsc和格式检查。补丁提供逐文件base/afterSHA及小hunk；正式应用和Rust运行由EKO owner窗口执行。ADR记录决策与现有官方参考；examples/官网无新增公共模型使用方式，交接明确不适用理由。
