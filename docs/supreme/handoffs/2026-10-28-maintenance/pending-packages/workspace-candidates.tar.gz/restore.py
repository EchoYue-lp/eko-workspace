"""只在新建 scratch 中恢复工程候选；不写源 checkout、index 或 HEAD。"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import subprocess


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, help='含固定 Git 基底对象的 echo-agent-cli checkout')
    parser.add_argument('--scratch', required=True, help='主根内尚不存在的隔离目录')
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    repo = Path(args.repo).resolve(strict=True)
    requested = Path(args.scratch).absolute()
    scratch = requested.resolve()
    if requested.exists() or requested.is_symlink() or scratch.exists():
        raise RuntimeError('拒绝覆盖已有 scratch')
    if not scratch.is_relative_to(repo.parent) or scratch.is_relative_to(repo):
        raise RuntimeError('scratch 必须位于主根内且在源 checkout 外')
    if scratch.is_relative_to(package) or package.is_relative_to(scratch):
        raise RuntimeError('scratch 与保全包不能互相包含')
    manifest = json.loads((package / 'restoration-manifest.json').read_text())
    original_raw = (package / 'original/manifest.json').read_bytes()
    if digest(original_raw) != manifest['source_candidate_manifest_sha256']:
        raise RuntimeError('原候选 manifest 指纹不符')
    source_head = manifest['source_head']
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')

    def source_git(*argv):
        return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *argv],
                              capture_output=True, check=True, env=env).stdout

    if source_git('cat-file', '-t', source_head).strip() != b'commit':
        raise RuntimeError('固定 sourceHEAD 不是 commit 对象')
    git_dir = Path(source_git('rev-parse', '--absolute-git-dir').decode().strip())
    index_path = Path(source_git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    index_before = digest(index_path.read_bytes()) if index_path.is_file() else None
    head_before = source_git('rev-parse', 'HEAD').decode().strip()
    source_before = {}
    for row in manifest['files']:
        rel = Path(row['path'])
        if rel.is_absolute() or '..' in rel.parts:
            raise RuntimeError('非法恢复路径')
        current = repo / rel
        source_before[str(rel)] = digest(current.read_bytes()) if current.is_file() else None
    for name, expected in manifest['patch_sha256'].items():
        path = package / name
        if path.is_symlink() or digest(path.read_bytes()) != expected:
            raise RuntimeError('补丁指纹不符：' + name)

    scratch.mkdir(parents=True)
    base_export = []
    for row in manifest['files']:
        original = row['git_base']
        if not original['exists']:
            continue
        raw = source_git('cat-file', 'blob', original['blob_oid'])
        if digest(raw) != original['sha256'] or len(raw) != original['bytes']:
            raise RuntimeError('Git 基底 blob 指纹不符：' + row['path'])
        target = scratch / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        base_export.append(row['path'])

    calls = []

    def apply(name):
        for check in [True, False]:
            argv = ['git', '--no-optional-locks', '--git-dir=' + str(git_dir),
                    '--work-tree=' + str(scratch), 'apply']
            if check:
                argv.append('--check')
            argv.append(str(package / name))
            result = subprocess.run(argv, cwd=scratch, capture_output=True, text=True, env=env)
            calls.append({'argv': argv, 'cwd': str(scratch), 'exit_code': result.returncode,
                          'stdout': result.stdout, 'stderr': result.stderr})
            if result.returncode != 0:
                print(json.dumps({'state': 'RESTORATION_FAILED_PRESERVE_SCRATCH',
                                  'scratch': str(scratch), 'calls': calls}, ensure_ascii=False, indent=2))
                raise RuntimeError('scratch 补丁应用失败；保留现场：' + name)

    def verify(label):
        results = []
        for row in manifest['files']:
            expected = row[label]
            path = scratch / row['path']
            exists = path.is_file()
            actual = path.read_bytes() if exists else None
            required = expected.get('exists', True)
            ok = exists == required and (not required or (
                digest(actual) == expected['sha256'] and len(actual) == expected['bytes']))
            results.append({'path': row['path'], 'exists': exists,
                            'bytes': len(actual) if actual is not None else None,
                            'sha256': digest(actual) if actual is not None else None,
                            'matches': ok})
        if any(not row['matches'] for row in results):
            print(json.dumps({'phase': label, 'results': results}, ensure_ascii=False, indent=2))
            raise RuntimeError('恢复指纹不一致；保留 scratch')
        return results

    apply(manifest['ordered_patches'][0])
    frozen_before = verify('frozen_before')
    for name in manifest['ordered_patches'][1:]:
        apply(name)
    candidate_after = verify('candidate_after')
    actual_files = sorted(str(path.relative_to(scratch)) for path in scratch.rglob('*') if path.is_file())
    if actual_files != sorted(row['path'] for row in manifest['files']):
        raise RuntimeError('scratch 文件清单与32个目标不一致')
    source_after = {rel: digest((repo / rel).read_bytes()) if (repo / rel).is_file() else None
                    for rel in source_before}
    print(json.dumps({
        'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'state': 'EXACT_BYTES_RESTORED_PENDING_UNREVIEWED_CANDIDATE',
        'package': str(package), 'scratch': str(scratch), 'source_repository': str(repo),
        'source_head_basis': source_head,
        'source_head_at_start': head_before,
        'source_head_at_end': source_git('rev-parse', 'HEAD').decode().strip(),
        'source_index_sha256_before': index_before,
        'source_index_sha256_after': digest(index_path.read_bytes()) if index_path.is_file() else None,
        'source_selected_files_changed_during_read': [rel for rel in source_before
                                                    if source_before[rel] != source_after[rel]],
        'git_blob_exports': len(base_export), 'frozen_before': frozen_before,
        'candidate_after': candidate_after, 'actual_file_count': len(actual_files), 'calls': calls,
        'qualification': '只证明从固定 Git 对象及补丁可恢复精确字节；无 Review/Cargo/TS/native 资格',
        'writes': '仅新 scratch；没有 --index/--cached，没有写源 checkout/HEAD/配置，没有清理',
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
