# Workspace 未合流候选保全包（2026-10-28）

状态：**未完成独立 Review、未完成最终验证、未合流生产**。本包属于人类明确暂停迭代后的工程保全，不表示功能完成，也不自动参加 Rust/TypeScript 编译。Root 统一决定复制到所属仓库的正式工程目录并 stage/commit；本线只在 ignored staging tree 准备。

## 内容与责任

保留冻结 manifest `2202b6c71d0c0177d5d619974e985e5d0b26565d4a1d12d3188533257e39b189` 中32文件的恢复信息和原5个候选补丁：W-C1 当前消息 object/退旧 thinking 数组与 rounds、W-C2 原生 NUL Worktree、W-C4 当前 producer 显式位置与消费者/测试夹具、中文 ADR。EKO 为唯一正式源码 writer，本线没有把候选写入生产。

Git 基底为 `080e0b698c664105f789f522779a985f93b4f71b`。该提交不等于候选冻结 before：后者含已存在的并行 WIP。`patches/00-source-head-to-frozen-base.patch` 只用于在隔离 scratch 重建冻结 before，不可当作新的生产合流补丁；随后依序应用原5个补丁得到32个 candidate after。Git 基底不存在的新文件，其完整内容已包含在相应补丁。无需同时保存重复的 full before/candidate 树。

已正式采用的 GUI Git/PTY TERM/branch-only反馈三修复不在本包中再次交付；基底覆盖到的已有源差异只作为冻结恢复上下文，不代表重新覆盖 EKO 当前源码的授权。前端 db38 的消息 producer 候选与本包部分文件不同 hunk，后继须由 EKO 统一审阅，不能整文件替换。W-C3 旧来源模块归 EKO 主 owner；W-D1 两处无 native 最终回复准入旁路及合法非流式 producer 的共享接缝只记录在 notes，未在本包中伪造 publication 或删掉非流式能力。

## 已有证据与限制

- 隔离当前 React 消费者副本：16文件、324测试自然0；TypeScript 第一次失败原日志保留，修当前fixture后第二次自然0。
- 精确 Worktree parser 函数体加标准库适配：before 4通过/2预期失败（exit101），candidate 6通过/0失败；编译使用 rustc -Dwarnings。不是完整 Tauri/Git/native 验收。
- 源码字段/分支驱动 JS 薄适配：before 6通过/4预期失败，candidate 10通过/0失败。不是原 Rust serde/registry 运行。
- rustfmt/Prettier已有日志保留。324与类型验证后还发生格式、测试名和注释变动，尚未完成最终独审与审后验证；**不能把上述历史结果授予最终2202整包门禁**。
- 从未运行本包 Cargo、真实 SSH、修后 App 或 live Worktree 创建。恢复演练只验证补丁应用和字节 SHA，不能替代这些验收。

## 恢复方法

在仍包含上述 Git 提交对象的 CLI 仓库旁，选择主根内一个**尚不存在**的 scratch 目录，执行：

```bash
python3 restore.py --repo /Users/ls/MyWork/code/ylp_agent_learn/lp-agent/echo-agent-cli --scratch /Users/ls/MyWork/code/ylp_agent_learn/lp-agent/.echo-semantic/local/workspace-preservation-restore-example
```

脚本拒绝覆盖已有 scratch，拒绝写入源 checkout，先从固定 Git blob 导出指定文件，再实际 `git apply`，分别核对 frozen-before 和 candidate-after SHA。它不改源 index/HEAD，不执行构建/测试，不 stage/commit。成功输出是保存可恢复性回执，工程候选仍未审/未合流。

根目录 `files.json` 列出本包全部其它文件的精确 bytes/SHA；该索引自身 bytes/SHA 由 Root 接收回执单独记录。原 candidate、旧 native116、169项源码保护证据、失败 ref/reflog、用户/auth 数据和旧 signed App 原件均保留，本线未清理。

## 明确排除

无二进制、Cargo target、node_modules symlink、用户配置或真实凭据、实际消息body。verification-source 仅保 `.txt` 源码接缝以解释已有日志，不放可被项目编译发现的 `.rs/.ts` 文件。原日志与原 manifest 保持原字节，不改写失败或补造通过。
