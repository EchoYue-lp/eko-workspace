# Workspace NoCompat 实际退役候选交接

执行源为用户亲自修改的总 Goal（SHA cd30e66fd0135d754a42c07169a5d49692c2e779f8975b6934c1ab3da498a5bb）和 Root 这轮明确实施授权。正式源码只有 EKO 单一 writer；本目录只保存函数级可合流补丁与实际验证，不是再次请求方案确认。

## 可合流补丁

- W-C1-current-message-object.patch：只接 object，删除旧 thinking 数组 parser、thinking_segments/execution_rounds 和 round DTO/types/构造/接纳测试；保 native blocks、b529 actual status/source、native_history_import、真实附件与 canonical call_id 步骤。Fork/Side 只移来源 UI message_id，当前 tool calls/steps 保持；测试用真实当前 Message producer，不手写旧 wrapper。
- W-C2-native-worktree-nul.patch：只解析现 producer 的 --porcelain -z，旧非 NUL 与缺终止符不构成列表事实；静态远端 fixture 变 NUL，保路径/Unicode/锁/完整 OID。
- W-C4-explicit-workspace-rust.patch：WorkspaceMetadata.project_location 必填，原 registry create/create_at/newLocal/SSH 先显式提供位置，删除缺字段按 project_root/root 推断。新 Metadata::new 必须带位置；原 inspect、revision、verified SSH、rollback、索引恢复和删数据保护继续。
- W-C4-current-frontend.patch：Workspace 接口同步必填，显示与终端不再猜位置；原当前测试夹具写明位置。多文件主要是现有夹具跟随类型合同，只有3处前端生产行/函数变化及新展示回归。
- current-contract-docs.patch：ADR0045/0055 同步当前消息合同、步骤复制、显式位置和 NUL 协议，旧正向兼容验收退役，不 skip、不标 matched/pass。

候选文件仅用于审阅，EKO 按 patch/function hunk 合流，不整文件覆盖其它 owner。SavedMessage 等6个TS/TSX producer退役由 db38 前端 owner 产包；本包 endpoints.ts 的 Workspace hunk与其 SavedMessage hunk独立，合并后必须再验真实 combined consumer。

## 已运行与边界

- 真实 current React consumer 隔离副本：16 files / 324 tests 自然0；全 src TypeScript 自然0。
- Worktree 精确生产 parser 函数体 + std 依赖 adapter：before 4 passed / 2 failed（非NUL/截断），candidate 6 passed / 0 failed；rustc -Dwarnings。不是完整 Tauri/Git/native 验收，未运行 live Git 创建。
- 附件/Workspace源码字段与分支驱动 JS 薄适配：before 6 passed / 4 failed，candidate 10 passed / 0 failed。仅约定驱动 adapter，不冒 Rust serde/registry 完整运行。
- Rust 源码仅格式解析；用户本轮明确禁 Cargo，产品 Rust、新 App、真实 SSH、完整资源 bytes/reader 与副作用不重放资格仍由 EKO 后继实际验证。现有 signed/encrypted Message 与 import verifier未改，不能据此声称已新验证协议。

W-C3 legacy_eko_history 由 EKO 主 owner 统一删除，本包不重复。W-D1 两个 final 无 native 旁路的当前 producer / 原 journal / 非流式接缝见 W-D1-shared-owner-seams.zh.md，已给 Root/EKO；不为共享 owner 的缺事实手填 publication 或只删 guard。

## 保全与交付

无 Cargo、UI/IPC、Framework写、target清理、旧用户数据/失败ref迁移或删除、stage/commit/push。用户原件、旧116native证据、失败/恢复包与保护tag不改。目录约2.6MiB前端src隔离输入和少量std测试，无新重构建。

文档在本包随源码；examples 搜索无此DTO/Metadata旧构造调用，注册表入口保持。官网能力与入口没有新增，故无需新示例/网站入口；后继 EKO 合流按正式 docs/examples/website 门禁复核。
