# W-D1：由 EKO 主 owner 统一闭合的接缝

用户当前授权要求先保持合法非流式能力，再在新唯一 typed publication 上严格统一。这里交准确接缝，不另造 producer、journal、bridge 或成功状态；不是旧兼容暂留的长期方案。

| 当前入口 | 原路径与 owner | 合流要求 |
|---|---|---|
| GUI | src/tauri/commands/chat.rs::send_chat_message_inner_with_side_admission → Foreground 原 lease → chat_driver::drive_chat_inner → AgentTurnDriver.drive → EkoTurnEventSink / JournaledChatSink → ChatEventLog | 原执行身份、Message/store 与同 execution 原事件必须一起闭合。 |
| IM | channel_runtime::MessageHandler::handle 只聚合 handle_stream，实际仍走 Foreground/shared driver，Channel sink 写 ChatEventLog | 保非流式 handle API；不能把聚合 OutboundMessage 文本重新当 canonical producer。 |
| cron | scheduler::build_occurrence_fire_fn_with_cancel → executor/events::drive_existing_cron_run → drive_owned_agent_turn → 原 driver；EkoAgentTurnSink::on_event → record_native_agent_event 写原 Run journal | 先核实际 canonical conversation/generation 与消费入口。当前 Fork reader 只读 ChatEventLog，但尚未证明 cron 会话就是产品 Fork 源，不能先造桥接或合成 Chat terminal。 |
| 同版导入恢复 | 正式 ConversationUpdateRequest 无 messages/import；project_saved_messages 仅 cfg(test)。活路径为 Side snapshot、managed replace_and_resume/resume_or_import、Fork | 保原 Message/CAS/checkpoint 和 provider opaque payload，不将 import 耐久成功当 publication 批准。 |

须在同一原 producer 合同闭合后同步处理 conversations.rs 的两处旧准入：`validated_reply_fork_publication_events` 对 !has_native 返回空 events；`validate_reply_fork_publication` 对 !has_native 返回 Ok。两处在本包中不改，避免仅删 guard 破坏当前非流式或补造成功。

尚需原 Framework owner 在现租约/安全切点给出真实 nonstream producer → 原 Message/store → 同 execution events 事实。CLI 主路径都调用 driver，并不能单独证明 F 内部 nonstream 已完整；ProjectAgentAdapter::chat 的 String、GUI 正文、旧 wrapper 或 TaskRun Completed 都不能反向生成署名、status 或 native origin。原 NativeHistoryImport、signed/encrypted history 完整回传保持。

预审者 /root/workspace_candidate_review 只读完成，未读 F、未 Cargo、未改文件/UI/进程。精确函数级结果已发送 Root/EKO；该项仍属 EKO 主 owner 的闭合动作，不标实现完成或 native pass。
