# Cross-chat GUI candidates（维护保全包）

状态：ignored engineering candidate，未审查完成、未合并、未验证最新修订。由 Root 按 EKO 正常预检、审查、门禁和提交流程处理。

## 来源

- Superproject snapshot: `c128fa1a9cbe5d91adc173bb71bf97e62fa7941a`。
- EKO formal checkout observed HEAD: `080e0b698c664105f789f522779a985f93b4f71b`。
- 完整候选 patch、逐路径 base/after/formal SHA 和每文件 patch 在 `evidence/`。
- 候选来自 `gui-interagent-timeline-20261028`；原图、失败日志和维护冻结状态按原路径保留。

## 行为范围

候选实现 typed AgentRouter 来源、live/cold canonical 输入、持久 ResourceLink、只读时间线、来源/正文折叠、typed 发送回执、代际安全导航、Fork 人类序号与原始时间顺序。它不解析旧 wrapper、不信工具输出字符串、不授用户 Goal/编辑权、不新增手工协作管理台。

## 证据边界

上一个可复现前端快照为9文件/149项测试自然0与TypeScript自然0；最新源码修订之后没有重跑测试或最终Review。Rust新回归没有Cargo结果。Provider NoCompat小补丁未组合，不能借其211项资格。

`evidence/scratch-apply-readback.json`只证明候选patch在候选base副本上的静态apply和逐SHA回读；不证明正式当前checkout可直接应用。共享正式文件漂移已在`base-after-index.json`明确，必须按函数hunk三方合并。

## 收口

本包不包含stage、commit、push、merge、Cargo、Host、模型、原生GUI或业务外部调用。Root统一保存/提交；恢复前重新核对formal base、Provider后继和当前Goal，不把本包状态写成Goal完成。


## 维护尝试记录

当前目录是 `staging-v2`。原 v1 保留。第一次不完整生成和被安全拒绝的 `rm -rf` 记录见 `evidence/maintenance-attempt-history.json`；其后仅删除了本次新建的不完整自有目录，没有删除其它材料。后续不再清理，由 Root 按精确 manifest 统一裁决。
